from pathlib import Path
import json,re,hashlib,struct,collections
R=Path(__file__).resolve().parent;blob=(R.parent/'outputs/gameplay_payload_capture/gameplay_luraph_blob.bin').read_bytes()
# Exact replacements from the source's e3 table (string.gsub table replacement).
replacements={b'|':b'1>^XZ',b' ':b'Tj@xi',b'"':b'1.-BY',b'#':b'J>%RD',b'!':b'WRWT?',b'z':b'&p?(.',b'~':b'2g6Si',b'{':b'9tqs*',b'y':b'E-_/?',b'}':b'2n;^>'}
stage1=re.sub(rb'[ -#y-~]',lambda m:replacements.get(m[0],m[0]),blob[4:])
assert len(stage1)%5==0
# u3 state path: x3(41) -> J3(34) builds N3/V3 with F=69,D=99;
# then c3(4), A3(0), p3(31), E3(7), i3(14), E3(5).
# E3(7) splits the first four input bytes; i3(14) assigns weights as below.
weights=[85**3,85,85**4,85**2,1]
output=bytearray();overflow=0;maximum=0
for i in range(0,len(stage1),5):
 word=sum((byte-36)*weight for byte,weight in zip(stage1[i:i+5],weights));maximum=max(maximum,word)
 if not 0<=word<2**32:overflow+=1
 output.extend(struct.pack('<I',word&0xffffffff))
(R/'main_base85_decoded.bin').write_bytes(output)
(R/'main_base85_expanded.txt').write_bytes(stage1)
report={'encoded_bytes':len(blob),'expanded_bytes':len(stage1),'decoded_bytes':len(output),'weights_in_input_order':weights,'overflow_words':overflow,'maximum_word':maximum,'decoded_sha256':hashlib.sha256(output).hexdigest(),'prefix_hex':output[:48].hex()}
(R/'main_base85_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
