from gameplay_graph import *
import hashlib
NEW=Path(__file__).resolve().parent.parent/'captures/run_1795730693_100093'
def resolve_new(name):
 p=NEW/Path(name).name
 return p if p.exists()else p.with_suffix('.txt')
class NewGraph(Graph):
 def __init__(self):
  self.nodes={}
  for p in NEW.glob('nodes_*.json'):
   for n in json.loads(p.read_text()):self.nodes[n['id']]=n
  self.manifest=json.loads((NEW/'manifest.txt').read_text())
 def scalar(self,v):
  if v.get('t')=='string'and'file'in v:return resolve_new(v['file']).read_bytes()
  return super().scalar(v)

if __name__=='__main__':
 old=Graph();new=NewGraph()
 print('labels example',new.manifest['labels'][:2])
 matches=[r for r in new.manifest['labels']if 'Auto Kick'in bytes.fromhex(r['labelHex']).decode()]
 print('auto kick',matches)
 callback=matches[0]['callback']['ref'];uv=dict(new.pairs(callback,'upvalues'))
 state=uv[34][1];data=dict(new.pairs(state));offsets=dict(new.pairs(data[5][1]));prior=dict(old.pairs(1527))
 print('new ids',{'auto_kick':callback,'state':state,'offsets':data[5][1],'buffer':data[4][1],'vm':uv[35]})
 changes=[(k,prior.get(k),v)for k,v in offsets.items()if prior.get(k)!=v]
 print('metadata changes',len(changes),changes[:30])
 a=(BASE/'runtime_graph/buffer_1528.bin').read_bytes();b=resolve_new(new.nodes[data[4][1]]['file']).read_bytes()
 print('buffer bytes',len(a),len(b),'different',sum(x!=y for x,y in zip(a,b)))
 print('new snapshot scalar135',offsets.get(135))
 report={'new_callback':callback,'new_state':state,'offset_changes':changes,'different_buffer_bytes':sum(x!=y for x,y in zip(a,b))}
 (R/'snapshot_comparison.json').write_text(json.dumps(report,indent=2))
