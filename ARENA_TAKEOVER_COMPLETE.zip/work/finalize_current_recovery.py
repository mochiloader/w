from pathlib import Path
import sys,json,re,subprocess,concurrent.futures
R=Path(__file__).resolve().parent;O=R.parent/'outputs/gameplay_recovery_current'
sys.path.insert(0,str(R/'luraph-tool/core'))
from ir import fmt_const
def quote_bytes(v):return '"'+''.join(chr(x)if 32<=x<127 and x not in [34,92]else '\\%03d'%x for x in v)+'"'
AST=Path(r'C:/Users/dorto/Documents/Codex/2026-10-18/i-want-you-to-fully-install/outputs/tools/luau/luau-ast.exe')
report=json.loads((O/'recovery_report.json').read_text())
def walk(n):
 if isinstance(n,dict):
  if 'type'in n:yield n
  for k,v in n.items():
   if k!='local':yield from walk(v)
 elif isinstance(n,list):
  for v in n:yield from walk(v)
def check(row):
 if row['status']!='translated body':return row
 p=subprocess.run([str(AST),str(O/row['file'])],capture_output=True,timeout=10)
 if p.returncode:
  row['status']='translation rejected';row['validation_error']=p.stderr.decode('utf8','replace')[:300];return row
 tree=json.loads(p.stdout.decode('latin1'))
 leaked=sorted({n['global']for n in walk(tree)if n['type']=='AstExprGlobal'and re.fullmatch(r'[GSdx]_\d+',n['global'])})
 if leaked:row['status']='translation rejected';row['validation_error']='Unbound VM loop state: '+', '.join(leaked)
 else:row['syntax_validated']=True;row['behavioral_equivalence_proven']=False
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:report=list(pool.map(check,report))
(O/'recovery_report.json').write_text(json.dumps(report,indent=2))
body=['-- PARTIAL RECOVERY. Not a runnable replacement for the original hub.','-- Each entry is a factory requiring the captured environment values.','-- Syntax checked; behavioral equivalence is not proven for all bodies.','local recovered = {}']
for row in report:
 if row['status']=='translated body':body.append('recovered['+json.dumps(row['name'])+'] = (function()\n'+(O/row['file']).read_text()+'\nend)()')
body.append('return recovered')
(O/'readable_recovered_bodies.lua').write_text('\n\n'.join(body)+'\n')
pool=json.loads((R/'isolated_constant_results.json').read_text());cached=json.loads((R/'cached_constant_index.json').read_text())
strings={r['index']:bytes.fromhex(r['value']['hex'])for r in pool if r['ok']and r['value']['type']=='string'}
for k,row in cached['old_values'].items():
 v=row['value']
 if v.get('t')=='string'and'hex'in v:strings[int(k)]=bytes.fromhex(v['hex'])
(O/'decoded_strings.lua').write_text('return {\n'+'\n'.join(' ['+str(k)+'] = '+quote_bytes(v)+','for k,v in sorted(strings.items()))+'\n}\n')
counts={s:sum(r['status']==s for r in report)for s in sorted({r['status']for r in report})}
summary={'functions_examined':len(report),'status_counts':counts,'translated_named_globals':[r['name']for r in report if r['status']=='translated body'and r['origin']=='named gameplay global'],'translated_ui_controls':sum(r['status']=='translated body'and r['origin']=='UI control'for r in report),'translated_other_functions':sum(r['status']=='translated body'and r['origin']=='unnamed captured function'for r in report),'isolated_constant_attempts':len(pool),'isolated_successful_entries':sum(r['ok']for r in pool),'live_cached_unique_entries':cached['old_unique'],'cross_checked_scalar_constants':cached['overlap_scalar_checks'],'cross_check_mismatches':cached['overlap_mismatches'],'decoded_string_entries':len(strings),'full_gameplay_recovered':False,'standalone_replacement':False}
(O/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
