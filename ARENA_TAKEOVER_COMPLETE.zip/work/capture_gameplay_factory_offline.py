from pathlib import Path
import subprocess
R=Path(__file__).resolve().parent
s=(R/'isolated_main_decoder.lua').read_text()
s='local __rootSteps=0\n'+s.replace('while true do local lo=D[Z];','while true do __rootSteps+=1;if __rootSteps<1200 then print("ROOT_PC",Z,D[Z])end;local lo=D[Z];')
s='local __offlineBudget=0\n'+s.replace('while true do','while true do __offlineBudget+=1;if __offlineBudget>300000 then error("OFFLINE_LOOP_BUDGET "..debug.traceback(),0)end;')
s='''local pending={}
local base=getfenv(0)
local realLoadstring=loadstring
local sandbox={task={cancel=function()end,wait=function()return 0 end,spawn=function(f,...)table.insert(pending,{f,table.pack(...)});return coroutine.create(function()end)end}}
local function spawn(f,...)
 local thread=coroutine.create(f)
 local ok,err=coroutine.resume(thread,...)
 if not ok then print("OFFLINE_TASK_ERROR",tostring(err))end
 return thread
end
sandbox.task.spawn=spawn
sandbox.task.wait=function()return coroutine.yield(0)end
local function datatype(...)return {...}end
for _,name in ipairs({"Vector3","Vector2","CFrame","Color3","UDim","UDim2","Rect","Instance","Random","Path2DControlPoint","PhysicalProperties","Font","TweenInfo","NumberSequence","ColorSequence","NumberSequenceKeypoint","ColorSequenceKeypoint","Ray","Region3","BrickColor","Axes","Faces","DateTime"})do sandbox[name]={new=datatype}end
sandbox.identifyexecutor=function()return "OFFLINE_ANALYSIS"end
sandbox.task.defer=sandbox.task.spawn;sandbox.task.delay=function(_,f,...)return sandbox.task.spawn(f,...)end
sandbox.getgenv=function()return sandbox end
sandbox.loadstring=function(text,name)
 print("OFFLINE_COMPILE",#text)
 local f,err=realLoadstring(text,name)
 if f then setfenv(f,sandbox)end
 return f,err
end
setmetatable(sandbox,{__index=function(_,k)local v=base[k];if v==nil then print("MISSING_GLOBAL",k)end;return v end})
setfenv(1,sandbox)
setfenv(0,sandbox)
'''+s
a=s.index('vm.C3=function');s=s[:a]+'''
local captures=0
vm[122]=function(self,...)
 captures+=1
 print("MAIN_FACTORY",captures)
 dump(table.pack(...),"main_factory_"..captures)
 return function(...)
  dump(table.pack(...),"main_middle_"..captures)
  return function(...)error("STOP_BEFORE_MAIN_GAMEPLAY_EXECUTION",0)end
 end
end
local ok,result=pcall(function()
 local root=vm:u3()
 print("ROOT_READY",type(root))
 return root()
end)
print("RESULT",ok,tostring(result))
'''
(R/'capture_gameplay_factory_offline.lua').write_text(s)
try:
 p=subprocess.run([str(R/'luau-custom-build/Release/luau.exe'),str(R/'capture_gameplay_factory_offline.lua')],capture_output=True,timeout=15)
 (R/'gameplay_factory_offline.dump.txt').write_bytes(p.stdout)
 print('exit',p.returncode,'output bytes',len(p.stdout),'stderr',p.stderr.decode('utf8','replace')[-600:])
 for line in p.stdout.decode('utf8','replace').splitlines():
  if line.startswith(('ROOT_READY','MAIN_FACTORY','RESULT','MISSING_GLOBAL')):print(line[:500])
except subprocess.TimeoutExpired as e:
 (R/'gameplay_factory_offline.dump.txt').write_bytes(e.stdout or b'');print('Timed out and terminated owned offline Lua process after 15 seconds')
