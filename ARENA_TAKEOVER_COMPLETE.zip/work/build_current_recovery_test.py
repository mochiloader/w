from pathlib import Path
R=Path(__file__).resolve().parent;O=R.parent/'outputs'
original=(O/'gameplay_deobfuscated/validate_auto_callback.lua').read_text()
new=(O/'gameplay_recovery_current/Automatics_Auto_Kick_126.lua').read_text()
test=original+'\nlocal makeRecovered=(function()\n'+new+'\nend)()\n'+'''
for _,value in ipairs({true,false,"sentinel",17})do
 local recoveredSettings={Automatics={}}
 local fn=makeRecovered(recoveredSettings)
 recoveredVM(value);fn(value)
 assert(settings.Automatics.AutoKick==recoveredSettings.Automatics.AutoKick,"new body mismatch")
end
print("PASS: new source-AST translation matches reconstructed VM for four inputs")
'''
(R/'test_current_recovery.lua').write_text(test)
