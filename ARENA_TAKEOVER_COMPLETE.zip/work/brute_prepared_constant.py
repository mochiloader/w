from isolated_constant_pool import *
from collections import Counter

def read_length(data,off):
 x=data[off]
 if x<128:return x,off+1
 y=data[off+1]
 if y<128:return x-128+y*128,off+2
 z=data[off+2]
 if z<128:return x-128+(y-128)*16384+z*128,off+3
 w=data[off+3]
 return (x-128)*16384+(y-128)*128+(z-128)+w*2097152,off+4

if __name__=='__main__':
 g=Graph();s=DecoderSnapshot(g);t=s.runtime;pool=json.loads((R/'isolated_constant_results.json').read_text())
 known={bytes.fromhex(r['value']['hex'])for r in pool if r['ok']and r['value']['type']=='string'}
 results=[]
 for index in ([int(x)for x in sys.argv[1:]]or[1520,4758,4352,2217,135]):
  offset=t.val({'ref':1527}).get(index);offset=offset^0x681aedb if offset>=732385 else offset
  original=bytes(t.val({'ref':1528}).data);length,start=read_length(original,offset+1)
  print('START',index,offset,original[offset],length,flush=True)
  if length>1500000:continue
  counts=Counter();hits=[]
  for key in range(256):
   s.reset();t.val({'ref':1527}).set(index,offset);buf=t.val({'ref':1528})
   buf.data[start:start+length]=bytes(x^key for x in original[start:start+length])
   p=S.LTable({-1:S.LTable({1:index}),-2:t.val({'ref':1934})});p.meta=t.val({'ref':1525});it=BoundedInterp(t)
   try:
    v=t.index(p,1,it);counts[type(v).__name__]+=1
    if isinstance(v,(S.LuaFunc,Ref,S.Builtin))or isinstance(v,bytes)and v in known:
     hit={'key':key,'type':type(v).__name__,'value':repr(v)[:250]};hits.append(hit);print('HIT',index,hit,flush=True)
   except Exception as e:counts[type(e).__name__]+=1
  results.append({'index':index,'length':length,'types':dict(counts),'hits':hits});print('COUNTS',index,counts,flush=True)
 (R/'prepared_constant_candidates.json').write_text(json.dumps(results,indent=2))
