from pathlib import Path
import subprocess
R=Path(__file__).resolve().parent
source=(R/'isolated_main_decoder.lua').read_text();a=source.index('vm.C3=function');b=source.index('local ok,err=',a)
replacement='''for _,id in ipairs({17,122})do
 vm[id]=function(self,...)
  print("FACTORY",id);dump(table.pack(...),"factory"..id)
  return function(...)
   print("MIDDLE",id);dump(table.pack(...),"middle"..id)
   return function(...)error("STOP_BEFORE_VIRTUAL_CODE",0)end
  end
 end
end
'''
source=source[:a]+replacement+source[b:]
(R/'captured_main_factories.lua').write_text(source)
try:
 result=subprocess.run([str(R/'luau-custom-build/Release/luau.exe'),str(R/'captured_main_factories.lua')],capture_output=True,timeout=10)
 (R/'main_factories.dump.txt').write_bytes(result.stdout)
 print('exit',result.returncode,'bytes',len(result.stdout),'stderr',result.stderr.decode('utf8','replace')[-500:])
 for l in result.stdout.decode('utf8','replace').splitlines():
  if l.startswith(('FACTORY','MIDDLE','RESULT')):print(l)
except subprocess.TimeoutExpired as e:
 (R/'main_factories.partial.txt').write_bytes(e.stdout or b'');print('Stopped owned local decoder after 10-second bound')
