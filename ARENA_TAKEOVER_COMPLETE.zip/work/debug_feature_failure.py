from lift_captured_source import *
g=Graph();s=DecoderSnapshot(g);t=s.runtime;load_patches(t);m=build_model(t)
p=json.loads((R/'isolated_constant_results.json').read_text());t.pool_exports={r['index']:r['value']for r in p if r['ok']}
c=json.loads((R/'cached_constant_index.json').read_text());t.cached_pool_values={int(k):v for k,v in c['old_values'].items()}
node=int(sys.argv[1])if len(sys.argv)>1 else 1499
i,order,errors,lf=lift_one(t,m,node,1200)
print('ERRORS',errors)
for k,n in order:print(k,'OP',getattr(n,'op',None),'\n'+'\n'.join(fmt_node(n)))
source=(R.parent/'outputs/full_gameplay_payload.lua').read_text()
ds=vmmap.find_dispatchers(m.vm)
for k,n in order:
 if getattr(n,'error',None):
  mode,pc=k[:2];opcode=n.op[1]
  for d in ds:
   w=d['node'];pos=source.rfind('if ',0,int(w['location'].split(' - ')[0].split(',')[1]));head=source[pos:pos+60]
   if str(mode)not in head:continue
   branch=vmmap.resolve(d['tree'],d['op'],opcode)
   if branch:print('FAILED HANDLER',head,vmmap.text_of(source.splitlines(),branch))
