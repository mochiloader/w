-- Captured function: Catching/Magnets Type
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.MagnetType = arg1
 end
end
