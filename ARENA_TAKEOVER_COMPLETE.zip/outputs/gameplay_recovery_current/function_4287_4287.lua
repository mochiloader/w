-- Captured function: function_4287
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1, arg2)
local r2 = { Instance = arg1, Apply = arg2, State = false }
capture1.insert(capture2, r2)
return r2
 end
end
