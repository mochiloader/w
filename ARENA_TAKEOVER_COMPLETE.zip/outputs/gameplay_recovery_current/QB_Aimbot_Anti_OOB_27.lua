-- Captured function: QB Aimbot/Anti OOB
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r33)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.oobFilter = r33
		return
	end
end
 end
end
