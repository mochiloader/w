-- Captured function: function_2340
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, capture12, capture13, capture14, capture15, capture16, capture17, capture18, capture19, capture20, capture21, capture22, capture23, capture24, capture25, capture26, capture27, capture28, capture29, capture30, captured_function_4272, captured_function_4273, captured_function_4274, captured_function_4276, captured_function_4279, captured_function_4280, captured_function_4281, captured_function_4282, captured_function_4283)
 return function(arg1, r21)
r21.AddToggle = captured_function_4282(nil, 366048678, 3256843861, 4043761288, 1638753582)
r21.AddSlider = captured_function_4283(nil, 3396289550, 1716297572, 1383613901, 3862570080)
r21.AddDropdown = captured_function_4273(nil, 3110066296, 2509150501, 3821622139, 3114362341)
r21.AddInput = captured_function_4272(nil, 2471435650, 1709063950, 3900207684, 1791741578)
r21.AddKeybind = captured_function_4274(nil, 1692386396, 1058371658, 651658242, 523613964)
r21.AddColorPicker = captured_function_4279(nil, 1038049379, 696185106, 2663954640, 1721860510)
r21.AddButton = captured_function_4280(nil, 2261311413, 4006365322, 2481625949, 3577079538)
r21.AddButtonRow = captured_function_4281(nil, 796420764, 460393715, 4208309027, 2036989875)
r21.AddLabel = captured_function_4276(nil, 3367943030, 2300253872, 1969042350, 3765373783)
 end
end
