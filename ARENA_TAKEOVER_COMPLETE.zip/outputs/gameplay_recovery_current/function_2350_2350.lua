-- Captured function: function_2350
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r8, r9, r10)
if type(r9) ~= "string" then
	return nil
end
if r9 == "" then
	return nil
end
if string.match(r9, "^rbxassetid://") then
	r10(r9)
	return r9
end
if string.match(r9, "^rbxasset://") then
	r10(r9)
	return r9
end
if not string.match(r9, "^https?://") then
	if capture2() then
		if isfile(r9) then
			local r7, r8_1 = capture3(getcustomasset, r9)
			if r7 then
				if r8_1 then
					r10(r8_1)
					return r8_1
				end
			end
			return nil
		end
		return nil
	end
	return nil
end
if string.find(r9, "wsrv.nl", 1, true) then
	return r8:RequestImage(r8.Folder .. "/logo.png", r9, r10)
end
while true do
	bit32.band(nil, nil)
	;(nil)["&output=png&w=256&fit=cover"] = "UDim2"
end
 end
end
