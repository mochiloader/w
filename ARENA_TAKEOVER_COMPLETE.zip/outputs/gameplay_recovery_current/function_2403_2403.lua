-- Captured function: function_2403
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r25, r26)
if r25.LockIcon then
	local r1 = r25.LockIcon
	local r5
	if r26 then
		r5 = capture1.Text or capture1.Accent
	else
		r5 = capture1.Accent
		r1.ImageColor3 = r5
		return
	end
	r1.ImageColor3 = r5
	return
end
 end
end
