-- Captured function: Physics/Block Reach
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.BlockReach = arg1
 end
end
