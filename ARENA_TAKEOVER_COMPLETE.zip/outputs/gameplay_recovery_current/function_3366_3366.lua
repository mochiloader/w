-- Captured function: function_3366
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(arg1, r34, r35)
local r36, r37, r38 = (capture1(r34) or capture2.Accent):ToHSV()
capture3 = r36
capture4 = r37
capture5 = r38
capture6(r35)
 end
end
