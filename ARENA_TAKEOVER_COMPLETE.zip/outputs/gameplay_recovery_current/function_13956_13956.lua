-- Captured function: function_13956
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
local r6 = capture3.offset
return capture1(capture2() + r6)
 end
end
