-- Captured function: function_3839
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r31)
r31.BackgroundTransparency = r31.BackgroundTransparency or 1
r31.Font = r31.Font or Enum.Font.GothamMedium
r31.TextSize = r31.TextSize or 13
r31.TextColor3 = r31.TextColor3 or capture1.Text
r31.TextXAlignment = r31.TextXAlignment or Enum.TextXAlignment.Left
return capture2("TextLabel", r31)
 end
end
