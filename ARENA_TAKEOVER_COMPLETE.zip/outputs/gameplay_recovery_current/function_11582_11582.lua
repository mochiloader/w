-- Captured function: function_11582
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r23, r24)
return capture1("Frame", {
	BackgroundColor3 = capture2.Divider,
	BorderSizePixel = 0,
	Size = UDim2.new(1, -capture3.Inset * 2, 0, 1),
	Position = UDim2.new(0, capture3.Inset, 1, -1),
	LayoutOrder = r24 or 0,
	Parent = r23,
})
 end
end
