-- Captured function: function_2331
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r12, r13, r14, r15)
local r2
if r13 then
	if r14 then
		r2 = string.format("[%s] %s", capture1(r13), capture1(r14))
	else
		r13 = r14 or r13 or ""
		r2 = capture1(r13)
	end
else
	r2 = capture1(r14 or r13 or "")
end
return r12:Notify(r2, r15)
 end
end
