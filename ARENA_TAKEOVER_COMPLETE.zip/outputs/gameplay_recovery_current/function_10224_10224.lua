-- Captured function: function_10224
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r33, r34)
if r33 ~= nil then
	return capture1(r33):gsub("[^ -~]", ""):sub(1, r34 or 64)
end
return nil
 end
end
