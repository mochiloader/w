-- Captured function: function_15248
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r37, r38)
local r5 = 1
local r6 = 0
while true do
	if r37 % 2 ~= r38 % 2 then
		r6 += r5
	end
	r37 = capture1(r37 / 2)
	r38 = capture1(r38 / 2)
	r5 *= 2
	if x_1 <= 0 then
		if d_1 >= S_1 then
			continue
		end
	elseif d_1 <= S_1 then
		continue
	end
	break
end
return r6
 end
end
