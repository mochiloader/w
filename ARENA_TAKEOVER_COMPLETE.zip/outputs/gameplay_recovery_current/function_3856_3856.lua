-- Captured function: function_3856
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_10540)
 return function()
local r2 = captured_function_10540(nil, 1796153206, 510242563, 3677318953, 1060224852)
capture1(r2)
return true
 end
end
