-- Captured function: function_10951
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function(r23)
local r4 = {}
local r3
if r23 then
	r3 = 0.55
else
	r3 = 1
end
r4.BackgroundTransparency = r3
capture1(capture2, r4, capture3.Quick)
local r4_1 = {}
local r3_2
if r23 then
	if capture5.Value then
		r3_2 = capture6.Control
	else
		r3_2 = capture6.Track or capture6.Control
	end
else
	r3_2 = capture6.Control
end
r4_1.BackgroundColor3 = r3_2
local r2 = capture3
if capture7 + 65851903 == 527042266 then
	capture7 = bit32.bxor(capture7, 1368606479)
end
capture1(capture4, r4_1, r2.Quick)
 end
end
