-- Captured function: Player/Fly
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r26)
capture1.enabled = r26
if capture3 ~= 280510937 then
	capture3 = bit32.bxor(capture3, 3568086171)
	if r26 then
		return
	end
elseif r26 then
	return
end
capture2()
 end
end
