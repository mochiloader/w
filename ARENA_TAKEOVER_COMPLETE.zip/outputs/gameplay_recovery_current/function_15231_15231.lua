-- Captured function: function_15231
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1.now().UnixTimestampMillis
 end
end
