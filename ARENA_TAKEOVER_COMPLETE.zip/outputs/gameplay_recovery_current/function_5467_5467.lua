-- Captured function: function_5467
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, captured_function_12123)
 return function(r17)
local r7 = capture1(r17)
capture2.floor(r17.w - r17.left)
local r3 = 1
local r4 = capture2.random(3, 4)
local r3_1, r4_1
if 1 <= 0 then
	if r3 >= r4 then
		while true do
			r3_1 = capture3.spawn
			r4_1 = captured_function_12123(nil, 285835514, 718236952, 142698666, 1268534752)
			r3_1(r4_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	while true do
		r3_1 = capture3.spawn
		r4_1 = captured_function_12123(nil, 285835514, 718236952, 142698666, 1268534752)
		r3_1(r4_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
capture9(r7, 7)
 end
end
