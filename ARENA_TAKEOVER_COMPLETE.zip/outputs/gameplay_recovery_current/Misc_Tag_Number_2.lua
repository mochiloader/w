-- Captured function: Misc/Tag Number
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r28)
if capture1 then
	capture1(r28, false)
	return
end
 end
end
