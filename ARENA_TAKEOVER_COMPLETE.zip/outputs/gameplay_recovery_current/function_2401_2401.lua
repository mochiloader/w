-- Captured function: function_2401
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r31, r32)
if r31.ScreenGui then
	r31.ScreenGui.Enabled = r32
	return
end
 end
end
