-- Captured function: Automatics/Rush End Part
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r25)
local r1 = capture1
if bit32.bxor(capture2, 529594001) == 65578037 then
	capture2 = bit32.bxor(capture2, 2017170929)
end
r1.ShowEndPart = r25
 end
end
