-- Captured function: function_13949
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r4)
local r10 = capture1.create(r4)
local r3 = 1
local r12, r5
if 1 <= 0 then
	if r3 >= r4 then
		r12 = r3
		while true do
			r5 = capture2.random(0, 15)
			r10[r12] = ("0123456789abcdef"):sub(r5 + 1, r5 + 1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r12 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r12 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	r12 = r3
	while true do
		r5 = capture2.random(0, 15)
		r10[r12] = ("0123456789abcdef"):sub(r5 + 1, r5 + 1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r12 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r12 = d_1
				continue
			end
			break
		end
	end
end
return capture1.concat(r10)
 end
end
