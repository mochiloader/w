-- Captured function: function_15233
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function(r5)
if type(r5.sig) ~= "string" then
	return false
end
if capture1.secret then
	local r13 = capture1.secret
	local r8 = capture4(r5.type)
	local r9 = r5.seq or 0
	local r10 = r5.sentAt or r5.timestamp or 0
	local r11 = r5.body or ""
	local r3 = r5.sig
	return capture5(capture2(r13, capture3(r8, r9, r10, r11)), r3)
end
return false
 end
end
