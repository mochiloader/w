-- Captured function: function_15236
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, captured_function_15472, captured_function_15473)
 return function(r31)
local r6 = {}
captured_function_15473(nil, 315121190, 3606719297, 2457086926, 2561979950)
local r1 = captured_function_15472(nil, 1389065300, 303243142, 3978413264, 4021745580)(r31, 203917118)
if r1 == 130817972 then
	bit32.bxor(r1, 555761883)
end
return table.concat(r6)
 end
end
