-- Captured function: function_4908
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(captured_function_11874)
 return function(r25)
local r6 = string.gsub
local r5 = captured_function_11874(nil, 198104347, 2725675228, 890010951, 2017426620)
return (r6(r25, "[^%w%-%.%_%~]", r5))
 end
end
