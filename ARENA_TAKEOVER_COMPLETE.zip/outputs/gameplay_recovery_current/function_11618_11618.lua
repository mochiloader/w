-- Captured function: function_11618
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(r22, r23)
if capture1 then
	capture1:Cancel()
	capture2:Cancel()
	capture1 = nil
	capture2 = nil
	if r23 then
		capture1 = capture3(capture4, { Size = UDim2.fromScale(r22, 1) }, capture5.Smooth)
		capture2 = capture3(capture6, { Position = UDim2.fromScale(r22, 0.5) }, capture5.Smooth)
		return
	end
elseif r23 then
	capture1 = capture3(capture4, { Size = UDim2.fromScale(r22, 1) }, capture5.Smooth)
	capture2 = capture3(capture6, { Position = UDim2.fromScale(r22, 0.5) }, capture5.Smooth)
	return
end
capture4.Size = UDim2.fromScale(r22, 1)
capture6.Position = UDim2.fromScale(r22, 0.5)
 end
end
