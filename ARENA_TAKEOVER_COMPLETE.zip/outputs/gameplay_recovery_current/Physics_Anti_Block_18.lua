-- Captured function: Physics/Anti Block
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.AntiBlock = arg1
 end
end
