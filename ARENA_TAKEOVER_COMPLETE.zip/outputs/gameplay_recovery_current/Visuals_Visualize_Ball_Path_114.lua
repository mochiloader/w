-- Captured function: Visuals/Visualize Ball Path
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r31)
capture1.Visuals.PathBeam = r31
if r31 then
	startPath()
	return
end
stopPath()
 end
end
