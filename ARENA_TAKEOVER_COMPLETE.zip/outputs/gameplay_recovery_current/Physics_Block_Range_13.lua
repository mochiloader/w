-- Captured function: Physics/Block Range
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.BlockReachRange = arg1
 end
end
