-- Captured function: function_3663
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if capture1 then
	capture1 = nil
	if _G.FF3HUD then
		if _G.FF3HUD.SetLocked then
			_G.FF3HUD:SetLocked(false)
			return
		end
	end
	return
end
local r2 = capture2()
if r2 then
	capture1 = r2
	if _G.FF3HUD then
		if _G.FF3HUD.SetLocked then
			_G.FF3HUD:SetLocked(true)
			return
		end
	end
end
 end
end
