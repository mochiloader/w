-- Captured function: Physics/Dive Boost
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(arg1)
DiveBoost.on = arg1
 end
end
