-- Captured function: function_5371
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r11, r12)
for _, r3 in ipairs(r11:GetChildren()) do
	local exitTo = nil
	local exitTo2 = nil
	local r8
	while true do
		if r3:IsA("SurfaceAppearance") then
			r8 = #r12.Detached + 1
			r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
			r3.Parent = nil
			local t60_37_1 = table.pack(d_1())
			if t60_37_1[1] then
				r3 = t60_37_1[3]
				continue
			end
			break
		else
			exitTo2 = 1
			break
		end
	end
	if exitTo2 == 1 then
		local exitTo4, exitTo3, exitTo6, exitTo5
		if r3:IsA("Decal") then
			exitTo4 = nil
			while true do
				r8 = #r12.Detached + 1
				r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
				r3.Parent = nil
				local t60_37_1 = table.pack(d_1())
				if t60_37_1[1] then
					r3 = t60_37_1[3]
					exitTo3 = nil
					while true do
						if r3:IsA("SurfaceAppearance") then
							r8 = #r12.Detached + 1
							r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
							r3.Parent = nil
							local t60_37_1 = table.pack(d_1())
							if t60_37_1[1] then
								r3 = t60_37_1[3]
								continue
							end
							break
						else
							exitTo3 = 1
							break
						end
					end
					if exitTo3 == 1 then
						if r3:IsA("Decal") then
							continue
						else
							exitTo4 = 1
							break
						end
					end
					break
				else
					break
				end
			end
			if exitTo4 == 1 then
				if r3:IsA("Texture") then
					exitTo6 = nil
					while true do
						r8 = #r12.Detached + 1
						r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
						r3.Parent = nil
						local t60_37_1 = table.pack(d_1())
						if t60_37_1[1] then
							r3 = t60_37_1[3]
							exitTo5 = nil
							while true do
								if r3:IsA("SurfaceAppearance") then
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										continue
									end
									break
								else
									exitTo5 = 1
									break
								end
							end
							if exitTo5 == 1 then
								if r3:IsA("Decal") then
									exitTo6 = 1
									break
								elseif r3:IsA("Texture") then
									continue
								else
									exitTo6 = 2
									break
								end
							end
							break
						else
							break
						end
					end
					if exitTo6 == 1 then
						while true do
							exitTo4 = nil
							while true do
								r8 = #r12.Detached + 1
								r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
								r3.Parent = nil
								local t60_37_1 = table.pack(d_1())
								if t60_37_1[1] then
									r3 = t60_37_1[3]
									exitTo3 = nil
									while true do
										if r3:IsA("SurfaceAppearance") then
											r8 = #r12.Detached + 1
											r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
											r3.Parent = nil
											local t60_37_1 = table.pack(d_1())
											if t60_37_1[1] then
												r3 = t60_37_1[3]
												continue
											end
											break
										else
											exitTo3 = 1
											break
										end
									end
									if exitTo3 == 1 then
										if r3:IsA("Decal") then
											continue
										else
											exitTo4 = 1
											break
										end
									end
									break
								else
									break
								end
							end
							if exitTo4 == 1 then
								if r3:IsA("Texture") then
									exitTo6 = nil
									while true do
										r8 = #r12.Detached + 1
										r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
										r3.Parent = nil
										local t60_37_1 = table.pack(d_1())
										if t60_37_1[1] then
											r3 = t60_37_1[3]
											exitTo5 = nil
											while true do
												if r3:IsA("SurfaceAppearance") then
													r8 = #r12.Detached + 1
													r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
													r3.Parent = nil
													local t60_37_1 = table.pack(d_1())
													if t60_37_1[1] then
														r3 = t60_37_1[3]
														continue
													end
													break
												else
													exitTo5 = 1
													break
												end
											end
											if exitTo5 == 1 then
												if r3:IsA("Decal") then
													exitTo6 = 1
													break
												elseif r3:IsA("Texture") then
													continue
												else
													exitTo6 = 2
													break
												end
											end
											break
										else
											break
										end
									end
									if exitTo6 == 1 then
										continue
									else
										if exitTo6 == 2 then
											exitTo = 1
										end
										break
									end
								else
									exitTo = 1
									break
								end
							end
							break
						end
					elseif exitTo6 == 2 then
						exitTo = 1
					end
				else
					exitTo = 1
				end
			end
		elseif r3:IsA("Texture") then
			exitTo6 = nil
			while true do
				r8 = #r12.Detached + 1
				r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
				r3.Parent = nil
				local t60_37_1 = table.pack(d_1())
				if t60_37_1[1] then
					r3 = t60_37_1[3]
					exitTo5 = nil
					while true do
						if r3:IsA("SurfaceAppearance") then
							r8 = #r12.Detached + 1
							r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
							r3.Parent = nil
							local t60_37_1 = table.pack(d_1())
							if t60_37_1[1] then
								r3 = t60_37_1[3]
								continue
							end
							break
						else
							exitTo5 = 1
							break
						end
					end
					if exitTo5 == 1 then
						if r3:IsA("Decal") then
							exitTo6 = 1
							break
						elseif r3:IsA("Texture") then
							continue
						else
							exitTo6 = 2
							break
						end
					end
					break
				else
					break
				end
			end
			if exitTo6 == 1 then
				while true do
					exitTo4 = nil
					local exitTo7 = nil
					while true do
						r8 = #r12.Detached + 1
						r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
						r3.Parent = nil
						local t60_37_1 = table.pack(d_1())
						if t60_37_1[1] then
							r3 = t60_37_1[3]
							exitTo3 = nil
							while true do
								if r3:IsA("SurfaceAppearance") then
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										continue
									end
									break
								else
									exitTo3 = 1
									break
								end
							end
							if exitTo3 == 1 then
								if not r3:IsA("Decal") then
									exitTo7 = 2
									break
								end
							else
								exitTo7 = 1
								break
							end
						else
							break
						end
					end
					if exitTo7 == 1 then
						if exitTo4 == 1 then
							if r3:IsA("Texture") then
								exitTo6 = nil
								while true do
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										exitTo5 = nil
										while true do
											if r3:IsA("SurfaceAppearance") then
												r8 = #r12.Detached + 1
												r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
												r3.Parent = nil
												local t60_37_1 = table.pack(d_1())
												if t60_37_1[1] then
													r3 = t60_37_1[3]
													continue
												end
												break
											else
												exitTo5 = 1
												break
											end
										end
										if exitTo5 == 1 then
											if r3:IsA("Decal") then
												exitTo6 = 1
												break
											elseif r3:IsA("Texture") then
												continue
											else
												exitTo6 = 2
												break
											end
										end
										break
									else
										break
									end
								end
								if exitTo6 == 1 then
									continue
								else
									if exitTo6 == 2 then
										exitTo = 1
									end
									break
								end
							else
								exitTo = 1
								break
							end
						end
					elseif exitTo7 == 2 then
						exitTo4 = 1
						if exitTo4 == 1 then
							if r3:IsA("Texture") then
								exitTo6 = nil
								while true do
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										exitTo5 = nil
										while true do
											if r3:IsA("SurfaceAppearance") then
												r8 = #r12.Detached + 1
												r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
												r3.Parent = nil
												local t60_37_1 = table.pack(d_1())
												if t60_37_1[1] then
													r3 = t60_37_1[3]
													continue
												end
												break
											else
												exitTo5 = 1
												break
											end
										end
										if exitTo5 == 1 then
											if r3:IsA("Decal") then
												exitTo6 = 1
												break
											elseif r3:IsA("Texture") then
												continue
											else
												exitTo6 = 2
												break
											end
										end
										break
									else
										break
									end
								end
								if exitTo6 == 1 then
									continue
								else
									if exitTo6 == 2 then
										exitTo = 1
									end
									break
								end
							else
								exitTo = 1
								break
							end
						end
					elseif exitTo4 == 1 then
						if r3:IsA("Texture") then
							exitTo6 = nil
							while true do
								r8 = #r12.Detached + 1
								r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
								r3.Parent = nil
								local t60_37_1 = table.pack(d_1())
								if t60_37_1[1] then
									r3 = t60_37_1[3]
									exitTo5 = nil
									while true do
										if r3:IsA("SurfaceAppearance") then
											r8 = #r12.Detached + 1
											r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
											r3.Parent = nil
											local t60_37_1 = table.pack(d_1())
											if t60_37_1[1] then
												r3 = t60_37_1[3]
												continue
											end
											break
										else
											exitTo5 = 1
											break
										end
									end
									if exitTo5 == 1 then
										if r3:IsA("Decal") then
											exitTo6 = 1
											break
										elseif r3:IsA("Texture") then
											continue
										else
											exitTo6 = 2
											break
										end
									end
									break
								else
									break
								end
							end
							if exitTo6 == 1 then
								continue
							else
								if exitTo6 == 2 then
									exitTo = 1
								end
								break
							end
						else
							exitTo = 1
							break
						end
					end
					break
				end
			elseif exitTo6 == 2 then
				exitTo = 1
			end
		else
			exitTo = 1
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
 end
end
