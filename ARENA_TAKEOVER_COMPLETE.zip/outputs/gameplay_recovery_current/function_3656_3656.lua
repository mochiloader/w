-- Captured function: function_3656
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
capture1.qba = not capture1.qba
 end
end
