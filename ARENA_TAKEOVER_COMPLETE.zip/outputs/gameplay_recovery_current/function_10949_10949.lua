-- Captured function: function_10949
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r36)
local r3 = capture2.UIStroke
local r4 = {}
local r5
if capture4 ~= 190342709 then
	if r36 then
		r5 = 0.45
	else
		r5 = 0.7
	end
else
	capture4 = bit32.bxor(capture4, 1355911695)
	if r36 then
		r5 = 0.45
		r4.Transparency = r5
		capture1(r3, r4, capture3.Quick)
		return
	else
		r5 = 0.7
		r4.Transparency = r5
		capture1(r3, r4, capture3.Quick)
		return
	end
end
r4.Transparency = r5
capture1(r3, r4, capture3.Quick)
 end
end
