-- Captured function: function_2338
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r14, r15)
local r5 = ipairs
if bit32.bxor(capture2, 72884392) == 157996264 then
	capture2 = bit32.bxor(capture2, 2952810623)
end
for _, r3 in r5(capture1) do
	if r3.Name ~= r15 then
		continue
	end
	r14:SetAccent(r3.Accent)
	return r3.Accent
end
return nil
 end
end
