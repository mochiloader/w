-- Captured function: Automatics/Kick Accuracy
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.KickAccuracy = arg1
 end
end
