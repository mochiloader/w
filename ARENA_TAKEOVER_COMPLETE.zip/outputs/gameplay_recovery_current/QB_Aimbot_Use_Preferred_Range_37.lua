-- Captured function: QB Aimbot/Use Preferred Range
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r37)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.autoanglepref = r37
	return
end
 end
end
