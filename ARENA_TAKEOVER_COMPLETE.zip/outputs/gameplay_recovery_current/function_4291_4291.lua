-- Captured function: function_4291
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, captured_function_11593)
 return function(r29)
local r1 = captured_function_11593(nil, 548245827, 2148971602, 2894851430, 1427444354)
capture1(r29, r1)
 end
end
