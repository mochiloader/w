-- Captured function: function_3365
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r20, r21)
capture1.insert(r20.Changed, r21)
return r20
 end
end
