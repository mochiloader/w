-- Captured function: function_10534
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r35, r36, r37, r38)
r37.BackgroundTransparency = 1
r37.Text = r36
r37.TextSize = r38 or capture1.clamp(capture1.floor(r37.Size.Y.Offset * 0.85), 8, 100)
r37.Font = Enum.Font.GothamBold
r37.Active = false
r37.BorderSizePixel = 0
r37.Parent = r35
return capture2("TextLabel", r37)
 end
end
