-- Captured function: function_5012
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, captured_function_11898)
 return function(r36, r37, r38)
if not r36 then
	return
end
local r1 = captured_function_11898(nil, 1861628590, 4042711324, 3930839900, 2693562772)
capture1(r1)
capture3.insert(capture4, { Instance = r36, Property = r37, Role = r38 })
 end
end
