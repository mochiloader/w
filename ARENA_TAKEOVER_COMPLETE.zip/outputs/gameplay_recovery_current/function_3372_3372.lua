-- Captured function: function_3372
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r6)
if r6 then
	if r6 ~= "" then
		if r6 ~= "No other players" then
			for _, r9 in ipairs(capture1:GetPlayers()) do
				local exitTo = nil
				while true do
					if r9 ~= capture2 then
						exitTo = 1
						break
					else
						local t15_32_1 = table.pack(d_1())
						if t15_32_1[1] then
							r9 = t15_32_1[3]
							continue
						end
						break
					end
				end
				if exitTo == 1 then
					if r9.Name ~= r6 then
						continue
					end
					return r9
				end
				break
			end
			return nil
		end
		return nil
	end
	return nil
end
return nil
 end
end
