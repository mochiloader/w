-- Captured function: function_15246
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r18, r19, r20)
if r19 then
	r20 = r20 or r19
else
	r19 = 1
	r20 = r20 or r19
end
local r1 = #r18
local r2, r20_1, r21, r3
if not (r19 < 0) then
	if not (r20 < 0) then
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			else
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	else
		r20 = r1 + r20 + 1
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
						return table.unpack(r2)
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	end
else
	r19 = r1 + r19 + 1
	if not (r20 < 0) then
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
						return table.unpack(r2)
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	else
		r20 = r1 + r20 + 1
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
						return table.unpack(r2)
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r2[#r2 + 1] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	end
end
 end
end
