-- Captured function: Visuals/Fog
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.Fog = arg1
capture2()
 end
end
