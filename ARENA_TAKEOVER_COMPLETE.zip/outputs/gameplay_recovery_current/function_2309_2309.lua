-- Captured function: function_2309
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r14, r15)
local r1 = r14.xmasctx
if r1 then
	if r14.Open then
		if capture1[r15] then
			capture2.spawn(capture1[r15], r1)
			return
		end
	end
end
 end
end
