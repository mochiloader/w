-- Captured function: QB Aimbot/Angle Step
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r24)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_STEP = r24
	return
end
 end
end
