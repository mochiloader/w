-- Captured function: function_13953
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
local r4 = capture5.startedAt
return {
	serverPlayers = #capture1:GetPlayers(),
	pingMs = capture2(),
	fps = capture3.clamp(capture4(capture5.fps + 0.5), 0, 1000),
	uptime = capture4(os.clock() - r4),
}
 end
end
