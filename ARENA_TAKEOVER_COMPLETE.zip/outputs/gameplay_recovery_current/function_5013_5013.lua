-- Captured function: function_5013
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r13, r14, arg3, arg4)
local r17 = capture1("UIStroke", r13, {
	Thickness = arg3 or 1,
	Transparency = arg4 or 0,
	ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
})
capture2(r17, "Color", r14 or "Accent")
return r17
 end
end
