-- Captured function: function_4166
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
local r2 = capture1.ConfigFolder
if r2 then
	return r2
end
return capture1.Folder .. "/configs"
 end
end
