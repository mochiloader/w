-- Captured function: QB Aimbot/Dime Lead
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r2)
if _G.DimeSetDimeLead then
	_G.DimeSetDimeLead(r2)
	return
end
 end
end
