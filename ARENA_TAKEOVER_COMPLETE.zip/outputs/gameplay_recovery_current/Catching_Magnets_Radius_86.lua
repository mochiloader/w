-- Captured function: Catching/Magnets Radius
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Catching.Radius = capture2.clamp(arg1, 0, 25)
 end
end
