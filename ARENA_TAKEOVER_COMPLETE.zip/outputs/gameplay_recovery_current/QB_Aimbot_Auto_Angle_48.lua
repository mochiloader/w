-- Captured function: QB Aimbot/Auto Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r12)
if capture1 then
	if not r12 then
		if capture2 then
			if capture2.Set then
				capture2:Set(true, true)
			end
		end
		if _G.DimeThrowCfg then
			_G.DimeThrowCfg.autoangle = true
			return
		end
		return
	end
end
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.autoangle = r12
	return
end
 end
end
