-- Captured function: QB Aimbot/Bullet Lead
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r20)
if _G.DimeSetBulletLead then
	_G.DimeSetBulletLead(r20)
	return
end
 end
end
