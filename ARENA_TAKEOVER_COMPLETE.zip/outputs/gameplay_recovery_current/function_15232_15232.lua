-- Captured function: function_15232
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function()
if 1270413256 ~= 1270413256 then
end
local r2, r3 = capture1(capture2)
local r11 = {
	placeId = capture3(game.PlaceId),
	jobId = capture4(game.JobId, 64),
	serverCapacity = capture5.MaxPlayers,
}
local r5
if capture6 then
	r5 = capture3(capture6.UserId)
	if not r5 then
		return (nil)(nil)
	end
else
	r5 = nil
end
r11.robloxUserId = r5
local r4
if capture6 then
	r4 = capture4(capture6.Name, 32) or nil
else
	r4 = nil
end
r11.robloxUsername = r4
local r2_1
if capture6 then
	local r4_1 = capture6
	if 788217528 ~= 788217528 then
	end
	local r5_1 = r4_1.DisplayName
	if 1511961204 == 191266792 then
		r2_1 = capture4(r3, 32) or nil
	else
		local r4_2 = capture4(r5_1, 32)
		local r5_2 = 3918796474
		if r5_2 % 4294967296 ~= r5_2 % 4294967296 then
		end
		if r4_2 then
			r11.robloxDisplayName = r4_2
			if r2 then
				r2_1 = capture4(r3, 32)
				if not r2_1 then
					r2_1 = nil
					r11.executor = r2_1
					r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
					return r11
				end
			else
				r2_1 = nil
				r11.executor = r2_1
				r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
				return r11
			end
		else
			r4_2 = nil
			r11.robloxDisplayName = r4_2
			if r2 then
				r2_1 = capture4(r3, 32)
				if not r2_1 then
					r2_1 = nil
					r11.executor = r2_1
					r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
					return r11
				end
			else
				r2_1 = nil
				r11.executor = r2_1
				r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
				return r11
			end
		end
	end
else
	r11.robloxDisplayName = nil
	if r2 then
		r2_1 = capture4(r3, 32)
		if not r2_1 then
			r2_1 = nil
			r11.executor = r2_1
			r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
			return r11
		end
	else
		r2_1 = nil
		r11.executor = r2_1
		r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
		return r11
	end
end
r11.executor = r2_1
r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
return r11
 end
end
