-- Captured function: QB Aimbot/Enable QB Aimbot
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r8)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.qba = r8
	return
end
 end
end
