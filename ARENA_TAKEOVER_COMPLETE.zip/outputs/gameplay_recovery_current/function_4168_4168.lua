-- Captured function: function_4168
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
local r6 = capture1.ScreenGui.AbsoluteSize
if not (r6.X < 1) then
	if not (r6.Y < 1) then
		capture4.Scale = capture2.max(capture2.min(1, (r6.X - 24) / capture3.X, (r6.Y - 24) / capture3.Y), 0.45)
		local r5 = capture5.UIScale
		local r7
		if capture1.Open then
			r7 = capture4.Scale or capture4.Scale * 0.97
		else
			r7 = capture4.Scale * 0.97
			r5.Scale = r7
			return
		end
		r5.Scale = r7
		return
	end
	return
end
 end
end
