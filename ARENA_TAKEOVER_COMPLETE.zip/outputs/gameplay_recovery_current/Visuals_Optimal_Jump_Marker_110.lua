-- Captured function: Visuals/Optimal Jump Marker
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r10)
capture1.Visuals.OptimalJump = r10
if not r10 then
	if optMarker then
		optMarker:Destroy()
		optMarker = nil
		optPos = nil
		return
	end
end
 end
end
