-- Captured function: function_10403
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function()
capture1.Text = capture2()
local r2 = capture1
local r4_1
if capture2() ~= "None" then
	r4_1 = capture3.Text
else
	r4_1 = capture3.Dim or capture3.Text
end
r2.TextColor3 = r4_1
local t58_20_1 = table.pack(d_1())
if t58_20_1[1] then
	local r2_1 = t58_20_1[2]
	local r3 = t58_20_1[3]
	while true do
		local r11 = capture5(r2_1)
		local r7 = r3.Label
		local r8 = {}
		local r9
		if r11 then
			r9 = capture3.AccentLift or capture3.Muted
		else
			r9 = capture3.Muted
		end
		r8.TextColor3 = r9
		capture6(r7, r8, capture7.Quick)
		local r7_1 = r3.Dot
		local r8_1 = {}
		local r9_1
		if r11 then
			r9_1 = 0
		else
			r9_1 = 1
		end
		r8_1.BackgroundTransparency = r9_1
		capture6(r7_1, r8_1, capture7.Quick)
		local r7_2 = r3.Tick
		local r8_2 = {}
		local r6 = r3.TickKey
		local r11_1
		if r11 then
			r11_1 = 0
		else
			r11_1 = 1
		end
		r8_2[r6] = r11_1
		capture6(r7_2, r8_2, capture7.Quick)
		local t35_55_1 = table.pack(d_1())
		if t35_55_1[1] then
			r2_1 = t35_55_1[2]
			r3 = t35_55_1[3]
			continue
		end
		break
	end
end
 end
end
