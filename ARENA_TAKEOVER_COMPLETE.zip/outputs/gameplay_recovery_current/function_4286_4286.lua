-- Captured function: function_4286
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r19, r20)
local r1, r2, r3 = ipairs(r19.Changed)
local t24_11_1 = table.pack(d_1())
if t24_11_1[1] then
	local r2_1 = t24_11_1[3]
	while true do
		capture1.spawn(r2_1, r20)
		local t29_14_1 = table.pack(d_1())
		if t29_14_1[1] then
			r2_1 = t29_14_1[3]
		else
			break
		end
	end
end
if r19.Callback then
	capture1.spawn(r19.Callback, r20)
	return
end
 end
end
