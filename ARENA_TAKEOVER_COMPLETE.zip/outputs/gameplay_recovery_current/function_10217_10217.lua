-- Captured function: function_10217
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, captured_function_13944, captured_function_13945)
 return function()
local state = 1
local r7, r3, r2_1, r2_2, r2_3, r4_1, r5_1, r4_2
while true do
	if state == 1 then
		if not capture1() then
			state = 32
		else
			state = 2
		end
	elseif state == 2 then
		if WebSocket then
			state = 3
		else
			state = 4
		end
	elseif state == 3 then
		r7 = WebSocket.connect
		if r7 then
			state = 9
		else
			state = 4
		end
	elseif state == 4 then
		if syn then
			state = 5
		else
			state = 7
		end
	elseif state == 5 then
		if syn.websocket then
			state = 6
		else
			state = 7
		end
	elseif state == 6 then
		r7 = syn.websocket.connect
		if r7 then
			state = 9
		else
			state = 7
		end
	elseif state == 7 then
		r7 = websocket
		if r7 then
			state = 8
		else
			state = 9
		end
	elseif state == 8 then
		r7 = websocket.connect
		if r7 then
			state = 11
		else
			state = 10
		end
	elseif state == 9 then
		if r7 then
			state = 11
		else
			state = 10
		end
	elseif state == 10 then
		return false
	elseif state == 11 then
		local r2
		r2, r3 = capture2(r7, capture3 .. capture4)
		if r2 then
			state = 13
		else
			state = 12
		end
	elseif state == 12 then
		return false
	elseif state == 13 then
		if not r3 then
			state = 31
		else
			state = 14
		end
	elseif state == 14 then
		capture5.socket = r3
		capture5.lastInbound = os.clock()
		r2_1 = r3.OnMessage
		if r2_1 then
			state = 16
		else
			state = 15
		end
	elseif state == 15 then
		r2_1 = r3.onMessage
		if r2_1 then
			state = 16
		else
			state = 17
		end
	elseif state == 16 then
		r2_1:Connect(capture6)
		state = 17
	elseif state == 17 then
		r2_2 = r3.OnClose
		if r2_2 then
			state = 18
		else
			state = 20
		end
	elseif state == 18 then
		local r5 = r2_2
		local r4 = r2_2.Connect
		local r7_1 = captured_function_13944(nil, 3527744144, 486391709, 3412698217, 2050339389)
		r4(r5, r7_1)
		state = 19
	elseif state == 19 then
		r2_3 = 530290456
		r4_1 = captured_function_13945(nil, 3768955383, 238949238, 1670950518, 89477099)
		r5_1 = 4212806067
		if 1866455814 ~= 453642490 then
			state = 21
		else
			state = 20
		end
	elseif state == 20 then
		r2_2 = r3.onClose
		if r2_2 then
			state = 18
		else
			state = 19
		end
	elseif state == 21 then
		local r5_2 = bit32.bxor(r5_1, 487860032)
		bit32.bxor(r2_3, r5_2)
		if capture2(r4_1) then
			state = 23
		else
			state = 22
		end
	elseif state == 22 then
		capture9("send failed")
		return false
	elseif state == 23 then
		r4_2 = os.clock() + capture10
		state = 24
	elseif state == 24 then
		if not (os.clock() < r4_2) then
			state = 30
		else
			state = 25
		end
	elseif state == 25 then
		if capture5.connected then
			state = 29
		else
			state = 26
		end
	elseif state == 26 then
		if capture5.socket then
			state = 28
		else
			state = 27
		end
	elseif state == 27 then
		return false
	elseif state == 28 then
		capture11.wait(0.1)
		state = 24
	elseif state == 29 then
		return true
	elseif state == 30 then
		capture9("auth timeout")
		return false
	elseif state == 31 then
		return false
	elseif state == 32 then
		return false
	end
end
 end
end
