-- Captured function: function_5014
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1, arg2)
return capture1("UICorner", arg1, { CornerRadius = UDim.new(arg2, 0) })
 end
end
