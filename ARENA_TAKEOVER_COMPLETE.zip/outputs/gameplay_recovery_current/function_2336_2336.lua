-- Captured function: function_2336
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r34)
local r4 = r34:GetAutoload()
if r4 then
	r34.Autoload = r4
	return r34:LoadConfig(r4)
end
return false, "no autoload set"
 end
end
