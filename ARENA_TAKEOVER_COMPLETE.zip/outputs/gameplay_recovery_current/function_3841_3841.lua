-- Captured function: function_3841
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r16, r17, arg3)
local r19 = capture1:Create(r16, arg3 or capture2.Smooth, r17)
r19:Play()
return r19
 end
end
