-- Captured function: function_15244
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r2)
local r12 = capture1.create(32)
local r5 = 1
local r6 = capture2.min(64, #r2)
local r8, r14, r5_1
if 2 <= 0 then
	if r5 >= r6 then
		r8 = r5
		while true do
			r14 = #r12 + 1
			r5_1 = capture4(r2:sub(r8, r8 + 1), 16) or 0
			r12[r14] = capture3(r5_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r8 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r8 = d_1
				continue
			end
			break
		end
	end
elseif r5 <= r6 then
	r8 = r5
	while true do
		r14 = #r12 + 1
		r5_1 = capture4(r2:sub(r8, r8 + 1), 16)
		if r5_1 then
			r12[r14] = capture3(r5_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r8 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r8 = d_1
				continue
			end
			break
		else
			r12[r14] = capture3(0)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r8 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r8 = d_1
				continue
			end
			break
		end
	end
end
return capture1.concat(r12)
 end
end
