-- Captured function: function_2345
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(arg1)
arg1.HoverDirty = true
 end
end
