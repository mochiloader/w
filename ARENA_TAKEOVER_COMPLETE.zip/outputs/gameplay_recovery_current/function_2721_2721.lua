-- Captured function: function_2721
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
if not (capture1() - capture2 < capture3) then
	capture2 = capture1()
	if capture4 then
		capture4.CFrame = capture4.CFrame + capture4.CFrame.LookVector * (capture5.Physics.QuickTPDistance or 0)
		return
	end
	return
end
 end
end
