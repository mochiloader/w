-- Captured function: Misc/Tung Sahor Ball
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r23)
capture1 = r23
if r23 then
	return
end
capture2 = 50
 end
end
