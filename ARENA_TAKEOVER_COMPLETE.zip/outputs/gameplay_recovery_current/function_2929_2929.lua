-- Captured function: function_2929
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r8, r9, r10)
if capture2 == 6086283 then
	capture2 = bit32.bxor(capture2, 3312970411)
end
if r8.Popover then
	if r8.Popover ~= r9 then
		r8.ClosePopover()
	end
end
r8.Popover = r9
r8.PopoverCloser = r10
capture1.Visible = true
 end
end
