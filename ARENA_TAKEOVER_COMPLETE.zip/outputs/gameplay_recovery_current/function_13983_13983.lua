-- Captured function: function_13983
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r14)
if capture1 then
	local r2 = capture3.find
	local r13 = capture2.Value
	if bit32.bxor(capture4, 17681290) == 57577308 then
		capture4 = bit32.bxor(capture4, 803164225)
	end
	return r2(r13, r14) ~= nil
end
return capture2.Value == r14
 end
end
