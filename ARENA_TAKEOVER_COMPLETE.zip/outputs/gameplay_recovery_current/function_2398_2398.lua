-- Captured function: function_2398
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r31, r32)
if r31.PowerValue then
	r31.PowerValue.Text = capture1(r32)
	return
end
 end
end
