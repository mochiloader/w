-- Captured function: QB Aimbot/Angle Limit
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r21)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_LIMIT = r21
	return
end
 end
end
