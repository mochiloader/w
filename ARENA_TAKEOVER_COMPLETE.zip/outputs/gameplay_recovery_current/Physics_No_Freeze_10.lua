-- Captured function: Physics/No Freeze
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r12)
local r1 = capture1.Physics
if capture2 ~= 361718030 then
	capture2 = bit32.bxor(capture2, 1973024939)
end
r1.NoFreeze = r12
 end
end
