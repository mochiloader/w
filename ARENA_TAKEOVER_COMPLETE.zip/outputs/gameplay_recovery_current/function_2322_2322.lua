-- Captured function: function_2322
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r30, arg2, arg3, r33)
return r30:CreateNotification(arg2, arg3, r33)
 end
end
