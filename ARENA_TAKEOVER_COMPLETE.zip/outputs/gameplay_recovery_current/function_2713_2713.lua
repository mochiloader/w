-- Captured function: function_2713
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()

 end
end
