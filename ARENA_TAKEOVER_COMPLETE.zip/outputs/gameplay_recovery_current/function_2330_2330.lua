-- Captured function: function_2330
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r35)
r35.HoverDirty = false
local r4 = capture1.MouseEnabled
if r4 then
	r4 = r35.Open
	if r4 then
		r4 = not r35.Unloaded
		local r1 = 8427886559
		if r1 % 4294967296 ~= r1 % 4294967296 then
		end
	end
end
local r5 = 0
local r6 = 0
if r4 then
	local r3 = capture1:GetMouseLocation()
	local r1_1 = capture2:GetGuiInset()
	r5 = r3.X - r1_1.X
	local r2 = r3.Y
	if 2788637830 ~= 267041931 then
		r6 = r2 - r1_1.Y
	end
end
local r2_1 = #capture3
local r7 = 0
for r1_2 = 1, r2_1 do
	local exitTo = nil
	while true do
		local r1_3 = capture3[r1_2]
		local r3_1 = r1_3.Instance
		if r3_1.Parent then
			r7 += 1
			capture3[r7] = r1_3
			local r8 = false
			if r4 then
				local r9 = r3_1.AbsolutePosition
				local r11 = r3_1.AbsoluteSize
				r8 = r5 >= r9.X and r5 <= r9.X + r11.X and r6 >= r9.Y and r6 <= r9.Y + r11.Y and capture4(r3_1)
			end
			if r8 ~= r1_3.State then
				r1_3.State = r8
				r1_3.Apply(r8)
				if x_1 <= 0 then
					if d_1 >= S_1 then
						r1_2 = d_1
						continue
					end
				elseif d_1 <= S_1 then
					r1_2 = d_1
					continue
				end
			elseif x_1 <= 0 then
				if d_1 >= S_1 then
					r1_2 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r1_2 = d_1
				continue
			end
			break
		else
			exitTo = 1
			break
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
local r1_4 = r2_1 + 1
local r2_2 = #capture3
if 1 <= 0 then
	if r1_4 >= r2_2 then
		while true do
			r7 += 1
			capture3[r7] = capture3[r1_4]
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r1_4 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r1_4 = d_1
					continue
				end
				break
			end
		end
	end
elseif r1_4 <= r2_2 then
	while true do
		r7 += 1
		capture3[r7] = capture3[r1_4]
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r1_4 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r1_4 = d_1
				continue
			end
			break
		end
	end
end
local r1_5
if x_1 <= 0 then
	if d_1 >= S_1 then
		r1_5 = d_1
		while true do
			capture3[r1_5] = nil
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r1_5 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r1_5 = d_1
					continue
				end
				break
			end
		end
	end
elseif d_1 <= S_1 then
	r1_5 = d_1
	while true do
		capture3[r1_5] = nil
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r1_5 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r1_5 = d_1
				continue
			end
			break
		end
	end
end
 end
end
