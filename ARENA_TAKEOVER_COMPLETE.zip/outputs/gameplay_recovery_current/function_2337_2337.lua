-- Captured function: function_2337
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_4265, captured_function_4266)
 return function(r35, r36)
local r42 = r36.AddColorPicker
return r36:AddDropdown("ThemePreset", {
	Text = "Preset",
	Values = r35:GetPresets(),
	Default = "Santa",
	Callback = captured_function_4266(nil, 382013437, 509873082, 3680915268, 1947685029),
}), (r42(r36, "ThemeAccent", {
	Text = "Accent",
	Default = capture1.Accent,
	Callback = captured_function_4265(nil, 1358484226, 721132962, 3086886931, 1923972522),
}))
 end
end
