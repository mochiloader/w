-- Captured function: function_10248
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
capture1.Enabled = false
 end
end
