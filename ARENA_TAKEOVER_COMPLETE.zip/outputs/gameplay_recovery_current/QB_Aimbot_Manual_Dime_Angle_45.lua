-- Captured function: QB Aimbot/Manual Dime Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r8)
if _G.DimeSetManualAngle then
	_G.DimeSetManualAngle(r8)
	return
end
 end
end
