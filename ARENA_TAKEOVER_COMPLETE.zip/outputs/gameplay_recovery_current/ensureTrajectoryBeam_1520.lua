-- Captured function: ensureTrajectoryBeam
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2 = 2025581612 == 235563133
if not r2 then
	if trajBeam then
		if trajBeam.Parent then
			trajBeam.Enabled = true
			return
		end
	end
	r2 = trajA0 or capture1.new("Attachment")
end
trajA0 = r2
trajA1 = trajA1 or capture1.new("Attachment")
trajA0.Name = "NxzTrajectoryAtt0"
trajA1.Name = "NxzTrajectoryAtt1"
trajA0.Parent = capture2.Terrain
trajA1.Parent = capture2.Terrain
trajBeam = trajBeam or capture1.new("Beam")
trajBeam.Name = "NxzTrajectoryBeam"
trajBeam.Attachment0 = trajA0
local r2_3 = trajBeam
local r4 = trajA1
if 3223426740 ~= 3223426740 then
end
r2_3.Attachment1 = r4
trajBeam.Segments = 56
if 2457882595 ~= 145379789 then
	return
end
 end
end
