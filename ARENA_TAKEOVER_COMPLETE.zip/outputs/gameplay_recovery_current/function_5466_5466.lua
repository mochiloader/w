-- Captured function: function_5466
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, captured_function_12120)
 return function(r18)
local r6 = capture1(r18)
r18.gustAt = os.clock()
local r2 = 1
local r3 = capture2.random(8, 11)
local r1, r2_1, r3_1
if 1 <= 0 then
	if r2 >= r3 then
		while true do
			r1 = capture3.delay
			r2_1 = capture2.random() * 0.9
			r3_1 = captured_function_12120(nil, 2658146378, 3089525230, 399323982, 1045589047)
			r1(r2_1, r3_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r2 <= r3 then
	while true do
		r1 = capture3.delay
		r2_1 = capture2.random() * 0.9
		r3_1 = captured_function_12120(nil, 2658146378, 3089525230, 399323982, 1045589047)
		r1(r2_1, r3_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
capture7(r6, 2.6)
 end
end
