-- Captured function: Player/Hip Height Value
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.HipHeightValue = arg1
 end
end
