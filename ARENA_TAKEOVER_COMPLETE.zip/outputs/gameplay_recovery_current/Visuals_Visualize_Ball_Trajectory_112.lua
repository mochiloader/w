-- Captured function: Visuals/Visualize Ball Trajectory
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r23)
capture1.Visuals.BallTrajectory = r23
if not r23 then
	resetTrajectorySnapshot()
	if trajBeam then
		trajBeam.Enabled = false
		return
	end
end
 end
end
