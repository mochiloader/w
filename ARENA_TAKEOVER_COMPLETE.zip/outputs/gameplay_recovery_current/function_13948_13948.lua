-- Captured function: function_13948
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r25)
local r1, r2 = capture1(capture2, r25)
if r1 then
	if r2 then
		return r2
	end
end
return nil
 end
end
