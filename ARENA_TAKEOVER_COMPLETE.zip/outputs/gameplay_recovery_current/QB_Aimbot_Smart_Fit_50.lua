-- Captured function: QB Aimbot/Smart Fit
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r30)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.smartfit = r30
end
capture1 = r30
if r30 then
	if _G.DimeSetMode then
		_G.DimeSetMode("FIT")
	end
	if capture2 then
		if capture2.Set then
			capture2:Set("FIT", true)
		end
	end
	if _G.DimeThrowCfg then
		_G.DimeThrowCfg.autoangle = true
	end
	if capture3 then
		if capture3.Set then
			capture3:Set(true, true)
			return
		end
	end
end
 end
end
