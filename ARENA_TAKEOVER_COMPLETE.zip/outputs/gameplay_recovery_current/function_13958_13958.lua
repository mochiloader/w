-- Captured function: function_13958
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1, arg2, arg3, r40)
return capture1.concat({ capture2.sessionId, arg1, arg2, arg3, r40 }, "|")
 end
end
