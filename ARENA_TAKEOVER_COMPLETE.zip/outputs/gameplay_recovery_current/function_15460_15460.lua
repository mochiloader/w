-- Captured function: function_15460
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(captured_function_15572, captured_function_15574, captured_function_15575, captured_function_15576, captured_function_15577, captured_function_15578)
 return function(r5)
if not r5 then
	return nil
end
local r1 = 1
local r2 = captured_function_15575(nil, 1848400042, 1056046405, 1557615706, 3347495092)
local r4 = captured_function_15577(nil, 3050230770, 3756961183, 1536356481, 2986583710)
parse_string = captured_function_15578(nil, 4192337327, 4042592818, 691382311, 4192538333)
parse_number = captured_function_15576(nil, 589052949, 2815589681, 3560998692, 3155788015)
parse_array = captured_function_15574(nil, 784995607, 394178750, 3612309436, 212344744)
parse_object = captured_function_15572(nil, 568178309, 330199424, 59007792, 1909598882)
local r7 = r4()
r2()
if not (r1 <= #r5) then
	return r7
end
error("Unexpected trailing characters at position " .. tostring(r1))
return r7
 end
end
