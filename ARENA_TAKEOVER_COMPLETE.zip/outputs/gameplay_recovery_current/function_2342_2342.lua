-- Captured function: function_2342
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
local r8 = {}
for r1, r2 in capture1(arg1.Flags) do
	local exitTo = nil
	while true do
		local r4, r5 = capture2(r2.Save)
		if r4 then
			if r5 ~= nil then
				r8[r1] = r5
				local t11_23_1 = table.pack(d_1())
				if t11_23_1[1] then
					r1 = t11_23_1[2]
					r2 = t11_23_1[3]
					continue
				end
			else
				local t12_37_1 = table.pack(d_1())
				if t12_37_1[1] then
					r1 = t12_37_1[2]
					r2 = t12_37_1[3]
					continue
				end
			end
			break
		else
			exitTo = 1
			break
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
return { Flags = r8, Toggles = {}, Options = {} }
 end
end
