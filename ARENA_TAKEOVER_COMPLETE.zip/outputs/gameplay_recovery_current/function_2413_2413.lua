-- Captured function: function_2413
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r23, r24)
if r23 then
	if r23 ~= r23 then
		if r24 then
			return r24
		end
		return Vector3.new(0, 0, 0)
	end
	local r1 = r23.Magnitude
	if not (r1 < 0.0001) then
		if r1 ~= r1 then
			if r24 then
				return r24
			end
			return Vector3.new(0, 0, 0)
		end
		return r23 / r1
	end
	if r24 then
		return r24
	end
	return Vector3.new(0, 0, 0)
end
if r24 then
	return r24
end
return Vector3.new(0, 0, 0)
 end
end
