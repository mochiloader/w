-- Captured function: function_15245
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r2)
local r4 = #r2
local r3 = 1
local r10 = 0
local r5
if 1 <= 0 then
	if r3 >= r4 then
		r5 = r3
		while true do
			r10 = (r10 * 31 + capture1(r2, r5)) % 4294967296
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r5 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r5 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	r5 = r3
	while true do
		r10 = (r10 * 31 + capture1(r2, r5)) % 4294967296
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r5 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r5 = d_1
				continue
			end
			break
		end
	end
end
local r5_1 = capture2.create(8)
local r2_1
if x_1 <= 0 then
	if d_1 >= S_1 then
		r2_1 = d_1
		while true do
			r5_1[r2_1] = capture4(r10 * capture3[r2_1] % 4294967296)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r2_1 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r2_1 = d_1
					continue
				end
				break
			end
		end
	end
elseif d_1 <= S_1 then
	r2_1 = d_1
	while true do
		r5_1[r2_1] = capture4(r10 * capture3[r2_1] % 4294967296)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r2_1 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r2_1 = d_1
				continue
			end
			break
		end
	end
end
return capture2.concat(r5_1)
 end
end
