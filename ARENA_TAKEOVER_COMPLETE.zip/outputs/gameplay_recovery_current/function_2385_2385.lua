-- Captured function: function_2385
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
capture1()
local r6 = capture2:sub(capture3, capture3)
if r6 ~= "\"" then
	if r6 ~= "{" then
		if r6 ~= "[" then
			if r6 == "t" then
				if capture2:sub(capture3, capture3 + 3) == "true" then
					capture3 += 4
					return true
				end
			end
			if r6 == "f" then
				if capture2:sub(capture3, capture3 + 4) == "false" then
					capture3 += 5
					return false
				end
			end
			if r6 ~= "n" then
				return parse_number()
			end
			if capture2:sub(capture3, capture3 + 3) ~= "null" then
				return parse_number()
			end
			capture3 += 4
			return nil
		end
		return parse_array()
	end
	return parse_object()
end
return parse_string()
 end
end
