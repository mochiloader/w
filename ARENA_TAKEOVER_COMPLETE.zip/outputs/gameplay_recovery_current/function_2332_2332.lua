-- Captured function: function_2332
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(captured_function_4241, captured_function_4243, captured_function_4244, captured_function_4245, captured_function_4246, captured_function_4247, captured_function_4248, captured_function_4249)
 return function(r13, r14)
local r4 = r13:ListConfigs()
r14:AddDropdown("ConfigList", { Text = "Config", Values = r4, Default = r13:GetAutoload() or r4[1] or "", NoSave = true })
r14:AddInput("ConfigName", { Text = "Name", Placeholder = "new config", NoSave = true })
r14:AddInput("ConfigPaste", { Text = "Import JSON", Placeholder = "paste config json", NoSave = true })
captured_function_4241(nil, 1864143158, 4165701579, 3683699572, 4031068943)
local r1_1 = r14.AddButtonRow
local r3 = {}
local r4_1 = { Text = "Save", Func = captured_function_4245(nil, 676612595, 1282168364, 698451808, 1641329840) }
local r5 = { Text = "Load", Func = captured_function_4244(nil, 3080191138, 393812606, 2051069085, 4257264712) }
r3[1] = r4_1
r3[2] = r5
r1_1(r14, r3)
local r1_2 = r14.AddButtonRow
local r3_1 = {}
local r4_2 = { Text = "Delete", Func = captured_function_4246(nil, 2444445772, 37861112, 1164657293, 360143786) }
local r5_1 = {
	Text = "Refresh",
	Func = captured_function_4249(nil, 2840195824, 176839170, 993466907, 1115153837),
}
r3_1[1] = r4_2
r3_1[2] = r5_1
r1_2(r14, r3_1)
local r1_3 = r14.AddButtonRow
local r3_2 = {}
local r4_3 = {
	Text = "Set autoload",
	Func = captured_function_4248(nil, 118036465, 2690913711, 2776419581, 3274899760),
}
local r5_2 = {
	Text = "Copy JSON",
	Func = captured_function_4247(nil, 2061546002, 1799645864, 2689273343, 3905698549),
}
r3_2[1] = r4_3
r3_2[2] = r5_2
r1_3(r14, r3_2)
r14:AddButton({
	Text = "Import JSON",
	Func = captured_function_4243(nil, 2152475800, 434125442, 1011364358, 3190605736),
})
 end
end
