-- Captured function: function_3666
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(arg1)
capture1 = arg1
capture3 = capture2[capture1]
capture4 = nil
if not capture5() then
	capture6()
end
if _G.FF3HUD then
	_G.FF3HUD:SetThrow(capture1)
	return
end
 end
end
