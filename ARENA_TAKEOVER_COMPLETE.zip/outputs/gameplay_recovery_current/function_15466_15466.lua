-- Captured function: function_15466
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r9, r10)
if type(r9) ~= "string" then
	return false
end
if type(r10) ~= "string" then
	return false
end
if #r9 ~= #r10 then
	return false
end
local r4 = #r9
local r3 = 1
local r7 = 0
local r14
if 1 <= 0 then
	if r3 >= r4 then
		r14 = r3
		while true do
			if capture1(r9, r14) ~= capture1(r10, r14) then
				r7 += 1
				if x_1 <= 0 then
					if d_1 >= S_1 then
						r14 = d_1
						continue
					end
				elseif d_1 <= S_1 then
					r14 = d_1
					continue
				end
				break
			else
				if x_1 <= 0 then
					if d_1 >= S_1 then
						r14 = d_1
						continue
					end
				elseif d_1 <= S_1 then
					r14 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	r14 = r3
	while true do
		if capture1(r9, r14) ~= capture1(r10, r14) then
			r7 += 1
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r14 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r14 = d_1
				continue
			end
			break
		else
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r14 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r14 = d_1
				continue
			end
			break
		end
	end
end
return r7 == 0
 end
end
