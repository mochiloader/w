-- Captured function: Catching/Arm Size
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.ArmSize = arg1
 end
end
