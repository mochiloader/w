-- Captured function: resetTrajectorySnapshot
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
trajSnapshotBall = nil
trajSnapshotOrigin = nil
trajSnapshotVelocity = nil
trajSnapshotAt = 0
 end
end
