-- Captured function: QB Aimbot/Pref Max Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r12)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_MAX = r12
	return
end
 end
end
