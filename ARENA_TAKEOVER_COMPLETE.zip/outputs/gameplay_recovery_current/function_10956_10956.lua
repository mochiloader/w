-- Captured function: function_10956
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(arg1)
local r4 = {}
local r3
if arg1 then
	r3 = 0.45
else
	r3 = 1
end
r4.BackgroundTransparency = r3
capture1(capture2, r4, capture3.Quick)
 end
end
