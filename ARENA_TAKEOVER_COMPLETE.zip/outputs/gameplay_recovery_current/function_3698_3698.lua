-- Captured function: function_3698
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r24, r25, r26)
if type(r24) ~= "string" then
	error("bad argument #1 to 'sub' (string expected, got " .. type(r24) .. ")", 2)
end
local r2 = #r24
if not (r25 < 0) then
	if r26 ~= nil then
		if not (r26 < 0) then
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if r2 < r25 then
						return ""
					end
				elseif r2 < r25 then
					return ""
				end
				return string.char(string.byte(r24, r25, r2))
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		else
			r26 = r2 + r26 + 1
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		end
	else
		r26 = r2
		if not (r25 < 1) then
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		else
			r25 = 1
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		end
	end
else
	r25 = r2 + r25 + 1
	if r26 ~= nil then
		if not (r26 < 0) then
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		else
			r26 = r2 + r26 + 1
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		end
	else
		r26 = r2
		if not (r25 < 1) then
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		else
			r25 = 1
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		end
	end
end
return ""
 end
end
