-- Captured function: Visuals/Camera Zoom Unlock
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.CameraZoom = arg1
 end
end
