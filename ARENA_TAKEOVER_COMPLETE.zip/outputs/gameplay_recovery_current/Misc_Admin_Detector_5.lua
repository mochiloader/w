-- Captured function: Misc/Admin Detector
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.AdminDetector = arg1
 end
end
