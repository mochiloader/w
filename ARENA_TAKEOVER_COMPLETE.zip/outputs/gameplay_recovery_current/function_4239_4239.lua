-- Captured function: function_4239
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r31)
if r31 then
	while true do
		if r31 ~= game then
			if r31:IsA("GuiObject") then
				if not r31.Visible then
					break
				end
			end
			if r31:IsA("ScreenGui") then
				return true
			end
			r31 = r31.Parent
			if r31 then
				continue
			end
			return true
		else
			return true
		end
	end
	return false
end
return true
 end
end
