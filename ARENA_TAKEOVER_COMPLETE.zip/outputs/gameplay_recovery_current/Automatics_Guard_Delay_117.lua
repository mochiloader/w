-- Captured function: Automatics/Guard Delay
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoGuardDelay = arg1
 end
end
