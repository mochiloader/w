-- Captured function: Player/Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Player.Speed = capture2.clamp(arg1, 0, 23)
 end
end
