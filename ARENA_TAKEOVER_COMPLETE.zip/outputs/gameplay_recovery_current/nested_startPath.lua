-- Reconstructed from captured VM instructions, with nested closures.
return function()
if pathConn then
	pathConn:Disconnect()
	pathConn = nil
end
pathConn = upv1.DescendantAdded:Connect(function(s15)
	upv2.defer(addPathBeam, s15)
end)
local r4, r5, r6 = upv3(upv4)
local t36_25_1 = table.pack(d_1())
if t36_25_1[1] then
	local r4_1 = t36_25_1[2]
	while true do
		upv2.defer(addPathBeam, r4_1)
		local t40_31_1 = table.pack(d_1())
		if t40_31_1[1] then
			r4_1 = t40_31_1[2]
		else
			break
		end
	end
end
end
