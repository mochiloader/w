-- Captured function: function_2394
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaCycleWR then
	_G.FF3QbaCycleWR(1)
	return
end
 end
end
