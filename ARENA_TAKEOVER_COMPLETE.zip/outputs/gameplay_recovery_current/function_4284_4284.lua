-- Captured function: function_4284
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, captured_function_11570, captured_function_11573, captured_function_11574, captured_function_11575, captured_function_11576)
 return function(r16, r17, arg3, r19)
local r12 = {
	Idx = r16,
	Type = arg3,
	Changed = {},
	Callback = r17.Callback,
	NoSave = r17.NoSave,
	OnChanged = captured_function_11575(nil, 2132584372, 1054972053, 3036332610, 3347703995),
	Get = captured_function_11576(nil, 3827004446, 2996530692, 3854959124, 809442831),
}
if r16 then
	r19[r16] = r12
	if not r17.NoSave then
		local r6 = r17.Default
		local r2, r5 = captured_function_11570(nil, 2805741710, 1474044529, 3816099779, 1308852122)(126582701, r6)
		if r2 + 393105472 == 176321159 then
			bit32.bxor(r2, 130475537)
		end
		capture5.Flags[r16] = {
			Default = r5,
			Save = captured_function_11574(nil, 1347617701, 1971689408, 3879355511, 1251048062),
			Load = captured_function_11573(nil, 1224453261, 4090914299, 3896611728, 695824339),
		}
		return r12
	end
end
return r12
 end
end
