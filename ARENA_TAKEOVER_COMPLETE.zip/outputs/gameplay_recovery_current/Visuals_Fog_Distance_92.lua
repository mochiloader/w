-- Captured function: Visuals/Fog Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.FogDistance = arg1
if capture1.Visuals.Fog then
	capture2()
	return
end
 end
end
