-- Captured function: clearLiveFootballVisuals
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
resetTrajectorySnapshot()
if trajBeam then
	trajBeam:Destroy()
	trajBeam = nil
end
if trajA0 then
	trajA0:Destroy()
	trajA0 = nil
end
if trajA1 then
	trajA1:Destroy()
	trajA1 = nil
end
if optMarker then
	optMarker:Destroy()
	optMarker = nil
	optPos = nil
	return
end
 end
end
