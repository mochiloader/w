-- Captured function: function_4430
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r20, r21, r22)
r20.Value = capture1(r21 or "")
local r1 = capture2
local r3 = r20.Value
if bit32.bxor(capture4, 171465547) ~= 16854246 then
	capture4 = bit32.bxor(capture4, 917265245)
end
r1.Text = r3
if r22 then
	return
end
capture3(r20, r20.Value)
 end
end
