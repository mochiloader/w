-- Captured function: Misc/Target
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(arg1)
capture1 = arg1
if capture2 then
	capture3()
	return
end
 end
end
