-- Captured function: Catching/Swat Reach Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.SwatRadius = arg1
 end
end
