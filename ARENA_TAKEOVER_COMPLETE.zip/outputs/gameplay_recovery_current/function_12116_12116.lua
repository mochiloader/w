-- Captured function: function_12116
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r4, r5, r6, r7, r8, r9)
local r15 = capture1.remove(capture2)
if not r15 then
	r15 = capture3.new("Frame")
	r15.BorderSizePixel = 0
	r15.AnchorPoint = capture4
	local r11 = capture3.new("UICorner")
	r11.CornerRadius = nil
	r11.Parent = r15
end
r15.BackgroundColor3 = r5
r15.BackgroundTransparency = r8 or 0
r15.Size = UDim2.fromOffset(r6, r6)
r15.Position = r7
r15.ZIndex = r9 or 999999
r15.Parent = r4
return r15
 end
end
