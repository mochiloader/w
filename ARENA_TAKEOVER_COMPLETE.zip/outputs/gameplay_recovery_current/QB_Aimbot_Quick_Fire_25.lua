-- Captured function: QB Aimbot/Quick Fire
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r4)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.openWRSnap = r4
		return
	end
end
 end
end
