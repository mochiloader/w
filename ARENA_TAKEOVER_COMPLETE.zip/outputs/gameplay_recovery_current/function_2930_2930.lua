-- Captured function: function_2930
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if capture1.Popover then
	local r2 = capture1.PopoverCloser
	capture1.Popover = nil
	capture1.PopoverCloser = nil
	capture2.Visible = false
	if r2 then
		r2()
		return
	end
	return
end
 end
end
