-- Recovered from the captured partVelocity VM, including both nested getters.
-- Supply original captured function #1882; its full behavior is not yet verified.
return function(protectedCall)
return function(part)
 if not part then return Vector3.new(0, 0, 0) end
 local ok, velocity = protectedCall(function() return part.AssemblyLinearVelocity end)
 if ok and velocity and velocity.Magnitude > 0.05 then return velocity end
 local fallbackOK, fallback = protectedCall(function() return part.Velocity end)
 if fallbackOK and fallback then return fallback end
 return Vector3.new(0, 0, 0)
end
end
