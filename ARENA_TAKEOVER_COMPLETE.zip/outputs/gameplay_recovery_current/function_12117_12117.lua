-- Captured function: function_12117
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, captured_function_15140)
 return function(arg1, arg2, r24)
capture1(arg1, arg2, TweenInfo.new(r24, capture2, Enum.EasingDirection.Out))
local r1 = capture3.delay
local r3 = captured_function_15140(nil, 1856567897, 3390302028, 766453266, 2554405406)
r1(r24 + 0.05, r3)
 end
end
