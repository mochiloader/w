-- Recovered captured function bodies. See recovery_report.json for limits.

local recovered = {}

recovered["stopHL"] = (function()
-- Captured function: stopHL
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if hlConn then
	hlConn:Disconnect()
	hlConn = nil
end
local r4, r5, r6 = ipairs(capture1:GetDescendants())
if capture2 ~= 385938617 then
	capture2 = bit32.bxor(capture2, 1888937537)
end
while true do
	local t71_29_1 = table.pack(d_1())
	if t71_29_1[1] then
		local r5_1 = t71_29_1[3]
		local exitTo = nil
		while true do
			if r5_1:IsA("Highlight") then
				if r5_1.Name ~= "NxzFootballHL" then
					if r5_1.Parent then
						if r5_1.Parent.Name ~= "Football" then
							exitTo = 1
							break
						else
							r5_1:Destroy()
							local t40_54_1 = table.pack(d_1())
							if t40_54_1[1] then
								r5_1 = t40_54_1[3]
								continue
							end
						end
					else
						exitTo = 1
						break
					end
				else
					r5_1:Destroy()
					local t50_61_1 = table.pack(d_1())
					if t50_61_1[1] then
						r5_1 = t50_61_1[3]
						continue
					end
				end
				break
			else
				exitTo = 1
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	else
		break
	end
end
 end
end

end)()

recovered["clearLiveFootballVisuals"] = (function()
-- Captured function: clearLiveFootballVisuals
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
resetTrajectorySnapshot()
if trajBeam then
	trajBeam:Destroy()
	trajBeam = nil
end
if trajA0 then
	trajA0:Destroy()
	trajA0 = nil
end
if trajA1 then
	trajA1:Destroy()
	trajA1 = nil
end
if optMarker then
	optMarker:Destroy()
	optMarker = nil
	optPos = nil
	return
end
 end
end

end)()

recovered["stopPath"] = (function()
-- Captured function: stopPath
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if pathConn then
	pathConn:Disconnect()
	pathConn = nil
end
pathVisuals = {}
local r2, r3, r4 = ipairs(capture1.Terrain:GetChildren())
if capture2 + 272804321 ~= 294234814 then
	capture2 = bit32.bxor(capture2, 2630796769)
end
while true do
	local t46_28_1 = table.pack(d_1())
	if t46_28_1[1] then
		local r3_1 = t46_28_1[3]
		local exitTo = nil
		while true do
			if r3_1.Name ~= "NxzPathBeam" then
				if r3_1.Name ~= "NxzPathAtt0" then
					if r3_1.Name ~= "NxzPathAtt1" then
						exitTo = 1
						break
					else
						r3_1:Destroy()
						local t69_44_1 = table.pack(d_1())
						if t69_44_1[1] then
							r3_1 = t69_44_1[3]
							continue
						end
					end
				else
					r3_1:Destroy()
					local t64_51_1 = table.pack(d_1())
					if t64_51_1[1] then
						r3_1 = t64_51_1[3]
						continue
					end
				end
				break
			else
				r3_1:Destroy()
				local t24_58_1 = table.pack(d_1())
				if t24_58_1[1] then
					r3_1 = t24_58_1[3]
					continue
				end
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	else
		break
	end
end
 end
end

end)()

recovered["resetTrajectorySnapshot"] = (function()
-- Captured function: resetTrajectorySnapshot
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
trajSnapshotBall = nil
trajSnapshotOrigin = nil
trajSnapshotVelocity = nil
trajSnapshotAt = 0
 end
end

end)()

recovered["parse_number"] = (function()
-- Captured function: parse_number
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r7, r8 = capture1:find("^%-?%d+%.?%d*[eE]?[%+%-]?%d*", capture2)
if not r7 then
	error("Invalid number at position " .. tostring(capture2))
end
local r5 = tonumber(capture1:sub(r7, r8))
capture2 = r8 + 1
return r5
 end
end

end)()

recovered["parse_object"] = (function()
-- Captured function: parse_object
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function()
capture1 = (738726383 == 78165110 or capture1) + 1
local r8 = {}
capture2()
if capture3:sub(capture1, capture1) ~= "}" then
	while true do
		capture2()
		if capture3:sub(capture1, capture1) ~= "\"" then
			error("Expected string key at position " .. tostring(capture1))
		end
		local r12 = parse_string()
		capture2()
		if capture3:sub(capture1, capture1) ~= ":" then
			error("Expected ':' after key at position " .. tostring(capture1))
		end
		capture1 += 1
		r8[r12] = capture4()
		capture2()
		local r3 = capture3:sub(capture1, capture1)
		if r3 ~= "}" then
			if r3 ~= "," then
				error("Expected ',' or '}' at position " .. tostring(capture1))
			else
				capture1 += 1
			end
			continue
		end
		break
	end
	capture1 += 1
	return r8
end
capture1 += 1
return r8
 end
end

end)()

recovered["stripBallTrails"] = (function()
-- Captured function: stripBallTrails
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r31)
if r31 then
	for _, r2 in ipairs(r31:GetDescendants()) do
		local exitTo = nil
		while true do
			if r2:IsA("Trail") then
				r2.Enabled = false
				local t18_23_1 = table.pack(d_1())
				if t18_23_1[1] then
					r2 = t18_23_1[3]
					continue
				end
				break
			else
				exitTo = 1
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	end
	return
end
 end
end

end)()

recovered["ensureTrajectoryBeam"] = (function()
-- Captured function: ensureTrajectoryBeam
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2 = 2025581612 == 235563133
if not r2 then
	if trajBeam then
		if trajBeam.Parent then
			trajBeam.Enabled = true
			return
		end
	end
	r2 = trajA0 or capture1.new("Attachment")
end
trajA0 = r2
trajA1 = trajA1 or capture1.new("Attachment")
trajA0.Name = "NxzTrajectoryAtt0"
trajA1.Name = "NxzTrajectoryAtt1"
trajA0.Parent = capture2.Terrain
trajA1.Parent = capture2.Terrain
trajBeam = trajBeam or capture1.new("Beam")
trajBeam.Name = "NxzTrajectoryBeam"
trajBeam.Attachment0 = trajA0
local r2_3 = trajBeam
local r4 = trajA1
if 3223426740 ~= 3223426740 then
end
r2_3.Attachment1 = r4
trajBeam.Segments = 56
if 2457882595 ~= 145379789 then
	return
end
 end
end

end)()

recovered["Misc/Tag Role"] = (function()
-- Captured function: Misc/Tag Role
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.tagRole = arg1
 end
end

end)()

recovered["Misc/Tag Number"] = (function()
-- Captured function: Misc/Tag Number
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r28)
if capture1 then
	capture1(r28, false)
	return
end
 end
end

end)()

recovered["Misc/Fake Global"] = (function()
-- Captured function: Misc/Fake Global
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.enabled = arg1
 end
end

end)()

recovered["Misc/Auto Captain"] = (function()
-- Captured function: Misc/Auto Captain
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r9)
capture1 = r9
if not r9 then
	if capture2 then
		capture2:Disconnect()
		capture2 = nil
		return
	end
end
 end
end

end)()

recovered["Misc/Admin Detector"] = (function()
-- Captured function: Misc/Admin Detector
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.AdminDetector = arg1
 end
end

end)()

recovered["Physics/Dive Boost Power"] = (function()
-- Captured function: Physics/Dive Boost Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
DiveBoost.mult = capture1.clamp(arg1, 0, 10)
 end
end

end)()

recovered["Physics/Dive Boost"] = (function()
-- Captured function: Physics/Dive Boost
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(arg1)
DiveBoost.on = arg1
 end
end

end)()

recovered["Physics/Dive Power Value"] = (function()
-- Captured function: Physics/Dive Power Value
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.DivePowerValue = arg1
 end
end

end)()

recovered["Physics/Dive Power"] = (function()
-- Captured function: Physics/Dive Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.DivePower = arg1
 end
end

end)()

recovered["Physics/No Freeze"] = (function()
-- Captured function: Physics/No Freeze
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r12)
local r1 = capture1.Physics
if capture2 ~= 361718030 then
	capture2 = bit32.bxor(capture2, 1973024939)
end
r1.NoFreeze = r12
 end
end

end)()

recovered["Physics/No Jump Cooldown"] = (function()
-- Captured function: Physics/No Jump Cooldown
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.NoJumpCooldown = arg1
 end
end

end)()

recovered["Misc/Tung Sahor Ball"] = (function()
-- Captured function: Misc/Tung Sahor Ball
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r23)
capture1 = r23
if r23 then
	return
end
capture2 = 50
 end
end

end)()

recovered["Physics/Block Range"] = (function()
-- Captured function: Physics/Block Range
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.BlockReachRange = arg1
 end
end

end)()

recovered["Misc/Anti Bench"] = (function()
-- Captured function: Misc/Anti Bench
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1 = arg1
 end
end

end)()

recovered["Physics/Show Block Reach"] = (function()
-- Captured function: Physics/Show Block Reach
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.BlockReachHitbox = arg1
 end
end

end)()

recovered["Physics/Block Reach"] = (function()
-- Captured function: Physics/Block Reach
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.BlockReach = arg1
 end
end

end)()

recovered["Physics/Anti Jam"] = (function()
-- Captured function: Physics/Anti Jam
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.AntiJam = arg1
 end
end

end)()

recovered["Physics/Anti Block"] = (function()
-- Captured function: Physics/Anti Block
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.AntiBlock = arg1
 end
end

end)()

recovered["Player/No Move Restrictions"] = (function()
-- Captured function: Player/No Move Restrictions
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.NoMoveRestrictions = arg1
 end
end

end)()

recovered["QB Aimbot/Choose Best WR"] = (function()
-- Captured function: QB Aimbot/Choose Best WR
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r11)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.chooseBestWR = r11
	return
end
 end
end

end)()

recovered["QB Aimbot/High Arc Throws"] = (function()
-- Captured function: QB Aimbot/High Arc Throws
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r22)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.loft = r22
		return
	end
end
 end
end

end)()

recovered["Player/Anti Ace Smooth"] = (function()
-- Captured function: Player/Anti Ace Smooth
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Smooth = arg1 / 100
 end
end

end)()

recovered["QB Aimbot/Ping Lead"] = (function()
-- Captured function: QB Aimbot/Ping Lead
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r14)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.pingLead = r14
		return
	end
end
 end
end

end)()

recovered["Player/Anti Ace Distance"] = (function()
-- Captured function: Player/Anti Ace Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Distance = arg1
 end
end

end)()

recovered["QB Aimbot/Quick Fire"] = (function()
-- Captured function: QB Aimbot/Quick Fire
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r4)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.openWRSnap = r4
		return
	end
end
 end
end

end)()

recovered["Player/Anti Ace"] = (function()
-- Captured function: Player/Anti Ace
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Enabled = arg1
 end
end

end)()

recovered["QB Aimbot/Anti OOB"] = (function()
-- Captured function: QB Aimbot/Anti OOB
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r33)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.oobFilter = r33
		return
	end
end
 end
end

end)()

recovered["Player/Angle Notifier"] = (function()
-- Captured function: Player/Angle Notifier
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.AngleNotifier = arg1
 end
end

end)()

recovered["Player/Angle Power"] = (function()
-- Captured function: Player/Angle Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.AngleVal = arg1
 end
end

end)()

recovered["QB Aimbot/Angle Step"] = (function()
-- Captured function: QB Aimbot/Angle Step
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r24)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_STEP = r24
	return
end
 end
end

end)()

recovered["Player/Angle Enhancer"] = (function()
-- Captured function: Player/Angle Enhancer
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.AngleEnhancer = arg1
 end
end

end)()

recovered["QB Aimbot/Angle Limit"] = (function()
-- Captured function: QB Aimbot/Angle Limit
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r21)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_LIMIT = r21
	return
end
 end
end

end)()

recovered["Player/Hip Height Value"] = (function()
-- Captured function: Player/Hip Height Value
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.HipHeightValue = arg1
 end
end

end)()

recovered["QB Aimbot/Pref Max Angle"] = (function()
-- Captured function: QB Aimbot/Pref Max Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r12)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_MAX = r12
	return
end
 end
end

end)()

recovered["Player/Hip Height"] = (function()
-- Captured function: Player/Hip Height
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.HipHeight = arg1
 end
end

end)()

recovered["QB Aimbot/Pref Min Angle"] = (function()
-- Captured function: QB Aimbot/Pref Min Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r25)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_MIN = r25
	return
end
 end
end

end)()

recovered["QB Aimbot/Use Preferred Range"] = (function()
-- Captured function: QB Aimbot/Use Preferred Range
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r37)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.autoanglepref = r37
	return
end
 end
end

end)()

recovered["Player/Fly Speed"] = (function()
-- Captured function: Player/Fly Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.speed = arg1
 end
end

end)()

recovered["Player/Fly"] = (function()
-- Captured function: Player/Fly
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r26)
capture1.enabled = r26
if capture3 ~= 280510937 then
	capture3 = bit32.bxor(capture3, 3568086171)
	if r26 then
		return
	end
elseif r26 then
	return
end
capture2()
 end
end

end)()

recovered["QB Aimbot/Bullet Lead"] = (function()
-- Captured function: QB Aimbot/Bullet Lead
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r20)
if _G.DimeSetBulletLead then
	_G.DimeSetBulletLead(r20)
	return
end
 end
end

end)()

recovered["Player/Infinite Power"] = (function()
-- Captured function: Player/Infinite Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.IJPower = arg1
 end
end

end)()

recovered["QB Aimbot/Dime Lead"] = (function()
-- Captured function: QB Aimbot/Dime Lead
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r2)
if _G.DimeSetDimeLead then
	_G.DimeSetDimeLead(r2)
	return
end
 end
end

end)()

recovered["Player/Infinite Jump"] = (function()
-- Captured function: Player/Infinite Jump
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.InfiniteJump = arg1
 end
end

end)()

recovered["Player/Velocity Boost"] = (function()
-- Captured function: Player/Velocity Boost
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.VJBoost = arg1
 end
end

end)()

recovered["QB Aimbot/Manual Dime Angle"] = (function()
-- Captured function: QB Aimbot/Manual Dime Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r8)
if _G.DimeSetManualAngle then
	_G.DimeSetManualAngle(r8)
	return
end
 end
end

end)()

recovered["Player/Velocity Jump"] = (function()
-- Captured function: Player/Velocity Jump
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.VelocityJump = arg1
 end
end

end)()

recovered["Player/Jump Power#2"] = (function()
-- Captured function: Player/Jump Power#2
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.JPower = arg1
 end
end

end)()

recovered["QB Aimbot/Auto Angle"] = (function()
-- Captured function: QB Aimbot/Auto Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r12)
if capture1 then
	if not r12 then
		if capture2 then
			if capture2.Set then
				capture2:Set(true, true)
			end
		end
		if _G.DimeThrowCfg then
			_G.DimeThrowCfg.autoangle = true
			return
		end
		return
	end
end
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.autoangle = r12
	return
end
 end
end

end)()

recovered["Player/Jump Power"] = (function()
-- Captured function: Player/Jump Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.JumpPower = arg1
 end
end

end)()

recovered["QB Aimbot/Smart Fit"] = (function()
-- Captured function: QB Aimbot/Smart Fit
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r30)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.smartfit = r30
end
capture1 = r30
if r30 then
	if _G.DimeSetMode then
		_G.DimeSetMode("FIT")
	end
	if capture2 then
		if capture2.Set then
			capture2:Set("FIT", true)
		end
	end
	if _G.DimeThrowCfg then
		_G.DimeThrowCfg.autoangle = true
	end
	if capture3 then
		if capture3.Set then
			capture3:Set(true, true)
			return
		end
	end
end
 end
end

end)()

recovered["Player/CF Speed"] = (function()
-- Captured function: Player/CF Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.cframeSpeed = arg1
 end
end

end)()

recovered["Player/CFrame Speed"] = (function()
-- Captured function: Player/CFrame Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.enabled = arg1
 end
end

end)()

recovered["Player/Speed"] = (function()
-- Captured function: Player/Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Player.Speed = capture2.clamp(arg1, 0, 23)
 end
end

end)()

recovered["Physics/Gravity"] = (function()
-- Captured function: Physics/Gravity
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.Gravity = arg1
 end
end

end)()

recovered["Player/Walk Speed"] = (function()
-- Captured function: Player/Walk Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r8)
local r2 = capture1.Player
if bit32.bxor(capture2, 363011559) == 479668872 then
	capture2 = bit32.bxor(capture2, 107600957)
end
r2.WalkSpeed = r8
 end
end

end)()

recovered["QB Aimbot/Throw Mode"] = (function()
-- Captured function: QB Aimbot/Throw Mode
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r14)
if capture1 then
	if r14 ~= "FIT" then
		if capture2 then
			if capture2.Set then
				capture2:Set("FIT", true)
			end
		end
		if _G.DimeSetMode then
			_G.DimeSetMode("FIT")
			return
		end
		return
	end
end
if _G.DimeSetMode then
	_G.DimeSetMode(r14)
	return
end
 end
end

end)()

recovered["QB Aimbot/Enable QB Aimbot"] = (function()
-- Captured function: QB Aimbot/Enable QB Aimbot
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r8)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.qba = r8
	return
end
 end
end

end)()

recovered["Catching/Football Size"] = (function()
-- Captured function: Catching/Football Size
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Catching.BallSize = capture2.clamp(arg1, 1, 20)
 end
end

end)()

recovered["Catching/Football Resize"] = (function()
-- Captured function: Catching/Football Resize
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.BallResize = arg1
 end
end

end)()

recovered["Catching/Arm Size"] = (function()
-- Captured function: Catching/Arm Size
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.ArmSize = arg1
 end
end

end)()

recovered["Misc/Endzone Zone"] = (function()
-- Captured function: Misc/Endzone Zone
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1 = arg1
 end
end

end)()

recovered["Catching/Arm Resize"] = (function()
-- Captured function: Catching/Arm Resize
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.ArmResize = arg1
 end
end

end)()

recovered["Catching/Catch Size"] = (function()
-- Captured function: Catching/Catch Size
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.HandSize = arg1
 end
end

end)()

recovered["Catching/Catch Resize"] = (function()
-- Captured function: Catching/Catch Resize
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.HandResize = arg1
 end
end

end)()

recovered["Catching/Fake Ball"] = (function()
-- Captured function: Catching/Fake Ball
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.FakeBall = arg1
 end
end

end)()

recovered["Catching/Dive Radius"] = (function()
-- Captured function: Catching/Dive Radius
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.DiveRadius = arg1
 end
end

end)()

recovered["Catching/Dive Vector"] = (function()
-- Captured function: Catching/Dive Vector
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.DiveVector = arg1
 end
end

end)()

recovered["Catching/Pull Tween Time"] = (function()
-- Captured function: Catching/Pull Tween Time
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.PullTweenTime = arg1
 end
end

end)()

recovered["Catching/Pull Radius"] = (function()
-- Captured function: Catching/Pull Radius
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.PullRadius = arg1
 end
end

end)()

recovered["Catching/Pull Vector"] = (function()
-- Captured function: Catching/Pull Vector
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.PullVector = arg1
 end
end

end)()

recovered["Catching/Swat Reach Distance"] = (function()
-- Captured function: Catching/Swat Reach Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.SwatRadius = arg1
 end
end

end)()

recovered["Catching/Swat Reach"] = (function()
-- Captured function: Catching/Swat Reach
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.SwatReach = arg1
 end
end

end)()

recovered["Physics/TP Distance"] = (function()
-- Captured function: Physics/TP Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.QuickTPDistance = arg1
 end
end

end)()

recovered["Catching/Freeze Tech Duration"] = (function()
-- Captured function: Catching/Freeze Tech Duration
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.FreezeDuration = arg1
 end
end

end)()

recovered["Catching/Freeze Tech"] = (function()
-- Captured function: Catching/Freeze Tech
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.FreezeTech = arg1
 end
end

end)()

recovered["Physics/Quick TP"] = (function()
-- Captured function: Physics/Quick TP
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r23)
capture1.Physics.QuickTP = r23
if r23 then
	capture2()
	return
end
capture3()
 end
end

end)()

recovered["Physics/Gravity Value"] = (function()
-- Captured function: Physics/Gravity Value
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r8)
local r2 = capture1
if bit32.bxor(capture2, 334854551) == 197404041 then
	capture2 = bit32.bxor(capture2, 3325302995)
end
r2.Physics.GravityValue = r8
 end
end

end)()

recovered["Physics/Click Tackle"] = (function()
-- Captured function: Physics/Click Tackle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.ClickTackle = arg1
 end
end

end)()

recovered["Catching/Magnets Hitbox Color"] = (function()
-- Captured function: Catching/Magnets Hitbox Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.HitboxColor = arg1
 end
end

end)()

recovered["Catching/Magnets Hitbox Shape"] = (function()
-- Captured function: Catching/Magnets Hitbox Shape
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.HitboxShape = arg1
 end
end

end)()

recovered["Catching/Visualize Magnets Hitbox"] = (function()
-- Captured function: Catching/Visualize Magnets Hitbox
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.ShowHitbox = arg1
 end
end

end)()

recovered["Catching/Magnets Type"] = (function()
-- Captured function: Catching/Magnets Type
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.MagnetType = arg1
 end
end

end)()

recovered["Physics/Click Tackle Distance"] = (function()
-- Captured function: Physics/Click Tackle Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.ClickTackleDistance = arg1
 end
end

end)()

recovered["Catching/Magnets Mode"] = (function()
-- Captured function: Catching/Magnets Mode
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.MagnetMode = arg1
 end
end

end)()

recovered["Catching/Magnets Delay"] = (function()
-- Captured function: Catching/Magnets Delay
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.Delay = arg1
 end
end

end)()

recovered["Catching/Magnets Radius"] = (function()
-- Captured function: Catching/Magnets Radius
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Catching.Radius = capture2.clamp(arg1, 0, 25)
 end
end

end)()

recovered["Catching/Football Magnets"] = (function()
-- Captured function: Catching/Football Magnets
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.Magnets = arg1
 end
end

end)()

recovered["Visuals/Replay FPS"] = (function()
-- Captured function: Visuals/Replay FPS
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.ReplayFPS = capture2.clamp(arg1, 30, 360)
 end
end

end)()

recovered["Visuals/Free Replay Camera"] = (function()
-- Captured function: Visuals/Free Replay Camera
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.ReplayCamera = arg1
 end
end

end)()

recovered["Visuals/Fog Color"] = (function()
-- Captured function: Visuals/Fog Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.FogColor = arg1
if capture1.Visuals.Fog then
	capture2()
	return
end
 end
end

end)()

recovered["Visuals/Fog Distance"] = (function()
-- Captured function: Visuals/Fog Distance
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.FogDistance = arg1
if capture1.Visuals.Fog then
	capture2()
	return
end
 end
end

end)()

recovered["Visuals/Fog"] = (function()
-- Captured function: Visuals/Fog
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.Fog = arg1
capture2()
 end
end

end)()

recovered["Visuals/Sky Preset"] = (function()
-- Captured function: Visuals/Sky Preset
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r5)
capture1(r5)
 end
end

end)()

recovered["Visuals/Precipitation"] = (function()
-- Captured function: Visuals/Precipitation
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r18)
capture1.Visuals.Weather = r18
capture2(r18)
 end
end

end)()

recovered["Visuals/Camera Zoom Unlock"] = (function()
-- Captured function: Visuals/Camera Zoom Unlock
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.CameraZoom = arg1
 end
end

end)()

recovered["Visuals/Hide Stadium"] = (function()
-- Captured function: Visuals/Hide Stadium
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r35)
capture1.Visuals.HideStadium = r35
setHideStadium(r35)
 end
end

end)()

recovered["Visuals/Low Graphics"] = (function()
-- Captured function: Visuals/Low Graphics
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r10)
capture1.Visuals.LowGraphics = r10
setLowGraphics(r10)
 end
end

end)()

recovered["Visuals/Shiny Helmet"] = (function()
-- Captured function: Visuals/Shiny Helmet
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r29)
capture1 = r29
if r29 then
	capture2()
	return
end
capture3()
 end
end

end)()

recovered["ThemeAccent"] = (function()
-- Captured function: ThemeAccent
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r5)
capture1:SetAccent(r5)
 end
end

end)()

recovered["Visuals/Remove Ball Trail"] = (function()
-- Captured function: Visuals/Remove Ball Trail
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r14)
capture1.Visuals.RemoveBallTrail = r14
if r14 then
	local r2, r3, r4 = capture2(capture3)
	local t7_12_1 = table.pack(d_1())
	if t7_12_1[1] then
		local r2_1 = t7_12_1[2]
		while true do
			stripBallTrails(r2_1)
			local t12_16_1 = table.pack(d_1())
			if t12_16_1[1] then
				r2_1 = t12_16_1[2]
			else
				break
			end
		end
	end
	return
end
 end
end

end)()

recovered["Visuals/Catch Effect Color"] = (function()
-- Captured function: Visuals/Catch Effect Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.CatchEffectColor = arg1
 end
end

end)()

recovered["ThemePreset"] = (function()
-- Captured function: ThemePreset
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r31)
local r29 = capture1:ApplyPreset(r31)
if r29 then
	if capture2 then
		capture2:SetValue(r29, true)
		return
	end
end
 end
end

end)()

recovered["Visuals/Catch Effects"] = (function()
-- Captured function: Visuals/Catch Effects
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.CatchEffects = arg1
 end
end

end)()

recovered["Visuals/Optimal Jump Color"] = (function()
-- Captured function: Visuals/Optimal Jump Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.OptimalJumpColor = arg1
 end
end

end)()

recovered["Visuals/Optimal Jump Marker"] = (function()
-- Captured function: Visuals/Optimal Jump Marker
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r10)
capture1.Visuals.OptimalJump = r10
if not r10 then
	if optMarker then
		optMarker:Destroy()
		optMarker = nil
		optPos = nil
		return
	end
end
 end
end

end)()

recovered["Visuals/Trajectory Color"] = (function()
-- Captured function: Visuals/Trajectory Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.TrajectoryColor = arg1
 end
end

end)()

recovered["Visuals/Visualize Ball Trajectory"] = (function()
-- Captured function: Visuals/Visualize Ball Trajectory
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r23)
capture1.Visuals.BallTrajectory = r23
if not r23 then
	resetTrajectorySnapshot()
	if trajBeam then
		trajBeam.Enabled = false
		return
	end
end
 end
end

end)()

recovered["Visuals/Path Color"] = (function()
-- Captured function: Visuals/Path Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.PathColor = arg1
 end
end

end)()

recovered["Visuals/Visualize Ball Path"] = (function()
-- Captured function: Visuals/Visualize Ball Path
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r31)
capture1.Visuals.PathBeam = r31
if r31 then
	startPath()
	return
end
stopPath()
 end
end

end)()

recovered["Visuals/Highlight Color"] = (function()
-- Captured function: Visuals/Highlight Color
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Visuals.HLColor = arg1
 end
end

end)()

recovered["Visuals/Football Highlight"] = (function()
-- Captured function: Visuals/Football Highlight
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r20)
local r1 = capture1.Visuals
if capture2 ~= 127432744 then
	capture2 = bit32.bxor(capture2, 1230850939)
end
r1.FootballHL = r20
if r20 then
	startHL()
	return
end
stopHL()
 end
end

end)()

recovered["Automatics/Guard Delay"] = (function()
-- Captured function: Automatics/Guard Delay
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoGuardDelay = arg1
 end
end

end)()

recovered["Automatics/Auto Guard"] = (function()
-- Captured function: Automatics/Auto Guard
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoGuard = arg1
 end
end

end)()

recovered["Automatics/Rush Delay"] = (function()
-- Captured function: Automatics/Rush Delay
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Delay = arg1
 end
end

end)()

recovered["Automatics/Rush End Part"] = (function()
-- Captured function: Automatics/Rush End Part
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r25)
local r1 = capture1
if bit32.bxor(capture2, 529594001) == 65578037 then
	capture2 = bit32.bxor(capture2, 2017170929)
end
r1.ShowEndPart = r25
 end
end

end)()

recovered["Misc/Enable Spectate"] = (function()
-- Captured function: Misc/Enable Spectate
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1 = arg1
capture2()
 end
end

end)()

recovered["Automatics/Rush Beam"] = (function()
-- Captured function: Automatics/Rush Beam
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.ShowBeam = arg1
 end
end

end)()

recovered["Automatics/Auto Rush"] = (function()
-- Captured function: Automatics/Auto Rush
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Enabled = arg1
 end
end

end)()

recovered["Automatics/Kick Accuracy"] = (function()
-- Captured function: Automatics/Kick Accuracy
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.KickAccuracy = arg1
 end
end

end)()

recovered["Misc/Target"] = (function()
-- Captured function: Misc/Target
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(arg1)
capture1 = arg1
if capture2 then
	capture3()
	return
end
 end
end

end)()

recovered["Automatics/Auto Kick"] = (function()
-- Captured function: Automatics/Auto Kick
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoKick = arg1
 end
end

end)()

recovered["Automatics/Swat Radius"] = (function()
-- Captured function: Automatics/Swat Radius
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoSwatRadius = arg1
 end
end

end)()

recovered["Physics/Auto Reel"] = (function()
-- Captured function: Physics/Auto Reel
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.on = arg1
 end
end

end)()

recovered["Automatics/Auto Swat"] = (function()
-- Captured function: Automatics/Auto Swat
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoSwat = arg1
 end
end

end)()

recovered["Automatics/Catch Radius"] = (function()
-- Captured function: Automatics/Catch Radius
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoCatchRadius = arg1
 end
end

end)()

recovered["Automatics/Auto Catch"] = (function()
-- Captured function: Automatics/Auto Catch
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoCatch = arg1
 end
end

end)()

recovered["Automatics/QB Type"] = (function()
-- Captured function: Automatics/QB Type
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoQBType = arg1
 end
end

end)()

recovered["Automatics/Auto QB"] = (function()
-- Captured function: Automatics/Auto QB
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Automatics.AutoQB = arg1
 end
end

end)()

recovered["Misc/Fling Target"] = (function()
-- Captured function: Misc/Fling Target
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1 = arg1
 end
end

end)()

recovered["Physics/Reel Power"] = (function()
-- Captured function: Physics/Reel Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.strength = capture2.clamp(arg1, 1, 8)
 end
end

end)()

recovered["function_1882"] = (function()
-- Captured function: function_1882
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_2725)
 return function(...)
return capture1(captured_function_2725(nil, 4147220690, 903842417, 3937291112, 442647495), select(2, ...))
 end
end

end)()

recovered["function_1900"] = (function()
-- Captured function: function_1900
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
local r4 = capture1.Character
if r4 then
	for _, r3 in ipairs(r4:GetDescendants()) do
		local exitTo = nil
		while true do
			if capture2(r3) then
				capture3(r3)
				local t19_20_1 = table.pack(d_1())
				if t19_20_1[1] then
					r3 = t19_20_1[3]
					continue
				end
				break
			else
				exitTo = 1
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	end
	return
end
 end
end

end)()

recovered["function_1928"] = (function()
-- Captured function: function_1928
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function()
if capture1 then
	local r8 = capture4(capture5)
	if r8 then
		if capture7(r8) then
			capture6:Notif("Spectate", "watching " .. r8.Name, 2)
			return
		end
		return
	end
	capture6:Notif("Spectate", "pick a target first", 2)
	capture1 = false
	return
end
capture2()
capture3()
 end
end

end)()

recovered["function_1941"] = (function()
-- Captured function: function_1941
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r9, arg2)
if arg2 then
	capture1 = r9
	return
end
 end
end

end)()

recovered["function_2309"] = (function()
-- Captured function: function_2309
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r14, r15)
local r1 = r14.xmasctx
if r1 then
	if r14.Open then
		if capture1[r15] then
			capture2.spawn(capture1[r15], r1)
			return
		end
	end
end
 end
end

end)()

recovered["function_2310"] = (function()
-- Captured function: function_2310
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r34, arg2, r36)
local r38 = arg2:Connect(r36)
capture1.insert(r34.Connections, r38)
return r38
 end
end

end)()

recovered["function_2320"] = (function()
-- Captured function: function_2320
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function(arg1, r17, arg3, r19)
if capture1[r17] ~= nil then
	if capture1[r17] then
		if r19 then
			r19(capture1[r17])
		end
	end
	local r1 = capture1[r17]
	if r1 then
		return r1
	end
	return nil
end
if capture2() then
	if isfile(r17) then
		local r1_1, r2 = capture3(getcustomasset, r17)
		local r3 = capture1
		if r1_1 then
			r2 = r2 or false
		else
			r2 = false
		end
		r3[r17] = r2
		if capture1[r17] then
			if r19 then
				r19(capture1[r17])
			end
		end
		local r1_2 = capture1[r17]
		if r1_2 then
			return r1_2
		end
		return nil
	end
	if capture4[r17] then
		capture5.insert(capture4[r17], r19)
		return nil
	end
	return (nil)("Rotation", table.unpack(nil, 1, (nil).n))
end
capture1[r17] = false
return nil
 end
end

end)()

recovered["function_2322"] = (function()
-- Captured function: function_2322
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r30, arg2, arg3, r33)
return r30:CreateNotification(arg2, arg3, r33)
 end
end

end)()

recovered["function_2326"] = (function()
-- Captured function: function_2326
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_4230, captured_function_4231)
 return function(r17, arg2)
r17:CreateWindow({
	Title = capture1(arg2 or "Cons1"),
	Subtitle = "cons",
	Folder = r17.Folder or "Cons1",
	Logo = "https://cdn.discordapp.com/icons/1446918773557952759/23fece088e485481a13c74598f9d1875.webp?size=1024",
})
local r2_1 = {}
captured_function_4231(nil, 2630825134, 2523859556, 506932382, 105117497)
r2_1.newTab = captured_function_4230(nil, 758365750, 1195055359, 593535721, 1792614257)
return r2_1
 end
end

end)()

recovered["function_2330"] = (function()
-- Captured function: function_2330
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r35)
r35.HoverDirty = false
local r4 = capture1.MouseEnabled
if r4 then
	r4 = r35.Open
	if r4 then
		r4 = not r35.Unloaded
		local r1 = 8427886559
		if r1 % 4294967296 ~= r1 % 4294967296 then
		end
	end
end
local r5 = 0
local r6 = 0
if r4 then
	local r3 = capture1:GetMouseLocation()
	local r1_1 = capture2:GetGuiInset()
	r5 = r3.X - r1_1.X
	local r2 = r3.Y
	if 2788637830 ~= 267041931 then
		r6 = r2 - r1_1.Y
	end
end
local r2_1 = #capture3
local r7 = 0
for r1_2 = 1, r2_1 do
	local exitTo = nil
	while true do
		local r1_3 = capture3[r1_2]
		local r3_1 = r1_3.Instance
		if r3_1.Parent then
			r7 += 1
			capture3[r7] = r1_3
			local r8 = false
			if r4 then
				local r9 = r3_1.AbsolutePosition
				local r11 = r3_1.AbsoluteSize
				r8 = r5 >= r9.X and r5 <= r9.X + r11.X and r6 >= r9.Y and r6 <= r9.Y + r11.Y and capture4(r3_1)
			end
			if r8 ~= r1_3.State then
				r1_3.State = r8
				r1_3.Apply(r8)
				if x_1 <= 0 then
					if d_1 >= S_1 then
						r1_2 = d_1
						continue
					end
				elseif d_1 <= S_1 then
					r1_2 = d_1
					continue
				end
			elseif x_1 <= 0 then
				if d_1 >= S_1 then
					r1_2 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r1_2 = d_1
				continue
			end
			break
		else
			exitTo = 1
			break
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
local r1_4 = r2_1 + 1
local r2_2 = #capture3
if 1 <= 0 then
	if r1_4 >= r2_2 then
		while true do
			r7 += 1
			capture3[r7] = capture3[r1_4]
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r1_4 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r1_4 = d_1
					continue
				end
				break
			end
		end
	end
elseif r1_4 <= r2_2 then
	while true do
		r7 += 1
		capture3[r7] = capture3[r1_4]
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r1_4 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r1_4 = d_1
				continue
			end
			break
		end
	end
end
local r1_5
if x_1 <= 0 then
	if d_1 >= S_1 then
		r1_5 = d_1
		while true do
			capture3[r1_5] = nil
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r1_5 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r1_5 = d_1
					continue
				end
				break
			end
		end
	end
elseif d_1 <= S_1 then
	r1_5 = d_1
	while true do
		capture3[r1_5] = nil
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r1_5 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r1_5 = d_1
				continue
			end
			break
		end
	end
end
 end
end

end)()

recovered["function_2331"] = (function()
-- Captured function: function_2331
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r12, r13, r14, r15)
local r2
if r13 then
	if r14 then
		r2 = string.format("[%s] %s", capture1(r13), capture1(r14))
	else
		r13 = r14 or r13 or ""
		r2 = capture1(r13)
	end
else
	r2 = capture1(r14 or r13 or "")
end
return r12:Notify(r2, r15)
 end
end

end)()

recovered["function_2332"] = (function()
-- Captured function: function_2332
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(captured_function_4241, captured_function_4243, captured_function_4244, captured_function_4245, captured_function_4246, captured_function_4247, captured_function_4248, captured_function_4249)
 return function(r13, r14)
local r4 = r13:ListConfigs()
r14:AddDropdown("ConfigList", { Text = "Config", Values = r4, Default = r13:GetAutoload() or r4[1] or "", NoSave = true })
r14:AddInput("ConfigName", { Text = "Name", Placeholder = "new config", NoSave = true })
r14:AddInput("ConfigPaste", { Text = "Import JSON", Placeholder = "paste config json", NoSave = true })
captured_function_4241(nil, 1864143158, 4165701579, 3683699572, 4031068943)
local r1_1 = r14.AddButtonRow
local r3 = {}
local r4_1 = { Text = "Save", Func = captured_function_4245(nil, 676612595, 1282168364, 698451808, 1641329840) }
local r5 = { Text = "Load", Func = captured_function_4244(nil, 3080191138, 393812606, 2051069085, 4257264712) }
r3[1] = r4_1
r3[2] = r5
r1_1(r14, r3)
local r1_2 = r14.AddButtonRow
local r3_1 = {}
local r4_2 = { Text = "Delete", Func = captured_function_4246(nil, 2444445772, 37861112, 1164657293, 360143786) }
local r5_1 = {
	Text = "Refresh",
	Func = captured_function_4249(nil, 2840195824, 176839170, 993466907, 1115153837),
}
r3_1[1] = r4_2
r3_1[2] = r5_1
r1_2(r14, r3_1)
local r1_3 = r14.AddButtonRow
local r3_2 = {}
local r4_3 = {
	Text = "Set autoload",
	Func = captured_function_4248(nil, 118036465, 2690913711, 2776419581, 3274899760),
}
local r5_2 = {
	Text = "Copy JSON",
	Func = captured_function_4247(nil, 2061546002, 1799645864, 2689273343, 3905698549),
}
r3_2[1] = r4_3
r3_2[2] = r5_2
r1_3(r14, r3_2)
r14:AddButton({
	Text = "Import JSON",
	Func = captured_function_4243(nil, 2152475800, 434125442, 1011364358, 3190605736),
})
 end
end

end)()

recovered["function_2333"] = (function()
-- Captured function: function_2333
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r19, r20, r21)
return r19:RequestImage(string.format("%s/icons/%s.png", r19.Folder, r20), string.format("https://wsrv.nl/?url=api.iconify.design%%2Flucide%%2F%s.svg%%3Fcolor%%3Dwhite&output=png&w=96", r20), r21)
 end
end

end)()

recovered["function_2336"] = (function()
-- Captured function: function_2336
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r34)
local r4 = r34:GetAutoload()
if r4 then
	r34.Autoload = r4
	return r34:LoadConfig(r4)
end
return false, "no autoload set"
 end
end

end)()

recovered["function_2337"] = (function()
-- Captured function: function_2337
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_4265, captured_function_4266)
 return function(r35, r36)
local r42 = r36.AddColorPicker
return r36:AddDropdown("ThemePreset", {
	Text = "Preset",
	Values = r35:GetPresets(),
	Default = "Santa",
	Callback = captured_function_4266(nil, 382013437, 509873082, 3680915268, 1947685029),
}), (r42(r36, "ThemeAccent", {
	Text = "Accent",
	Default = capture1.Accent,
	Callback = captured_function_4265(nil, 1358484226, 721132962, 3086886931, 1923972522),
}))
 end
end

end)()

recovered["function_2338"] = (function()
-- Captured function: function_2338
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r14, r15)
local r5 = ipairs
if bit32.bxor(capture2, 72884392) == 157996264 then
	capture2 = bit32.bxor(capture2, 2952810623)
end
for _, r3 in r5(capture1) do
	if r3.Name ~= r15 then
		continue
	end
	r14:SetAccent(r3.Accent)
	return r3.Accent
end
return nil
 end
end

end)()

recovered["function_2339"] = (function()
-- Captured function: function_2339
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r11 = {}
local r2, r3, r4 = ipairs(capture1)
local t8_10_1 = table.pack(d_1())
if t8_10_1[1] then
	local r3_1 = t8_10_1[3]
	while true do
		capture2.insert(r11, r3_1.Name)
		local t12_15_1 = table.pack(d_1())
		if t12_15_1[1] then
			r3_1 = t12_15_1[3]
		else
			break
		end
	end
end
return r11
 end
end

end)()

recovered["function_2340"] = (function()
-- Captured function: function_2340
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, capture12, capture13, capture14, capture15, capture16, capture17, capture18, capture19, capture20, capture21, capture22, capture23, capture24, capture25, capture26, capture27, capture28, capture29, capture30, captured_function_4272, captured_function_4273, captured_function_4274, captured_function_4276, captured_function_4279, captured_function_4280, captured_function_4281, captured_function_4282, captured_function_4283)
 return function(arg1, r21)
r21.AddToggle = captured_function_4282(nil, 366048678, 3256843861, 4043761288, 1638753582)
r21.AddSlider = captured_function_4283(nil, 3396289550, 1716297572, 1383613901, 3862570080)
r21.AddDropdown = captured_function_4273(nil, 3110066296, 2509150501, 3821622139, 3114362341)
r21.AddInput = captured_function_4272(nil, 2471435650, 1709063950, 3900207684, 1791741578)
r21.AddKeybind = captured_function_4274(nil, 1692386396, 1058371658, 651658242, 523613964)
r21.AddColorPicker = captured_function_4279(nil, 1038049379, 696185106, 2663954640, 1721860510)
r21.AddButton = captured_function_4280(nil, 2261311413, 4006365322, 2481625949, 3577079538)
r21.AddButtonRow = captured_function_4281(nil, 796420764, 460393715, 4208309027, 2036989875)
r21.AddLabel = captured_function_4276(nil, 3367943030, 2300253872, 1969042350, 3765373783)
 end
end

end)()

recovered["function_2342"] = (function()
-- Captured function: function_2342
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
local r8 = {}
for r1, r2 in capture1(arg1.Flags) do
	local exitTo = nil
	while true do
		local r4, r5 = capture2(r2.Save)
		if r4 then
			if r5 ~= nil then
				r8[r1] = r5
				local t11_23_1 = table.pack(d_1())
				if t11_23_1[1] then
					r1 = t11_23_1[2]
					r2 = t11_23_1[3]
					continue
				end
			else
				local t12_37_1 = table.pack(d_1())
				if t12_37_1[1] then
					r1 = t12_37_1[2]
					r2 = t12_37_1[3]
					continue
				end
			end
			break
		else
			exitTo = 1
			break
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
return { Flags = r8, Toggles = {}, Options = {} }
 end
end

end)()

recovered["function_2344"] = (function()
-- Captured function: function_2344
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r35)
if capture1() then
	local r3 = r35.Folder .. "/autoload.txt"
	if isfile(r3) then
		local r1, r2 = capture2(readfile, r3)
		if r1 then
			if r2 ~= "" then
				if r2 then
					return r2
				end
			end
		end
		return nil
	end
	return nil
end
return nil
 end
end

end)()

recovered["function_2345"] = (function()
-- Captured function: function_2345
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(arg1)
arg1.HoverDirty = true
 end
end

end)()

recovered["function_2350"] = (function()
-- Captured function: function_2350
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r8, r9, r10)
if type(r9) ~= "string" then
	return nil
end
if r9 == "" then
	return nil
end
if string.match(r9, "^rbxassetid://") then
	r10(r9)
	return r9
end
if string.match(r9, "^rbxasset://") then
	r10(r9)
	return r9
end
if not string.match(r9, "^https?://") then
	if capture2() then
		if isfile(r9) then
			local r7, r8_1 = capture3(getcustomasset, r9)
			if r7 then
				if r8_1 then
					r10(r8_1)
					return r8_1
				end
			end
			return nil
		end
		return nil
	end
	return nil
end
if string.find(r9, "wsrv.nl", 1, true) then
	return r8:RequestImage(r8.Folder .. "/logo.png", r9, r10)
end
while true do
	bit32.band(nil, nil)
	;(nil)["&output=png&w=256&fit=cover"] = "UDim2"
end
 end
end

end)()

recovered["function_2384"] = (function()
-- Captured function: function_2384
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2, r3 = capture1:find("^[ \n\r\t]*", capture2)
capture2 = (r3 or capture2 - 1) + 1
 end
end

end)()

recovered["function_2385"] = (function()
-- Captured function: function_2385
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
capture1()
local r6 = capture2:sub(capture3, capture3)
if r6 ~= "\"" then
	if r6 ~= "{" then
		if r6 ~= "[" then
			if r6 == "t" then
				if capture2:sub(capture3, capture3 + 3) == "true" then
					capture3 += 4
					return true
				end
			end
			if r6 == "f" then
				if capture2:sub(capture3, capture3 + 4) == "false" then
					capture3 += 5
					return false
				end
			end
			if r6 ~= "n" then
				return parse_number()
			end
			if capture2:sub(capture3, capture3 + 3) ~= "null" then
				return parse_number()
			end
			capture3 += 4
			return nil
		end
		return parse_array()
	end
	return parse_object()
end
return parse_string()
 end
end

end)()

recovered["function_2390"] = (function()
-- Captured function: function_2390
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaCycleWR then
	_G.FF3QbaCycleWR(-1)
	return
end
 end
end

end)()

recovered["function_2391"] = (function()
-- Captured function: function_2391
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaToggleLock then
	_G.FF3QbaToggleLock()
	return
end
 end
end

end)()

recovered["function_2392"] = (function()
-- Captured function: function_2392
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaAdjustAngle then
	_G.FF3QbaAdjustAngle(-5)
	return
end
 end
end

end)()

recovered["function_2393"] = (function()
-- Captured function: function_2393
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaAdjustAngle then
	_G.FF3QbaAdjustAngle(5)
	return
end
 end
end

end)()

recovered["function_2394"] = (function()
-- Captured function: function_2394
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaCycleWR then
	_G.FF3QbaCycleWR(1)
	return
end
 end
end

end)()

recovered["function_2397"] = (function()
-- Captured function: function_2397
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r2, r3, r4, r5)
if r2.ReadHolder then
	if r3 then
		r2.ReadHolder.Visible = true
		if r2.ReadLabel then
			r2.ReadLabel.Text = r3
			if r5 then
				r2.ReadLabel.TextColor3 = r5
			end
		end
		if r2.ReadReason then
			r2.ReadReason.Text = r4 or ""
		end
		if r2.ReadStroke then
			if r5 then
				r2.ReadStroke.Color = r5
				return
			end
		end
		return
	end
	if r2.ReadHolder.Visible then
		r2.ReadHolder.Visible = false
		return
	end
	return
end
 end
end

end)()

recovered["function_2398"] = (function()
-- Captured function: function_2398
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r31, r32)
if r31.PowerValue then
	r31.PowerValue.Text = capture1(r32)
	return
end
 end
end

end)()

recovered["function_2400"] = (function()
-- Captured function: function_2400
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r33, r34)
if r33.ThrowName then
	r33.ThrowName.Text = capture1(r34)
	return
end
 end
end

end)()

recovered["function_2401"] = (function()
-- Captured function: function_2401
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r31, r32)
if r31.ScreenGui then
	r31.ScreenGui.Enabled = r32
	return
end
 end
end

end)()

recovered["function_2403"] = (function()
-- Captured function: function_2403
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r25, r26)
if r25.LockIcon then
	local r1 = r25.LockIcon
	local r5
	if r26 then
		r5 = capture1.Text or capture1.Accent
	else
		r5 = capture1.Accent
		r1.ImageColor3 = r5
		return
	end
	r1.ImageColor3 = r5
	return
end
 end
end

end)()

recovered["function_2412"] = (function()
-- Captured function: function_2412
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
capture2 = capture1.CurrentCamera or capture2
return capture2
 end
end

end)()

recovered["function_2413"] = (function()
-- Captured function: function_2413
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r23, r24)
if r23 then
	if r23 ~= r23 then
		if r24 then
			return r24
		end
		return Vector3.new(0, 0, 0)
	end
	local r1 = r23.Magnitude
	if not (r1 < 0.0001) then
		if r1 ~= r1 then
			if r24 then
				return r24
			end
			return Vector3.new(0, 0, 0)
		end
		return r23 / r1
	end
	if r24 then
		return r24
	end
	return Vector3.new(0, 0, 0)
end
if r24 then
	return r24
end
return Vector3.new(0, 0, 0)
 end
end

end)()

recovered["function_2709"] = (function()
-- Captured function: function_2709
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1, arg2, r22)
capture1:SetValue(arg2, r22)
 end
end

end)()

recovered["function_2711"] = (function()
-- Captured function: function_2711
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1.Value
 end
end

end)()

recovered["function_2713"] = (function()
-- Captured function: function_2713
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()

 end
end

end)()

recovered["function_2714"] = (function()
-- Captured function: function_2714
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
return false
 end
end

end)()

recovered["function_2715"] = (function()
-- Captured function: function_2715
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1, arg2)
capture1:SetValues(arg2 or {})
 end
end

end)()

recovered["function_2720"] = (function()
-- Captured function: function_2720
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
return (arg1 or "_p") .. capture1(capture2.random(100000, 900000))
 end
end

end)()

recovered["function_2721"] = (function()
-- Captured function: function_2721
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
if not (capture1() - capture2 < capture3) then
	capture2 = capture1()
	if capture4 then
		capture4.CFrame = capture4.CFrame + capture4.CFrame.LookVector * (capture5.Physics.QuickTPDistance or 0)
		return
	end
	return
end
 end
end

end)()

recovered["function_2929"] = (function()
-- Captured function: function_2929
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r8, r9, r10)
if capture2 == 6086283 then
	capture2 = bit32.bxor(capture2, 3312970411)
end
if r8.Popover then
	if r8.Popover ~= r9 then
		r8.ClosePopover()
	end
end
r8.Popover = r9
r8.PopoverCloser = r10
capture1.Visible = true
 end
end

end)()

recovered["function_2930"] = (function()
-- Captured function: function_2930
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if capture1.Popover then
	local r2 = capture1.PopoverCloser
	capture1.Popover = nil
	capture1.PopoverCloser = nil
	capture2.Visible = false
	if r2 then
		r2()
		return
	end
	return
end
 end
end

end)()

recovered["function_3365"] = (function()
-- Captured function: function_3365
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r20, r21)
capture1.insert(r20.Changed, r21)
return r20
 end
end

end)()

recovered["function_3366"] = (function()
-- Captured function: function_3366
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(arg1, r34, r35)
local r36, r37, r38 = (capture1(r34) or capture2.Accent):ToHSV()
capture3 = r36
capture4 = r37
capture5 = r38
capture6(r35)
 end
end

end)()

recovered["function_3368"] = (function()
-- Captured function: function_3368
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(arg1)
return arg1.Value
 end
end

end)()

recovered["function_3370"] = (function()
-- Captured function: function_3370
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
if capture1 then
	capture1:Disconnect()
	capture1 = nil
end
if capture2 then
	capture2:Disconnect()
	capture2 = nil
end
capture3 = nil
 end
end

end)()

recovered["function_3372"] = (function()
-- Captured function: function_3372
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r6)
if r6 then
	if r6 ~= "" then
		if r6 ~= "No other players" then
			for _, r9 in ipairs(capture1:GetPlayers()) do
				local exitTo = nil
				while true do
					if r9 ~= capture2 then
						exitTo = 1
						break
					else
						local t15_32_1 = table.pack(d_1())
						if t15_32_1[1] then
							r9 = t15_32_1[3]
							continue
						end
						break
					end
				end
				if exitTo == 1 then
					if r9.Name ~= r6 then
						continue
					end
					return r9
				end
				break
			end
			return nil
		end
		return nil
	end
	return nil
end
return nil
 end
end

end)()

recovered["function_3656"] = (function()
-- Captured function: function_3656
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
capture1.qba = not capture1.qba
 end
end

end)()

recovered["function_3657"] = (function()
-- Captured function: function_3657
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture2 = capture1.clamp(capture2 + arg1, 5, 85)
if _G.FF3HUD then
	return
end
 end
end

end)()

recovered["function_3658"] = (function()
-- Captured function: function_3658
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2
if capture1 ~= "Dime" then
	if capture1 ~= "Bullet" then
		r2 = "Dime"
	else
		r2 = "FIT"
	end
else
	r2 = "Bullet"
end
capture2(r2)
 end
end

end)()

recovered["function_3659"] = (function()
-- Captured function: function_3659
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture2 = capture1.clamp(arg1, 5, 85)
 end
end

end)()

recovered["function_3661"] = (function()
-- Captured function: function_3661
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1
 end
end

end)()

recovered["function_3662"] = (function()
-- Captured function: function_3662
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1
 end
end

end)()

recovered["function_3663"] = (function()
-- Captured function: function_3663
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if capture1 then
	capture1 = nil
	if _G.FF3HUD then
		if _G.FF3HUD.SetLocked then
			_G.FF3HUD:SetLocked(false)
			return
		end
	end
	return
end
local r2 = capture2()
if r2 then
	capture1 = r2
	if _G.FF3HUD then
		if _G.FF3HUD.SetLocked then
			_G.FF3HUD:SetLocked(true)
			return
		end
	end
end
 end
end

end)()

recovered["function_3665"] = (function()
-- Captured function: function_3665
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r23)
capture1.DEFAULT_BULLET_LEAD = r23
capture2.Bullet = r23
 end
end

end)()

recovered["function_3666"] = (function()
-- Captured function: function_3666
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(arg1)
capture1 = arg1
capture3 = capture2[capture1]
capture4 = nil
if not capture5() then
	capture6()
end
if _G.FF3HUD then
	_G.FF3HUD:SetThrow(capture1)
	return
end
 end
end

end)()

recovered["function_3667"] = (function()
-- Captured function: function_3667
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r28)
capture1.DEFAULT_DIME_LEAD = r28
capture2.Dime = r28
 end
end

end)()

recovered["function_3698"] = (function()
-- Captured function: function_3698
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r24, r25, r26)
if type(r24) ~= "string" then
	error("bad argument #1 to 'sub' (string expected, got " .. type(r24) .. ")", 2)
end
local r2 = #r24
if not (r25 < 0) then
	if r26 ~= nil then
		if not (r26 < 0) then
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if r2 < r25 then
						return ""
					end
				elseif r2 < r25 then
					return ""
				end
				return string.char(string.byte(r24, r25, r2))
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		else
			r26 = r2 + r26 + 1
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		end
	else
		r26 = r2
		if not (r25 < 1) then
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		else
			r25 = 1
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		end
	end
else
	r25 = r2 + r25 + 1
	if r26 ~= nil then
		if not (r26 < 0) then
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		else
			r26 = r2 + r26 + 1
			if not (r25 < 1) then
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			else
				r25 = 1
				if not (r2 < r26) then
					r2 = r26
					if not (r2 < r25) then
						return string.char(string.byte(r24, r25, r2))
					end
					return ""
				end
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
			end
		end
	else
		r26 = r2
		if not (r25 < 1) then
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		else
			r25 = 1
			if not (r2 < r26) then
				r2 = r26
				if not (r2 < r25) then
					return string.char(string.byte(r24, r25, r2))
				end
				return ""
			end
			if not (r2 < r25) then
				return string.char(string.byte(r24, r25, r2))
			end
		end
	end
end
return ""
 end
end

end)()

recovered["function_3762"] = (function()
-- Captured function: function_3762
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function(r13, r14, r15)
local r1 = capture1
if capture5 + 324921259 ~= 239314693 then
	if r1 then
		if type(r14) ~= "table" then
			r14 = {}
			r13.Value = r14
		elseif r14 then
			r13.Value = r14
		else
			r14 = {}
			r13.Value = r14
		end
	else
		r14 = r14 or ""
		r13.Value = capture2(r14)
	end
else
	capture5 = bit32.bxor(capture5, 2217423837)
	if r1 then
		if type(r14) ~= "table" then
			r14 = {}
			r13.Value = r14
		elseif r14 then
			r13.Value = r14
		else
			r14 = {}
			r13.Value = r14
		end
	else
		r13.Value = capture2(r14 or "")
	end
end
capture3()
if r15 then
	return
end
capture4(r13, r13.Value)
 end
end

end)()

recovered["function_3834"] = (function()
-- Captured function: function_3834
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(r19, r20, r21)
local r4 = capture1.new(r19)
local r5 = r20.Parent
r20.Parent = nil
for r1, r2 in r20, nil, nil do
	local exitTo = nil
	while true do
		r4[r1] = r2
		if capture2(r2) ~= "Color3" then
			exitTo = 1
			break
		else
			local r7 = capture3[capture4(r2)]
			if r7 then
				capture5.insert(capture6, { Instance = r4, Property = r1, Role = r7 })
				local t24_37_1 = table.pack(d_1())
				if t24_37_1[1] then
					r1 = t24_37_1[2]
					r2 = t24_37_1[3]
					continue
				end
			else
				exitTo = 1
				break
			end
			break
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
if r21 then
	local t34_46_1 = table.pack(d_1())
	if t34_46_1[1] then
		local r2_1 = t34_46_1[3]
		while true do
			r2_1.Parent = r4
			local t30_48_1 = table.pack(d_1())
			if t30_48_1[1] then
				r2_1 = t30_48_1[3]
			else
				break
			end
		end
	end
end
r4.Parent = r5
return r4
 end
end

end)()

recovered["function_3835"] = (function()
-- Captured function: function_3835
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r28)
return capture1("UICorner", { CornerRadius = UDim.new(0, r28) })
 end
end

end)()

recovered["function_3836"] = (function()
-- Captured function: function_3836
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1, arg2, arg3)
return capture1("UIStroke", {
	Color = arg1 or capture2.Border,
	Transparency = arg2 or 0.5,
	Thickness = arg3 or 1,
	ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
})
 end
end

end)()

recovered["function_3837"] = (function()
-- Captured function: function_3837
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r19, r20)
return capture1("UIGradient", {
	Color = ColorSequence.new(nil, Color3.fromRGB(255 * r20, 255 * r20, 255 * capture2.min(r20 + 0.08, 1))),
	Rotation = r19,
})
 end
end

end)()

recovered["function_3839"] = (function()
-- Captured function: function_3839
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r31)
r31.BackgroundTransparency = r31.BackgroundTransparency or 1
r31.Font = r31.Font or Enum.Font.GothamMedium
r31.TextSize = r31.TextSize or 13
r31.TextColor3 = r31.TextColor3 or capture1.Text
r31.TextXAlignment = r31.TextXAlignment or Enum.TextXAlignment.Left
return capture2("TextLabel", r31)
 end
end

end)()

recovered["function_3840"] = (function()
-- Captured function: function_3840
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r32)
local r2 = capture1("UIGradient", { Color = capture2(), Rotation = r32 or 0 })
capture3.insert(capture4, r2)
return r2
 end
end

end)()

recovered["function_3841"] = (function()
-- Captured function: function_3841
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r16, r17, arg3)
local r19 = capture1:Create(r16, arg3 or capture2.Smooth, r17)
r19:Play()
return r19
 end
end

end)()

recovered["function_3854"] = (function()
-- Captured function: function_3854
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8)
 return function()
return "ZIndex"
 end
end

end)()

recovered["function_3856"] = (function()
-- Captured function: function_3856
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_10540)
 return function()
local r2 = captured_function_10540(nil, 1796153206, 510242563, 3677318953, 1060224852)
capture1(r2)
return true
 end
end

end)()

recovered["function_4165"] = (function()
-- Captured function: function_4165
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
local r4 = type(writefile) == "function"
if r4 then
	r4 = type(isfile) == "function"
	if r4 then
		return type(readfile) == "function"
	end
end
return r4
 end
end

end)()

recovered["function_4166"] = (function()
-- Captured function: function_4166
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
local r2 = capture1.ConfigFolder
if r2 then
	return r2
end
return capture1.Folder .. "/configs"
 end
end

end)()

recovered["function_4168"] = (function()
-- Captured function: function_4168
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
local r6 = capture1.ScreenGui.AbsoluteSize
if not (r6.X < 1) then
	if not (r6.Y < 1) then
		capture4.Scale = capture2.max(capture2.min(1, (r6.X - 24) / capture3.X, (r6.Y - 24) / capture3.Y), 0.45)
		local r5 = capture5.UIScale
		local r7
		if capture1.Open then
			r7 = capture4.Scale or capture4.Scale * 0.97
		else
			r7 = capture4.Scale * 0.97
			r5.Scale = r7
			return
		end
		r5.Scale = r7
		return
	end
	return
end
 end
end

end)()

recovered["function_4174"] = (function()
-- Captured function: function_4174
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
local r2 = type(getcustomasset) == "function"
if r2 then
	return (capture1())
end
return r2
 end
end

end)()

recovered["function_4176"] = (function()
-- Captured function: function_4176
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r5)
if type(makefolder) ~= "function" then
	return
end
if type(isfolder) ~= "function" then
	return
end
local r5_1, r10, r11 = string.gmatch(r5, "[^/]+")
local r9_1 = nil
for r5_2 in r5_1, r10, r11 do
	local exitTo = nil
	while true do
		if r9_1 then
			r9_1 = r9_1 .. "/" .. r5_2 or r5_2
		else
			r9_1 = r5_2
		end
		if isfolder(r9_1) then
			exitTo = 1
			break
		else
			capture1(makefolder, r9_1)
			local t28_48_1 = table.pack(d_1())
			if t28_48_1[1] then
				r5_2 = t28_48_1[2]
				continue
			end
		end
		break
	end
	if exitTo == 1 then
		continue
	end
	break
end
 end
end

end)()

recovered["function_4182"] = (function()
-- Captured function: function_4182
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
local r13 = ColorSequence.new
local r11 = {}
local r5 = ColorSequenceKeypoint.new(0, capture1.AccentDeep)
local r6 = ColorSequenceKeypoint.new(0.55, capture1.Accent)
local r4 = ColorSequenceKeypoint.new
local r9 = capture1.AccentLift
r11[1] = r5
r11[2] = r6
do
	local values = table.pack(r4(1, r9))
	table.move(values, 1, values.n, 3, r11)
end
return r13(r11)
 end
end

end)()

recovered["function_4184"] = (function()
-- Captured function: function_4184
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function()
capture1.clear(capture2)
local t12_8_1 = table.pack(d_1())
if t12_8_1[1] then
	local r2 = t12_8_1[2]
	local r3 = t12_8_1[3]
	while true do
		capture2[capture4(r3)] = r2
		local t18_15_1 = table.pack(d_1())
		if t18_15_1[1] then
			r2 = t18_15_1[2]
			r3 = t18_15_1[3]
		else
			break
		end
	end
end
 end
end

end)()

recovered["function_4239"] = (function()
-- Captured function: function_4239
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r31)
if r31 then
	while true do
		if r31 ~= game then
			if r31:IsA("GuiObject") then
				if not r31.Visible then
					break
				end
			end
			if r31:IsA("ScreenGui") then
				return true
			end
			r31 = r31.Parent
			if r31 then
				continue
			end
			return true
		else
			return true
		end
	end
	return false
end
return true
 end
end

end)()

recovered["function_4284"] = (function()
-- Captured function: function_4284
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, captured_function_11570, captured_function_11573, captured_function_11574, captured_function_11575, captured_function_11576)
 return function(r16, r17, arg3, r19)
local r12 = {
	Idx = r16,
	Type = arg3,
	Changed = {},
	Callback = r17.Callback,
	NoSave = r17.NoSave,
	OnChanged = captured_function_11575(nil, 2132584372, 1054972053, 3036332610, 3347703995),
	Get = captured_function_11576(nil, 3827004446, 2996530692, 3854959124, 809442831),
}
if r16 then
	r19[r16] = r12
	if not r17.NoSave then
		local r6 = r17.Default
		local r2, r5 = captured_function_11570(nil, 2805741710, 1474044529, 3816099779, 1308852122)(126582701, r6)
		if r2 + 393105472 == 176321159 then
			bit32.bxor(r2, 130475537)
		end
		capture5.Flags[r16] = {
			Default = r5,
			Save = captured_function_11574(nil, 1347617701, 1971689408, 3879355511, 1251048062),
			Load = captured_function_11573(nil, 1224453261, 4090914299, 3896611728, 695824339),
		}
		return r12
	end
end
return r12
 end
end

end)()

recovered["function_4286"] = (function()
-- Captured function: function_4286
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r19, r20)
local r1, r2, r3 = ipairs(r19.Changed)
local t24_11_1 = table.pack(d_1())
if t24_11_1[1] then
	local r2_1 = t24_11_1[3]
	while true do
		capture1.spawn(r2_1, r20)
		local t29_14_1 = table.pack(d_1())
		if t29_14_1[1] then
			r2_1 = t29_14_1[3]
		else
			break
		end
	end
end
if r19.Callback then
	capture1.spawn(r19.Callback, r20)
	return
end
 end
end

end)()

recovered["function_4287"] = (function()
-- Captured function: function_4287
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1, arg2)
local r2 = { Instance = arg1, Apply = arg2, State = false }
capture1.insert(capture2, r2)
return r2
 end
end

end)()

recovered["function_4288"] = (function()
-- Captured function: function_4288
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r19, r20)
return capture1("UIListLayout", {
	Padding = UDim.new(0, r19),
	FillDirection = r20 or Enum.FillDirection.Vertical,
	SortOrder = Enum.SortOrder.LayoutOrder,
})
 end
end

end)()

recovered["function_4289"] = (function()
-- Captured function: function_4289
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r15, r16, r17, r18)
return capture1("UIPadding", {
	PaddingTop = UDim.new(0, r15),
	PaddingRight = UDim.new(0, r16 or r15),
	PaddingBottom = UDim.new(0, r17 or r15),
	PaddingLeft = UDim.new(0, r18 or r16 or r15),
})
 end
end

end)()

recovered["function_4290"] = (function()
-- Captured function: function_4290
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, captured_function_11590)
 return function(r35)
local r1 = captured_function_11590(nil, 1262634896, 1382027650, 462155422, 1355776997)
capture1(r35, r1)
 end
end

end)()

recovered["function_4291"] = (function()
-- Captured function: function_4291
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, captured_function_11593)
 return function(r29)
local r1 = captured_function_11593(nil, 548245827, 2148971602, 2894851430, 1427444354)
capture1(r29, r1)
 end
end

end)()

recovered["function_4292"] = (function()
-- Captured function: function_4292
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r15)
return string.format("#%02X%02X%02X", r15.R * 255 + 0.5, r15.G * 255 + 0.5, r15.B * 255 + 0.5)
 end
end

end)()

recovered["function_4348"] = (function()
-- Captured function: function_4348
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11)
 return function(r10, r11, r12)
local r2_1 = capture1.clamp(capture2(capture3(r11) or capture4), capture4, capture5)
if r10.Dragging then
	if r2_1 == r10.Value then
		if r10.Painted then
			return
		end
	end
end
r10.Painted = true
r10.Value = r2_1
local r3 = capture6
local r5 = capture11 + 317666717 ~= 345475987
table.unpack(nil, 66, (nil).n)
capture11 = bit32.bxor(capture11, 1589306755)
r3.Text = r5 .. capture8
local r4 = not r10.Dragging
capture9((r2_1 - capture4) / capture1.max(capture5 - capture4, 1e-06), r4)
if r12 then
	return
end
capture10(r10, r2_1)
 end
end

end)()

recovered["function_4430"] = (function()
-- Captured function: function_4430
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r20, r21, r22)
r20.Value = capture1(r21 or "")
local r1 = capture2
local r3 = r20.Value
if bit32.bxor(capture4, 171465547) ~= 16854246 then
	capture4 = bit32.bxor(capture4, 917265245)
end
r1.Text = r3
if r22 then
	return
end
capture3(r20, r20.Value)
 end
end

end)()

recovered["function_4632"] = (function()
-- Captured function: function_4632
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if capture1.Type ~= "Keybind" then
	if capture1.Type ~= "Color" then
		return capture1.Value
	end
	return capture2(capture1.Value)
end
if capture1.Value then
	local r4 = capture1.Value.Name
	if r4 then
		return r4
	end
end
return ""
 end
end

end)()

recovered["function_4906"] = (function()
-- Captured function: function_4906
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r20, r21)
if r20 ~= r21 then
	if type(r20) == "table" then
		if type(r21) == "table" then
			if #r20 ~= #r21 then
				return false
			end
			for r1, r2 in ipairs(r20) do
				if r2 ~= r21[r1] then
					return false
				end
			end
			for r5 in capture1(r21) do
				if r20[r5] ~= nil then
					continue
				end
				return false
			end
			return true
		end
	end
	return false
end
return true
 end
end

end)()

recovered["function_4908"] = (function()
-- Captured function: function_4908
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(captured_function_11874)
 return function(r25)
local r6 = string.gsub
local r5 = captured_function_11874(nil, 198104347, 2725675228, 890010951, 2017426620)
return (r6(r25, "[^%w%-%.%_%~]", r5))
 end
end

end)()

recovered["function_5011"] = (function()
-- Captured function: function_5011
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, captured_function_11896)
 return function(r11, r12, r13)
local r9, r10 = capture1(capture2.new, r11)
if r9 then
	if not r10 then
		return nil
	end
	if r13 then
		local r2, r3, r4 = capture3(r13)
		local t46_24_1 = table.pack(d_1())
		if t46_24_1[1] then
			repeat
				local r9_1 = captured_function_11896(nil, 2843920232, 1754623972, 2407713943, 1857457844)
				capture1(r9_1)
				local t27_29_1 = table.pack(d_1())
			until not t27_29_1[1]
		end
		if r12 then
			r10.Parent = r12
			return r10
		end
	elseif r12 then
		r10.Parent = r12
		return r10
	end
	return r10
end
return nil
 end
end

end)()

recovered["function_5012"] = (function()
-- Captured function: function_5012
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, captured_function_11898)
 return function(r36, r37, r38)
if not r36 then
	return
end
local r1 = captured_function_11898(nil, 1861628590, 4042711324, 3930839900, 2693562772)
capture1(r1)
capture3.insert(capture4, { Instance = r36, Property = r37, Role = r38 })
 end
end

end)()

recovered["function_5013"] = (function()
-- Captured function: function_5013
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r13, r14, arg3, arg4)
local r17 = capture1("UIStroke", r13, {
	Thickness = arg3 or 1,
	Transparency = arg4 or 0,
	ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual,
})
capture2(r17, "Color", r14 or "Accent")
return r17
 end
end

end)()

recovered["function_5014"] = (function()
-- Captured function: function_5014
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1, arg2)
return capture1("UICorner", arg1, { CornerRadius = UDim.new(arg2, 0) })
 end
end

end)()

recovered["function_5371"] = (function()
-- Captured function: function_5371
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r11, r12)
for _, r3 in ipairs(r11:GetChildren()) do
	local exitTo = nil
	local exitTo2 = nil
	local r8
	while true do
		if r3:IsA("SurfaceAppearance") then
			r8 = #r12.Detached + 1
			r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
			r3.Parent = nil
			local t60_37_1 = table.pack(d_1())
			if t60_37_1[1] then
				r3 = t60_37_1[3]
				continue
			end
			break
		else
			exitTo2 = 1
			break
		end
	end
	if exitTo2 == 1 then
		local exitTo4, exitTo3, exitTo6, exitTo5
		if r3:IsA("Decal") then
			exitTo4 = nil
			while true do
				r8 = #r12.Detached + 1
				r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
				r3.Parent = nil
				local t60_37_1 = table.pack(d_1())
				if t60_37_1[1] then
					r3 = t60_37_1[3]
					exitTo3 = nil
					while true do
						if r3:IsA("SurfaceAppearance") then
							r8 = #r12.Detached + 1
							r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
							r3.Parent = nil
							local t60_37_1 = table.pack(d_1())
							if t60_37_1[1] then
								r3 = t60_37_1[3]
								continue
							end
							break
						else
							exitTo3 = 1
							break
						end
					end
					if exitTo3 == 1 then
						if r3:IsA("Decal") then
							continue
						else
							exitTo4 = 1
							break
						end
					end
					break
				else
					break
				end
			end
			if exitTo4 == 1 then
				if r3:IsA("Texture") then
					exitTo6 = nil
					while true do
						r8 = #r12.Detached + 1
						r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
						r3.Parent = nil
						local t60_37_1 = table.pack(d_1())
						if t60_37_1[1] then
							r3 = t60_37_1[3]
							exitTo5 = nil
							while true do
								if r3:IsA("SurfaceAppearance") then
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										continue
									end
									break
								else
									exitTo5 = 1
									break
								end
							end
							if exitTo5 == 1 then
								if r3:IsA("Decal") then
									exitTo6 = 1
									break
								elseif r3:IsA("Texture") then
									continue
								else
									exitTo6 = 2
									break
								end
							end
							break
						else
							break
						end
					end
					if exitTo6 == 1 then
						while true do
							exitTo4 = nil
							while true do
								r8 = #r12.Detached + 1
								r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
								r3.Parent = nil
								local t60_37_1 = table.pack(d_1())
								if t60_37_1[1] then
									r3 = t60_37_1[3]
									exitTo3 = nil
									while true do
										if r3:IsA("SurfaceAppearance") then
											r8 = #r12.Detached + 1
											r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
											r3.Parent = nil
											local t60_37_1 = table.pack(d_1())
											if t60_37_1[1] then
												r3 = t60_37_1[3]
												continue
											end
											break
										else
											exitTo3 = 1
											break
										end
									end
									if exitTo3 == 1 then
										if r3:IsA("Decal") then
											continue
										else
											exitTo4 = 1
											break
										end
									end
									break
								else
									break
								end
							end
							if exitTo4 == 1 then
								if r3:IsA("Texture") then
									exitTo6 = nil
									while true do
										r8 = #r12.Detached + 1
										r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
										r3.Parent = nil
										local t60_37_1 = table.pack(d_1())
										if t60_37_1[1] then
											r3 = t60_37_1[3]
											exitTo5 = nil
											while true do
												if r3:IsA("SurfaceAppearance") then
													r8 = #r12.Detached + 1
													r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
													r3.Parent = nil
													local t60_37_1 = table.pack(d_1())
													if t60_37_1[1] then
														r3 = t60_37_1[3]
														continue
													end
													break
												else
													exitTo5 = 1
													break
												end
											end
											if exitTo5 == 1 then
												if r3:IsA("Decal") then
													exitTo6 = 1
													break
												elseif r3:IsA("Texture") then
													continue
												else
													exitTo6 = 2
													break
												end
											end
											break
										else
											break
										end
									end
									if exitTo6 == 1 then
										continue
									else
										if exitTo6 == 2 then
											exitTo = 1
										end
										break
									end
								else
									exitTo = 1
									break
								end
							end
							break
						end
					elseif exitTo6 == 2 then
						exitTo = 1
					end
				else
					exitTo = 1
				end
			end
		elseif r3:IsA("Texture") then
			exitTo6 = nil
			while true do
				r8 = #r12.Detached + 1
				r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
				r3.Parent = nil
				local t60_37_1 = table.pack(d_1())
				if t60_37_1[1] then
					r3 = t60_37_1[3]
					exitTo5 = nil
					while true do
						if r3:IsA("SurfaceAppearance") then
							r8 = #r12.Detached + 1
							r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
							r3.Parent = nil
							local t60_37_1 = table.pack(d_1())
							if t60_37_1[1] then
								r3 = t60_37_1[3]
								continue
							end
							break
						else
							exitTo5 = 1
							break
						end
					end
					if exitTo5 == 1 then
						if r3:IsA("Decal") then
							exitTo6 = 1
							break
						elseif r3:IsA("Texture") then
							continue
						else
							exitTo6 = 2
							break
						end
					end
					break
				else
					break
				end
			end
			if exitTo6 == 1 then
				while true do
					exitTo4 = nil
					local exitTo7 = nil
					while true do
						r8 = #r12.Detached + 1
						r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
						r3.Parent = nil
						local t60_37_1 = table.pack(d_1())
						if t60_37_1[1] then
							r3 = t60_37_1[3]
							exitTo3 = nil
							while true do
								if r3:IsA("SurfaceAppearance") then
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										continue
									end
									break
								else
									exitTo3 = 1
									break
								end
							end
							if exitTo3 == 1 then
								if not r3:IsA("Decal") then
									exitTo7 = 2
									break
								end
							else
								exitTo7 = 1
								break
							end
						else
							break
						end
					end
					if exitTo7 == 1 then
						if exitTo4 == 1 then
							if r3:IsA("Texture") then
								exitTo6 = nil
								while true do
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										exitTo5 = nil
										while true do
											if r3:IsA("SurfaceAppearance") then
												r8 = #r12.Detached + 1
												r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
												r3.Parent = nil
												local t60_37_1 = table.pack(d_1())
												if t60_37_1[1] then
													r3 = t60_37_1[3]
													continue
												end
												break
											else
												exitTo5 = 1
												break
											end
										end
										if exitTo5 == 1 then
											if r3:IsA("Decal") then
												exitTo6 = 1
												break
											elseif r3:IsA("Texture") then
												continue
											else
												exitTo6 = 2
												break
											end
										end
										break
									else
										break
									end
								end
								if exitTo6 == 1 then
									continue
								else
									if exitTo6 == 2 then
										exitTo = 1
									end
									break
								end
							else
								exitTo = 1
								break
							end
						end
					elseif exitTo7 == 2 then
						exitTo4 = 1
						if exitTo4 == 1 then
							if r3:IsA("Texture") then
								exitTo6 = nil
								while true do
									r8 = #r12.Detached + 1
									r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
									r3.Parent = nil
									local t60_37_1 = table.pack(d_1())
									if t60_37_1[1] then
										r3 = t60_37_1[3]
										exitTo5 = nil
										while true do
											if r3:IsA("SurfaceAppearance") then
												r8 = #r12.Detached + 1
												r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
												r3.Parent = nil
												local t60_37_1 = table.pack(d_1())
												if t60_37_1[1] then
													r3 = t60_37_1[3]
													continue
												end
												break
											else
												exitTo5 = 1
												break
											end
										end
										if exitTo5 == 1 then
											if r3:IsA("Decal") then
												exitTo6 = 1
												break
											elseif r3:IsA("Texture") then
												continue
											else
												exitTo6 = 2
												break
											end
										end
										break
									else
										break
									end
								end
								if exitTo6 == 1 then
									continue
								else
									if exitTo6 == 2 then
										exitTo = 1
									end
									break
								end
							else
								exitTo = 1
								break
							end
						end
					elseif exitTo4 == 1 then
						if r3:IsA("Texture") then
							exitTo6 = nil
							while true do
								r8 = #r12.Detached + 1
								r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
								r3.Parent = nil
								local t60_37_1 = table.pack(d_1())
								if t60_37_1[1] then
									r3 = t60_37_1[3]
									exitTo5 = nil
									while true do
										if r3:IsA("SurfaceAppearance") then
											r8 = #r12.Detached + 1
											r12.Detached[r8] = { Inst = r3, Parent = r3.Parent }
											r3.Parent = nil
											local t60_37_1 = table.pack(d_1())
											if t60_37_1[1] then
												r3 = t60_37_1[3]
												continue
											end
											break
										else
											exitTo5 = 1
											break
										end
									end
									if exitTo5 == 1 then
										if r3:IsA("Decal") then
											exitTo6 = 1
											break
										elseif r3:IsA("Texture") then
											continue
										else
											exitTo6 = 2
											break
										end
									end
									break
								else
									break
								end
							end
							if exitTo6 == 1 then
								continue
							else
								if exitTo6 == 2 then
									exitTo = 1
								end
								break
							end
						else
							exitTo = 1
							break
						end
					end
					break
				end
			elseif exitTo6 == 2 then
				exitTo = 1
			end
		else
			exitTo = 1
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
 end
end

end)()

recovered["function_5463"] = (function()
-- Captured function: function_5463
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, captured_function_12110)
 return function(r21)
local r5 = capture1(r21)
capture2.floor(r21.w - r21.left)
local r2 = 1
local r3 = capture2.random(2, 3)
local r1, r2_1, r3_1
if 1 <= 0 then
	if r2 >= r3 then
		r1 = r2
		while true do
			r2_1 = capture3.delay
			r3_1 = captured_function_12110(nil, 1352712825, 1226058382, 387570673, 2040616624)
			r2_1((r1 - 1) * 0.35, r3_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r1 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r1 = d_1
					continue
				end
				break
			end
		end
	end
elseif r2 <= r3 then
	r1 = r2
	while true do
		r2_1 = capture3.delay
		r3_1 = captured_function_12110(nil, 1352712825, 1226058382, 387570673, 2040616624)
		r2_1((r1 - 1) * 0.35, r3_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r1 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r1 = d_1
				continue
			end
			break
		end
	end
end
capture6(r5, 2.8)
 end
end

end)()

recovered["function_5466"] = (function()
-- Captured function: function_5466
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, captured_function_12120)
 return function(r18)
local r6 = capture1(r18)
r18.gustAt = os.clock()
local r2 = 1
local r3 = capture2.random(8, 11)
local r1, r2_1, r3_1
if 1 <= 0 then
	if r2 >= r3 then
		while true do
			r1 = capture3.delay
			r2_1 = capture2.random() * 0.9
			r3_1 = captured_function_12120(nil, 2658146378, 3089525230, 399323982, 1045589047)
			r1(r2_1, r3_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r2 <= r3 then
	while true do
		r1 = capture3.delay
		r2_1 = capture2.random() * 0.9
		r3_1 = captured_function_12120(nil, 2658146378, 3089525230, 399323982, 1045589047)
		r1(r2_1, r3_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
capture7(r6, 2.6)
 end
end

end)()

recovered["function_5467"] = (function()
-- Captured function: function_5467
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, captured_function_12123)
 return function(r17)
local r7 = capture1(r17)
capture2.floor(r17.w - r17.left)
local r3 = 1
local r4 = capture2.random(3, 4)
local r3_1, r4_1
if 1 <= 0 then
	if r3 >= r4 then
		while true do
			r3_1 = capture3.spawn
			r4_1 = captured_function_12123(nil, 285835514, 718236952, 142698666, 1268534752)
			r3_1(r4_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	while true do
		r3_1 = capture3.spawn
		r4_1 = captured_function_12123(nil, 285835514, 718236952, 142698666, 1268534752)
		r3_1(r4_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
capture9(r7, 7)
 end
end

end)()

recovered["function_5469"] = (function()
-- Captured function: function_5469
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, captured_function_12127)
 return function(r8)
local r10 = capture1(r8)
r8.gustAt = os.clock()
local r6 = capture2.random(10, 14)
local r5 = 1
local r5_1, r6_1
if 1 <= 0 then
	if r5 >= r6 then
		while true do
			r5_1 = capture3.spawn
			r6_1 = captured_function_12127(nil, 1827211605, 3338438843, 1186447854, 1122654132)
			r5_1(r6_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r5 <= r6 then
	while true do
		r5_1 = capture3.spawn
		r6_1 = captured_function_12127(nil, 1827211605, 3338438843, 1186447854, 1122654132)
		r5_1(r6_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
capture6(r10, 3.6)
 end
end

end)()

recovered["function_10052"] = (function()
-- Captured function: function_10052
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, capture12, capture13)
 return function(r24)
local r3 = capture1
local r4 = capture2
local r5 = capture3
local r2 = Color3.fromHSV
local r8, r7
repeat
	r2 = r2(r3, r4, r5)
	capture4.Value = r2
	capture5.BackgroundColor3 = r2
	capture6.BackgroundColor3 = r2
	r8 = capture7
	r7 = Color3.fromHSV
	r4 = capture1
	r3 = not r2
until not r3
r8.BackgroundColor3 = r7(r4, 1, 1)
capture8.Position = UDim2.fromScale(capture2, 1 - capture3)
local r7_1 = capture9
local r6 = UDim2.fromScale
if capture13 + 284238677 ~= 531419481 then
	capture13 = bit32.bxor(capture13, 3160485261)
end
r7_1.Position = r6(0.5, capture1)
capture10.Text = capture11(r2)
if r24 then
	return
end
capture12(capture4, r2)
 end
end

end)()

recovered["function_10217"] = (function()
-- Captured function: function_10217
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, captured_function_13944, captured_function_13945)
 return function()
local state = 1
local r7, r3, r2_1, r2_2, r2_3, r4_1, r5_1, r4_2
while true do
	if state == 1 then
		if not capture1() then
			state = 32
		else
			state = 2
		end
	elseif state == 2 then
		if WebSocket then
			state = 3
		else
			state = 4
		end
	elseif state == 3 then
		r7 = WebSocket.connect
		if r7 then
			state = 9
		else
			state = 4
		end
	elseif state == 4 then
		if syn then
			state = 5
		else
			state = 7
		end
	elseif state == 5 then
		if syn.websocket then
			state = 6
		else
			state = 7
		end
	elseif state == 6 then
		r7 = syn.websocket.connect
		if r7 then
			state = 9
		else
			state = 7
		end
	elseif state == 7 then
		r7 = websocket
		if r7 then
			state = 8
		else
			state = 9
		end
	elseif state == 8 then
		r7 = websocket.connect
		if r7 then
			state = 11
		else
			state = 10
		end
	elseif state == 9 then
		if r7 then
			state = 11
		else
			state = 10
		end
	elseif state == 10 then
		return false
	elseif state == 11 then
		local r2
		r2, r3 = capture2(r7, capture3 .. capture4)
		if r2 then
			state = 13
		else
			state = 12
		end
	elseif state == 12 then
		return false
	elseif state == 13 then
		if not r3 then
			state = 31
		else
			state = 14
		end
	elseif state == 14 then
		capture5.socket = r3
		capture5.lastInbound = os.clock()
		r2_1 = r3.OnMessage
		if r2_1 then
			state = 16
		else
			state = 15
		end
	elseif state == 15 then
		r2_1 = r3.onMessage
		if r2_1 then
			state = 16
		else
			state = 17
		end
	elseif state == 16 then
		r2_1:Connect(capture6)
		state = 17
	elseif state == 17 then
		r2_2 = r3.OnClose
		if r2_2 then
			state = 18
		else
			state = 20
		end
	elseif state == 18 then
		local r5 = r2_2
		local r4 = r2_2.Connect
		local r7_1 = captured_function_13944(nil, 3527744144, 486391709, 3412698217, 2050339389)
		r4(r5, r7_1)
		state = 19
	elseif state == 19 then
		r2_3 = 530290456
		r4_1 = captured_function_13945(nil, 3768955383, 238949238, 1670950518, 89477099)
		r5_1 = 4212806067
		if 1866455814 ~= 453642490 then
			state = 21
		else
			state = 20
		end
	elseif state == 20 then
		r2_2 = r3.onClose
		if r2_2 then
			state = 18
		else
			state = 19
		end
	elseif state == 21 then
		local r5_2 = bit32.bxor(r5_1, 487860032)
		bit32.bxor(r2_3, r5_2)
		if capture2(r4_1) then
			state = 23
		else
			state = 22
		end
	elseif state == 22 then
		capture9("send failed")
		return false
	elseif state == 23 then
		r4_2 = os.clock() + capture10
		state = 24
	elseif state == 24 then
		if not (os.clock() < r4_2) then
			state = 30
		else
			state = 25
		end
	elseif state == 25 then
		if capture5.connected then
			state = 29
		else
			state = 26
		end
	elseif state == 26 then
		if capture5.socket then
			state = 28
		else
			state = 27
		end
	elseif state == 27 then
		return false
	elseif state == 28 then
		capture11.wait(0.1)
		state = 24
	elseif state == 29 then
		return true
	elseif state == 30 then
		capture9("auth timeout")
		return false
	elseif state == 31 then
		return false
	elseif state == 32 then
		return false
	end
end
 end
end

end)()

recovered["function_10224"] = (function()
-- Captured function: function_10224
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r33, r34)
if r33 ~= nil then
	return capture1(r33):gsub("[^ -~]", ""):sub(1, r34 or 64)
end
return nil
 end
end

end)()

recovered["function_10236"] = (function()
-- Captured function: function_10236
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r24)
if game.PlaceId == 82866880824588 then
	local r22 = capture1:GetPlayerFromCharacter(r24)
	if r22 then
		if capture2.Team then
			if r22.Team then
				if r22.Team ~= capture2.Team then
					return false
				end
			end
		end
	end
end
if capture3(r24) then
	return false
end
if capture4(r24) then
	return false
end
return true
 end
end

end)()

recovered["function_10247"] = (function()
-- Captured function: function_10247
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2 = capture1 ~= nil
if r2 then
	return os.clock() < capture2
end
return r2
 end
end

end)()

recovered["function_10248"] = (function()
-- Captured function: function_10248
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
capture1.Enabled = false
 end
end

end)()

recovered["function_10403"] = (function()
-- Captured function: function_10403
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function()
capture1.Text = capture2()
local r2 = capture1
local r4_1
if capture2() ~= "None" then
	r4_1 = capture3.Text
else
	r4_1 = capture3.Dim or capture3.Text
end
r2.TextColor3 = r4_1
local t58_20_1 = table.pack(d_1())
if t58_20_1[1] then
	local r2_1 = t58_20_1[2]
	local r3 = t58_20_1[3]
	while true do
		local r11 = capture5(r2_1)
		local r7 = r3.Label
		local r8 = {}
		local r9
		if r11 then
			r9 = capture3.AccentLift or capture3.Muted
		else
			r9 = capture3.Muted
		end
		r8.TextColor3 = r9
		capture6(r7, r8, capture7.Quick)
		local r7_1 = r3.Dot
		local r8_1 = {}
		local r9_1
		if r11 then
			r9_1 = 0
		else
			r9_1 = 1
		end
		r8_1.BackgroundTransparency = r9_1
		capture6(r7_1, r8_1, capture7.Quick)
		local r7_2 = r3.Tick
		local r8_2 = {}
		local r6 = r3.TickKey
		local r11_1
		if r11 then
			r11_1 = 0
		else
			r11_1 = 1
		end
		r8_2[r6] = r11_1
		capture6(r7_2, r8_2, capture7.Quick)
		local t35_55_1 = table.pack(d_1())
		if t35_55_1[1] then
			r2_1 = t35_55_1[2]
			r3 = t35_55_1[3]
			continue
		end
		break
	end
end
 end
end

end)()

recovered["function_10533"] = (function()
-- Captured function: function_10533
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r36)
local r5 = r36.w - r36.left - 70
local r7 = r36.h - 90
return r36.left + 20 + capture1.random() * r5, 40 + capture1.random() * r7
 end
end

end)()

recovered["function_10534"] = (function()
-- Captured function: function_10534
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r35, r36, r37, r38)
r37.BackgroundTransparency = 1
r37.Text = r36
r37.TextSize = r38 or capture1.clamp(capture1.floor(r37.Size.Y.Offset * 0.85), 8, 100)
r37.Font = Enum.Font.GothamBold
r37.Active = false
r37.BorderSizePixel = 0
r37.Parent = r35
return capture2("TextLabel", r37)
 end
end

end)()

recovered["function_10629"] = (function()
-- Captured function: function_10629
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(arg1, arg2, r15)
local r2 = { Instance = arg2 }
if capture4 == 305325661 then
	capture4 = bit32.bxor(capture4, 3236072989)
end
r2.Text = string.lower(r15 or "")
capture1.insert(capture2.Rows, r2)
capture1.insert(capture3.Rows, r2)
return r2
 end
end

end)()

recovered["function_10635"] = (function()
-- Captured function: function_10635
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, capture12, captured_function_11541)
 return function(arg1, arg2)
local r9 = arg2 or {}
local r29 = capture1(capture2, 48)
local r8 = {
	BackgroundColor3 = capture4.Control,
	BorderSizePixel = 0,
	Size = UDim2.new(1, -capture5.Inset * 2, 0, 34),
}
local r5 = UDim2.fromOffset
local r2 = capture5
if 2261311413 ~= 309952634 then
	r8.Position = r5(r2.Inset, 7)
end
r8.Font = Enum.Font.GothamMedium
r8.TextSize = 12
r8.TextColor3 = capture4.Text
r8.Text = r9.Text or "Button"
r8.AutoButtonColor = false
r8.Parent = r29
local r3_1 = capture4.Border
local r3_2 = capture3("TextButton", r8, { capture6(10), capture7(r3_1, 0.5) })
capture8(r3_2, r3_2)
local r31_1 = capture9
local r30 = capture9.Connect
local r32 = r3_2.MouseButton1Click
local r33 = captured_function_11541(nil, 842471354, 3316944838, 859861577, 3453293981)
r30(r31_1, r32, r33)
capture2:Register(r29, r9.Text)
return r3_2
 end
end

end)()

recovered["function_10940"] = (function()
-- Captured function: function_10940
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function(r26)
local r4 = {}
local r3
if r26 then
	r3 = 0
else
	r3 = 1
end
r4.BackgroundTransparency = r3
capture1(capture2, r4, capture3.Quick)
if capture7 == 66153680 then
	capture7 = bit32.bxor(capture7, 3228400781)
end
local r4_1 = {}
local r2 = capture5
local r3_1
if r26 then
	r3_1 = capture6.Text or capture6.Muted
else
	r3_1 = capture6.Muted
	r4_1[r2] = r3_1
	capture1(capture4, r4_1, capture3.Quick)
	return
end
r4_1[r2] = r3_1
capture1(capture4, r4_1, capture3.Quick)
 end
end

end)()

recovered["function_10942"] = (function()
-- Captured function: function_10942
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8)
 return function(r8)
local r5 = capture1
if bit32.bxor(capture8, 172606042) == 100220191 then
	capture8 = bit32.bxor(capture8, 414794657)
end
if r5.ActiveTab ~= capture2 then
	local r12 = {}
	local r6
	if r8 then
		r6 = 0.45
	else
		r6 = 1
	end
	r12.BackgroundTransparency = r6
	capture3(capture4, r12, capture5.Quick)
	local r7 = {}
	local r6_1
	if r8 then
		r6_1 = capture7.Text or capture7.Muted
	else
		r6_1 = capture7.Muted
		r7.TextColor3 = r6_1
		capture3(capture6, r7, capture5.Quick)
		return
	end
	r7.TextColor3 = r6_1
	capture3(capture6, r7, capture5.Quick)
	return
end
 end
end

end)()

recovered["function_10949"] = (function()
-- Captured function: function_10949
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r36)
local r3 = capture2.UIStroke
local r4 = {}
local r5
if capture4 ~= 190342709 then
	if r36 then
		r5 = 0.45
	else
		r5 = 0.7
	end
else
	capture4 = bit32.bxor(capture4, 1355911695)
	if r36 then
		r5 = 0.45
		r4.Transparency = r5
		capture1(r3, r4, capture3.Quick)
		return
	else
		r5 = 0.7
		r4.Transparency = r5
		capture1(r3, r4, capture3.Quick)
		return
	end
end
r4.Transparency = r5
capture1(r3, r4, capture3.Quick)
 end
end

end)()

recovered["function_10950"] = (function()
-- Captured function: function_10950
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(r9)
local r13 = {}
local r4
if r9 then
	r4 = 0
else
	r4 = 1
end
r13.BackgroundTransparency = r4
if capture6 + 140299607 ~= 236977619 then
	capture6 = bit32.bxor(capture6, 1281456199)
end
local r11 = UDim2.new
local r7
if r9 then
	r7 = capture3.max(capture4.AbsoluteSize.Y - 16, 18) or 0
else
	r7 = 0
	r13.Size = r11(0, 2, 0, r7)
	capture1(capture2, r13, capture5.Smooth)
	return
end
r13.Size = r11(0, 2, 0, r7)
capture1(capture2, r13, capture5.Smooth)
 end
end

end)()

recovered["function_10951"] = (function()
-- Captured function: function_10951
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function(r23)
local r4 = {}
local r3
if r23 then
	r3 = 0.55
else
	r3 = 1
end
r4.BackgroundTransparency = r3
capture1(capture2, r4, capture3.Quick)
local r4_1 = {}
local r3_2
if r23 then
	if capture5.Value then
		r3_2 = capture6.Control
	else
		r3_2 = capture6.Track or capture6.Control
	end
else
	r3_2 = capture6.Control
end
r4_1.BackgroundColor3 = r3_2
local r2 = capture3
if capture7 + 65851903 == 527042266 then
	capture7 = bit32.bxor(capture7, 1368606479)
end
capture1(capture4, r4_1, r2.Quick)
 end
end

end)()

recovered["function_10955"] = (function()
-- Captured function: function_10955
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(arg1)
local r4 = {}
local r5
if arg1 then
	r5 = capture3 or capture4.Track or upv5 or capture4.Control
else
	r5 = upv5 or capture4.Control
end
r4.BackgroundColor3 = r5
capture1(capture2, r4, upv6.Quick)
 end
end

end)()

recovered["function_10956"] = (function()
-- Captured function: function_10956
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(arg1)
local r4 = {}
local r3
if arg1 then
	r3 = 0.45
else
	r3 = 1
end
r4.BackgroundTransparency = r3
capture1(capture2, r4, capture3.Quick)
 end
end

end)()

recovered["function_11582"] = (function()
-- Captured function: function_11582
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r23, r24)
return capture1("Frame", {
	BackgroundColor3 = capture2.Divider,
	BorderSizePixel = 0,
	Size = UDim2.new(1, -capture3.Inset * 2, 0, 1),
	Position = UDim2.new(0, capture3.Inset, 1, -1),
	LayoutOrder = r24 or 0,
	Parent = r23,
})
 end
end

end)()

recovered["function_11617"] = (function()
-- Captured function: function_11617
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
local r1 = 10 ^ capture1
return capture2.floor(arg1 * r1 + 0.5) / r1
 end
end

end)()

recovered["function_11618"] = (function()
-- Captured function: function_11618
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(r22, r23)
if capture1 then
	capture1:Cancel()
	capture2:Cancel()
	capture1 = nil
	capture2 = nil
	if r23 then
		capture1 = capture3(capture4, { Size = UDim2.fromScale(r22, 1) }, capture5.Smooth)
		capture2 = capture3(capture6, { Position = UDim2.fromScale(r22, 0.5) }, capture5.Smooth)
		return
	end
elseif r23 then
	capture1 = capture3(capture4, { Size = UDim2.fromScale(r22, 1) }, capture5.Smooth)
	capture2 = capture3(capture6, { Position = UDim2.fromScale(r22, 0.5) }, capture5.Smooth)
	return
end
capture4.Size = UDim2.fromScale(r22, 1)
capture6.Position = UDim2.fromScale(r22, 0.5)
 end
end

end)()

recovered["function_12107"] = (function()
-- Captured function: function_12107
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, captured_function_15133)
 return function(arg1, r34)
local r2 = capture1.delay
local r3 = captured_function_15133(nil, 2754867555, 3808480099, 4221791533, 1971808138)
r2(r34, r3)
 end
end

end)()

recovered["function_12116"] = (function()
-- Captured function: function_12116
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r4, r5, r6, r7, r8, r9)
local r15 = capture1.remove(capture2)
if not r15 then
	r15 = capture3.new("Frame")
	r15.BorderSizePixel = 0
	r15.AnchorPoint = capture4
	local r11 = capture3.new("UICorner")
	r11.CornerRadius = nil
	r11.Parent = r15
end
r15.BackgroundColor3 = r5
r15.BackgroundTransparency = r8 or 0
r15.Size = UDim2.fromOffset(r6, r6)
r15.Position = r7
r15.ZIndex = r9 or 999999
r15.Parent = r4
return r15
 end
end

end)()

recovered["function_12117"] = (function()
-- Captured function: function_12117
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, captured_function_15140)
 return function(arg1, arg2, r24)
capture1(arg1, arg2, TweenInfo.new(r24, capture2, Enum.EasingDirection.Out))
local r1 = capture3.delay
local r3 = captured_function_15140(nil, 1856567897, 3390302028, 766453266, 2554405406)
r1(r24 + 0.05, r3)
 end
end

end)()

recovered["function_13946"] = (function()
-- Captured function: function_13946
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
if capture1 then
	local r2, r3 = capture2(capture1, { Method = "GET", Url = capture3 .. capture4 })
	if r2 then
		if type(r3) ~= "table" then
			return nil
		end
		if r3.StatusCode ~= 200 then
			return nil
		end
		local r2_2 = capture5(r3.Body or "")
		if r2_2 then
			local r2_3 = r2_2.challengeId
			if r2_3 then
				return r2_3
			end
		end
		return nil
	end
	return nil
end
return nil
 end
end

end)()

recovered["function_13948"] = (function()
-- Captured function: function_13948
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r25)
local r1, r2 = capture1(capture2, r25)
if r1 then
	if r2 then
		return r2
	end
end
return nil
 end
end

end)()

recovered["function_13949"] = (function()
-- Captured function: function_13949
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r4)
local r10 = capture1.create(r4)
local r3 = 1
local r12, r5
if 1 <= 0 then
	if r3 >= r4 then
		r12 = r3
		while true do
			r5 = capture2.random(0, 15)
			r10[r12] = ("0123456789abcdef"):sub(r5 + 1, r5 + 1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r12 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r12 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	r12 = r3
	while true do
		r5 = capture2.random(0, 15)
		r10[r12] = ("0123456789abcdef"):sub(r5 + 1, r5 + 1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r12 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r12 = d_1
				continue
			end
			break
		end
	end
end
return capture1.concat(r10)
 end
end

end)()

recovered["function_13953"] = (function()
-- Captured function: function_13953
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
local r4 = capture5.startedAt
return {
	serverPlayers = #capture1:GetPlayers(),
	pingMs = capture2(),
	fps = capture3.clamp(capture4(capture5.fps + 0.5), 0, 1000),
	uptime = capture4(os.clock() - r4),
}
 end
end

end)()

recovered["function_13956"] = (function()
-- Captured function: function_13956
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
local r6 = capture3.offset
return capture1(capture2() + r6)
 end
end

end)()

recovered["function_13958"] = (function()
-- Captured function: function_13958
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1, arg2, arg3, r40)
return capture1.concat({ capture2.sessionId, arg1, arg2, arg3, r40 }, "|")
 end
end

end)()

recovered["function_13966"] = (function()
-- Captured function: function_13966
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r28)
if r28 then
	local r26 = capture1:GetPlayerFromCharacter(r28)
	if r26 then
		if capture2[r26] then
			local r1 = capture2[r26].idle
			if r1 then
				return r1
			end
		end
	end
	return false
end
return false
 end
end

end)()

recovered["function_13983"] = (function()
-- Captured function: function_13983
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r14)
if capture1 then
	local r2 = capture3.find
	local r13 = capture2.Value
	if bit32.bxor(capture4, 17681290) == 57577308 then
		capture4 = bit32.bxor(capture4, 803164225)
	end
	return r2(r13, r14) ~= nil
end
return capture2.Value == r14
 end
end

end)()

recovered["function_15229"] = (function()
-- Captured function: function_15229
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r32)
local r2, r3 = capture1(capture2, r32)
if r2 then
	if type(r3) ~= "table" then
		return nil
	end
	return r3
end
return nil
 end
end

end)()

recovered["function_15231"] = (function()
-- Captured function: function_15231
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1.now().UnixTimestampMillis
 end
end

end)()

recovered["function_15232"] = (function()
-- Captured function: function_15232
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function()
if 1270413256 ~= 1270413256 then
end
local r2, r3 = capture1(capture2)
local r11 = {
	placeId = capture3(game.PlaceId),
	jobId = capture4(game.JobId, 64),
	serverCapacity = capture5.MaxPlayers,
}
local r5
if capture6 then
	r5 = capture3(capture6.UserId)
	if not r5 then
		return (nil)(nil)
	end
else
	r5 = nil
end
r11.robloxUserId = r5
local r4
if capture6 then
	r4 = capture4(capture6.Name, 32) or nil
else
	r4 = nil
end
r11.robloxUsername = r4
local r2_1
if capture6 then
	local r4_1 = capture6
	if 788217528 ~= 788217528 then
	end
	local r5_1 = r4_1.DisplayName
	if 1511961204 == 191266792 then
		r2_1 = capture4(r3, 32) or nil
	else
		local r4_2 = capture4(r5_1, 32)
		local r5_2 = 3918796474
		if r5_2 % 4294967296 ~= r5_2 % 4294967296 then
		end
		if r4_2 then
			r11.robloxDisplayName = r4_2
			if r2 then
				r2_1 = capture4(r3, 32)
				if not r2_1 then
					r2_1 = nil
					r11.executor = r2_1
					r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
					return r11
				end
			else
				r2_1 = nil
				r11.executor = r2_1
				r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
				return r11
			end
		else
			r4_2 = nil
			r11.robloxDisplayName = r4_2
			if r2 then
				r2_1 = capture4(r3, 32)
				if not r2_1 then
					r2_1 = nil
					r11.executor = r2_1
					r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
					return r11
				end
			else
				r2_1 = nil
				r11.executor = r2_1
				r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
				return r11
			end
		end
	end
else
	r11.robloxDisplayName = nil
	if r2 then
		r2_1 = capture4(r3, 32)
		if not r2_1 then
			r2_1 = nil
			r11.executor = r2_1
			r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
			return r11
		end
	else
		r2_1 = nil
		r11.executor = r2_1
		r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
		return r11
	end
end
r11.executor = r2_1
r11.scriptVersion = capture4(capture7().SNC_ScriptVersion, 24)
return r11
 end
end

end)()

recovered["function_15233"] = (function()
-- Captured function: function_15233
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function(r5)
if type(r5.sig) ~= "string" then
	return false
end
if capture1.secret then
	local r13 = capture1.secret
	local r8 = capture4(r5.type)
	local r9 = r5.seq or 0
	local r10 = r5.sentAt or r5.timestamp or 0
	local r11 = r5.body or ""
	local r3 = r5.sig
	return capture5(capture2(r13, capture3(r8, r9, r10, r11)), r3)
end
return false
 end
end

end)()

recovered["function_15236"] = (function()
-- Captured function: function_15236
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, captured_function_15472, captured_function_15473)
 return function(r31)
local r6 = {}
captured_function_15473(nil, 315121190, 3606719297, 2457086926, 2561979950)
local r1 = captured_function_15472(nil, 1389065300, 303243142, 3978413264, 4021745580)(r31, 203917118)
if r1 == 130817972 then
	bit32.bxor(r1, 555761883)
end
return table.concat(r6)
 end
end

end)()

recovered["function_15239"] = (function()
-- Captured function: function_15239
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, captured_function_15476)
 return function()
local r8 = captured_function_15476(nil, 1331713480, 1979246267, 4237231356, 1314455533)
local r5, r6 = capture1(r8)
if r5 then
	if type(r6) ~= "number" then
		return -1
	end
	if r6 ~= r6 then
		return -1
	end
	return capture3.clamp(capture4(r6 + 0.5), 0, 10000)
end
return -1
 end
end

end)()

recovered["function_15240"] = (function()
-- Captured function: function_15240
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r8)
return r8 - r8 % 1
 end
end

end)()

recovered["function_15244"] = (function()
-- Captured function: function_15244
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r2)
local r12 = capture1.create(32)
local r5 = 1
local r6 = capture2.min(64, #r2)
local r8, r14, r5_1
if 2 <= 0 then
	if r5 >= r6 then
		r8 = r5
		while true do
			r14 = #r12 + 1
			r5_1 = capture4(r2:sub(r8, r8 + 1), 16) or 0
			r12[r14] = capture3(r5_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r8 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r8 = d_1
				continue
			end
			break
		end
	end
elseif r5 <= r6 then
	r8 = r5
	while true do
		r14 = #r12 + 1
		r5_1 = capture4(r2:sub(r8, r8 + 1), 16)
		if r5_1 then
			r12[r14] = capture3(r5_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r8 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r8 = d_1
				continue
			end
			break
		else
			r12[r14] = capture3(0)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r8 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r8 = d_1
				continue
			end
			break
		end
	end
end
return capture1.concat(r12)
 end
end

end)()

recovered["function_15245"] = (function()
-- Captured function: function_15245
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r2)
local r4 = #r2
local r3 = 1
local r10 = 0
local r5
if 1 <= 0 then
	if r3 >= r4 then
		r5 = r3
		while true do
			r10 = (r10 * 31 + capture1(r2, r5)) % 4294967296
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r5 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r5 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	r5 = r3
	while true do
		r10 = (r10 * 31 + capture1(r2, r5)) % 4294967296
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r5 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r5 = d_1
				continue
			end
			break
		end
	end
end
local r5_1 = capture2.create(8)
local r2_1
if x_1 <= 0 then
	if d_1 >= S_1 then
		r2_1 = d_1
		while true do
			r5_1[r2_1] = capture4(r10 * capture3[r2_1] % 4294967296)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r2_1 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r2_1 = d_1
					continue
				end
				break
			end
		end
	end
elseif d_1 <= S_1 then
	r2_1 = d_1
	while true do
		r5_1[r2_1] = capture4(r10 * capture3[r2_1] % 4294967296)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r2_1 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r2_1 = d_1
				continue
			end
			break
		end
	end
end
return capture2.concat(r5_1)
 end
end

end)()

recovered["function_15246"] = (function()
-- Captured function: function_15246
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r18, r19, r20)
if r19 then
	r20 = r20 or r19
else
	r19 = 1
	r20 = r20 or r19
end
local r1 = #r18
local r2, r20_1, r21, r3
if not (r19 < 0) then
	if not (r20 < 0) then
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			else
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	else
		r20 = r1 + r20 + 1
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
						return table.unpack(r2)
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	end
else
	r19 = r1 + r19 + 1
	if not (r20 < 0) then
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
						return table.unpack(r2)
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	else
		r20 = r1 + r20 + 1
		if not (r19 < 1) then
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
						return table.unpack(r2)
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r3 = #r2 + 1
						r2[r3] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		else
			r19 = 1
			if not (r1 < r20) then
				r1 = r20
				if not (r1 < r19) then
					r2 = {}
					r20_1 = r1
					if 1 <= 0 then
						if r19 >= r20_1 then
							r21 = r19
							while true do
								r3 = #r2 + 1
								r2[r3] = capture1[r18:sub(r21, r21)]
								if x_1 <= 0 then
									if d_1 >= S_1 then
										r21 = d_1
										continue
									end
									break
								else
									if d_1 <= S_1 then
										r21 = d_1
										continue
									end
									break
								end
							end
							return table.unpack(r2)
						end
					elseif r19 <= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
					return table.unpack(r2)
				end
				return
			end
			if not (r1 < r19) then
				r2 = {}
				r20_1 = r1
				if 1 <= 0 then
					if r19 >= r20_1 then
						r21 = r19
						while true do
							r3 = #r2 + 1
							r2[r3] = capture1[r18:sub(r21, r21)]
							if x_1 <= 0 then
								if d_1 >= S_1 then
									r21 = d_1
									continue
								end
								break
							else
								if d_1 <= S_1 then
									r21 = d_1
									continue
								end
								break
							end
						end
					end
				elseif r19 <= r20_1 then
					r21 = r19
					while true do
						r2[#r2 + 1] = capture1[r18:sub(r21, r21)]
						if x_1 <= 0 then
							if d_1 >= S_1 then
								r21 = d_1
								continue
							end
							break
						else
							if d_1 <= S_1 then
								r21 = d_1
								continue
							end
							break
						end
					end
				end
				return table.unpack(r2)
			end
		end
	end
end
 end
end

end)()

recovered["function_15247"] = (function()
-- Captured function: function_15247
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(...)
local r11 = { ... }
local r7 = {}
local r4 = #r11
local r3 = 1
if 1 <= 0 then
	if r3 >= r4 then
		while true do
			local r4_1 = #r7 + 1
			r7[r4_1] = capture1[r11[r3]]
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r3 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r3 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	while true do
		r7[#r7 + 1] = capture1[r11[r3]]
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r3 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r3 = d_1
				continue
			end
			break
		end
	end
end
return table.concat(r7)
 end
end

end)()

recovered["function_15248"] = (function()
-- Captured function: function_15248
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r37, r38)
local r5 = 1
local r6 = 0
while true do
	if r37 % 2 ~= r38 % 2 then
		r6 += r5
	end
	r37 = capture1(r37 / 2)
	r38 = capture1(r38 / 2)
	r5 *= 2
	if x_1 <= 0 then
		if d_1 >= S_1 then
			continue
		end
	elseif d_1 <= S_1 then
		continue
	end
	break
end
return r6
 end
end

end)()

recovered["function_15460"] = (function()
-- Captured function: function_15460
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(captured_function_15572, captured_function_15574, captured_function_15575, captured_function_15576, captured_function_15577, captured_function_15578)
 return function(r5)
if not r5 then
	return nil
end
local r1 = 1
local r2 = captured_function_15575(nil, 1848400042, 1056046405, 1557615706, 3347495092)
local r4 = captured_function_15577(nil, 3050230770, 3756961183, 1536356481, 2986583710)
parse_string = captured_function_15578(nil, 4192337327, 4042592818, 691382311, 4192538333)
parse_number = captured_function_15576(nil, 589052949, 2815589681, 3560998692, 3155788015)
parse_array = captured_function_15574(nil, 784995607, 394178750, 3612309436, 212344744)
parse_object = captured_function_15572(nil, 568178309, 330199424, 59007792, 1909598882)
local r7 = r4()
r2()
if not (r1 <= #r5) then
	return r7
end
error("Unexpected trailing characters at position " .. tostring(r1))
return r7
 end
end

end)()

recovered["function_15466"] = (function()
-- Captured function: function_15466
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r9, r10)
if type(r9) ~= "string" then
	return false
end
if type(r10) ~= "string" then
	return false
end
if #r9 ~= #r10 then
	return false
end
local r4 = #r9
local r3 = 1
local r7 = 0
local r14
if 1 <= 0 then
	if r3 >= r4 then
		r14 = r3
		while true do
			if capture1(r9, r14) ~= capture1(r10, r14) then
				r7 += 1
				if x_1 <= 0 then
					if d_1 >= S_1 then
						r14 = d_1
						continue
					end
				elseif d_1 <= S_1 then
					r14 = d_1
					continue
				end
				break
			else
				if x_1 <= 0 then
					if d_1 >= S_1 then
						r14 = d_1
						continue
					end
				elseif d_1 <= S_1 then
					r14 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	r14 = r3
	while true do
		if capture1(r9, r14) ~= capture1(r10, r14) then
			r7 += 1
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r14 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r14 = d_1
				continue
			end
			break
		else
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r14 = d_1
					continue
				end
			elseif d_1 <= S_1 then
				r14 = d_1
				continue
			end
			break
		end
	end
end
return r7 == 0
 end
end

end)()

recovered["function_15468"] = (function()
-- Captured function: function_15468
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, captured_function_15584)
 return function(r25)
if not capture1 then
	capture1 = captured_function_15584(780332709, 4036643730, 4059398698, nil, 3367814979)
end
local r1 = 1
local r6 = ""
local r2 = r25
if 1 <= 0 then
	if r1 >= r2 then
		while true do
			r6 ..= capture3[capture1(65, 122)]
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r1 <= r2 then
	while true do
		r6 ..= capture3[capture1(65, 122)]
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
return r6
 end
end

end)()

recovered["function_15481"] = (function()
-- Captured function: function_15481
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r13)
local r6 = capture1.create(4)
local r2 = 0
while true do
	local r3 = capture2(r13 / 256 ^ r2) % 256
	local r4 = capture2(r3 / 16)
	local r3_1 = r3 % 16
	r6[r2 + 1] = ("0123456789abcdef"):sub(r4 + 1, r4 + 1) .. ("0123456789abcdef"):sub(r3_1 + 1, r3_1 + 1)
	if x_1 <= 0 then
		if d_1 >= S_1 then
			r2 = d_1
			continue
		end
		break
	else
		if d_1 <= S_1 then
			r2 = d_1
			continue
		end
		break
	end
end
return capture1.concat(r6)
 end
end

end)()

recovered["function_1772"] = (function()
-- Captured function: function_1772
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r9)
if r9 then
	if r9 ~= "" then
		capture1.tagNum = r9
		return
	end
	return
end
 end
end

end)()

return recovered
