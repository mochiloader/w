-- Captured function: QB Aimbot/High Arc Throws
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r22)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.loft = r22
		return
	end
end
 end
end
