-- Captured function: Physics/Click Tackle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.ClickTackle = arg1
 end
end
