-- Captured function: function_3662
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1
 end
end
