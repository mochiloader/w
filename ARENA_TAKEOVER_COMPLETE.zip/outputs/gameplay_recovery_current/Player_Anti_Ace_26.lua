-- Captured function: Player/Anti Ace
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Enabled = arg1
 end
end
