-- Captured function: function_13946
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function()
if capture1 then
	local r2, r3 = capture2(capture1, { Method = "GET", Url = capture3 .. capture4 })
	if r2 then
		if type(r3) ~= "table" then
			return nil
		end
		if r3.StatusCode ~= 200 then
			return nil
		end
		local r2_2 = capture5(r3.Body or "")
		if r2_2 then
			local r2_3 = r2_2.challengeId
			if r2_3 then
				return r2_3
			end
		end
		return nil
	end
	return nil
end
return nil
 end
end
