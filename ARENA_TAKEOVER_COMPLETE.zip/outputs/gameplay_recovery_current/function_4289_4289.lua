-- Captured function: function_4289
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r15, r16, r17, r18)
return capture1("UIPadding", {
	PaddingTop = UDim.new(0, r15),
	PaddingRight = UDim.new(0, r16 or r15),
	PaddingBottom = UDim.new(0, r17 or r15),
	PaddingLeft = UDim.new(0, r18 or r16 or r15),
})
 end
end
