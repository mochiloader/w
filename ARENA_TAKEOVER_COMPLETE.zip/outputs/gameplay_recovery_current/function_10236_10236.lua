-- Captured function: function_10236
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r24)
if game.PlaceId == 82866880824588 then
	local r22 = capture1:GetPlayerFromCharacter(r24)
	if r22 then
		if capture2.Team then
			if r22.Team then
				if r22.Team ~= capture2.Team then
					return false
				end
			end
		end
	end
end
if capture3(r24) then
	return false
end
if capture4(r24) then
	return false
end
return true
 end
end
