-- Captured function: function_2392
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaAdjustAngle then
	_G.FF3QbaAdjustAngle(-5)
	return
end
 end
end
