-- Captured function: function_4182
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
local r13 = ColorSequence.new
local r11 = {}
local r5 = ColorSequenceKeypoint.new(0, capture1.AccentDeep)
local r6 = ColorSequenceKeypoint.new(0.55, capture1.Accent)
local r4 = ColorSequenceKeypoint.new
local r9 = capture1.AccentLift
r11[1] = r5
r11[2] = r6
do
	local values = table.pack(r4(1, r9))
	table.move(values, 1, values.n, 3, r11)
end
return r13(r11)
 end
end
