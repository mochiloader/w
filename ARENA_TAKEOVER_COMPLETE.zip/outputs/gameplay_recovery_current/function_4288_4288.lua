-- Captured function: function_4288
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r19, r20)
return capture1("UIListLayout", {
	Padding = UDim.new(0, r19),
	FillDirection = r20 or Enum.FillDirection.Vertical,
	SortOrder = Enum.SortOrder.LayoutOrder,
})
 end
end
