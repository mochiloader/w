-- Captured function: Visuals/Replay FPS
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Visuals.ReplayFPS = capture2.clamp(arg1, 30, 360)
 end
end
