-- Captured function: function_3657
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture2 = capture1.clamp(capture2 + arg1, 5, 85)
if _G.FF3HUD then
	return
end
 end
end
