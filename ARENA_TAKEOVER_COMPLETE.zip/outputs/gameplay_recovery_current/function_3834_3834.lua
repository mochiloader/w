-- Captured function: function_3834
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(r19, r20, r21)
local r4 = capture1.new(r19)
local r5 = r20.Parent
r20.Parent = nil
for r1, r2 in r20, nil, nil do
	local exitTo = nil
	while true do
		r4[r1] = r2
		if capture2(r2) ~= "Color3" then
			exitTo = 1
			break
		else
			local r7 = capture3[capture4(r2)]
			if r7 then
				capture5.insert(capture6, { Instance = r4, Property = r1, Role = r7 })
				local t24_37_1 = table.pack(d_1())
				if t24_37_1[1] then
					r1 = t24_37_1[2]
					r2 = t24_37_1[3]
					continue
				end
			else
				exitTo = 1
				break
			end
			break
		end
	end
	if exitTo == 1 then
		continue
	end
	break
end
if r21 then
	local t34_46_1 = table.pack(d_1())
	if t34_46_1[1] then
		local r2_1 = t34_46_1[3]
		while true do
			r2_1.Parent = r4
			local t30_48_1 = table.pack(d_1())
			if t30_48_1[1] then
				r2_1 = t30_48_1[3]
			else
				break
			end
		end
	end
end
r4.Parent = r5
return r4
 end
end
