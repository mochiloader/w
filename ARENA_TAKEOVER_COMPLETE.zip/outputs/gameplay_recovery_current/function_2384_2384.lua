-- Captured function: function_2384
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2, r3 = capture1:find("^[ \n\r\t]*", capture2)
capture2 = (r3 or capture2 - 1) + 1
 end
end
