-- Captured function: function_4632
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if capture1.Type ~= "Keybind" then
	if capture1.Type ~= "Color" then
		return capture1.Value
	end
	return capture2(capture1.Value)
end
if capture1.Value then
	local r4 = capture1.Value.Name
	if r4 then
		return r4
	end
end
return ""
 end
end
