-- Captured function: function_2412
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
capture2 = capture1.CurrentCamera or capture2
return capture2
 end
end
