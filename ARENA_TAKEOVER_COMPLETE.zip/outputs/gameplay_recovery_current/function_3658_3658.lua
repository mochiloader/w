-- Captured function: function_3658
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2
if capture1 ~= "Dime" then
	if capture1 ~= "Bullet" then
		r2 = "Dime"
	else
		r2 = "FIT"
	end
else
	r2 = "Bullet"
end
capture2(r2)
 end
end
