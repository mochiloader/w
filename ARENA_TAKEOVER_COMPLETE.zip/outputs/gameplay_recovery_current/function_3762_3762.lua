-- Captured function: function_3762
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5)
 return function(r13, r14, r15)
local r1 = capture1
if capture5 + 324921259 ~= 239314693 then
	if r1 then
		if type(r14) ~= "table" then
			r14 = {}
			r13.Value = r14
		elseif r14 then
			r13.Value = r14
		else
			r14 = {}
			r13.Value = r14
		end
	else
		r14 = r14 or ""
		r13.Value = capture2(r14)
	end
else
	capture5 = bit32.bxor(capture5, 2217423837)
	if r1 then
		if type(r14) ~= "table" then
			r14 = {}
			r13.Value = r14
		elseif r14 then
			r13.Value = r14
		else
			r14 = {}
			r13.Value = r14
		end
	else
		r13.Value = capture2(r14 or "")
	end
end
capture3()
if r15 then
	return
end
capture4(r13, r13.Value)
 end
end
