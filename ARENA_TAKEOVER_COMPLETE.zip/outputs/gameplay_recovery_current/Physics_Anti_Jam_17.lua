-- Captured function: Physics/Anti Jam
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Physics.AntiJam = arg1
 end
end
