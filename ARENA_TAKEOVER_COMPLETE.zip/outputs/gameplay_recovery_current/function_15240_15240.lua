-- Captured function: function_15240
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r8)
return r8 - r8 % 1
 end
end
