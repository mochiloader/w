-- Captured function: function_5463
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, captured_function_12110)
 return function(r21)
local r5 = capture1(r21)
capture2.floor(r21.w - r21.left)
local r2 = 1
local r3 = capture2.random(2, 3)
local r1, r2_1, r3_1
if 1 <= 0 then
	if r2 >= r3 then
		r1 = r2
		while true do
			r2_1 = capture3.delay
			r3_1 = captured_function_12110(nil, 1352712825, 1226058382, 387570673, 2040616624)
			r2_1((r1 - 1) * 0.35, r3_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r1 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r1 = d_1
					continue
				end
				break
			end
		end
	end
elseif r2 <= r3 then
	r1 = r2
	while true do
		r2_1 = capture3.delay
		r3_1 = captured_function_12110(nil, 1352712825, 1226058382, 387570673, 2040616624)
		r2_1((r1 - 1) * 0.35, r3_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r1 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r1 = d_1
				continue
			end
			break
		end
	end
end
capture6(r5, 2.8)
 end
end
