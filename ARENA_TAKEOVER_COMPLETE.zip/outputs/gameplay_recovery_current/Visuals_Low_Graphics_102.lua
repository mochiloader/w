-- Captured function: Visuals/Low Graphics
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r10)
capture1.Visuals.LowGraphics = r10
setLowGraphics(r10)
 end
end
