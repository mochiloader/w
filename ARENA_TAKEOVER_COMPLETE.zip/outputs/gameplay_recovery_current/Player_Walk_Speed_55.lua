-- Captured function: Player/Walk Speed
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r8)
local r2 = capture1.Player
if bit32.bxor(capture2, 363011559) == 479668872 then
	capture2 = bit32.bxor(capture2, 107600957)
end
r2.WalkSpeed = r8
 end
end
