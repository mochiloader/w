-- Reconstructed from captured VM instructions, with nested closures.
return function(r37)
if not r37 then
	return Vector3.new(0, 0, 0)
end
local r1, r2 = upv1(function()
	return r37.AssemblyLinearVelocity
end)
if r1 then
	if r2 then
		if r2.Magnitude > 0.05 then
			return r2
		end
	end
end
local r1_1, r2_1 = upv1(function()
	return r37.Velocity
end)
if r1_1 then
	if r2_1 then
		return r2_1
	end
end
return Vector3.new(0, 0, 0)
end
