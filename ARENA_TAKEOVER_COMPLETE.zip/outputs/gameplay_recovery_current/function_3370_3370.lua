-- Captured function: function_3370
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
if capture1 then
	capture1:Disconnect()
	capture1 = nil
end
if capture2 then
	capture2:Disconnect()
	capture2 = nil
end
capture3 = nil
 end
end
