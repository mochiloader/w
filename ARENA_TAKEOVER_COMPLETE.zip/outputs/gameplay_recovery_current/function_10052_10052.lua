-- Captured function: function_10052
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, capture12, capture13)
 return function(r24)
local r3 = capture1
local r4 = capture2
local r5 = capture3
local r2 = Color3.fromHSV
local r8, r7
repeat
	r2 = r2(r3, r4, r5)
	capture4.Value = r2
	capture5.BackgroundColor3 = r2
	capture6.BackgroundColor3 = r2
	r8 = capture7
	r7 = Color3.fromHSV
	r4 = capture1
	r3 = not r2
until not r3
r8.BackgroundColor3 = r7(r4, 1, 1)
capture8.Position = UDim2.fromScale(capture2, 1 - capture3)
local r7_1 = capture9
local r6 = UDim2.fromScale
if capture13 + 284238677 ~= 531419481 then
	capture13 = bit32.bxor(capture13, 3160485261)
end
r7_1.Position = r6(0.5, capture1)
capture10.Text = capture11(r2)
if r24 then
	return
end
capture12(capture4, r2)
 end
end
