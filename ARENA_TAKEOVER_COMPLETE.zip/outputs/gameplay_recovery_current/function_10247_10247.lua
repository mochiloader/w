-- Captured function: function_10247
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r2 = capture1 ~= nil
if r2 then
	return os.clock() < capture2
end
return r2
 end
end
