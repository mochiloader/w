-- Captured function: function_4184
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function()
capture1.clear(capture2)
local t12_8_1 = table.pack(d_1())
if t12_8_1[1] then
	local r2 = t12_8_1[2]
	local r3 = t12_8_1[3]
	while true do
		capture2[capture4(r3)] = r2
		local t18_15_1 = table.pack(d_1())
		if t18_15_1[1] then
			r2 = t18_15_1[2]
			r3 = t18_15_1[3]
		else
			break
		end
	end
end
 end
end
