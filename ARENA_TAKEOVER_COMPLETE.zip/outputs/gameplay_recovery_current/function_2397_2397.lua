-- Captured function: function_2397
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r2, r3, r4, r5)
if r2.ReadHolder then
	if r3 then
		r2.ReadHolder.Visible = true
		if r2.ReadLabel then
			r2.ReadLabel.Text = r3
			if r5 then
				r2.ReadLabel.TextColor3 = r5
			end
		end
		if r2.ReadReason then
			r2.ReadReason.Text = r4 or ""
		end
		if r2.ReadStroke then
			if r5 then
				r2.ReadStroke.Color = r5
				return
			end
		end
		return
	end
	if r2.ReadHolder.Visible then
		r2.ReadHolder.Visible = false
		return
	end
	return
end
 end
end
