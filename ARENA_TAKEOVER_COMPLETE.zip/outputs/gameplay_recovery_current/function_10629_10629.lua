-- Captured function: function_10629
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(arg1, arg2, r15)
local r2 = { Instance = arg2 }
if capture4 == 305325661 then
	capture4 = bit32.bxor(capture4, 3236072989)
end
r2.Text = string.lower(r15 or "")
capture1.insert(capture2.Rows, r2)
capture1.insert(capture3.Rows, r2)
return r2
 end
end
