-- Captured function: Catching/Dive Vector
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Catching.DiveVector = arg1
 end
end
