-- Captured function: function_10942
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8)
 return function(r8)
local r5 = capture1
if bit32.bxor(capture8, 172606042) == 100220191 then
	capture8 = bit32.bxor(capture8, 414794657)
end
if r5.ActiveTab ~= capture2 then
	local r12 = {}
	local r6
	if r8 then
		r6 = 0.45
	else
		r6 = 1
	end
	r12.BackgroundTransparency = r6
	capture3(capture4, r12, capture5.Quick)
	local r7 = {}
	local r6_1
	if r8 then
		r6_1 = capture7.Text or capture7.Muted
	else
		r6_1 = capture7.Muted
		r7.TextColor3 = r6_1
		capture3(capture6, r7, capture5.Quick)
		return
	end
	r7.TextColor3 = r6_1
	capture3(capture6, r7, capture5.Quick)
	return
end
 end
end
