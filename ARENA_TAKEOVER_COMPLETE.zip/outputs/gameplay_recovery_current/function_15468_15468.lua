-- Captured function: function_15468
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, captured_function_15584)
 return function(r25)
if not capture1 then
	capture1 = captured_function_15584(780332709, 4036643730, 4059398698, nil, 3367814979)
end
local r1 = 1
local r6 = ""
local r2 = r25
if 1 <= 0 then
	if r1 >= r2 then
		while true do
			r6 ..= capture3[capture1(65, 122)]
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r1 <= r2 then
	while true do
		r6 ..= capture3[capture1(65, 122)]
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
return r6
 end
end
