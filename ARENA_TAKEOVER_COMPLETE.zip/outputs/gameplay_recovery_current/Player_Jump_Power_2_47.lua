-- Captured function: Player/Jump Power#2
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Player.JPower = arg1
 end
end
