-- Captured function: function_2400
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r33, r34)
if r33.ThrowName then
	r33.ThrowName.Text = capture1(r34)
	return
end
 end
end
