-- Captured function: function_4906
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r20, r21)
if r20 ~= r21 then
	if type(r20) == "table" then
		if type(r21) == "table" then
			if #r20 ~= #r21 then
				return false
			end
			for r1, r2 in ipairs(r20) do
				if r2 ~= r21[r1] then
					return false
				end
			end
			for r5 in capture1(r21) do
				if r20[r5] ~= nil then
					continue
				end
				return false
			end
			return true
		end
	end
	return false
end
return true
 end
end
