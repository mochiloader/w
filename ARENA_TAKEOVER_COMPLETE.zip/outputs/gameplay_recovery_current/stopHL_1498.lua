-- Captured function: stopHL
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if hlConn then
	hlConn:Disconnect()
	hlConn = nil
end
local r4, r5, r6 = ipairs(capture1:GetDescendants())
if capture2 ~= 385938617 then
	capture2 = bit32.bxor(capture2, 1888937537)
end
while true do
	local t71_29_1 = table.pack(d_1())
	if t71_29_1[1] then
		local r5_1 = t71_29_1[3]
		local exitTo = nil
		while true do
			if r5_1:IsA("Highlight") then
				if r5_1.Name ~= "NxzFootballHL" then
					if r5_1.Parent then
						if r5_1.Parent.Name ~= "Football" then
							exitTo = 1
							break
						else
							r5_1:Destroy()
							local t40_54_1 = table.pack(d_1())
							if t40_54_1[1] then
								r5_1 = t40_54_1[3]
								continue
							end
						end
					else
						exitTo = 1
						break
					end
				else
					r5_1:Destroy()
					local t50_61_1 = table.pack(d_1())
					if t50_61_1[1] then
						r5_1 = t50_61_1[3]
						continue
					end
				end
				break
			else
				exitTo = 1
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	else
		break
	end
end
 end
end
