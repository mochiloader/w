-- Captured function: function_15247
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(...)
local r11 = { ... }
local r7 = {}
local r4 = #r11
local r3 = 1
if 1 <= 0 then
	if r3 >= r4 then
		while true do
			local r4_1 = #r7 + 1
			r7[r4_1] = capture1[r11[r3]]
			if x_1 <= 0 then
				if d_1 >= S_1 then
					r3 = d_1
					continue
				end
				break
			else
				if d_1 <= S_1 then
					r3 = d_1
					continue
				end
				break
			end
		end
	end
elseif r3 <= r4 then
	while true do
		r7[#r7 + 1] = capture1[r11[r3]]
		if x_1 <= 0 then
			if d_1 >= S_1 then
				r3 = d_1
				continue
			end
			break
		else
			if d_1 <= S_1 then
				r3 = d_1
				continue
			end
			break
		end
	end
end
return table.concat(r7)
 end
end
