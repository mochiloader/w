-- Captured function: function_1772
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r9)
if r9 then
	if r9 ~= "" then
		capture1.tagNum = r9
		return
	end
	return
end
 end
end
