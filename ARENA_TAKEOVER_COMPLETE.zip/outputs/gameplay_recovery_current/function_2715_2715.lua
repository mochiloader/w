-- Captured function: function_2715
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1, arg2)
capture1:SetValues(arg2 or {})
 end
end
