-- Captured function: Physics/Gravity Value
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r8)
local r2 = capture1
if bit32.bxor(capture2, 334854551) == 197404041 then
	capture2 = bit32.bxor(capture2, 3325302995)
end
r2.Physics.GravityValue = r8
 end
end
