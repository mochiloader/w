-- Captured function: ThemePreset
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r31)
local r29 = capture1:ApplyPreset(r31)
if r29 then
	if capture2 then
		capture2:SetValue(r29, true)
		return
	end
end
 end
end
