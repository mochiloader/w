-- Captured function: Visuals/Precipitation
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r18)
capture1.Visuals.Weather = r18
capture2(r18)
 end
end
