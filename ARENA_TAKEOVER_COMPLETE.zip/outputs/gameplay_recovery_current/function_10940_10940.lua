-- Captured function: function_10940
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function(r26)
local r4 = {}
local r3
if r26 then
	r3 = 0
else
	r3 = 1
end
r4.BackgroundTransparency = r3
capture1(capture2, r4, capture3.Quick)
if capture7 == 66153680 then
	capture7 = bit32.bxor(capture7, 3228400781)
end
local r4_1 = {}
local r2 = capture5
local r3_1
if r26 then
	r3_1 = capture6.Text or capture6.Muted
else
	r3_1 = capture6.Muted
	r4_1[r2] = r3_1
	capture1(capture4, r4_1, capture3.Quick)
	return
end
r4_1[r2] = r3_1
capture1(capture4, r4_1, capture3.Quick)
 end
end
