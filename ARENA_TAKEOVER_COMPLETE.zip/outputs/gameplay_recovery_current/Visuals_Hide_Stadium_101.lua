-- Captured function: Visuals/Hide Stadium
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r35)
capture1.Visuals.HideStadium = r35
setHideStadium(r35)
 end
end
