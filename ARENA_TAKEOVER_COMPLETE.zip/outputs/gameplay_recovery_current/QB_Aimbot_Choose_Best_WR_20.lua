-- Captured function: QB Aimbot/Choose Best WR
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r11)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.chooseBestWR = r11
	return
end
 end
end
