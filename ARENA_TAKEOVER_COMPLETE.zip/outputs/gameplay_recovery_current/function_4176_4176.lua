-- Captured function: function_4176
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r5)
if type(makefolder) ~= "function" then
	return
end
if type(isfolder) ~= "function" then
	return
end
local r5_1, r10, r11 = string.gmatch(r5, "[^/]+")
local r9_1 = nil
for r5_2 in r5_1, r10, r11 do
	local exitTo = nil
	while true do
		if r9_1 then
			r9_1 = r9_1 .. "/" .. r5_2 or r5_2
		else
			r9_1 = r5_2
		end
		if isfolder(r9_1) then
			exitTo = 1
			break
		else
			capture1(makefolder, r9_1)
			local t28_48_1 = table.pack(d_1())
			if t28_48_1[1] then
				r5_2 = t28_48_1[2]
				continue
			end
		end
		break
	end
	if exitTo == 1 then
		continue
	end
	break
end
 end
end
