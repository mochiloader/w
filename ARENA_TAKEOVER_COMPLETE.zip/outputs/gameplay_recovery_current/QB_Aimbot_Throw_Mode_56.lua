-- Captured function: QB Aimbot/Throw Mode
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r14)
if capture1 then
	if r14 ~= "FIT" then
		if capture2 then
			if capture2.Set then
				capture2:Set("FIT", true)
			end
		end
		if _G.DimeSetMode then
			_G.DimeSetMode("FIT")
			return
		end
		return
	end
end
if _G.DimeSetMode then
	_G.DimeSetMode(r14)
	return
end
 end
end
