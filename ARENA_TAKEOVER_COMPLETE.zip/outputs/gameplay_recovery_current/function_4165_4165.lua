-- Captured function: function_4165
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
local r4 = type(writefile) == "function"
if r4 then
	r4 = type(isfile) == "function"
	if r4 then
		return type(readfile) == "function"
	end
end
return r4
 end
end
