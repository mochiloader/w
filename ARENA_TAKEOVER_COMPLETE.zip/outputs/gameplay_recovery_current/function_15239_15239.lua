-- Captured function: function_15239
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, captured_function_15476)
 return function()
local r8 = captured_function_15476(nil, 1331713480, 1979246267, 4237231356, 1314455533)
local r5, r6 = capture1(r8)
if r5 then
	if type(r6) ~= "number" then
		return -1
	end
	if r6 ~= r6 then
		return -1
	end
	return capture3.clamp(capture4(r6 + 0.5), 0, 10000)
end
return -1
 end
end
