-- Captured function: Misc/Enable Spectate
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1 = arg1
capture2()
 end
end
