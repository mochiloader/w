-- Captured function: function_3854
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8)
 return function()
return "ZIndex"
 end
end
