-- Captured function: function_2714
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
return false
 end
end
