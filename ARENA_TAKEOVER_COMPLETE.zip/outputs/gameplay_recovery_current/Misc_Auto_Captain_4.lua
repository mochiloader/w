-- Captured function: Misc/Auto Captain
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r9)
capture1 = r9
if not r9 then
	if capture2 then
		capture2:Disconnect()
		capture2 = nil
		return
	end
end
 end
end
