-- Captured function: Visuals/Remove Ball Trail
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r14)
capture1.Visuals.RemoveBallTrail = r14
if r14 then
	local r2, r3, r4 = capture2(capture3)
	local t7_12_1 = table.pack(d_1())
	if t7_12_1[1] then
		local r2_1 = t7_12_1[2]
		while true do
			stripBallTrails(r2_1)
			local t12_16_1 = table.pack(d_1())
			if t12_16_1[1] then
				r2_1 = t12_16_1[2]
			else
				break
			end
		end
	end
	return
end
 end
end
