-- Captured function: ThemeAccent
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r5)
capture1:SetAccent(r5)
 end
end
