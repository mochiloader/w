-- Captured function: stripBallTrails
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r31)
if r31 then
	for _, r2 in ipairs(r31:GetDescendants()) do
		local exitTo = nil
		while true do
			if r2:IsA("Trail") then
				r2.Enabled = false
				local t18_23_1 = table.pack(d_1())
				if t18_23_1[1] then
					r2 = t18_23_1[3]
					continue
				end
				break
			else
				exitTo = 1
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	end
	return
end
 end
end
