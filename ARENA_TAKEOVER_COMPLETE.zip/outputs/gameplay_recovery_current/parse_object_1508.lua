-- Captured function: parse_object
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function()
capture1 = (738726383 == 78165110 or capture1) + 1
local r8 = {}
capture2()
if capture3:sub(capture1, capture1) ~= "}" then
	while true do
		capture2()
		if capture3:sub(capture1, capture1) ~= "\"" then
			error("Expected string key at position " .. tostring(capture1))
		end
		local r12 = parse_string()
		capture2()
		if capture3:sub(capture1, capture1) ~= ":" then
			error("Expected ':' after key at position " .. tostring(capture1))
		end
		capture1 += 1
		r8[r12] = capture4()
		capture2()
		local r3 = capture3:sub(capture1, capture1)
		if r3 ~= "}" then
			if r3 ~= "," then
				error("Expected ',' or '}' at position " .. tostring(capture1))
			else
				capture1 += 1
			end
			continue
		end
		break
	end
	capture1 += 1
	return r8
end
capture1 += 1
return r8
 end
end
