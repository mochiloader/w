-- Captured function: function_2391
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function()
if _G.FF3QbaToggleLock then
	_G.FF3QbaToggleLock()
	return
end
 end
end
