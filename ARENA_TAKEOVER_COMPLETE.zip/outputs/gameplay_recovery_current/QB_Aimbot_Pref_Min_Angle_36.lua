-- Captured function: QB Aimbot/Pref Min Angle
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r25)
if _G.DimeThrowCfg then
	_G.DimeThrowCfg.PREFERRED_ANGLE_MIN = r25
	return
end
 end
end
