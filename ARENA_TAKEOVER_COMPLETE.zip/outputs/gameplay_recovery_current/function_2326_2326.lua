-- Captured function: function_2326
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_4230, captured_function_4231)
 return function(r17, arg2)
r17:CreateWindow({
	Title = capture1(arg2 or "Cons1"),
	Subtitle = "cons",
	Folder = r17.Folder or "Cons1",
	Logo = "https://cdn.discordapp.com/icons/1446918773557952759/23fece088e485481a13c74598f9d1875.webp?size=1024",
})
local r2_1 = {}
captured_function_4231(nil, 2630825134, 2523859556, 506932382, 105117497)
r2_1.newTab = captured_function_4230(nil, 758365750, 1195055359, 593535721, 1792614257)
return r2_1
 end
end
