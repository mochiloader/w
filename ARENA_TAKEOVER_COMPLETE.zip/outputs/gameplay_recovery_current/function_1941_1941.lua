-- Captured function: function_1941
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r9, arg2)
if arg2 then
	capture1 = r9
	return
end
 end
end
