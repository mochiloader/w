-- Captured function: function_2320
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function(arg1, r17, arg3, r19)
if capture1[r17] ~= nil then
	if capture1[r17] then
		if r19 then
			r19(capture1[r17])
		end
	end
	local r1 = capture1[r17]
	if r1 then
		return r1
	end
	return nil
end
if capture2() then
	if isfile(r17) then
		local r1_1, r2 = capture3(getcustomasset, r17)
		local r3 = capture1
		if r1_1 then
			r2 = r2 or false
		else
			r2 = false
		end
		r3[r17] = r2
		if capture1[r17] then
			if r19 then
				r19(capture1[r17])
			end
		end
		local r1_2 = capture1[r17]
		if r1_2 then
			return r1_2
		end
		return nil
	end
	if capture4[r17] then
		capture5.insert(capture4[r17], r19)
		return nil
	end
	return (nil)("Rotation", table.unpack(nil, 1, (nil).n))
end
capture1[r17] = false
return nil
 end
end
