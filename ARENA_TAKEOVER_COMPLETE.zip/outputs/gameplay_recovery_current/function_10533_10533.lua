-- Captured function: function_10533
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r36)
local r5 = r36.w - r36.left - 70
local r7 = r36.h - 90
return r36.left + 20 + capture1.random() * r5, 40 + capture1.random() * r7
 end
end
