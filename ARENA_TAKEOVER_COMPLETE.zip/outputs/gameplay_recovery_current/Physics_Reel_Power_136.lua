-- Captured function: Physics/Reel Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.strength = capture2.clamp(arg1, 1, 8)
 end
end
