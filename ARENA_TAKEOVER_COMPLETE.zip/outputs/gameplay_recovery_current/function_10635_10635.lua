-- Captured function: function_10635
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11, capture12, captured_function_11541)
 return function(arg1, arg2)
local r9 = arg2 or {}
local r29 = capture1(capture2, 48)
local r8 = {
	BackgroundColor3 = capture4.Control,
	BorderSizePixel = 0,
	Size = UDim2.new(1, -capture5.Inset * 2, 0, 34),
}
local r5 = UDim2.fromOffset
local r2 = capture5
if 2261311413 ~= 309952634 then
	r8.Position = r5(r2.Inset, 7)
end
r8.Font = Enum.Font.GothamMedium
r8.TextSize = 12
r8.TextColor3 = capture4.Text
r8.Text = r9.Text or "Button"
r8.AutoButtonColor = false
r8.Parent = r29
local r3_1 = capture4.Border
local r3_2 = capture3("TextButton", r8, { capture6(10), capture7(r3_1, 0.5) })
capture8(r3_2, r3_2)
local r31_1 = capture9
local r30 = capture9.Connect
local r32 = r3_2.MouseButton1Click
local r33 = captured_function_11541(nil, 842471354, 3316944838, 859861577, 3453293981)
r30(r31_1, r32, r33)
capture2:Register(r29, r9.Text)
return r3_2
 end
end
