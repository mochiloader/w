-- Captured function: Visuals/Shiny Helmet
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r29)
capture1 = r29
if r29 then
	capture2()
	return
end
capture3()
 end
end
