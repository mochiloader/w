-- Captured function: function_3837
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r19, r20)
return capture1("UIGradient", {
	Color = ColorSequence.new(nil, Color3.fromRGB(255 * r20, 255 * r20, 255 * capture2.min(r20 + 0.08, 1))),
	Rotation = r19,
})
 end
end
