-- Captured function: function_1900
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function()
local r4 = capture1.Character
if r4 then
	for _, r3 in ipairs(r4:GetDescendants()) do
		local exitTo = nil
		while true do
			if capture2(r3) then
				capture3(r3)
				local t19_20_1 = table.pack(d_1())
				if t19_20_1[1] then
					r3 = t19_20_1[3]
					continue
				end
				break
			else
				exitTo = 1
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	end
	return
end
 end
end
