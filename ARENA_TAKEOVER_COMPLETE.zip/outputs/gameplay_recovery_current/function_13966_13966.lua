-- Captured function: function_13966
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r28)
if r28 then
	local r26 = capture1:GetPlayerFromCharacter(r28)
	if r26 then
		if capture2[r26] then
			local r1 = capture2[r26].idle
			if r1 then
				return r1
			end
		end
	end
	return false
end
return false
 end
end
