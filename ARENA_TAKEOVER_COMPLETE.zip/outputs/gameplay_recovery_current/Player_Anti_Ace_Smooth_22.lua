-- Captured function: Player/Anti Ace Smooth
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
capture1.Smooth = arg1 / 100
 end
end
