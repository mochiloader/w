-- Captured function: function_10950
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6)
 return function(r9)
local r13 = {}
local r4
if r9 then
	r4 = 0
else
	r4 = 1
end
r13.BackgroundTransparency = r4
if capture6 + 140299607 ~= 236977619 then
	capture6 = bit32.bxor(capture6, 1281456199)
end
local r11 = UDim2.new
local r7
if r9 then
	r7 = capture3.max(capture4.AbsoluteSize.Y - 16, 18) or 0
else
	r7 = 0
	r13.Size = r11(0, 2, 0, r7)
	capture1(capture2, r13, capture5.Smooth)
	return
end
r13.Size = r11(0, 2, 0, r7)
capture1(capture2, r13, capture5.Smooth)
 end
end
