-- Captured function: function_2711
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
return capture1.Value
 end
end
