-- Captured function: function_4348
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7, capture8, capture9, capture10, capture11)
 return function(r10, r11, r12)
local r2_1 = capture1.clamp(capture2(capture3(r11) or capture4), capture4, capture5)
if r10.Dragging then
	if r2_1 == r10.Value then
		if r10.Painted then
			return
		end
	end
end
r10.Painted = true
r10.Value = r2_1
local r3 = capture6
local r5 = capture11 + 317666717 ~= 345475987
table.unpack(nil, 66, (nil).n)
capture11 = bit32.bxor(capture11, 1589306755)
r3.Text = r5 .. capture8
local r4 = not r10.Dragging
capture9((r2_1 - capture4) / capture1.max(capture5 - capture4, 1e-06), r4)
if r12 then
	return
end
capture10(r10, r2_1)
 end
end
