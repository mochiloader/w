-- Captured function: function_2344
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r35)
if capture1() then
	local r3 = r35.Folder .. "/autoload.txt"
	if isfile(r3) then
		local r1, r2 = capture2(readfile, r3)
		if r1 then
			if r2 ~= "" then
				if r2 then
					return r2
				end
			end
		end
		return nil
	end
	return nil
end
return nil
 end
end
