-- Captured function: function_1882
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, captured_function_2725)
 return function(...)
return capture1(captured_function_2725(nil, 4147220690, 903842417, 3937291112, 442647495), select(2, ...))
 end
end
