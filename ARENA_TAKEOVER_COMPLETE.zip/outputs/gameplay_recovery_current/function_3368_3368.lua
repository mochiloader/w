-- Captured function: function_3368
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(arg1)
return arg1.Value
 end
end
