-- Captured function: function_3667
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r28)
capture1.DEFAULT_DIME_LEAD = r28
capture2.Dime = r28
 end
end
