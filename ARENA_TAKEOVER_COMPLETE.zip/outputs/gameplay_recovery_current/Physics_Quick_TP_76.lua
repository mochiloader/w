-- Captured function: Physics/Quick TP
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3)
 return function(r23)
capture1.Physics.QuickTP = r23
if r23 then
	capture2()
	return
end
capture3()
 end
end
