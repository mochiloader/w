-- Captured function: function_12107
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, captured_function_15133)
 return function(arg1, r34)
local r2 = capture1.delay
local r3 = captured_function_15133(nil, 2754867555, 3808480099, 4221791533, 1971808138)
r2(r34, r3)
 end
end
