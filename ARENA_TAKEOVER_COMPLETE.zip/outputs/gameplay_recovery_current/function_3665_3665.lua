-- Captured function: function_3665
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r23)
capture1.DEFAULT_BULLET_LEAD = r23
capture2.Bullet = r23
 end
end
