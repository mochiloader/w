-- Captured function: function_15229
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r32)
local r2, r3 = capture1(capture2, r32)
if r2 then
	if type(r3) ~= "table" then
		return nil
	end
	return r3
end
return nil
 end
end
