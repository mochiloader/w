-- Captured function: function_3659
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture2 = capture1.clamp(arg1, 5, 85)
 end
end
