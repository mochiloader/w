-- Captured function: function_3840
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(r32)
local r2 = capture1("UIGradient", { Color = capture2(), Rotation = r32 or 0 })
capture3.insert(capture4, r2)
return r2
 end
end
