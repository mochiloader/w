-- Captured function: function_11617
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
local r1 = 10 ^ capture1
return capture2.floor(arg1 * r1 + 0.5) / r1
 end
end
