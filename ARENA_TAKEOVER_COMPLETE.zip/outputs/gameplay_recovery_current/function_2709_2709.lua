-- Captured function: function_2709
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1, arg2, r22)
capture1:SetValue(arg2, r22)
 end
end
