-- Captured function: function_4174
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function()
local r2 = type(getcustomasset) == "function"
if r2 then
	return (capture1())
end
return r2
 end
end
