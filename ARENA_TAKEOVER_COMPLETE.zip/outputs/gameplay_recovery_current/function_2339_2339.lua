-- Captured function: function_2339
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r11 = {}
local r2, r3, r4 = ipairs(capture1)
local t8_10_1 = table.pack(d_1())
if t8_10_1[1] then
	local r3_1 = t8_10_1[3]
	while true do
		capture2.insert(r11, r3_1.Name)
		local t12_15_1 = table.pack(d_1())
		if t12_15_1[1] then
			r3_1 = t12_15_1[3]
		else
			break
		end
	end
end
return r11
 end
end
