-- Captured function: function_5011
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, captured_function_11896)
 return function(r11, r12, r13)
local r9, r10 = capture1(capture2.new, r11)
if r9 then
	if not r10 then
		return nil
	end
	if r13 then
		local r2, r3, r4 = capture3(r13)
		local t46_24_1 = table.pack(d_1())
		if t46_24_1[1] then
			repeat
				local r9_1 = captured_function_11896(nil, 2843920232, 1754623972, 2407713943, 1857457844)
				capture1(r9_1)
				local t27_29_1 = table.pack(d_1())
			until not t27_29_1[1]
		end
		if r12 then
			r10.Parent = r12
			return r10
		end
	elseif r12 then
		r10.Parent = r12
		return r10
	end
	return r10
end
return nil
 end
end
