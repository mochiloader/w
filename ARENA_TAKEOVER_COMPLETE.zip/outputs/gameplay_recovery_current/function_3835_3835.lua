-- Captured function: function_3835
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r28)
return capture1("UICorner", { CornerRadius = UDim.new(0, r28) })
 end
end
