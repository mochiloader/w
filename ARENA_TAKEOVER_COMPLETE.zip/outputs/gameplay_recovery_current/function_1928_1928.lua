-- Captured function: function_1928
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, capture7)
 return function()
if capture1 then
	local r8 = capture4(capture5)
	if r8 then
		if capture7(r8) then
			capture6:Notif("Spectate", "watching " .. r8.Name, 2)
			return
		end
		return
	end
	capture6:Notif("Spectate", "pick a target first", 2)
	capture1 = false
	return
end
capture2()
capture3()
 end
end
