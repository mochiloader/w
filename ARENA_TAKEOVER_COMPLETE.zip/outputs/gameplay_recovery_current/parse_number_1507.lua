-- Captured function: parse_number
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
local r7, r8 = capture1:find("^%-?%d+%.?%d*[eE]?[%+%-]?%d*", capture2)
if not r7 then
	error("Invalid number at position " .. tostring(capture2))
end
local r5 = tonumber(capture1:sub(r7, r8))
capture2 = r8 + 1
return r5
 end
end
