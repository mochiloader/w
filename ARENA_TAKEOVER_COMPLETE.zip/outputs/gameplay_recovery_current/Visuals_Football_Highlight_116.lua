-- Captured function: Visuals/Football Highlight
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r20)
local r1 = capture1.Visuals
if capture2 ~= 127432744 then
	capture2 = bit32.bxor(capture2, 1230850939)
end
r1.FootballHL = r20
if r20 then
	startHL()
	return
end
stopHL()
 end
end
