-- Captured function: function_2333
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r19, r20, r21)
return r19:RequestImage(string.format("%s/icons/%s.png", r19.Folder, r20), string.format("https://wsrv.nl/?url=api.iconify.design%%2Flucide%%2F%s.svg%%3Fcolor%%3Dwhite&output=png&w=96", r20), r21)
 end
end
