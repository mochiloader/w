-- Captured function: function_15481
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(r13)
local r6 = capture1.create(4)
local r2 = 0
while true do
	local r3 = capture2(r13 / 256 ^ r2) % 256
	local r4 = capture2(r3 / 16)
	local r3_1 = r3 % 16
	r6[r2 + 1] = ("0123456789abcdef"):sub(r4 + 1, r4 + 1) .. ("0123456789abcdef"):sub(r3_1 + 1, r3_1 + 1)
	if x_1 <= 0 then
		if d_1 >= S_1 then
			r2 = d_1
			continue
		end
		break
	else
		if d_1 <= S_1 then
			r2 = d_1
			continue
		end
		break
	end
end
return capture1.concat(r6)
 end
end
