-- Captured function: function_5469
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4, capture5, capture6, captured_function_12127)
 return function(r8)
local r10 = capture1(r8)
r8.gustAt = os.clock()
local r6 = capture2.random(10, 14)
local r5 = 1
local r5_1, r6_1
if 1 <= 0 then
	if r5 >= r6 then
		while true do
			r5_1 = capture3.spawn
			r6_1 = captured_function_12127(nil, 1827211605, 3338438843, 1186447854, 1122654132)
			r5_1(r6_1)
			if x_1 <= 0 then
				if d_1 >= S_1 then
					continue
				end
				break
			else
				if d_1 <= S_1 then
					continue
				end
				break
			end
		end
	end
elseif r5 <= r6 then
	while true do
		r5_1 = capture3.spawn
		r6_1 = captured_function_12127(nil, 1827211605, 3338438843, 1186447854, 1122654132)
		r5_1(r6_1)
		if x_1 <= 0 then
			if d_1 >= S_1 then
				continue
			end
			break
		else
			if d_1 <= S_1 then
				continue
			end
			break
		end
	end
end
capture6(r10, 3.6)
 end
end
