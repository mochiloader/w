-- Captured function: function_10955
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, capture4)
 return function(arg1)
local r4 = {}
local r5
if arg1 then
	r5 = capture3 or capture4.Track or upv5 or capture4.Control
else
	r5 = upv5 or capture4.Control
end
r4.BackgroundColor3 = r5
capture1(capture2, r4, upv6.Quick)
 end
end
