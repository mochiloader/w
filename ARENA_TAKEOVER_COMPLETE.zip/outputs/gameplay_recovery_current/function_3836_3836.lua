-- Captured function: function_3836
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1, arg2, arg3)
return capture1("UIStroke", {
	Color = arg1 or capture2.Border,
	Transparency = arg2 or 0.5,
	Thickness = arg3 or 1,
	ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
})
 end
end
