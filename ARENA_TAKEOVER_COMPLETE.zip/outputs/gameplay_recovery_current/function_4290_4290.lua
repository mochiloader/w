-- Captured function: function_4290
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2, capture3, captured_function_11590)
 return function(r35)
local r1 = captured_function_11590(nil, 1262634896, 1382027650, 462155422, 1355776997)
capture1(r35, r1)
 end
end
