-- Captured function: QB Aimbot/Ping Lead
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r14)
if _G.DimeThrowCfg then
	if _G.DimeThrowCfg.proFlags then
		_G.DimeThrowCfg.proFlags.pingLead = r14
		return
	end
end
 end
end
