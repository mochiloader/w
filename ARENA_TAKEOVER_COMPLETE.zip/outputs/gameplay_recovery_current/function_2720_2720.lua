-- Captured function: function_2720
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
return (arg1 or "_p") .. capture1(capture2.random(100000, 900000))
 end
end
