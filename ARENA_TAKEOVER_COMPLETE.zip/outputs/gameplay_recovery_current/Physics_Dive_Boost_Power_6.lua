-- Captured function: Physics/Dive Boost Power
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(arg1)
DiveBoost.mult = capture1.clamp(arg1, 0, 10)
 end
end
