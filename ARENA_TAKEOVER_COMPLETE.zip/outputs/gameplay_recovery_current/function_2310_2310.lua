-- Captured function: function_2310
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1)
 return function(r34, arg2, r36)
local r38 = arg2:Connect(r36)
capture1.insert(r34.Connections, r38)
return r38
 end
end
