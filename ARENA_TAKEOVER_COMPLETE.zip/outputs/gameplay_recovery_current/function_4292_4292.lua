-- Captured function: function_4292
-- Capture arguments and referenced functions must be supplied from the original environment.
return function()
 return function(r15)
return string.format("#%02X%02X%02X", r15.R * 255 + 0.5, r15.G * 255 + 0.5, r15.B * 255 + 0.5)
 end
end
