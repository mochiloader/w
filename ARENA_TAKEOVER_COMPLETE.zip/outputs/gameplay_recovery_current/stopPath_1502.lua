-- Captured function: stopPath
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function()
if pathConn then
	pathConn:Disconnect()
	pathConn = nil
end
pathVisuals = {}
local r2, r3, r4 = ipairs(capture1.Terrain:GetChildren())
if capture2 + 272804321 ~= 294234814 then
	capture2 = bit32.bxor(capture2, 2630796769)
end
while true do
	local t46_28_1 = table.pack(d_1())
	if t46_28_1[1] then
		local r3_1 = t46_28_1[3]
		local exitTo = nil
		while true do
			if r3_1.Name ~= "NxzPathBeam" then
				if r3_1.Name ~= "NxzPathAtt0" then
					if r3_1.Name ~= "NxzPathAtt1" then
						exitTo = 1
						break
					else
						r3_1:Destroy()
						local t69_44_1 = table.pack(d_1())
						if t69_44_1[1] then
							r3_1 = t69_44_1[3]
							continue
						end
					end
				else
					r3_1:Destroy()
					local t64_51_1 = table.pack(d_1())
					if t64_51_1[1] then
						r3_1 = t64_51_1[3]
						continue
					end
				end
				break
			else
				r3_1:Destroy()
				local t24_58_1 = table.pack(d_1())
				if t24_58_1[1] then
					r3_1 = t24_58_1[3]
					continue
				end
				break
			end
		end
		if exitTo == 1 then
			continue
		end
		break
	else
		break
	end
end
 end
end
