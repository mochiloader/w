-- Captured function: Catching/Football Size
-- Capture arguments and referenced functions must be supplied from the original environment.
return function(capture1, capture2)
 return function(arg1)
capture1.Catching.BallSize = capture2.clamp(arg1, 1, 20)
 end
end
