-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735037608;
local u2 = UNNAMED_2819735039528;
local u3 = UNNAMED_2819735028776;
local u4 = u3(UNNAMED_2819735082872);
local u5 = UNNAMED_2819735087672;
local u6 = UNNAMED_2819735035448;
local u7 = nil;
local u8 = nil;
local u9 = nil;
local u10 = nil;
local u11 = nil;
local u12 = nil;
local u13 = nil;
local u14 = UNNAMED_2819735041496;
local u15 = UNNAMED_2819735075864;
local u16 = UNNAMED_2819735060216;
local u17 = UNNAMED_2819735056472;
local u18 = UNNAMED_2819735075048;
local u19 = UNNAMED_2819735041208;
local u20 = UNNAMED_2819735079272;
local u21 = UNNAMED_2819735037656;
local u22 = UNNAMED_2819735051864;
local u23 = UNNAMED_2819735072120;
local u24 = UNNAMED_2819735089448;
local u25 = UNNAMED_2819735044328;
local u26 = UNNAMED_2819735070056;
local u27 = UNNAMED_2819735035736;
local u28 = UNNAMED_2819735049896;
local u29 = UNNAMED_2819735057288;
local u30 = UNNAMED_2819735055224;
local u31 = UNNAMED_2819735038088;
local v1041, v1042, v1043, v1044, v1045 = UNNAMED_2819735041976(function(...) -- Line: 3
    -- upvalues: u6 (ref), UNNAMED_2819735075720 (ref), u5 (ref), u4 (copy), UNNAMED_2819735072264 (ref), UNNAMED_2819735035304 (ref), UNNAMED_2819735063384 (ref), u16 (copy), u17 (copy), u14 (copy), UNNAMED_2819735066504 (ref), u18 (copy), u19 (copy), UNNAMED_2819735050136 (ref), UNNAMED_2819735029544 (ref), u12 (ref), u13 (ref), u15 (copy), u3 (copy), u21 (copy), u1 (ref), u20 (copy), u22 (copy), UNNAMED_2819735088680 (ref), u8 (ref), u7 (ref), u9 (ref), u10 (ref), u11 (ref), UNNAMED_2819735058152 (ref), u2 (ref), u23 (copy), u24 (copy), u25 (copy), u26 (copy), u27 (copy), UNNAMED_2819735088728 (ref), u28 (copy), u29 (copy), u30 (copy), u31 (copy), UNNAMED_2819735077064 (ref)
    local v32, v33, v34, v35, v36, v37;
    local u6, v32, v33, v34, v35, v36, v37, u8, u2, u5, u1, u10, u12, u7, u9, u13, u11;
    local v38 = 0;

    while true do
        if v38 == 0 then
            v38 = -1;
            v32 = nil;
            v33 = nil;
            v34 = nil;
            v35 = nil;
            v36 = nil;
            v37 = nil;

            if u6 ~= 113 then
                v38 = 1;
                continue;
            end;

            v38 = 6;
            continue;
        elseif v38 == 1 then
            v38 = -1;

            if u6 ~= 127 then
                v38 = 2;
                continue;
            end;

            v38 = 5;
            continue;
        elseif v38 == 2 then
            v38 = -1;

            if u6 ~= 240 then
                v38 = 3;
                continue;
            end;

            v38 = 4;
            continue;
        elseif v38 == 3 then
            v38 = -1;

            if u6 ~= 31 then
                return;
            end;

            while true do
                local v39 = UNNAMED_2819735063384[u5];

                if v39 < 95 then
                    if v39 < 47 then
                        if v39 < 23 then
                            if v39 < 11 then
                                if v39 < 5 then
                                    if v39 >= 2 then
                                        if v39 < 3 then
                                            v36 = UNNAMED_2819735072264[u5];
                                            local v40 = UNNAMED_2819735035304[u5];
                                            u4[v36] = UNNAMED_2819735077064[u5];
                                            u4[v36 + 1] = v40;
                                        elseif v39 == 4 then
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] // u4[UNNAMED_2819735075720[u5]];
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]];
                                            v36 = UNNAMED_2819735035304[u5 + 1];
                                            v34 = UNNAMED_2819735075720[u5 + 1];
                                            v32 = UNNAMED_2819735072264[u5 + 1];
                                            v35 = v36 + v32 - 1;
                                            v33 = v36 + v34;
                                            v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                            u16(v37, 1, v32, v36, u4);
                                            u5 = u5 + 1;
                                        end;
                                    elseif v39 == 1 then
                                        if u4[UNNAMED_2819735072264[u5]] ~= u4[UNNAMED_2819735075720[u5]] then
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735075720[u5]]] = UNNAMED_2819735035304[u5];
                                    end;
                                elseif v39 >= 8 then
                                    if v39 >= 9 then
                                        if v39 == 10 then
                                            u8 = u8 + u10;

                                            if u10 <= 0 then
                                                v36 = u9 <= u8;
                                            else
                                                v36 = u8 <= u9;
                                            end;

                                            if v36 then
                                                u4[UNNAMED_2819735035304[u5]] = u8;
                                                u5 = UNNAMED_2819735075720[u5];
                                            else
                                                u5 = UNNAMED_2819735072264[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735050136[u5] * UNNAMED_2819735077064[u5];
                                        end;
                                    else
                                        v36 = UNNAMED_2819735035304[u5];
                                        v34 = UNNAMED_2819735075720[u5];
                                        v32 = UNNAMED_2819735072264[u5];
                                        v35 = v36 + v32 - 1;
                                        v33 = v36 + v34;
                                        v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                        u16(v37, 1, v32, v36, u4);
                                    end;
                                elseif v39 >= 6 then
                                    if v39 == 7 then
                                        v36 = UNNAMED_2819735075720[u5];
                                        local v41 = u4[UNNAMED_2819735035304[u5]];
                                        u4[v36] = u4[UNNAMED_2819735072264[u5]];
                                        u4[v36 + 1] = v41;
                                    elseif UNNAMED_2819735035304[u5] > u4[UNNAMED_2819735072264[u5]] then
                                        u5 = UNNAMED_2819735075720[u5];
                                    end;
                                else
                                    u24[UNNAMED_2819735066504[u5]][UNNAMED_2819735077064[u5]] = u4[UNNAMED_2819735035304[u5]];
                                end;
                            elseif v39 < 17 then
                                if v39 >= 14 then
                                    if v39 < 15 then
                                        local v42 = u12;
                                        local v43 = u13;

                                        if v42 then
                                            for i in u15, v42 do
                                                local v44 = v42[i];

                                                if v44 then
                                                    v44[5] = v44;
                                                    v44[6] = u4[i];
                                                    v44[4] = 6;
                                                    v42[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v43 then
                                            for i, v in u15, v43 do
                                                local v45 = v[6];

                                                if v43 then
                                                    local v46 = v43[i];

                                                    if v46 then
                                                        local v47 = u3(v45);
                                                        u16(u4, i, i + v45 - 1, 1, v47);
                                                        v46[5] = v47;
                                                        v46[4] = 1;
                                                        v43[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(u4[UNNAMED_2819735075720[u5]], u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                                    end;

                                    if v39 ~= 16 and u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735066504[u5] then
                                        u5 = UNNAMED_2819735075720[u5];
                                    end;
                                elseif v39 >= 12 then
                                    if v39 == 13 then
                                        u4[UNNAMED_2819735035304[u5]] = #u4[UNNAMED_2819735075720[u5]];
                                    else
                                        local v48 = UNNAMED_2819735072264[u5];
                                        local v49 = UNNAMED_2819735077064[u5];
                                        local v50 = u21(UNNAMED_2819735035304[u5], 4294967295);
                                        local v51 = u21(v49, 4294967295);
                                        local v52 = u21(v50, 65535);
                                        local v53 = u20(v50, 16);
                                        local v54 = u21(v51, 65535);
                                        local v55 = u20(v51, 16);
                                        local v56 = u21(v52 * v54 + u22(u21(v52 * v55 + v53 * v54, 65535), 16), 4294967295) % 4294967296;
                                        u4[v48] = v56 ~= v56 and 0 or v56 - v56 % 1;
                                    end;
                                else
                                    v36 = UNNAMED_2819735075720[u5];
                                    v34, v32 = u8();

                                    if v34 then
                                        u4[v36] = v32;
                                        u5 = UNNAMED_2819735035304[u5];
                                    else
                                        u5 = UNNAMED_2819735072264[u5];
                                    end;
                                end;
                            elseif v39 < 20 then
                                if v39 < 18 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] - u4[UNNAMED_2819735075720[u5]];
                                elseif v39 == 19 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] ~= u4[UNNAMED_2819735072264[u5]];
                                else
                                    v36 = UNNAMED_2819735075720[u5];
                                    v34 = UNNAMED_2819735035304[u5];
                                    v32 = UNNAMED_2819735072264[u5];
                                    v35 = v36 + v34;
                                    u4[v36] = u17(u4[v36](u14(u4, v36 + 1, v35)));
                                end;
                            elseif v39 >= 21 then
                                if v39 == 22 then
                                    u4[UNNAMED_2819735035304[u5]] = {};
                                else
                                    local v57 = UNNAMED_2819735072264[u5];
                                    local v58 = u4[UNNAMED_2819735035304[u5]];
                                    local v59 = u21(UNNAMED_2819735077064[u5], 4294967295);
                                    local v60 = u21(v58, 4294967295);
                                    local v61 = u21(v59, 65535);
                                    local v62 = u20(v59, 16);
                                    local v63 = u21(v60, 65535);
                                    local v64 = u20(v60, 16);
                                    local v65 = u21(v61 * v63 + u22(u21(v61 * v64 + v62 * v63, 65535), 16), 4294967295) % 4294967296;
                                    u4[v57] = v65 ~= v65 and 0 or v65 - v65 % 1;
                                end;
                            else
                                v36 = UNNAMED_2819735075720[u5];
                                v34 = u18(u1, u21(u20(u1, 14), 262143), (u21(u20(u1, 28), 15)));
                                v32 = UNNAMED_2819735072264[u5];
                                v35 = UNNAMED_2819735035304[u5];
                                v33 = v32 < 2097152 and 7 or 14;
                                v37 = u21(v32, u22(1, v33) - 1);
                                UNNAMED_2819735063384[u5] = u18(u20(v32, v33), 55, (u21(u20(v34, 21), 127)));
                                UNNAMED_2819735075720[u5] = u18(v36, 33, (u21(v34, 127)));
                                UNNAMED_2819735035304[u5] = u18(v35, 2, (u21(u20(v34, 7), 127)));
                                UNNAMED_2819735072264[u5] = u18(v37, 53, (u21(u20(v34, 14), 127)));
                                u5 = u5 - 1;
                            end;
                        elseif v39 >= 35 then
                            if v39 >= 41 then
                                if v39 < 44 then
                                    if v39 < 42 then
                                        u24[UNNAMED_2819735050136[u5]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735077064[u5];
                                    elseif v39 == 43 then
                                        local v66 = UNNAMED_2819735075720[u5];
                                        local v67 = u4[UNNAMED_2819735035304[u5]];
                                        local v68 = u21(u4[UNNAMED_2819735072264[u5]], 4294967295);
                                        local v69 = u21(v67, 4294967295);
                                        local v70 = u21(v68, 65535);
                                        local v71 = u20(v68, 16);
                                        local v72 = u21(v69, 65535);
                                        local v73 = u20(v69, 16);
                                        local v74 = u21(v70 * v72 + u22(u21(v70 * v73 + v71 * v72, 65535), 16), 4294967295) % 4294967296;
                                        u4[v66] = v74 ~= v74 and 0 or v74 - v74 % 1;
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = u21(u4[UNNAMED_2819735075720[u5]], u4[UNNAMED_2819735035304[u5]]);
                                    end;
                                else
                                    if v39 < 45 then
                                        local v75 = u12;
                                        local v76 = u13;

                                        if v75 then
                                            for i in u15, v75 do
                                                local v77 = v75[i];

                                                if v77 then
                                                    v77[5] = v77;
                                                    v77[6] = u4[i];
                                                    v77[4] = 6;
                                                    v75[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v76 then
                                            for i, v in u15, v76 do
                                                local v78 = v[6];

                                                if v76 then
                                                    local v79 = v76[i];

                                                    if v79 then
                                                        local v80 = u3(v78);
                                                        u16(u4, i, i + v78 - 1, 1, v80);
                                                        v79[5] = v80;
                                                        v79[4] = 1;
                                                        v76[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(u4[UNNAMED_2819735072264[u5]]);
                                    end;

                                    if v39 == 46 then
                                        u4[UNNAMED_2819735075720[u5]]();
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] ~= UNNAMED_2819735075720[u5];
                                    end;
                                end;
                            elseif v39 < 38 then
                                if v39 < 36 then
                                    u4[UNNAMED_2819735035304[u5]] = u21(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735072264[u5]);
                                elseif v39 == 37 then
                                    if u12 then
                                        local v81 = u12;
                                        local v82 = UNNAMED_2819735072264[u5];
                                        local v83 = v81[v82];

                                        if v83 then
                                            v83[5] = v83;
                                            v83[6] = u4[v82];
                                            v83[4] = 6;
                                            v81[v82] = nil;
                                        end;

                                        local v84 = u12;
                                        local v85 = UNNAMED_2819735075720[u5];
                                        local v86 = v84[v85];

                                        if v86 then
                                            v86[5] = v86;
                                            v86[6] = u4[v85];
                                            v86[4] = 6;
                                            v84[v85] = nil;
                                        end;

                                        local v87 = u12;
                                        local v88 = UNNAMED_2819735035304[u5];
                                        local v89 = v87[v88];

                                        if v89 then
                                            v89[5] = v89;
                                            v89[6] = u4[v88];
                                            v89[4] = 6;
                                            v87[v88] = nil;
                                        end;
                                    end;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735077064[u5]];
                                end;
                            elseif v39 < 39 then
                                v36 = UNNAMED_2819735035304[u5];
                                v34 = UNNAMED_2819735072264[u5];
                                v32 = UNNAMED_2819735075720[u5];
                                v35 = u4[v36];
                                u16(u4, v36 + 1, v36 + v34, v32 + 1, v35);
                            elseif v39 == 40 then
                                u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735035304[u5]]];
                            else
                                u4[UNNAMED_2819735035304[u5]] = u18(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735077064[u5]);
                            end;
                        elseif v39 >= 29 then
                            if v39 >= 32 then
                                if v39 < 33 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] // UNNAMED_2819735072264[u5];
                                elseif v39 == 34 then
                                    v36 = UNNAMED_2819735035304[u5];
                                    v34, v32, v35 = u8();

                                    if v34 then
                                        u4[v36] = v32;
                                        u4[v36 + 1] = v35;
                                        u5 = UNNAMED_2819735075720[u5];
                                    else
                                        u5 = UNNAMED_2819735072264[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735066504[u5]] = u4[UNNAMED_2819735075720[u5]];
                                end;
                            else
                                if v39 >= 30 then
                                    if v39 ~= 31 then
                                        local v90 = u12;
                                        local v91 = u13;

                                        if v90 then
                                            for i in u15, v90 do
                                                local v92 = v90[i];

                                                if v92 then
                                                    v92[5] = v92;
                                                    v92[6] = u4[i];
                                                    v92[4] = 6;
                                                    v90[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v91 then
                                            for i, v in u15, v91 do
                                                local v93 = v[6];

                                                if v91 then
                                                    local v94 = v91[i];

                                                    if v94 then
                                                        local v95 = u3(v93);
                                                        u16(u4, i, i + v93 - 1, 1, v95);
                                                        v94[5] = v95;
                                                        v94[4] = 1;
                                                        v91[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, false;
                                    end;

                                    local v96 = UNNAMED_2819735035304[u5];
                                    local v97 = UNNAMED_2819735072264[u5];
                                    local v98 = v96 + v97;
                                    local v99 = u4[v98];
                                    local n = v99.n;
                                    local v100 = u12;
                                    local v101 = u13;

                                    if v100 then
                                        for i in u15, v100 do
                                            local v102 = v100[i];

                                            if v102 then
                                                v102[5] = v102;
                                                v102[6] = u4[i];
                                                v102[4] = 6;
                                                v100[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v101 then
                                        for i, v in u15, v101 do
                                            local v103 = v[6];

                                            if v101 then
                                                local v104 = v101[i];

                                                if v104 then
                                                    local v105 = u3(v103);
                                                    u16(u4, i, i + v103 - 1, 1, v105);
                                                    v104[5] = v105;
                                                    v104[4] = 1;
                                                    v101[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    v99.n = v97 + n - 1;
                                    u16(v99, 1, n, v97, v99);
                                    u16(u4, v96 + 1, v98 - 1, 1, v99);

                                    return true, true, v96, v99;
                                end;

                                u4[UNNAMED_2819735075720[u5]] = u18(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735035304[u5]);
                            end;
                        elseif v39 < 26 then
                            if v39 < 24 then
                                u2 = u4[UNNAMED_2819735072264[u5]];
                            elseif v39 == 25 then
                                UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735077064[u5];
                            else
                                u24[UNNAMED_2819735066504[u5]] = UNNAMED_2819735050136[u5];
                            end;
                        elseif v39 < 27 then
                            local v106 = nil;
                            local v107 = UNNAMED_2819735035304[u5];
                            local v108 = UNNAMED_2819735066504[u5];
                            local v109 = UNNAMED_2819735077064[u5];
                            local v110 = u12;
                            local v111 = u13;
                            local v112 = v109[0];

                            if v112 then
                                local v113 = #v112 / 3;

                                if v113 > 0 then
                                    v106 = {};

                                    for i = 1, v113 do
                                        local v114 = (i - 1) * 3;
                                        local v115 = v112[v114 + 2];
                                        local v116 = v112[v114 + 1];
                                        local v117;

                                        if v115 == 2 then
                                            v110 = v110 or {};
                                            local v118 = v110[v116];

                                            if not v118 then
                                                v118 = {
                                                    [5] = u4,
                                                    [4] = v116
                                                };
                                                v110[v116] = v118;
                                            end;

                                            v106[i] = v118;
                                            v117 = i;
                                        elseif v115 == 0 then
                                            v106[i] = u4[v116];
                                            v117 = i;
                                        elseif v115 == 3 then
                                            v106[i] = UNNAMED_2819735029544[v116];
                                            v117 = i;
                                        elseif v115 == 1 then
                                            v111 = v111 or {};
                                            local v119 = v111[v116];

                                            if not v119 then
                                                v119 = {
                                                    [5] = u4,
                                                    [4] = v116,
                                                    [6] = v112[v114 + 3]
                                                };
                                                v111[v116] = v119;
                                            end;

                                            v106[i] = v119;
                                            v117 = i;
                                        else
                                            v117 = i;
                                        end;
                                    end;
                                end;
                            end;

                            local v120 = v109[-2];
                            v109[v120] = v106;
                            local v121 = v108(u14(v109, 1, v109[-1]));
                            v109[v120] = nil;
                            u4[v107] = v121;
                            u12 = v110;
                            u13 = v111;
                        elseif v39 == 28 then
                            v36 = UNNAMED_2819735035304[u5];
                            v34 = UNNAMED_2819735075720[u5];
                            v32 = UNNAMED_2819735072264[u5];
                            v35 = u4[v36];
                            v33 = v36 + v34;
                            v37 = u4[v33];
                            u16(u4, v36 + 1, v33 - 1, v32 + 1, v35);
                            u16(v37, 1, v37.n, v32 + v34, v35);
                        else
                            u4[UNNAMED_2819735075720[u5]] = u19(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735066504[u5]);
                        end;
                    elseif v39 < 71 then
                        if v39 < 59 then
                            if v39 >= 53 then
                                if v39 < 56 then
                                    if v39 < 54 then
                                        u4[UNNAMED_2819735072264[u5]](UNNAMED_2819735077064[u5]);
                                    elseif v39 == 55 then
                                        if u4[UNNAMED_2819735072264[u5]] >= UNNAMED_2819735035304[u5] then
                                            u5 = UNNAMED_2819735075720[u5];
                                        end;
                                    else
                                        v36 = UNNAMED_2819735072264[u5] + 1;
                                        v34 = UNNAMED_2819735035304[u5];

                                        for i = 1, UNNAMED_2819735075720[u5] do
                                            local v122 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                            local v123 = u18(v122, (u20(v122, 13)));
                                            v34 = u21(u18(v123, (u22(v123, 14))), 536870911);
                                            UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                            UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                            UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 14), 127)));
                                            UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 21), 127)));
                                            v36 = v36 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735063384[u5] = 16;
                                    end;
                                elseif v39 < 57 then
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] - UNNAMED_2819735050136[u5];
                                elseif v39 == 58 then
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] / UNNAMED_2819735072264[u5];
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u2;
                                end;
                            elseif v39 >= 50 then
                                if v39 < 51 then
                                    local v124 = u12;
                                    local v125 = u13;

                                    if v124 then
                                        for i in u15, v124 do
                                            local v126 = v124[i];

                                            if v126 then
                                                v126[5] = v126;
                                                v126[6] = u4[i];
                                                v126[4] = 6;
                                                v124[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v125 then
                                        for i, v in u15, v125 do
                                            local v127 = v[6];

                                            if v125 then
                                                local v128 = v125[i];

                                                if v128 then
                                                    local v129 = u3(v127);
                                                    u16(u4, i, i + v127 - 1, 1, v129);
                                                    v128[5] = v129;
                                                    v128[4] = 1;
                                                    v125[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u17(UNNAMED_2819735066504[u5], u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n));
                                end;

                                if v39 == 52 then
                                    if u4[UNNAMED_2819735075720[u5]] > u4[UNNAMED_2819735072264[u5]] then
                                        u5 = UNNAMED_2819735035304[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735072264[u5]]);
                                end;
                            elseif v39 >= 48 then
                                if v39 == 49 then
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5] + u4[UNNAMED_2819735072264[u5]];
                                else
                                    u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735072264[u5]]);
                                end;
                            else
                                v36 = UNNAMED_2819735075720[u5];
                                v34 = UNNAMED_2819735035304[u5];
                                v32 = UNNAMED_2819735072264[u5];
                                v35 = v36 + v34;
                                v33 = u4[v35];
                                v37 = v33.n;
                                v33.n = v34 + v37 - 1;
                                u16(v33, 1, v37, v34, v33);
                                u16(u4, v36 + 1, v35 - 1, 1, v33);
                                u4[v36] = u17(u4[v36](u14(v33, 1, v33.n)));
                            end;
                        elseif v39 < 65 then
                            if v39 < 62 then
                                if v39 >= 60 then
                                    if v39 == 61 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]][u4[UNNAMED_2819735072264[u5]]];
                                    else
                                        u5 = u4[UNNAMED_2819735072264[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5] .. u4[UNNAMED_2819735072264[u5]];
                                end;
                            else
                                if v39 < 63 then
                                    local v130 = u12;
                                    local v131 = u13;

                                    if v130 then
                                        for i in u15, v130 do
                                            local v132 = v130[i];

                                            if v132 then
                                                v132[5] = v132;
                                                v132[6] = u4[i];
                                                v132[4] = 6;
                                                v130[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v131 then
                                        for i, v in u15, v131 do
                                            local v133 = v[6];

                                            if v131 then
                                                local v134 = v131[i];

                                                if v134 then
                                                    local v135 = u3(v133);
                                                    u16(u4, i, i + v133 - 1, 1, v135);
                                                    v134[5] = v135;
                                                    v134[4] = 1;
                                                    v131[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u4[UNNAMED_2819735072264[u5]];
                                end;

                                if v39 == 64 then
                                    v36 = u4[UNNAMED_2819735072264[u5]];
                                    u4[UNNAMED_2819735075720[u5]] = u17(u14(v36, UNNAMED_2819735035304[u5], v36.n));
                                else
                                    u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735072264[u5] - u4[UNNAMED_2819735035304[u5]];
                                end;
                            end;
                        elseif v39 >= 68 then
                            if v39 < 69 then
                                local v136 = u12;
                                local v137 = u13;

                                if v136 then
                                    for i in u15, v136 do
                                        local v138 = v136[i];

                                        if v138 then
                                            v138[5] = v138;
                                            v138[6] = u4[i];
                                            v138[4] = 6;
                                            v136[i] = nil;
                                        end;
                                    end;
                                end;

                                if v137 then
                                    for i, v in u15, v137 do
                                        local v139 = v[6];

                                        if v137 then
                                            local v140 = v137[i];

                                            if v140 then
                                                local v141 = u3(v139);
                                                u16(u4, i, i + v139 - 1, 1, v141);
                                                v140[5] = v141;
                                                v140[4] = 1;
                                                v137[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return true, true, UNNAMED_2819735035304[u5], u17(u4[UNNAMED_2819735075720[u5]]);
                            end;

                            if v39 ~= 70 then
                                local v142 = u12;
                                local v143 = u13;

                                if v142 then
                                    for i in u15, v142 do
                                        local v144 = v142[i];

                                        if v144 then
                                            v144[5] = v144;
                                            v144[6] = u4[i];
                                            v144[4] = 6;
                                            v142[i] = nil;
                                        end;
                                    end;
                                end;

                                if v143 then
                                    for i, v in u15, v143 do
                                        local v145 = v[6];

                                        if v143 then
                                            local v146 = v143[i];

                                            if v146 then
                                                local v147 = u3(v145);
                                                u16(u4, i, i + v145 - 1, 1, v147);
                                                v146[5] = v147;
                                                v146[4] = 1;
                                                v143[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return true, true, UNNAMED_2819735072264[u5], u17(u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735075720[u5]]);
                            end;

                            UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735072264[u5]]] = UNNAMED_2819735077064[u5];
                        elseif v39 >= 66 then
                            if v39 == 67 then
                                u4[UNNAMED_2819735075720[u5]](UNNAMED_2819735066504[u5], UNNAMED_2819735050136[u5]);
                            else
                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] == u4[UNNAMED_2819735075720[u5]];
                            end;
                        else
                            v36 = UNNAMED_2819735035304[u5];
                            v34 = u18(u1, u21(u20(u1, 14), 262143), (u21(u20(u1, 28), 15)));
                            v32 = UNNAMED_2819735075720[u5];
                            v35 = UNNAMED_2819735072264[u5];
                            v33 = v36 < 16384 and 7 or (v36 < 2097152 and 14 or 21);
                            v37 = u21(v36, u22(1, v33) - 1);
                            local v148 = u20(v36, v33);
                            UNNAMED_2819735072264[u5] = u18(v35, 116, (u21(u20(v34, 14), 127)));
                            UNNAMED_2819735075720[u5] = u18(v32, 74, (u21(v34, 127)));
                            UNNAMED_2819735035304[u5] = u18(v37, 92, (u21(u20(v34, 7), 127)));
                            UNNAMED_2819735063384[u5] = u18(v148, 66, (u21(u20(v34, 21), 127)));
                            u5 = u5 - 1;
                        end;
                    elseif v39 < 83 then
                        if v39 >= 77 then
                            if v39 < 80 then
                                if v39 < 78 then
                                    u4[UNNAMED_2819735072264[u5]] = u24[UNNAMED_2819735077064[u5]];
                                elseif v39 == 79 then
                                    v36 = UNNAMED_2819735035304[u5];
                                    local v149 = u4[UNNAMED_2819735075720[u5]];
                                    u4[v36] = UNNAMED_2819735066504[u5];
                                    u4[v36 + 1] = v149;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] % u4[UNNAMED_2819735075720[u5]];
                                end;
                            elseif v39 < 81 then
                                u4[UNNAMED_2819735075720[u5]] = -u4[UNNAMED_2819735035304[u5]];
                            elseif v39 == 82 then
                                u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] > UNNAMED_2819735072264[u5];
                            else
                                u4[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735075720[u5]]] = u4[UNNAMED_2819735072264[u5]];
                            end;
                        elseif v39 < 74 then
                            if v39 < 72 then
                                u4[UNNAMED_2819735072264[u5]] = u20(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735075720[u5]);
                            elseif v39 == 73 then
                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] > UNNAMED_2819735077064[u5];
                            else
                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]] * UNNAMED_2819735050136[u5];
                            end;
                        elseif v39 < 75 then
                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]] .. UNNAMED_2819735050136[u5];
                        else
                            if v39 ~= 76 then
                                local v150 = u12;
                                local v151 = u13;

                                if v150 then
                                    for i in u15, v150 do
                                        local v152 = v150[i];

                                        if v152 then
                                            v152[5] = v152;
                                            v152[6] = u4[i];
                                            v152[4] = 6;
                                            v150[i] = nil;
                                        end;
                                    end;
                                end;

                                if v151 then
                                    for i, v in u15, v151 do
                                        local v153 = v[6];

                                        if v151 then
                                            local v154 = v151[i];

                                            if v154 then
                                                local v155 = u3(v153);
                                                u16(u4, i, i + v153 - 1, 1, v155);
                                                v154[5] = v155;
                                                v154[4] = 1;
                                                v151[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return false, true, u17(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735050136[u5]);
                            end;

                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] + u4[UNNAMED_2819735035304[u5]];
                        end;
                    elseif v39 >= 89 then
                        if v39 >= 92 then
                            if v39 < 93 then
                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] + UNNAMED_2819735066504[u5];
                            elseif v39 == 94 then
                                v36 = UNNAMED_2819735075720[u5];
                                local v156 = u4[UNNAMED_2819735072264[u5]];
                                u4[v36] = UNNAMED_2819735035304[u5];
                                u4[v36 + 1] = v156;
                            else
                                local v157;

                                if u4[UNNAMED_2819735075720[u5]] then
                                    v157 = UNNAMED_2819735072264[u5];
                                else
                                    v157 = UNNAMED_2819735035304[u5];
                                end;

                                u5 = v157;
                            end;
                        elseif v39 >= 90 then
                            if v39 == 91 then
                                local v158 = u12;
                                local v159 = u13;

                                if v158 then
                                    for i in u15, v158 do
                                        local v160 = v158[i];

                                        if v160 then
                                            v160[5] = v160;
                                            v160[6] = u4[i];
                                            v160[4] = 6;
                                            v158[i] = nil;
                                        end;
                                    end;
                                end;

                                if v159 then
                                    for i, v in u15, v159 do
                                        local v161 = v[6];

                                        if v159 then
                                            local v162 = v159[i];

                                            if v162 then
                                                local v163 = u3(v161);
                                                u16(u4, i, i + v161 - 1, 1, v163);
                                                v162[5] = v163;
                                                v162[4] = 1;
                                                v159[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return true, true, UNNAMED_2819735075720[u5], u4[UNNAMED_2819735035304[u5]];
                            end;

                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] % UNNAMED_2819735050136[u5];
                        else
                            v36 = UNNAMED_2819735075720[u5];
                            local v164 = UNNAMED_2819735072264[u5];
                            u4[v36] = UNNAMED_2819735035304[u5];
                            u4[v36 + 1] = v164;
                        end;
                    elseif v39 < 86 then
                        if v39 < 84 then
                            local v165 = u12;
                            local v166 = u13;

                            if v165 then
                                for i in u15, v165 do
                                    local v167 = v165[i];

                                    if v167 then
                                        v167[5] = v167;
                                        v167[6] = u4[i];
                                        v167[4] = 6;
                                        v165[i] = nil;
                                    end;
                                end;
                            end;

                            if v166 then
                                for i, v in u15, v166 do
                                    local v168 = v[6];

                                    if v166 then
                                        local v169 = v166[i];

                                        if v169 then
                                            local v170 = u3(v168);
                                            u16(u4, i, i + v168 - 1, 1, v170);
                                            v169[5] = v170;
                                            v169[4] = 1;
                                            v166[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return false, true, u17(UNNAMED_2819735077064[u5]);
                        end;

                        if v39 == 85 then
                            v36 = UNNAMED_2819735035304[u5];
                            local v171 = UNNAMED_2819735075720[u5];
                            u4[v36] = u4[UNNAMED_2819735072264[u5]];
                            u4[v36 + 1] = v171;
                        else
                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] * UNNAMED_2819735072264[u5];
                        end;
                    elseif v39 >= 87 then
                        if v39 == 88 then
                            v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                            v36[5][v36[4]] = u4[UNNAMED_2819735072264[u5]];
                        else
                            u8 = u7[8];
                            u9 = u7[5];
                            u10 = u7[7];
                            u11 = u7[6];
                            u7 = u7[9];
                        end;
                    else
                        u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735072264[u5] + u4[UNNAMED_2819735035304[u5]];
                    end;
                elseif v39 < 142 then
                    if v39 < 118 then
                        if v39 < 106 then
                            if v39 < 100 then
                                if v39 >= 97 then
                                    if v39 >= 98 then
                                        if v39 == 99 then
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] % UNNAMED_2819735072264[u5];
                                        else
                                            UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735077064[u5]] = u4[UNNAMED_2819735072264[u5]];
                                        end;
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] < u4[UNNAMED_2819735075720[u5]];
                                    end;
                                elseif v39 == 96 then
                                    local v172 = u4[UNNAMED_2819735035304[u5]] % 4294967296;
                                    u4[UNNAMED_2819735072264[u5]] = v172 ~= v172 and 0 or v172 - v172 % 1;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u22(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735075720[u5]);
                                end;
                            elseif v39 < 103 then
                                if v39 >= 101 then
                                    if v39 == 102 then
                                        u5 = u4[UNNAMED_2819735075720[u5]];
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = u17(u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735077064[u5]));
                                    end;
                                else
                                    local v173 = UNNAMED_2819735075720[u5];
                                    local v174 = UNNAMED_2819735035304[u5];
                                    local v175, v176 = u4[UNNAMED_2819735072264[u5]]();
                                    u4[v173] = v175;
                                    u4[v174] = v176;
                                end;
                            elseif v39 < 104 then
                                u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735035304[u5]], u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                            elseif v39 == 105 then
                                u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735077064[u5]] = UNNAMED_2819735072264[u5];
                            else
                                v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                v36[5][v36[4]][UNNAMED_2819735077064[u5]] = UNNAMED_2819735066504[u5];
                            end;
                        elseif v39 >= 112 then
                            if v39 < 115 then
                                if v39 < 113 then
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735066504[u5]);
                                else
                                    if v39 == 114 then
                                        local v177 = u12;
                                        local v178 = u13;

                                        if v177 then
                                            for i in u15, v177 do
                                                local v179 = v177[i];

                                                if v179 then
                                                    v179[5] = v179;
                                                    v179[6] = u4[i];
                                                    v179[4] = 6;
                                                    v177[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v178 then
                                            for i, v in u15, v178 do
                                                local v180 = v[6];

                                                if v178 then
                                                    local v181 = v178[i];

                                                    if v181 then
                                                        local v182 = u3(v180);
                                                        u16(u4, i, i + v180 - 1, 1, v182);
                                                        v181[5] = v182;
                                                        v181[4] = 1;
                                                        v178[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819735072264[u5], u17();
                                    end;

                                    v36 = UNNAMED_2819735075720[u5];
                                    local v183 = UNNAMED_2819735066504[u5];
                                    u4[v36] = UNNAMED_2819735035304[u5];
                                    u4[v36 + 1] = v183;
                                end;
                            elseif v39 >= 116 then
                                if v39 == 117 then
                                    u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]];
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u25(u4[UNNAMED_2819735075720[u5]]);
                                end;
                            else
                                u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]];
                            end;
                        elseif v39 < 109 then
                            if v39 >= 107 then
                                if v39 ~= 108 then
                                    local v184 = u12;
                                    local v185 = u13;

                                    if v184 then
                                        for i in u15, v184 do
                                            local v186 = v184[i];

                                            if v186 then
                                                v186[5] = v186;
                                                v186[6] = u4[i];
                                                v186[4] = 6;
                                                v184[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v185 then
                                        for i, v in u15, v185 do
                                            local v187 = v[6];

                                            if v185 then
                                                local v188 = v185[i];

                                                if v188 then
                                                    local v189 = u3(v187);
                                                    u16(u4, i, i + v187 - 1, 1, v189);
                                                    v188[5] = v189;
                                                    v188[4] = 1;
                                                    v185[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819735072264[u5], u17(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735077064[u5]);
                                end;

                                u7 = {
                                    [6] = u11,
                                    [5] = u9,
                                    [9] = u7,
                                    [8] = u8,
                                    [7] = u10
                                };
                                v36 = UNNAMED_2819735035304[u5];
                                u10 = u4[v36 + 2] + 0;
                                u9 = u4[v36 + 1] + 0;
                                u8 = u4[v36] - u10;
                                u5 = UNNAMED_2819735075720[u5];
                            elseif UNNAMED_2819735077064[u5] >= u4[UNNAMED_2819735072264[u5]] then
                                u5 = UNNAMED_2819735035304[u5];
                            end;
                        elseif v39 >= 110 then
                            if v39 == 111 then
                                if u4[UNNAMED_2819735072264[u5]] >= u4[UNNAMED_2819735035304[u5]] then
                                    u5 = UNNAMED_2819735075720[u5];
                                end;
                            else
                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735075720[u5]]);
                            end;
                        else
                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735066504[u5] * u4[UNNAMED_2819735075720[u5]];
                        end;
                    elseif v39 >= 130 then
                        if v39 >= 136 then
                            if v39 >= 139 then
                                if v39 < 140 then
                                    local v190 = u12;
                                    local v191 = u13;

                                    if v190 then
                                        for i in u15, v190 do
                                            local v192 = v190[i];

                                            if v192 then
                                                v192[5] = v192;
                                                v192[6] = u4[i];
                                                v192[4] = 6;
                                                v190[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v191 then
                                        for i, v in u15, v191 do
                                            local v193 = v[6];

                                            if v191 then
                                                local v194 = v191[i];

                                                if v194 then
                                                    local v195 = u3(v193);
                                                    u16(u4, i, i + v193 - 1, 1, v195);
                                                    v194[5] = v195;
                                                    v194[4] = 1;
                                                    v191[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u17(UNNAMED_2819735050136[u5], UNNAMED_2819735077064[u5]);
                                end;

                                if v39 == 141 then
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5];
                                else
                                    v36 = UNNAMED_2819735075720[u5] + 1;
                                    v34 = u18(UNNAMED_2819735035304[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));

                                    for i = 1, UNNAMED_2819735072264[u5] do
                                        local v196 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                        local v197 = u18(v196, (u20(v196, 13)));
                                        v34 = u21(u18(v197, (u22(v197, 14))), 536870911);
                                        UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                        UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                        UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 14), 127)));
                                        UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 21), 127)));
                                        v36 = v36 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735063384[u5] = 16;
                                end;
                            elseif v39 < 137 then
                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]][UNNAMED_2819735072264[u5]];
                            elseif v39 == 138 then
                                v36 = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]];
                                v36[5][v36[4]] = UNNAMED_2819735077064[u5];
                            else
                                UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735035304[u5];
                            end;
                        elseif v39 < 133 then
                            if v39 < 131 then
                                u4[UNNAMED_2819735075720[u5]](u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                            else
                                if v39 == 132 then
                                    local v198 = u12;
                                    local v199 = u13;

                                    if v198 then
                                        for i in u15, v198 do
                                            local v200 = v198[i];

                                            if v200 then
                                                v200[5] = v200;
                                                v200[6] = u4[i];
                                                v200[4] = 6;
                                                v198[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v199 then
                                        for i, v in u15, v199 do
                                            local v201 = v[6];

                                            if v199 then
                                                local v202 = v199[i];

                                                if v202 then
                                                    local v203 = u3(v201);
                                                    u16(u4, i, i + v201 - 1, 1, v203);
                                                    v202[5] = v203;
                                                    v202[4] = 1;
                                                    v199[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819735075720[u5], u17(UNNAMED_2819735066504[u5], u4[UNNAMED_2819735035304[u5]]);
                                end;

                                u4[UNNAMED_2819735072264[u5]] = u24[UNNAMED_2819735077064[u5]][u4[UNNAMED_2819735035304[u5]]];
                            end;
                        elseif v39 >= 134 then
                            if v39 == 135 then
                                u4[UNNAMED_2819735072264[u5]] = u17(u4[UNNAMED_2819735075720[u5]]());
                            else
                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]]();
                            end;
                        else
                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] * u4[UNNAMED_2819735072264[u5]];
                        end;
                    elseif v39 < 124 then
                        if v39 >= 121 then
                            if v39 < 122 then
                                u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735072264[u5] ^ u4[UNNAMED_2819735035304[u5]];
                            elseif v39 == 123 then
                                u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735066504[u5]];
                            else
                                local v204 = UNNAMED_2819735035304[u5];
                                local v205 = UNNAMED_2819735072264[u5];
                                local v206 = UNNAMED_2819735058152[5];
                                local v207 = u18(v206[v204], 109162203);
                                v206[v204] = v207;
                                local v208 = UNNAMED_2819735058152[4];
                                local v209 = v207 + 1;
                                local v210 = u28(v208, v209);
                                local v211;

                                if v210 < 128 then
                                    v211 = v209 + 1;
                                else
                                    local v212 = u28(v208, v209 + 1);

                                    if v212 < 128 then
                                        v210 = v210 - 128 + v212 * 128;
                                        v211 = v209 + 2;
                                    else
                                        local v213 = u28(v208, v209 + 2);

                                        if v213 < 128 then
                                            v210 = v210 - 128 + (v212 - 128) * 16384 + v213 * 128;
                                            v211 = v209 + 3;
                                        else
                                            local v214 = u28(v208, v209 + 3);
                                            v210 = (v210 - 128) * 16384 + (v212 - 128) * 128 + (v213 - 128) + v214 % 128 * 2097152 + (v214 - v214 % 128) * 2097152;
                                            v211 = v209 + 4;
                                        end;
                                    end;
                                end;

                                local v215 = v205 * 16843009;
                                local v216 = v211 + v210;
                                local v217 = v216 - v210 % 4;

                                for i = v211, v217 - 1, 4 do
                                    u29(v208, i, (u18(u30(v208, i), v215)));
                                    local _ = i;
                                end;

                                for i = v217, v216 - 1 do
                                    u31(v208, i, (u18(u28(v208, i), v205)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735035304[u5] = 229;
                                UNNAMED_2819735072264[u5] = 199;
                                UNNAMED_2819735075720[u5] = 60;
                                UNNAMED_2819735063384[u5] = 16;
                            end;
                        elseif v39 >= 119 then
                            if v39 == 120 then
                                UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735072264[u5]]] = u4[UNNAMED_2819735075720[u5]];
                            else
                                u4[UNNAMED_2819735035304[u5]] = u19(u4[UNNAMED_2819735075720[u5]], u4[UNNAMED_2819735072264[u5]]);
                            end;
                        else
                            u5 = UNNAMED_2819735075720[u5];
                        end;
                    elseif v39 >= 127 then
                        if v39 < 128 then
                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] .. u4[UNNAMED_2819735075720[u5]];
                        elseif v39 == 129 then
                            u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                        else
                            local v218;

                            if u4[UNNAMED_2819735035304[u5]] then
                                v218 = UNNAMED_2819735072264[u5];
                            else
                                v218 = UNNAMED_2819735075720[u5];
                            end;

                            u5 = v218;
                        end;
                    elseif v39 < 125 then
                        u4[UNNAMED_2819735072264[u5]] = u1;
                    elseif v39 == 126 then
                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]](u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                    else
                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] / UNNAMED_2819735077064[u5];
                    end;
                elseif v39 < 166 then
                    if v39 < 154 then
                        if v39 < 148 then
                            if v39 >= 145 then
                                if v39 < 146 then
                                    u4[UNNAMED_2819735072264[u5]] = u18(u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735075720[u5]]);
                                elseif v39 == 147 then
                                    u4[UNNAMED_2819735072264[u5]](UNNAMED_2819735077064[u5], u4[UNNAMED_2819735035304[u5]]);
                                else
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] >= UNNAMED_2819735035304[u5];
                                end;
                            elseif v39 >= 143 then
                                if v39 == 144 then
                                    v36 = UNNAMED_2819735075720[u5];
                                    v34 = u4[UNNAMED_2819735072264[u5]];
                                    u4[v36 + 1] = v34;
                                    u4[v36] = v34[UNNAMED_2819735050136[u5]];
                                else
                                    v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                    u4[UNNAMED_2819735075720[u5]] = v36[5][v36[4]][UNNAMED_2819735066504[u5]];
                                end;
                            else
                                u4[UNNAMED_2819735075720[u5]] = u4;
                            end;
                        elseif v39 >= 151 then
                            if v39 >= 152 then
                                if v39 == 153 then
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] == UNNAMED_2819735035304[u5];
                                else
                                    v36 = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]];
                                    u4[UNNAMED_2819735035304[u5]] = v36[5][v36[4]];
                                end;
                            else
                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] / u4[UNNAMED_2819735075720[u5]];
                            end;
                        elseif v39 >= 149 then
                            if v39 ~= 150 then
                                local v219 = UNNAMED_2819735072264[u5];
                                local v220 = v219 + UNNAMED_2819735075720[u5];
                                local v221 = u12;
                                local v222 = u13;

                                if v221 then
                                    for i in u15, v221 do
                                        local v223 = v221[i];

                                        if v223 then
                                            v223[5] = v223;
                                            v223[6] = u4[i];
                                            v223[4] = 6;
                                            v221[i] = nil;
                                        end;
                                    end;
                                end;

                                if v222 then
                                    for i, v in u15, v222 do
                                        local v224 = v[6];

                                        if v222 then
                                            local v225 = v222[i];

                                            if v225 then
                                                local v226 = u3(v224);
                                                u16(u4, i, i + v224 - 1, 1, v226);
                                                v225[5] = v226;
                                                v225[4] = 1;
                                                v222[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return true, false, v219, v220;
                            end;

                            u7 = {
                                [6] = u11,
                                [5] = u9,
                                [9] = u7,
                                [8] = u8,
                                [7] = u10
                            };
                            v36 = UNNAMED_2819735035304[u5];
                            v34 = u26(u27);
                            v34(UNNAMED_2819735088728, u4[v36], u4[v36 + 1], u4[v36 + 2]);
                            u8 = v34;
                            u11 = UNNAMED_2819735072264[u5];
                            u5 = UNNAMED_2819735075720[u5];
                        else
                            local v227 = UNNAMED_2819735075720[u5];
                            local v228 = u18(UNNAMED_2819735035304[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));
                            local v229 = UNNAMED_2819735058152[5];
                            local v230 = u18(v229[v227], 109162203);
                            v229[v227] = v230;
                            local v231 = UNNAMED_2819735058152[4];
                            local v232 = v230 + 1;
                            local v233 = u28(v231, v232);
                            local v234;

                            if v233 < 128 then
                                v234 = v232 + 1;
                            else
                                local v235 = u28(v231, v232 + 1);

                                if v235 < 128 then
                                    v233 = v233 - 128 + v235 * 128;
                                    v234 = v232 + 2;
                                else
                                    local v236 = u28(v231, v232 + 2);

                                    if v236 < 128 then
                                        v233 = v233 - 128 + (v235 - 128) * 16384 + v236 * 128;
                                        v234 = v232 + 3;
                                    else
                                        local v237 = u28(v231, v232 + 3);
                                        v233 = (v233 - 128) * 16384 + (v235 - 128) * 128 + (v236 - 128) + v237 % 128 * 2097152 + (v237 - v237 % 128) * 2097152;
                                        v234 = v232 + 4;
                                    end;
                                end;
                            end;

                            local v238 = v228 * 16843009;
                            local v239 = v234 + v233;
                            local v240 = v239 - v233 % 4;

                            for i = v234, v240 - 1, 4 do
                                u29(v231, i, (u18(u30(v231, i), v238)));
                                local _ = i;
                            end;

                            for i = v240, v239 - 1 do
                                u31(v231, i, (u18(u28(v231, i), v228)));
                                local _ = i;
                            end;

                            UNNAMED_2819735075720[u5] = 113;
                            UNNAMED_2819735035304[u5] = 125;
                            UNNAMED_2819735072264[u5] = 38;
                            UNNAMED_2819735063384[u5] = 16;
                        end;
                    elseif v39 < 160 then
                        if v39 < 157 then
                            if v39 >= 155 then
                                if v39 == 156 then
                                    local v241 = UNNAMED_2819735035304[u5];
                                    local v242 = UNNAMED_2819735077064[u5];
                                    local v243 = u21(UNNAMED_2819735066504[u5], 4294967295);
                                    local v244 = u21(v242, 4294967295);
                                    local v245 = u21(v243, 65535);
                                    local v246 = u20(v243, 16);
                                    local v247 = u21(v244, 65535);
                                    local v248 = u20(v244, 16);
                                    local v249 = u21(v245 * v247 + u22(u21(v245 * v248 + v246 * v247, 65535), 16), 4294967295) % 4294967296;
                                    u4[v241] = v249 ~= v249 and 0 or v249 - v249 % 1;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] - UNNAMED_2819735075720[u5];
                                end;
                            else
                                u4[UNNAMED_2819735035304[u5]] = u21(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735077064[u5]);
                            end;
                        elseif v39 >= 158 then
                            if v39 == 159 then
                                local v250 = u12;
                                local v251 = u13;

                                if v250 then
                                    for i in u15, v250 do
                                        local v252 = v250[i];

                                        if v252 then
                                            v252[5] = v252;
                                            v252[6] = u4[i];
                                            v252[4] = 6;
                                            v250[i] = nil;
                                        end;
                                    end;
                                end;

                                if v251 then
                                    for i, v in u15, v251 do
                                        local v253 = v[6];

                                        if v251 then
                                            local v254 = v251[i];

                                            if v254 then
                                                local v255 = u3(v253);
                                                u16(u4, i, i + v253 - 1, 1, v255);
                                                v254[5] = v255;
                                                v254[4] = 1;
                                                v251[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                local v256 = UNNAMED_2819735072264[u5];
                                local v257 = UNNAMED_2819735075720[u5];
                                local v258 = v256 + v257 - 1;
                                local v259 = u4[v258];
                                local n = v259.n;
                                v259.n = v257 + n - 1;
                                u16(v259, 1, n, v257, v259);
                                u16(u4, v256, v258 - 1, 1, v259);

                                return false, true, v259;
                            end;

                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735066504[u5] - u4[UNNAMED_2819735075720[u5]];
                        elseif UNNAMED_2819735072264[u5] >= u4[UNNAMED_2819735035304[u5]] then
                            u5 = UNNAMED_2819735075720[u5];
                        end;
                    elseif v39 < 163 then
                        if v39 >= 161 then
                            if v39 ~= 162 then
                                local v260 = u12;
                                local v261 = u13;

                                if v260 then
                                    for i in u15, v260 do
                                        local v262 = v260[i];

                                        if v262 then
                                            v262[5] = v262;
                                            v262[6] = u4[i];
                                            v262[4] = 6;
                                            v260[i] = nil;
                                        end;
                                    end;
                                end;

                                if v261 then
                                    for i, v in u15, v261 do
                                        local v263 = v[6];

                                        if v261 then
                                            local v264 = v261[i];

                                            if v264 then
                                                local v265 = u3(v263);
                                                u16(u4, i, i + v263 - 1, 1, v265);
                                                v264[5] = v265;
                                                v264[4] = 1;
                                                v261[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return false, true, u17(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735066504[u5], UNNAMED_2819735050136[u5]);
                            end;

                            if u12 then
                                local v266 = u12;
                                local v267 = UNNAMED_2819735072264[u5];
                                local v268 = v266[v267];

                                if v268 then
                                    v268[5] = v268;
                                    v268[6] = u4[v267];
                                    v268[4] = 6;
                                    v266[v267] = nil;
                                end;

                                local v269 = u12;
                                local v270 = UNNAMED_2819735035304[u5];
                                local v271 = v269[v270];

                                if v271 then
                                    v271[5] = v271;
                                    v271[6] = u4[v270];
                                    v271[4] = 6;
                                    v269[v270] = nil;
                                end;
                            end;
                        else
                            u4[UNNAMED_2819735075720[u5]] = not u4[UNNAMED_2819735035304[u5]];
                        end;
                    elseif v39 >= 164 then
                        if v39 == 165 then
                            v36 = UNNAMED_2819735075720[u5];
                            v34 = UNNAMED_2819735072264[u5];
                            v32 = UNNAMED_2819735035304[u5];
                            v35 = v36 + v32 - 1;
                            v33 = v36 + v34;
                            v37 = u4[v33];
                            local n = v37.n;
                            v37.n = v34 + n - 1;
                            u16(v37, 1, n, v34, v37);
                            u16(u4, v36 + 1, v33 - 1, 1, v37);
                            u16(u17(u4[v36](u14(v37, 1, v37.n))), 1, v32, v36, u4);
                        else
                            u4[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735035304[u5]]] = UNNAMED_2819735077064[u5];
                        end;
                    else
                        u4[UNNAMED_2819735035304[u5]] = u24[UNNAMED_2819735066504[u5]][UNNAMED_2819735077064[u5]];
                    end;
                elseif v39 >= 178 then
                    if v39 >= 184 then
                        if v39 >= 187 then
                            if v39 < 188 then
                                if u12 then
                                    local v272 = u12;
                                    local v273 = UNNAMED_2819735035304[u5];
                                    local v274 = v272[v273];

                                    if v274 then
                                        v274[5] = v274;
                                        v274[6] = u4[v273];
                                        v274[4] = 6;
                                        v272[v273] = nil;
                                    end;
                                end;
                            elseif v39 == 189 then
                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] + UNNAMED_2819735075720[u5];
                            elseif u4[UNNAMED_2819735072264[u5]] > UNNAMED_2819735075720[u5] then
                                u5 = UNNAMED_2819735035304[u5];
                            end;
                        elseif v39 >= 185 then
                            if v39 == 186 then
                                v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                v36[5][v36[4]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735072264[u5]];
                            else
                                local v275 = UNNAMED_2819735075720[u5];
                                local v276 = UNNAMED_2819735035304[u5];
                                local v277 = u21(u4[UNNAMED_2819735072264[u5]], 4294967295);
                                local v278 = u21(v276, 4294967295);
                                local v279 = u21(v277, 65535);
                                local v280 = u20(v277, 16);
                                local v281 = u21(v278, 65535);
                                local v282 = u20(v278, 16);
                                local v283 = u21(v279 * v281 + u22(u21(v279 * v282 + v280 * v281, 65535), 16), 4294967295) % 4294967296;
                                u4[v275] = v283 ~= v283 and 0 or v283 - v283 % 1;
                            end;
                        else
                            u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735072264[u5]](u4[UNNAMED_2819735075720[u5]]));
                        end;
                    elseif v39 < 181 then
                        if v39 < 179 then
                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] == UNNAMED_2819735050136[u5];
                        elseif v39 == 180 then
                            u4[UNNAMED_2819735075720[u5]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735066504[u5];
                        else
                            local v284 = UNNAMED_2819735075720[u5];
                            local v285 = u18(UNNAMED_2819735035304[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));
                            local v286 = UNNAMED_2819735058152[5];
                            local v287 = u18(v286[v284], 109162203);
                            v286[v284] = v287;
                            local v288 = UNNAMED_2819735058152[4];
                            local v289 = v287 + 1;
                            local v290 = u28(v288, v289);
                            local v291;

                            if v290 < 128 then
                                v291 = v289 + 1;
                            else
                                local v292 = u28(v288, v289 + 1);

                                if v292 < 128 then
                                    v290 = v290 - 128 + v292 * 128;
                                    v291 = v289 + 2;
                                else
                                    local v293 = u28(v288, v289 + 2);

                                    if v293 < 128 then
                                        v290 = v290 - 128 + (v292 - 128) * 16384 + v293 * 128;
                                        v291 = v289 + 3;
                                    else
                                        local v294 = u28(v288, v289 + 3);
                                        v290 = (v290 - 128) * 16384 + (v292 - 128) * 128 + (v293 - 128) + v294 % 128 * 2097152 + (v294 - v294 % 128) * 2097152;
                                        v291 = v289 + 4;
                                    end;
                                end;
                            end;

                            local v295 = v285 * 16843009;
                            local v296 = v291 + v290;
                            local v297 = v296 - v290 % 4;

                            for i = v291, v297 - 1, 4 do
                                u29(v288, i, (u18(u30(v288, i), v295)));
                                local _ = i;
                            end;

                            for i = v297, v296 - 1 do
                                u31(v288, i, (u18(u28(v288, i), v285)));
                                local _ = i;
                            end;

                            UNNAMED_2819735075720[u5] = 249;
                            UNNAMED_2819735035304[u5] = 231;
                            UNNAMED_2819735072264[u5] = 181;
                            UNNAMED_2819735063384[u5] = 16;
                        end;
                    elseif v39 >= 182 then
                        if v39 == 183 then
                            u1 = u4[UNNAMED_2819735075720[u5]];
                        else
                            u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735075720[u5];
                        end;
                    elseif u4[UNNAMED_2819735075720[u5]] ~= UNNAMED_2819735050136[u5] then
                        u5 = UNNAMED_2819735072264[u5];
                    end;
                elseif v39 >= 172 then
                    if v39 < 175 then
                        if v39 < 173 then
                            local v298 = u12;
                            local v299 = u13;

                            if v298 then
                                for i in u15, v298 do
                                    local v300 = v298[i];

                                    if v300 then
                                        v300[5] = v300;
                                        v300[6] = u4[i];
                                        v300[4] = 6;
                                        v298[i] = nil;
                                    end;
                                end;
                            end;

                            if v299 then
                                for i, v in u15, v299 do
                                    local v301 = v[6];

                                    if v299 then
                                        local v302 = v299[i];

                                        if v302 then
                                            local v303 = u3(v301);
                                            u16(u4, i, i + v301 - 1, 1, v303);
                                            v302[5] = v303;
                                            v302[4] = 1;
                                            v299[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return true, true, UNNAMED_2819735072264[u5], u17(UNNAMED_2819735077064[u5]);
                        end;

                        if v39 == 174 then
                            local v304 = u12;
                            local v305 = u13;

                            if v304 then
                                for i in u15, v304 do
                                    local v306 = v304[i];

                                    if v306 then
                                        v306[5] = v306;
                                        v306[6] = u4[i];
                                        v306[4] = 6;
                                        v304[i] = nil;
                                    end;
                                end;
                            end;

                            if v305 then
                                for i, v in u15, v305 do
                                    local v307 = v[6];

                                    if v305 then
                                        local v308 = v305[i];

                                        if v308 then
                                            local v309 = u3(v307);
                                            u16(u4, i, i + v307 - 1, 1, v309);
                                            v308[5] = v309;
                                            v308[4] = 1;
                                            v305[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return false, true, u17(UNNAMED_2819735077064[u5], u4[UNNAMED_2819735035304[u5]]);
                        end;

                        u24[UNNAMED_2819735077064[u5]] = u4[UNNAMED_2819735035304[u5]];
                    elseif v39 < 176 then
                        if u4[UNNAMED_2819735075720[u5]] ~= UNNAMED_2819735035304[u5] then
                            u5 = UNNAMED_2819735072264[u5];
                        end;
                    else
                        if v39 ~= 177 then
                            local v310 = u12;
                            local v311 = u13;

                            if v310 then
                                for i in u15, v310 do
                                    local v312 = v310[i];

                                    if v312 then
                                        v312[5] = v312;
                                        v312[6] = u4[i];
                                        v312[4] = 6;
                                        v310[i] = nil;
                                    end;
                                end;
                            end;

                            if v311 then
                                for i, v in u15, v311 do
                                    local v313 = v[6];

                                    if v311 then
                                        local v314 = v311[i];

                                        if v314 then
                                            local v315 = u3(v313);
                                            u16(u4, i, i + v313 - 1, 1, v315);
                                            v314[5] = v315;
                                            v314[4] = 1;
                                            v311[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return false, true, u17(u4[UNNAMED_2819735072264[u5]], u4[UNNAMED_2819735035304[u5]]);
                        end;

                        u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735066504[u5]);
                    end;
                elseif v39 >= 169 then
                    if v39 >= 170 then
                        if v39 ~= 171 then
                            local v316 = u12;
                            local v317 = u13;

                            if v316 then
                                for i in u15, v316 do
                                    local v318 = v316[i];

                                    if v318 then
                                        v318[5] = v318;
                                        v318[6] = u4[i];
                                        v318[4] = 6;
                                        v316[i] = nil;
                                    end;
                                end;
                            end;

                            if v317 then
                                for i, v in u15, v317 do
                                    local v319 = v[6];

                                    if v317 then
                                        local v320 = v317[i];

                                        if v320 then
                                            local v321 = u3(v319);
                                            u16(u4, i, i + v319 - 1, 1, v321);
                                            v320[5] = v321;
                                            v320[4] = 1;
                                            v317[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return true, true, UNNAMED_2819735072264[u5], u17(u4[UNNAMED_2819735075720[u5]], u14(u4[UNNAMED_2819735035304[u5]], 1, u4[UNNAMED_2819735035304[u5]].n));
                        end;

                        if UNNAMED_2819735066504[u5] > u4[UNNAMED_2819735075720[u5]] then
                            u5 = UNNAMED_2819735035304[u5];
                        end;
                    else
                        u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] < UNNAMED_2819735066504[u5];
                    end;
                elseif v39 >= 167 then
                    if v39 == 168 then
                        v36 = UNNAMED_2819735035304[u5];
                        local v322 = UNNAMED_2819735077064[u5];
                        u4[v36] = UNNAMED_2819735066504[u5];
                        u4[v36 + 1] = v322;
                    else
                        u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] ~= UNNAMED_2819735050136[u5];
                    end;
                else
                    v36 = UNNAMED_2819735075720[u5] + 1;
                    v34 = u18(UNNAMED_2819735035304[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));

                    for i = 1, UNNAMED_2819735072264[u5] do
                        local v323 = u21(u18(v34, (u22(v34, 13))), 536870911);
                        local v324 = u18(v323, (u20(v323, 13)));
                        v34 = u21(u18(v324, (u22(v324, 14))), 536870911);
                        UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                        UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                        UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 14), 127)));
                        UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 21), 127)));
                        v36 = v36 + 1;
                        local _ = i;
                    end;

                    UNNAMED_2819735063384[u5] = 16;
                end;

                u5 = u5 + 1;
            end;

            v38 = 4;
            continue;
        elseif v38 == 4 then
            v38 = -1;

            while true do
                local u5;
                local v325 = 0;

                while true do
                    if v325 == 0 then
                        v325 = -1;
                        local v326 = UNNAMED_2819735072264[u5];

                        if v326 < 103 then
                            if v326 >= 51 then
                                if v326 >= 77 then
                                    if v326 < 90 then
                                        if v326 >= 83 then
                                            if v326 >= 86 then
                                                if v326 >= 88 then
                                                    if v326 == 89 then
                                                        v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                                        v36[5][v36[4]][UNNAMED_2819735088680[u5]] = UNNAMED_2819735075720[u5];
                                                    else
                                                        local v327 = UNNAMED_2819735063384[u5];
                                                        local v328 = UNNAMED_2819735077064[u5];
                                                        local v329 = u21(UNNAMED_2819735050136[u5], 4294967295);
                                                        local v330 = u21(v328, 4294967295);
                                                        local v331 = u21(v329, 65535);
                                                        local v332 = u20(v329, 16);
                                                        local v333 = u21(v330, 65535);
                                                        local v334 = u20(v330, 16);
                                                        local v335 = u21(v331 * v333 + u22(u21(v331 * v334 + v332 * v333, 65535), 16), 4294967295) % 4294967296;
                                                        u4[v327] = v335 ~= v335 and 0 or v335 - v335 % 1;
                                                    end;
                                                elseif v326 == 87 then
                                                    v36 = u4[UNNAMED_2819735075720[u5]];
                                                    u4[UNNAMED_2819735035304[u5]] = u17(u14(v36, UNNAMED_2819735063384[u5], v36.n));
                                                else
                                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735063384[u5]] % UNNAMED_2819735035304[u5];
                                                end;
                                            elseif v326 >= 84 then
                                                if v326 == 85 then
                                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735077064[u5];
                                                else
                                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]];
                                                    v36 = UNNAMED_2819735035304[u5 + 1];
                                                    v34 = UNNAMED_2819735063384[u5 + 1];
                                                    v32 = UNNAMED_2819735075720[u5 + 1];
                                                    v35 = v36 + v32 - 1;
                                                    v33 = v36 + v34;
                                                    v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                                    u16(v37, 1, v32, v36, u4);
                                                    u5 = u5 + 1;
                                                end;
                                            else
                                                u4[UNNAMED_2819735063384[u5]] = u21(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735035304[u5]);
                                            end;
                                        elseif v326 < 80 then
                                            if v326 < 78 then
                                                v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                                v36[5][v36[4]] = UNNAMED_2819735088680[u5];
                                            elseif v326 == 79 then
                                                u4[UNNAMED_2819735063384[u5]] = u19(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735077064[u5]);
                                            else
                                                u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735050136[u5]);
                                            end;
                                        elseif v326 >= 81 then
                                            if v326 == 82 then
                                                local v336 = u4[UNNAMED_2819735063384[u5]] % 4294967296;
                                                u4[UNNAMED_2819735075720[u5]] = v336 ~= v336 and 0 or v336 - v336 % 1;
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735063384[u5]]));
                                            end;
                                        end;
                                    elseif v326 >= 96 then
                                        if v326 < 99 then
                                            if v326 >= 97 then
                                                if v326 == 98 then
                                                    local v337 = u12;
                                                    local v338 = u13;

                                                    if v337 then
                                                        for i in u15, v337 do
                                                            local v339 = v337[i];

                                                            if v339 then
                                                                v339[5] = v339;
                                                                v339[6] = u4[i];
                                                                v339[4] = 6;
                                                                v337[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v338 then
                                                        for i, v in u15, v338 do
                                                            local v340 = v[6];

                                                            if v338 then
                                                                local v341 = v338[i];

                                                                if v341 then
                                                                    local v342 = u3(v340);
                                                                    u16(u4, i, i + v340 - 1, 1, v342);
                                                                    v341[5] = v342;
                                                                    v341[4] = 1;
                                                                    v338[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819735063384[u5], u17(u4[UNNAMED_2819735035304[u5]]);
                                                end;

                                                local v343 = UNNAMED_2819735075720[u5];
                                                local v344 = u4[UNNAMED_2819735035304[u5]];
                                                local v345 = u21(UNNAMED_2819735088680[u5], 4294967295);
                                                local v346 = u21(v344, 4294967295);
                                                local v347 = u21(v345, 65535);
                                                local v348 = u20(v345, 16);
                                                local v349 = u21(v346, 65535);
                                                local v350 = u20(v346, 16);
                                                local v351 = u21(v347 * v349 + u22(u21(v347 * v350 + v348 * v349, 65535), 16), 4294967295) % 4294967296;
                                                u4[v343] = v351 ~= v351 and 0 or v351 - v351 % 1;
                                            else
                                                local v352 = UNNAMED_2819735035304[u5];
                                                local v353 = u4[UNNAMED_2819735063384[u5]];
                                                local v354 = u21(u4[UNNAMED_2819735075720[u5]], 4294967295);
                                                local v355 = u21(v353, 4294967295);
                                                local v356 = u21(v354, 65535);
                                                local v357 = u20(v354, 16);
                                                local v358 = u21(v355, 65535);
                                                local v359 = u20(v355, 16);
                                                local v360 = u21(v356 * v358 + u22(u21(v356 * v359 + v357 * v358, 65535), 16), 4294967295) % 4294967296;
                                                u4[v352] = v360 ~= v360 and 0 or v360 - v360 % 1;
                                            end;
                                        elseif v326 < 101 then
                                            if v326 == 100 then
                                                local v361 = u12;
                                                local v362 = u13;

                                                if v361 then
                                                    for i in u15, v361 do
                                                        local v363 = v361[i];

                                                        if v363 then
                                                            v363[5] = v363;
                                                            v363[6] = u4[i];
                                                            v363[4] = 6;
                                                            v361[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v362 then
                                                    for i, v in u15, v362 do
                                                        local v364 = v[6];

                                                        if v362 then
                                                            local v365 = v362[i];

                                                            if v365 then
                                                                local v366 = u3(v364);
                                                                u16(u4, i, i + v364 - 1, 1, v366);
                                                                v365[5] = v366;
                                                                v365[4] = 1;
                                                                v362[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(UNNAMED_2819735077064[u5], u4[UNNAMED_2819735035304[u5]]);
                                            end;

                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] % UNNAMED_2819735077064[u5];
                                        elseif v326 == 102 then
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5] * u4[UNNAMED_2819735063384[u5]];
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][UNNAMED_2819735050136[u5]];
                                        end;
                                    elseif v326 < 93 then
                                        if v326 < 91 then
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]] .. UNNAMED_2819735050136[u5];
                                        elseif v326 == 92 then
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735050136[u5] - u4[UNNAMED_2819735063384[u5]];
                                        else
                                            u24[UNNAMED_2819735050136[u5]][UNNAMED_2819735077064[u5]] = UNNAMED_2819735088680[u5];
                                        end;
                                    elseif v326 >= 94 then
                                        if v326 == 95 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34, v32, v35 = u8();

                                            if v34 then
                                                u4[v36] = v32;
                                                u4[v36 + 1] = v35;
                                                u5 = UNNAMED_2819735075720[u5];
                                            else
                                                u5 = UNNAMED_2819735063384[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] < UNNAMED_2819735088680[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735075720[u5]]);
                                    end;
                                elseif v326 >= 64 then
                                    if v326 < 70 then
                                        if v326 < 67 then
                                            if v326 >= 65 then
                                                if v326 == 66 then
                                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] > UNNAMED_2819735075720[u5];
                                                else
                                                    v36 = UNNAMED_2819735075720[u5] + 1;
                                                    v34 = u18(UNNAMED_2819735035304[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));

                                                    for i = 1, UNNAMED_2819735063384[u5] do
                                                        local v367 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                                        local v368 = u18(v367, (u20(v367, 13)));
                                                        v34 = u21(u18(v368, (u22(v368, 14))), 536870911);
                                                        UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                                        UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                                        UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 14), 127)));
                                                        UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 21), 127)));
                                                        v36 = v36 + 1;
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819735072264[u5] = 80;
                                                end;
                                            else
                                                u4[UNNAMED_2819735063384[u5]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735077064[u5];
                                            end;
                                        elseif v326 < 68 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = UNNAMED_2819735063384[u5];
                                            v32 = UNNAMED_2819735075720[u5];
                                            v35 = v36 + v32 - 1;
                                            v33 = v36 + v34;
                                            v37 = u4[v33];
                                            local n = v37.n;
                                            v37.n = v34 + n - 1;
                                            u16(v37, 1, n, v34, v37);
                                            u16(u4, v36 + 1, v33 - 1, 1, v37);
                                            u16(u17(u4[v36](u14(v37, 1, v37.n))), 1, v32, v36, u4);
                                        elseif v326 == 69 then
                                            local v369;

                                            if u4[UNNAMED_2819735035304[u5]] then
                                                v369 = UNNAMED_2819735075720[u5];
                                            else
                                                v369 = UNNAMED_2819735063384[u5];
                                            end;

                                            u5 = v369;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] - UNNAMED_2819735075720[u5];
                                        end;
                                    elseif v326 >= 73 then
                                        if v326 >= 75 then
                                            if v326 == 76 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] >= u4[UNNAMED_2819735063384[u5]];
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = {};
                                            end;
                                        elseif v326 == 74 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            local v370 = u4[UNNAMED_2819735075720[u5]];
                                            u4[v36] = UNNAMED_2819735063384[u5];
                                            u4[v36 + 1] = v370;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u21(u4[UNNAMED_2819735063384[u5]], u4[UNNAMED_2819735075720[u5]]);
                                        end;
                                    elseif v326 >= 71 then
                                        if v326 == 72 then
                                            v36 = UNNAMED_2819735029544[UNNAMED_2819735063384[u5]];
                                            u4[UNNAMED_2819735075720[u5]] = v36[5][v36[4]][UNNAMED_2819735035304[u5]];
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] + u4[UNNAMED_2819735075720[u5]];
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u25(u4[UNNAMED_2819735063384[u5]]);
                                    end;
                                elseif v326 < 57 then
                                    if v326 >= 54 then
                                        if v326 >= 55 then
                                            if v326 == 56 then
                                                u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]][u4[UNNAMED_2819735035304[u5]]];
                                            else
                                                u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735035304[u5] ^ u4[UNNAMED_2819735063384[u5]];
                                            end;
                                        else
                                            UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735063384[u5]]] = UNNAMED_2819735077064[u5];
                                        end;
                                    elseif v326 >= 52 then
                                        if v326 == 53 then
                                            u4[UNNAMED_2819735063384[u5]] = u19(u4[UNNAMED_2819735075720[u5]], u4[UNNAMED_2819735035304[u5]]);
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u21(UNNAMED_2819735050136[u5], u4[UNNAMED_2819735063384[u5]]);
                                        end;
                                    else
                                        v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                        u4[UNNAMED_2819735063384[u5]] = v36[5][v36[4]][UNNAMED_2819735050136[u5]];
                                    end;
                                elseif v326 < 60 then
                                    if v326 < 58 then
                                        u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735035304[u5] + u4[UNNAMED_2819735075720[u5]];
                                    elseif v326 == 59 then
                                        u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]] == UNNAMED_2819735035304[u5];
                                    else
                                        u5 = u4[UNNAMED_2819735075720[u5]];
                                    end;
                                elseif v326 < 62 then
                                    if v326 == 61 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] + UNNAMED_2819735077064[u5];
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]](u14(u4[UNNAMED_2819735063384[u5]], 1, u4[UNNAMED_2819735063384[u5]].n));
                                    end;
                                elseif v326 == 63 then
                                    if UNNAMED_2819735035304[u5] > u4[UNNAMED_2819735063384[u5]] then
                                        u5 = UNNAMED_2819735075720[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735075720[u5]] = u18(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735063384[u5]);
                                end;
                            elseif v326 >= 25 then
                                if v326 >= 38 then
                                    if v326 >= 44 then
                                        if v326 >= 47 then
                                            if v326 >= 49 then
                                                if v326 == 50 then
                                                    v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                                    v36[5][v36[4]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735063384[u5]];
                                                else
                                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] > u4[UNNAMED_2819735075720[u5]];
                                                end;
                                            elseif v326 == 48 then
                                                u4[UNNAMED_2819735063384[u5]]();
                                            else
                                                u4[UNNAMED_2819735063384[u5]][u4[UNNAMED_2819735075720[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                            end;
                                        elseif v326 < 45 then
                                            u4[UNNAMED_2819735063384[u5]] = u21(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735050136[u5]);
                                        elseif v326 == 46 then
                                            u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735050136[u5], u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n));
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                        end;
                                    elseif v326 < 41 then
                                        if v326 >= 39 then
                                            if v326 ~= 40 then
                                                local v371 = u12;
                                                local v372 = u13;

                                                if v371 then
                                                    for i in u15, v371 do
                                                        local v373 = v371[i];

                                                        if v373 then
                                                            v373[5] = v373;
                                                            v373[6] = u4[i];
                                                            v373[4] = 6;
                                                            v371[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v372 then
                                                    for i, v in u15, v372 do
                                                        local v374 = v[6];

                                                        if v372 then
                                                            local v375 = v372[i];

                                                            if v375 then
                                                                local v376 = u3(v374);
                                                                u16(u4, i, i + v374 - 1, 1, v376);
                                                                v375[5] = v376;
                                                                v375[4] = 1;
                                                                v372[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735063384[u5]]);
                                            end;

                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735077064[u5]];
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735050136[u5] + u4[UNNAMED_2819735063384[u5]];
                                        end;
                                    elseif v326 < 42 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] * UNNAMED_2819735077064[u5];
                                    else
                                        if v326 == 43 then
                                            local v377 = u12;
                                            local v378 = u13;

                                            if v377 then
                                                for i in u15, v377 do
                                                    local v379 = v377[i];

                                                    if v379 then
                                                        v379[5] = v379;
                                                        v379[6] = u4[i];
                                                        v379[4] = 6;
                                                        v377[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v378 then
                                                for i, v in u15, v378 do
                                                    local v380 = v[6];

                                                    if v378 then
                                                        local v381 = v378[i];

                                                        if v381 then
                                                            local v382 = u3(v380);
                                                            u16(u4, i, i + v380 - 1, 1, v382);
                                                            v381[5] = v382;
                                                            v381[4] = 1;
                                                            v378[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735035304[u5], u4[UNNAMED_2819735063384[u5]];
                                        end;

                                        v36 = UNNAMED_2819735075720[u5];
                                        local v383 = UNNAMED_2819735035304[u5];
                                        u4[v36] = UNNAMED_2819735088680[u5];
                                        u4[v36 + 1] = v383;
                                    end;
                                elseif v326 < 31 then
                                    if v326 >= 28 then
                                        if v326 >= 29 then
                                            if v326 == 30 then
                                                v36 = u18(u1, u21(u20(u1, 14), 262143), (u21(u20(u1, 28), 15)));
                                                v34 = UNNAMED_2819735075720[u5];
                                                v32 = UNNAMED_2819735035304[u5];
                                                v35 = UNNAMED_2819735063384[u5];
                                                v33 = v32 < 16384 and 7 or (v32 < 2097152 and 14 or 21);
                                                v37 = u20(v32, v33);
                                                local v384 = u21(v32, u22(1, v33) - 1);
                                                UNNAMED_2819735063384[u5] = u18(v35, 108, (u21(u20(v36, 14), 127)));
                                                UNNAMED_2819735075720[u5] = u18(v34, 127, (u21(v36, 127)));
                                                UNNAMED_2819735035304[u5] = u18(v384, 67, (u21(u20(v36, 7), 127)));
                                                UNNAMED_2819735072264[u5] = u18(v37, 124, (u21(u20(v36, 21), 127)));
                                                u5 = u5 - 1;
                                            else
                                                local v385 = UNNAMED_2819735075720[u5];
                                                local v386 = u18(UNNAMED_2819735035304[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));
                                                local v387 = UNNAMED_2819735058152[5];
                                                local v388 = u18(v387[v385], 109162203);
                                                v387[v385] = v388;
                                                local v389 = UNNAMED_2819735058152[4];
                                                local v390 = v388 + 1;
                                                local v391 = u28(v389, v390);
                                                local v392;

                                                if v391 < 128 then
                                                    v392 = v390 + 1;
                                                else
                                                    local v393 = u28(v389, v390 + 1);

                                                    if v393 < 128 then
                                                        v391 = v391 - 128 + v393 * 128;
                                                        v392 = v390 + 2;
                                                    else
                                                        local v394 = u28(v389, v390 + 2);

                                                        if v394 < 128 then
                                                            v391 = v391 - 128 + (v393 - 128) * 16384 + v394 * 128;
                                                            v392 = v390 + 3;
                                                        else
                                                            local v395 = u28(v389, v390 + 3);
                                                            v391 = (v391 - 128) * 16384 + (v393 - 128) * 128 + (v394 - 128) + v395 % 128 * 2097152 + (v395 - v395 % 128) * 2097152;
                                                            v392 = v390 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v396 = v386 * 16843009;
                                                local v397 = v392 + v391;
                                                local v398 = v397 - v391 % 4;

                                                for i = v392, v398 - 1, 4 do
                                                    u29(v389, i, (u18(u30(v389, i), v396)));
                                                    local _ = i;
                                                end;

                                                for i = v398, v397 - 1 do
                                                    u31(v389, i, (u18(u28(v389, i), v386)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735075720[u5] = 42;
                                                UNNAMED_2819735035304[u5] = 156;
                                                UNNAMED_2819735063384[u5] = 248;
                                                UNNAMED_2819735072264[u5] = 80;
                                            end;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735063384[u5]] ~= UNNAMED_2819735035304[u5];
                                        end;
                                    else
                                        if v326 < 26 then
                                            local v399 = u12;
                                            local v400 = u13;

                                            if v399 then
                                                for i in u15, v399 do
                                                    local v401 = v399[i];

                                                    if v401 then
                                                        v401[5] = v401;
                                                        v401[6] = u4[i];
                                                        v401[4] = 6;
                                                        v399[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v400 then
                                                for i, v in u15, v400 do
                                                    local v402 = v[6];

                                                    if v400 then
                                                        local v403 = v400[i];

                                                        if v403 then
                                                            local v404 = u3(v402);
                                                            u16(u4, i, i + v402 - 1, 1, v404);
                                                            v403[5] = v404;
                                                            v403[4] = 1;
                                                            v400[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735063384[u5], u17(u4[UNNAMED_2819735075720[u5]], u14(u4[UNNAMED_2819735035304[u5]], 1, u4[UNNAMED_2819735035304[u5]].n));
                                        end;

                                        if v326 == 27 then
                                            u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735035304[u5]], u14(u4[UNNAMED_2819735063384[u5]], 1, u4[UNNAMED_2819735063384[u5]].n));
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] - u4[UNNAMED_2819735075720[u5]];
                                        end;
                                    end;
                                elseif v326 < 34 then
                                    if v326 < 32 then
                                        UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735063384[u5]];
                                    elseif v326 == 33 then
                                        u4[UNNAMED_2819735063384[u5]](u4[UNNAMED_2819735035304[u5]]);
                                    else
                                        u5 = u4[UNNAMED_2819735063384[u5]];
                                    end;
                                elseif v326 < 36 then
                                    if v326 == 35 then
                                        local v405 = UNNAMED_2819735075720[u5];
                                        local v406 = u18(UNNAMED_2819735035304[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));
                                        local v407 = UNNAMED_2819735058152[5];
                                        local v408 = u18(v407[v405], 109162203);
                                        v407[v405] = v408;
                                        local v409 = UNNAMED_2819735058152[4];
                                        local v410 = v408 + 1;
                                        local v411 = u28(v409, v410);
                                        local v412;

                                        if v411 < 128 then
                                            v412 = v410 + 1;
                                        else
                                            local v413 = u28(v409, v410 + 1);

                                            if v413 < 128 then
                                                v411 = v411 - 128 + v413 * 128;
                                                v412 = v410 + 2;
                                            else
                                                local v414 = u28(v409, v410 + 2);

                                                if v414 < 128 then
                                                    v411 = v411 - 128 + (v413 - 128) * 16384 + v414 * 128;
                                                    v412 = v410 + 3;
                                                else
                                                    local v415 = u28(v409, v410 + 3);
                                                    v411 = (v411 - 128) * 16384 + (v413 - 128) * 128 + (v414 - 128) + v415 % 128 * 2097152 + (v415 - v415 % 128) * 2097152;
                                                    v412 = v410 + 4;
                                                end;
                                            end;
                                        end;

                                        local v416 = v406 * 16843009;
                                        local v417 = v412 + v411;
                                        local v418 = v417 - v411 % 4;

                                        for i = v412, v418 - 1, 4 do
                                            u29(v409, i, (u18(u30(v409, i), v416)));
                                            local _ = i;
                                        end;

                                        for i = v418, v417 - 1 do
                                            u31(v409, i, (u18(u28(v409, i), v406)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735075720[u5] = 21;
                                        UNNAMED_2819735035304[u5] = 205;
                                        UNNAMED_2819735063384[u5] = 192;
                                        UNNAMED_2819735072264[u5] = 80;
                                    else
                                        v36 = UNNAMED_2819735075720[u5] + 1;
                                        v34 = u18(UNNAMED_2819735035304[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));

                                        for i = 1, UNNAMED_2819735063384[u5] do
                                            local v419 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                            local v420 = u18(v419, (u20(v419, 13)));
                                            v34 = u21(u18(v420, (u22(v420, 14))), 536870911);
                                            UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                            UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                            UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 14), 127)));
                                            UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 21), 127)));
                                            v36 = v36 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735072264[u5] = 80;
                                    end;
                                elseif v326 == 37 then
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][u4[UNNAMED_2819735063384[u5]]];
                                else
                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]] / UNNAMED_2819735035304[u5];
                                end;
                            elseif v326 < 12 then
                                if v326 >= 6 then
                                    if v326 >= 9 then
                                        if v326 < 10 then
                                            v36 = UNNAMED_2819735063384[u5];
                                            local v421 = UNNAMED_2819735035304[u5];
                                            u4[v36] = UNNAMED_2819735075720[u5];
                                            u4[v36 + 1] = v421;
                                        elseif v326 == 11 then
                                            for i = UNNAMED_2819735063384[u5], UNNAMED_2819735035304[u5] do
                                                u4[i] = nil;
                                                local _ = i;
                                            end;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735035304[u5] - u4[UNNAMED_2819735063384[u5]];
                                        end;
                                    elseif v326 >= 7 then
                                        if v326 == 8 then
                                            if UNNAMED_2819735075720[u5] >= u4[UNNAMED_2819735063384[u5]] then
                                                u5 = UNNAMED_2819735035304[u5];
                                            end;
                                        elseif u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735077064[u5] then
                                            u5 = UNNAMED_2819735063384[u5];
                                        end;
                                    else
                                        v36 = UNNAMED_2819735029544[UNNAMED_2819735063384[u5]];
                                        u4[UNNAMED_2819735035304[u5]] = v36[5][v36[4]];
                                    end;
                                elseif v326 >= 3 then
                                    if v326 < 4 then
                                        u7 = {
                                            [6] = u11,
                                            [5] = u9,
                                            [9] = u7,
                                            [8] = u8,
                                            [7] = u10
                                        };
                                        v36 = UNNAMED_2819735063384[u5];
                                        u10 = u4[v36 + 2] + 0;
                                        u9 = u4[v36 + 1] + 0;
                                        u8 = u4[v36] - u10;
                                        u5 = UNNAMED_2819735035304[u5];
                                    elseif v326 == 5 then
                                        u4[UNNAMED_2819735075720[u5]] = u24[UNNAMED_2819735088680[u5]];
                                    elseif u12 then
                                        local v422 = u12;
                                        local v423 = UNNAMED_2819735035304[u5];
                                        local v424 = v422[v423];

                                        if v424 then
                                            v424[5] = v424;
                                            v424[6] = u4[v423];
                                            v424[4] = 6;
                                            v422[v423] = nil;
                                        end;
                                    end;
                                elseif v326 >= 1 then
                                    if v326 == 2 then
                                        u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735050136[u5] .. u4[UNNAMED_2819735075720[u5]];
                                    else
                                        u1 = u4[UNNAMED_2819735075720[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] * u4[UNNAMED_2819735063384[u5]];
                                end;
                            elseif v326 >= 18 then
                                if v326 < 21 then
                                    if v326 >= 19 then
                                        if v326 == 20 then
                                            u4[UNNAMED_2819735035304[u5]] = u19(UNNAMED_2819735088680[u5], u4[UNNAMED_2819735075720[u5]]);
                                        elseif u4[UNNAMED_2819735075720[u5]] ~= UNNAMED_2819735063384[u5] then
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    else
                                        u24[UNNAMED_2819735077064[u5]][UNNAMED_2819735088680[u5]] = u4[UNNAMED_2819735035304[u5]];
                                    end;
                                elseif v326 >= 23 then
                                    if v326 == 24 then
                                        u4[UNNAMED_2819735035304[u5]] = #u4[UNNAMED_2819735063384[u5]];
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] ~= u4[UNNAMED_2819735075720[u5]];
                                    end;
                                elseif v326 == 22 then
                                    u2 = u4[UNNAMED_2819735063384[u5]];
                                else
                                    u4[UNNAMED_2819735075720[u5]][u4[UNNAMED_2819735035304[u5]]] = UNNAMED_2819735088680[u5];
                                end;
                            elseif v326 >= 15 then
                                if v326 >= 16 then
                                    if v326 == 17 then
                                        local v425 = UNNAMED_2819735063384[u5];
                                        local v426 = UNNAMED_2819735035304[u5];
                                        local v427 = UNNAMED_2819735058152[5];
                                        local v428 = u18(v427[v425], 109162203);
                                        v427[v425] = v428;
                                        local v429 = UNNAMED_2819735058152[4];
                                        local v430 = v428 + 1;
                                        local v431 = u28(v429, v430);
                                        local v432;

                                        if v431 < 128 then
                                            v432 = v430 + 1;
                                        else
                                            local v433 = u28(v429, v430 + 1);

                                            if v433 < 128 then
                                                v431 = v431 - 128 + v433 * 128;
                                                v432 = v430 + 2;
                                            else
                                                local v434 = u28(v429, v430 + 2);

                                                if v434 < 128 then
                                                    v431 = v431 - 128 + (v433 - 128) * 16384 + v434 * 128;
                                                    v432 = v430 + 3;
                                                else
                                                    local v435 = u28(v429, v430 + 3);
                                                    v431 = (v431 - 128) * 16384 + (v433 - 128) * 128 + (v434 - 128) + v435 % 128 * 2097152 + (v435 - v435 % 128) * 2097152;
                                                    v432 = v430 + 4;
                                                end;
                                            end;
                                        end;

                                        local v436 = v426 * 16843009;
                                        local v437 = v432 + v431;
                                        local v438 = v437 - v431 % 4;

                                        for i = v432, v438 - 1, 4 do
                                            u29(v429, i, (u18(u30(v429, i), v436)));
                                            local _ = i;
                                        end;

                                        for i = v438, v437 - 1 do
                                            u31(v429, i, (u18(u28(v429, i), v426)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735063384[u5] = 78;
                                        UNNAMED_2819735035304[u5] = 229;
                                        UNNAMED_2819735075720[u5] = 8;
                                        UNNAMED_2819735072264[u5] = 80;
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735035304[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735075720[u5]] = u20(u4[UNNAMED_2819735063384[u5]], UNNAMED_2819735035304[u5]);
                                end;
                            elseif v326 >= 13 then
                                if v326 == 14 then
                                    if u4[UNNAMED_2819735035304[u5]] ~= u4[UNNAMED_2819735075720[u5]] then
                                        u5 = UNNAMED_2819735063384[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735063384[u5] * u4[UNNAMED_2819735075720[u5]];
                                end;
                            else
                                v36 = UNNAMED_2819735063384[u5] + 1;
                                v34 = UNNAMED_2819735035304[u5];

                                for i = 1, UNNAMED_2819735075720[u5] do
                                    local v439 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                    local v440 = u18(v439, (u20(v439, 13)));
                                    v34 = u21(u18(v440, (u22(v440, 14))), 536870911);
                                    UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                    UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                    UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 14), 127)));
                                    UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 21), 127)));
                                    v36 = v36 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735072264[u5] = 80;
                            end;
                        else
                            if v326 >= 155 then
                                if v326 >= 181 then
                                    if v326 >= 194 then
                                        if v326 >= 200 then
                                            if v326 >= 203 then
                                                if v326 < 205 then
                                                    if v326 == 204 then
                                                        u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]] < u4[UNNAMED_2819735035304[u5]];
                                                    else
                                                        v36 = UNNAMED_2819735035304[u5];
                                                        v34, v32 = u8();

                                                        if v34 then
                                                            u4[v36] = v32;
                                                            u5 = UNNAMED_2819735063384[u5];
                                                        else
                                                            u5 = UNNAMED_2819735075720[u5];
                                                        end;
                                                    end;
                                                else
                                                    if v326 == 206 then
                                                        local v441 = u12;
                                                        local v442 = u13;

                                                        if v441 then
                                                            for i in u15, v441 do
                                                                local v443 = v441[i];

                                                                if v443 then
                                                                    v443[5] = v443;
                                                                    v443[6] = u4[i];
                                                                    v443[4] = 6;
                                                                    v441[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v442 then
                                                            for i, v in u15, v442 do
                                                                local v444 = v[6];

                                                                if v442 then
                                                                    local v445 = v442[i];

                                                                    if v445 then
                                                                        local v446 = u3(v444);
                                                                        u16(u4, i, i + v444 - 1, 1, v446);
                                                                        v445[5] = v446;
                                                                        v445[4] = 1;
                                                                        v442[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u17(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735088680[u5], UNNAMED_2819735077064[u5]);
                                                    end;

                                                    u4[UNNAMED_2819735035304[u5]] = -u4[UNNAMED_2819735063384[u5]];
                                                end;
                                            elseif v326 < 201 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] // UNNAMED_2819735063384[u5];
                                            else
                                                if v326 == 202 then
                                                    local v447 = UNNAMED_2819735075720[u5];
                                                    local v448 = v447 + UNNAMED_2819735035304[u5];
                                                    local v449 = u12;
                                                    local v450 = u13;

                                                    if v449 then
                                                        for i in u15, v449 do
                                                            local v451 = v449[i];

                                                            if v451 then
                                                                v451[5] = v451;
                                                                v451[6] = u4[i];
                                                                v451[4] = 6;
                                                                v449[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v450 then
                                                        for i, v in u15, v450 do
                                                            local v452 = v[6];

                                                            if v450 then
                                                                local v453 = v450[i];

                                                                if v453 then
                                                                    local v454 = u3(v452);
                                                                    u16(u4, i, i + v452 - 1, 1, v454);
                                                                    v453[5] = v454;
                                                                    v453[4] = 1;
                                                                    v450[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, false, v447, v448;
                                                end;

                                                u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]] % u4[UNNAMED_2819735035304[u5]];
                                            end;
                                        elseif v326 >= 197 then
                                            if v326 < 198 then
                                                u4[UNNAMED_2819735035304[u5]] = not u4[UNNAMED_2819735075720[u5]];
                                            elseif v326 == 199 then
                                                u5 = UNNAMED_2819735035304[u5];
                                            else
                                                v36 = UNNAMED_2819735063384[u5];
                                                v34 = u4[UNNAMED_2819735075720[u5]];
                                                u4[v36 + 1] = v34;
                                                u4[v36] = v34[UNNAMED_2819735050136[u5]];
                                            end;
                                        elseif v326 < 195 then
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] .. u4[UNNAMED_2819735063384[u5]];
                                        else
                                            if v326 ~= 196 then
                                                local v455 = u12;
                                                local v456 = u13;

                                                if v455 then
                                                    for i in u15, v455 do
                                                        local v457 = v455[i];

                                                        if v457 then
                                                            v457[5] = v457;
                                                            v457[6] = u4[i];
                                                            v457[4] = 6;
                                                            v455[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v456 then
                                                    for i, v in u15, v456 do
                                                        local v458 = v[6];

                                                        if v456 then
                                                            local v459 = v456[i];

                                                            if v459 then
                                                                local v460 = u3(v458);
                                                                u16(u4, i, i + v458 - 1, 1, v460);
                                                                v459[5] = v460;
                                                                v459[4] = 1;
                                                                v456[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735035304[u5], u17(u4[UNNAMED_2819735063384[u5]], u4[UNNAMED_2819735075720[u5]]);
                                            end;

                                            local v461 = UNNAMED_2819735063384[u5];
                                            local v462 = UNNAMED_2819735035304[u5];
                                            local v463 = u21(u4[UNNAMED_2819735075720[u5]], 4294967295);
                                            local v464 = u21(v462, 4294967295);
                                            local v465 = u21(v463, 65535);
                                            local v466 = u20(v463, 16);
                                            local v467 = u21(v464, 65535);
                                            local v468 = u20(v464, 16);
                                            local v469 = u21(v465 * v467 + u22(u21(v465 * v468 + v466 * v467, 65535), 16), 4294967295) % 4294967296;
                                            u4[v461] = v469 ~= v469 and 0 or v469 - v469 % 1;
                                        end;
                                    elseif v326 < 187 then
                                        if v326 >= 184 then
                                            if v326 >= 185 then
                                                if v326 == 186 then
                                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] == u4[UNNAMED_2819735075720[u5]];
                                                else
                                                    v36 = UNNAMED_2819735035304[u5];
                                                    v34 = UNNAMED_2819735063384[u5];
                                                    v32 = UNNAMED_2819735075720[u5];
                                                    v35 = v36 + v32 - 1;
                                                    v33 = v36 + v34;
                                                    v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                                    u16(v37, 1, v32, v36, u4);
                                                end;
                                            else
                                                u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735050136[u5] % u4[UNNAMED_2819735063384[u5]];
                                            end;
                                        elseif v326 >= 182 then
                                            if v326 == 183 then
                                                u4[UNNAMED_2819735063384[u5]] = u2;
                                            elseif UNNAMED_2819735077064[u5] > u4[UNNAMED_2819735063384[u5]] then
                                                u5 = UNNAMED_2819735035304[u5];
                                            end;
                                        else
                                            v36 = UNNAMED_2819735063384[u5];
                                            local v470 = u4[UNNAMED_2819735075720[u5]];
                                            u4[v36] = u4[UNNAMED_2819735035304[u5]];
                                            u4[v36 + 1] = v470;
                                        end;
                                    elseif v326 >= 190 then
                                        if v326 < 192 then
                                            if v326 == 191 then
                                                v36 = UNNAMED_2819735035304[u5];
                                                local v471 = UNNAMED_2819735088680[u5];
                                                u4[v36] = u4[UNNAMED_2819735075720[u5]];
                                                u4[v36 + 1] = v471;
                                            else
                                                v36 = UNNAMED_2819735075720[u5];
                                                local v472 = u4[UNNAMED_2819735035304[u5]];
                                                u4[v36] = UNNAMED_2819735088680[u5];
                                                u4[v36 + 1] = v472;
                                            end;
                                        elseif v326 == 193 then
                                            u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735050136[u5], UNNAMED_2819735077064[u5]);
                                        else
                                            UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735088680[u5]] = UNNAMED_2819735077064[u5];
                                        end;
                                    elseif v326 < 188 then
                                        if u4[UNNAMED_2819735035304[u5]] >= u4[UNNAMED_2819735075720[u5]] then
                                            u5 = UNNAMED_2819735063384[u5];
                                        end;
                                    elseif v326 == 189 then
                                        u4[UNNAMED_2819735035304[u5]](u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n));
                                    else
                                        v36 = UNNAMED_2819735063384[u5];
                                        v34 = UNNAMED_2819735075720[u5];
                                        v32 = UNNAMED_2819735035304[u5];
                                        v35 = u4[v36];
                                        v33 = v36 + v34;
                                        v37 = u4[v33];
                                        u16(u4, v36 + 1, v33 - 1, v32 + 1, v35);
                                        u16(v37, 1, v37.n, v32 + v34, v35);
                                    end;
                                elseif v326 >= 168 then
                                    if v326 >= 174 then
                                        if v326 >= 177 then
                                            if v326 < 179 then
                                                if v326 == 178 then
                                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] <= UNNAMED_2819735075720[u5];
                                                else
                                                    u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735063384[u5]];
                                                end;
                                            elseif v326 == 180 then
                                                local v473 = UNNAMED_2819735075720[u5];
                                                local v474 = UNNAMED_2819735063384[u5];
                                                local v475, v476 = u4[UNNAMED_2819735035304[u5]]();
                                                u4[v473] = v475;
                                                u4[v474] = v476;
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] // u4[UNNAMED_2819735075720[u5]];
                                            end;
                                        elseif v326 >= 175 then
                                            if v326 == 176 then
                                                local v477 = u12;
                                                local v478 = u13;

                                                if v477 then
                                                    for i in u15, v477 do
                                                        local v479 = v477[i];

                                                        if v479 then
                                                            v479[5] = v479;
                                                            v479[6] = u4[i];
                                                            v479[4] = 6;
                                                            v477[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v478 then
                                                    for i, v in u15, v478 do
                                                        local v480 = v[6];

                                                        if v478 then
                                                            local v481 = v478[i];

                                                            if v481 then
                                                                local v482 = u3(v480);
                                                                u16(u4, i, i + v480 - 1, 1, v482);
                                                                v481[5] = v482;
                                                                v481[4] = 1;
                                                                v478[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(UNNAMED_2819735077064[u5]);
                                            end;

                                            u4[UNNAMED_2819735075720[u5]] = u4;
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = u1;
                                        end;
                                    elseif v326 >= 171 then
                                        if v326 >= 172 then
                                            if v326 ~= 173 then
                                                local v483 = u12;
                                                local v484 = u13;

                                                if v483 then
                                                    for i in u15, v483 do
                                                        local v485 = v483[i];

                                                        if v485 then
                                                            v485[5] = v485;
                                                            v485[6] = u4[i];
                                                            v485[4] = 6;
                                                            v483[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v484 then
                                                    for i, v in u15, v484 do
                                                        local v486 = v[6];

                                                        if v484 then
                                                            local v487 = v484[i];

                                                            if v487 then
                                                                local v488 = u3(v486);
                                                                u16(u4, i, i + v486 - 1, 1, v488);
                                                                v487[5] = v488;
                                                                v487[4] = 1;
                                                                v484[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(UNNAMED_2819735088680[u5], UNNAMED_2819735077064[u5]);
                                            end;

                                            local v489 = UNNAMED_2819735075720[u5];
                                            local v490 = u4[UNNAMED_2819735063384[u5]];
                                            local v491 = u21(UNNAMED_2819735035304[u5], 4294967295);
                                            local v492 = u21(v490, 4294967295);
                                            local v493 = u21(v491, 65535);
                                            local v494 = u20(v491, 16);
                                            local v495 = u21(v492, 65535);
                                            local v496 = u20(v492, 16);
                                            local v497 = u21(v493 * v495 + u22(u21(v493 * v496 + v494 * v495, 65535), 16), 4294967295) % 4294967296;
                                            u4[v489] = v497 ~= v497 and 0 or v497 - v497 % 1;
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] <= UNNAMED_2819735077064[u5];
                                        end;
                                    elseif v326 >= 169 then
                                        if v326 == 170 then
                                            u7 = {
                                                [6] = u11,
                                                [5] = u9,
                                                [9] = u7,
                                                [8] = u8,
                                                [7] = u10
                                            };
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = u26(u27);
                                            v34(UNNAMED_2819735088728, u4[v36], u4[v36 + 1], u4[v36 + 2]);
                                            u8 = v34;
                                            u11 = UNNAMED_2819735063384[u5];
                                            u5 = UNNAMED_2819735075720[u5];
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735075720[u5]]());
                                        end;
                                    else
                                        u24[UNNAMED_2819735088680[u5]][u4[UNNAMED_2819735075720[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                    end;
                                elseif v326 < 161 then
                                    if v326 < 158 then
                                        if v326 < 156 then
                                            v36 = UNNAMED_2819735063384[u5];
                                            v34 = UNNAMED_2819735035304[u5];
                                            v32 = UNNAMED_2819735075720[u5];
                                            v35 = u4[v36];
                                            u16(u4, v36 + 1, v36 + v34, v32 + 1, v35);
                                        else
                                            if v326 == 157 then
                                                local v498 = u12;
                                                local v499 = u13;

                                                if v498 then
                                                    for i in u15, v498 do
                                                        local v500 = v498[i];

                                                        if v500 then
                                                            v500[5] = v500;
                                                            v500[6] = u4[i];
                                                            v500[4] = 6;
                                                            v498[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v499 then
                                                    for i, v in u15, v499 do
                                                        local v501 = v[6];

                                                        if v499 then
                                                            local v502 = v499[i];

                                                            if v502 then
                                                                local v503 = u3(v501);
                                                                u16(u4, i, i + v501 - 1, 1, v503);
                                                                v502[5] = v503;
                                                                v502[4] = 1;
                                                                v499[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735088680[u5]);
                                            end;

                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = UNNAMED_2819735063384[u5];
                                            v32 = UNNAMED_2819735075720[u5];
                                            v35 = v36 + v34;
                                            u4[v36] = u17(u4[v36](u14(u4, v36 + 1, v35)));
                                        end;
                                    elseif v326 >= 159 then
                                        if v326 == 160 then
                                            v36 = UNNAMED_2819735075720[u5];
                                            v34 = UNNAMED_2819735035304[u5];
                                            v32 = UNNAMED_2819735063384[u5];
                                            v35 = v36 + v34;
                                            v33 = u4[v35];
                                            v37 = v33.n;
                                            v33.n = v34 + v37 - 1;
                                            u16(v33, 1, v37, v34, v33);
                                            u16(u4, v36 + 1, v35 - 1, 1, v33);
                                            u4[v36] = u17(u4[v36](u14(v33, 1, v33.n)));
                                        else
                                            u24[UNNAMED_2819735077064[u5]] = UNNAMED_2819735088680[u5];
                                        end;
                                    else
                                        u8 = u7[8];
                                        u9 = u7[5];
                                        u10 = u7[7];
                                        u11 = u7[6];
                                        u7 = u7[9];
                                    end;
                                elseif v326 >= 164 then
                                    if v326 >= 166 then
                                        if v326 ~= 167 then
                                            local v504 = u12;
                                            local v505 = u13;

                                            if v504 then
                                                for i in u15, v504 do
                                                    local v506 = v504[i];

                                                    if v506 then
                                                        v506[5] = v506;
                                                        v506[6] = u4[i];
                                                        v506[4] = 6;
                                                        v504[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v505 then
                                                for i, v in u15, v505 do
                                                    local v507 = v[6];

                                                    if v505 then
                                                        local v508 = v505[i];

                                                        if v508 then
                                                            local v509 = u3(v507);
                                                            u16(u4, i, i + v507 - 1, 1, v509);
                                                            v508[5] = v509;
                                                            v508[4] = 1;
                                                            v505[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u17(u4[UNNAMED_2819735075720[u5]]);
                                        end;

                                        if UNNAMED_2819735077064[u5] >= u4[UNNAMED_2819735035304[u5]] then
                                            u5 = UNNAMED_2819735063384[u5];
                                        end;
                                    elseif v326 == 165 then
                                        local v510 = UNNAMED_2819735063384[u5];
                                        local v511 = UNNAMED_2819735077064[u5];
                                        local v512 = u21(u4[UNNAMED_2819735035304[u5]], 4294967295);
                                        local v513 = u21(v511, 4294967295);
                                        local v514 = u21(v512, 65535);
                                        local v515 = u20(v512, 16);
                                        local v516 = u21(v513, 65535);
                                        local v517 = u20(v513, 16);
                                        local v518 = u21(v514 * v516 + u22(u21(v514 * v517 + v515 * v516, 65535), 16), 4294967295) % 4294967296;
                                        u4[v510] = v518 ~= v518 and 0 or v518 - v518 % 1;
                                    else
                                        u24[UNNAMED_2819735088680[u5]] = u4[UNNAMED_2819735075720[u5]];
                                    end;
                                elseif v326 >= 162 then
                                    if v326 == 163 then
                                        u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735063384[u5]](u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n)));
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] + UNNAMED_2819735063384[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] / UNNAMED_2819735077064[u5];
                                end;

                                v325 = 1;
                                continue;
                            end;

                            if v326 < 129 then
                                if v326 < 116 then
                                    if v326 < 109 then
                                        if v326 >= 106 then
                                            if v326 >= 107 then
                                                if v326 ~= 108 then
                                                    local v519 = u12;
                                                    local v520 = u13;

                                                    if v519 then
                                                        for i in u15, v519 do
                                                            local v521 = v519[i];

                                                            if v521 then
                                                                v521[5] = v521;
                                                                v521[6] = u4[i];
                                                                v521[4] = 6;
                                                                v519[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v520 then
                                                        for i, v in u15, v520 do
                                                            local v522 = v[6];

                                                            if v520 then
                                                                local v523 = v520[i];

                                                                if v523 then
                                                                    local v524 = u3(v522);
                                                                    u16(u4, i, i + v522 - 1, 1, v524);
                                                                    v523[5] = v524;
                                                                    v523[4] = 1;
                                                                    v520[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u4[UNNAMED_2819735063384[u5]];
                                                end;

                                                u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735050136[u5];
                                            else
                                                UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][u4[UNNAMED_2819735063384[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                            end;
                                        elseif v326 < 104 then
                                            u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735088728[UNNAMED_2819735035304[u5]];
                                        else
                                            if v326 ~= 105 then
                                                local v525 = u12;
                                                local v526 = u13;

                                                if v525 then
                                                    for i in u15, v525 do
                                                        local v527 = v525[i];

                                                        if v527 then
                                                            v527[5] = v527;
                                                            v527[6] = u4[i];
                                                            v527[4] = 6;
                                                            v525[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v526 then
                                                    for i, v in u15, v526 do
                                                        local v528 = v[6];

                                                        if v526 then
                                                            local v529 = v526[i];

                                                            if v529 then
                                                                local v530 = u3(v528);
                                                                u16(u4, i, i + v528 - 1, 1, v530);
                                                                v529[5] = v530;
                                                                v529[4] = 1;
                                                                v526[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, false;
                                            end;

                                            v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                            v36[5][v36[4]] = u4[UNNAMED_2819735035304[u5]];
                                        end;
                                    elseif v326 < 112 then
                                        if v326 >= 110 then
                                            if v326 == 111 then
                                                u4[UNNAMED_2819735063384[u5]] = u24[UNNAMED_2819735077064[u5]][UNNAMED_2819735050136[u5]];
                                            elseif u4[UNNAMED_2819735075720[u5]] > u4[UNNAMED_2819735063384[u5]] then
                                                u5 = UNNAMED_2819735035304[u5];
                                            end;
                                        else
                                            u8 = u8 + u10;

                                            if u10 <= 0 then
                                                v36 = u9 <= u8;
                                            else
                                                v36 = u8 <= u9;
                                            end;

                                            if v36 then
                                                u4[UNNAMED_2819735035304[u5]] = u8;
                                                u5 = UNNAMED_2819735075720[u5];
                                            else
                                                u5 = UNNAMED_2819735063384[u5];
                                            end;
                                        end;
                                    elseif v326 < 114 then
                                        if v326 == 113 then
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]][UNNAMED_2819735075720[u5]];
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] <= u4[UNNAMED_2819735063384[u5]];
                                        end;
                                    elseif v326 == 115 then
                                        u4[UNNAMED_2819735075720[u5]] = u18(u4[UNNAMED_2819735063384[u5]], UNNAMED_2819735050136[u5]);
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735077064[u5]));
                                    end;
                                elseif v326 < 122 then
                                    if v326 >= 119 then
                                        if v326 < 120 then
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]]();
                                        elseif v326 == 121 then
                                            if u4[UNNAMED_2819735075720[u5]] > UNNAMED_2819735088680[u5] then
                                                u5 = UNNAMED_2819735035304[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735075720[u5]][UNNAMED_2819735088680[u5]] = UNNAMED_2819735035304[u5];
                                        end;
                                    elseif v326 >= 117 then
                                        if v326 == 118 then
                                            local v531;

                                            if u4[UNNAMED_2819735063384[u5]] then
                                                v531 = UNNAMED_2819735035304[u5];
                                            else
                                                v531 = UNNAMED_2819735075720[u5];
                                            end;

                                            u5 = v531;
                                        elseif u4[UNNAMED_2819735063384[u5]] ~= UNNAMED_2819735077064[u5] then
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    else
                                        v36 = UNNAMED_2819735035304[u5];
                                        local v532 = UNNAMED_2819735077064[u5];
                                        u4[v36] = UNNAMED_2819735063384[u5];
                                        u4[v36 + 1] = v532;
                                    end;
                                elseif v326 >= 125 then
                                    if v326 < 127 then
                                        if v326 == 126 then
                                            local v533 = u12;
                                            local v534 = u13;

                                            if v533 then
                                                for i in u15, v533 do
                                                    local v535 = v533[i];

                                                    if v535 then
                                                        v535[5] = v535;
                                                        v535[6] = u4[i];
                                                        v535[4] = 6;
                                                        v533[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v534 then
                                                for i, v in u15, v534 do
                                                    local v536 = v[6];

                                                    if v534 then
                                                        local v537 = v534[i];

                                                        if v537 then
                                                            local v538 = u3(v536);
                                                            u16(u4, i, i + v536 - 1, 1, v538);
                                                            v537[5] = v538;
                                                            v537[4] = 1;
                                                            v534[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735063384[u5], u17(UNNAMED_2819735050136[u5], u4[UNNAMED_2819735075720[u5]]);
                                        end;

                                        u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735075720[u5]] ~= UNNAMED_2819735050136[u5];
                                    elseif v326 == 128 then
                                        v36 = UNNAMED_2819735063384[u5];
                                        local v539 = UNNAMED_2819735077064[u5];
                                        u4[v36] = UNNAMED_2819735050136[u5];
                                        u4[v36 + 1] = v539;
                                    else
                                        local v540 = nil;
                                        local v541 = UNNAMED_2819735075720[u5];
                                        local v542 = UNNAMED_2819735050136[u5];
                                        local v543 = UNNAMED_2819735088680[u5];
                                        local v544 = u12;
                                        local v545 = u13;
                                        local v546 = v543[0];

                                        if v546 then
                                            local v547 = #v546 / 3;

                                            if v547 > 0 then
                                                v540 = {};

                                                for i = 1, v547 do
                                                    local v548 = (i - 1) * 3;
                                                    local v549 = v546[v548 + 2];
                                                    local v550 = v546[v548 + 1];
                                                    local v551;

                                                    if v549 == 2 then
                                                        v544 = v544 or {};
                                                        local v552 = v544[v550];

                                                        if not v552 then
                                                            v552 = {
                                                                [5] = u4,
                                                                [4] = v550
                                                            };
                                                            v544[v550] = v552;
                                                        end;

                                                        v540[i] = v552;
                                                        v551 = i;
                                                    elseif v549 == 0 then
                                                        v540[i] = u4[v550];
                                                        v551 = i;
                                                    elseif v549 == 3 then
                                                        v540[i] = UNNAMED_2819735029544[v550];
                                                        v551 = i;
                                                    elseif v549 == 1 then
                                                        v545 = v545 or {};
                                                        local v553 = v545[v550];

                                                        if not v553 then
                                                            v553 = {
                                                                [5] = u4,
                                                                [4] = v550,
                                                                [6] = v546[v548 + 3]
                                                            };
                                                            v545[v550] = v553;
                                                        end;

                                                        v540[i] = v553;
                                                        v551 = i;
                                                    else
                                                        v551 = i;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v554 = v543[-2];
                                        v543[v554] = v540;
                                        local v555 = v542(u14(v543, 1, v543[-1]));
                                        v543[v554] = nil;
                                        u4[v541] = v555;
                                        u12 = v544;
                                        u13 = v545;
                                    end;
                                elseif v326 >= 123 then
                                    if v326 == 124 then
                                        u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] * UNNAMED_2819735063384[u5];
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u18(UNNAMED_2819735088680[u5], u4[UNNAMED_2819735075720[u5]]);
                                    end;
                                elseif u12 then
                                    local v556 = u12;
                                    local v557 = UNNAMED_2819735035304[u5];
                                    local v558 = v556[v557];

                                    if v558 then
                                        v558[5] = v558;
                                        v558[6] = u4[v557];
                                        v558[4] = 6;
                                        v556[v557] = nil;
                                    end;

                                    local v559 = u12;
                                    local v560 = UNNAMED_2819735075720[u5];
                                    local v561 = v559[v560];

                                    if v561 then
                                        v561[5] = v561;
                                        v561[6] = u4[v560];
                                        v561[4] = 6;
                                        v559[v560] = nil;
                                    end;
                                end;
                            else
                                if v326 >= 142 then
                                    if v326 < 148 then
                                        if v326 < 145 then
                                            if v326 < 143 then
                                                if u4[UNNAMED_2819735075720[u5]] > UNNAMED_2819735035304[u5] then
                                                    u5 = UNNAMED_2819735063384[u5];
                                                end;
                                            elseif v326 == 144 then
                                                u4[UNNAMED_2819735063384[u5]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735075720[u5]];
                                            else
                                                v36 = u18(u1, u21(u20(u1, 14), 262143), (u21(u20(u1, 28), 15)));
                                                v34 = UNNAMED_2819735063384[u5];
                                                v32 = UNNAMED_2819735075720[u5];
                                                v35 = UNNAMED_2819735035304[u5];
                                                v33 = v34 < 2097152 and 7 or 14;
                                                v37 = u21(v34, u22(1, v33) - 1);
                                                local v562 = u20(v34, v33);
                                                UNNAMED_2819735035304[u5] = u18(v35, 67, (u21(u20(v36, 7), 127)));
                                                UNNAMED_2819735072264[u5] = u18(v562, 121, (u21(u20(v36, 21), 127)));
                                                UNNAMED_2819735075720[u5] = u18(v32, 3, (u21(v36, 127)));
                                                UNNAMED_2819735063384[u5] = u18(v37, 31, (u21(u20(v36, 14), 127)));
                                                u5 = u5 - 1;
                                            end;
                                        elseif v326 < 146 then
                                            v36 = UNNAMED_2819735029544[UNNAMED_2819735063384[u5]];
                                            v36[5][v36[4]][UNNAMED_2819735077064[u5]] = UNNAMED_2819735050136[u5];
                                        elseif v326 == 147 then
                                            u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735077064[u5], u4[UNNAMED_2819735035304[u5]]);
                                        else
                                            v36 = UNNAMED_2819735035304[u5];
                                            local v563 = UNNAMED_2819735075720[u5];
                                            u4[v36] = u4[UNNAMED_2819735063384[u5]];
                                            u4[v36 + 1] = v563;
                                        end;
                                    elseif v326 < 151 then
                                        if v326 < 149 then
                                            if u4[UNNAMED_2819735075720[u5]] >= UNNAMED_2819735035304[u5] then
                                                u5 = UNNAMED_2819735063384[u5];
                                            end;
                                        elseif v326 == 150 then
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735063384[u5] / u4[UNNAMED_2819735075720[u5]];
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735075720[u5];
                                        end;
                                    elseif v326 >= 153 then
                                        if v326 == 154 then
                                            u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735063384[u5]], UNNAMED_2819735050136[u5]);
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] == UNNAMED_2819735088680[u5];
                                        end;
                                    elseif v326 == 152 then
                                        UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735088680[u5]] = UNNAMED_2819735075720[u5];
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = u18(u4[UNNAMED_2819735075720[u5]], u4[UNNAMED_2819735035304[u5]]);
                                    end;

                                    v325 = 1;
                                    continue;
                                end;

                                if v326 >= 135 then
                                    if v326 < 138 then
                                        if v326 >= 136 then
                                            if v326 == 137 then
                                                u4[UNNAMED_2819735035304[u5]] = u22(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735063384[u5]);
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u24[UNNAMED_2819735088680[u5]][u4[UNNAMED_2819735075720[u5]]];
                                            end;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]];
                                        end;
                                    elseif v326 >= 140 then
                                        if v326 == 141 then
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] / u4[UNNAMED_2819735063384[u5]];
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5] + UNNAMED_2819735088680[u5];
                                        end;
                                    elseif v326 == 139 then
                                        u4[UNNAMED_2819735075720[u5]][UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]];
                                    elseif u12 then
                                        local v564 = u12;
                                        local v565 = UNNAMED_2819735063384[u5];
                                        local v566 = v564[v565];

                                        if v566 then
                                            v566[5] = v566;
                                            v566[6] = u4[v565];
                                            v566[4] = 6;
                                            v564[v565] = nil;
                                        end;

                                        local v567 = u12;
                                        local v568 = UNNAMED_2819735075720[u5];
                                        local v569 = v567[v568];

                                        if v569 then
                                            v569[5] = v569;
                                            v569[6] = u4[v568];
                                            v569[4] = 6;
                                            v567[v568] = nil;
                                        end;

                                        local v570 = u12;
                                        local v571 = UNNAMED_2819735035304[u5];
                                        local v572 = v570[v571];

                                        if v572 then
                                            v572[5] = v572;
                                            v572[6] = u4[v571];
                                            v572[4] = 6;
                                            v570[v571] = nil;
                                        end;
                                    end;
                                elseif v326 >= 132 then
                                    if v326 < 133 then
                                        u4[UNNAMED_2819735063384[u5]] = u3(UNNAMED_2819735075720[u5]);
                                    elseif v326 == 134 then
                                        local v573 = UNNAMED_2819735075720[u5];
                                        local v574 = UNNAMED_2819735050136[u5];
                                        local v575 = u21(UNNAMED_2819735063384[u5], 4294967295);
                                        local v576 = u21(v574, 4294967295);
                                        local v577 = u21(v575, 65535);
                                        local v578 = u20(v575, 16);
                                        local v579 = u21(v576, 65535);
                                        local v580 = u20(v576, 16);
                                        local v581 = u21(v577 * v579 + u22(u21(v577 * v580 + v578 * v579, 65535), 16), 4294967295) % 4294967296;
                                        u4[v573] = v581 ~= v581 and 0 or v581 - v581 % 1;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] - UNNAMED_2819735077064[u5];
                                    end;
                                else
                                    if v326 < 130 then
                                        u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735063384[u5]], u4[UNNAMED_2819735035304[u5]]);
                                        v325 = 1;
                                        continue;
                                    end;

                                    if v326 == 131 then
                                        u6 = UNNAMED_2819735035304[u5];
                                        u5 = UNNAMED_2819735063384[u5] + 1;
                                        v38 = 3;
                                        break;
                                    end;

                                    u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735050136[u5]);
                                end;
                            end;
                        end;

                        v325 = 1;
                        continue;
                    elseif v325 == 1 then
                        v325 = -1;
                        u5 = u5 + 1;
                        break;
                    else
                        break;
                    end;
                end;

                if v38 ~= -1 then
                    break;
                end;
            end;

            if v38 ~= -1 then
                continue;
            end;

            v38 = 5;
            continue;
        elseif v38 == 5 then
            v38 = -1;

            while true do
                local u5;
                local v582 = 0;

                while true do
                    if v582 == 0 then
                        v582 = -1;
                        local v583 = UNNAMED_2819735063384[u5];

                        if v583 < 95 then
                            if v583 < 47 then
                                if v583 < 23 then
                                    if v583 >= 11 then
                                        if v583 >= 17 then
                                            if v583 >= 20 then
                                                if v583 < 21 then
                                                    u4[UNNAMED_2819735072264[u5]] = not u4[UNNAMED_2819735035304[u5]];
                                                else
                                                    if v583 ~= 22 then
                                                        local v584 = u12;
                                                        local v585 = u13;

                                                        if v584 then
                                                            for i in u15, v584 do
                                                                local v586 = v584[i];

                                                                if v586 then
                                                                    v586[5] = v586;
                                                                    v586[6] = u4[i];
                                                                    v586[4] = 6;
                                                                    v584[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v585 then
                                                            for i, v in u15, v585 do
                                                                local v587 = v[6];

                                                                if v585 then
                                                                    local v588 = v585[i];

                                                                    if v588 then
                                                                        local v589 = u3(v587);
                                                                        u16(u4, i, i + v587 - 1, 1, v589);
                                                                        v588[5] = v589;
                                                                        v588[4] = 1;
                                                                        v585[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return true, true, UNNAMED_2819735035304[u5], u17(UNNAMED_2819735066504[u5], u4[UNNAMED_2819735075720[u5]]);
                                                    end;

                                                    v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                                    v36[5][v36[4]] = u4[UNNAMED_2819735035304[u5]];
                                                end;
                                            elseif v583 < 18 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] == UNNAMED_2819735072264[u5];
                                            elseif v583 == 19 then
                                                u4[UNNAMED_2819735075720[u5]] = u18(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735050136[u5]);
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] < u4[UNNAMED_2819735075720[u5]];
                                            end;
                                        elseif v583 < 14 then
                                            if v583 >= 12 then
                                                if v583 == 13 then
                                                    u24[UNNAMED_2819735077064[u5]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735066504[u5];
                                                else
                                                    u5 = u4[UNNAMED_2819735072264[u5]];
                                                end;
                                            else
                                                v36 = UNNAMED_2819735035304[u5];
                                                v34 = u4[UNNAMED_2819735075720[u5]];
                                                u4[v36 + 1] = v34;
                                                u4[v36] = v34[UNNAMED_2819735066504[u5]];
                                            end;
                                        elseif v583 < 15 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34, v32, v35 = u8();

                                            if v34 then
                                                u4[v36] = v32;
                                                u4[v36 + 1] = v35;
                                                u5 = UNNAMED_2819735075720[u5];
                                            else
                                                u5 = UNNAMED_2819735072264[u5];
                                            end;
                                        elseif v583 == 16 then
                                            v36 = UNNAMED_2819735075720[u5];
                                            v34 = UNNAMED_2819735035304[u5];
                                            v32 = UNNAMED_2819735072264[u5];
                                            v35 = u18(u1, u21(u20(u1, 14), 262143), (u21(u20(u1, 28), 15)));
                                            v33 = v34 < 2097152 and 7 or 14;
                                            v37 = u21(v34, u22(1, v33) - 1);
                                            local v590 = u20(v34, v33);
                                            UNNAMED_2819735035304[u5] = u18(v37, 9, (u21(u20(v35, 7), 127)));
                                            UNNAMED_2819735072264[u5] = u18(v32, 109, (u21(u20(v35, 14), 127)));
                                            UNNAMED_2819735075720[u5] = u18(v36, 42, (u21(v35, 127)));
                                            UNNAMED_2819735063384[u5] = u18(v590, 126, (u21(u20(v35, 21), 127)));
                                            u5 = u5 - 1;
                                        else
                                            v36 = UNNAMED_2819735072264[u5];
                                            local v591 = UNNAMED_2819735077064[u5];
                                            u4[v36] = UNNAMED_2819735035304[u5];
                                            u4[v36 + 1] = v591;
                                        end;
                                    elseif v583 >= 5 then
                                        if v583 < 8 then
                                            if v583 >= 6 then
                                                if v583 == 7 then
                                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]] > UNNAMED_2819735050136[u5];
                                                else
                                                    u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735077064[u5], u4[UNNAMED_2819735072264[u5]]);
                                                end;
                                            else
                                                u2 = u4[UNNAMED_2819735072264[u5]];
                                            end;
                                        elseif v583 < 9 then
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]] / UNNAMED_2819735035304[u5];
                                        else
                                            if v583 == 10 then
                                                local v592 = u12;
                                                local v593 = u13;

                                                if v592 then
                                                    for i in u15, v592 do
                                                        local v594 = v592[i];

                                                        if v594 then
                                                            v594[5] = v594;
                                                            v594[6] = u4[i];
                                                            v594[4] = 6;
                                                            v592[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v593 then
                                                    for i, v in u15, v593 do
                                                        local v595 = v[6];

                                                        if v593 then
                                                            local v596 = v593[i];

                                                            if v596 then
                                                                local v597 = u3(v595);
                                                                u16(u4, i, i + v595 - 1, 1, v597);
                                                                v596[5] = v597;
                                                                v596[4] = 1;
                                                                v593[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, false;
                                            end;

                                            if u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735075720[u5] then
                                                u5 = UNNAMED_2819735072264[u5];
                                            end;
                                        end;
                                    elseif v583 >= 2 then
                                        if v583 < 3 then
                                            v36 = UNNAMED_2819735072264[u5];
                                            local v598 = UNNAMED_2819735035304[u5];
                                            u4[v36] = u4[UNNAMED_2819735075720[u5]];
                                            u4[v36 + 1] = v598;
                                        elseif v583 == 4 then
                                            v36 = UNNAMED_2819735072264[u5];
                                            local v599 = u4[UNNAMED_2819735035304[u5]];
                                            u4[v36] = u4[UNNAMED_2819735075720[u5]];
                                            u4[v36 + 1] = v599;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735072264[u5]]];
                                        end;
                                    elseif v583 == 1 then
                                        v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                        v36[5][v36[4]] = UNNAMED_2819735050136[u5];
                                    else
                                        v36 = UNNAMED_2819735035304[u5];
                                        v34 = u4[UNNAMED_2819735075720[u5]];
                                        u4[v36 + 1] = v34;
                                        u4[v36] = v34[UNNAMED_2819735066504[u5]];
                                        u4[UNNAMED_2819735035304[u5 + 1]] = u4[UNNAMED_2819735075720[u5 + 1]];
                                        u4[UNNAMED_2819735035304[u5 + 2]] = UNNAMED_2819735066504[u5 + 2];
                                        u4[UNNAMED_2819735035304[u5 + 3]] = u4[UNNAMED_2819735075720[u5 + 3]];
                                        u5 = u5 + 3;
                                    end;
                                elseif v583 >= 35 then
                                    if v583 >= 41 then
                                        if v583 < 44 then
                                            if v583 >= 42 then
                                                if v583 == 43 then
                                                    v36 = UNNAMED_2819735075720[u5];
                                                    v34, v32 = u8();

                                                    if v34 then
                                                        u4[v36] = v32;
                                                        u5 = UNNAMED_2819735072264[u5];
                                                    else
                                                        u5 = UNNAMED_2819735035304[u5];
                                                    end;
                                                else
                                                    u4[UNNAMED_2819735072264[u5]] = u25(u4[UNNAMED_2819735035304[u5]]);
                                                end;
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735035304;
                                            end;
                                        elseif v583 >= 45 then
                                            if v583 == 46 then
                                                u4[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735075720[u5]]] = UNNAMED_2819735066504[u5];
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] - u4[UNNAMED_2819735075720[u5]];
                                            end;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]][UNNAMED_2819735050136[u5]];
                                        end;
                                    elseif v583 < 38 then
                                        if v583 < 36 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = UNNAMED_2819735072264[u5];
                                            v32 = UNNAMED_2819735075720[u5];
                                            v35 = v36 + v34;
                                            v33 = u4[v35];
                                            v37 = v33.n;
                                            v33.n = v34 + v37 - 1;
                                            u16(v33, 1, v37, v34, v33);
                                            u16(u4, v36 + 1, v35 - 1, 1, v33);
                                            u4[v36] = u17(u4[v36](u14(v33, 1, v33.n)));
                                        elseif v583 == 37 then
                                            v36 = UNNAMED_2819735072264[u5];
                                            v34 = UNNAMED_2819735035304[u5];
                                            v32 = UNNAMED_2819735075720[u5];
                                            v35 = u4[v36];
                                            u16(u4, v36 + 1, v36 + v34, v32 + 1, v35);
                                        elseif u4[UNNAMED_2819735075720[u5]] ~= UNNAMED_2819735072264[u5] then
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    elseif v583 >= 39 then
                                        if v583 == 40 then
                                            u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] .. u4[UNNAMED_2819735035304[u5]];
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] % u4[UNNAMED_2819735075720[u5]];
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5] + u4[UNNAMED_2819735072264[u5]];
                                    end;
                                elseif v583 < 29 then
                                    if v583 < 26 then
                                        if v583 >= 24 then
                                            if v583 == 25 then
                                                u24[UNNAMED_2819735050136[u5]][u4[UNNAMED_2819735075720[u5]]] = UNNAMED_2819735066504[u5];
                                            else
                                                u4[UNNAMED_2819735072264[u5]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735075720[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] - UNNAMED_2819735077064[u5];
                                        end;
                                    elseif v583 < 27 then
                                        u4[UNNAMED_2819735072264[u5]] = u24[UNNAMED_2819735077064[u5]][u4[UNNAMED_2819735035304[u5]]];
                                    elseif v583 == 28 then
                                        if UNNAMED_2819735035304[u5] > u4[UNNAMED_2819735075720[u5]] then
                                            u5 = UNNAMED_2819735072264[u5];
                                        end;
                                    else
                                        v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                        u4[UNNAMED_2819735075720[u5]] = v36[5][v36[4]][UNNAMED_2819735066504[u5]];
                                    end;
                                elseif v583 >= 32 then
                                    if v583 < 33 then
                                        u8 = u8 + u10;

                                        if u10 <= 0 then
                                            v36 = u9 <= u8;
                                        else
                                            v36 = u8 <= u9;
                                        end;

                                        if v36 then
                                            u4[UNNAMED_2819735072264[u5]] = u8;
                                            u5 = UNNAMED_2819735075720[u5];
                                        else
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    elseif v583 == 34 then
                                        u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735066504[u5];
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] / u4[UNNAMED_2819735072264[u5]];
                                    end;
                                elseif v583 >= 30 then
                                    if v583 == 31 then
                                        local v600 = u12;
                                        local v601 = u13;

                                        if v600 then
                                            for i in u15, v600 do
                                                local v602 = v600[i];

                                                if v602 then
                                                    v602[5] = v602;
                                                    v602[6] = u4[i];
                                                    v602[4] = 6;
                                                    v600[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v601 then
                                            for i, v in u15, v601 do
                                                local v603 = v[6];

                                                if v601 then
                                                    local v604 = v601[i];

                                                    if v604 then
                                                        local v605 = u3(v603);
                                                        u16(u4, i, i + v603 - 1, 1, v605);
                                                        v604[5] = v605;
                                                        v604[4] = 1;
                                                        v601[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(u4[UNNAMED_2819735072264[u5]], u4[UNNAMED_2819735075720[u5]]);
                                    end;

                                    u4[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735072264[u5]]] = u4[UNNAMED_2819735075720[u5]];
                                else
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                end;
                            elseif v583 >= 71 then
                                if v583 >= 83 then
                                    if v583 < 89 then
                                        if v583 < 86 then
                                            if v583 >= 84 then
                                                if v583 == 85 then
                                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] + UNNAMED_2819735066504[u5];
                                                else
                                                    v36 = UNNAMED_2819735075720[u5];
                                                    v34 = UNNAMED_2819735072264[u5];
                                                    v32 = UNNAMED_2819735035304[u5];
                                                    v35 = v36 + v32 - 1;
                                                    v33 = v36 + v34;
                                                    v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                                    u16(v37, 1, v32, v36, u4);
                                                end;
                                            else
                                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]] > UNNAMED_2819735035304[u5];
                                            end;
                                        elseif v583 < 87 then
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735066504[u5] .. u4[UNNAMED_2819735035304[u5]];
                                        elseif v583 == 88 then
                                            if UNNAMED_2819735066504[u5] >= u4[UNNAMED_2819735035304[u5]] then
                                                u5 = UNNAMED_2819735075720[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = {};
                                        end;
                                    elseif v583 < 92 then
                                        if v583 < 90 then
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735058152;
                                        elseif v583 == 91 then
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] + UNNAMED_2819735075720[u5];
                                        elseif u4[UNNAMED_2819735075720[u5]] > UNNAMED_2819735066504[u5] then
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    elseif v583 >= 93 then
                                        if v583 == 94 then
                                            u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735072264[u5] ^ u4[UNNAMED_2819735035304[u5]];
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u21(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735075720[u5]);
                                        end;
                                    else
                                        local v606 = UNNAMED_2819735072264[u5];
                                        local v607 = u4[UNNAMED_2819735035304[u5]];
                                        local v608 = u21(UNNAMED_2819735077064[u5], 4294967295);
                                        local v609 = u21(v607, 4294967295);
                                        local v610 = u21(v608, 65535);
                                        local v611 = u20(v608, 16);
                                        local v612 = u21(v609, 65535);
                                        local v613 = u20(v609, 16);
                                        local v614 = u21(v610 * v612 + u22(u21(v610 * v613 + v611 * v612, 65535), 16), 4294967295) % 4294967296;
                                        u4[v606] = v614 ~= v614 and 0 or v614 - v614 % 1;
                                    end;
                                elseif v583 >= 77 then
                                    if v583 < 80 then
                                        if v583 >= 78 then
                                            if v583 == 79 then
                                                if u12 then
                                                    local v615 = u12;
                                                    local v616 = UNNAMED_2819735075720[u5];
                                                    local v617 = v615[v616];

                                                    if v617 then
                                                        v617[5] = v617;
                                                        v617[6] = u4[v616];
                                                        v617[4] = 6;
                                                        v615[v616] = nil;
                                                    end;

                                                    local v618 = u12;
                                                    local v619 = UNNAMED_2819735035304[u5];
                                                    local v620 = v618[v619];

                                                    if v620 then
                                                        v620[5] = v620;
                                                        v620[6] = u4[v619];
                                                        v620[4] = 6;
                                                        v618[v619] = nil;
                                                    end;

                                                    local v621 = u12;
                                                    local v622 = UNNAMED_2819735072264[u5];
                                                    local v623 = v621[v622];

                                                    if v623 then
                                                        v623[5] = v623;
                                                        v623[6] = u4[v622];
                                                        v623[4] = 6;
                                                        v621[v622] = nil;
                                                    end;
                                                end;
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] % UNNAMED_2819735066504[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735077064[u5] * UNNAMED_2819735066504[u5];
                                        end;
                                    elseif v583 < 81 then
                                        u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]]();
                                    else
                                        if v583 == 82 then
                                            local v624 = u12;
                                            local v625 = u13;

                                            if v624 then
                                                for i in u15, v624 do
                                                    local v626 = v624[i];

                                                    if v626 then
                                                        v626[5] = v626;
                                                        v626[6] = u4[i];
                                                        v626[4] = 6;
                                                        v624[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v625 then
                                                for i, v in u15, v625 do
                                                    local v627 = v[6];

                                                    if v625 then
                                                        local v628 = v625[i];

                                                        if v628 then
                                                            local v629 = u3(v627);
                                                            u16(u4, i, i + v627 - 1, 1, v629);
                                                            v628[5] = v629;
                                                            v628[4] = 1;
                                                            v625[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735035304[u5], u17(UNNAMED_2819735066504[u5]);
                                        end;

                                        v36 = UNNAMED_2819735035304[u5];
                                        local v630 = UNNAMED_2819735066504[u5];
                                        u4[v36] = UNNAMED_2819735077064[u5];
                                        u4[v36 + 1] = v630;
                                    end;
                                elseif v583 < 74 then
                                    if v583 < 72 then
                                        u1 = u4[UNNAMED_2819735075720[u5]];
                                    elseif v583 == 73 then
                                        local v631 = UNNAMED_2819735075720[u5];
                                        local v632 = u18(UNNAMED_2819735035304[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));
                                        local v633 = UNNAMED_2819735058152[5];
                                        local v634 = u18(v633[v631], 109162203);
                                        v633[v631] = v634;
                                        local v635 = UNNAMED_2819735058152[4];
                                        local v636 = v634 + 1;
                                        local v637 = u28(v635, v636);
                                        local v638;

                                        if v637 < 128 then
                                            v638 = v636 + 1;
                                        else
                                            local v639 = u28(v635, v636 + 1);

                                            if v639 < 128 then
                                                v637 = v637 - 128 + v639 * 128;
                                                v638 = v636 + 2;
                                            else
                                                local v640 = u28(v635, v636 + 2);

                                                if v640 < 128 then
                                                    v637 = v637 - 128 + (v639 - 128) * 16384 + v640 * 128;
                                                    v638 = v636 + 3;
                                                else
                                                    local v641 = u28(v635, v636 + 3);
                                                    v637 = (v637 - 128) * 16384 + (v639 - 128) * 128 + (v640 - 128) + v641 % 128 * 2097152 + (v641 - v641 % 128) * 2097152;
                                                    v638 = v636 + 4;
                                                end;
                                            end;
                                        end;

                                        local v642 = v632 * 16843009;
                                        local v643 = v638 + v637;
                                        local v644 = v643 - v637 % 4;

                                        for i = v638, v644 - 1, 4 do
                                            u29(v635, i, (u18(u30(v635, i), v642)));
                                            local _ = i;
                                        end;

                                        for i = v644, v643 - 1 do
                                            u31(v635, i, (u18(u28(v635, i), v632)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735075720[u5] = 163;
                                        UNNAMED_2819735035304[u5] = 35;
                                        UNNAMED_2819735072264[u5] = 219;
                                        UNNAMED_2819735063384[u5] = 190;
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = u22(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735075720[u5]);
                                    end;
                                else
                                    if v583 < 75 then
                                        local v645 = u12;
                                        local v646 = u13;

                                        if v645 then
                                            for i in u15, v645 do
                                                local v647 = v645[i];

                                                if v647 then
                                                    v647[5] = v647;
                                                    v647[6] = u4[i];
                                                    v647[4] = 6;
                                                    v645[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v646 then
                                            for i, v in u15, v646 do
                                                local v648 = v[6];

                                                if v646 then
                                                    local v649 = v646[i];

                                                    if v649 then
                                                        local v650 = u3(v648);
                                                        u16(u4, i, i + v648 - 1, 1, v650);
                                                        v649[5] = v650;
                                                        v649[4] = 1;
                                                        v646[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(u4[UNNAMED_2819735075720[u5]]);
                                    end;

                                    if v583 == 76 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]];
                                        u4[UNNAMED_2819735035304[u5 + 1]] = UNNAMED_2819735066504[u5 + 1];
                                        u4[UNNAMED_2819735035304[u5 + 2]] = u4[UNNAMED_2819735075720[u5 + 2]];
                                        v36 = UNNAMED_2819735075720[u5 + 3];
                                        v34 = u4[v36];
                                        v32 = u4[v36 + 1];
                                        v35 = u4[v36 + 2];
                                        u4[v36] = v34(v32, v35);
                                        u5 = u5 + 3;
                                    else
                                        u24[UNNAMED_2819735066504[u5]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735075720[u5]];
                                    end;
                                end;
                            elseif v583 < 59 then
                                if v583 < 53 then
                                    if v583 < 50 then
                                        if v583 >= 48 then
                                            if v583 == 49 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] // UNNAMED_2819735075720[u5];
                                            else
                                                v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                                u4[UNNAMED_2819735072264[u5]] = v36[5][v36[4]];
                                            end;
                                        else
                                            u5 = u4[UNNAMED_2819735035304[u5]];
                                        end;
                                    elseif v583 >= 51 then
                                        if v583 ~= 52 then
                                            local v651 = u12;
                                            local v652 = u13;

                                            if v651 then
                                                for i in u15, v651 do
                                                    local v653 = v651[i];

                                                    if v653 then
                                                        v653[5] = v653;
                                                        v653[6] = u4[i];
                                                        v653[4] = 6;
                                                        v651[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v652 then
                                                for i, v in u15, v652 do
                                                    local v654 = v[6];

                                                    if v652 then
                                                        local v655 = v652[i];

                                                        if v655 then
                                                            local v656 = u3(v654);
                                                            u16(u4, i, i + v654 - 1, 1, v656);
                                                            v655[5] = v656;
                                                            v655[4] = 1;
                                                            v652[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735035304[u5], u17(u4[UNNAMED_2819735075720[u5]]);
                                        end;

                                        v36 = UNNAMED_2819735072264[u5] + 1;
                                        v34 = UNNAMED_2819735075720[u5];

                                        for i = 1, UNNAMED_2819735035304[u5] do
                                            local v657 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                            local v658 = u18(v657, (u20(v657, 13)));
                                            v34 = u21(u18(v658, (u22(v658, 14))), 536870911);
                                            UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                            UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                            UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 14), 127)));
                                            UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 21), 127)));
                                            v36 = v36 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735063384[u5] = 190;
                                    elseif UNNAMED_2819735072264[u5] >= u4[UNNAMED_2819735035304[u5]] then
                                        u5 = UNNAMED_2819735075720[u5];
                                    end;
                                elseif v583 < 56 then
                                    if v583 < 54 then
                                        u24[UNNAMED_2819735077064[u5]][u4[UNNAMED_2819735072264[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                    elseif v583 == 55 then
                                        u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735075720[u5] - u4[UNNAMED_2819735072264[u5]];
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735072264;
                                    end;
                                elseif v583 < 57 then
                                    if u4[UNNAMED_2819735072264[u5]] > u4[UNNAMED_2819735035304[u5]] then
                                        u5 = UNNAMED_2819735075720[u5];
                                    end;
                                elseif v583 == 58 then
                                    u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735072264[u5]]);
                                else
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]][UNNAMED_2819735077064[u5]];
                                end;
                            elseif v583 < 65 then
                                if v583 < 62 then
                                    if v583 < 60 then
                                        u4[UNNAMED_2819735035304[u5]]();
                                    elseif v583 == 61 then
                                        local v659 = UNNAMED_2819735035304[u5];
                                        local v660 = u4[UNNAMED_2819735075720[u5]];
                                        u4[v659 + 1] = v660;
                                        u4[v659] = v660[UNNAMED_2819735066504[u5]];
                                        u4[UNNAMED_2819735035304[u5 + 1]] = u4[UNNAMED_2819735075720[u5 + 1]];
                                        u4[UNNAMED_2819735035304[u5 + 2]] = UNNAMED_2819735066504[u5 + 2];
                                        u4[UNNAMED_2819735035304[u5 + 3]] = u4[UNNAMED_2819735075720[u5 + 3]];
                                        v36 = UNNAMED_2819735075720[u5 + 4];
                                        v34 = u4[v36];
                                        v32 = u4[v36 + 1];
                                        v35 = u4[v36 + 2];
                                        u4[v36] = v34(v32, v35);
                                        u5 = u5 + 4;
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735075720;
                                    end;
                                else
                                    if v583 < 63 then
                                        local v661 = u12;
                                        local v662 = u13;

                                        if v661 then
                                            for i in u15, v661 do
                                                local v663 = v661[i];

                                                if v663 then
                                                    v663[5] = v663;
                                                    v663[6] = u4[i];
                                                    v663[4] = 6;
                                                    v661[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v662 then
                                            for i, v in u15, v662 do
                                                local v664 = v[6];

                                                if v662 then
                                                    local v665 = v662[i];

                                                    if v665 then
                                                        local v666 = u3(v664);
                                                        u16(u4, i, i + v664 - 1, 1, v666);
                                                        v665[5] = v666;
                                                        v665[4] = 1;
                                                        v662[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(u4[UNNAMED_2819735035304[u5]], u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n));
                                    end;

                                    if v583 == 64 then
                                        u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] ~= UNNAMED_2819735072264[u5];
                                    else
                                        u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735077064[u5]);
                                    end;
                                end;
                            elseif v583 >= 68 then
                                if v583 < 69 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] * UNNAMED_2819735066504[u5];
                                elseif v583 == 70 then
                                    u4[UNNAMED_2819735075720[u5]] = u19(u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735072264[u5]]);
                                else
                                    u4[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735072264[u5]]] = UNNAMED_2819735075720[u5];
                                end;
                            elseif v583 < 66 then
                                UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735072264[u5];
                            elseif v583 == 67 then
                                u4[UNNAMED_2819735035304[u5]] = u18(u4[UNNAMED_2819735075720[u5]], UNNAMED_2819735072264[u5]);
                            else
                                local v667 = UNNAMED_2819735075720[u5];
                                local v668 = u4[UNNAMED_2819735072264[u5]];
                                local v669 = u21(u4[UNNAMED_2819735035304[u5]], 4294967295);
                                local v670 = u21(v668, 4294967295);
                                local v671 = u21(v669, 65535);
                                local v672 = u20(v669, 16);
                                local v673 = u21(v670, 65535);
                                local v674 = u20(v670, 16);
                                local v675 = u21(v671 * v673 + u22(u21(v671 * v674 + v672 * v673, 65535), 16), 4294967295) % 4294967296;
                                u4[v667] = v675 ~= v675 and 0 or v675 - v675 % 1;
                            end;
                        elseif v583 < 143 then
                            if v583 < 119 then
                                if v583 >= 107 then
                                    if v583 >= 113 then
                                        if v583 < 116 then
                                            if v583 < 114 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] // u4[UNNAMED_2819735075720[u5]];
                                            elseif v583 == 115 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] ~= u4[UNNAMED_2819735072264[u5]];
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735066504[u5];
                                                u4[UNNAMED_2819735035304[u5 + 1]] = u4[UNNAMED_2819735075720[u5 + 1]];
                                                v36 = UNNAMED_2819735075720[u5 + 2];
                                                v34 = u4[v36];
                                                v32 = u4[v36 + 1];
                                                v35 = u4[v36 + 2];
                                                u4[v36] = v34(v32, v35);
                                                u5 = u5 + 2;
                                            end;
                                        elseif v583 < 117 then
                                            UNNAMED_2819735029544[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735075720[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                        elseif v583 == 118 then
                                            local v676;

                                            if u4[UNNAMED_2819735035304[u5]] then
                                                v676 = UNNAMED_2819735075720[u5];
                                            else
                                                v676 = UNNAMED_2819735072264[u5];
                                            end;

                                            u5 = v676;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u20(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735035304[u5]);
                                        end;
                                    elseif v583 < 110 then
                                        if v583 >= 108 then
                                            if v583 ~= 109 then
                                                local v677 = u12;
                                                local v678 = u13;

                                                if v677 then
                                                    for i in u15, v677 do
                                                        local v679 = v677[i];

                                                        if v679 then
                                                            v679[5] = v679;
                                                            v679[6] = u4[i];
                                                            v679[4] = 6;
                                                            v677[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v678 then
                                                    for i, v in u15, v678 do
                                                        local v680 = v[6];

                                                        if v678 then
                                                            local v681 = v678[i];

                                                            if v681 then
                                                                local v682 = u3(v680);
                                                                u16(u4, i, i + v680 - 1, 1, v682);
                                                                v681[5] = v682;
                                                                v681[4] = 1;
                                                                v678[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(UNNAMED_2819735066504[u5], UNNAMED_2819735077064[u5]);
                                            end;

                                            u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735063384;
                                        else
                                            v36 = UNNAMED_2819735035304[u5];
                                            local v683 = UNNAMED_2819735072264[u5];
                                            u4[v36] = UNNAMED_2819735075720[u5];
                                            u4[v36 + 1] = v683;
                                        end;
                                    elseif v583 >= 111 then
                                        if v583 == 112 then
                                            UNNAMED_2819735029544[UNNAMED_2819735075720[u5]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735072264[u5]];
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735077064[u5]);
                                        end;
                                    elseif u12 then
                                        local v684 = u12;
                                        local v685 = UNNAMED_2819735075720[u5];
                                        local v686 = v684[v685];

                                        if v686 then
                                            v686[5] = v686;
                                            v686[6] = u4[v685];
                                            v686[4] = 6;
                                            v684[v685] = nil;
                                        end;

                                        local v687 = u12;
                                        local v688 = UNNAMED_2819735072264[u5];
                                        local v689 = v687[v688];

                                        if v689 then
                                            v689[5] = v689;
                                            v689[6] = u4[v688];
                                            v689[4] = 6;
                                            v687[v688] = nil;
                                        end;
                                    end;
                                elseif v583 < 101 then
                                    if v583 < 98 then
                                        if v583 < 96 then
                                            local v690 = u12;
                                            local v691 = u13;

                                            if v690 then
                                                for i in u15, v690 do
                                                    local v692 = v690[i];

                                                    if v692 then
                                                        v692[5] = v692;
                                                        v692[6] = u4[i];
                                                        v692[4] = 6;
                                                        v690[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v691 then
                                                for i, v in u15, v691 do
                                                    local v693 = v[6];

                                                    if v691 then
                                                        local v694 = v691[i];

                                                        if v694 then
                                                            local v695 = u3(v693);
                                                            u16(u4, i, i + v693 - 1, 1, v695);
                                                            v694[5] = v695;
                                                            v694[4] = 1;
                                                            v691[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u17(UNNAMED_2819735066504[u5]);
                                        end;

                                        if v583 == 97 then
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]](u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n));
                                        else
                                            u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735072264[u5]]);
                                        end;
                                    elseif v583 < 99 then
                                        if u4[UNNAMED_2819735035304[u5]] ~= u4[UNNAMED_2819735072264[u5]] then
                                            u5 = UNNAMED_2819735075720[u5];
                                        end;
                                    elseif v583 == 100 then
                                        u4[UNNAMED_2819735035304[u5]] = u24[UNNAMED_2819735077064[u5]];
                                    else
                                        local v696 = nil;
                                        local v697 = UNNAMED_2819735035304[u5];
                                        local v698 = UNNAMED_2819735066504[u5];
                                        local v699 = UNNAMED_2819735077064[u5];
                                        local v700 = u12;
                                        local v701 = u13;
                                        local v702 = v699[0];

                                        if v702 then
                                            local v703 = #v702 / 3;

                                            if v703 > 0 then
                                                v696 = {};

                                                for i = 1, v703 do
                                                    local v704 = (i - 1) * 3;
                                                    local v705 = v702[v704 + 2];
                                                    local v706 = v702[v704 + 1];
                                                    local v707;

                                                    if v705 == 2 then
                                                        v700 = v700 or {};
                                                        local v708 = v700[v706];

                                                        if not v708 then
                                                            v708 = {
                                                                [5] = u4,
                                                                [4] = v706
                                                            };
                                                            v700[v706] = v708;
                                                        end;

                                                        v696[i] = v708;
                                                        v707 = i;
                                                    elseif v705 == 0 then
                                                        v696[i] = u4[v706];
                                                        v707 = i;
                                                    elseif v705 == 3 then
                                                        v696[i] = UNNAMED_2819735029544[v706];
                                                        v707 = i;
                                                    elseif v705 == 1 then
                                                        v701 = v701 or {};
                                                        local v709 = v701[v706];

                                                        if not v709 then
                                                            v709 = {
                                                                [5] = u4,
                                                                [4] = v706,
                                                                [6] = v702[v704 + 3]
                                                            };
                                                            v701[v706] = v709;
                                                        end;

                                                        v696[i] = v709;
                                                        v707 = i;
                                                    else
                                                        v707 = i;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v710 = v699[-2];
                                        v699[v710] = v696;
                                        local v711 = v698(u14(v699, 1, v699[-1]));
                                        v699[v710] = nil;
                                        u4[v697] = v711;
                                        u12 = v700;
                                        u13 = v701;
                                    end;
                                elseif v583 < 104 then
                                    if v583 >= 102 then
                                        if v583 == 103 then
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735075720[u5] * u4[UNNAMED_2819735072264[u5]];
                                        elseif u4[UNNAMED_2819735035304[u5]] ~= UNNAMED_2819735077064[u5] then
                                            u5 = UNNAMED_2819735072264[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735075720[u5]] = u17(u4[UNNAMED_2819735072264[u5]]());
                                    end;
                                elseif v583 >= 105 then
                                    if v583 == 106 then
                                        v36 = UNNAMED_2819735029544[UNNAMED_2819735075720[u5]];
                                        v36[5][v36[4]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735050136[u5];
                                    else
                                        u24[UNNAMED_2819735077064[u5]] = u4[UNNAMED_2819735035304[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] == UNNAMED_2819735066504[u5];
                                end;
                            elseif v583 < 131 then
                                if v583 < 125 then
                                    if v583 < 122 then
                                        if v583 >= 120 then
                                            if v583 == 121 then
                                                u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]] % UNNAMED_2819735035304[u5];
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] / UNNAMED_2819735077064[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] >= UNNAMED_2819735075720[u5];
                                        end;
                                    elseif v583 < 123 then
                                        u4[UNNAMED_2819735035304[u5]] = u18(u4[UNNAMED_2819735072264[u5]], u4[UNNAMED_2819735075720[u5]]);
                                    elseif v583 == 124 then
                                        v36 = UNNAMED_2819735075720[u5] + 1;
                                        v34 = u18(UNNAMED_2819735035304[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));

                                        for i = 1, UNNAMED_2819735072264[u5] do
                                            local v712 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                            local v713 = u18(v712, (u20(v712, 13)));
                                            v34 = u21(u18(v713, (u22(v713, 14))), 536870911);
                                            UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                            UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                            UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 14), 127)));
                                            UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 21), 127)));
                                            v36 = v36 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735063384[u5] = 190;
                                    else
                                        u4[UNNAMED_2819735075720[u5]] = #u4[UNNAMED_2819735035304[u5]];
                                    end;
                                elseif v583 >= 128 then
                                    if v583 >= 129 then
                                        if v583 == 130 then
                                            u7 = {
                                                [6] = u11,
                                                [5] = u9,
                                                [9] = u7,
                                                [8] = u8,
                                                [7] = u10
                                            };
                                            v36 = UNNAMED_2819735075720[u5];
                                            v34 = u26(u27);
                                            v34(UNNAMED_2819735088728, u4[v36], u4[v36 + 1], u4[v36 + 2]);
                                            u8 = v34;
                                            u11 = UNNAMED_2819735035304[u5];
                                            u5 = UNNAMED_2819735072264[u5];
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] <= UNNAMED_2819735075720[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735075720[u5]], u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                                    end;
                                elseif v583 >= 126 then
                                    if v583 == 127 then
                                        u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735066504[u5]] = u4[UNNAMED_2819735075720[u5]];
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] * u4[UNNAMED_2819735075720[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]];
                                end;
                            elseif v583 >= 137 then
                                if v583 < 140 then
                                    if v583 < 138 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] - UNNAMED_2819735072264[u5];
                                    elseif v583 == 139 then
                                        v36 = UNNAMED_2819735035304[u5];
                                        v34 = UNNAMED_2819735075720[u5];
                                        v32 = UNNAMED_2819735072264[u5];
                                        v35 = v36 + v32 - 1;
                                        v33 = v36 + v34;
                                        v37 = u4[v33];
                                        local n = v37.n;
                                        v37.n = v34 + n - 1;
                                        u16(v37, 1, n, v34, v37);
                                        u16(u4, v36 + 1, v33 - 1, 1, v37);
                                        u16(u17(u4[v36](u14(v37, 1, v37.n))), 1, v32, v36, u4);
                                    else
                                        u4[UNNAMED_2819735075720[u5]] = -u4[UNNAMED_2819735035304[u5]];
                                    end;
                                elseif v583 < 141 then
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735072264[u5]](u4[UNNAMED_2819735035304[u5]]);
                                else
                                    if v583 == 142 then
                                        local v714 = u12;
                                        local v715 = u13;

                                        if v714 then
                                            for i in u15, v714 do
                                                local v716 = v714[i];

                                                if v716 then
                                                    v716[5] = v716;
                                                    v716[6] = u4[i];
                                                    v716[4] = 6;
                                                    v714[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v715 then
                                            for i, v in u15, v715 do
                                                local v717 = v[6];

                                                if v715 then
                                                    local v718 = v715[i];

                                                    if v718 then
                                                        local v719 = u3(v717);
                                                        u16(u4, i, i + v717 - 1, 1, v719);
                                                        v718[5] = v719;
                                                        v718[4] = 1;
                                                        v715[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735077064[u5]);
                                    end;

                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735077064[u5];
                                end;
                            elseif v583 >= 134 then
                                if v583 < 135 then
                                    local v720 = u12;
                                    local v721 = u13;

                                    if v720 then
                                        for i in u15, v720 do
                                            local v722 = v720[i];

                                            if v722 then
                                                v722[5] = v722;
                                                v722[6] = u4[i];
                                                v722[4] = 6;
                                                v720[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v721 then
                                        for i, v in u15, v721 do
                                            local v723 = v[6];

                                            if v721 then
                                                local v724 = v721[i];

                                                if v724 then
                                                    local v725 = u3(v723);
                                                    u16(u4, i, i + v723 - 1, 1, v725);
                                                    v724[5] = v725;
                                                    v724[4] = 1;
                                                    v721[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u17(UNNAMED_2819735050136[u5], u4[UNNAMED_2819735075720[u5]]);
                                end;

                                if v583 == 136 then
                                    u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735072264[u5]];
                                else
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735075720[u5]]];
                                end;
                            elseif v583 >= 132 then
                                if v583 == 133 then
                                    u4[UNNAMED_2819735075720[u5]](UNNAMED_2819735066504[u5], u14(u4[UNNAMED_2819735035304[u5]], 1, u4[UNNAMED_2819735035304[u5]].n));
                                else
                                    local v726;

                                    if u4[UNNAMED_2819735072264[u5]] then
                                        v726 = UNNAMED_2819735035304[u5];
                                    else
                                        v726 = UNNAMED_2819735075720[u5];
                                    end;

                                    u5 = v726;
                                end;
                            else
                                u4[UNNAMED_2819735072264[u5]] = u2;
                            end;
                        elseif v583 >= 167 then
                            if v583 >= 179 then
                                if v583 >= 185 then
                                    if v583 >= 188 then
                                        if v583 < 189 then
                                            u4[UNNAMED_2819735072264[u5]] = u1;
                                        elseif v583 ~= 190 then
                                            v36 = UNNAMED_2819735075720[u5] + 1;
                                            v34 = u18(UNNAMED_2819735035304[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));

                                            for i = 1, UNNAMED_2819735072264[u5] do
                                                local v727 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                                local v728 = u18(v727, (u20(v727, 13)));
                                                v34 = u21(u18(v728, (u22(v728, 14))), 536870911);
                                                UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 0), 127)));
                                                UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 7), 127)));
                                                UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 14), 127)));
                                                UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 21), 127)));
                                                v36 = v36 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735063384[u5] = 190;
                                        end;
                                    elseif v583 < 186 then
                                        UNNAMED_2819735029544[UNNAMED_2819735072264[u5]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735077064[u5];
                                    elseif v583 == 187 then
                                        local v729 = UNNAMED_2819735075720[u5];
                                        local v730 = UNNAMED_2819735050136[u5];
                                        local v731 = u21(UNNAMED_2819735066504[u5], 4294967295);
                                        local v732 = u21(v730, 4294967295);
                                        local v733 = u21(v731, 65535);
                                        local v734 = u20(v731, 16);
                                        local v735 = u21(v732, 65535);
                                        local v736 = u20(v732, 16);
                                        local v737 = u21(v733 * v735 + u22(u21(v733 * v736 + v734 * v735, 65535), 16), 4294967295) % 4294967296;
                                        u4[v729] = v737 ~= v737 and 0 or v737 - v737 % 1;
                                    elseif u4[UNNAMED_2819735075720[u5]] > UNNAMED_2819735072264[u5] then
                                        u5 = UNNAMED_2819735035304[u5];
                                    end;
                                elseif v583 < 182 then
                                    if v583 >= 180 then
                                        if v583 == 181 then
                                            u4[UNNAMED_2819735035304[u5]] = u21(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735077064[u5]);
                                        elseif UNNAMED_2819735077064[u5] > u4[UNNAMED_2819735035304[u5]] then
                                            u5 = UNNAMED_2819735072264[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735075720[u5]][UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]];
                                    end;
                                elseif v583 < 183 then
                                    v36 = UNNAMED_2819735075720[u5];
                                    v34 = u4[v36];
                                    v32 = u4[v36 + 1];
                                    v35 = u4[v36 + 2];
                                    u4[v36] = v34(v32, v35);
                                elseif v583 == 184 then
                                    u4[UNNAMED_2819735072264[u5]](u14(u4[UNNAMED_2819735075720[u5]], 1, u4[UNNAMED_2819735075720[u5]].n));
                                else
                                    local v738 = UNNAMED_2819735075720[u5];
                                    local v739 = u18(UNNAMED_2819735035304[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));
                                    local v740 = UNNAMED_2819735058152[5];
                                    local v741 = u18(v740[v738], 109162203);
                                    v740[v738] = v741;
                                    local v742 = UNNAMED_2819735058152[4];
                                    local v743 = v741 + 1;
                                    local v744 = u28(v742, v743);
                                    local v745;

                                    if v744 < 128 then
                                        v745 = v743 + 1;
                                    else
                                        local v746 = u28(v742, v743 + 1);

                                        if v746 < 128 then
                                            v744 = v744 - 128 + v746 * 128;
                                            v745 = v743 + 2;
                                        else
                                            local v747 = u28(v742, v743 + 2);

                                            if v747 < 128 then
                                                v744 = v744 - 128 + (v746 - 128) * 16384 + v747 * 128;
                                                v745 = v743 + 3;
                                            else
                                                local v748 = u28(v742, v743 + 3);
                                                v744 = (v744 - 128) * 16384 + (v746 - 128) * 128 + (v747 - 128) + v748 % 128 * 2097152 + (v748 - v748 % 128) * 2097152;
                                                v745 = v743 + 4;
                                            end;
                                        end;
                                    end;

                                    local v749 = v739 * 16843009;
                                    local v750 = v745 + v744;
                                    local v751 = v750 - v744 % 4;

                                    for i = v745, v751 - 1, 4 do
                                        u29(v742, i, (u18(u30(v742, i), v749)));
                                        local _ = i;
                                    end;

                                    for i = v751, v750 - 1 do
                                        u31(v742, i, (u18(u28(v742, i), v739)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735075720[u5] = 133;
                                    UNNAMED_2819735035304[u5] = 151;
                                    UNNAMED_2819735072264[u5] = 44;
                                    UNNAMED_2819735063384[u5] = 190;
                                end;
                            elseif v583 >= 173 then
                                if v583 >= 176 then
                                    if v583 >= 177 then
                                        if v583 == 178 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = UNNAMED_2819735075720[u5];
                                            v32 = UNNAMED_2819735072264[u5];
                                            v35 = u18(u1, u21(u20(u1, 14), 262143), (u21(u20(u1, 28), 15)));
                                            v33 = v34 < 16384 and 7 or (v34 < 2097152 and 14 or 21);
                                            v37 = u20(v34, v33);
                                            local v752 = u21(v34, u22(1, v33) - 1);
                                            UNNAMED_2819735072264[u5] = u18(v32, 120, (u21(u20(v35, 14), 127)));
                                            UNNAMED_2819735075720[u5] = u18(v752, 92, (u21(v35, 127)));
                                            UNNAMED_2819735063384[u5] = u18(v37, 2, (u21(u20(v35, 21), 127)));
                                            UNNAMED_2819735035304[u5] = u18(v36, 109, (u21(u20(v35, 7), 127)));
                                            u5 = u5 - 1;
                                        else
                                            u4[UNNAMED_2819735075720[u5]] = u24[UNNAMED_2819735050136[u5]][UNNAMED_2819735066504[u5]];
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u19(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735077064[u5]);
                                    end;
                                elseif v583 >= 174 then
                                    if v583 == 175 then
                                        v36 = UNNAMED_2819735035304[u5];
                                        v34 = UNNAMED_2819735072264[u5];
                                        v32 = UNNAMED_2819735075720[u5];
                                        v35 = v36 + v34;
                                        u4[v36] = u17(u4[v36](u14(u4, v36 + 1, v35)));
                                    else
                                        u4[UNNAMED_2819735075720[u5]] = u4[UNNAMED_2819735035304[u5]] < UNNAMED_2819735072264[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735077064[u5];
                                end;
                            elseif v583 < 170 then
                                if v583 < 168 then
                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735075720[u5]] > u4[UNNAMED_2819735035304[u5]];
                                else
                                    if v583 == 169 then
                                        local v753 = u12;
                                        local v754 = u13;

                                        if v753 then
                                            for i in u15, v753 do
                                                local v755 = v753[i];

                                                if v755 then
                                                    v755[5] = v755;
                                                    v755[6] = u4[i];
                                                    v755[4] = 6;
                                                    v753[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v754 then
                                            for i, v in u15, v754 do
                                                local v756 = v[6];

                                                if v754 then
                                                    local v757 = v754[i];

                                                    if v757 then
                                                        local v758 = u3(v756);
                                                        u16(u4, i, i + v756 - 1, 1, v758);
                                                        v757[5] = v758;
                                                        v757[4] = 1;
                                                        v754[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819735075720[u5], u17();
                                    end;

                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] == u4[UNNAMED_2819735072264[u5]];
                                end;
                            elseif v583 >= 171 then
                                if v583 == 172 then
                                    if u12 then
                                        local v759 = u12;
                                        local v760 = UNNAMED_2819735072264[u5];
                                        local v761 = v759[v760];

                                        if v761 then
                                            v761[5] = v761;
                                            v761[6] = u4[v760];
                                            v761[4] = 6;
                                            v759[v760] = nil;
                                        end;
                                    end;
                                else
                                    v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                    v36[5][v36[4]][UNNAMED_2819735077064[u5]] = u4[UNNAMED_2819735072264[u5]];
                                end;
                            else
                                local v762 = u4[UNNAMED_2819735035304[u5]] % 4294967296;
                                u4[UNNAMED_2819735075720[u5]] = v762 ~= v762 and 0 or v762 - v762 % 1;
                            end;
                        else
                            if v583 < 155 then
                                if v583 >= 149 then
                                    if v583 < 152 then
                                        if v583 < 150 then
                                            v36 = UNNAMED_2819735072264[u5];
                                            local v763 = u4[UNNAMED_2819735035304[u5]];
                                            u4[v36] = UNNAMED_2819735077064[u5];
                                            u4[v36 + 1] = v763;
                                        elseif v583 == 151 then
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] .. UNNAMED_2819735077064[u5];
                                        else
                                            u7 = {
                                                [6] = u11,
                                                [5] = u9,
                                                [9] = u7,
                                                [8] = u8,
                                                [7] = u10
                                            };
                                            v36 = UNNAMED_2819735075720[u5];
                                            u10 = u4[v36 + 2] + 0;
                                            u9 = u4[v36 + 1] + 0;
                                            u8 = u4[v36] - u10;
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    elseif v583 >= 153 then
                                        if v583 == 154 then
                                            local v764 = UNNAMED_2819735075720[u5];
                                            local v765 = UNNAMED_2819735035304[u5];
                                            local v766 = UNNAMED_2819735058152[5];
                                            local v767 = u18(v766[v764], 109162203);
                                            v766[v764] = v767;
                                            local v768 = UNNAMED_2819735058152[4];
                                            local v769 = v767 + 1;
                                            local v770 = u28(v768, v769);
                                            local v771;

                                            if v770 < 128 then
                                                v771 = v769 + 1;
                                            else
                                                local v772 = u28(v768, v769 + 1);

                                                if v772 < 128 then
                                                    v770 = v770 - 128 + v772 * 128;
                                                    v771 = v769 + 2;
                                                else
                                                    local v773 = u28(v768, v769 + 2);

                                                    if v773 < 128 then
                                                        v770 = v770 - 128 + (v772 - 128) * 16384 + v773 * 128;
                                                        v771 = v769 + 3;
                                                    else
                                                        local v774 = u28(v768, v769 + 3);
                                                        v770 = (v770 - 128) * 16384 + (v772 - 128) * 128 + (v773 - 128) + v774 % 128 * 2097152 + (v774 - v774 % 128) * 2097152;
                                                        v771 = v769 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v775 = v765 * 16843009;
                                            local v776 = v771 + v770;
                                            local v777 = v776 - v770 % 4;

                                            for i = v771, v777 - 1, 4 do
                                                u29(v768, i, (u18(u30(v768, i), v775)));
                                                local _ = i;
                                            end;

                                            for i = v777, v776 - 1 do
                                                u31(v768, i, (u18(u28(v768, i), v765)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735075720[u5] = 212;
                                            UNNAMED_2819735035304[u5] = 21;
                                            UNNAMED_2819735072264[u5] = 154;
                                            UNNAMED_2819735063384[u5] = 190;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] * UNNAMED_2819735072264[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735075720[u5]](UNNAMED_2819735066504[u5]));
                                    end;
                                elseif v583 >= 146 then
                                    if v583 < 147 then
                                        v36 = UNNAMED_2819735035304[u5];
                                        local v778 = u4[UNNAMED_2819735075720[u5]];
                                        u4[v36] = UNNAMED_2819735072264[u5];
                                        u4[v36 + 1] = v778;
                                    elseif v583 == 148 then
                                        u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735072264[u5];
                                    else
                                        u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735066504[u5] * u4[UNNAMED_2819735035304[u5]];
                                    end;
                                elseif v583 < 144 then
                                    if u4[UNNAMED_2819735075720[u5]] >= u4[UNNAMED_2819735072264[u5]] then
                                        u5 = UNNAMED_2819735035304[u5];
                                    end;
                                elseif v583 == 145 then
                                    v36 = UNNAMED_2819735035304[u5];
                                    local v779 = UNNAMED_2819735075720[u5];
                                    u4[v36] = UNNAMED_2819735066504[u5];
                                    u4[v36 + 1] = v779;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u17(u4[UNNAMED_2819735075720[u5]](u4[UNNAMED_2819735035304[u5]]));
                                end;

                                v582 = 1;
                                continue;
                            end;

                            if v583 < 161 then
                                if v583 < 158 then
                                    if v583 >= 156 then
                                        if v583 == 157 then
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735075720[u5]] + u4[UNNAMED_2819735072264[u5]];
                                        else
                                            u5 = UNNAMED_2819735072264[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735075720[u5]] = UNNAMED_2819735072264[u5] + u4[UNNAMED_2819735035304[u5]];
                                    end;

                                    v582 = 1;
                                    continue;
                                end;

                                if v583 >= 159 then
                                    if v583 == 160 then
                                        u4[UNNAMED_2819735072264[u5]] = u21(u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735075720[u5]]);
                                    else
                                        local v780 = UNNAMED_2819735035304[u5];
                                        local v781 = UNNAMED_2819735072264[u5];
                                        local v782 = u21(u4[UNNAMED_2819735075720[u5]], 4294967295);
                                        local v783 = u21(v781, 4294967295);
                                        local v784 = u21(v782, 65535);
                                        local v785 = u20(v782, 16);
                                        local v786 = u21(v783, 65535);
                                        local v787 = u20(v783, 16);
                                        local v788 = u21(v784 * v786 + u22(u21(v784 * v787 + v785 * v786, 65535), 16), 4294967295) % 4294967296;
                                        u4[v780] = v788 ~= v788 and 0 or v788 - v788 % 1;
                                    end;

                                    v582 = 1;
                                    continue;
                                end;

                                u6 = UNNAMED_2819735035304[u5];
                                u5 = UNNAMED_2819735072264[u5] + 1;
                                v38 = 2;
                                break;
                            end;

                            if v583 >= 164 then
                                if v583 < 165 then
                                    local v789 = UNNAMED_2819735035304[u5];
                                    local v790 = v789 + UNNAMED_2819735075720[u5];
                                    local v791 = u12;
                                    local v792 = u13;

                                    if v791 then
                                        for i in u15, v791 do
                                            local v793 = v791[i];

                                            if v793 then
                                                v793[5] = v793;
                                                v793[6] = u4[i];
                                                v793[4] = 6;
                                                v791[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v792 then
                                        for i, v in u15, v792 do
                                            local v794 = v[6];

                                            if v792 then
                                                local v795 = v792[i];

                                                if v795 then
                                                    local v796 = u3(v794);
                                                    u16(u4, i, i + v794 - 1, 1, v796);
                                                    v795[5] = v796;
                                                    v795[4] = 1;
                                                    v792[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, false, v789, v790;
                                end;

                                if v583 == 166 then
                                    u4[UNNAMED_2819735072264[u5]](u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735077064[u5]);
                                else
                                    u8 = u7[8];
                                    u9 = u7[5];
                                    u10 = u7[7];
                                    u11 = u7[6];
                                    u7 = u7[9];
                                end;
                            elseif v583 >= 162 then
                                if v583 == 163 then
                                    v36 = UNNAMED_2819735072264[u5];
                                    v34 = UNNAMED_2819735035304[u5];
                                    v32 = UNNAMED_2819735075720[u5];
                                    v35 = u4[v36];
                                    v33 = v36 + v34;
                                    v37 = u4[v33];
                                    u16(u4, v36 + 1, v33 - 1, v32 + 1, v35);
                                    u16(v37, 1, v37.n, v32 + v34, v35);
                                elseif u4[UNNAMED_2819735072264[u5]] >= UNNAMED_2819735077064[u5] then
                                    u5 = UNNAMED_2819735035304[u5];
                                end;
                            else
                                u4[UNNAMED_2819735075720[u5]] = u4;
                            end;
                        end;

                        v582 = 1;
                        continue;
                    elseif v582 == 1 then
                        v582 = -1;
                        u5 = u5 + 1;
                        break;
                    else
                        break;
                    end;
                end;

                if v38 ~= -1 then
                    break;
                end;
            end;

            if v38 ~= -1 then
                continue;
            end;

            v38 = 6;
            continue;
        elseif v38 == 6 then
            v38 = -1;

            while true do
                local u5;
                local v797 = 0;

                while true do
                    if v797 == 0 then
                        v797 = -1;
                        local v798 = UNNAMED_2819735075720[u5];

                        if v798 >= 96 then
                            if v798 >= 144 then
                                if v798 >= 168 then
                                    if v798 >= 180 then
                                        if v798 < 186 then
                                            if v798 < 183 then
                                                if v798 >= 181 then
                                                    if v798 == 182 then
                                                        v36 = u4[UNNAMED_2819735063384[u5]];
                                                        u4[UNNAMED_2819735072264[u5]] = u17(u14(v36, UNNAMED_2819735035304[u5], v36.n));
                                                    else
                                                        local v799 = UNNAMED_2819735072264[u5];
                                                        local v800 = UNNAMED_2819735063384[u5];
                                                        local v801, v802 = u4[UNNAMED_2819735035304[u5]]();
                                                        u4[v799] = v801;
                                                        u4[v800] = v802;
                                                    end;
                                                else
                                                    v36 = UNNAMED_2819735063384[u5];
                                                    v34, v32 = u8();

                                                    if v34 then
                                                        u4[v36] = v32;
                                                        u5 = UNNAMED_2819735035304[u5];
                                                    else
                                                        u5 = UNNAMED_2819735072264[u5];
                                                    end;
                                                end;
                                            elseif v798 < 184 then
                                                u4[UNNAMED_2819735063384[u5]] = u25(u4[UNNAMED_2819735035304[u5]]);
                                            elseif v798 == 185 then
                                                u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735088680[u5]];
                                            elseif u4[UNNAMED_2819735035304[u5]] ~= UNNAMED_2819735066504[u5] then
                                                u5 = UNNAMED_2819735063384[u5];
                                            end;
                                        elseif v798 >= 189 then
                                            if v798 >= 190 then
                                                if v798 == 191 then
                                                    u1 = u4[UNNAMED_2819735063384[u5]];
                                                else
                                                    local v803;

                                                    if u4[UNNAMED_2819735072264[u5]] then
                                                        v803 = UNNAMED_2819735063384[u5];
                                                    else
                                                        v803 = UNNAMED_2819735035304[u5];
                                                    end;

                                                    u5 = v803;
                                                end;
                                            else
                                                u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735050136[u5];
                                            end;
                                        elseif v798 >= 187 then
                                            if v798 == 188 then
                                                u24[UNNAMED_2819735088680[u5]] = UNNAMED_2819735066504[u5];
                                            else
                                                UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][UNNAMED_2819735088680[u5]] = UNNAMED_2819735066504[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]](u4[UNNAMED_2819735035304[u5]]);
                                        end;
                                    elseif v798 < 174 then
                                        if v798 >= 171 then
                                            if v798 >= 172 then
                                                if v798 == 173 then
                                                    u4[UNNAMED_2819735072264[u5]] = u24[UNNAMED_2819735050136[u5]][UNNAMED_2819735088680[u5]];
                                                else
                                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] - u4[UNNAMED_2819735072264[u5]];
                                                end;
                                            else
                                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] % UNNAMED_2819735035304[u5];
                                            end;
                                        elseif v798 >= 169 then
                                            if v798 == 170 then
                                                u4[UNNAMED_2819735072264[u5]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735063384[u5]];
                                            else
                                                u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735072264[u5]] // UNNAMED_2819735035304[u5];
                                            end;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735066504[u5] * u4[UNNAMED_2819735063384[u5]];
                                        end;
                                    elseif v798 >= 177 then
                                        if v798 < 178 then
                                            UNNAMED_2819735029544[UNNAMED_2819735035304[u5]][u4[UNNAMED_2819735072264[u5]]] = UNNAMED_2819735088680[u5];
                                        else
                                            if v798 == 179 then
                                                local v804 = u12;
                                                local v805 = u13;

                                                if v804 then
                                                    for i in u15, v804 do
                                                        local v806 = v804[i];

                                                        if v806 then
                                                            v806[5] = v806;
                                                            v806[6] = u4[i];
                                                            v806[4] = 6;
                                                            v804[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v805 then
                                                    for i, v in u15, v805 do
                                                        local v807 = v[6];

                                                        if v805 then
                                                            local v808 = v805[i];

                                                            if v808 then
                                                                local v809 = u3(v807);
                                                                u16(u4, i, i + v807 - 1, 1, v809);
                                                                v808[5] = v809;
                                                                v808[4] = 1;
                                                                v805[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(UNNAMED_2819735088680[u5], u4[UNNAMED_2819735072264[u5]]);
                                            end;

                                            u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735035304;
                                        end;
                                    elseif v798 < 175 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] * UNNAMED_2819735072264[u5];
                                    elseif v798 == 176 then
                                        u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735072264[u5]]());
                                    elseif u4[UNNAMED_2819735072264[u5]] ~= u4[UNNAMED_2819735035304[u5]] then
                                        u5 = UNNAMED_2819735063384[u5];
                                    end;
                                elseif v798 >= 156 then
                                    if v798 < 162 then
                                        if v798 < 159 then
                                            if v798 >= 157 then
                                                if v798 == 158 then
                                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735088680[u5] + u4[UNNAMED_2819735072264[u5]];
                                                else
                                                    u24[UNNAMED_2819735088680[u5]][UNNAMED_2819735066504[u5]] = u4[UNNAMED_2819735035304[u5]];
                                                end;
                                            else
                                                u4[UNNAMED_2819735063384[u5]] = u20(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735072264[u5]);
                                            end;
                                        elseif v798 >= 160 then
                                            if v798 == 161 then
                                                if u4[UNNAMED_2819735035304[u5]] > UNNAMED_2819735066504[u5] then
                                                    u5 = UNNAMED_2819735063384[u5];
                                                end;
                                            else
                                                v36 = { ... };
                                                v34 = UNNAMED_2819735072264[u5];
                                                u16(v36, 1, UNNAMED_2819735063384[u5], v34, u4);
                                            end;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] > UNNAMED_2819735088680[u5];
                                        end;
                                    elseif v798 < 165 then
                                        if v798 >= 163 then
                                            if v798 == 164 then
                                                u7 = {
                                                    [6] = u11,
                                                    [5] = u9,
                                                    [9] = u7,
                                                    [8] = u8,
                                                    [7] = u10
                                                };
                                                v36 = UNNAMED_2819735072264[u5];
                                                v34 = u26(u27);
                                                v34(UNNAMED_2819735088728, u4[v36], u4[v36 + 1], u4[v36 + 2]);
                                                u8 = v34;
                                                u11 = UNNAMED_2819735063384[u5];
                                                u5 = UNNAMED_2819735035304[u5];
                                            else
                                                u4[UNNAMED_2819735063384[u5]][u4[UNNAMED_2819735072264[u5]]] = UNNAMED_2819735050136[u5];
                                            end;
                                        else
                                            local v810 = UNNAMED_2819735072264[u5];
                                            local v811 = UNNAMED_2819735063384[u5];
                                            local v812 = UNNAMED_2819735058152[5];
                                            local v813 = u18(v812[v810], 109162203);
                                            v812[v810] = v813;
                                            local v814 = UNNAMED_2819735058152[4];
                                            local v815 = v813 + 1;
                                            local v816 = u28(v814, v815);
                                            local v817;

                                            if v816 < 128 then
                                                v817 = v815 + 1;
                                            else
                                                local v818 = u28(v814, v815 + 1);

                                                if v818 < 128 then
                                                    v816 = v816 - 128 + v818 * 128;
                                                    v817 = v815 + 2;
                                                else
                                                    local v819 = u28(v814, v815 + 2);

                                                    if v819 < 128 then
                                                        v816 = v816 - 128 + (v818 - 128) * 16384 + v819 * 128;
                                                        v817 = v815 + 3;
                                                    else
                                                        local v820 = u28(v814, v815 + 3);
                                                        v816 = (v816 - 128) * 16384 + (v818 - 128) * 128 + (v819 - 128) + v820 % 128 * 2097152 + (v820 - v820 % 128) * 2097152;
                                                        v817 = v815 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v821 = v811 * 16843009;
                                            local v822 = v817 + v816;
                                            local v823 = v822 - v816 % 4;

                                            for i = v817, v823 - 1, 4 do
                                                u29(v814, i, (u18(u30(v814, i), v821)));
                                                local _ = i;
                                            end;

                                            for i = v823, v822 - 1 do
                                                u31(v814, i, (u18(u28(v814, i), v811)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735072264[u5] = 164;
                                            UNNAMED_2819735063384[u5] = 52;
                                            UNNAMED_2819735035304[u5] = 243;
                                            UNNAMED_2819735075720[u5] = 86;
                                        end;
                                    else
                                        if v798 < 166 then
                                            local v824 = u12;
                                            local v825 = u13;

                                            if v824 then
                                                for i in u15, v824 do
                                                    local v826 = v824[i];

                                                    if v826 then
                                                        v826[5] = v826;
                                                        v826[6] = u4[i];
                                                        v826[4] = 6;
                                                        v824[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v825 then
                                                for i, v in u15, v825 do
                                                    local v827 = v[6];

                                                    if v825 then
                                                        local v828 = v825[i];

                                                        if v828 then
                                                            local v829 = u3(v827);
                                                            u16(u4, i, i + v827 - 1, 1, v829);
                                                            v828[5] = v829;
                                                            v828[4] = 1;
                                                            v825[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735072264[u5], u17(u4[UNNAMED_2819735063384[u5]], u4[UNNAMED_2819735035304[u5]]);
                                        end;

                                        if v798 == 167 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = UNNAMED_2819735063384[u5];
                                            v32 = UNNAMED_2819735072264[u5];
                                            v35 = v36 + v34;
                                            u4[v36] = u17(u4[v36](u14(u4, v36 + 1, v35)));
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] % UNNAMED_2819735066504[u5];
                                        end;
                                    end;
                                elseif v798 < 150 then
                                    if v798 >= 147 then
                                        if v798 < 148 then
                                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]][UNNAMED_2819735066504[u5]];
                                        elseif v798 == 149 then
                                            u4[UNNAMED_2819735035304[u5]] = u2;
                                        else
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]](u14(u4[UNNAMED_2819735035304[u5]], 1, u4[UNNAMED_2819735035304[u5]].n));
                                        end;
                                    elseif v798 < 145 then
                                        u7 = {
                                            [6] = u11,
                                            [5] = u9,
                                            [9] = u7,
                                            [8] = u8,
                                            [7] = u10
                                        };
                                        v36 = UNNAMED_2819735072264[u5];
                                        u10 = u4[v36 + 2] + 0;
                                        u9 = u4[v36 + 1] + 0;
                                        u8 = u4[v36] - u10;
                                        u5 = UNNAMED_2819735063384[u5];
                                    elseif v798 == 146 then
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] < UNNAMED_2819735035304[u5];
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735072264[u5]] + UNNAMED_2819735050136[u5];
                                    end;
                                elseif v798 >= 153 then
                                    if v798 < 154 then
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] == UNNAMED_2819735050136[u5];
                                    elseif v798 == 155 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735063384[u5]]];
                                    else
                                        UNNAMED_2819735029544[UNNAMED_2819735063384[u5]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735035304[u5];
                                    end;
                                elseif v798 < 151 then
                                    UNNAMED_2819735029544[UNNAMED_2819735063384[u5]][UNNAMED_2819735050136[u5]] = u4[UNNAMED_2819735072264[u5]];
                                elseif v798 == 152 then
                                    v36 = UNNAMED_2819735072264[u5];
                                    local v830 = u4[UNNAMED_2819735035304[u5]];
                                    u4[v36] = UNNAMED_2819735088680[u5];
                                    u4[v36 + 1] = v830;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = u17(u4[UNNAMED_2819735072264[u5]](u4[UNNAMED_2819735063384[u5]]));
                                end;
                            elseif v798 >= 120 then
                                if v798 >= 132 then
                                    if v798 >= 138 then
                                        if v798 >= 141 then
                                            if v798 < 142 then
                                                local v831 = u12;
                                                local v832 = u13;

                                                if v831 then
                                                    for i in u15, v831 do
                                                        local v833 = v831[i];

                                                        if v833 then
                                                            v833[5] = v833;
                                                            v833[6] = u4[i];
                                                            v833[4] = 6;
                                                            v831[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v832 then
                                                    for i, v in u15, v832 do
                                                        local v834 = v[6];

                                                        if v832 then
                                                            local v835 = v832[i];

                                                            if v835 then
                                                                local v836 = u3(v834);
                                                                u16(u4, i, i + v834 - 1, 1, v836);
                                                                v835[5] = v836;
                                                                v835[4] = 1;
                                                                v832[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u17(u4[UNNAMED_2819735063384[u5]], u4[UNNAMED_2819735035304[u5]]);
                                            end;

                                            if v798 == 143 then
                                                u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735063384[u5]], u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                                            else
                                                u4[UNNAMED_2819735072264[u5]] = u21(u4[UNNAMED_2819735063384[u5]], u4[UNNAMED_2819735035304[u5]]);
                                            end;
                                        elseif v798 < 139 then
                                            u4[UNNAMED_2819735035304[u5]] = u1;
                                        elseif v798 == 140 then
                                            u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] - UNNAMED_2819735035304[u5];
                                        else
                                            v36 = UNNAMED_2819735029544[UNNAMED_2819735063384[u5]];
                                            u4[UNNAMED_2819735035304[u5]] = v36[5][v36[4]];
                                        end;
                                    elseif v798 < 135 then
                                        if v798 >= 133 then
                                            if v798 == 134 then
                                                v36 = UNNAMED_2819735063384[u5];
                                                v34 = UNNAMED_2819735035304[u5];
                                                v32 = UNNAMED_2819735072264[u5];
                                                v35 = v36 + v34;
                                                v33 = u4[v35];
                                                v37 = v33.n;
                                                v33.n = v34 + v37 - 1;
                                                u16(v33, 1, v37, v34, v33);
                                                u16(u4, v36 + 1, v35 - 1, 1, v33);
                                                u4[v36] = u17(u4[v36](u14(v33, 1, v33.n)));
                                            else
                                                local v837;

                                                if u4[UNNAMED_2819735072264[u5]] then
                                                    v837 = UNNAMED_2819735035304[u5];
                                                else
                                                    v837 = UNNAMED_2819735063384[u5];
                                                end;

                                                u5 = v837;
                                            end;
                                        else
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735072264[u5];
                                        end;
                                    elseif v798 >= 136 then
                                        if v798 == 137 then
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735063384;
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]]();
                                        end;
                                    else
                                        v36 = UNNAMED_2819735072264[u5];
                                        local v838 = UNNAMED_2819735063384[u5];
                                        u4[v36] = u4[UNNAMED_2819735035304[u5]];
                                        u4[v36 + 1] = v838;
                                    end;
                                elseif v798 >= 126 then
                                    if v798 < 129 then
                                        if v798 >= 127 then
                                            if v798 == 128 then
                                                u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]][UNNAMED_2819735035304[u5]];
                                            else
                                                local v839 = UNNAMED_2819735035304[u5];
                                                local v840 = UNNAMED_2819735063384[u5];
                                                local v841 = u21(u4[UNNAMED_2819735072264[u5]], 4294967295);
                                                local v842 = u21(v840, 4294967295);
                                                local v843 = u21(v841, 65535);
                                                local v844 = u20(v841, 16);
                                                local v845 = u21(v842, 65535);
                                                local v846 = u20(v842, 16);
                                                local v847 = u21(v843 * v845 + u22(u21(v843 * v846 + v844 * v845, 65535), 16), 4294967295) % 4294967296;
                                                u4[v839] = v847 ~= v847 and 0 or v847 - v847 % 1;
                                            end;
                                        else
                                            v36 = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]];
                                            u4[UNNAMED_2819735035304[u5]] = v36[5][v36[4]][UNNAMED_2819735088680[u5]];
                                        end;
                                    elseif v798 < 130 then
                                        u4[UNNAMED_2819735063384[u5]] = u18(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735050136[u5]);
                                    elseif v798 == 131 then
                                        local v848 = nil;
                                        local v849 = UNNAMED_2819735063384[u5];
                                        local v850 = UNNAMED_2819735050136[u5];
                                        local v851 = UNNAMED_2819735066504[u5];
                                        local v852 = u12;
                                        local v853 = u13;
                                        local v854 = v851[0];

                                        if v854 then
                                            local v855 = #v854 / 3;

                                            if v855 > 0 then
                                                v848 = {};

                                                for i = 1, v855 do
                                                    local v856 = (i - 1) * 3;
                                                    local v857 = v854[v856 + 2];
                                                    local v858 = v854[v856 + 1];
                                                    local v859;

                                                    if v857 == 2 then
                                                        v852 = v852 or {};
                                                        local v860 = v852[v858];

                                                        if not v860 then
                                                            v860 = {
                                                                [5] = u4,
                                                                [4] = v858
                                                            };
                                                            v852[v858] = v860;
                                                        end;

                                                        v848[i] = v860;
                                                        v859 = i;
                                                    elseif v857 == 0 then
                                                        v848[i] = u4[v858];
                                                        v859 = i;
                                                    elseif v857 == 3 then
                                                        v848[i] = UNNAMED_2819735029544[v858];
                                                        v859 = i;
                                                    elseif v857 == 1 then
                                                        v853 = v853 or {};
                                                        local v861 = v853[v858];

                                                        if not v861 then
                                                            v861 = {
                                                                [5] = u4,
                                                                [4] = v858,
                                                                [6] = v854[v856 + 3]
                                                            };
                                                            v853[v858] = v861;
                                                        end;

                                                        v848[i] = v861;
                                                        v859 = i;
                                                    else
                                                        v859 = i;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v862 = v851[-2];
                                        v851[v862] = v848;
                                        local v863 = v850(u14(v851, 1, v851[-1]));
                                        v851[v862] = nil;
                                        u4[v849] = v863;
                                        u12 = v852;
                                        u13 = v853;
                                    else
                                        v36 = UNNAMED_2819735035304[u5];
                                        local v864 = UNNAMED_2819735072264[u5];
                                        u4[v36] = UNNAMED_2819735088680[u5];
                                        u4[v36 + 1] = v864;
                                    end;
                                elseif v798 < 123 then
                                    if v798 < 121 then
                                        u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735063384[u5] * u4[UNNAMED_2819735072264[u5]];
                                    elseif v798 == 122 then
                                        local v865 = u4[UNNAMED_2819735072264[u5]] % 4294967296;
                                        u4[UNNAMED_2819735035304[u5]] = v865 ~= v865 and 0 or v865 - v865 % 1;
                                    else
                                        v36 = UNNAMED_2819735063384[u5];
                                        v34, v32, v35 = u8();

                                        if v34 then
                                            u4[v36] = v32;
                                            u4[v36 + 1] = v35;
                                            u5 = UNNAMED_2819735035304[u5];
                                        else
                                            u5 = UNNAMED_2819735072264[u5];
                                        end;
                                    end;
                                elseif v798 < 124 then
                                    u4[UNNAMED_2819735063384[u5]](u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735066504[u5]);
                                elseif v798 == 125 then
                                    local v866 = UNNAMED_2819735035304[u5];
                                    local v867 = UNNAMED_2819735088680[u5];
                                    local v868 = u21(UNNAMED_2819735066504[u5], 4294967295);
                                    local v869 = u21(v867, 4294967295);
                                    local v870 = u21(v868, 65535);
                                    local v871 = u20(v868, 16);
                                    local v872 = u21(v869, 65535);
                                    local v873 = u20(v869, 16);
                                    local v874 = u21(v870 * v872 + u22(u21(v870 * v873 + v871 * v872, 65535), 16), 4294967295) % 4294967296;
                                    u4[v866] = v874 ~= v874 and 0 or v874 - v874 % 1;
                                else
                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735072264[u5]] * UNNAMED_2819735050136[u5];
                                end;
                            elseif v798 >= 108 then
                                if v798 >= 114 then
                                    if v798 < 117 then
                                        if v798 >= 115 then
                                            if v798 == 116 then
                                                v36 = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]];
                                                v36[5][v36[4]] = UNNAMED_2819735088680[u5];
                                            else
                                                u4[UNNAMED_2819735072264[u5]] = u17(u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735050136[u5]));
                                            end;
                                        else
                                            u8 = u8 + u10;

                                            if u10 <= 0 then
                                                v36 = u9 <= u8;
                                            else
                                                v36 = u8 <= u9;
                                            end;

                                            if v36 then
                                                u4[UNNAMED_2819735063384[u5]] = u8;
                                                u5 = UNNAMED_2819735035304[u5];
                                            else
                                                u5 = UNNAMED_2819735072264[u5];
                                            end;
                                        end;
                                    elseif v798 >= 118 then
                                        if v798 == 119 then
                                            if u12 then
                                                local v875 = u12;
                                                local v876 = UNNAMED_2819735072264[u5];
                                                local v877 = v875[v876];

                                                if v877 then
                                                    v877[5] = v877;
                                                    v877[6] = u4[v876];
                                                    v877[4] = 6;
                                                    v875[v876] = nil;
                                                end;
                                            end;
                                        else
                                            v36 = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]];
                                            v36[5][v36[4]][UNNAMED_2819735050136[u5]] = UNNAMED_2819735088680[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = u21(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735035304[u5]);
                                    end;
                                elseif v798 >= 111 then
                                    if v798 >= 112 then
                                        if v798 ~= 113 then
                                            local v878 = u12;
                                            local v879 = u13;

                                            if v878 then
                                                for i in u15, v878 do
                                                    local v880 = v878[i];

                                                    if v880 then
                                                        v880[5] = v880;
                                                        v880[6] = u4[i];
                                                        v880[4] = 6;
                                                        v878[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v879 then
                                                for i, v in u15, v879 do
                                                    local v881 = v[6];

                                                    if v879 then
                                                        local v882 = v879[i];

                                                        if v882 then
                                                            local v883 = u3(v881);
                                                            u16(u4, i, i + v881 - 1, 1, v883);
                                                            v882[5] = v883;
                                                            v882[4] = 1;
                                                            v879[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735072264[u5], u17(u4[UNNAMED_2819735063384[u5]], u14(u4[UNNAMED_2819735035304[u5]], 1, u4[UNNAMED_2819735035304[u5]].n));
                                        end;

                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] - UNNAMED_2819735066504[u5];
                                    else
                                        v36 = UNNAMED_2819735035304[u5];
                                        local v884 = UNNAMED_2819735063384[u5];
                                        u4[v36] = UNNAMED_2819735072264[u5];
                                        u4[v36 + 1] = v884;
                                    end;
                                elseif v798 < 109 then
                                    if u12 then
                                        local v885 = u12;
                                        local v886 = UNNAMED_2819735072264[u5];
                                        local v887 = v885[v886];

                                        if v887 then
                                            v887[5] = v887;
                                            v887[6] = u4[v886];
                                            v887[4] = 6;
                                            v885[v886] = nil;
                                        end;

                                        local v888 = u12;
                                        local v889 = UNNAMED_2819735063384[u5];
                                        local v890 = v888[v889];

                                        if v890 then
                                            v890[5] = v890;
                                            v890[6] = u4[v889];
                                            v890[4] = 6;
                                            v888[v889] = nil;
                                        end;
                                    end;
                                elseif v798 == 110 then
                                    local v891 = UNNAMED_2819735063384[u5];
                                    local v892 = u18(UNNAMED_2819735072264[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));
                                    local v893 = UNNAMED_2819735058152[5];
                                    local v894 = u18(v893[v891], 109162203);
                                    v893[v891] = v894;
                                    local v895 = UNNAMED_2819735058152[4];
                                    local v896 = v894 + 1;
                                    local v897 = u28(v895, v896);
                                    local v898;

                                    if v897 < 128 then
                                        v898 = v896 + 1;
                                    else
                                        local v899 = u28(v895, v896 + 1);

                                        if v899 < 128 then
                                            v897 = v897 - 128 + v899 * 128;
                                            v898 = v896 + 2;
                                        else
                                            local v900 = u28(v895, v896 + 2);

                                            if v900 < 128 then
                                                v897 = v897 - 128 + (v899 - 128) * 16384 + v900 * 128;
                                                v898 = v896 + 3;
                                            else
                                                local v901 = u28(v895, v896 + 3);
                                                v897 = (v897 - 128) * 16384 + (v899 - 128) * 128 + (v900 - 128) + v901 % 128 * 2097152 + (v901 - v901 % 128) * 2097152;
                                                v898 = v896 + 4;
                                            end;
                                        end;
                                    end;

                                    local v902 = v892 * 16843009;
                                    local v903 = v898 + v897;
                                    local v904 = v903 - v897 % 4;

                                    for i = v898, v904 - 1, 4 do
                                        u29(v895, i, (u18(u30(v895, i), v902)));
                                        local _ = i;
                                    end;

                                    for i = v904, v903 - 1 do
                                        u31(v895, i, (u18(u28(v895, i), v892)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735063384[u5] = 239;
                                    UNNAMED_2819735072264[u5] = 197;
                                    UNNAMED_2819735035304[u5] = 41;
                                    UNNAMED_2819735075720[u5] = 86;
                                else
                                    v36 = UNNAMED_2819735035304[u5];
                                    v34 = UNNAMED_2819735063384[u5];
                                    v32 = UNNAMED_2819735072264[u5];
                                    v35 = v36 + v32 - 1;
                                    v33 = v36 + v34;
                                    v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                    u16(v37, 1, v32, v36, u4);
                                end;
                            elseif v798 < 102 then
                                if v798 < 99 then
                                    if v798 >= 97 then
                                        if v798 == 98 then
                                            local v905 = u12;
                                            local v906 = u13;

                                            if v905 then
                                                for i in u15, v905 do
                                                    local v907 = v905[i];

                                                    if v907 then
                                                        v907[5] = v907;
                                                        v907[6] = u4[i];
                                                        v907[4] = 6;
                                                        v905[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v906 then
                                                for i, v in u15, v906 do
                                                    local v908 = v[6];

                                                    if v906 then
                                                        local v909 = v906[i];

                                                        if v909 then
                                                            local v910 = u3(v908);
                                                            u16(u4, i, i + v908 - 1, 1, v910);
                                                            v909[5] = v910;
                                                            v909[4] = 1;
                                                            v906[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735063384[u5], u17(u4[UNNAMED_2819735035304[u5]]);
                                        end;

                                        u4[UNNAMED_2819735063384[u5]] = u24[UNNAMED_2819735050136[u5]];
                                    else
                                        v36 = UNNAMED_2819735072264[u5];
                                        local v911 = u4[UNNAMED_2819735063384[u5]];
                                        u4[v36] = u4[UNNAMED_2819735035304[u5]];
                                        u4[v36 + 1] = v911;
                                    end;
                                elseif v798 >= 100 then
                                    if v798 == 101 then
                                        local v912 = UNNAMED_2819735063384[u5];
                                        local v913 = u18(UNNAMED_2819735072264[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));
                                        local v914 = UNNAMED_2819735058152[5];
                                        local v915 = u18(v914[v912], 109162203);
                                        v914[v912] = v915;
                                        local v916 = UNNAMED_2819735058152[4];
                                        local v917 = v915 + 1;
                                        local v918 = u28(v916, v917);
                                        local v919;

                                        if v918 < 128 then
                                            v919 = v917 + 1;
                                        else
                                            local v920 = u28(v916, v917 + 1);

                                            if v920 < 128 then
                                                v918 = v918 - 128 + v920 * 128;
                                                v919 = v917 + 2;
                                            else
                                                local v921 = u28(v916, v917 + 2);

                                                if v921 < 128 then
                                                    v918 = v918 - 128 + (v920 - 128) * 16384 + v921 * 128;
                                                    v919 = v917 + 3;
                                                else
                                                    local v922 = u28(v916, v917 + 3);
                                                    v918 = (v918 - 128) * 16384 + (v920 - 128) * 128 + (v921 - 128) + v922 % 128 * 2097152 + (v922 - v922 % 128) * 2097152;
                                                    v919 = v917 + 4;
                                                end;
                                            end;
                                        end;

                                        local v923 = v913 * 16843009;
                                        local v924 = v919 + v918;
                                        local v925 = v924 - v918 % 4;

                                        for i = v919, v925 - 1, 4 do
                                            u29(v916, i, (u18(u30(v916, i), v923)));
                                            local _ = i;
                                        end;

                                        for i = v925, v924 - 1 do
                                            u31(v916, i, (u18(u28(v916, i), v913)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735063384[u5] = 187;
                                        UNNAMED_2819735072264[u5] = 245;
                                        UNNAMED_2819735035304[u5] = 185;
                                        UNNAMED_2819735075720[u5] = 86;
                                    else
                                        u5 = u4[UNNAMED_2819735072264[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735066504[u5], u14(u4[UNNAMED_2819735063384[u5]], 1, u4[UNNAMED_2819735063384[u5]].n));
                                end;
                            elseif v798 >= 105 then
                                if v798 < 106 then
                                    local v926 = UNNAMED_2819735035304[u5];
                                    local v927 = v926 + UNNAMED_2819735063384[u5];
                                    local v928 = u12;
                                    local v929 = u13;

                                    if v928 then
                                        for i in u15, v928 do
                                            local v930 = v928[i];

                                            if v930 then
                                                v930[5] = v930;
                                                v930[6] = u4[i];
                                                v930[4] = 6;
                                                v928[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v929 then
                                        for i, v in u15, v929 do
                                            local v931 = v[6];

                                            if v929 then
                                                local v932 = v929[i];

                                                if v932 then
                                                    local v933 = u3(v931);
                                                    u16(u4, i, i + v931 - 1, 1, v933);
                                                    v932[5] = v933;
                                                    v932[4] = 1;
                                                    v929[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, false, v926, v927;
                                end;

                                if v798 == 107 then
                                    local v934 = u12;
                                    local v935 = u13;

                                    if v934 then
                                        for i in u15, v934 do
                                            local v936 = v934[i];

                                            if v936 then
                                                v936[5] = v936;
                                                v936[6] = u4[i];
                                                v936[4] = 6;
                                                v934[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v935 then
                                        for i, v in u15, v935 do
                                            local v937 = v[6];

                                            if v935 then
                                                local v938 = v935[i];

                                                if v938 then
                                                    local v939 = u3(v937);
                                                    u16(u4, i, i + v937 - 1, 1, v939);
                                                    v938[5] = v939;
                                                    v938[4] = 1;
                                                    v935[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u17(UNNAMED_2819735066504[u5], UNNAMED_2819735088680[u5]);
                                end;

                                if u4[UNNAMED_2819735035304[u5]] >= UNNAMED_2819735072264[u5] then
                                    u5 = UNNAMED_2819735063384[u5];
                                end;
                            elseif v798 < 103 then
                                if UNNAMED_2819735072264[u5] > u4[UNNAMED_2819735035304[u5]] then
                                    u5 = UNNAMED_2819735063384[u5];
                                end;
                            elseif v798 == 104 then
                                u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] ~= UNNAMED_2819735066504[u5];
                            else
                                v36 = UNNAMED_2819735072264[u5];
                                v34 = UNNAMED_2819735035304[u5];
                                v32 = UNNAMED_2819735063384[u5];
                                v35 = u4[v36];
                                u16(u4, v36 + 1, v36 + v34, v32 + 1, v35);
                            end;

                            v797 = 1;
                            continue;
                        end;

                        if v798 >= 48 then
                            if v798 < 72 then
                                if v798 < 60 then
                                    if v798 >= 54 then
                                        if v798 >= 57 then
                                            if v798 < 58 then
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] + u4[UNNAMED_2819735072264[u5]];
                                            elseif v798 == 59 then
                                                UNNAMED_2819735029544[UNNAMED_2819735063384[u5]][u4[UNNAMED_2819735035304[u5]]] = u4[UNNAMED_2819735072264[u5]];
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] < UNNAMED_2819735066504[u5];
                                            end;
                                        elseif v798 < 55 then
                                            u2 = u4[UNNAMED_2819735035304[u5]];
                                        elseif v798 == 56 then
                                            u4[UNNAMED_2819735063384[u5]] = u4;
                                        else
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] ~= u4[UNNAMED_2819735072264[u5]];
                                        end;
                                    elseif v798 >= 51 then
                                        if v798 < 52 then
                                            v36 = UNNAMED_2819735063384[u5] + 1;
                                            v34 = UNNAMED_2819735072264[u5];

                                            for i = 1, UNNAMED_2819735035304[u5] do
                                                local v940 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                                local v941 = u18(v940, (u20(v940, 13)));
                                                v34 = u21(u18(v941, (u22(v941, 14))), 536870911);
                                                UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 0), 127)));
                                                UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 7), 127)));
                                                UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 14), 127)));
                                                UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 21), 127)));
                                                v36 = v36 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735075720[u5] = 86;
                                        elseif v798 == 53 then
                                            u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735072264[u5]] > u4[UNNAMED_2819735035304[u5]];
                                        elseif u4[UNNAMED_2819735035304[u5]] > UNNAMED_2819735063384[u5] then
                                            u5 = UNNAMED_2819735072264[u5];
                                        end;
                                    else
                                        if v798 < 49 then
                                            local v942 = u12;
                                            local v943 = u13;

                                            if v942 then
                                                for i in u15, v942 do
                                                    local v944 = v942[i];

                                                    if v944 then
                                                        v944[5] = v944;
                                                        v944[6] = u4[i];
                                                        v944[4] = 6;
                                                        v942[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v943 then
                                                for i, v in u15, v943 do
                                                    local v945 = v[6];

                                                    if v943 then
                                                        local v946 = v943[i];

                                                        if v946 then
                                                            local v947 = u3(v945);
                                                            u16(u4, i, i + v945 - 1, 1, v947);
                                                            v946[5] = v947;
                                                            v946[4] = 1;
                                                            v943[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, false;
                                        end;

                                        if v798 ~= 50 then
                                            local v948 = u12;
                                            local v949 = u13;

                                            if v948 then
                                                for i in u15, v948 do
                                                    local v950 = v948[i];

                                                    if v950 then
                                                        v950[5] = v950;
                                                        v950[6] = u4[i];
                                                        v950[4] = 6;
                                                        v948[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v949 then
                                                for i, v in u15, v949 do
                                                    local v951 = v[6];

                                                    if v949 then
                                                        local v952 = v949[i];

                                                        if v952 then
                                                            local v953 = u3(v951);
                                                            u16(u4, i, i + v951 - 1, 1, v953);
                                                            v952[5] = v953;
                                                            v952[4] = 1;
                                                            v949[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735072264[u5], u17(UNNAMED_2819735050136[u5], u14(u4[UNNAMED_2819735063384[u5]], 1, u4[UNNAMED_2819735063384[u5]].n));
                                        end;

                                        v36 = u4[UNNAMED_2819735063384[u5]];
                                        v34 = UNNAMED_2819735072264[u5];
                                        v32 = UNNAMED_2819735035304[u5];
                                        u16(v36, 1, v32, v34, u4);
                                    end;
                                elseif v798 >= 66 then
                                    if v798 >= 69 then
                                        if v798 >= 70 then
                                            if v798 == 71 then
                                                v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                                v36[5][v36[4]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735063384[u5];
                                            else
                                                u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735075720;
                                            end;
                                        else
                                            v36 = UNNAMED_2819735035304[u5];
                                            v34 = UNNAMED_2819735072264[u5];
                                            v32 = u18(u2, u21(u20(u2, 14), 262143), (u21(u20(u2, 28), 15)));
                                            v35 = UNNAMED_2819735063384[u5];
                                            v33 = v36 < 2097152 and 7 or 14;
                                            v37 = u20(v36, v33);
                                            local v954 = u21(v36, u22(1, v33) - 1);
                                            UNNAMED_2819735063384[u5] = u18(v35, 66, (u21(v32, 127)));
                                            UNNAMED_2819735072264[u5] = u18(v34, 83, (u21(u20(v32, 7), 127)));
                                            UNNAMED_2819735075720[u5] = u18(v37, 60, (u21(u20(v32, 21), 127)));
                                            UNNAMED_2819735035304[u5] = u18(v954, 7, (u21(u20(v32, 14), 127)));
                                            u5 = u5 - 1;
                                        end;
                                    elseif v798 < 67 then
                                        u24[UNNAMED_2819735066504[u5]] = u4[UNNAMED_2819735035304[u5]];
                                    elseif v798 == 68 then
                                        if u12 then
                                            local v955 = u12;
                                            local v956 = UNNAMED_2819735035304[u5];
                                            local v957 = v955[v956];

                                            if v957 then
                                                v957[5] = v957;
                                                v957[6] = u4[v956];
                                                v957[4] = 6;
                                                v955[v956] = nil;
                                            end;

                                            local v958 = u12;
                                            local v959 = UNNAMED_2819735063384[u5];
                                            local v960 = v958[v959];

                                            if v960 then
                                                v960[5] = v960;
                                                v960[6] = u4[v959];
                                                v960[4] = 6;
                                                v958[v959] = nil;
                                            end;

                                            local v961 = u12;
                                            local v962 = UNNAMED_2819735072264[u5];
                                            local v963 = v961[v962];

                                            if v963 then
                                                v963[5] = v963;
                                                v963[6] = u4[v962];
                                                v963[4] = 6;
                                                v961[v962] = nil;
                                            end;
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] // u4[UNNAMED_2819735063384[u5]];
                                    end;
                                elseif v798 >= 63 then
                                    if v798 < 64 then
                                        u4[UNNAMED_2819735063384[u5]] = {};
                                    elseif v798 == 65 then
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] == u4[UNNAMED_2819735063384[u5]];
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735072264[u5]](UNNAMED_2819735050136[u5]);
                                    end;
                                elseif v798 < 61 then
                                    u4[UNNAMED_2819735063384[u5]] = u21(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735066504[u5]);
                                elseif v798 == 62 then
                                    if UNNAMED_2819735035304[u5] >= u4[UNNAMED_2819735072264[u5]] then
                                        u5 = UNNAMED_2819735063384[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735063384[u5] ^ u4[UNNAMED_2819735035304[u5]];
                                end;
                            elseif v798 >= 84 then
                                if v798 < 90 then
                                    if v798 < 87 then
                                        if v798 < 85 then
                                            u4[UNNAMED_2819735035304[u5]] = #u4[UNNAMED_2819735063384[u5]];
                                        elseif v798 ~= 86 then
                                            local v964 = UNNAMED_2819735063384[u5];
                                            local v965 = u4[UNNAMED_2819735072264[u5]];
                                            local v966 = u21(UNNAMED_2819735050136[u5], 4294967295);
                                            local v967 = u21(v965, 4294967295);
                                            local v968 = u21(v966, 65535);
                                            local v969 = u20(v966, 16);
                                            local v970 = u21(v967, 65535);
                                            local v971 = u20(v967, 16);
                                            local v972 = u21(v968 * v970 + u22(u21(v968 * v971 + v969 * v970, 65535), 16), 4294967295) % 4294967296;
                                            u4[v964] = v972 ~= v972 and 0 or v972 - v972 % 1;
                                        end;
                                    elseif v798 < 88 then
                                        u4[UNNAMED_2819735072264[u5]] = u22(u4[UNNAMED_2819735063384[u5]], UNNAMED_2819735035304[u5]);
                                    else
                                        if v798 == 89 then
                                            local v973 = u12;
                                            local v974 = u13;

                                            if v973 then
                                                for i in u15, v973 do
                                                    local v975 = v973[i];

                                                    if v975 then
                                                        v975[5] = v975;
                                                        v975[6] = u4[i];
                                                        v975[4] = 6;
                                                        v973[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v974 then
                                                for i, v in u15, v974 do
                                                    local v976 = v[6];

                                                    if v974 then
                                                        local v977 = v974[i];

                                                        if v977 then
                                                            local v978 = u3(v976);
                                                            u16(u4, i, i + v976 - 1, 1, v978);
                                                            v977[5] = v978;
                                                            v977[4] = 1;
                                                            v974[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            local v979 = UNNAMED_2819735072264[u5];

                                            return false, false, v979, v979 + UNNAMED_2819735035304[u5] - 1;
                                        end;

                                        u4[UNNAMED_2819735072264[u5]][UNNAMED_2819735088680[u5]] = UNNAMED_2819735035304[u5];
                                    end;
                                elseif v798 < 93 then
                                    if v798 >= 91 then
                                        if v798 == 92 then
                                            local v980 = u12;
                                            local v981 = u13;

                                            if v980 then
                                                for i in u15, v980 do
                                                    local v982 = v980[i];

                                                    if v982 then
                                                        v982[5] = v982;
                                                        v982[6] = u4[i];
                                                        v982[4] = 6;
                                                        v980[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v981 then
                                                for i, v in u15, v981 do
                                                    local v983 = v[6];

                                                    if v981 then
                                                        local v984 = v981[i];

                                                        if v984 then
                                                            local v985 = u3(v983);
                                                            u16(u4, i, i + v983 - 1, 1, v985);
                                                            v984[5] = v985;
                                                            v984[4] = 1;
                                                            v981[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u17(u4[UNNAMED_2819735072264[u5]]);
                                        end;

                                        u4[UNNAMED_2819735035304[u5]](UNNAMED_2819735066504[u5]);
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u18(UNNAMED_2819735066504[u5], UNNAMED_2819735088680[u5]);
                                    end;
                                else
                                    if v798 >= 94 then
                                        if v798 == 95 then
                                            local v986 = u12;
                                            local v987 = u13;

                                            if v986 then
                                                for i in u15, v986 do
                                                    local v988 = v986[i];

                                                    if v988 then
                                                        v988[5] = v988;
                                                        v988[6] = u4[i];
                                                        v988[4] = 6;
                                                        v986[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v987 then
                                                for i, v in u15, v987 do
                                                    local v989 = v[6];

                                                    if v987 then
                                                        local v990 = v987[i];

                                                        if v990 then
                                                            local v991 = u3(v989);
                                                            u16(u4, i, i + v989 - 1, 1, v991);
                                                            v990[5] = v991;
                                                            v990[4] = 1;
                                                            v987[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u4[UNNAMED_2819735035304[u5]];
                                        end;

                                        local v992 = u12;
                                        local v993 = u13;

                                        if v992 then
                                            for i in u15, v992 do
                                                local v994 = v992[i];

                                                if v994 then
                                                    v994[5] = v994;
                                                    v994[6] = u4[i];
                                                    v994[4] = 6;
                                                    v992[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v993 then
                                            for i, v in u15, v993 do
                                                local v995 = v[6];

                                                if v993 then
                                                    local v996 = v993[i];

                                                    if v996 then
                                                        local v997 = u3(v995);
                                                        u16(u4, i, i + v995 - 1, 1, v997);
                                                        v996[5] = v997;
                                                        v996[4] = 1;
                                                        v993[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819735072264[u5], u4[UNNAMED_2819735063384[u5]];
                                    end;

                                    u4[UNNAMED_2819735035304[u5]] = u24[UNNAMED_2819735088680[u5]][u4[UNNAMED_2819735072264[u5]]];
                                end;
                            elseif v798 >= 78 then
                                if v798 >= 81 then
                                    if v798 < 82 then
                                        u4[UNNAMED_2819735035304[u5]][UNNAMED_2819735066504[u5]] = UNNAMED_2819735088680[u5];
                                    elseif v798 == 83 then
                                        v36 = UNNAMED_2819735035304[u5];
                                        v34 = UNNAMED_2819735063384[u5];
                                        v32 = UNNAMED_2819735072264[u5];
                                        v35 = u4[v36];
                                        v33 = v36 + v34;
                                        v37 = u4[v33];
                                        u16(u4, v36 + 1, v33 - 1, v32 + 1, v35);
                                        u16(v37, 1, v37.n, v32 + v34, v35);
                                    else
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] .. UNNAMED_2819735050136[u5];
                                    end;
                                elseif v798 >= 79 then
                                    if v798 == 80 then
                                        v36 = UNNAMED_2819735035304[u5];
                                        v34 = UNNAMED_2819735072264[u5];
                                        v32 = UNNAMED_2819735063384[u5];
                                        v35 = u18(u2, u21(u20(u2, 14), 262143), (u21(u20(u2, 28), 15)));
                                        v33 = v32 < 16384 and 7 or (v32 < 2097152 and 14 or 21);
                                        v37 = u20(v32, v33);
                                        UNNAMED_2819735063384[u5] = u18(u21(v32, u22(1, v33) - 1), 58, (u21(v35, 127)));
                                        UNNAMED_2819735072264[u5] = u18(v34, 44, (u21(u20(v35, 7), 127)));
                                        UNNAMED_2819735035304[u5] = u18(v36, 38, (u21(u20(v35, 14), 127)));
                                        UNNAMED_2819735075720[u5] = u18(v37, 20, (u21(u20(v35, 21), 127)));
                                        u5 = u5 - 1;
                                    else
                                        v36 = UNNAMED_2819735072264[u5];
                                        v34 = u4[UNNAMED_2819735063384[u5]];
                                        u4[v36 + 1] = v34;
                                        u4[v36] = v34[UNNAMED_2819735050136[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] % u4[UNNAMED_2819735035304[u5]];
                                end;
                            elseif v798 >= 75 then
                                if v798 < 76 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] > UNNAMED_2819735072264[u5];
                                elseif v798 == 77 then
                                    if u4[UNNAMED_2819735063384[u5]] >= u4[UNNAMED_2819735035304[u5]] then
                                        u5 = UNNAMED_2819735072264[u5];
                                    end;
                                else
                                    u4[UNNAMED_2819735063384[u5]]();
                                end;
                            elseif v798 >= 73 then
                                if v798 == 74 then
                                    u24[UNNAMED_2819735066504[u5]][u4[UNNAMED_2819735063384[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                else
                                    v36 = UNNAMED_2819735029544[UNNAMED_2819735035304[u5]];
                                    v36[5][v36[4]] = u4[UNNAMED_2819735072264[u5]];
                                end;
                            else
                                u5 = UNNAMED_2819735063384[u5];
                            end;

                            v797 = 1;
                            continue;
                        end;

                        if v798 < 24 then
                            if v798 < 12 then
                                if v798 < 6 then
                                    if v798 >= 3 then
                                        if v798 < 4 then
                                            v36 = UNNAMED_2819735035304[u5];
                                            local v998 = UNNAMED_2819735066504[u5];
                                            u4[v36] = UNNAMED_2819735088680[u5];
                                            u4[v36 + 1] = v998;
                                        else
                                            if v798 ~= 5 then
                                                local v999 = u12;
                                                local v1000 = u13;

                                                if v999 then
                                                    for i in u15, v999 do
                                                        local v1001 = v999[i];

                                                        if v1001 then
                                                            v1001[5] = v1001;
                                                            v1001[6] = u4[i];
                                                            v1001[4] = 6;
                                                            v999[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v1000 then
                                                    for i, v in u15, v1000 do
                                                        local v1002 = v[6];

                                                        if v1000 then
                                                            local v1003 = v1000[i];

                                                            if v1003 then
                                                                local v1004 = u3(v1002);
                                                                u16(u4, i, i + v1002 - 1, 1, v1004);
                                                                v1003[5] = v1004;
                                                                v1003[4] = 1;
                                                                v1000[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735072264[u5], u17(u4[UNNAMED_2819735035304[u5]], UNNAMED_2819735088680[u5]);
                                            end;

                                            if UNNAMED_2819735050136[u5] >= u4[UNNAMED_2819735072264[u5]] then
                                                u5 = UNNAMED_2819735063384[u5];
                                            end;
                                        end;
                                    elseif v798 >= 1 then
                                        if v798 == 2 then
                                            u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735066504[u5] .. u4[UNNAMED_2819735063384[u5]];
                                        elseif u4[UNNAMED_2819735072264[u5]] > u4[UNNAMED_2819735063384[u5]] then
                                            u5 = UNNAMED_2819735035304[u5];
                                        end;
                                    else
                                        u4[UNNAMED_2819735063384[u5]] = u19(u4[UNNAMED_2819735035304[u5]], u4[UNNAMED_2819735072264[u5]]);
                                    end;
                                elseif v798 < 9 then
                                    if v798 < 7 then
                                        local v1005 = u12;
                                        local v1006 = u13;

                                        if v1005 then
                                            for i in u15, v1005 do
                                                local v1007 = v1005[i];

                                                if v1007 then
                                                    v1007[5] = v1007;
                                                    v1007[6] = u4[i];
                                                    v1007[4] = 6;
                                                    v1005[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v1006 then
                                            for i, v in u15, v1006 do
                                                local v1008 = v[6];

                                                if v1006 then
                                                    local v1009 = v1006[i];

                                                    if v1009 then
                                                        local v1010 = u3(v1008);
                                                        u16(u4, i, i + v1008 - 1, 1, v1010);
                                                        v1009[5] = v1010;
                                                        v1009[4] = 1;
                                                        v1006[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u17(UNNAMED_2819735050136[u5]);
                                    end;

                                    if v798 == 8 then
                                        u4[UNNAMED_2819735035304[u5]] = u18(u4[UNNAMED_2819735072264[u5]], u4[UNNAMED_2819735063384[u5]]);
                                    else
                                        u8 = u7[8];
                                        u9 = u7[5];
                                        u10 = u7[7];
                                        u11 = u7[6];
                                        u7 = u7[9];
                                    end;
                                elseif v798 < 10 then
                                    if u4[UNNAMED_2819735072264[u5]] ~= UNNAMED_2819735063384[u5] then
                                        u5 = UNNAMED_2819735035304[u5];
                                    end;
                                elseif v798 == 11 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] .. u4[UNNAMED_2819735072264[u5]];
                                elseif UNNAMED_2819735050136[u5] > u4[UNNAMED_2819735072264[u5]] then
                                    u5 = UNNAMED_2819735063384[u5];
                                end;
                            elseif v798 >= 18 then
                                if v798 < 21 then
                                    if v798 >= 19 then
                                        if v798 == 20 then
                                            local v1011 = UNNAMED_2819735035304[u5];
                                            local v1012 = UNNAMED_2819735063384[u5];
                                            local v1013 = v1011 + v1012;
                                            local v1014 = u4[v1013];
                                            local n = v1014.n;
                                            local v1015 = u12;
                                            local v1016 = u13;

                                            if v1015 then
                                                for i in u15, v1015 do
                                                    local v1017 = v1015[i];

                                                    if v1017 then
                                                        v1017[5] = v1017;
                                                        v1017[6] = u4[i];
                                                        v1017[4] = 6;
                                                        v1015[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v1016 then
                                                for i, v in u15, v1016 do
                                                    local v1018 = v[6];

                                                    if v1016 then
                                                        local v1019 = v1016[i];

                                                        if v1019 then
                                                            local v1020 = u3(v1018);
                                                            u16(u4, i, i + v1018 - 1, 1, v1020);
                                                            v1019[5] = v1020;
                                                            v1019[4] = 1;
                                                            v1016[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            v1014.n = v1012 + n - 1;
                                            u16(v1014, 1, n, v1012, v1014);
                                            u16(u4, v1011 + 1, v1013 - 1, 1, v1014);

                                            return true, true, v1011, v1014;
                                        end;

                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735035304[u5]] ~= UNNAMED_2819735063384[u5];
                                    else
                                        u5 = u4[UNNAMED_2819735035304[u5]];
                                    end;
                                elseif v798 < 22 then
                                    u4[UNNAMED_2819735035304[u5]] = UNNAMED_2819735029544[UNNAMED_2819735063384[u5]];
                                elseif v798 == 23 then
                                    u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735058152;
                                else
                                    u4[UNNAMED_2819735035304[u5]] = not u4[UNNAMED_2819735072264[u5]];
                                end;
                            elseif v798 >= 15 then
                                if v798 >= 16 then
                                    if v798 == 17 then
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]] == UNNAMED_2819735035304[u5];
                                    elseif u4[UNNAMED_2819735063384[u5]] >= UNNAMED_2819735066504[u5] then
                                        u5 = UNNAMED_2819735035304[u5];
                                    end;
                                else
                                    v36 = UNNAMED_2819735063384[u5] + 1;
                                    v34 = u18(UNNAMED_2819735072264[u5], (u21(u18(u2, (u21(u20(u2, 29), 7))), 536870911)));

                                    for i = 1, UNNAMED_2819735035304[u5] do
                                        local v1021 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                        local v1022 = u18(v1021, (u20(v1021, 13)));
                                        v34 = u21(u18(v1022, (u22(v1022, 14))), 536870911);
                                        UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 0), 127)));
                                        UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 7), 127)));
                                        UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 14), 127)));
                                        UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 21), 127)));
                                        v36 = v36 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735075720[u5] = 86;
                                end;
                            elseif v798 < 13 then
                                u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]][1];
                            elseif v798 == 14 then
                                v36 = UNNAMED_2819735063384[u5];
                                v34 = { ... };
                                v32 = UNNAMED_2819735035304[u5];
                                u16(v34, 1, v36 - 1, v32, u4);
                                u4[v32 + v36 - 1] = u17(u23(v36, ...));
                            else
                                v36 = UNNAMED_2819735063384[u5];
                                local v1023 = UNNAMED_2819735066504[u5];
                                u4[v36] = UNNAMED_2819735035304[u5];
                                u4[v36 + 1] = v1023;
                            end;

                            v797 = 1;
                            continue;
                        end;

                        if v798 >= 36 then
                            if v798 < 42 then
                                if v798 < 39 then
                                    if v798 < 37 then
                                        u4[UNNAMED_2819735072264[u5]](u4[UNNAMED_2819735035304[u5]]);
                                    elseif v798 == 38 then
                                        u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]];
                                    else
                                        v36 = UNNAMED_2819735063384[u5];
                                        v34 = UNNAMED_2819735072264[u5];
                                        v32 = UNNAMED_2819735035304[u5];
                                        v35 = v36 + v32 - 1;
                                        v33 = v36 + v34;
                                        v37 = u4[v33];
                                        local n = v37.n;
                                        v37.n = v34 + n - 1;
                                        u16(v37, 1, n, v34, v37);
                                        u16(u4, v36 + 1, v33 - 1, 1, v37);
                                        u16(u17(u4[v36](u14(v37, 1, v37.n))), 1, v32, v36, u4);
                                    end;
                                elseif v798 < 40 then
                                    u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735063384[u5]] + UNNAMED_2819735072264[u5];
                                elseif v798 == 41 then
                                    u4[UNNAMED_2819735063384[u5]](UNNAMED_2819735066504[u5], u4[UNNAMED_2819735035304[u5]]);
                                else
                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] * u4[UNNAMED_2819735072264[u5]];
                                end;
                            elseif v798 < 45 then
                                if v798 >= 43 then
                                    if v798 == 44 then
                                        for i = UNNAMED_2819735072264[u5], UNNAMED_2819735035304[u5] do
                                            u4[i] = nil;
                                            local _ = i;
                                        end;
                                    else
                                        u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] / u4[UNNAMED_2819735063384[u5]];
                                    end;
                                else
                                    u4[UNNAMED_2819735072264[u5]] = -u4[UNNAMED_2819735035304[u5]];
                                end;
                            elseif v798 < 46 then
                                u4[UNNAMED_2819735063384[u5]] = u18(u4[UNNAMED_2819735072264[u5]], UNNAMED_2819735035304[u5]);
                            elseif v798 == 47 then
                                u4[UNNAMED_2819735063384[u5]](u14(u4[UNNAMED_2819735072264[u5]], 1, u4[UNNAMED_2819735072264[u5]].n));
                            else
                                u4[UNNAMED_2819735072264[u5]] = u19(u4[UNNAMED_2819735063384[u5]], UNNAMED_2819735050136[u5]);
                            end;
                        elseif v798 >= 30 then
                            if v798 < 33 then
                                if v798 < 31 then
                                    u4[UNNAMED_2819735063384[u5]] = u4[UNNAMED_2819735035304[u5]] < u4[UNNAMED_2819735072264[u5]];
                                elseif v798 == 32 then
                                    u4[UNNAMED_2819735035304[u5]](u4[UNNAMED_2819735072264[u5]], u4[UNNAMED_2819735063384[u5]]);
                                else
                                    u4[UNNAMED_2819735063384[u5]][u4[UNNAMED_2819735072264[u5]]] = u4[UNNAMED_2819735035304[u5]];
                                end;
                            elseif v798 < 34 then
                                v36 = UNNAMED_2819735072264[u5];
                                v34 = u4[UNNAMED_2819735063384[u5]];
                                u4[v36 + 1] = v34;
                                u4[v36] = v34[UNNAMED_2819735050136[u5]];
                                u4[UNNAMED_2819735072264[u5 + 1]] = u4[UNNAMED_2819735063384[u5 + 1]];
                                u4[UNNAMED_2819735072264[u5 + 2]] = UNNAMED_2819735050136[u5 + 2];
                                u4[UNNAMED_2819735072264[u5 + 3]] = u4[UNNAMED_2819735063384[u5 + 3]];
                                u5 = u5 + 3;
                            else
                                if v798 ~= 35 then
                                    local v1024 = u12;
                                    local v1025 = u13;

                                    if v1024 then
                                        for i in u15, v1024 do
                                            local v1026 = v1024[i];

                                            if v1026 then
                                                v1026[5] = v1026;
                                                v1026[6] = u4[i];
                                                v1026[4] = 6;
                                                v1024[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v1025 then
                                        for i, v in u15, v1025 do
                                            local v1027 = v[6];

                                            if v1025 then
                                                local v1028 = v1025[i];

                                                if v1028 then
                                                    local v1029 = u3(v1027);
                                                    u16(u4, i, i + v1027 - 1, 1, v1029);
                                                    v1028[5] = v1029;
                                                    v1028[4] = 1;
                                                    v1025[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819735035304[u5], u17();
                                end;

                                u4[UNNAMED_2819735063384[u5]] = UNNAMED_2819735029544[UNNAMED_2819735072264[u5]][u4[UNNAMED_2819735035304[u5]]];
                            end;
                        else
                            if v798 < 27 then
                                if v798 < 25 then
                                    u4[UNNAMED_2819735072264[u5]] = u4[UNNAMED_2819735063384[u5]];
                                    v36 = UNNAMED_2819735035304[u5 + 1];
                                    v34 = UNNAMED_2819735063384[u5 + 1];
                                    v32 = UNNAMED_2819735072264[u5 + 1];
                                    v35 = v36 + v32 - 1;
                                    v33 = v36 + v34;
                                    v37 = u17(u4[v36](u14(u4, v36 + 1, v36 + v34)));
                                    u16(v37, 1, v32, v36, u4);
                                    u5 = u5 + 1;
                                elseif v798 == 26 then
                                    u4[UNNAMED_2819735072264[u5]] = UNNAMED_2819735072264;
                                else
                                    local v1030 = UNNAMED_2819735063384[u5];
                                    local v1031 = u4[UNNAMED_2819735035304[u5]];
                                    local v1032 = u21(u4[UNNAMED_2819735072264[u5]], 4294967295);
                                    local v1033 = u21(v1031, 4294967295);
                                    local v1034 = u21(v1032, 65535);
                                    local v1035 = u20(v1032, 16);
                                    local v1036 = u21(v1033, 65535);
                                    local v1037 = u20(v1033, 16);
                                    local v1038 = u21(v1034 * v1036 + u22(u21(v1034 * v1037 + v1035 * v1036, 65535), 16), 4294967295) % 4294967296;
                                    u4[v1030] = v1038 ~= v1038 and 0 or v1038 - v1038 % 1;
                                end;

                                v797 = 1;
                                continue;
                            end;

                            if v798 < 28 then
                                v36 = UNNAMED_2819735063384[u5] + 1;
                                v34 = u18(UNNAMED_2819735072264[u5], (u21(u18(u1, (u21(u20(u1, 29), 7))), 536870911)));

                                for i = 1, UNNAMED_2819735035304[u5] do
                                    local v1039 = u21(u18(v34, (u22(v34, 13))), 536870911);
                                    local v1040 = u18(v1039, (u20(v1039, 13)));
                                    v34 = u21(u18(v1040, (u22(v1040, 14))), 536870911);
                                    UNNAMED_2819735063384[v36] = u18(UNNAMED_2819735063384[v36], (u21(u20(v34, 0), 127)));
                                    UNNAMED_2819735072264[v36] = u18(UNNAMED_2819735072264[v36], (u21(u20(v34, 7), 127)));
                                    UNNAMED_2819735035304[v36] = u18(UNNAMED_2819735035304[v36], (u21(u20(v34, 14), 127)));
                                    UNNAMED_2819735075720[v36] = u18(UNNAMED_2819735075720[v36], (u21(u20(v34, 21), 127)));
                                    v36 = v36 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735075720[u5] = 86;
                                v797 = 1;
                                continue;
                            end;

                            if v798 == 29 then
                                u6 = UNNAMED_2819735035304[u5];
                                u5 = UNNAMED_2819735072264[u5] + 1;
                                v38 = 1;
                                break;
                            end;

                            u4[UNNAMED_2819735035304[u5]] = u4[UNNAMED_2819735072264[u5]] / UNNAMED_2819735063384[u5];
                        end;

                        v797 = 1;
                        continue;
                    elseif v797 == 1 then
                        v797 = -1;
                        u5 = u5 + 1;
                        break;
                    else
                        break;
                    end;
                end;

                if v38 ~= -1 then
                    break;
                end;
            end;

            if v38 ~= -1 then
                continue;
            end;

            break;
        else
            break;
        end;
    end;
end, ...);

if v1041 then
    if v1042 then
        if v1043 then
            return u4[v1044](u14(v1045, 1, v1045.n));
        end;

        return u4[v1044](u14(u4, v1044 + 1, v1045));
    end;

    if v1044 then
        if v1043 then
            return u14(v1044, 1, v1044.n);
        end;

        return u14(u4, v1044, v1045);
    end;
else
    local v1046 = u12;
    local v1047 = u13;

    if v1046 then
        for i in u15, v1046 do
            local v1048 = v1046[i];

            if v1048 then
                v1048[5] = v1048;
                v1048[6] = u4[i];
                v1048[4] = 6;
                v1046[i] = nil;
            end;
        end;
    end;

    if v1047 then
        for i, v in u15, v1047 do
            local v1049 = v[6];

            if v1047 then
                local v1050 = v1047[i];

                if v1050 then
                    local v1051 = u3(v1049);
                    u16(u4, i, i + v1049 - 1, 1, v1051);
                    v1050[5] = v1051;
                    v1050[4] = 1;
                    v1047[i] = nil;
                end;
            end;
        end;
    end;

    UNNAMED_2819735079512(UNNAMED_2819735088728, v1042, u5, UNNAMED_2819735048888);
end;