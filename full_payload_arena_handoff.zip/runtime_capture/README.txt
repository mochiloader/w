The original launcher ran successfully without capture hooks or a tamper kick.
The script's gameplay UI appeared. Read-only runtime inspection then captured
the selected gameplay callbacks and their reachable Lua values.

This is new gameplay runtime evidence, not just another copy of /loader/v1.
There are 136 named controls, including Automatics/Auto Kick,
Automatics/Kick Accuracy, QB Aimbot, and Catching controls. The Auto Kick
callback is graph node 126. Its VM decompilation is saved
as auto_kick_callback.vm.lua. Four QB callback VM decompilations are also saved.

The captured LPH-prefixed blob is 1,105,490 bytes. The graph contains
15,609 nodes, 3,289 functions, 12,316 tables,
4 buffers, and 245,805 table entries. The exporter
finished its selected traversal without hitting a limit. Every recorded graph
reference resolves, and no per-table truncation was reported.

This is NOT complete original Lua source. The gameplay callbacks remain
virtualized. The decompiler exposes the interpreter and unresolved upvalue
names; it does not turn virtual instructions into clean gameplay functions.
Native functions and Roblox objects are external leaves. Lazy constant
decoders were not invoked, so some constants remain encoded. A complete
selected reference graph does not prove all application behaviors or every
runtime object were captured. These files are for analysis, not execution.

Files:
- gameplay_luraph_blob.bin: captured LPH-prefixed gameplay VM blob.
- runtime_graph/: numbered JSON node records, manifest, buffers, and long strings.
  Each {"ref":N} points to a node ID. Scalar values carry explicit types;
  strings use hex, long strings/buffers use saved files. Captured original file
  paths resolve by basename inside runtime_graph/. constantsRef points to a
  function node holding an identical compiled constant group (by function hash).
- auto_kick_callback.vm.lua: decompiled interpreter closure bound to Auto Kick.
- gameplay_callback_*.lua: decompiled interpreter closures bound to QB controls.
- gameplay_controls.json: label-to-callback-node mapping.
- readable_runtime_strings.json: readable values extracted from captured graph
  strings; a string's presence is not proof of execution or complete behavior.
- capture_summary.json: counts, digest, validation, and limitations.

The known license value was redacted in exported strings. No recovered code
was executed. No compiler or HTTP hook was installed. No gameplay setting was
changed by the inspection. The original script remains loaded in the client.
Live-client work stopped after this capture, as requested. Two earlier graph
exports were incomplete or filtered too narrowly and are not in this bundle.
