-- Decompiled with Potassium's decompiler.

local v1 = UNNAMED_2819735088440[114];
v1();

for i, v in UNNAMED_2819735078072, UNNAMED_2819735029304, UNNAMED_2819735033768 do
    v1(true, i, v);
end;