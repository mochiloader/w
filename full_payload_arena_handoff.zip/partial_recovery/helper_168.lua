-- Decompiled with Potassium's decompiler.

local v1 = UNNAMED_2819735088536[37];
local v2 = UNNAMED_2819735088536[68];
local v3 = UNNAMED_2819735088536[103];
local v4 = 3;
local v5 = nil;

while true do
    while v4 <= 3 do
        if v4 <= 1 then
            if v4 <= 0 then
                local v6 = UNNAMED_2819735048024[UNNAMED_2819735087768];

                if v6 then
                    v5 = v6;
                    UNNAMED_2819735048024 = v1;
                    v4 = 4;
                    UNNAMED_2819735087768 = "LPH:";
                else
                    UNNAMED_2819735048024 = v1;
                    v4 = 7;
                    UNNAMED_2819735087768 = "LPH:";
                end;
            else
                v1(UNNAMED_2819735048744, 0);
                v4 = 6;
            end;
        elseif v4 <= 2 then
            v4 = v2(UNNAMED_2819735048744, "%:[^%l%L]?([0-9]+)[%:\n\r]") and 0 or 1;
        else
            v4 = v3(UNNAMED_2819735048744) == "string" and 2 or 5;
        end;
    end;

    if v4 <= 5 then
        if v4 <= 4 then
            UNNAMED_2819735048024(UNNAMED_2819735087768 .. v5 .. ": " .. UNNAMED_2819735048744, 0);
            v4 = 6;
        else
            v1(UNNAMED_2819735048744, 1);
            v4 = 6;
        end;
    else
        if v4 <= 6 then
            return;
        end;

        v4 = 4;
        v5 = "?";
    end;
end;