-- Analysis reference: renamed decompiled VM, not devirtualized gameplay.
-- Shadow-declaration repairs are inferred and tested only for the Auto Kick toggle path.
return function(captured, ...)
	-- Decompiled with Potassium's decompiler.

	local seedA = captured.seedA
	local seedB = captured.seedB
	local createRegisters = captured.createRegisters
	local registers = createRegisters(captured.registerCount)
	local pc = captured.entryPc
	local mode = captured.entryMode
	local u7 = nil
	local u8 = nil
	local u9 = nil
	local u10 = nil
	local u11 = nil
	local u12 = nil
	local u13 = nil
	local unpackValues = captured.unpackValues
	local nextEntry = captured.nextEntry
	local moveValues = captured.moveValues
	local packValues = captured.packValues
	local bitXor = captured.bitXor
	local bitOr = captured.bitOr
	local rightShift = captured.rightShift
	local bitAnd = captured.bitAnd
	local leftShift = captured.leftShift
	local selectValues = captured.selectValues
	local environment = captured.environment
	local bitNot = captured.bitNot
	local wrapCoroutine = captured.wrapCoroutine
	local closeUpvalues = captured.closeUpvalues
	local readByte = captured.readByte
	local writeUInt32 = captured.writeUInt32
	local readUInt32 = captured.readUInt32
	local writeByte = captured.writeByte
	local v1041, v1042, v1043, v1044, v1045 = captured.protectedCall(function(...) -- Line: 3
		-- upvalues: mode (ref), captured.opcodes (ref), pc (ref), registers (copy), captured.operandB (ref), captured.operandA (ref), captured.operandC (ref), moveValues (copy), packValues (copy), unpackValues (copy), captured.constantB (ref), bitXor (copy), bitOr (copy), captured.constantA (ref), captured.capturedValues (ref), u12 (ref), u13 (ref), nextEntry (copy), createRegisters (copy), bitAnd (copy), seedA (ref), rightShift (copy), leftShift (copy), captured.constantC (ref), u8 (ref), u7 (ref), u9 (ref), u10 (ref), u11 (ref), captured.constantState (ref), seedB (ref), selectValues (copy), environment (copy), bitNot (copy), wrapCoroutine (copy), closeUpvalues (copy), captured.runtime (ref), readByte (copy), writeUInt32 (copy), readUInt32 (copy), writeByte (copy), captured.constantOpcode (ref)
		local v32, v33, v34, v35, v36, v37
		local v32, v33, v34, v35, v36, v37
		local v38 = 0

		while true do
			if v38 == 0 then
				v38 = -1
				v32 = nil
				v33 = nil
				v34 = nil
				v35 = nil
				v36 = nil
				v37 = nil

				if mode ~= 113 then
					v38 = 1
					continue
				end

				v38 = 6
				continue
			elseif v38 == 1 then
				v38 = -1

				if mode ~= 127 then
					v38 = 2
					continue
				end

				v38 = 5
				continue
			elseif v38 == 2 then
				v38 = -1

				if mode ~= 240 then
					v38 = 3
					continue
				end

				v38 = 4
				continue
			elseif v38 == 3 then
				v38 = -1

				if mode ~= 31 then
					return
				end

				while true do
					local v39 = captured.operandC[pc]

					if v39 < 95 then
						if v39 < 47 then
							if v39 < 23 then
								if v39 < 11 then
									if v39 < 5 then
										if v39 >= 2 then
											if v39 < 3 then
												v36 = captured.operandB[pc]
												local v40 = captured.operandA[pc]
												registers[v36] = captured.constantOpcode[pc]
												registers[v36 + 1] = v40
											elseif v39 == 4 then
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
													// registers[captured.opcodes[pc]]
											else
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
												v36 = captured.operandA[pc + 1]
												v34 = captured.opcodes[pc + 1]
												v32 = captured.operandB[pc + 1]
												v35 = v36 + v32 - 1
												v33 = v36 + v34
												v37 = packValues(
													registers[v36](unpackValues(registers, v36 + 1, v36 + v34))
												)
												moveValues(v37, 1, v32, v36, registers)
												pc = pc + 1
											end
										elseif v39 == 1 then
											if registers[captured.operandB[pc]] ~= registers[captured.opcodes[pc]] then
												pc = captured.operandA[pc]
											end
										else
											registers[captured.operandB[pc]][registers[captured.opcodes[pc]]] =
												captured.operandA[pc]
										end
									elseif v39 >= 8 then
										if v39 >= 9 then
											if v39 == 10 then
												u8 = u8 + u10

												if u10 <= 0 then
													v36 = u9 <= u8
												else
													v36 = u8 <= u9
												end

												if v36 then
													registers[captured.operandA[pc]] = u8
													pc = captured.opcodes[pc]
												else
													pc = captured.operandB[pc]
												end
											else
												registers[captured.operandB[pc]] = captured.constantA[pc]
													* captured.constantOpcode[pc]
											end
										else
											v36 = captured.operandA[pc]
											v34 = captured.opcodes[pc]
											v32 = captured.operandB[pc]
											v35 = v36 + v32 - 1
											v33 = v36 + v34
											v37 =
												packValues(registers[v36](unpackValues(registers, v36 + 1, v36 + v34)))
											moveValues(v37, 1, v32, v36, registers)
										end
									elseif v39 >= 6 then
										if v39 == 7 then
											v36 = captured.opcodes[pc]
											local v41 = registers[captured.operandA[pc]]
											registers[v36] = registers[captured.operandB[pc]]
											registers[v36 + 1] = v41
										elseif captured.operandA[pc] > registers[captured.operandB[pc]] then
											pc = captured.opcodes[pc]
										end
									else
										environment[captured.constantB[pc]][captured.constantOpcode[pc]] =
											registers[captured.operandA[pc]]
									end
								elseif v39 < 17 then
									if v39 >= 14 then
										if v39 < 15 then
											local v42 = u12
											local v43 = u13

											if v42 then
												for i in nextEntry, v42 do
													local v44 = v42[i]

													if v44 then
														v44[5] = v44
														v44[6] = registers[i]
														v44[4] = 6
														v42[i] = nil
													end
												end
											end

											if v43 then
												for i, v in nextEntry, v43 do
													local v45 = v[6]

													if v43 then
														local v46 = v43[i]

														if v46 then
															local v47 = createRegisters(v45)
															moveValues(registers, i, i + v45 - 1, 1, v47)
															v46[5] = v47
															v46[4] = 1
															v43[i] = nil
														end
													end
												end
											end

											return false,
												true,
												packValues(
													registers[captured.opcodes[pc]],
													unpackValues(
														registers[captured.operandB[pc]],
														1,
														registers[captured.operandB[pc]].n
													)
												)
										end

										if v39 ~= 16 and registers[captured.operandA[pc]] >= captured.constantB[pc] then
											pc = captured.opcodes[pc]
										end
									elseif v39 >= 12 then
										if v39 == 13 then
											registers[captured.operandA[pc]] = #registers[captured.opcodes[pc]]
										else
											local v48 = captured.operandB[pc]
											local v49 = captured.constantOpcode[pc]
											local v50 = bitAnd(captured.operandA[pc], 4294967295)
											local v51 = bitAnd(v49, 4294967295)
											local v52 = bitAnd(v50, 65535)
											local v53 = rightShift(v50, 16)
											local v54 = bitAnd(v51, 65535)
											local v55 = rightShift(v51, 16)
											local v56 = bitAnd(
												v52 * v54 + leftShift(bitAnd(v52 * v55 + v53 * v54, 65535), 16),
												4294967295
											) % 4294967296
											registers[v48] = v56 ~= v56 and 0 or v56 - v56 % 1
										end
									else
										v36 = captured.opcodes[pc]
										v34, v32 = u8()

										if v34 then
											registers[v36] = v32
											pc = captured.operandA[pc]
										else
											pc = captured.operandB[pc]
										end
									end
								elseif v39 < 20 then
									if v39 < 18 then
										registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
											- registers[captured.opcodes[pc]]
									elseif v39 == 19 then
										registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
											~= registers[captured.operandB[pc]]
									else
										v36 = captured.opcodes[pc]
										v34 = captured.operandA[pc]
										v32 = captured.operandB[pc]
										v35 = v36 + v34
										registers[v36] =
											packValues(registers[v36](unpackValues(registers, v36 + 1, v35)))
									end
								elseif v39 >= 21 then
									if v39 == 22 then
										registers[captured.operandA[pc]] = {}
									else
										local v57 = captured.operandB[pc]
										local v58 = registers[captured.operandA[pc]]
										local v59 = bitAnd(captured.constantOpcode[pc], 4294967295)
										local v60 = bitAnd(v58, 4294967295)
										local v61 = bitAnd(v59, 65535)
										local v62 = rightShift(v59, 16)
										local v63 = bitAnd(v60, 65535)
										local v64 = rightShift(v60, 16)
										local v65 = bitAnd(
											v61 * v63 + leftShift(bitAnd(v61 * v64 + v62 * v63, 65535), 16),
											4294967295
										) % 4294967296
										registers[v57] = v65 ~= v65 and 0 or v65 - v65 % 1
									end
								else
									v36 = captured.opcodes[pc]
									v34 = bitXor(
										seedA,
										bitAnd(rightShift(seedA, 14), 262143),
										(bitAnd(rightShift(seedA, 28), 15))
									)
									v32 = captured.operandB[pc]
									v35 = captured.operandA[pc]
									v33 = v32 < 2097152 and 7 or 14
									v37 = bitAnd(v32, leftShift(1, v33) - 1)
									captured.operandC[pc] =
										bitXor(rightShift(v32, v33), 55, (bitAnd(rightShift(v34, 21), 127)))
									captured.opcodes[pc] = bitXor(v36, 33, (bitAnd(v34, 127)))
									captured.operandA[pc] = bitXor(v35, 2, (bitAnd(rightShift(v34, 7), 127)))
									captured.operandB[pc] = bitXor(v37, 53, (bitAnd(rightShift(v34, 14), 127)))
									pc = pc - 1
								end
							elseif v39 >= 35 then
								if v39 >= 41 then
									if v39 < 44 then
										if v39 < 42 then
											environment[captured.constantA[pc]][captured.constantB[pc]] =
												captured.constantOpcode[pc]
										elseif v39 == 43 then
											local v66 = captured.opcodes[pc]
											local v67 = registers[captured.operandA[pc]]
											local v68 = bitAnd(registers[captured.operandB[pc]], 4294967295)
											local v69 = bitAnd(v67, 4294967295)
											local v70 = bitAnd(v68, 65535)
											local v71 = rightShift(v68, 16)
											local v72 = bitAnd(v69, 65535)
											local v73 = rightShift(v69, 16)
											local v74 = bitAnd(
												v70 * v72 + leftShift(bitAnd(v70 * v73 + v71 * v72, 65535), 16),
												4294967295
											) % 4294967296
											registers[v66] = v74 ~= v74 and 0 or v74 - v74 % 1
										else
											registers[captured.operandB[pc]] = bitAnd(
												registers[captured.opcodes[pc]],
												registers[captured.operandA[pc]]
											)
										end
									else
										if v39 < 45 then
											local v75 = u12
											local v76 = u13

											if v75 then
												for i in nextEntry, v75 do
													local v77 = v75[i]

													if v77 then
														v77[5] = v77
														v77[6] = registers[i]
														v77[4] = 6
														v75[i] = nil
													end
												end
											end

											if v76 then
												for i, v in nextEntry, v76 do
													local v78 = v[6]

													if v76 then
														local v79 = v76[i]

														if v79 then
															local v80 = createRegisters(v78)
															moveValues(registers, i, i + v78 - 1, 1, v80)
															v79[5] = v80
															v79[4] = 1
															v76[i] = nil
														end
													end
												end
											end

											return false, true, packValues(registers[captured.operandB[pc]])
										end

										if v39 == 46 then
											registers[captured.opcodes[pc]]()
										else
											registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
												~= captured.opcodes[pc]
										end
									end
								elseif v39 < 38 then
									if v39 < 36 then
										registers[captured.operandA[pc]] =
											bitAnd(registers[captured.opcodes[pc]], captured.operandB[pc])
									elseif v39 == 37 then
										if u12 then
											local v81 = u12
											local v82 = captured.operandB[pc]
											local v83 = v81[v82]

											if v83 then
												v83[5] = v83
												v83[6] = registers[v82]
												v83[4] = 6
												v81[v82] = nil
											end

											local v84 = u12
											local v85 = captured.opcodes[pc]
											local v86 = v84[v85]

											if v86 then
												v86[5] = v86
												v86[6] = registers[v85]
												v86[4] = 6
												v84[v85] = nil
											end

											local v87 = u12
											local v88 = captured.operandA[pc]
											local v89 = v87[v88]

											if v89 then
												v89[5] = v89
												v89[6] = registers[v88]
												v89[4] = 6
												v87[v88] = nil
											end
										end
									else
										registers[captured.operandB[pc]] =
											registers[captured.operandA[pc]][captured.constantOpcode[pc]]
									end
								elseif v39 < 39 then
									v36 = captured.operandA[pc]
									v34 = captured.operandB[pc]
									v32 = captured.opcodes[pc]
									v35 = registers[v36]
									moveValues(registers, v36 + 1, v36 + v34, v32 + 1, v35)
								elseif v39 == 40 then
									registers[captured.opcodes[pc]] =
										captured.capturedValues[captured.operandB[pc]][registers[captured.operandA[pc]]]
								else
									registers[captured.operandA[pc]] =
										bitXor(registers[captured.operandB[pc]], captured.constantOpcode[pc])
								end
							elseif v39 >= 29 then
								if v39 >= 32 then
									if v39 < 33 then
										registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
											// captured.operandB[pc]
									elseif v39 == 34 then
										v36 = captured.operandA[pc]
										v34, v32, v35 = u8()

										if v34 then
											registers[v36] = v32
											registers[v36 + 1] = v35
											pc = captured.opcodes[pc]
										else
											pc = captured.operandB[pc]
										end
									else
										registers[captured.operandA[pc]][captured.constantB[pc]] =
											registers[captured.opcodes[pc]]
									end
								else
									if v39 >= 30 then
										if v39 ~= 31 then
											local v90 = u12
											local v91 = u13

											if v90 then
												for i in nextEntry, v90 do
													local v92 = v90[i]

													if v92 then
														v92[5] = v92
														v92[6] = registers[i]
														v92[4] = 6
														v90[i] = nil
													end
												end
											end

											if v91 then
												for i, v in nextEntry, v91 do
													local v93 = v[6]

													if v91 then
														local v94 = v91[i]

														if v94 then
															local v95 = createRegisters(v93)
															moveValues(registers, i, i + v93 - 1, 1, v95)
															v94[5] = v95
															v94[4] = 1
															v91[i] = nil
														end
													end
												end
											end

											return false, false
										end

										local v96 = captured.operandA[pc]
										local v97 = captured.operandB[pc]
										local v98 = v96 + v97
										local v99 = registers[v98]
										local n = v99.n
										local v100 = u12
										local v101 = u13

										if v100 then
											for i in nextEntry, v100 do
												local v102 = v100[i]

												if v102 then
													v102[5] = v102
													v102[6] = registers[i]
													v102[4] = 6
													v100[i] = nil
												end
											end
										end

										if v101 then
											for i, v in nextEntry, v101 do
												local v103 = v[6]

												if v101 then
													local v104 = v101[i]

													if v104 then
														local v105 = createRegisters(v103)
														moveValues(registers, i, i + v103 - 1, 1, v105)
														v104[5] = v105
														v104[4] = 1
														v101[i] = nil
													end
												end
											end
										end

										v99.n = v97 + n - 1
										moveValues(v99, 1, n, v97, v99)
										moveValues(registers, v96 + 1, v98 - 1, 1, v99)

										return true, true, v96, v99
									end

									registers[captured.opcodes[pc]] =
										bitXor(registers[captured.operandB[pc]], captured.operandA[pc])
								end
							elseif v39 < 26 then
								if v39 < 24 then
									seedB = registers[captured.operandB[pc]]
								elseif v39 == 25 then
									captured.capturedValues[captured.operandA[pc]][captured.constantB[pc]] =
										captured.constantOpcode[pc]
								else
									environment[captured.constantB[pc]] = captured.constantA[pc]
								end
							elseif v39 < 27 then
								local v106 = nil
								local v107 = captured.operandA[pc]
								local v108 = captured.constantB[pc]
								local v109 = captured.constantOpcode[pc]
								local v110 = u12
								local v111 = u13
								local v112 = v109[0]

								if v112 then
									local v113 = #v112 / 3

									if v113 > 0 then
										v106 = {}

										for i = 1, v113 do
											local v114 = (i - 1) * 3
											local v115 = v112[v114 + 2]
											local v116 = v112[v114 + 1]
											local v117

											if v115 == 2 then
												v110 = v110 or {}
												local v118 = v110[v116]

												if not v118 then
													v118 = {
														[5] = registers,
														[4] = v116,
													}
													v110[v116] = v118
												end

												v106[i] = v118
												v117 = i
											elseif v115 == 0 then
												v106[i] = registers[v116]
												v117 = i
											elseif v115 == 3 then
												v106[i] = captured.capturedValues[v116]
												v117 = i
											elseif v115 == 1 then
												v111 = v111 or {}
												local v119 = v111[v116]

												if not v119 then
													v119 = {
														[5] = registers,
														[4] = v116,
														[6] = v112[v114 + 3],
													}
													v111[v116] = v119
												end

												v106[i] = v119
												v117 = i
											else
												v117 = i
											end
										end
									end
								end

								local v120 = v109[-2]
								v109[v120] = v106
								local v121 = v108(unpackValues(v109, 1, v109[-1]))
								v109[v120] = nil
								registers[v107] = v121
								u12 = v110
								u13 = v111
							elseif v39 == 28 then
								v36 = captured.operandA[pc]
								v34 = captured.opcodes[pc]
								v32 = captured.operandB[pc]
								v35 = registers[v36]
								v33 = v36 + v34
								v37 = registers[v33]
								moveValues(registers, v36 + 1, v33 - 1, v32 + 1, v35)
								moveValues(v37, 1, v37.n, v32 + v34, v35)
							else
								registers[captured.opcodes[pc]] =
									bitOr(registers[captured.operandA[pc]], captured.constantB[pc])
							end
						elseif v39 < 71 then
							if v39 < 59 then
								if v39 >= 53 then
									if v39 < 56 then
										if v39 < 54 then
											registers[captured.operandB[pc]](captured.constantOpcode[pc])
										elseif v39 == 55 then
											if registers[captured.operandB[pc]] >= captured.operandA[pc] then
												pc = captured.opcodes[pc]
											end
										else
											v36 = captured.operandB[pc] + 1
											v34 = captured.operandA[pc]

											for i = 1, captured.opcodes[pc] do
												local v122 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
												local v123 = bitXor(v122, (rightShift(v122, 13)))
												v34 = bitAnd(bitXor(v123, (leftShift(v123, 14))), 536870911)
												captured.opcodes[v36] =
													bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
												captured.operandA[v36] =
													bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
												captured.operandB[v36] =
													bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 14), 127)))
												captured.operandC[v36] =
													bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 21), 127)))
												v36 = v36 + 1
												local _ = i
											end

											captured.operandC[pc] = 16
										end
									elseif v39 < 57 then
										registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
											- captured.constantA[pc]
									elseif v39 == 58 then
										registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
											/ captured.operandB[pc]
									else
										registers[captured.operandB[pc]] = seedB
									end
								elseif v39 >= 50 then
									if v39 < 51 then
										local v124 = u12
										local v125 = u13

										if v124 then
											for i in nextEntry, v124 do
												local v126 = v124[i]

												if v126 then
													v126[5] = v126
													v126[6] = registers[i]
													v126[4] = 6
													v124[i] = nil
												end
											end
										end

										if v125 then
											for i, v in nextEntry, v125 do
												local v127 = v[6]

												if v125 then
													local v128 = v125[i]

													if v128 then
														local v129 = createRegisters(v127)
														moveValues(registers, i, i + v127 - 1, 1, v129)
														v128[5] = v129
														v128[4] = 1
														v125[i] = nil
													end
												end
											end
										end

										return false,
											true,
											packValues(
												captured.constantB[pc],
												unpackValues(
													registers[captured.opcodes[pc]],
													1,
													registers[captured.opcodes[pc]].n
												)
											)
									end

									if v39 == 52 then
										if registers[captured.opcodes[pc]] > registers[captured.operandB[pc]] then
											pc = captured.operandA[pc]
										end
									else
										registers[captured.opcodes[pc]](
											registers[captured.operandA[pc]],
											registers[captured.operandB[pc]]
										)
									end
								elseif v39 >= 48 then
									if v39 == 49 then
										registers[captured.operandA[pc]] = captured.constantOpcode[pc]
											+ registers[captured.operandB[pc]]
									else
										registers[captured.operandA[pc]](registers[captured.operandB[pc]])
									end
								else
									v36 = captured.opcodes[pc]
									v34 = captured.operandA[pc]
									v32 = captured.operandB[pc]
									v35 = v36 + v34
									v33 = registers[v35]
									v37 = v33.n
									v33.n = v34 + v37 - 1
									moveValues(v33, 1, v37, v34, v33)
									moveValues(registers, v36 + 1, v35 - 1, 1, v33)
									registers[v36] = packValues(registers[v36](unpackValues(v33, 1, v33.n)))
								end
							elseif v39 < 65 then
								if v39 < 62 then
									if v39 >= 60 then
										if v39 == 61 then
											registers[captured.operandA[pc]] =
												registers[captured.opcodes[pc]][registers[captured.operandB[pc]]]
										else
											pc = registers[captured.operandB[pc]]
										end
									else
										registers[captured.operandA[pc]] = captured.constantOpcode[pc]
											.. registers[captured.operandB[pc]]
									end
								else
									if v39 < 63 then
										local v130 = u12
										local v131 = u13

										if v130 then
											for i in nextEntry, v130 do
												local v132 = v130[i]

												if v132 then
													v132[5] = v132
													v132[6] = registers[i]
													v132[4] = 6
													v130[i] = nil
												end
											end
										end

										if v131 then
											for i, v in nextEntry, v131 do
												local v133 = v[6]

												if v131 then
													local v134 = v131[i]

													if v134 then
														local v135 = createRegisters(v133)
														moveValues(registers, i, i + v133 - 1, 1, v135)
														v134[5] = v135
														v134[4] = 1
														v131[i] = nil
													end
												end
											end
										end

										return false, true, registers[captured.operandB[pc]]
									end

									if v39 == 64 then
										v36 = registers[captured.operandB[pc]]
										registers[captured.opcodes[pc]] =
											packValues(unpackValues(v36, captured.operandA[pc], v36.n))
									else
										registers[captured.opcodes[pc]] = captured.operandB[pc]
											- registers[captured.operandA[pc]]
									end
								end
							elseif v39 >= 68 then
								if v39 < 69 then
									local v136 = u12
									local v137 = u13

									if v136 then
										for i in nextEntry, v136 do
											local v138 = v136[i]

											if v138 then
												v138[5] = v138
												v138[6] = registers[i]
												v138[4] = 6
												v136[i] = nil
											end
										end
									end

									if v137 then
										for i, v in nextEntry, v137 do
											local v139 = v[6]

											if v137 then
												local v140 = v137[i]

												if v140 then
													local v141 = createRegisters(v139)
													moveValues(registers, i, i + v139 - 1, 1, v141)
													v140[5] = v141
													v140[4] = 1
													v137[i] = nil
												end
											end
										end
									end

									return true,
										true,
										captured.operandA[pc],
										packValues(registers[captured.opcodes[pc]])
								end

								if v39 ~= 70 then
									local v142 = u12
									local v143 = u13

									if v142 then
										for i in nextEntry, v142 do
											local v144 = v142[i]

											if v144 then
												v144[5] = v144
												v144[6] = registers[i]
												v144[4] = 6
												v142[i] = nil
											end
										end
									end

									if v143 then
										for i, v in nextEntry, v143 do
											local v145 = v[6]

											if v143 then
												local v146 = v143[i]

												if v146 then
													local v147 = createRegisters(v145)
													moveValues(registers, i, i + v145 - 1, 1, v147)
													v146[5] = v147
													v146[4] = 1
													v143[i] = nil
												end
											end
										end
									end

									return true,
										true,
										captured.operandB[pc],
										packValues(registers[captured.operandA[pc]], registers[captured.opcodes[pc]])
								end

								captured.capturedValues[captured.operandA[pc]][registers[captured.operandB[pc]]] =
									captured.constantOpcode[pc]
							elseif v39 >= 66 then
								if v39 == 67 then
									registers[captured.opcodes[pc]](captured.constantB[pc], captured.constantA[pc])
								else
									registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
										== registers[captured.opcodes[pc]]
								end
							else
								v36 = captured.operandA[pc]
								v34 = bitXor(
									seedA,
									bitAnd(rightShift(seedA, 14), 262143),
									(bitAnd(rightShift(seedA, 28), 15))
								)
								v32 = captured.opcodes[pc]
								v35 = captured.operandB[pc]
								v33 = v36 < 16384 and 7 or (v36 < 2097152 and 14 or 21)
								v37 = bitAnd(v36, leftShift(1, v33) - 1)
								local v148 = rightShift(v36, v33)
								captured.operandB[pc] = bitXor(v35, 116, (bitAnd(rightShift(v34, 14), 127)))
								captured.opcodes[pc] = bitXor(v32, 74, (bitAnd(v34, 127)))
								captured.operandA[pc] = bitXor(v37, 92, (bitAnd(rightShift(v34, 7), 127)))
								captured.operandC[pc] = bitXor(v148, 66, (bitAnd(rightShift(v34, 21), 127)))
								pc = pc - 1
							end
						elseif v39 < 83 then
							if v39 >= 77 then
								if v39 < 80 then
									if v39 < 78 then
										registers[captured.operandB[pc]] = environment[captured.constantOpcode[pc]]
									elseif v39 == 79 then
										v36 = captured.operandA[pc]
										local v149 = registers[captured.opcodes[pc]]
										registers[v36] = captured.constantB[pc]
										registers[v36 + 1] = v149
									else
										registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
											% registers[captured.opcodes[pc]]
									end
								elseif v39 < 81 then
									registers[captured.opcodes[pc]] = -registers[captured.operandA[pc]]
								elseif v39 == 82 then
									registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
										> captured.operandB[pc]
								else
									registers[captured.operandA[pc]][registers[captured.opcodes[pc]]] =
										registers[captured.operandB[pc]]
								end
							elseif v39 < 74 then
								if v39 < 72 then
									registers[captured.operandB[pc]] =
										rightShift(registers[captured.operandA[pc]], captured.opcodes[pc])
								elseif v39 == 73 then
									registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
										> captured.constantOpcode[pc]
								else
									registers[captured.operandB[pc]] = registers[captured.opcodes[pc]]
										* captured.constantA[pc]
								end
							elseif v39 < 75 then
								registers[captured.operandB[pc]] = registers[captured.opcodes[pc]]
									.. captured.constantA[pc]
							else
								if v39 ~= 76 then
									local v150 = u12
									local v151 = u13

									if v150 then
										for i in nextEntry, v150 do
											local v152 = v150[i]

											if v152 then
												v152[5] = v152
												v152[6] = registers[i]
												v152[4] = 6
												v150[i] = nil
											end
										end
									end

									if v151 then
										for i, v in nextEntry, v151 do
											local v153 = v[6]

											if v151 then
												local v154 = v151[i]

												if v154 then
													local v155 = createRegisters(v153)
													moveValues(registers, i, i + v153 - 1, 1, v155)
													v154[5] = v155
													v154[4] = 1
													v151[i] = nil
												end
											end
										end
									end

									return false,
										true,
										packValues(registers[captured.opcodes[pc]], captured.constantA[pc])
								end

								registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
									+ registers[captured.operandA[pc]]
							end
						elseif v39 >= 89 then
							if v39 >= 92 then
								if v39 < 93 then
									registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
										+ captured.constantB[pc]
								elseif v39 == 94 then
									v36 = captured.opcodes[pc]
									local v156 = registers[captured.operandB[pc]]
									registers[v36] = captured.operandA[pc]
									registers[v36 + 1] = v156
								else
									local v157

									if registers[captured.opcodes[pc]] then
										v157 = captured.operandB[pc]
									else
										v157 = captured.operandA[pc]
									end

									pc = v157
								end
							elseif v39 >= 90 then
								if v39 == 91 then
									local v158 = u12
									local v159 = u13

									if v158 then
										for i in nextEntry, v158 do
											local v160 = v158[i]

											if v160 then
												v160[5] = v160
												v160[6] = registers[i]
												v160[4] = 6
												v158[i] = nil
											end
										end
									end

									if v159 then
										for i, v in nextEntry, v159 do
											local v161 = v[6]

											if v159 then
												local v162 = v159[i]

												if v162 then
													local v163 = createRegisters(v161)
													moveValues(registers, i, i + v161 - 1, 1, v163)
													v162[5] = v163
													v162[4] = 1
													v159[i] = nil
												end
											end
										end
									end

									return true, true, captured.opcodes[pc], registers[captured.operandA[pc]]
								end

								registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
									% captured.constantA[pc]
							else
								v36 = captured.opcodes[pc]
								local v164 = captured.operandB[pc]
								registers[v36] = captured.operandA[pc]
								registers[v36 + 1] = v164
							end
						elseif v39 < 86 then
							if v39 < 84 then
								local v165 = u12
								local v166 = u13

								if v165 then
									for i in nextEntry, v165 do
										local v167 = v165[i]

										if v167 then
											v167[5] = v167
											v167[6] = registers[i]
											v167[4] = 6
											v165[i] = nil
										end
									end
								end

								if v166 then
									for i, v in nextEntry, v166 do
										local v168 = v[6]

										if v166 then
											local v169 = v166[i]

											if v169 then
												local v170 = createRegisters(v168)
												moveValues(registers, i, i + v168 - 1, 1, v170)
												v169[5] = v170
												v169[4] = 1
												v166[i] = nil
											end
										end
									end
								end

								return false, true, packValues(captured.constantOpcode[pc])
							end

							if v39 == 85 then
								v36 = captured.operandA[pc]
								local v171 = captured.opcodes[pc]
								registers[v36] = registers[captured.operandB[pc]]
								registers[v36 + 1] = v171
							else
								registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
									* captured.operandB[pc]
							end
						elseif v39 >= 87 then
							if v39 == 88 then
								v36 = captured.capturedValues[captured.opcodes[pc]]
								v36[5][v36[4]] = registers[captured.operandB[pc]]
							else
								u8 = u7[8]
								u9 = u7[5]
								u10 = u7[7]
								u11 = u7[6]
								u7 = u7[9]
							end
						else
							registers[captured.opcodes[pc]] = captured.operandB[pc] + registers[captured.operandA[pc]]
						end
					elseif v39 < 142 then
						if v39 < 118 then
							if v39 < 106 then
								if v39 < 100 then
									if v39 >= 97 then
										if v39 >= 98 then
											if v39 == 99 then
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
													% captured.operandB[pc]
											else
												captured.capturedValues[captured.operandA[pc]][captured.constantOpcode[pc]] =
													registers[captured.operandB[pc]]
											end
										else
											registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
												< registers[captured.opcodes[pc]]
										end
									elseif v39 == 96 then
										local v172 = registers[captured.operandA[pc]] % 4294967296
										registers[captured.operandB[pc]] = v172 ~= v172 and 0 or v172 - v172 % 1
									else
										registers[captured.operandB[pc]] =
											leftShift(registers[captured.operandA[pc]], captured.opcodes[pc])
									end
								elseif v39 < 103 then
									if v39 >= 101 then
										if v39 == 102 then
											pc = registers[captured.opcodes[pc]]
										else
											registers[captured.operandB[pc]] = packValues(
												registers[captured.operandA[pc]](captured.constantOpcode[pc])
											)
										end
									else
										local v173 = captured.opcodes[pc]
										local v174 = captured.operandA[pc]
										local v175, v176 = registers[captured.operandB[pc]]()
										registers[v173] = v175
										registers[v174] = v176
									end
								elseif v39 < 104 then
									registers[captured.opcodes[pc]](
										registers[captured.operandA[pc]],
										unpackValues(
											registers[captured.operandB[pc]],
											1,
											registers[captured.operandB[pc]].n
										)
									)
								elseif v39 == 105 then
									registers[captured.operandA[pc]][captured.constantOpcode[pc]] =
										captured.operandB[pc]
								else
									v36 = captured.capturedValues[captured.operandA[pc]]
									v36[5][v36[4]][captured.constantOpcode[pc]] = captured.constantB[pc]
								end
							elseif v39 >= 112 then
								if v39 < 115 then
									if v39 < 113 then
										registers[captured.opcodes[pc]] =
											registers[captured.operandA[pc]](captured.constantB[pc])
									else
										if v39 == 114 then
											local v177 = u12
											local v178 = u13

											if v177 then
												for i in nextEntry, v177 do
													local v179 = v177[i]

													if v179 then
														v179[5] = v179
														v179[6] = registers[i]
														v179[4] = 6
														v177[i] = nil
													end
												end
											end

											if v178 then
												for i, v in nextEntry, v178 do
													local v180 = v[6]

													if v178 then
														local v181 = v178[i]

														if v181 then
															local v182 = createRegisters(v180)
															moveValues(registers, i, i + v180 - 1, 1, v182)
															v181[5] = v182
															v181[4] = 1
															v178[i] = nil
														end
													end
												end
											end

											return true, true, captured.operandB[pc], packValues()
										end

										v36 = captured.opcodes[pc]
										local v183 = captured.constantB[pc]
										registers[v36] = captured.operandA[pc]
										registers[v36 + 1] = v183
									end
								elseif v39 >= 116 then
									if v39 == 117 then
										registers[captured.operandA[pc]][captured.operandB[pc]] =
											registers[captured.opcodes[pc]]
									else
										registers[captured.operandB[pc]] = bitNot(registers[captured.opcodes[pc]])
									end
								else
									registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
								end
							elseif v39 < 109 then
								if v39 >= 107 then
									if v39 ~= 108 then
										local v184 = u12
										local v185 = u13

										if v184 then
											for i in nextEntry, v184 do
												local v186 = v184[i]

												if v186 then
													v186[5] = v186
													v186[6] = registers[i]
													v186[4] = 6
													v184[i] = nil
												end
											end
										end

										if v185 then
											for i, v in nextEntry, v185 do
												local v187 = v[6]

												if v185 then
													local v188 = v185[i]

													if v188 then
														local v189 = createRegisters(v187)
														moveValues(registers, i, i + v187 - 1, 1, v189)
														v188[5] = v189
														v188[4] = 1
														v185[i] = nil
													end
												end
											end
										end

										return true,
											true,
											captured.operandB[pc],
											packValues(registers[captured.operandA[pc]], captured.constantOpcode[pc])
									end

									u7 = {
										[6] = u11,
										[5] = u9,
										[9] = u7,
										[8] = u8,
										[7] = u10,
									}
									v36 = captured.operandA[pc]
									u10 = registers[v36 + 2] + 0
									u9 = registers[v36 + 1] + 0
									u8 = registers[v36] - u10
									pc = captured.opcodes[pc]
								elseif captured.constantOpcode[pc] >= registers[captured.operandB[pc]] then
									pc = captured.operandA[pc]
								end
							elseif v39 >= 110 then
								if v39 == 111 then
									if registers[captured.operandB[pc]] >= registers[captured.operandA[pc]] then
										pc = captured.opcodes[pc]
									end
								else
									registers[captured.operandB[pc]] =
										registers[captured.operandA[pc]](registers[captured.opcodes[pc]])
								end
							else
								registers[captured.operandA[pc]] = captured.constantB[pc]
									* registers[captured.opcodes[pc]]
							end
						elseif v39 >= 130 then
							if v39 >= 136 then
								if v39 >= 139 then
									if v39 < 140 then
										local v190 = u12
										local v191 = u13

										if v190 then
											for i in nextEntry, v190 do
												local v192 = v190[i]

												if v192 then
													v192[5] = v192
													v192[6] = registers[i]
													v192[4] = 6
													v190[i] = nil
												end
											end
										end

										if v191 then
											for i, v in nextEntry, v191 do
												local v193 = v[6]

												if v191 then
													local v194 = v191[i]

													if v194 then
														local v195 = createRegisters(v193)
														moveValues(registers, i, i + v193 - 1, 1, v195)
														v194[5] = v195
														v194[4] = 1
														v191[i] = nil
													end
												end
											end
										end

										return false,
											true,
											packValues(captured.constantA[pc], captured.constantOpcode[pc])
									end

									if v39 == 141 then
										registers[captured.operandA[pc]] = captured.constantOpcode[pc]
									else
										v36 = captured.opcodes[pc] + 1
										v34 = bitXor(
											captured.operandA[pc],
											(bitAnd(bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))), 536870911))
										)

										for i = 1, captured.operandB[pc] do
											local v196 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
											local v197 = bitXor(v196, (rightShift(v196, 13)))
											v34 = bitAnd(bitXor(v197, (leftShift(v197, 14))), 536870911)
											captured.opcodes[v36] =
												bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
											captured.operandA[v36] =
												bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
											captured.operandB[v36] =
												bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 14), 127)))
											captured.operandC[v36] =
												bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 21), 127)))
											v36 = v36 + 1
											local _ = i
										end

										captured.operandC[pc] = 16
									end
								elseif v39 < 137 then
									registers[captured.operandA[pc]] =
										registers[captured.opcodes[pc]][captured.operandB[pc]]
								elseif v39 == 138 then
									v36 = captured.capturedValues[captured.operandB[pc]]
									v36[5][v36[4]] = captured.constantOpcode[pc]
								else
									captured.capturedValues[captured.opcodes[pc]][captured.constantB[pc]] =
										captured.operandA[pc]
								end
							elseif v39 < 133 then
								if v39 < 131 then
									registers[captured.opcodes[pc]](
										unpackValues(
											registers[captured.operandB[pc]],
											1,
											registers[captured.operandB[pc]].n
										)
									)
								else
									if v39 == 132 then
										local v198 = u12
										local v199 = u13

										if v198 then
											for i in nextEntry, v198 do
												local v200 = v198[i]

												if v200 then
													v200[5] = v200
													v200[6] = registers[i]
													v200[4] = 6
													v198[i] = nil
												end
											end
										end

										if v199 then
											for i, v in nextEntry, v199 do
												local v201 = v[6]

												if v199 then
													local v202 = v199[i]

													if v202 then
														local v203 = createRegisters(v201)
														moveValues(registers, i, i + v201 - 1, 1, v203)
														v202[5] = v203
														v202[4] = 1
														v199[i] = nil
													end
												end
											end
										end

										return true,
											true,
											captured.opcodes[pc],
											packValues(captured.constantB[pc], registers[captured.operandA[pc]])
									end

									registers[captured.operandB[pc]] =
										environment[captured.constantOpcode[pc]][registers[captured.operandA[pc]]]
								end
							elseif v39 >= 134 then
								if v39 == 135 then
									registers[captured.operandB[pc]] = packValues(registers[captured.opcodes[pc]]())
								else
									registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]()
								end
							else
								registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
									* registers[captured.operandB[pc]]
							end
						elseif v39 < 124 then
							if v39 >= 121 then
								if v39 < 122 then
									registers[captured.opcodes[pc]] = captured.operandB[pc]
										^ registers[captured.operandA[pc]]
								elseif v39 == 123 then
									registers[captured.opcodes[pc]] =
										captured.capturedValues[captured.operandA[pc]][captured.constantB[pc]]
								else
									local v204 = captured.operandA[pc]
									local v205 = captured.operandB[pc]
									local v206 = captured.constantState[5]
									local v207 = bitXor(v206[v204], 109162203)
									v206[v204] = v207
									local v208 = captured.constantState[4]
									local v209 = v207 + 1
									local v210 = readByte(v208, v209)
									local v211

									if v210 < 128 then
										v211 = v209 + 1
									else
										local v212 = readByte(v208, v209 + 1)

										if v212 < 128 then
											v210 = v210 - 128 + v212 * 128
											v211 = v209 + 2
										else
											local v213 = readByte(v208, v209 + 2)

											if v213 < 128 then
												v210 = v210 - 128 + (v212 - 128) * 16384 + v213 * 128
												v211 = v209 + 3
											else
												local v214 = readByte(v208, v209 + 3)
												v210 = (v210 - 128) * 16384
													+ (v212 - 128) * 128
													+ (v213 - 128)
													+ v214 % 128 * 2097152
													+ (v214 - v214 % 128) * 2097152
												v211 = v209 + 4
											end
										end
									end

									local v215 = v205 * 16843009
									local v216 = v211 + v210
									local v217 = v216 - v210 % 4

									for i = v211, v217 - 1, 4 do
										writeUInt32(v208, i, (bitXor(readUInt32(v208, i), v215)))
										local _ = i
									end

									for i = v217, v216 - 1 do
										writeByte(v208, i, (bitXor(readByte(v208, i), v205)))
										local _ = i
									end

									captured.operandA[pc] = 229
									captured.operandB[pc] = 199
									captured.opcodes[pc] = 60
									captured.operandC[pc] = 16
								end
							elseif v39 >= 119 then
								if v39 == 120 then
									captured.capturedValues[captured.operandA[pc]][registers[captured.operandB[pc]]] =
										registers[captured.opcodes[pc]]
								else
									registers[captured.operandA[pc]] =
										bitOr(registers[captured.opcodes[pc]], registers[captured.operandB[pc]])
								end
							else
								pc = captured.opcodes[pc]
							end
						elseif v39 >= 127 then
							if v39 < 128 then
								registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
									.. registers[captured.opcodes[pc]]
							elseif v39 == 129 then
								registers[captured.operandB[pc]] = captured.capturedValues[captured.operandA[pc]]
							else
								local v218

								if registers[captured.operandA[pc]] then
									v218 = captured.operandB[pc]
								else
									v218 = captured.opcodes[pc]
								end

								pc = v218
							end
						elseif v39 < 125 then
							registers[captured.operandB[pc]] = seedA
						elseif v39 == 126 then
							registers[captured.operandA[pc]] = registers[captured.opcodes[pc]](
								unpackValues(registers[captured.operandB[pc]], 1, registers[captured.operandB[pc]].n)
							)
						else
							registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
								/ captured.constantOpcode[pc]
						end
					elseif v39 < 166 then
						if v39 < 154 then
							if v39 < 148 then
								if v39 >= 145 then
									if v39 < 146 then
										registers[captured.operandB[pc]] =
											bitXor(registers[captured.operandA[pc]], registers[captured.opcodes[pc]])
									elseif v39 == 147 then
										registers[captured.operandB[pc]](
											captured.constantOpcode[pc],
											registers[captured.operandA[pc]]
										)
									else
										registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
											>= captured.operandA[pc]
									end
								elseif v39 >= 143 then
									if v39 == 144 then
										v36 = captured.opcodes[pc]
										v34 = registers[captured.operandB[pc]]
										registers[v36 + 1] = v34
										registers[v36] = v34[captured.constantA[pc]]
									else
										v36 = captured.capturedValues[captured.operandA[pc]]
										registers[captured.opcodes[pc]] = v36[5][v36[4]][captured.constantB[pc]]
									end
								else
									registers[captured.opcodes[pc]] = registers
								end
							elseif v39 >= 151 then
								if v39 >= 152 then
									if v39 == 153 then
										registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
											== captured.operandA[pc]
									else
										v36 = captured.capturedValues[captured.operandB[pc]]
										registers[captured.operandA[pc]] = v36[5][v36[4]]
									end
								else
									registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
										/ registers[captured.opcodes[pc]]
								end
							elseif v39 >= 149 then
								if v39 ~= 150 then
									local v219 = captured.operandB[pc]
									local v220 = v219 + captured.opcodes[pc]
									local v221 = u12
									local v222 = u13

									if v221 then
										for i in nextEntry, v221 do
											local v223 = v221[i]

											if v223 then
												v223[5] = v223
												v223[6] = registers[i]
												v223[4] = 6
												v221[i] = nil
											end
										end
									end

									if v222 then
										for i, v in nextEntry, v222 do
											local v224 = v[6]

											if v222 then
												local v225 = v222[i]

												if v225 then
													local v226 = createRegisters(v224)
													moveValues(registers, i, i + v224 - 1, 1, v226)
													v225[5] = v226
													v225[4] = 1
													v222[i] = nil
												end
											end
										end
									end

									return true, false, v219, v220
								end

								u7 = {
									[6] = u11,
									[5] = u9,
									[9] = u7,
									[8] = u8,
									[7] = u10,
								}
								v36 = captured.operandA[pc]
								v34 = wrapCoroutine(closeUpvalues)
								v34(captured.runtime, registers[v36], registers[v36 + 1], registers[v36 + 2])
								u8 = v34
								u11 = captured.operandB[pc]
								pc = captured.opcodes[pc]
							else
								local v227 = captured.opcodes[pc]
								local v228 = bitXor(
									captured.operandA[pc],
									(bitAnd(bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))), 536870911))
								)
								local v229 = captured.constantState[5]
								local v230 = bitXor(v229[v227], 109162203)
								v229[v227] = v230
								local v231 = captured.constantState[4]
								local v232 = v230 + 1
								local v233 = readByte(v231, v232)
								local v234

								if v233 < 128 then
									v234 = v232 + 1
								else
									local v235 = readByte(v231, v232 + 1)

									if v235 < 128 then
										v233 = v233 - 128 + v235 * 128
										v234 = v232 + 2
									else
										local v236 = readByte(v231, v232 + 2)

										if v236 < 128 then
											v233 = v233 - 128 + (v235 - 128) * 16384 + v236 * 128
											v234 = v232 + 3
										else
											local v237 = readByte(v231, v232 + 3)
											v233 = (v233 - 128) * 16384
												+ (v235 - 128) * 128
												+ (v236 - 128)
												+ v237 % 128 * 2097152
												+ (v237 - v237 % 128) * 2097152
											v234 = v232 + 4
										end
									end
								end

								local v238 = v228 * 16843009
								local v239 = v234 + v233
								local v240 = v239 - v233 % 4

								for i = v234, v240 - 1, 4 do
									writeUInt32(v231, i, (bitXor(readUInt32(v231, i), v238)))
									local _ = i
								end

								for i = v240, v239 - 1 do
									writeByte(v231, i, (bitXor(readByte(v231, i), v228)))
									local _ = i
								end

								captured.opcodes[pc] = 113
								captured.operandA[pc] = 125
								captured.operandB[pc] = 38
								captured.operandC[pc] = 16
							end
						elseif v39 < 160 then
							if v39 < 157 then
								if v39 >= 155 then
									if v39 == 156 then
										local v241 = captured.operandA[pc]
										local v242 = captured.constantOpcode[pc]
										local v243 = bitAnd(captured.constantB[pc], 4294967295)
										local v244 = bitAnd(v242, 4294967295)
										local v245 = bitAnd(v243, 65535)
										local v246 = rightShift(v243, 16)
										local v247 = bitAnd(v244, 65535)
										local v248 = rightShift(v244, 16)
										local v249 = bitAnd(
											v245 * v247 + leftShift(bitAnd(v245 * v248 + v246 * v247, 65535), 16),
											4294967295
										) % 4294967296
										registers[v241] = v249 ~= v249 and 0 or v249 - v249 % 1
									else
										registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
											- captured.opcodes[pc]
									end
								else
									registers[captured.operandA[pc]] =
										bitAnd(registers[captured.operandB[pc]], captured.constantOpcode[pc])
								end
							elseif v39 >= 158 then
								if v39 == 159 then
									local v250 = u12
									local v251 = u13

									if v250 then
										for i in nextEntry, v250 do
											local v252 = v250[i]

											if v252 then
												v252[5] = v252
												v252[6] = registers[i]
												v252[4] = 6
												v250[i] = nil
											end
										end
									end

									if v251 then
										for i, v in nextEntry, v251 do
											local v253 = v[6]

											if v251 then
												local v254 = v251[i]

												if v254 then
													local v255 = createRegisters(v253)
													moveValues(registers, i, i + v253 - 1, 1, v255)
													v254[5] = v255
													v254[4] = 1
													v251[i] = nil
												end
											end
										end
									end

									local v256 = captured.operandB[pc]
									local v257 = captured.opcodes[pc]
									local v258 = v256 + v257 - 1
									local v259 = registers[v258]
									local n = v259.n
									v259.n = v257 + n - 1
									moveValues(v259, 1, n, v257, v259)
									moveValues(registers, v256, v258 - 1, 1, v259)

									return false, true, v259
								end

								registers[captured.operandA[pc]] = captured.constantB[pc]
									- registers[captured.opcodes[pc]]
							elseif captured.operandB[pc] >= registers[captured.operandA[pc]] then
								pc = captured.opcodes[pc]
							end
						elseif v39 < 163 then
							if v39 >= 161 then
								if v39 ~= 162 then
									local v260 = u12
									local v261 = u13

									if v260 then
										for i in nextEntry, v260 do
											local v262 = v260[i]

											if v262 then
												v262[5] = v262
												v262[6] = registers[i]
												v262[4] = 6
												v260[i] = nil
											end
										end
									end

									if v261 then
										for i, v in nextEntry, v261 do
											local v263 = v[6]

											if v261 then
												local v264 = v261[i]

												if v264 then
													local v265 = createRegisters(v263)
													moveValues(registers, i, i + v263 - 1, 1, v265)
													v264[5] = v265
													v264[4] = 1
													v261[i] = nil
												end
											end
										end
									end

									return false,
										true,
										packValues(
											registers[captured.opcodes[pc]],
											captured.constantB[pc],
											captured.constantA[pc]
										)
								end

								if u12 then
									local v266 = u12
									local v267 = captured.operandB[pc]
									local v268 = v266[v267]

									if v268 then
										v268[5] = v268
										v268[6] = registers[v267]
										v268[4] = 6
										v266[v267] = nil
									end

									local v269 = u12
									local v270 = captured.operandA[pc]
									local v271 = v269[v270]

									if v271 then
										v271[5] = v271
										v271[6] = registers[v270]
										v271[4] = 6
										v269[v270] = nil
									end
								end
							else
								registers[captured.opcodes[pc]] = not registers[captured.operandA[pc]]
							end
						elseif v39 >= 164 then
							if v39 == 165 then
								v36 = captured.opcodes[pc]
								v34 = captured.operandB[pc]
								v32 = captured.operandA[pc]
								v35 = v36 + v32 - 1
								v33 = v36 + v34
								v37 = registers[v33]
								local n = v37.n
								v37.n = v34 + n - 1
								moveValues(v37, 1, n, v34, v37)
								moveValues(registers, v36 + 1, v33 - 1, 1, v37)
								moveValues(
									packValues(registers[v36](unpackValues(v37, 1, v37.n))),
									1,
									v32,
									v36,
									registers
								)
							else
								registers[captured.operandB[pc]][registers[captured.operandA[pc]]] =
									captured.constantOpcode[pc]
							end
						else
							registers[captured.operandA[pc]] =
								environment[captured.constantB[pc]][captured.constantOpcode[pc]]
						end
					elseif v39 >= 178 then
						if v39 >= 184 then
							if v39 >= 187 then
								if v39 < 188 then
									if u12 then
										local v272 = u12
										local v273 = captured.operandA[pc]
										local v274 = v272[v273]

										if v274 then
											v274[5] = v274
											v274[6] = registers[v273]
											v274[4] = 6
											v272[v273] = nil
										end
									end
								elseif v39 == 189 then
									registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
										+ captured.opcodes[pc]
								elseif registers[captured.operandB[pc]] > captured.opcodes[pc] then
									pc = captured.operandA[pc]
								end
							elseif v39 >= 185 then
								if v39 == 186 then
									v36 = captured.capturedValues[captured.opcodes[pc]]
									v36[5][v36[4]][captured.constantA[pc]] = registers[captured.operandB[pc]]
								else
									local v275 = captured.opcodes[pc]
									local v276 = captured.operandA[pc]
									local v277 = bitAnd(registers[captured.operandB[pc]], 4294967295)
									local v278 = bitAnd(v276, 4294967295)
									local v279 = bitAnd(v277, 65535)
									local v280 = rightShift(v277, 16)
									local v281 = bitAnd(v278, 65535)
									local v282 = rightShift(v278, 16)
									local v283 = bitAnd(
										v279 * v281 + leftShift(bitAnd(v279 * v282 + v280 * v281, 65535), 16),
										4294967295
									) % 4294967296
									registers[v275] = v283 ~= v283 and 0 or v283 - v283 % 1
								end
							else
								registers[captured.operandA[pc]] =
									packValues(registers[captured.operandB[pc]](registers[captured.opcodes[pc]]))
							end
						elseif v39 < 181 then
							if v39 < 179 then
								registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
									== captured.constantA[pc]
							elseif v39 == 180 then
								registers[captured.opcodes[pc]][captured.constantA[pc]] = captured.constantB[pc]
							else
								local v284 = captured.opcodes[pc]
								local v285 = bitXor(
									captured.operandA[pc],
									(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
								)
								local v286 = captured.constantState[5]
								local v287 = bitXor(v286[v284], 109162203)
								v286[v284] = v287
								local v288 = captured.constantState[4]
								local v289 = v287 + 1
								local v290 = readByte(v288, v289)
								local v291

								if v290 < 128 then
									v291 = v289 + 1
								else
									local v292 = readByte(v288, v289 + 1)

									if v292 < 128 then
										v290 = v290 - 128 + v292 * 128
										v291 = v289 + 2
									else
										local v293 = readByte(v288, v289 + 2)

										if v293 < 128 then
											v290 = v290 - 128 + (v292 - 128) * 16384 + v293 * 128
											v291 = v289 + 3
										else
											local v294 = readByte(v288, v289 + 3)
											v290 = (v290 - 128) * 16384
												+ (v292 - 128) * 128
												+ (v293 - 128)
												+ v294 % 128 * 2097152
												+ (v294 - v294 % 128) * 2097152
											v291 = v289 + 4
										end
									end
								end

								local v295 = v285 * 16843009
								local v296 = v291 + v290
								local v297 = v296 - v290 % 4

								for i = v291, v297 - 1, 4 do
									writeUInt32(v288, i, (bitXor(readUInt32(v288, i), v295)))
									local _ = i
								end

								for i = v297, v296 - 1 do
									writeByte(v288, i, (bitXor(readByte(v288, i), v285)))
									local _ = i
								end

								captured.opcodes[pc] = 249
								captured.operandA[pc] = 231
								captured.operandB[pc] = 181
								captured.operandC[pc] = 16
							end
						elseif v39 >= 182 then
							if v39 == 183 then
								seedA = registers[captured.opcodes[pc]]
							else
								registers[captured.operandB[pc]] = captured.opcodes[pc]
							end
						elseif registers[captured.opcodes[pc]] ~= captured.constantA[pc] then
							pc = captured.operandB[pc]
						end
					elseif v39 >= 172 then
						if v39 < 175 then
							if v39 < 173 then
								local v298 = u12
								local v299 = u13

								if v298 then
									for i in nextEntry, v298 do
										local v300 = v298[i]

										if v300 then
											v300[5] = v300
											v300[6] = registers[i]
											v300[4] = 6
											v298[i] = nil
										end
									end
								end

								if v299 then
									for i, v in nextEntry, v299 do
										local v301 = v[6]

										if v299 then
											local v302 = v299[i]

											if v302 then
												local v303 = createRegisters(v301)
												moveValues(registers, i, i + v301 - 1, 1, v303)
												v302[5] = v303
												v302[4] = 1
												v299[i] = nil
											end
										end
									end
								end

								return true, true, captured.operandB[pc], packValues(captured.constantOpcode[pc])
							end

							if v39 == 174 then
								local v304 = u12
								local v305 = u13

								if v304 then
									for i in nextEntry, v304 do
										local v306 = v304[i]

										if v306 then
											v306[5] = v306
											v306[6] = registers[i]
											v306[4] = 6
											v304[i] = nil
										end
									end
								end

								if v305 then
									for i, v in nextEntry, v305 do
										local v307 = v[6]

										if v305 then
											local v308 = v305[i]

											if v308 then
												local v309 = createRegisters(v307)
												moveValues(registers, i, i + v307 - 1, 1, v309)
												v308[5] = v309
												v308[4] = 1
												v305[i] = nil
											end
										end
									end
								end

								return false,
									true,
									packValues(captured.constantOpcode[pc], registers[captured.operandA[pc]])
							end

							environment[captured.constantOpcode[pc]] = registers[captured.operandA[pc]]
						elseif v39 < 176 then
							if registers[captured.opcodes[pc]] ~= captured.operandA[pc] then
								pc = captured.operandB[pc]
							end
						else
							if v39 ~= 177 then
								local v310 = u12
								local v311 = u13

								if v310 then
									for i in nextEntry, v310 do
										local v312 = v310[i]

										if v312 then
											v312[5] = v312
											v312[6] = registers[i]
											v312[4] = 6
											v310[i] = nil
										end
									end
								end

								if v311 then
									for i, v in nextEntry, v311 do
										local v313 = v[6]

										if v311 then
											local v314 = v311[i]

											if v314 then
												local v315 = createRegisters(v313)
												moveValues(registers, i, i + v313 - 1, 1, v315)
												v314[5] = v315
												v314[4] = 1
												v311[i] = nil
											end
										end
									end
								end

								return false,
									true,
									packValues(registers[captured.operandB[pc]], registers[captured.operandA[pc]])
							end

							registers[captured.operandA[pc]](registers[captured.opcodes[pc]], captured.constantB[pc])
						end
					elseif v39 >= 169 then
						if v39 >= 170 then
							if v39 ~= 171 then
								local v316 = u12
								local v317 = u13

								if v316 then
									for i in nextEntry, v316 do
										local v318 = v316[i]

										if v318 then
											v318[5] = v318
											v318[6] = registers[i]
											v318[4] = 6
											v316[i] = nil
										end
									end
								end

								if v317 then
									for i, v in nextEntry, v317 do
										local v319 = v[6]

										if v317 then
											local v320 = v317[i]

											if v320 then
												local v321 = createRegisters(v319)
												moveValues(registers, i, i + v319 - 1, 1, v321)
												v320[5] = v321
												v320[4] = 1
												v317[i] = nil
											end
										end
									end
								end

								return true,
									true,
									captured.operandB[pc],
									packValues(
										registers[captured.opcodes[pc]],
										unpackValues(
											registers[captured.operandA[pc]],
											1,
											registers[captured.operandA[pc]].n
										)
									)
							end

							if captured.constantB[pc] > registers[captured.opcodes[pc]] then
								pc = captured.operandA[pc]
							end
						else
							registers[captured.opcodes[pc]] = registers[captured.operandA[pc]] < captured.constantB[pc]
						end
					elseif v39 >= 167 then
						if v39 == 168 then
							v36 = captured.operandA[pc]
							local v322 = captured.constantOpcode[pc]
							registers[v36] = captured.constantB[pc]
							registers[v36 + 1] = v322
						else
							registers[captured.opcodes[pc]] = registers[captured.operandB[pc]] ~= captured.constantA[pc]
						end
					else
						v36 = captured.opcodes[pc] + 1
						v34 = bitXor(
							captured.operandA[pc],
							(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
						)

						for i = 1, captured.operandB[pc] do
							local v323 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
							local v324 = bitXor(v323, (rightShift(v323, 13)))
							v34 = bitAnd(bitXor(v324, (leftShift(v324, 14))), 536870911)
							captured.opcodes[v36] = bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
							captured.operandA[v36] = bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
							captured.operandB[v36] = bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 14), 127)))
							captured.operandC[v36] = bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 21), 127)))
							v36 = v36 + 1
							local _ = i
						end

						captured.operandC[pc] = 16
					end

					pc = pc + 1
				end

				v38 = 4
				continue
			elseif v38 == 4 then
				v38 = -1

				while true do
					local v325 = 0

					while true do
						if v325 == 0 then
							v325 = -1
							local v326 = captured.operandB[pc]

							if v326 < 103 then
								if v326 >= 51 then
									if v326 >= 77 then
										if v326 < 90 then
											if v326 >= 83 then
												if v326 >= 86 then
													if v326 >= 88 then
														if v326 == 89 then
															v36 = captured.capturedValues[captured.operandA[pc]]
															v36[5][v36[4]][captured.constantC[pc]] =
																captured.opcodes[pc]
														else
															local v327 = captured.operandC[pc]
															local v328 = captured.constantOpcode[pc]
															local v329 = bitAnd(captured.constantA[pc], 4294967295)
															local v330 = bitAnd(v328, 4294967295)
															local v331 = bitAnd(v329, 65535)
															local v332 = rightShift(v329, 16)
															local v333 = bitAnd(v330, 65535)
															local v334 = rightShift(v330, 16)
															local v335 = bitAnd(
																v331 * v333
																	+ leftShift(
																		bitAnd(v331 * v334 + v332 * v333, 65535),
																		16
																	),
																4294967295
															) % 4294967296
															registers[v327] = v335 ~= v335 and 0 or v335 - v335 % 1
														end
													elseif v326 == 87 then
														v36 = registers[captured.opcodes[pc]]
														registers[captured.operandA[pc]] =
															packValues(unpackValues(v36, captured.operandC[pc], v36.n))
													else
														registers[captured.opcodes[pc]] = registers[captured.operandC[pc]]
															% captured.operandA[pc]
													end
												elseif v326 >= 84 then
													if v326 == 85 then
														registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
															>= captured.constantOpcode[pc]
													else
														registers[captured.opcodes[pc]] =
															registers[captured.operandA[pc]]
														v36 = captured.operandA[pc + 1]
														v34 = captured.operandC[pc + 1]
														v32 = captured.opcodes[pc + 1]
														v35 = v36 + v32 - 1
														v33 = v36 + v34
														v37 = packValues(
															registers[v36](unpackValues(registers, v36 + 1, v36 + v34))
														)
														moveValues(v37, 1, v32, v36, registers)
														pc = pc + 1
													end
												else
													registers[captured.operandC[pc]] =
														bitAnd(registers[captured.opcodes[pc]], captured.operandA[pc])
												end
											elseif v326 < 80 then
												if v326 < 78 then
													v36 = captured.capturedValues[captured.operandA[pc]]
													v36[5][v36[4]] = captured.constantC[pc]
												elseif v326 == 79 then
													registers[captured.operandC[pc]] = bitOr(
														registers[captured.operandA[pc]],
														captured.constantOpcode[pc]
													)
												else
													registers[captured.opcodes[pc]] =
														registers[captured.operandC[pc]](captured.constantA[pc])
												end
											elseif v326 >= 81 then
												if v326 == 82 then
													local v336 = registers[captured.operandC[pc]] % 4294967296
													registers[captured.opcodes[pc]] = v336 ~= v336 and 0
														or v336 - v336 % 1
												else
													registers[captured.operandA[pc]] = packValues(
														registers[captured.opcodes[pc]](
															registers[captured.operandC[pc]]
														)
													)
												end
											end
										elseif v326 >= 96 then
											if v326 < 99 then
												if v326 >= 97 then
													if v326 == 98 then
														local v337 = u12
														local v338 = u13

														if v337 then
															for i in nextEntry, v337 do
																local v339 = v337[i]

																if v339 then
																	v339[5] = v339
																	v339[6] = registers[i]
																	v339[4] = 6
																	v337[i] = nil
																end
															end
														end

														if v338 then
															for i, v in nextEntry, v338 do
																local v340 = v[6]

																if v338 then
																	local v341 = v338[i]

																	if v341 then
																		local v342 = createRegisters(v340)
																		moveValues(registers, i, i + v340 - 1, 1, v342)
																		v341[5] = v342
																		v341[4] = 1
																		v338[i] = nil
																	end
																end
															end
														end

														return true,
															true,
															captured.operandC[pc],
															packValues(registers[captured.operandA[pc]])
													end

													local v343 = captured.opcodes[pc]
													local v344 = registers[captured.operandA[pc]]
													local v345 = bitAnd(captured.constantC[pc], 4294967295)
													local v346 = bitAnd(v344, 4294967295)
													local v347 = bitAnd(v345, 65535)
													local v348 = rightShift(v345, 16)
													local v349 = bitAnd(v346, 65535)
													local v350 = rightShift(v346, 16)
													local v351 = bitAnd(
														v347 * v349
															+ leftShift(bitAnd(v347 * v350 + v348 * v349, 65535), 16),
														4294967295
													) % 4294967296
													registers[v343] = v351 ~= v351 and 0 or v351 - v351 % 1
												else
													local v352 = captured.operandA[pc]
													local v353 = registers[captured.operandC[pc]]
													local v354 = bitAnd(registers[captured.opcodes[pc]], 4294967295)
													local v355 = bitAnd(v353, 4294967295)
													local v356 = bitAnd(v354, 65535)
													local v357 = rightShift(v354, 16)
													local v358 = bitAnd(v355, 65535)
													local v359 = rightShift(v355, 16)
													local v360 = bitAnd(
														v356 * v358
															+ leftShift(bitAnd(v356 * v359 + v357 * v358, 65535), 16),
														4294967295
													) % 4294967296
													registers[v352] = v360 ~= v360 and 0 or v360 - v360 % 1
												end
											elseif v326 < 101 then
												if v326 == 100 then
													local v361 = u12
													local v362 = u13

													if v361 then
														for i in nextEntry, v361 do
															local v363 = v361[i]

															if v363 then
																v363[5] = v363
																v363[6] = registers[i]
																v363[4] = 6
																v361[i] = nil
															end
														end
													end

													if v362 then
														for i, v in nextEntry, v362 do
															local v364 = v[6]

															if v362 then
																local v365 = v362[i]

																if v365 then
																	local v366 = createRegisters(v364)
																	moveValues(registers, i, i + v364 - 1, 1, v366)
																	v365[5] = v366
																	v365[4] = 1
																	v362[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(
															captured.constantOpcode[pc],
															registers[captured.operandA[pc]]
														)
												end

												registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
													% captured.constantOpcode[pc]
											elseif v326 == 102 then
												registers[captured.operandA[pc]] = captured.constantOpcode[pc]
													* registers[captured.operandC[pc]]
											else
												registers[captured.operandC[pc]] =
													captured.capturedValues[captured.opcodes[pc]][captured.constantA[pc]]
											end
										elseif v326 < 93 then
											if v326 < 91 then
												registers[captured.operandC[pc]] = registers[captured.opcodes[pc]]
													.. captured.constantA[pc]
											elseif v326 == 92 then
												registers[captured.opcodes[pc]] = captured.constantA[pc]
													- registers[captured.operandC[pc]]
											else
												environment[captured.constantA[pc]][captured.constantOpcode[pc]] =
													captured.constantC[pc]
											end
										elseif v326 >= 94 then
											if v326 == 95 then
												v36 = captured.operandA[pc]
												v34, v32, v35 = u8()

												if v34 then
													registers[v36] = v32
													registers[v36 + 1] = v35
													pc = captured.opcodes[pc]
												else
													pc = captured.operandC[pc]
												end
											else
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
													< captured.constantC[pc]
											end
										else
											registers[captured.operandC[pc]] =
												registers[captured.operandA[pc]](registers[captured.opcodes[pc]])
										end
									elseif v326 >= 64 then
										if v326 < 70 then
											if v326 < 67 then
												if v326 >= 65 then
													if v326 == 66 then
														registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
															> captured.opcodes[pc]
													else
														v36 = captured.opcodes[pc] + 1
														v34 = bitXor(
															captured.operandA[pc],
															(
																bitAnd(
																	bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))),
																	536870911
																)
															)
														)

														for i = 1, captured.operandC[pc] do
															local v367 =
																bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
															local v368 = bitXor(v367, (rightShift(v367, 13)))
															v34 = bitAnd(bitXor(v368, (leftShift(v368, 14))), 536870911)
															captured.opcodes[v36] = bitXor(
																captured.opcodes[v36],
																(bitAnd(rightShift(v34, 0), 127))
															)
															captured.operandA[v36] = bitXor(
																captured.operandA[v36],
																(bitAnd(rightShift(v34, 7), 127))
															)
															captured.operandC[v36] = bitXor(
																captured.operandC[v36],
																(bitAnd(rightShift(v34, 14), 127))
															)
															captured.operandB[v36] = bitXor(
																captured.operandB[v36],
																(bitAnd(rightShift(v34, 21), 127))
															)
															v36 = v36 + 1
															local _ = i
														end

														captured.operandB[pc] = 80
													end
												else
													registers[captured.operandC[pc]][captured.constantA[pc]] =
														captured.constantOpcode[pc]
												end
											elseif v326 < 68 then
												v36 = captured.operandA[pc]
												v34 = captured.operandC[pc]
												v32 = captured.opcodes[pc]
												v35 = v36 + v32 - 1
												v33 = v36 + v34
												v37 = registers[v33]
												local n = v37.n
												v37.n = v34 + n - 1
												moveValues(v37, 1, n, v34, v37)
												moveValues(registers, v36 + 1, v33 - 1, 1, v37)
												moveValues(
													packValues(registers[v36](unpackValues(v37, 1, v37.n))),
													1,
													v32,
													v36,
													registers
												)
											elseif v326 == 69 then
												local v369

												if registers[captured.operandA[pc]] then
													v369 = captured.opcodes[pc]
												else
													v369 = captured.operandC[pc]
												end

												pc = v369
											else
												registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
													- captured.opcodes[pc]
											end
										elseif v326 >= 73 then
											if v326 >= 75 then
												if v326 == 76 then
													registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
														>= registers[captured.operandC[pc]]
												else
													registers[captured.operandA[pc]] = {}
												end
											elseif v326 == 74 then
												v36 = captured.operandA[pc]
												local v370 = registers[captured.opcodes[pc]]
												registers[v36] = captured.operandC[pc]
												registers[v36 + 1] = v370
											else
												registers[captured.operandA[pc]] = bitAnd(
													registers[captured.operandC[pc]],
													registers[captured.opcodes[pc]]
												)
											end
										elseif v326 >= 71 then
											if v326 == 72 then
												v36 = captured.capturedValues[captured.operandC[pc]]
												registers[captured.opcodes[pc]] = v36[5][v36[4]][captured.operandA[pc]]
											else
												registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
													+ registers[captured.opcodes[pc]]
											end
										else
											registers[captured.operandA[pc]] = bitNot(registers[captured.operandC[pc]])
										end
									elseif v326 < 57 then
										if v326 >= 54 then
											if v326 >= 55 then
												if v326 == 56 then
													registers[captured.operandC[pc]] =
														registers[captured.opcodes[pc]][registers[captured.operandA[pc]]]
												else
													registers[captured.opcodes[pc]] = captured.operandA[pc]
														^ registers[captured.operandC[pc]]
												end
											else
												captured.capturedValues[captured.operandA[pc]][registers[captured.operandC[pc]]] =
													captured.constantOpcode[pc]
											end
										elseif v326 >= 52 then
											if v326 == 53 then
												registers[captured.operandC[pc]] = bitOr(
													registers[captured.opcodes[pc]],
													registers[captured.operandA[pc]]
												)
											else
												registers[captured.opcodes[pc]] =
													bitAnd(captured.constantA[pc], registers[captured.operandC[pc]])
											end
										else
											v36 = captured.capturedValues[captured.opcodes[pc]]
											registers[captured.operandC[pc]] = v36[5][v36[4]][captured.constantA[pc]]
										end
									elseif v326 < 60 then
										if v326 < 58 then
											registers[captured.operandC[pc]] = captured.operandA[pc]
												+ registers[captured.opcodes[pc]]
										elseif v326 == 59 then
											registers[captured.operandC[pc]] = registers[captured.opcodes[pc]]
												== captured.operandA[pc]
										else
											pc = registers[captured.opcodes[pc]]
										end
									elseif v326 < 62 then
										if v326 == 61 then
											registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
												+ captured.constantOpcode[pc]
										else
											registers[captured.operandA[pc]] = registers[captured.opcodes[pc]](
												unpackValues(
													registers[captured.operandC[pc]],
													1,
													registers[captured.operandC[pc]].n
												)
											)
										end
									elseif v326 == 63 then
										if captured.operandA[pc] > registers[captured.operandC[pc]] then
											pc = captured.opcodes[pc]
										end
									else
										registers[captured.opcodes[pc]] =
											bitXor(registers[captured.operandA[pc]], captured.operandC[pc])
									end
								elseif v326 >= 25 then
									if v326 >= 38 then
										if v326 >= 44 then
											if v326 >= 47 then
												if v326 >= 49 then
													if v326 == 50 then
														v36 = captured.capturedValues[captured.opcodes[pc]]
														v36[5][v36[4]][captured.constantA[pc]] =
															registers[captured.operandC[pc]]
													else
														registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
															> registers[captured.opcodes[pc]]
													end
												elseif v326 == 48 then
													registers[captured.operandC[pc]]()
												else
													registers[captured.operandC[pc]][registers[captured.opcodes[pc]]] =
														registers[captured.operandA[pc]]
												end
											elseif v326 < 45 then
												registers[captured.operandC[pc]] =
													bitAnd(registers[captured.opcodes[pc]], captured.constantA[pc])
											elseif v326 == 46 then
												registers[captured.operandC[pc]](
													captured.constantA[pc],
													unpackValues(
														registers[captured.opcodes[pc]],
														1,
														registers[captured.opcodes[pc]].n
													)
												)
											else
												registers[captured.operandA[pc]] =
													captured.capturedValues[captured.opcodes[pc]]
											end
										elseif v326 < 41 then
											if v326 >= 39 then
												if v326 ~= 40 then
													local v371 = u12
													local v372 = u13

													if v371 then
														for i in nextEntry, v371 do
															local v373 = v371[i]

															if v373 then
																v373[5] = v373
																v373[6] = registers[i]
																v373[4] = 6
																v371[i] = nil
															end
														end
													end

													if v372 then
														for i, v in nextEntry, v372 do
															local v374 = v[6]

															if v372 then
																local v375 = v372[i]

																if v375 then
																	local v376 = createRegisters(v374)
																	moveValues(registers, i, i + v374 - 1, 1, v376)
																	v375[5] = v376
																	v375[4] = 1
																	v372[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(
															registers[captured.operandA[pc]],
															registers[captured.operandC[pc]]
														)
												end

												registers[captured.operandC[pc]] =
													registers[captured.operandA[pc]][captured.constantOpcode[pc]]
											else
												registers[captured.opcodes[pc]] = captured.constantA[pc]
													+ registers[captured.operandC[pc]]
											end
										elseif v326 < 42 then
											registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
												* captured.constantOpcode[pc]
										else
											if v326 == 43 then
												local v377 = u12
												local v378 = u13

												if v377 then
													for i in nextEntry, v377 do
														local v379 = v377[i]

														if v379 then
															v379[5] = v379
															v379[6] = registers[i]
															v379[4] = 6
															v377[i] = nil
														end
													end
												end

												if v378 then
													for i, v in nextEntry, v378 do
														local v380 = v[6]

														if v378 then
															local v381 = v378[i]

															if v381 then
																local v382 = createRegisters(v380)
																moveValues(registers, i, i + v380 - 1, 1, v382)
																v381[5] = v382
																v381[4] = 1
																v378[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandA[pc],
													registers[captured.operandC[pc]]
											end

											v36 = captured.opcodes[pc]
											local v383 = captured.operandA[pc]
											registers[v36] = captured.constantC[pc]
											registers[v36 + 1] = v383
										end
									elseif v326 < 31 then
										if v326 >= 28 then
											if v326 >= 29 then
												if v326 == 30 then
													v36 = bitXor(
														seedA,
														bitAnd(rightShift(seedA, 14), 262143),
														(bitAnd(rightShift(seedA, 28), 15))
													)
													v34 = captured.opcodes[pc]
													v32 = captured.operandA[pc]
													v35 = captured.operandC[pc]
													v33 = v32 < 16384 and 7 or (v32 < 2097152 and 14 or 21)
													v37 = rightShift(v32, v33)
													local v384 = bitAnd(v32, leftShift(1, v33) - 1)
													captured.operandC[pc] =
														bitXor(v35, 108, (bitAnd(rightShift(v36, 14), 127)))
													captured.opcodes[pc] = bitXor(v34, 127, (bitAnd(v36, 127)))
													captured.operandA[pc] =
														bitXor(v384, 67, (bitAnd(rightShift(v36, 7), 127)))
													captured.operandB[pc] =
														bitXor(v37, 124, (bitAnd(rightShift(v36, 21), 127)))
													pc = pc - 1
												else
													local v385 = captured.opcodes[pc]
													local v386 = bitXor(
														captured.operandA[pc],
														(
															bitAnd(
																bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))),
																536870911
															)
														)
													)
													local v387 = captured.constantState[5]
													local v388 = bitXor(v387[v385], 109162203)
													v387[v385] = v388
													local v389 = captured.constantState[4]
													local v390 = v388 + 1
													local v391 = readByte(v389, v390)
													local v392

													if v391 < 128 then
														v392 = v390 + 1
													else
														local v393 = readByte(v389, v390 + 1)

														if v393 < 128 then
															v391 = v391 - 128 + v393 * 128
															v392 = v390 + 2
														else
															local v394 = readByte(v389, v390 + 2)

															if v394 < 128 then
																v391 = v391 - 128 + (v393 - 128) * 16384 + v394 * 128
																v392 = v390 + 3
															else
																local v395 = readByte(v389, v390 + 3)
																v391 = (v391 - 128) * 16384
																	+ (v393 - 128) * 128
																	+ (v394 - 128)
																	+ v395 % 128 * 2097152
																	+ (v395 - v395 % 128) * 2097152
																v392 = v390 + 4
															end
														end
													end

													local v396 = v386 * 16843009
													local v397 = v392 + v391
													local v398 = v397 - v391 % 4

													for i = v392, v398 - 1, 4 do
														writeUInt32(v389, i, (bitXor(readUInt32(v389, i), v396)))
														local _ = i
													end

													for i = v398, v397 - 1 do
														writeByte(v389, i, (bitXor(readByte(v389, i), v386)))
														local _ = i
													end

													captured.opcodes[pc] = 42
													captured.operandA[pc] = 156
													captured.operandC[pc] = 248
													captured.operandB[pc] = 80
												end
											else
												registers[captured.opcodes[pc]] = registers[captured.operandC[pc]]
													~= captured.operandA[pc]
											end
										else
											if v326 < 26 then
												local v399 = u12
												local v400 = u13

												if v399 then
													for i in nextEntry, v399 do
														local v401 = v399[i]

														if v401 then
															v401[5] = v401
															v401[6] = registers[i]
															v401[4] = 6
															v399[i] = nil
														end
													end
												end

												if v400 then
													for i, v in nextEntry, v400 do
														local v402 = v[6]

														if v400 then
															local v403 = v400[i]

															if v403 then
																local v404 = createRegisters(v402)
																moveValues(registers, i, i + v402 - 1, 1, v404)
																v403[5] = v404
																v403[4] = 1
																v400[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandC[pc],
													packValues(
														registers[captured.opcodes[pc]],
														unpackValues(
															registers[captured.operandA[pc]],
															1,
															registers[captured.operandA[pc]].n
														)
													)
											end

											if v326 == 27 then
												registers[captured.opcodes[pc]](
													registers[captured.operandA[pc]],
													unpackValues(
														registers[captured.operandC[pc]],
														1,
														registers[captured.operandC[pc]].n
													)
												)
											else
												registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
													- registers[captured.opcodes[pc]]
											end
										end
									elseif v326 < 34 then
										if v326 < 32 then
											captured.capturedValues[captured.opcodes[pc]][captured.constantA[pc]] =
												registers[captured.operandC[pc]]
										elseif v326 == 33 then
											registers[captured.operandC[pc]](registers[captured.operandA[pc]])
										else
											pc = registers[captured.operandC[pc]]
										end
									elseif v326 < 36 then
										if v326 == 35 then
											local v405 = captured.opcodes[pc]
											local v406 = bitXor(
												captured.operandA[pc],
												(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
											)
											local v407 = captured.constantState[5]
											local v408 = bitXor(v407[v405], 109162203)
											v407[v405] = v408
											local v409 = captured.constantState[4]
											local v410 = v408 + 1
											local v411 = readByte(v409, v410)
											local v412

											if v411 < 128 then
												v412 = v410 + 1
											else
												local v413 = readByte(v409, v410 + 1)

												if v413 < 128 then
													v411 = v411 - 128 + v413 * 128
													v412 = v410 + 2
												else
													local v414 = readByte(v409, v410 + 2)

													if v414 < 128 then
														v411 = v411 - 128 + (v413 - 128) * 16384 + v414 * 128
														v412 = v410 + 3
													else
														local v415 = readByte(v409, v410 + 3)
														v411 = (v411 - 128) * 16384
															+ (v413 - 128) * 128
															+ (v414 - 128)
															+ v415 % 128 * 2097152
															+ (v415 - v415 % 128) * 2097152
														v412 = v410 + 4
													end
												end
											end

											local v416 = v406 * 16843009
											local v417 = v412 + v411
											local v418 = v417 - v411 % 4

											for i = v412, v418 - 1, 4 do
												writeUInt32(v409, i, (bitXor(readUInt32(v409, i), v416)))
												local _ = i
											end

											for i = v418, v417 - 1 do
												writeByte(v409, i, (bitXor(readByte(v409, i), v406)))
												local _ = i
											end

											captured.opcodes[pc] = 21
											captured.operandA[pc] = 205
											captured.operandC[pc] = 192
											captured.operandB[pc] = 80
										else
											v36 = captured.opcodes[pc] + 1
											v34 = bitXor(
												captured.operandA[pc],
												(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
											)

											for i = 1, captured.operandC[pc] do
												local v419 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
												local v420 = bitXor(v419, (rightShift(v419, 13)))
												v34 = bitAnd(bitXor(v420, (leftShift(v420, 14))), 536870911)
												captured.opcodes[v36] =
													bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
												captured.operandA[v36] =
													bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
												captured.operandC[v36] =
													bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 14), 127)))
												captured.operandB[v36] =
													bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 21), 127)))
												v36 = v36 + 1
												local _ = i
											end

											captured.operandB[pc] = 80
										end
									elseif v326 == 37 then
										registers[captured.operandA[pc]] =
											captured.capturedValues[captured.opcodes[pc]][registers[captured.operandC[pc]]]
									else
										registers[captured.operandC[pc]] = registers[captured.opcodes[pc]]
											/ captured.operandA[pc]
									end
								elseif v326 < 12 then
									if v326 >= 6 then
										if v326 >= 9 then
											if v326 < 10 then
												v36 = captured.operandC[pc]
												local v421 = captured.operandA[pc]
												registers[v36] = captured.opcodes[pc]
												registers[v36 + 1] = v421
											elseif v326 == 11 then
												for i = captured.operandC[pc], captured.operandA[pc] do
													registers[i] = nil
													local _ = i
												end
											else
												registers[captured.opcodes[pc]] = captured.operandA[pc]
													- registers[captured.operandC[pc]]
											end
										elseif v326 >= 7 then
											if v326 == 8 then
												if captured.opcodes[pc] >= registers[captured.operandC[pc]] then
													pc = captured.operandA[pc]
												end
											elseif registers[captured.operandA[pc]] >= captured.constantOpcode[pc] then
												pc = captured.operandC[pc]
											end
										else
											v36 = captured.capturedValues[captured.operandC[pc]]
											registers[captured.operandA[pc]] = v36[5][v36[4]]
										end
									elseif v326 >= 3 then
										if v326 < 4 then
											u7 = {
												[6] = u11,
												[5] = u9,
												[9] = u7,
												[8] = u8,
												[7] = u10,
											}
											v36 = captured.operandC[pc]
											u10 = registers[v36 + 2] + 0
											u9 = registers[v36 + 1] + 0
											u8 = registers[v36] - u10
											pc = captured.operandA[pc]
										elseif v326 == 5 then
											registers[captured.opcodes[pc]] = environment[captured.constantC[pc]]
										elseif u12 then
											local v422 = u12
											local v423 = captured.operandA[pc]
											local v424 = v422[v423]

											if v424 then
												v424[5] = v424
												v424[6] = registers[v423]
												v424[4] = 6
												v422[v423] = nil
											end
										end
									elseif v326 >= 1 then
										if v326 == 2 then
											registers[captured.operandC[pc]] = captured.constantA[pc]
												.. registers[captured.opcodes[pc]]
										else
											seedA = registers[captured.opcodes[pc]]
										end
									else
										registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
											* registers[captured.operandC[pc]]
									end
								elseif v326 >= 18 then
									if v326 < 21 then
										if v326 >= 19 then
											if v326 == 20 then
												registers[captured.operandA[pc]] =
													bitOr(captured.constantC[pc], registers[captured.opcodes[pc]])
											elseif registers[captured.opcodes[pc]] ~= captured.operandC[pc] then
												pc = captured.operandA[pc]
											end
										else
											environment[captured.constantOpcode[pc]][captured.constantC[pc]] =
												registers[captured.operandA[pc]]
										end
									elseif v326 >= 23 then
										if v326 == 24 then
											registers[captured.operandA[pc]] = #registers[captured.operandC[pc]]
										else
											registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
												~= registers[captured.opcodes[pc]]
										end
									elseif v326 == 22 then
										seedB = registers[captured.operandC[pc]]
									else
										registers[captured.opcodes[pc]][registers[captured.operandA[pc]]] =
											captured.constantC[pc]
									end
								elseif v326 >= 15 then
									if v326 >= 16 then
										if v326 == 17 then
											local v425 = captured.operandC[pc]
											local v426 = captured.operandA[pc]
											local v427 = captured.constantState[5]
											local v428 = bitXor(v427[v425], 109162203)
											v427[v425] = v428
											local v429 = captured.constantState[4]
											local v430 = v428 + 1
											local v431 = readByte(v429, v430)
											local v432

											if v431 < 128 then
												v432 = v430 + 1
											else
												local v433 = readByte(v429, v430 + 1)

												if v433 < 128 then
													v431 = v431 - 128 + v433 * 128
													v432 = v430 + 2
												else
													local v434 = readByte(v429, v430 + 2)

													if v434 < 128 then
														v431 = v431 - 128 + (v433 - 128) * 16384 + v434 * 128
														v432 = v430 + 3
													else
														local v435 = readByte(v429, v430 + 3)
														v431 = (v431 - 128) * 16384
															+ (v433 - 128) * 128
															+ (v434 - 128)
															+ v435 % 128 * 2097152
															+ (v435 - v435 % 128) * 2097152
														v432 = v430 + 4
													end
												end
											end

											local v436 = v426 * 16843009
											local v437 = v432 + v431
											local v438 = v437 - v431 % 4

											for i = v432, v438 - 1, 4 do
												writeUInt32(v429, i, (bitXor(readUInt32(v429, i), v436)))
												local _ = i
											end

											for i = v438, v437 - 1 do
												writeByte(v429, i, (bitXor(readByte(v429, i), v426)))
												local _ = i
											end

											captured.operandC[pc] = 78
											captured.operandA[pc] = 229
											captured.opcodes[pc] = 8
											captured.operandB[pc] = 80
										else
											registers[captured.operandC[pc]] = captured.operandA[pc]
										end
									else
										registers[captured.opcodes[pc]] =
											rightShift(registers[captured.operandC[pc]], captured.operandA[pc])
									end
								elseif v326 >= 13 then
									if v326 == 14 then
										if registers[captured.operandA[pc]] ~= registers[captured.opcodes[pc]] then
											pc = captured.operandC[pc]
										end
									else
										registers[captured.operandA[pc]] = captured.operandC[pc]
											* registers[captured.opcodes[pc]]
									end
								else
									v36 = captured.operandC[pc] + 1
									v34 = captured.operandA[pc]

									for i = 1, captured.opcodes[pc] do
										local v439 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
										local v440 = bitXor(v439, (rightShift(v439, 13)))
										v34 = bitAnd(bitXor(v440, (leftShift(v440, 14))), 536870911)
										captured.opcodes[v36] =
											bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
										captured.operandA[v36] =
											bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
										captured.operandC[v36] =
											bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 14), 127)))
										captured.operandB[v36] =
											bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 21), 127)))
										v36 = v36 + 1
										local _ = i
									end

									captured.operandB[pc] = 80
								end
							else
								if v326 >= 155 then
									if v326 >= 181 then
										if v326 >= 194 then
											if v326 >= 200 then
												if v326 >= 203 then
													if v326 < 205 then
														if v326 == 204 then
															registers[captured.operandC[pc]] = registers[captured.opcodes[pc]]
																< registers[captured.operandA[pc]]
														else
															v36 = captured.operandA[pc]
															v34, v32 = u8()

															if v34 then
																registers[v36] = v32
																pc = captured.operandC[pc]
															else
																pc = captured.opcodes[pc]
															end
														end
													else
														if v326 == 206 then
															local v441 = u12
															local v442 = u13

															if v441 then
																for i in nextEntry, v441 do
																	local v443 = v441[i]

																	if v443 then
																		v443[5] = v443
																		v443[6] = registers[i]
																		v443[4] = 6
																		v441[i] = nil
																	end
																end
															end

															if v442 then
																for i, v in nextEntry, v442 do
																	local v444 = v[6]

																	if v442 then
																		local v445 = v442[i]

																		if v445 then
																			local v446 = createRegisters(v444)
																			moveValues(
																				registers,
																				i,
																				i + v444 - 1,
																				1,
																				v446
																			)
																			v445[5] = v446
																			v445[4] = 1
																			v442[i] = nil
																		end
																	end
																end
															end

															return false,
																true,
																packValues(
																	registers[captured.operandA[pc]],
																	captured.constantC[pc],
																	captured.constantOpcode[pc]
																)
														end

														registers[captured.operandA[pc]] =
															-registers[captured.operandC[pc]]
													end
												elseif v326 < 201 then
													registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
														// captured.operandC[pc]
												else
													if v326 == 202 then
														local v447 = captured.opcodes[pc]
														local v448 = v447 + captured.operandA[pc]
														local v449 = u12
														local v450 = u13

														if v449 then
															for i in nextEntry, v449 do
																local v451 = v449[i]

																if v451 then
																	v451[5] = v451
																	v451[6] = registers[i]
																	v451[4] = 6
																	v449[i] = nil
																end
															end
														end

														if v450 then
															for i, v in nextEntry, v450 do
																local v452 = v[6]

																if v450 then
																	local v453 = v450[i]

																	if v453 then
																		local v454 = createRegisters(v452)
																		moveValues(registers, i, i + v452 - 1, 1, v454)
																		v453[5] = v454
																		v453[4] = 1
																		v450[i] = nil
																	end
																end
															end
														end

														return true, false, v447, v448
													end

													registers[captured.operandC[pc]] = registers[captured.opcodes[pc]]
														% registers[captured.operandA[pc]]
												end
											elseif v326 >= 197 then
												if v326 < 198 then
													registers[captured.operandA[pc]] =
														not registers[captured.opcodes[pc]]
												elseif v326 == 199 then
													pc = captured.operandA[pc]
												else
													v36 = captured.operandC[pc]
													v34 = registers[captured.opcodes[pc]]
													registers[v36 + 1] = v34
													registers[v36] = v34[captured.constantA[pc]]
												end
											elseif v326 < 195 then
												registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
													.. registers[captured.operandC[pc]]
											else
												if v326 ~= 196 then
													local v455 = u12
													local v456 = u13

													if v455 then
														for i in nextEntry, v455 do
															local v457 = v455[i]

															if v457 then
																v457[5] = v457
																v457[6] = registers[i]
																v457[4] = 6
																v455[i] = nil
															end
														end
													end

													if v456 then
														for i, v in nextEntry, v456 do
															local v458 = v[6]

															if v456 then
																local v459 = v456[i]

																if v459 then
																	local v460 = createRegisters(v458)
																	moveValues(registers, i, i + v458 - 1, 1, v460)
																	v459[5] = v460
																	v459[4] = 1
																	v456[i] = nil
																end
															end
														end
													end

													return true,
														true,
														captured.operandA[pc],
														packValues(
															registers[captured.operandC[pc]],
															registers[captured.opcodes[pc]]
														)
												end

												local v461 = captured.operandC[pc]
												local v462 = captured.operandA[pc]
												local v463 = bitAnd(registers[captured.opcodes[pc]], 4294967295)
												local v464 = bitAnd(v462, 4294967295)
												local v465 = bitAnd(v463, 65535)
												local v466 = rightShift(v463, 16)
												local v467 = bitAnd(v464, 65535)
												local v468 = rightShift(v464, 16)
												local v469 = bitAnd(
													v465 * v467
														+ leftShift(bitAnd(v465 * v468 + v466 * v467, 65535), 16),
													4294967295
												) % 4294967296
												registers[v461] = v469 ~= v469 and 0 or v469 - v469 % 1
											end
										elseif v326 < 187 then
											if v326 >= 184 then
												if v326 >= 185 then
													if v326 == 186 then
														registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
															== registers[captured.opcodes[pc]]
													else
														v36 = captured.operandA[pc]
														v34 = captured.operandC[pc]
														v32 = captured.opcodes[pc]
														v35 = v36 + v32 - 1
														v33 = v36 + v34
														v37 = packValues(
															registers[v36](unpackValues(registers, v36 + 1, v36 + v34))
														)
														moveValues(v37, 1, v32, v36, registers)
													end
												else
													registers[captured.opcodes[pc]] = captured.constantA[pc]
														% registers[captured.operandC[pc]]
												end
											elseif v326 >= 182 then
												if v326 == 183 then
													registers[captured.operandC[pc]] = seedB
												elseif
													captured.constantOpcode[pc] > registers[captured.operandC[pc]]
												then
													pc = captured.operandA[pc]
												end
											else
												v36 = captured.operandC[pc]
												local v470 = registers[captured.opcodes[pc]]
												registers[v36] = registers[captured.operandA[pc]]
												registers[v36 + 1] = v470
											end
										elseif v326 >= 190 then
											if v326 < 192 then
												if v326 == 191 then
													v36 = captured.operandA[pc]
													local v471 = captured.constantC[pc]
													registers[v36] = registers[captured.opcodes[pc]]
													registers[v36 + 1] = v471
												else
													v36 = captured.opcodes[pc]
													local v472 = registers[captured.operandA[pc]]
													registers[v36] = captured.constantC[pc]
													registers[v36 + 1] = v472
												end
											elseif v326 == 193 then
												registers[captured.operandC[pc]](
													captured.constantA[pc],
													captured.constantOpcode[pc]
												)
											else
												captured.capturedValues[captured.operandA[pc]][captured.constantC[pc]] =
													captured.constantOpcode[pc]
											end
										elseif v326 < 188 then
											if registers[captured.operandA[pc]] >= registers[captured.opcodes[pc]] then
												pc = captured.operandC[pc]
											end
										elseif v326 == 189 then
											registers[captured.operandA[pc]](
												unpackValues(
													registers[captured.opcodes[pc]],
													1,
													registers[captured.opcodes[pc]].n
												)
											)
										else
											v36 = captured.operandC[pc]
											v34 = captured.opcodes[pc]
											v32 = captured.operandA[pc]
											v35 = registers[v36]
											v33 = v36 + v34
											v37 = registers[v33]
											moveValues(registers, v36 + 1, v33 - 1, v32 + 1, v35)
											moveValues(v37, 1, v37.n, v32 + v34, v35)
										end
									elseif v326 >= 168 then
										if v326 >= 174 then
											if v326 >= 177 then
												if v326 < 179 then
													if v326 == 178 then
														registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
															<= captured.opcodes[pc]
													else
														registers[captured.opcodes[pc]] =
															captured.capturedValues[captured.operandA[pc]][captured.operandC[pc]]
													end
												elseif v326 == 180 then
													local v473 = captured.opcodes[pc]
													local v474 = captured.operandC[pc]
													local v475, v476 = registers[captured.operandA[pc]]()
													registers[v473] = v475
													registers[v474] = v476
												else
													registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
														// registers[captured.opcodes[pc]]
												end
											elseif v326 >= 175 then
												if v326 == 176 then
													local v477 = u12
													local v478 = u13

													if v477 then
														for i in nextEntry, v477 do
															local v479 = v477[i]

															if v479 then
																v479[5] = v479
																v479[6] = registers[i]
																v479[4] = 6
																v477[i] = nil
															end
														end
													end

													if v478 then
														for i, v in nextEntry, v478 do
															local v480 = v[6]

															if v478 then
																local v481 = v478[i]

																if v481 then
																	local v482 = createRegisters(v480)
																	moveValues(registers, i, i + v480 - 1, 1, v482)
																	v481[5] = v482
																	v481[4] = 1
																	v478[i] = nil
																end
															end
														end
													end

													return false, true, packValues(captured.constantOpcode[pc])
												end

												registers[captured.opcodes[pc]] = registers
											else
												registers[captured.operandC[pc]] = seedA
											end
										elseif v326 >= 171 then
											if v326 >= 172 then
												if v326 ~= 173 then
													local v483 = u12
													local v484 = u13

													if v483 then
														for i in nextEntry, v483 do
															local v485 = v483[i]

															if v485 then
																v485[5] = v485
																v485[6] = registers[i]
																v485[4] = 6
																v483[i] = nil
															end
														end
													end

													if v484 then
														for i, v in nextEntry, v484 do
															local v486 = v[6]

															if v484 then
																local v487 = v484[i]

																if v487 then
																	local v488 = createRegisters(v486)
																	moveValues(registers, i, i + v486 - 1, 1, v488)
																	v487[5] = v488
																	v487[4] = 1
																	v484[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(captured.constantC[pc], captured.constantOpcode[pc])
												end

												local v489 = captured.opcodes[pc]
												local v490 = registers[captured.operandC[pc]]
												local v491 = bitAnd(captured.operandA[pc], 4294967295)
												local v492 = bitAnd(v490, 4294967295)
												local v493 = bitAnd(v491, 65535)
												local v494 = rightShift(v491, 16)
												local v495 = bitAnd(v492, 65535)
												local v496 = rightShift(v492, 16)
												local v497 = bitAnd(
													v493 * v495
														+ leftShift(bitAnd(v493 * v496 + v494 * v495, 65535), 16),
													4294967295
												) % 4294967296
												registers[v489] = v497 ~= v497 and 0 or v497 - v497 % 1
											else
												registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
													<= captured.constantOpcode[pc]
											end
										elseif v326 >= 169 then
											if v326 == 170 then
												u7 = {
													[6] = u11,
													[5] = u9,
													[9] = u7,
													[8] = u8,
													[7] = u10,
												}
												v36 = captured.operandA[pc]
												v34 = wrapCoroutine(closeUpvalues)
												v34(
													captured.runtime,
													registers[v36],
													registers[v36 + 1],
													registers[v36 + 2]
												)
												u8 = v34
												u11 = captured.operandC[pc]
												pc = captured.opcodes[pc]
											else
												registers[captured.operandA[pc]] =
													packValues(registers[captured.opcodes[pc]]())
											end
										else
											environment[captured.constantC[pc]][registers[captured.opcodes[pc]]] =
												registers[captured.operandA[pc]]
										end
									elseif v326 < 161 then
										if v326 < 158 then
											if v326 < 156 then
												v36 = captured.operandC[pc]
												v34 = captured.operandA[pc]
												v32 = captured.opcodes[pc]
												v35 = registers[v36]
												moveValues(registers, v36 + 1, v36 + v34, v32 + 1, v35)
											else
												if v326 == 157 then
													local v498 = u12
													local v499 = u13

													if v498 then
														for i in nextEntry, v498 do
															local v500 = v498[i]

															if v500 then
																v500[5] = v500
																v500[6] = registers[i]
																v500[4] = 6
																v498[i] = nil
															end
														end
													end

													if v499 then
														for i, v in nextEntry, v499 do
															local v501 = v[6]

															if v499 then
																local v502 = v499[i]

																if v502 then
																	local v503 = createRegisters(v501)
																	moveValues(registers, i, i + v501 - 1, 1, v503)
																	v502[5] = v503
																	v502[4] = 1
																	v499[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(
															registers[captured.opcodes[pc]],
															captured.constantC[pc]
														)
												end

												v36 = captured.operandA[pc]
												v34 = captured.operandC[pc]
												v32 = captured.opcodes[pc]
												v35 = v36 + v34
												registers[v36] =
													packValues(registers[v36](unpackValues(registers, v36 + 1, v35)))
											end
										elseif v326 >= 159 then
											if v326 == 160 then
												v36 = captured.opcodes[pc]
												v34 = captured.operandA[pc]
												v32 = captured.operandC[pc]
												v35 = v36 + v34
												v33 = registers[v35]
												v37 = v33.n
												v33.n = v34 + v37 - 1
												moveValues(v33, 1, v37, v34, v33)
												moveValues(registers, v36 + 1, v35 - 1, 1, v33)
												registers[v36] = packValues(registers[v36](unpackValues(v33, 1, v33.n)))
											else
												environment[captured.constantOpcode[pc]] = captured.constantC[pc]
											end
										else
											u8 = u7[8]
											u9 = u7[5]
											u10 = u7[7]
											u11 = u7[6]
											u7 = u7[9]
										end
									elseif v326 >= 164 then
										if v326 >= 166 then
											if v326 ~= 167 then
												local v504 = u12
												local v505 = u13

												if v504 then
													for i in nextEntry, v504 do
														local v506 = v504[i]

														if v506 then
															v506[5] = v506
															v506[6] = registers[i]
															v506[4] = 6
															v504[i] = nil
														end
													end
												end

												if v505 then
													for i, v in nextEntry, v505 do
														local v507 = v[6]

														if v505 then
															local v508 = v505[i]

															if v508 then
																local v509 = createRegisters(v507)
																moveValues(registers, i, i + v507 - 1, 1, v509)
																v508[5] = v509
																v508[4] = 1
																v505[i] = nil
															end
														end
													end
												end

												return false, true, packValues(registers[captured.opcodes[pc]])
											end

											if captured.constantOpcode[pc] >= registers[captured.operandA[pc]] then
												pc = captured.operandC[pc]
											end
										elseif v326 == 165 then
											local v510 = captured.operandC[pc]
											local v511 = captured.constantOpcode[pc]
											local v512 = bitAnd(registers[captured.operandA[pc]], 4294967295)
											local v513 = bitAnd(v511, 4294967295)
											local v514 = bitAnd(v512, 65535)
											local v515 = rightShift(v512, 16)
											local v516 = bitAnd(v513, 65535)
											local v517 = rightShift(v513, 16)
											local v518 = bitAnd(
												v514 * v516 + leftShift(bitAnd(v514 * v517 + v515 * v516, 65535), 16),
												4294967295
											) % 4294967296
											registers[v510] = v518 ~= v518 and 0 or v518 - v518 % 1
										else
											environment[captured.constantC[pc]] = registers[captured.opcodes[pc]]
										end
									elseif v326 >= 162 then
										if v326 == 163 then
											registers[captured.operandA[pc]] = packValues(
												registers[captured.operandC[pc]](
													unpackValues(
														registers[captured.opcodes[pc]],
														1,
														registers[captured.opcodes[pc]].n
													)
												)
											)
										else
											registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
												+ captured.operandC[pc]
										end
									else
										registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
											/ captured.constantOpcode[pc]
									end

									v325 = 1
									continue
								end

								if v326 < 129 then
									if v326 < 116 then
										if v326 < 109 then
											if v326 >= 106 then
												if v326 >= 107 then
													if v326 ~= 108 then
														local v519 = u12
														local v520 = u13

														if v519 then
															for i in nextEntry, v519 do
																local v521 = v519[i]

																if v521 then
																	v521[5] = v521
																	v521[6] = registers[i]
																	v521[4] = 6
																	v519[i] = nil
																end
															end
														end

														if v520 then
															for i, v in nextEntry, v520 do
																local v522 = v[6]

																if v520 then
																	local v523 = v520[i]

																	if v523 then
																		local v524 = createRegisters(v522)
																		moveValues(registers, i, i + v522 - 1, 1, v524)
																		v523[5] = v524
																		v523[4] = 1
																		v520[i] = nil
																	end
																end
															end
														end

														return false, true, registers[captured.operandC[pc]]
													end

													registers[captured.operandC[pc]] = captured.constantA[pc]
												else
													captured.capturedValues[captured.opcodes[pc]][registers[captured.operandC[pc]]] =
														registers[captured.operandA[pc]]
												end
											elseif v326 < 104 then
												registers[captured.operandC[pc]] =
													captured.runtime[captured.operandA[pc]]
											else
												if v326 ~= 105 then
													local v525 = u12
													local v526 = u13

													if v525 then
														for i in nextEntry, v525 do
															local v527 = v525[i]

															if v527 then
																v527[5] = v527
																v527[6] = registers[i]
																v527[4] = 6
																v525[i] = nil
															end
														end
													end

													if v526 then
														for i, v in nextEntry, v526 do
															local v528 = v[6]

															if v526 then
																local v529 = v526[i]

																if v529 then
																	local v530 = createRegisters(v528)
																	moveValues(registers, i, i + v528 - 1, 1, v530)
																	v529[5] = v530
																	v529[4] = 1
																	v526[i] = nil
																end
															end
														end
													end

													return false, false
												end

												v36 = captured.capturedValues[captured.opcodes[pc]]
												v36[5][v36[4]] = registers[captured.operandA[pc]]
											end
										elseif v326 < 112 then
											if v326 >= 110 then
												if v326 == 111 then
													registers[captured.operandC[pc]] =
														environment[captured.constantOpcode[pc]][captured.constantA[pc]]
												elseif
													registers[captured.opcodes[pc]] > registers[captured.operandC[pc]]
												then
													pc = captured.operandA[pc]
												end
											else
												u8 = u8 + u10

												if u10 <= 0 then
													v36 = u9 <= u8
												else
													v36 = u8 <= u9
												end

												if v36 then
													registers[captured.operandA[pc]] = u8
													pc = captured.opcodes[pc]
												else
													pc = captured.operandC[pc]
												end
											end
										elseif v326 < 114 then
											if v326 == 113 then
												registers[captured.operandA[pc]] =
													registers[captured.operandC[pc]][captured.opcodes[pc]]
											else
												registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
													<= registers[captured.operandC[pc]]
											end
										elseif v326 == 115 then
											registers[captured.opcodes[pc]] =
												bitXor(registers[captured.operandC[pc]], captured.constantA[pc])
										else
											registers[captured.operandA[pc]] = packValues(
												registers[captured.operandC[pc]](captured.constantOpcode[pc])
											)
										end
									elseif v326 < 122 then
										if v326 >= 119 then
											if v326 < 120 then
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]()
											elseif v326 == 121 then
												if registers[captured.opcodes[pc]] > captured.constantC[pc] then
													pc = captured.operandA[pc]
												end
											else
												registers[captured.opcodes[pc]][captured.constantC[pc]] =
													captured.operandA[pc]
											end
										elseif v326 >= 117 then
											if v326 == 118 then
												local v531

												if registers[captured.operandC[pc]] then
													v531 = captured.operandA[pc]
												else
													v531 = captured.opcodes[pc]
												end

												pc = v531
											elseif registers[captured.operandC[pc]] ~= captured.constantOpcode[pc] then
												pc = captured.operandA[pc]
											end
										else
											v36 = captured.operandA[pc]
											local v532 = captured.constantOpcode[pc]
											registers[v36] = captured.operandC[pc]
											registers[v36 + 1] = v532
										end
									elseif v326 >= 125 then
										if v326 < 127 then
											if v326 == 126 then
												local v533 = u12
												local v534 = u13

												if v533 then
													for i in nextEntry, v533 do
														local v535 = v533[i]

														if v535 then
															v535[5] = v535
															v535[6] = registers[i]
															v535[4] = 6
															v533[i] = nil
														end
													end
												end

												if v534 then
													for i, v in nextEntry, v534 do
														local v536 = v[6]

														if v534 then
															local v537 = v534[i]

															if v537 then
																local v538 = createRegisters(v536)
																moveValues(registers, i, i + v536 - 1, 1, v538)
																v537[5] = v538
																v537[4] = 1
																v534[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandC[pc],
													packValues(captured.constantA[pc], registers[captured.opcodes[pc]])
											end

											registers[captured.operandC[pc]] = registers[captured.opcodes[pc]]
												~= captured.constantA[pc]
										elseif v326 == 128 then
											v36 = captured.operandC[pc]
											local v539 = captured.constantOpcode[pc]
											registers[v36] = captured.constantA[pc]
											registers[v36 + 1] = v539
										else
											local v540 = nil
											local v541 = captured.opcodes[pc]
											local v542 = captured.constantA[pc]
											local v543 = captured.constantC[pc]
											local v544 = u12
											local v545 = u13
											local v546 = v543[0]

											if v546 then
												local v547 = #v546 / 3

												if v547 > 0 then
													v540 = {}

													for i = 1, v547 do
														local v548 = (i - 1) * 3
														local v549 = v546[v548 + 2]
														local v550 = v546[v548 + 1]
														local v551

														if v549 == 2 then
															v544 = v544 or {}
															local v552 = v544[v550]

															if not v552 then
																v552 = {
																	[5] = registers,
																	[4] = v550,
																}
																v544[v550] = v552
															end

															v540[i] = v552
															v551 = i
														elseif v549 == 0 then
															v540[i] = registers[v550]
															v551 = i
														elseif v549 == 3 then
															v540[i] = captured.capturedValues[v550]
															v551 = i
														elseif v549 == 1 then
															v545 = v545 or {}
															local v553 = v545[v550]

															if not v553 then
																v553 = {
																	[5] = registers,
																	[4] = v550,
																	[6] = v546[v548 + 3],
																}
																v545[v550] = v553
															end

															v540[i] = v553
															v551 = i
														else
															v551 = i
														end
													end
												end
											end

											local v554 = v543[-2]
											v543[v554] = v540
											local v555 = v542(unpackValues(v543, 1, v543[-1]))
											v543[v554] = nil
											registers[v541] = v555
											u12 = v544
											u13 = v545
										end
									elseif v326 >= 123 then
										if v326 == 124 then
											registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
												* captured.operandC[pc]
										else
											registers[captured.operandA[pc]] =
												bitXor(captured.constantC[pc], registers[captured.opcodes[pc]])
										end
									elseif u12 then
										local v556 = u12
										local v557 = captured.operandA[pc]
										local v558 = v556[v557]

										if v558 then
											v558[5] = v558
											v558[6] = registers[v557]
											v558[4] = 6
											v556[v557] = nil
										end

										local v559 = u12
										local v560 = captured.opcodes[pc]
										local v561 = v559[v560]

										if v561 then
											v561[5] = v561
											v561[6] = registers[v560]
											v561[4] = 6
											v559[v560] = nil
										end
									end
								else
									if v326 >= 142 then
										if v326 < 148 then
											if v326 < 145 then
												if v326 < 143 then
													if registers[captured.opcodes[pc]] > captured.operandA[pc] then
														pc = captured.operandC[pc]
													end
												elseif v326 == 144 then
													registers[captured.operandC[pc]][captured.constantA[pc]] =
														registers[captured.opcodes[pc]]
												else
													v36 = bitXor(
														seedA,
														bitAnd(rightShift(seedA, 14), 262143),
														(bitAnd(rightShift(seedA, 28), 15))
													)
													v34 = captured.operandC[pc]
													v32 = captured.opcodes[pc]
													v35 = captured.operandA[pc]
													v33 = v34 < 2097152 and 7 or 14
													v37 = bitAnd(v34, leftShift(1, v33) - 1)
													local v562 = rightShift(v34, v33)
													captured.operandA[pc] =
														bitXor(v35, 67, (bitAnd(rightShift(v36, 7), 127)))
													captured.operandB[pc] =
														bitXor(v562, 121, (bitAnd(rightShift(v36, 21), 127)))
													captured.opcodes[pc] = bitXor(v32, 3, (bitAnd(v36, 127)))
													captured.operandC[pc] =
														bitXor(v37, 31, (bitAnd(rightShift(v36, 14), 127)))
													pc = pc - 1
												end
											elseif v326 < 146 then
												v36 = captured.capturedValues[captured.operandC[pc]]
												v36[5][v36[4]][captured.constantOpcode[pc]] = captured.constantA[pc]
											elseif v326 == 147 then
												registers[captured.operandC[pc]](
													captured.constantOpcode[pc],
													registers[captured.operandA[pc]]
												)
											else
												v36 = captured.operandA[pc]
												local v563 = captured.opcodes[pc]
												registers[v36] = registers[captured.operandC[pc]]
												registers[v36 + 1] = v563
											end
										elseif v326 < 151 then
											if v326 < 149 then
												if registers[captured.opcodes[pc]] >= captured.operandA[pc] then
													pc = captured.operandC[pc]
												end
											elseif v326 == 150 then
												registers[captured.operandA[pc]] = captured.operandC[pc]
													/ registers[captured.opcodes[pc]]
											else
												registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
													>= captured.opcodes[pc]
											end
										elseif v326 >= 153 then
											if v326 == 154 then
												registers[captured.opcodes[pc]](
													registers[captured.operandC[pc]],
													captured.constantA[pc]
												)
											else
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
													== captured.constantC[pc]
											end
										elseif v326 == 152 then
											captured.capturedValues[captured.operandA[pc]][captured.constantC[pc]] =
												captured.opcodes[pc]
										else
											registers[captured.operandC[pc]] = bitXor(
												registers[captured.opcodes[pc]],
												registers[captured.operandA[pc]]
											)
										end

										v325 = 1
										continue
									end

									if v326 >= 135 then
										if v326 < 138 then
											if v326 >= 136 then
												if v326 == 137 then
													registers[captured.operandA[pc]] = leftShift(
														registers[captured.opcodes[pc]],
														captured.operandC[pc]
													)
												else
													registers[captured.operandA[pc]] =
														environment[captured.constantC[pc]][registers[captured.opcodes[pc]]]
												end
											else
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
											end
										elseif v326 >= 140 then
											if v326 == 141 then
												registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
													/ registers[captured.operandC[pc]]
											else
												registers[captured.operandA[pc]] = captured.constantOpcode[pc]
													+ captured.constantC[pc]
											end
										elseif v326 == 139 then
											registers[captured.opcodes[pc]][captured.operandA[pc]] =
												registers[captured.operandC[pc]]
										elseif u12 then
											local v564 = u12
											local v565 = captured.operandC[pc]
											local v566 = v564[v565]

											if v566 then
												v566[5] = v566
												v566[6] = registers[v565]
												v566[4] = 6
												v564[v565] = nil
											end

											local v567 = u12
											local v568 = captured.opcodes[pc]
											local v569 = v567[v568]

											if v569 then
												v569[5] = v569
												v569[6] = registers[v568]
												v569[4] = 6
												v567[v568] = nil
											end

											local v570 = u12
											local v571 = captured.operandA[pc]
											local v572 = v570[v571]

											if v572 then
												v572[5] = v572
												v572[6] = registers[v571]
												v572[4] = 6
												v570[v571] = nil
											end
										end
									elseif v326 >= 132 then
										if v326 < 133 then
											registers[captured.operandC[pc]] = createRegisters(captured.opcodes[pc])
										elseif v326 == 134 then
											local v573 = captured.opcodes[pc]
											local v574 = captured.constantA[pc]
											local v575 = bitAnd(captured.operandC[pc], 4294967295)
											local v576 = bitAnd(v574, 4294967295)
											local v577 = bitAnd(v575, 65535)
											local v578 = rightShift(v575, 16)
											local v579 = bitAnd(v576, 65535)
											local v580 = rightShift(v576, 16)
											local v581 = bitAnd(
												v577 * v579 + leftShift(bitAnd(v577 * v580 + v578 * v579, 65535), 16),
												4294967295
											) % 4294967296
											registers[v573] = v581 ~= v581 and 0 or v581 - v581 % 1
										else
											registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
												- captured.constantOpcode[pc]
										end
									else
										if v326 < 130 then
											registers[captured.opcodes[pc]](
												registers[captured.operandC[pc]],
												registers[captured.operandA[pc]]
											)
											v325 = 1
											continue
										end

										if v326 == 131 then
											mode = captured.operandA[pc]
											pc = captured.operandC[pc] + 1
											v38 = 3
											break
										end

										registers[captured.operandC[pc]](captured.constantA[pc])
									end
								end
							end

							v325 = 1
							continue
						elseif v325 == 1 then
							v325 = -1
							pc = pc + 1
							break
						else
							break
						end
					end

					if v38 ~= -1 then
						break
					end
				end

				if v38 ~= -1 then
					continue
				end

				v38 = 5
				continue
			elseif v38 == 5 then
				v38 = -1

				while true do
					local v582 = 0

					while true do
						if v582 == 0 then
							v582 = -1
							local v583 = captured.operandC[pc]

							if v583 < 95 then
								if v583 < 47 then
									if v583 < 23 then
										if v583 >= 11 then
											if v583 >= 17 then
												if v583 >= 20 then
													if v583 < 21 then
														registers[captured.operandB[pc]] =
															not registers[captured.operandA[pc]]
													else
														if v583 ~= 22 then
															local v584 = u12
															local v585 = u13

															if v584 then
																for i in nextEntry, v584 do
																	local v586 = v584[i]

																	if v586 then
																		v586[5] = v586
																		v586[6] = registers[i]
																		v586[4] = 6
																		v584[i] = nil
																	end
																end
															end

															if v585 then
																for i, v in nextEntry, v585 do
																	local v587 = v[6]

																	if v585 then
																		local v588 = v585[i]

																		if v588 then
																			local v589 = createRegisters(v587)
																			moveValues(
																				registers,
																				i,
																				i + v587 - 1,
																				1,
																				v589
																			)
																			v588[5] = v589
																			v588[4] = 1
																			v585[i] = nil
																		end
																	end
																end
															end

															return true,
																true,
																captured.operandA[pc],
																packValues(
																	captured.constantB[pc],
																	registers[captured.opcodes[pc]]
																)
														end

														v36 = captured.capturedValues[captured.opcodes[pc]]
														v36[5][v36[4]] = registers[captured.operandA[pc]]
													end
												elseif v583 < 18 then
													registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
														== captured.operandB[pc]
												elseif v583 == 19 then
													registers[captured.opcodes[pc]] =
														bitXor(registers[captured.operandB[pc]], captured.constantA[pc])
												else
													registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
														< registers[captured.opcodes[pc]]
												end
											elseif v583 < 14 then
												if v583 >= 12 then
													if v583 == 13 then
														environment[captured.constantOpcode[pc]][captured.constantA[pc]] =
															captured.constantB[pc]
													else
														pc = registers[captured.operandB[pc]]
													end
												else
													v36 = captured.operandA[pc]
													v34 = registers[captured.opcodes[pc]]
													registers[v36 + 1] = v34
													registers[v36] = v34[captured.constantB[pc]]
												end
											elseif v583 < 15 then
												v36 = captured.operandA[pc]
												v34, v32, v35 = u8()

												if v34 then
													registers[v36] = v32
													registers[v36 + 1] = v35
													pc = captured.opcodes[pc]
												else
													pc = captured.operandB[pc]
												end
											elseif v583 == 16 then
												v36 = captured.opcodes[pc]
												v34 = captured.operandA[pc]
												v32 = captured.operandB[pc]
												v35 = bitXor(
													seedA,
													bitAnd(rightShift(seedA, 14), 262143),
													(bitAnd(rightShift(seedA, 28), 15))
												)
												v33 = v34 < 2097152 and 7 or 14
												v37 = bitAnd(v34, leftShift(1, v33) - 1)
												local v590 = rightShift(v34, v33)
												captured.operandA[pc] =
													bitXor(v37, 9, (bitAnd(rightShift(v35, 7), 127)))
												captured.operandB[pc] =
													bitXor(v32, 109, (bitAnd(rightShift(v35, 14), 127)))
												captured.opcodes[pc] = bitXor(v36, 42, (bitAnd(v35, 127)))
												captured.operandC[pc] =
													bitXor(v590, 126, (bitAnd(rightShift(v35, 21), 127)))
												pc = pc - 1
											else
												v36 = captured.operandB[pc]
												local v591 = captured.constantOpcode[pc]
												registers[v36] = captured.operandA[pc]
												registers[v36 + 1] = v591
											end
										elseif v583 >= 5 then
											if v583 < 8 then
												if v583 >= 6 then
													if v583 == 7 then
														registers[captured.operandB[pc]] = registers[captured.opcodes[pc]]
															> captured.constantA[pc]
													else
														registers[captured.operandA[pc]](
															captured.constantOpcode[pc],
															registers[captured.operandB[pc]]
														)
													end
												else
													seedB = registers[captured.operandB[pc]]
												end
											elseif v583 < 9 then
												registers[captured.operandB[pc]] = registers[captured.opcodes[pc]]
													/ captured.operandA[pc]
											else
												if v583 == 10 then
													local v592 = u12
													local v593 = u13

													if v592 then
														for i in nextEntry, v592 do
															local v594 = v592[i]

															if v594 then
																v594[5] = v594
																v594[6] = registers[i]
																v594[4] = 6
																v592[i] = nil
															end
														end
													end

													if v593 then
														for i, v in nextEntry, v593 do
															local v595 = v[6]

															if v593 then
																local v596 = v593[i]

																if v596 then
																	local v597 = createRegisters(v595)
																	moveValues(registers, i, i + v595 - 1, 1, v597)
																	v596[5] = v597
																	v596[4] = 1
																	v593[i] = nil
																end
															end
														end
													end

													return false, false
												end

												if registers[captured.operandA[pc]] >= captured.opcodes[pc] then
													pc = captured.operandB[pc]
												end
											end
										elseif v583 >= 2 then
											if v583 < 3 then
												v36 = captured.operandB[pc]
												local v598 = captured.operandA[pc]
												registers[v36] = registers[captured.opcodes[pc]]
												registers[v36 + 1] = v598
											elseif v583 == 4 then
												v36 = captured.operandB[pc]
												local v599 = registers[captured.operandA[pc]]
												registers[v36] = registers[captured.opcodes[pc]]
												registers[v36 + 1] = v599
											else
												registers[captured.opcodes[pc]] =
													registers[captured.operandA[pc]][registers[captured.operandB[pc]]]
											end
										elseif v583 == 1 then
											v36 = captured.capturedValues[captured.opcodes[pc]]
											v36[5][v36[4]] = captured.constantA[pc]
										else
											v36 = captured.operandA[pc]
											v34 = registers[captured.opcodes[pc]]
											registers[v36 + 1] = v34
											registers[v36] = v34[captured.constantB[pc]]
											registers[captured.operandA[pc + 1]] = registers[captured.opcodes[pc + 1]]
											registers[captured.operandA[pc + 2]] = captured.constantB[pc + 2]
											registers[captured.operandA[pc + 3]] = registers[captured.opcodes[pc + 3]]
											pc = pc + 3
										end
									elseif v583 >= 35 then
										if v583 >= 41 then
											if v583 < 44 then
												if v583 >= 42 then
													if v583 == 43 then
														v36 = captured.opcodes[pc]
														v34, v32 = u8()

														if v34 then
															registers[v36] = v32
															pc = captured.operandB[pc]
														else
															pc = captured.operandA[pc]
														end
													else
														registers[captured.operandB[pc]] =
															bitNot(registers[captured.operandA[pc]])
													end
												else
													registers[captured.operandA[pc]] = captured.operandA
												end
											elseif v583 >= 45 then
												if v583 == 46 then
													registers[captured.operandA[pc]][registers[captured.opcodes[pc]]] =
														captured.constantB[pc]
												else
													registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
														- registers[captured.opcodes[pc]]
												end
											else
												registers[captured.opcodes[pc]] =
													captured.capturedValues[captured.operandB[pc]][captured.constantA[pc]]
											end
										elseif v583 < 38 then
											if v583 < 36 then
												v36 = captured.operandA[pc]
												v34 = captured.operandB[pc]
												v32 = captured.opcodes[pc]
												v35 = v36 + v34
												v33 = registers[v35]
												v37 = v33.n
												v33.n = v34 + v37 - 1
												moveValues(v33, 1, v37, v34, v33)
												moveValues(registers, v36 + 1, v35 - 1, 1, v33)
												registers[v36] = packValues(registers[v36](unpackValues(v33, 1, v33.n)))
											elseif v583 == 37 then
												v36 = captured.operandB[pc]
												v34 = captured.operandA[pc]
												v32 = captured.opcodes[pc]
												v35 = registers[v36]
												moveValues(registers, v36 + 1, v36 + v34, v32 + 1, v35)
											elseif registers[captured.opcodes[pc]] ~= captured.operandB[pc] then
												pc = captured.operandA[pc]
											end
										elseif v583 >= 39 then
											if v583 == 40 then
												registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
													.. registers[captured.operandA[pc]]
											else
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
													% registers[captured.opcodes[pc]]
											end
										else
											registers[captured.operandA[pc]] = captured.constantOpcode[pc]
												+ registers[captured.operandB[pc]]
										end
									elseif v583 < 29 then
										if v583 < 26 then
											if v583 >= 24 then
												if v583 == 25 then
													environment[captured.constantA[pc]][registers[captured.opcodes[pc]]] =
														captured.constantB[pc]
												else
													registers[captured.operandB[pc]][captured.constantA[pc]] =
														captured.opcodes[pc]
												end
											else
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
													- captured.constantOpcode[pc]
											end
										elseif v583 < 27 then
											registers[captured.operandB[pc]] =
												environment[captured.constantOpcode[pc]][registers[captured.operandA[pc]]]
										elseif v583 == 28 then
											if captured.operandA[pc] > registers[captured.opcodes[pc]] then
												pc = captured.operandB[pc]
											end
										else
											v36 = captured.capturedValues[captured.operandA[pc]]
											registers[captured.opcodes[pc]] = v36[5][v36[4]][captured.constantB[pc]]
										end
									elseif v583 >= 32 then
										if v583 < 33 then
											u8 = u8 + u10

											if u10 <= 0 then
												v36 = u9 <= u8
											else
												v36 = u8 <= u9
											end

											if v36 then
												registers[captured.operandB[pc]] = u8
												pc = captured.opcodes[pc]
											else
												pc = captured.operandA[pc]
											end
										elseif v583 == 34 then
											registers[captured.operandA[pc]] = captured.constantB[pc]
										else
											registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
												/ registers[captured.operandB[pc]]
										end
									elseif v583 >= 30 then
										if v583 == 31 then
											local v600 = u12
											local v601 = u13

											if v600 then
												for i in nextEntry, v600 do
													local v602 = v600[i]

													if v602 then
														v602[5] = v602
														v602[6] = registers[i]
														v602[4] = 6
														v600[i] = nil
													end
												end
											end

											if v601 then
												for i, v in nextEntry, v601 do
													local v603 = v[6]

													if v601 then
														local v604 = v601[i]

														if v604 then
															local v605 = createRegisters(v603)
															moveValues(registers, i, i + v603 - 1, 1, v605)
															v604[5] = v605
															v604[4] = 1
															v601[i] = nil
														end
													end
												end
											end

											return false,
												true,
												packValues(
													registers[captured.operandB[pc]],
													registers[captured.opcodes[pc]]
												)
										end

										registers[captured.operandA[pc]][registers[captured.operandB[pc]]] =
											registers[captured.opcodes[pc]]
									else
										registers[captured.operandA[pc]] = captured.capturedValues[captured.opcodes[pc]]
									end
								elseif v583 >= 71 then
									if v583 >= 83 then
										if v583 < 89 then
											if v583 < 86 then
												if v583 >= 84 then
													if v583 == 85 then
														registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
															+ captured.constantB[pc]
													else
														v36 = captured.opcodes[pc]
														v34 = captured.operandB[pc]
														v32 = captured.operandA[pc]
														v35 = v36 + v32 - 1
														v33 = v36 + v34
														v37 = packValues(
															registers[v36](unpackValues(registers, v36 + 1, v36 + v34))
														)
														moveValues(v37, 1, v32, v36, registers)
													end
												else
													registers[captured.operandB[pc]] = registers[captured.opcodes[pc]]
														> captured.operandA[pc]
												end
											elseif v583 < 87 then
												registers[captured.opcodes[pc]] = captured.constantB[pc]
													.. registers[captured.operandA[pc]]
											elseif v583 == 88 then
												if captured.constantB[pc] >= registers[captured.operandA[pc]] then
													pc = captured.opcodes[pc]
												end
											else
												registers[captured.operandB[pc]] = {}
											end
										elseif v583 < 92 then
											if v583 < 90 then
												registers[captured.opcodes[pc]] = captured.constantState
											elseif v583 == 91 then
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
													+ captured.opcodes[pc]
											elseif registers[captured.opcodes[pc]] > captured.constantB[pc] then
												pc = captured.operandA[pc]
											end
										elseif v583 >= 93 then
											if v583 == 94 then
												registers[captured.opcodes[pc]] = captured.operandB[pc]
													^ registers[captured.operandA[pc]]
											else
												registers[captured.operandA[pc]] =
													bitAnd(registers[captured.operandB[pc]], captured.opcodes[pc])
											end
										else
											local v606 = captured.operandB[pc]
											local v607 = registers[captured.operandA[pc]]
											local v608 = bitAnd(captured.constantOpcode[pc], 4294967295)
											local v609 = bitAnd(v607, 4294967295)
											local v610 = bitAnd(v608, 65535)
											local v611 = rightShift(v608, 16)
											local v612 = bitAnd(v609, 65535)
											local v613 = rightShift(v609, 16)
											local v614 = bitAnd(
												v610 * v612 + leftShift(bitAnd(v610 * v613 + v611 * v612, 65535), 16),
												4294967295
											) % 4294967296
											registers[v606] = v614 ~= v614 and 0 or v614 - v614 % 1
										end
									elseif v583 >= 77 then
										if v583 < 80 then
											if v583 >= 78 then
												if v583 == 79 then
													if u12 then
														local v615 = u12
														local v616 = captured.opcodes[pc]
														local v617 = v615[v616]

														if v617 then
															v617[5] = v617
															v617[6] = registers[v616]
															v617[4] = 6
															v615[v616] = nil
														end

														local v618 = u12
														local v619 = captured.operandA[pc]
														local v620 = v618[v619]

														if v620 then
															v620[5] = v620
															v620[6] = registers[v619]
															v620[4] = 6
															v618[v619] = nil
														end

														local v621 = u12
														local v622 = captured.operandB[pc]
														local v623 = v621[v622]

														if v623 then
															v623[5] = v623
															v623[6] = registers[v622]
															v623[4] = 6
															v621[v622] = nil
														end
													end
												else
													registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
														% captured.constantB[pc]
												end
											else
												registers[captured.operandA[pc]] = captured.constantOpcode[pc]
													* captured.constantB[pc]
											end
										elseif v583 < 81 then
											registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]()
										else
											if v583 == 82 then
												local v624 = u12
												local v625 = u13

												if v624 then
													for i in nextEntry, v624 do
														local v626 = v624[i]

														if v626 then
															v626[5] = v626
															v626[6] = registers[i]
															v626[4] = 6
															v624[i] = nil
														end
													end
												end

												if v625 then
													for i, v in nextEntry, v625 do
														local v627 = v[6]

														if v625 then
															local v628 = v625[i]

															if v628 then
																local v629 = createRegisters(v627)
																moveValues(registers, i, i + v627 - 1, 1, v629)
																v628[5] = v629
																v628[4] = 1
																v625[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandA[pc],
													packValues(captured.constantB[pc])
											end

											v36 = captured.operandA[pc]
											local v630 = captured.constantB[pc]
											registers[v36] = captured.constantOpcode[pc]
											registers[v36 + 1] = v630
										end
									elseif v583 < 74 then
										if v583 < 72 then
											seedA = registers[captured.opcodes[pc]]
										elseif v583 == 73 then
											local v631 = captured.opcodes[pc]
											local v632 = bitXor(
												captured.operandA[pc],
												(bitAnd(bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))), 536870911))
											)
											local v633 = captured.constantState[5]
											local v634 = bitXor(v633[v631], 109162203)
											v633[v631] = v634
											local v635 = captured.constantState[4]
											local v636 = v634 + 1
											local v637 = readByte(v635, v636)
											local v638

											if v637 < 128 then
												v638 = v636 + 1
											else
												local v639 = readByte(v635, v636 + 1)

												if v639 < 128 then
													v637 = v637 - 128 + v639 * 128
													v638 = v636 + 2
												else
													local v640 = readByte(v635, v636 + 2)

													if v640 < 128 then
														v637 = v637 - 128 + (v639 - 128) * 16384 + v640 * 128
														v638 = v636 + 3
													else
														local v641 = readByte(v635, v636 + 3)
														v637 = (v637 - 128) * 16384
															+ (v639 - 128) * 128
															+ (v640 - 128)
															+ v641 % 128 * 2097152
															+ (v641 - v641 % 128) * 2097152
														v638 = v636 + 4
													end
												end
											end

											local v642 = v632 * 16843009
											local v643 = v638 + v637
											local v644 = v643 - v637 % 4

											for i = v638, v644 - 1, 4 do
												writeUInt32(v635, i, (bitXor(readUInt32(v635, i), v642)))
												local _ = i
											end

											for i = v644, v643 - 1 do
												writeByte(v635, i, (bitXor(readByte(v635, i), v632)))
												local _ = i
											end

											captured.opcodes[pc] = 163
											captured.operandA[pc] = 35
											captured.operandB[pc] = 219
											captured.operandC[pc] = 190
										else
											registers[captured.operandB[pc]] =
												leftShift(registers[captured.operandA[pc]], captured.opcodes[pc])
										end
									else
										if v583 < 75 then
											local v645 = u12
											local v646 = u13

											if v645 then
												for i in nextEntry, v645 do
													local v647 = v645[i]

													if v647 then
														v647[5] = v647
														v647[6] = registers[i]
														v647[4] = 6
														v645[i] = nil
													end
												end
											end

											if v646 then
												for i, v in nextEntry, v646 do
													local v648 = v[6]

													if v646 then
														local v649 = v646[i]

														if v649 then
															local v650 = createRegisters(v648)
															moveValues(registers, i, i + v648 - 1, 1, v650)
															v649[5] = v650
															v649[4] = 1
															v646[i] = nil
														end
													end
												end
											end

											return false, true, packValues(registers[captured.opcodes[pc]])
										end

										if v583 == 76 then
											registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
											registers[captured.operandA[pc + 1]] = captured.constantB[pc + 1]
											registers[captured.operandA[pc + 2]] = registers[captured.opcodes[pc + 2]]
											v36 = captured.opcodes[pc + 3]
											v34 = registers[v36]
											v32 = registers[v36 + 1]
											v35 = registers[v36 + 2]
											registers[v36] = v34(v32, v35)
											pc = pc + 3
										else
											environment[captured.constantB[pc]][captured.constantA[pc]] =
												registers[captured.opcodes[pc]]
										end
									end
								elseif v583 < 59 then
									if v583 < 53 then
										if v583 < 50 then
											if v583 >= 48 then
												if v583 == 49 then
													registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
														// captured.opcodes[pc]
												else
													v36 = captured.capturedValues[captured.operandA[pc]]
													registers[captured.operandB[pc]] = v36[5][v36[4]]
												end
											else
												pc = registers[captured.operandA[pc]]
											end
										elseif v583 >= 51 then
											if v583 ~= 52 then
												local v651 = u12
												local v652 = u13

												if v651 then
													for i in nextEntry, v651 do
														local v653 = v651[i]

														if v653 then
															v653[5] = v653
															v653[6] = registers[i]
															v653[4] = 6
															v651[i] = nil
														end
													end
												end

												if v652 then
													for i, v in nextEntry, v652 do
														local v654 = v[6]

														if v652 then
															local v655 = v652[i]

															if v655 then
																local v656 = createRegisters(v654)
																moveValues(registers, i, i + v654 - 1, 1, v656)
																v655[5] = v656
																v655[4] = 1
																v652[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandA[pc],
													packValues(registers[captured.opcodes[pc]])
											end

											v36 = captured.operandB[pc] + 1
											v34 = captured.opcodes[pc]

											for i = 1, captured.operandA[pc] do
												local v657 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
												local v658 = bitXor(v657, (rightShift(v657, 13)))
												v34 = bitAnd(bitXor(v658, (leftShift(v658, 14))), 536870911)
												captured.opcodes[v36] =
													bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
												captured.operandA[v36] =
													bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
												captured.operandB[v36] =
													bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 14), 127)))
												captured.operandC[v36] =
													bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 21), 127)))
												v36 = v36 + 1
												local _ = i
											end

											captured.operandC[pc] = 190
										elseif captured.operandB[pc] >= registers[captured.operandA[pc]] then
											pc = captured.opcodes[pc]
										end
									elseif v583 < 56 then
										if v583 < 54 then
											environment[captured.constantOpcode[pc]][registers[captured.operandB[pc]]] =
												registers[captured.operandA[pc]]
										elseif v583 == 55 then
											registers[captured.operandA[pc]] = captured.opcodes[pc]
												- registers[captured.operandB[pc]]
										else
											registers[captured.operandA[pc]] = captured.operandB
										end
									elseif v583 < 57 then
										if registers[captured.operandB[pc]] > registers[captured.operandA[pc]] then
											pc = captured.opcodes[pc]
										end
									elseif v583 == 58 then
										registers[captured.opcodes[pc]](
											registers[captured.operandA[pc]],
											registers[captured.operandB[pc]]
										)
									else
										registers[captured.operandA[pc]] =
											registers[captured.operandB[pc]][captured.constantOpcode[pc]]
									end
								elseif v583 < 65 then
									if v583 < 62 then
										if v583 < 60 then
											registers[captured.operandA[pc]]()
										elseif v583 == 61 then
											local v659 = captured.operandA[pc]
											local v660 = registers[captured.opcodes[pc]]
											registers[v659 + 1] = v660
											registers[v659] = v660[captured.constantB[pc]]
											registers[captured.operandA[pc + 1]] = registers[captured.opcodes[pc + 1]]
											registers[captured.operandA[pc + 2]] = captured.constantB[pc + 2]
											registers[captured.operandA[pc + 3]] = registers[captured.opcodes[pc + 3]]
											v36 = captured.opcodes[pc + 4]
											v34 = registers[v36]
											v32 = registers[v36 + 1]
											v35 = registers[v36 + 2]
											registers[v36] = v34(v32, v35)
											pc = pc + 4
										else
											registers[captured.operandB[pc]] = captured.opcodes
										end
									else
										if v583 < 63 then
											local v661 = u12
											local v662 = u13

											if v661 then
												for i in nextEntry, v661 do
													local v663 = v661[i]

													if v663 then
														v663[5] = v663
														v663[6] = registers[i]
														v663[4] = 6
														v661[i] = nil
													end
												end
											end

											if v662 then
												for i, v in nextEntry, v662 do
													local v664 = v[6]

													if v662 then
														local v665 = v662[i]

														if v665 then
															local v666 = createRegisters(v664)
															moveValues(registers, i, i + v664 - 1, 1, v666)
															v665[5] = v666
															v665[4] = 1
															v662[i] = nil
														end
													end
												end
											end

											return false,
												true,
												packValues(
													registers[captured.operandA[pc]],
													unpackValues(
														registers[captured.opcodes[pc]],
														1,
														registers[captured.opcodes[pc]].n
													)
												)
										end

										if v583 == 64 then
											registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
												~= captured.operandB[pc]
										else
											registers[captured.operandA[pc]](captured.constantOpcode[pc])
										end
									end
								elseif v583 >= 68 then
									if v583 < 69 then
										registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
											* captured.constantB[pc]
									elseif v583 == 70 then
										registers[captured.opcodes[pc]] =
											bitOr(registers[captured.operandA[pc]], registers[captured.operandB[pc]])
									else
										registers[captured.operandA[pc]][registers[captured.operandB[pc]]] =
											captured.opcodes[pc]
									end
								elseif v583 < 66 then
									captured.capturedValues[captured.opcodes[pc]][captured.constantA[pc]] =
										captured.operandB[pc]
								elseif v583 == 67 then
									registers[captured.operandA[pc]] =
										bitXor(registers[captured.opcodes[pc]], captured.operandB[pc])
								else
									local v667 = captured.opcodes[pc]
									local v668 = registers[captured.operandB[pc]]
									local v669 = bitAnd(registers[captured.operandA[pc]], 4294967295)
									local v670 = bitAnd(v668, 4294967295)
									local v671 = bitAnd(v669, 65535)
									local v672 = rightShift(v669, 16)
									local v673 = bitAnd(v670, 65535)
									local v674 = rightShift(v670, 16)
									local v675 = bitAnd(
										v671 * v673 + leftShift(bitAnd(v671 * v674 + v672 * v673, 65535), 16),
										4294967295
									) % 4294967296
									registers[v667] = v675 ~= v675 and 0 or v675 - v675 % 1
								end
							elseif v583 < 143 then
								if v583 < 119 then
									if v583 >= 107 then
										if v583 >= 113 then
											if v583 < 116 then
												if v583 < 114 then
													registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
														// registers[captured.opcodes[pc]]
												elseif v583 == 115 then
													registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
														~= registers[captured.operandB[pc]]
												else
													registers[captured.operandA[pc]] = captured.constantB[pc]
													registers[captured.operandA[pc + 1]] =
														registers[captured.opcodes[pc + 1]]
													v36 = captured.opcodes[pc + 2]
													v34 = registers[v36]
													v32 = registers[v36 + 1]
													v35 = registers[v36 + 2]
													registers[v36] = v34(v32, v35)
													pc = pc + 2
												end
											elseif v583 < 117 then
												captured.capturedValues[captured.operandB[pc]][registers[captured.opcodes[pc]]] =
													registers[captured.operandA[pc]]
											elseif v583 == 118 then
												local v676

												if registers[captured.operandA[pc]] then
													v676 = captured.opcodes[pc]
												else
													v676 = captured.operandB[pc]
												end

												pc = v676
											else
												registers[captured.opcodes[pc]] =
													rightShift(registers[captured.operandB[pc]], captured.operandA[pc])
											end
										elseif v583 < 110 then
											if v583 >= 108 then
												if v583 ~= 109 then
													local v677 = u12
													local v678 = u13

													if v677 then
														for i in nextEntry, v677 do
															local v679 = v677[i]

															if v679 then
																v679[5] = v679
																v679[6] = registers[i]
																v679[4] = 6
																v677[i] = nil
															end
														end
													end

													if v678 then
														for i, v in nextEntry, v678 do
															local v680 = v[6]

															if v678 then
																local v681 = v678[i]

																if v681 then
																	local v682 = createRegisters(v680)
																	moveValues(registers, i, i + v680 - 1, 1, v682)
																	v681[5] = v682
																	v681[4] = 1
																	v678[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(captured.constantB[pc], captured.constantOpcode[pc])
												end

												registers[captured.operandB[pc]] = captured.operandC
											else
												v36 = captured.operandA[pc]
												local v683 = captured.operandB[pc]
												registers[v36] = captured.opcodes[pc]
												registers[v36 + 1] = v683
											end
										elseif v583 >= 111 then
											if v583 == 112 then
												captured.capturedValues[captured.opcodes[pc]][captured.constantA[pc]] =
													registers[captured.operandB[pc]]
											else
												registers[captured.operandB[pc]] =
													registers[captured.operandA[pc]](captured.constantOpcode[pc])
											end
										elseif u12 then
											local v684 = u12
											local v685 = captured.opcodes[pc]
											local v686 = v684[v685]

											if v686 then
												v686[5] = v686
												v686[6] = registers[v685]
												v686[4] = 6
												v684[v685] = nil
											end

											local v687 = u12
											local v688 = captured.operandB[pc]
											local v689 = v687[v688]

											if v689 then
												v689[5] = v689
												v689[6] = registers[v688]
												v689[4] = 6
												v687[v688] = nil
											end
										end
									elseif v583 < 101 then
										if v583 < 98 then
											if v583 < 96 then
												local v690 = u12
												local v691 = u13

												if v690 then
													for i in nextEntry, v690 do
														local v692 = v690[i]

														if v692 then
															v692[5] = v692
															v692[6] = registers[i]
															v692[4] = 6
															v690[i] = nil
														end
													end
												end

												if v691 then
													for i, v in nextEntry, v691 do
														local v693 = v[6]

														if v691 then
															local v694 = v691[i]

															if v694 then
																local v695 = createRegisters(v693)
																moveValues(registers, i, i + v693 - 1, 1, v695)
																v694[5] = v695
																v694[4] = 1
																v691[i] = nil
															end
														end
													end
												end

												return false, true, packValues(captured.constantB[pc])
											end

											if v583 == 97 then
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]](
													unpackValues(
														registers[captured.opcodes[pc]],
														1,
														registers[captured.opcodes[pc]].n
													)
												)
											else
												registers[captured.operandA[pc]](registers[captured.operandB[pc]])
											end
										elseif v583 < 99 then
											if registers[captured.operandA[pc]] ~= registers[captured.operandB[pc]] then
												pc = captured.opcodes[pc]
											end
										elseif v583 == 100 then
											registers[captured.operandA[pc]] = environment[captured.constantOpcode[pc]]
										else
											local v696 = nil
											local v697 = captured.operandA[pc]
											local v698 = captured.constantB[pc]
											local v699 = captured.constantOpcode[pc]
											local v700 = u12
											local v701 = u13
											local v702 = v699[0]

											if v702 then
												local v703 = #v702 / 3

												if v703 > 0 then
													v696 = {}

													for i = 1, v703 do
														local v704 = (i - 1) * 3
														local v705 = v702[v704 + 2]
														local v706 = v702[v704 + 1]
														local v707

														if v705 == 2 then
															v700 = v700 or {}
															local v708 = v700[v706]

															if not v708 then
																v708 = {
																	[5] = registers,
																	[4] = v706,
																}
																v700[v706] = v708
															end

															v696[i] = v708
															v707 = i
														elseif v705 == 0 then
															v696[i] = registers[v706]
															v707 = i
														elseif v705 == 3 then
															v696[i] = captured.capturedValues[v706]
															v707 = i
														elseif v705 == 1 then
															v701 = v701 or {}
															local v709 = v701[v706]

															if not v709 then
																v709 = {
																	[5] = registers,
																	[4] = v706,
																	[6] = v702[v704 + 3],
																}
																v701[v706] = v709
															end

															v696[i] = v709
															v707 = i
														else
															v707 = i
														end
													end
												end
											end

											local v710 = v699[-2]
											v699[v710] = v696
											local v711 = v698(unpackValues(v699, 1, v699[-1]))
											v699[v710] = nil
											registers[v697] = v711
											u12 = v700
											u13 = v701
										end
									elseif v583 < 104 then
										if v583 >= 102 then
											if v583 == 103 then
												registers[captured.operandA[pc]] = captured.opcodes[pc]
													* registers[captured.operandB[pc]]
											elseif registers[captured.operandA[pc]] ~= captured.constantOpcode[pc] then
												pc = captured.operandB[pc]
											end
										else
											registers[captured.opcodes[pc]] =
												packValues(registers[captured.operandB[pc]]())
										end
									elseif v583 >= 105 then
										if v583 == 106 then
											v36 = captured.capturedValues[captured.opcodes[pc]]
											v36[5][v36[4]][captured.constantB[pc]] = captured.constantA[pc]
										else
											environment[captured.constantOpcode[pc]] = registers[captured.operandA[pc]]
										end
									else
										registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
											== captured.constantB[pc]
									end
								elseif v583 < 131 then
									if v583 < 125 then
										if v583 < 122 then
											if v583 >= 120 then
												if v583 == 121 then
													registers[captured.opcodes[pc]] = registers[captured.operandB[pc]]
														% captured.operandA[pc]
												else
													registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
														/ captured.constantOpcode[pc]
												end
											else
												registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
													>= captured.opcodes[pc]
											end
										elseif v583 < 123 then
											registers[captured.operandA[pc]] = bitXor(
												registers[captured.operandB[pc]],
												registers[captured.opcodes[pc]]
											)
										elseif v583 == 124 then
											v36 = captured.opcodes[pc] + 1
											v34 = bitXor(
												captured.operandA[pc],
												(bitAnd(bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))), 536870911))
											)

											for i = 1, captured.operandB[pc] do
												local v712 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
												local v713 = bitXor(v712, (rightShift(v712, 13)))
												v34 = bitAnd(bitXor(v713, (leftShift(v713, 14))), 536870911)
												captured.opcodes[v36] =
													bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
												captured.operandA[v36] =
													bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 7), 127)))
												captured.operandB[v36] =
													bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 14), 127)))
												captured.operandC[v36] =
													bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 21), 127)))
												v36 = v36 + 1
												local _ = i
											end

											captured.operandC[pc] = 190
										else
											registers[captured.opcodes[pc]] = #registers[captured.operandA[pc]]
										end
									elseif v583 >= 128 then
										if v583 >= 129 then
											if v583 == 130 then
												u7 = {
													[6] = u11,
													[5] = u9,
													[9] = u7,
													[8] = u8,
													[7] = u10,
												}
												v36 = captured.opcodes[pc]
												v34 = wrapCoroutine(closeUpvalues)
												v34(
													captured.runtime,
													registers[v36],
													registers[v36 + 1],
													registers[v36 + 2]
												)
												u8 = v34
												u11 = captured.operandA[pc]
												pc = captured.operandB[pc]
											else
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
													<= captured.opcodes[pc]
											end
										else
											registers[captured.operandA[pc]](
												registers[captured.opcodes[pc]],
												unpackValues(
													registers[captured.operandB[pc]],
													1,
													registers[captured.operandB[pc]].n
												)
											)
										end
									elseif v583 >= 126 then
										if v583 == 127 then
											registers[captured.operandA[pc]][captured.constantB[pc]] =
												registers[captured.opcodes[pc]]
										else
											registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
												* registers[captured.opcodes[pc]]
										end
									else
										registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
									end
								elseif v583 >= 137 then
									if v583 < 140 then
										if v583 < 138 then
											registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
												- captured.operandB[pc]
										elseif v583 == 139 then
											v36 = captured.operandA[pc]
											v34 = captured.opcodes[pc]
											v32 = captured.operandB[pc]
											v35 = v36 + v32 - 1
											v33 = v36 + v34
											v37 = registers[v33]
											local n = v37.n
											v37.n = v34 + n - 1
											moveValues(v37, 1, n, v34, v37)
											moveValues(registers, v36 + 1, v33 - 1, 1, v37)
											moveValues(
												packValues(registers[v36](unpackValues(v37, 1, v37.n))),
												1,
												v32,
												v36,
												registers
											)
										else
											registers[captured.opcodes[pc]] = -registers[captured.operandA[pc]]
										end
									elseif v583 < 141 then
										registers[captured.opcodes[pc]] =
											registers[captured.operandB[pc]](registers[captured.operandA[pc]])
									else
										if v583 == 142 then
											local v714 = u12
											local v715 = u13

											if v714 then
												for i in nextEntry, v714 do
													local v716 = v714[i]

													if v716 then
														v716[5] = v716
														v716[6] = registers[i]
														v716[4] = 6
														v714[i] = nil
													end
												end
											end

											if v715 then
												for i, v in nextEntry, v715 do
													local v717 = v[6]

													if v715 then
														local v718 = v715[i]

														if v718 then
															local v719 = createRegisters(v717)
															moveValues(registers, i, i + v717 - 1, 1, v719)
															v718[5] = v719
															v718[4] = 1
															v715[i] = nil
														end
													end
												end
											end

											return false,
												true,
												packValues(
													registers[captured.operandA[pc]],
													captured.constantOpcode[pc]
												)
										end

										registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
											>= captured.constantOpcode[pc]
									end
								elseif v583 >= 134 then
									if v583 < 135 then
										local v720 = u12
										local v721 = u13

										if v720 then
											for i in nextEntry, v720 do
												local v722 = v720[i]

												if v722 then
													v722[5] = v722
													v722[6] = registers[i]
													v722[4] = 6
													v720[i] = nil
												end
											end
										end

										if v721 then
											for i, v in nextEntry, v721 do
												local v723 = v[6]

												if v721 then
													local v724 = v721[i]

													if v724 then
														local v725 = createRegisters(v723)
														moveValues(registers, i, i + v723 - 1, 1, v725)
														v724[5] = v725
														v724[4] = 1
														v721[i] = nil
													end
												end
											end
										end

										return false,
											true,
											packValues(captured.constantA[pc], registers[captured.opcodes[pc]])
									end

									if v583 == 136 then
										registers[captured.opcodes[pc]] =
											registers[captured.operandA[pc]][captured.operandB[pc]]
									else
										registers[captured.operandA[pc]] =
											captured.capturedValues[captured.operandB[pc]][registers[captured.opcodes[pc]]]
									end
								elseif v583 >= 132 then
									if v583 == 133 then
										registers[captured.opcodes[pc]](
											captured.constantB[pc],
											unpackValues(
												registers[captured.operandA[pc]],
												1,
												registers[captured.operandA[pc]].n
											)
										)
									else
										local v726

										if registers[captured.operandB[pc]] then
											v726 = captured.operandA[pc]
										else
											v726 = captured.opcodes[pc]
										end

										pc = v726
									end
								else
									registers[captured.operandB[pc]] = seedB
								end
							elseif v583 >= 167 then
								if v583 >= 179 then
									if v583 >= 185 then
										if v583 >= 188 then
											if v583 < 189 then
												registers[captured.operandB[pc]] = seedA
											elseif v583 ~= 190 then
												v36 = captured.opcodes[pc] + 1
												v34 = bitXor(
													captured.operandA[pc],
													(
														bitAnd(
															bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))),
															536870911
														)
													)
												)

												for i = 1, captured.operandB[pc] do
													local v727 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
													local v728 = bitXor(v727, (rightShift(v727, 13)))
													v34 = bitAnd(bitXor(v728, (leftShift(v728, 14))), 536870911)
													captured.opcodes[v36] =
														bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 0), 127)))
													captured.operandA[v36] = bitXor(
														captured.operandA[v36],
														(bitAnd(rightShift(v34, 7), 127))
													)
													captured.operandB[v36] = bitXor(
														captured.operandB[v36],
														(bitAnd(rightShift(v34, 14), 127))
													)
													captured.operandC[v36] = bitXor(
														captured.operandC[v36],
														(bitAnd(rightShift(v34, 21), 127))
													)
													v36 = v36 + 1
													local _ = i
												end

												captured.operandC[pc] = 190
											end
										elseif v583 < 186 then
											captured.capturedValues[captured.operandB[pc]][captured.constantA[pc]] =
												captured.constantOpcode[pc]
										elseif v583 == 187 then
											local v729 = captured.opcodes[pc]
											local v730 = captured.constantA[pc]
											local v731 = bitAnd(captured.constantB[pc], 4294967295)
											local v732 = bitAnd(v730, 4294967295)
											local v733 = bitAnd(v731, 65535)
											local v734 = rightShift(v731, 16)
											local v735 = bitAnd(v732, 65535)
											local v736 = rightShift(v732, 16)
											local v737 = bitAnd(
												v733 * v735 + leftShift(bitAnd(v733 * v736 + v734 * v735, 65535), 16),
												4294967295
											) % 4294967296
											registers[v729] = v737 ~= v737 and 0 or v737 - v737 % 1
										elseif registers[captured.opcodes[pc]] > captured.operandB[pc] then
											pc = captured.operandA[pc]
										end
									elseif v583 < 182 then
										if v583 >= 180 then
											if v583 == 181 then
												registers[captured.operandA[pc]] = bitAnd(
													registers[captured.operandB[pc]],
													captured.constantOpcode[pc]
												)
											elseif captured.constantOpcode[pc] > registers[captured.operandA[pc]] then
												pc = captured.operandB[pc]
											end
										else
											registers[captured.opcodes[pc]][captured.operandA[pc]] =
												registers[captured.operandB[pc]]
										end
									elseif v583 < 183 then
										v36 = captured.opcodes[pc]
										v34 = registers[v36]
										v32 = registers[v36 + 1]
										v35 = registers[v36 + 2]
										registers[v36] = v34(v32, v35)
									elseif v583 == 184 then
										registers[captured.operandB[pc]](
											unpackValues(
												registers[captured.opcodes[pc]],
												1,
												registers[captured.opcodes[pc]].n
											)
										)
									else
										local v738 = captured.opcodes[pc]
										local v739 = bitXor(
											captured.operandA[pc],
											(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
										)
										local v740 = captured.constantState[5]
										local v741 = bitXor(v740[v738], 109162203)
										v740[v738] = v741
										local v742 = captured.constantState[4]
										local v743 = v741 + 1
										local v744 = readByte(v742, v743)
										local v745

										if v744 < 128 then
											v745 = v743 + 1
										else
											local v746 = readByte(v742, v743 + 1)

											if v746 < 128 then
												v744 = v744 - 128 + v746 * 128
												v745 = v743 + 2
											else
												local v747 = readByte(v742, v743 + 2)

												if v747 < 128 then
													v744 = v744 - 128 + (v746 - 128) * 16384 + v747 * 128
													v745 = v743 + 3
												else
													local v748 = readByte(v742, v743 + 3)
													v744 = (v744 - 128) * 16384
														+ (v746 - 128) * 128
														+ (v747 - 128)
														+ v748 % 128 * 2097152
														+ (v748 - v748 % 128) * 2097152
													v745 = v743 + 4
												end
											end
										end

										local v749 = v739 * 16843009
										local v750 = v745 + v744
										local v751 = v750 - v744 % 4

										for i = v745, v751 - 1, 4 do
											writeUInt32(v742, i, (bitXor(readUInt32(v742, i), v749)))
											local _ = i
										end

										for i = v751, v750 - 1 do
											writeByte(v742, i, (bitXor(readByte(v742, i), v739)))
											local _ = i
										end

										captured.opcodes[pc] = 133
										captured.operandA[pc] = 151
										captured.operandB[pc] = 44
										captured.operandC[pc] = 190
									end
								elseif v583 >= 173 then
									if v583 >= 176 then
										if v583 >= 177 then
											if v583 == 178 then
												v36 = captured.operandA[pc]
												v34 = captured.opcodes[pc]
												v32 = captured.operandB[pc]
												v35 = bitXor(
													seedA,
													bitAnd(rightShift(seedA, 14), 262143),
													(bitAnd(rightShift(seedA, 28), 15))
												)
												v33 = v34 < 16384 and 7 or (v34 < 2097152 and 14 or 21)
												v37 = rightShift(v34, v33)
												local v752 = bitAnd(v34, leftShift(1, v33) - 1)
												captured.operandB[pc] =
													bitXor(v32, 120, (bitAnd(rightShift(v35, 14), 127)))
												captured.opcodes[pc] = bitXor(v752, 92, (bitAnd(v35, 127)))
												captured.operandC[pc] =
													bitXor(v37, 2, (bitAnd(rightShift(v35, 21), 127)))
												captured.operandA[pc] =
													bitXor(v36, 109, (bitAnd(rightShift(v35, 7), 127)))
												pc = pc - 1
											else
												registers[captured.opcodes[pc]] =
													environment[captured.constantA[pc]][captured.constantB[pc]]
											end
										else
											registers[captured.operandA[pc]] =
												bitOr(registers[captured.operandB[pc]], captured.constantOpcode[pc])
										end
									elseif v583 >= 174 then
										if v583 == 175 then
											v36 = captured.operandA[pc]
											v34 = captured.operandB[pc]
											v32 = captured.opcodes[pc]
											v35 = v36 + v34
											registers[v36] =
												packValues(registers[v36](unpackValues(registers, v36 + 1, v35)))
										else
											registers[captured.opcodes[pc]] = registers[captured.operandA[pc]]
												< captured.operandB[pc]
										end
									else
										registers[captured.operandA[pc]][captured.constantB[pc]] =
											captured.constantOpcode[pc]
									end
								elseif v583 < 170 then
									if v583 < 168 then
										registers[captured.operandB[pc]] = registers[captured.opcodes[pc]]
											> registers[captured.operandA[pc]]
									else
										if v583 == 169 then
											local v753 = u12
											local v754 = u13

											if v753 then
												for i in nextEntry, v753 do
													local v755 = v753[i]

													if v755 then
														v755[5] = v755
														v755[6] = registers[i]
														v755[4] = 6
														v753[i] = nil
													end
												end
											end

											if v754 then
												for i, v in nextEntry, v754 do
													local v756 = v[6]

													if v754 then
														local v757 = v754[i]

														if v757 then
															local v758 = createRegisters(v756)
															moveValues(registers, i, i + v756 - 1, 1, v758)
															v757[5] = v758
															v757[4] = 1
															v754[i] = nil
														end
													end
												end
											end

											return true, true, captured.opcodes[pc], packValues()
										end

										registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
											== registers[captured.operandB[pc]]
									end
								elseif v583 >= 171 then
									if v583 == 172 then
										if u12 then
											local v759 = u12
											local v760 = captured.operandB[pc]
											local v761 = v759[v760]

											if v761 then
												v761[5] = v761
												v761[6] = registers[v760]
												v761[4] = 6
												v759[v760] = nil
											end
										end
									else
										v36 = captured.capturedValues[captured.operandA[pc]]
										v36[5][v36[4]][captured.constantOpcode[pc]] = registers[captured.operandB[pc]]
									end
								else
									local v762 = registers[captured.operandA[pc]] % 4294967296
									registers[captured.opcodes[pc]] = v762 ~= v762 and 0 or v762 - v762 % 1
								end
							else
								if v583 < 155 then
									if v583 >= 149 then
										if v583 < 152 then
											if v583 < 150 then
												v36 = captured.operandB[pc]
												local v763 = registers[captured.operandA[pc]]
												registers[v36] = captured.constantOpcode[pc]
												registers[v36 + 1] = v763
											elseif v583 == 151 then
												registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
													.. captured.constantOpcode[pc]
											else
												u7 = {
													[6] = u11,
													[5] = u9,
													[9] = u7,
													[8] = u8,
													[7] = u10,
												}
												v36 = captured.opcodes[pc]
												u10 = registers[v36 + 2] + 0
												u9 = registers[v36 + 1] + 0
												u8 = registers[v36] - u10
												pc = captured.operandA[pc]
											end
										elseif v583 >= 153 then
											if v583 == 154 then
												local v764 = captured.opcodes[pc]
												local v765 = captured.operandA[pc]
												local v766 = captured.constantState[5]
												local v767 = bitXor(v766[v764], 109162203)
												v766[v764] = v767
												local v768 = captured.constantState[4]
												local v769 = v767 + 1
												local v770 = readByte(v768, v769)
												local v771

												if v770 < 128 then
													v771 = v769 + 1
												else
													local v772 = readByte(v768, v769 + 1)

													if v772 < 128 then
														v770 = v770 - 128 + v772 * 128
														v771 = v769 + 2
													else
														local v773 = readByte(v768, v769 + 2)

														if v773 < 128 then
															v770 = v770 - 128 + (v772 - 128) * 16384 + v773 * 128
															v771 = v769 + 3
														else
															local v774 = readByte(v768, v769 + 3)
															v770 = (v770 - 128) * 16384
																+ (v772 - 128) * 128
																+ (v773 - 128)
																+ v774 % 128 * 2097152
																+ (v774 - v774 % 128) * 2097152
															v771 = v769 + 4
														end
													end
												end

												local v775 = v765 * 16843009
												local v776 = v771 + v770
												local v777 = v776 - v770 % 4

												for i = v771, v777 - 1, 4 do
													writeUInt32(v768, i, (bitXor(readUInt32(v768, i), v775)))
													local _ = i
												end

												for i = v777, v776 - 1 do
													writeByte(v768, i, (bitXor(readByte(v768, i), v765)))
													local _ = i
												end

												captured.opcodes[pc] = 212
												captured.operandA[pc] = 21
												captured.operandB[pc] = 154
												captured.operandC[pc] = 190
											else
												registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
													* captured.operandB[pc]
											end
										else
											registers[captured.operandA[pc]] =
												packValues(registers[captured.opcodes[pc]](captured.constantB[pc]))
										end
									elseif v583 >= 146 then
										if v583 < 147 then
											v36 = captured.operandA[pc]
											local v778 = registers[captured.opcodes[pc]]
											registers[v36] = captured.operandB[pc]
											registers[v36 + 1] = v778
										elseif v583 == 148 then
											registers[captured.opcodes[pc]] = captured.operandB[pc]
										else
											registers[captured.opcodes[pc]] = captured.constantB[pc]
												* registers[captured.operandA[pc]]
										end
									elseif v583 < 144 then
										if registers[captured.opcodes[pc]] >= registers[captured.operandB[pc]] then
											pc = captured.operandA[pc]
										end
									elseif v583 == 145 then
										v36 = captured.operandA[pc]
										local v779 = captured.opcodes[pc]
										registers[v36] = captured.constantB[pc]
										registers[v36 + 1] = v779
									else
										registers[captured.operandB[pc]] = packValues(
											registers[captured.opcodes[pc]](registers[captured.operandA[pc]])
										)
									end

									v582 = 1
									continue
								end

								if v583 < 161 then
									if v583 < 158 then
										if v583 >= 156 then
											if v583 == 157 then
												registers[captured.operandA[pc]] = registers[captured.opcodes[pc]]
													+ registers[captured.operandB[pc]]
											else
												pc = captured.operandB[pc]
											end
										else
											registers[captured.opcodes[pc]] = captured.operandB[pc]
												+ registers[captured.operandA[pc]]
										end

										v582 = 1
										continue
									end

									if v583 >= 159 then
										if v583 == 160 then
											registers[captured.operandB[pc]] = bitAnd(
												registers[captured.operandA[pc]],
												registers[captured.opcodes[pc]]
											)
										else
											local v780 = captured.operandA[pc]
											local v781 = captured.operandB[pc]
											local v782 = bitAnd(registers[captured.opcodes[pc]], 4294967295)
											local v783 = bitAnd(v781, 4294967295)
											local v784 = bitAnd(v782, 65535)
											local v785 = rightShift(v782, 16)
											local v786 = bitAnd(v783, 65535)
											local v787 = rightShift(v783, 16)
											local v788 = bitAnd(
												v784 * v786 + leftShift(bitAnd(v784 * v787 + v785 * v786, 65535), 16),
												4294967295
											) % 4294967296
											registers[v780] = v788 ~= v788 and 0 or v788 - v788 % 1
										end

										v582 = 1
										continue
									end

									mode = captured.operandA[pc]
									pc = captured.operandB[pc] + 1
									v38 = 2
									break
								end

								if v583 >= 164 then
									if v583 < 165 then
										local v789 = captured.operandA[pc]
										local v790 = v789 + captured.opcodes[pc]
										local v791 = u12
										local v792 = u13

										if v791 then
											for i in nextEntry, v791 do
												local v793 = v791[i]

												if v793 then
													v793[5] = v793
													v793[6] = registers[i]
													v793[4] = 6
													v791[i] = nil
												end
											end
										end

										if v792 then
											for i, v in nextEntry, v792 do
												local v794 = v[6]

												if v792 then
													local v795 = v792[i]

													if v795 then
														local v796 = createRegisters(v794)
														moveValues(registers, i, i + v794 - 1, 1, v796)
														v795[5] = v796
														v795[4] = 1
														v792[i] = nil
													end
												end
											end
										end

										return true, false, v789, v790
									end

									if v583 == 166 then
										registers[captured.operandB[pc]](
											registers[captured.operandA[pc]],
											captured.constantOpcode[pc]
										)
									else
										u8 = u7[8]
										u9 = u7[5]
										u10 = u7[7]
										u11 = u7[6]
										u7 = u7[9]
									end
								elseif v583 >= 162 then
									if v583 == 163 then
										v36 = captured.operandB[pc]
										v34 = captured.operandA[pc]
										v32 = captured.opcodes[pc]
										v35 = registers[v36]
										v33 = v36 + v34
										v37 = registers[v33]
										moveValues(registers, v36 + 1, v33 - 1, v32 + 1, v35)
										moveValues(v37, 1, v37.n, v32 + v34, v35)
									elseif registers[captured.operandB[pc]] >= captured.constantOpcode[pc] then
										pc = captured.operandA[pc]
									end
								else
									registers[captured.opcodes[pc]] = registers
								end
							end

							v582 = 1
							continue
						elseif v582 == 1 then
							v582 = -1
							pc = pc + 1
							break
						else
							break
						end
					end

					if v38 ~= -1 then
						break
					end
				end

				if v38 ~= -1 then
					continue
				end

				v38 = 6
				continue
			elseif v38 == 6 then
				v38 = -1

				while true do
					local v797 = 0

					while true do
						if v797 == 0 then
							v797 = -1
							local v798 = captured.opcodes[pc]

							if v798 >= 96 then
								if v798 >= 144 then
									if v798 >= 168 then
										if v798 >= 180 then
											if v798 < 186 then
												if v798 < 183 then
													if v798 >= 181 then
														if v798 == 182 then
															v36 = registers[captured.operandC[pc]]
															registers[captured.operandB[pc]] = packValues(
																unpackValues(v36, captured.operandA[pc], v36.n)
															)
														else
															local v799 = captured.operandB[pc]
															local v800 = captured.operandC[pc]
															local v801, v802 = registers[captured.operandA[pc]]()
															registers[v799] = v801
															registers[v800] = v802
														end
													else
														v36 = captured.operandC[pc]
														v34, v32 = u8()

														if v34 then
															registers[v36] = v32
															pc = captured.operandA[pc]
														else
															pc = captured.operandB[pc]
														end
													end
												elseif v798 < 184 then
													registers[captured.operandC[pc]] =
														bitNot(registers[captured.operandA[pc]])
												elseif v798 == 185 then
													registers[captured.operandB[pc]] =
														captured.capturedValues[captured.operandA[pc]][captured.constantC[pc]]
												elseif registers[captured.operandA[pc]] ~= captured.constantB[pc] then
													pc = captured.operandC[pc]
												end
											elseif v798 >= 189 then
												if v798 >= 190 then
													if v798 == 191 then
														seedA = registers[captured.operandC[pc]]
													else
														local v803

														if registers[captured.operandB[pc]] then
															v803 = captured.operandC[pc]
														else
															v803 = captured.operandA[pc]
														end

														pc = v803
													end
												else
													registers[captured.operandB[pc]] = captured.constantA[pc]
												end
											elseif v798 >= 187 then
												if v798 == 188 then
													environment[captured.constantC[pc]] = captured.constantB[pc]
												else
													captured.capturedValues[captured.operandA[pc]][captured.constantC[pc]] =
														captured.constantB[pc]
												end
											else
												registers[captured.operandB[pc]] =
													registers[captured.operandC[pc]](registers[captured.operandA[pc]])
											end
										elseif v798 < 174 then
											if v798 >= 171 then
												if v798 >= 172 then
													if v798 == 173 then
														registers[captured.operandB[pc]] =
															environment[captured.constantA[pc]][captured.constantC[pc]]
													else
														registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
															- registers[captured.operandB[pc]]
													end
												else
													registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
														% captured.operandA[pc]
												end
											elseif v798 >= 169 then
												if v798 == 170 then
													registers[captured.operandB[pc]][captured.constantA[pc]] =
														registers[captured.operandC[pc]]
												else
													registers[captured.operandC[pc]] = registers[captured.operandB[pc]]
														// captured.operandA[pc]
												end
											else
												registers[captured.operandA[pc]] = captured.constantB[pc]
													* registers[captured.operandC[pc]]
											end
										elseif v798 >= 177 then
											if v798 < 178 then
												captured.capturedValues[captured.operandA[pc]][registers[captured.operandB[pc]]] =
													captured.constantC[pc]
											else
												if v798 == 179 then
													local v804 = u12
													local v805 = u13

													if v804 then
														for i in nextEntry, v804 do
															local v806 = v804[i]

															if v806 then
																v806[5] = v806
																v806[6] = registers[i]
																v806[4] = 6
																v804[i] = nil
															end
														end
													end

													if v805 then
														for i, v in nextEntry, v805 do
															local v807 = v[6]

															if v805 then
																local v808 = v805[i]

																if v808 then
																	local v809 = createRegisters(v807)
																	moveValues(registers, i, i + v807 - 1, 1, v809)
																	v808[5] = v809
																	v808[4] = 1
																	v805[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(
															captured.constantC[pc],
															registers[captured.operandB[pc]]
														)
												end

												registers[captured.operandB[pc]] = captured.operandA
											end
										elseif v798 < 175 then
											registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
												* captured.operandB[pc]
										elseif v798 == 176 then
											registers[captured.operandA[pc]] =
												packValues(registers[captured.operandB[pc]]())
										elseif registers[captured.operandB[pc]] ~= registers[captured.operandA[pc]] then
											pc = captured.operandC[pc]
										end
									elseif v798 >= 156 then
										if v798 < 162 then
											if v798 < 159 then
												if v798 >= 157 then
													if v798 == 158 then
														registers[captured.operandA[pc]] = captured.constantC[pc]
															+ registers[captured.operandB[pc]]
													else
														environment[captured.constantC[pc]][captured.constantB[pc]] =
															registers[captured.operandA[pc]]
													end
												else
													registers[captured.operandC[pc]] = rightShift(
														registers[captured.operandA[pc]],
														captured.operandB[pc]
													)
												end
											elseif v798 >= 160 then
												if v798 == 161 then
													if registers[captured.operandA[pc]] > captured.constantB[pc] then
														pc = captured.operandC[pc]
													end
												else
													v36 = { ... }
													v34 = captured.operandB[pc]
													moveValues(v36, 1, captured.operandC[pc], v34, registers)
												end
											else
												registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
													> captured.constantC[pc]
											end
										elseif v798 < 165 then
											if v798 >= 163 then
												if v798 == 164 then
													u7 = {
														[6] = u11,
														[5] = u9,
														[9] = u7,
														[8] = u8,
														[7] = u10,
													}
													v36 = captured.operandB[pc]
													v34 = wrapCoroutine(closeUpvalues)
													v34(
														captured.runtime,
														registers[v36],
														registers[v36 + 1],
														registers[v36 + 2]
													)
													u8 = v34
													u11 = captured.operandC[pc]
													pc = captured.operandA[pc]
												else
													registers[captured.operandC[pc]][registers[captured.operandB[pc]]] =
														captured.constantA[pc]
												end
											else
												local v810 = captured.operandB[pc]
												local v811 = captured.operandC[pc]
												local v812 = captured.constantState[5]
												local v813 = bitXor(v812[v810], 109162203)
												v812[v810] = v813
												local v814 = captured.constantState[4]
												local v815 = v813 + 1
												local v816 = readByte(v814, v815)
												local v817

												if v816 < 128 then
													v817 = v815 + 1
												else
													local v818 = readByte(v814, v815 + 1)

													if v818 < 128 then
														v816 = v816 - 128 + v818 * 128
														v817 = v815 + 2
													else
														local v819 = readByte(v814, v815 + 2)

														if v819 < 128 then
															v816 = v816 - 128 + (v818 - 128) * 16384 + v819 * 128
															v817 = v815 + 3
														else
															local v820 = readByte(v814, v815 + 3)
															v816 = (v816 - 128) * 16384
																+ (v818 - 128) * 128
																+ (v819 - 128)
																+ v820 % 128 * 2097152
																+ (v820 - v820 % 128) * 2097152
															v817 = v815 + 4
														end
													end
												end

												local v821 = v811 * 16843009
												local v822 = v817 + v816
												local v823 = v822 - v816 % 4

												for i = v817, v823 - 1, 4 do
													writeUInt32(v814, i, (bitXor(readUInt32(v814, i), v821)))
													local _ = i
												end

												for i = v823, v822 - 1 do
													writeByte(v814, i, (bitXor(readByte(v814, i), v811)))
													local _ = i
												end

												captured.operandB[pc] = 164
												captured.operandC[pc] = 52
												captured.operandA[pc] = 243
												captured.opcodes[pc] = 86
											end
										else
											if v798 < 166 then
												local v824 = u12
												local v825 = u13

												if v824 then
													for i in nextEntry, v824 do
														local v826 = v824[i]

														if v826 then
															v826[5] = v826
															v826[6] = registers[i]
															v826[4] = 6
															v824[i] = nil
														end
													end
												end

												if v825 then
													for i, v in nextEntry, v825 do
														local v827 = v[6]

														if v825 then
															local v828 = v825[i]

															if v828 then
																local v829 = createRegisters(v827)
																moveValues(registers, i, i + v827 - 1, 1, v829)
																v828[5] = v829
																v828[4] = 1
																v825[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandB[pc],
													packValues(
														registers[captured.operandC[pc]],
														registers[captured.operandA[pc]]
													)
											end

											if v798 == 167 then
												v36 = captured.operandA[pc]
												v34 = captured.operandC[pc]
												v32 = captured.operandB[pc]
												v35 = v36 + v34
												registers[v36] =
													packValues(registers[v36](unpackValues(registers, v36 + 1, v35)))
											else
												registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
													% captured.constantB[pc]
											end
										end
									elseif v798 < 150 then
										if v798 >= 147 then
											if v798 < 148 then
												registers[captured.operandA[pc]] =
													registers[captured.operandC[pc]][captured.constantB[pc]]
											elseif v798 == 149 then
												registers[captured.operandA[pc]] = seedB
											else
												registers[captured.operandB[pc]] = registers[captured.operandC[pc]](
													unpackValues(
														registers[captured.operandA[pc]],
														1,
														registers[captured.operandA[pc]].n
													)
												)
											end
										elseif v798 < 145 then
											u7 = {
												[6] = u11,
												[5] = u9,
												[9] = u7,
												[8] = u8,
												[7] = u10,
											}
											v36 = captured.operandB[pc]
											u10 = registers[v36 + 2] + 0
											u9 = registers[v36 + 1] + 0
											u8 = registers[v36] - u10
											pc = captured.operandC[pc]
										elseif v798 == 146 then
											registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
												< captured.operandA[pc]
										else
											registers[captured.operandC[pc]] = registers[captured.operandB[pc]]
												+ captured.constantA[pc]
										end
									elseif v798 >= 153 then
										if v798 < 154 then
											registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
												== captured.constantA[pc]
										elseif v798 == 155 then
											registers[captured.operandA[pc]] =
												registers[captured.operandB[pc]][registers[captured.operandC[pc]]]
										else
											captured.capturedValues[captured.operandC[pc]][captured.constantB[pc]] =
												captured.operandA[pc]
										end
									elseif v798 < 151 then
										captured.capturedValues[captured.operandC[pc]][captured.constantA[pc]] =
											registers[captured.operandB[pc]]
									elseif v798 == 152 then
										v36 = captured.operandB[pc]
										local v830 = registers[captured.operandA[pc]]
										registers[v36] = captured.constantC[pc]
										registers[v36 + 1] = v830
									else
										registers[captured.operandA[pc]] = packValues(
											registers[captured.operandB[pc]](registers[captured.operandC[pc]])
										)
									end
								elseif v798 >= 120 then
									if v798 >= 132 then
										if v798 >= 138 then
											if v798 >= 141 then
												if v798 < 142 then
													local v831 = u12
													local v832 = u13

													if v831 then
														for i in nextEntry, v831 do
															local v833 = v831[i]

															if v833 then
																v833[5] = v833
																v833[6] = registers[i]
																v833[4] = 6
																v831[i] = nil
															end
														end
													end

													if v832 then
														for i, v in nextEntry, v832 do
															local v834 = v[6]

															if v832 then
																local v835 = v832[i]

																if v835 then
																	local v836 = createRegisters(v834)
																	moveValues(registers, i, i + v834 - 1, 1, v836)
																	v835[5] = v836
																	v835[4] = 1
																	v832[i] = nil
																end
															end
														end
													end

													return false,
														true,
														packValues(
															registers[captured.operandC[pc]],
															registers[captured.operandA[pc]]
														)
												end

												if v798 == 143 then
													registers[captured.operandA[pc]](
														registers[captured.operandC[pc]],
														unpackValues(
															registers[captured.operandB[pc]],
															1,
															registers[captured.operandB[pc]].n
														)
													)
												else
													registers[captured.operandB[pc]] = bitAnd(
														registers[captured.operandC[pc]],
														registers[captured.operandA[pc]]
													)
												end
											elseif v798 < 139 then
												registers[captured.operandA[pc]] = seedA
											elseif v798 == 140 then
												registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
													- captured.operandA[pc]
											else
												v36 = captured.capturedValues[captured.operandC[pc]]
												registers[captured.operandA[pc]] = v36[5][v36[4]]
											end
										elseif v798 < 135 then
											if v798 >= 133 then
												if v798 == 134 then
													v36 = captured.operandC[pc]
													v34 = captured.operandA[pc]
													v32 = captured.operandB[pc]
													v35 = v36 + v34
													v33 = registers[v35]
													v37 = v33.n
													v33.n = v34 + v37 - 1
													moveValues(v33, 1, v37, v34, v33)
													moveValues(registers, v36 + 1, v35 - 1, 1, v33)
													registers[v36] =
														packValues(registers[v36](unpackValues(v33, 1, v33.n)))
												else
													local v837

													if registers[captured.operandB[pc]] then
														v837 = captured.operandA[pc]
													else
														v837 = captured.operandC[pc]
													end

													pc = v837
												end
											else
												registers[captured.operandA[pc]] = captured.operandB[pc]
											end
										elseif v798 >= 136 then
											if v798 == 137 then
												registers[captured.operandA[pc]] = captured.operandC
											else
												registers[captured.operandC[pc]] = registers[captured.operandA[pc]]()
											end
										else
											v36 = captured.operandB[pc]
											local v838 = captured.operandC[pc]
											registers[v36] = registers[captured.operandA[pc]]
											registers[v36 + 1] = v838
										end
									elseif v798 >= 126 then
										if v798 < 129 then
											if v798 >= 127 then
												if v798 == 128 then
													registers[captured.operandB[pc]] =
														registers[captured.operandC[pc]][captured.operandA[pc]]
												else
													local v839 = captured.operandA[pc]
													local v840 = captured.operandC[pc]
													local v841 = bitAnd(registers[captured.operandB[pc]], 4294967295)
													local v842 = bitAnd(v840, 4294967295)
													local v843 = bitAnd(v841, 65535)
													local v844 = rightShift(v841, 16)
													local v845 = bitAnd(v842, 65535)
													local v846 = rightShift(v842, 16)
													local v847 = bitAnd(
														v843 * v845
															+ leftShift(bitAnd(v843 * v846 + v844 * v845, 65535), 16),
														4294967295
													) % 4294967296
													registers[v839] = v847 ~= v847 and 0 or v847 - v847 % 1
												end
											else
												v36 = captured.capturedValues[captured.operandB[pc]]
												registers[captured.operandA[pc]] =
													v36[5][v36[4]][captured.constantC[pc]]
											end
										elseif v798 < 130 then
											registers[captured.operandC[pc]] =
												bitXor(registers[captured.operandB[pc]], captured.constantA[pc])
										elseif v798 == 131 then
											local v848 = nil
											local v849 = captured.operandC[pc]
											local v850 = captured.constantA[pc]
											local v851 = captured.constantB[pc]
											local v852 = u12
											local v853 = u13
											local v854 = v851[0]

											if v854 then
												local v855 = #v854 / 3

												if v855 > 0 then
													v848 = {}

													for i = 1, v855 do
														local v856 = (i - 1) * 3
														local v857 = v854[v856 + 2]
														local v858 = v854[v856 + 1]
														local v859

														if v857 == 2 then
															v852 = v852 or {}
															local v860 = v852[v858]

															if not v860 then
																v860 = {
																	[5] = registers,
																	[4] = v858,
																}
																v852[v858] = v860
															end

															v848[i] = v860
															v859 = i
														elseif v857 == 0 then
															v848[i] = registers[v858]
															v859 = i
														elseif v857 == 3 then
															v848[i] = captured.capturedValues[v858]
															v859 = i
														elseif v857 == 1 then
															v853 = v853 or {}
															local v861 = v853[v858]

															if not v861 then
																v861 = {
																	[5] = registers,
																	[4] = v858,
																	[6] = v854[v856 + 3],
																}
																v853[v858] = v861
															end

															v848[i] = v861
															v859 = i
														else
															v859 = i
														end
													end
												end
											end

											local v862 = v851[-2]
											v851[v862] = v848
											local v863 = v850(unpackValues(v851, 1, v851[-1]))
											v851[v862] = nil
											registers[v849] = v863
											u12 = v852
											u13 = v853
										else
											v36 = captured.operandA[pc]
											local v864 = captured.operandB[pc]
											registers[v36] = captured.constantC[pc]
											registers[v36 + 1] = v864
										end
									elseif v798 < 123 then
										if v798 < 121 then
											registers[captured.operandA[pc]] = captured.operandC[pc]
												* registers[captured.operandB[pc]]
										elseif v798 == 122 then
											local v865 = registers[captured.operandB[pc]] % 4294967296
											registers[captured.operandA[pc]] = v865 ~= v865 and 0 or v865 - v865 % 1
										else
											v36 = captured.operandC[pc]
											v34, v32, v35 = u8()

											if v34 then
												registers[v36] = v32
												registers[v36 + 1] = v35
												pc = captured.operandA[pc]
											else
												pc = captured.operandB[pc]
											end
										end
									elseif v798 < 124 then
										registers[captured.operandC[pc]](
											registers[captured.operandA[pc]],
											captured.constantB[pc]
										)
									elseif v798 == 125 then
										local v866 = captured.operandA[pc]
										local v867 = captured.constantC[pc]
										local v868 = bitAnd(captured.constantB[pc], 4294967295)
										local v869 = bitAnd(v867, 4294967295)
										local v870 = bitAnd(v868, 65535)
										local v871 = rightShift(v868, 16)
										local v872 = bitAnd(v869, 65535)
										local v873 = rightShift(v869, 16)
										local v874 = bitAnd(
											v870 * v872 + leftShift(bitAnd(v870 * v873 + v871 * v872, 65535), 16),
											4294967295
										) % 4294967296
										registers[v866] = v874 ~= v874 and 0 or v874 - v874 % 1
									else
										registers[captured.operandC[pc]] = registers[captured.operandB[pc]]
											* captured.constantA[pc]
									end
								elseif v798 >= 108 then
									if v798 >= 114 then
										if v798 < 117 then
											if v798 >= 115 then
												if v798 == 116 then
													v36 = captured.capturedValues[captured.operandB[pc]]
													v36[5][v36[4]] = captured.constantC[pc]
												else
													registers[captured.operandB[pc]] = packValues(
														registers[captured.operandC[pc]](captured.constantA[pc])
													)
												end
											else
												u8 = u8 + u10

												if u10 <= 0 then
													v36 = u9 <= u8
												else
													v36 = u8 <= u9
												end

												if v36 then
													registers[captured.operandC[pc]] = u8
													pc = captured.operandA[pc]
												else
													pc = captured.operandB[pc]
												end
											end
										elseif v798 >= 118 then
											if v798 == 119 then
												if u12 then
													local v875 = u12
													local v876 = captured.operandB[pc]
													local v877 = v875[v876]

													if v877 then
														v877[5] = v877
														v877[6] = registers[v876]
														v877[4] = 6
														v875[v876] = nil
													end
												end
											else
												v36 = captured.capturedValues[captured.operandB[pc]]
												v36[5][v36[4]][captured.constantA[pc]] = captured.constantC[pc]
											end
										else
											registers[captured.operandC[pc]] =
												bitAnd(registers[captured.operandB[pc]], captured.operandA[pc])
										end
									elseif v798 >= 111 then
										if v798 >= 112 then
											if v798 ~= 113 then
												local v878 = u12
												local v879 = u13

												if v878 then
													for i in nextEntry, v878 do
														local v880 = v878[i]

														if v880 then
															v880[5] = v880
															v880[6] = registers[i]
															v880[4] = 6
															v878[i] = nil
														end
													end
												end

												if v879 then
													for i, v in nextEntry, v879 do
														local v881 = v[6]

														if v879 then
															local v882 = v879[i]

															if v882 then
																local v883 = createRegisters(v881)
																moveValues(registers, i, i + v881 - 1, 1, v883)
																v882[5] = v883
																v882[4] = 1
																v879[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandB[pc],
													packValues(
														registers[captured.operandC[pc]],
														unpackValues(
															registers[captured.operandA[pc]],
															1,
															registers[captured.operandA[pc]].n
														)
													)
											end

											registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
												- captured.constantB[pc]
										else
											v36 = captured.operandA[pc]
											local v884 = captured.operandC[pc]
											registers[v36] = captured.operandB[pc]
											registers[v36 + 1] = v884
										end
									elseif v798 < 109 then
										if u12 then
											local v885 = u12
											local v886 = captured.operandB[pc]
											local v887 = v885[v886]

											if v887 then
												v887[5] = v887
												v887[6] = registers[v886]
												v887[4] = 6
												v885[v886] = nil
											end

											local v888 = u12
											local v889 = captured.operandC[pc]
											local v890 = v888[v889]

											if v890 then
												v890[5] = v890
												v890[6] = registers[v889]
												v890[4] = 6
												v888[v889] = nil
											end
										end
									elseif v798 == 110 then
										local v891 = captured.operandC[pc]
										local v892 = bitXor(
											captured.operandB[pc],
											(bitAnd(bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))), 536870911))
										)
										local v893 = captured.constantState[5]
										local v894 = bitXor(v893[v891], 109162203)
										v893[v891] = v894
										local v895 = captured.constantState[4]
										local v896 = v894 + 1
										local v897 = readByte(v895, v896)
										local v898

										if v897 < 128 then
											v898 = v896 + 1
										else
											local v899 = readByte(v895, v896 + 1)

											if v899 < 128 then
												v897 = v897 - 128 + v899 * 128
												v898 = v896 + 2
											else
												local v900 = readByte(v895, v896 + 2)

												if v900 < 128 then
													v897 = v897 - 128 + (v899 - 128) * 16384 + v900 * 128
													v898 = v896 + 3
												else
													local v901 = readByte(v895, v896 + 3)
													v897 = (v897 - 128) * 16384
														+ (v899 - 128) * 128
														+ (v900 - 128)
														+ v901 % 128 * 2097152
														+ (v901 - v901 % 128) * 2097152
													v898 = v896 + 4
												end
											end
										end

										local v902 = v892 * 16843009
										local v903 = v898 + v897
										local v904 = v903 - v897 % 4

										for i = v898, v904 - 1, 4 do
											writeUInt32(v895, i, (bitXor(readUInt32(v895, i), v902)))
											local _ = i
										end

										for i = v904, v903 - 1 do
											writeByte(v895, i, (bitXor(readByte(v895, i), v892)))
											local _ = i
										end

										captured.operandC[pc] = 239
										captured.operandB[pc] = 197
										captured.operandA[pc] = 41
										captured.opcodes[pc] = 86
									else
										v36 = captured.operandA[pc]
										v34 = captured.operandC[pc]
										v32 = captured.operandB[pc]
										v35 = v36 + v32 - 1
										v33 = v36 + v34
										v37 = packValues(registers[v36](unpackValues(registers, v36 + 1, v36 + v34)))
										moveValues(v37, 1, v32, v36, registers)
									end
								elseif v798 < 102 then
									if v798 < 99 then
										if v798 >= 97 then
											if v798 == 98 then
												local v905 = u12
												local v906 = u13

												if v905 then
													for i in nextEntry, v905 do
														local v907 = v905[i]

														if v907 then
															v907[5] = v907
															v907[6] = registers[i]
															v907[4] = 6
															v905[i] = nil
														end
													end
												end

												if v906 then
													for i, v in nextEntry, v906 do
														local v908 = v[6]

														if v906 then
															local v909 = v906[i]

															if v909 then
																local v910 = createRegisters(v908)
																moveValues(registers, i, i + v908 - 1, 1, v910)
																v909[5] = v910
																v909[4] = 1
																v906[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandC[pc],
													packValues(registers[captured.operandA[pc]])
											end

											registers[captured.operandC[pc]] = environment[captured.constantA[pc]]
										else
											v36 = captured.operandB[pc]
											local v911 = registers[captured.operandC[pc]]
											registers[v36] = registers[captured.operandA[pc]]
											registers[v36 + 1] = v911
										end
									elseif v798 >= 100 then
										if v798 == 101 then
											local v912 = captured.operandC[pc]
											local v913 = bitXor(
												captured.operandB[pc],
												(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
											)
											local v914 = captured.constantState[5]
											local v915 = bitXor(v914[v912], 109162203)
											v914[v912] = v915
											local v916 = captured.constantState[4]
											local v917 = v915 + 1
											local v918 = readByte(v916, v917)
											local v919

											if v918 < 128 then
												v919 = v917 + 1
											else
												local v920 = readByte(v916, v917 + 1)

												if v920 < 128 then
													v918 = v918 - 128 + v920 * 128
													v919 = v917 + 2
												else
													local v921 = readByte(v916, v917 + 2)

													if v921 < 128 then
														v918 = v918 - 128 + (v920 - 128) * 16384 + v921 * 128
														v919 = v917 + 3
													else
														local v922 = readByte(v916, v917 + 3)
														v918 = (v918 - 128) * 16384
															+ (v920 - 128) * 128
															+ (v921 - 128)
															+ v922 % 128 * 2097152
															+ (v922 - v922 % 128) * 2097152
														v919 = v917 + 4
													end
												end
											end

											local v923 = v913 * 16843009
											local v924 = v919 + v918
											local v925 = v924 - v918 % 4

											for i = v919, v925 - 1, 4 do
												writeUInt32(v916, i, (bitXor(readUInt32(v916, i), v923)))
												local _ = i
											end

											for i = v925, v924 - 1 do
												writeByte(v916, i, (bitXor(readByte(v916, i), v913)))
												local _ = i
											end

											captured.operandC[pc] = 187
											captured.operandB[pc] = 245
											captured.operandA[pc] = 185
											captured.opcodes[pc] = 86
										else
											pc = registers[captured.operandB[pc]]
										end
									else
										registers[captured.operandA[pc]](
											captured.constantB[pc],
											unpackValues(
												registers[captured.operandC[pc]],
												1,
												registers[captured.operandC[pc]].n
											)
										)
									end
								elseif v798 >= 105 then
									if v798 < 106 then
										local v926 = captured.operandA[pc]
										local v927 = v926 + captured.operandC[pc]
										local v928 = u12
										local v929 = u13

										if v928 then
											for i in nextEntry, v928 do
												local v930 = v928[i]

												if v930 then
													v930[5] = v930
													v930[6] = registers[i]
													v930[4] = 6
													v928[i] = nil
												end
											end
										end

										if v929 then
											for i, v in nextEntry, v929 do
												local v931 = v[6]

												if v929 then
													local v932 = v929[i]

													if v932 then
														local v933 = createRegisters(v931)
														moveValues(registers, i, i + v931 - 1, 1, v933)
														v932[5] = v933
														v932[4] = 1
														v929[i] = nil
													end
												end
											end
										end

										return true, false, v926, v927
									end

									if v798 == 107 then
										local v934 = u12
										local v935 = u13

										if v934 then
											for i in nextEntry, v934 do
												local v936 = v934[i]

												if v936 then
													v936[5] = v936
													v936[6] = registers[i]
													v936[4] = 6
													v934[i] = nil
												end
											end
										end

										if v935 then
											for i, v in nextEntry, v935 do
												local v937 = v[6]

												if v935 then
													local v938 = v935[i]

													if v938 then
														local v939 = createRegisters(v937)
														moveValues(registers, i, i + v937 - 1, 1, v939)
														v938[5] = v939
														v938[4] = 1
														v935[i] = nil
													end
												end
											end
										end

										return false, true, packValues(captured.constantB[pc], captured.constantC[pc])
									end

									if registers[captured.operandA[pc]] >= captured.operandB[pc] then
										pc = captured.operandC[pc]
									end
								elseif v798 < 103 then
									if captured.operandB[pc] > registers[captured.operandA[pc]] then
										pc = captured.operandC[pc]
									end
								elseif v798 == 104 then
									registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
										~= captured.constantB[pc]
								else
									v36 = captured.operandB[pc]
									v34 = captured.operandA[pc]
									v32 = captured.operandC[pc]
									v35 = registers[v36]
									moveValues(registers, v36 + 1, v36 + v34, v32 + 1, v35)
								end

								v797 = 1
								continue
							end

							if v798 >= 48 then
								if v798 < 72 then
									if v798 < 60 then
										if v798 >= 54 then
											if v798 >= 57 then
												if v798 < 58 then
													registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
														+ registers[captured.operandB[pc]]
												elseif v798 == 59 then
													captured.capturedValues[captured.operandC[pc]][registers[captured.operandA[pc]]] =
														registers[captured.operandB[pc]]
												else
													registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
														< captured.constantB[pc]
												end
											elseif v798 < 55 then
												seedB = registers[captured.operandA[pc]]
											elseif v798 == 56 then
												registers[captured.operandC[pc]] = registers
											else
												registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
													~= registers[captured.operandB[pc]]
											end
										elseif v798 >= 51 then
											if v798 < 52 then
												v36 = captured.operandC[pc] + 1
												v34 = captured.operandB[pc]

												for i = 1, captured.operandA[pc] do
													local v940 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
													local v941 = bitXor(v940, (rightShift(v940, 13)))
													v34 = bitAnd(bitXor(v941, (leftShift(v941, 14))), 536870911)
													captured.operandC[v36] = bitXor(
														captured.operandC[v36],
														(bitAnd(rightShift(v34, 0), 127))
													)
													captured.operandB[v36] = bitXor(
														captured.operandB[v36],
														(bitAnd(rightShift(v34, 7), 127))
													)
													captured.operandA[v36] = bitXor(
														captured.operandA[v36],
														(bitAnd(rightShift(v34, 14), 127))
													)
													captured.opcodes[v36] = bitXor(
														captured.opcodes[v36],
														(bitAnd(rightShift(v34, 21), 127))
													)
													v36 = v36 + 1
													local _ = i
												end

												captured.opcodes[pc] = 86
											elseif v798 == 53 then
												registers[captured.operandC[pc]] = registers[captured.operandB[pc]]
													> registers[captured.operandA[pc]]
											elseif registers[captured.operandA[pc]] > captured.operandC[pc] then
												pc = captured.operandB[pc]
											end
										else
											if v798 < 49 then
												local v942 = u12
												local v943 = u13

												if v942 then
													for i in nextEntry, v942 do
														local v944 = v942[i]

														if v944 then
															v944[5] = v944
															v944[6] = registers[i]
															v944[4] = 6
															v942[i] = nil
														end
													end
												end

												if v943 then
													for i, v in nextEntry, v943 do
														local v945 = v[6]

														if v943 then
															local v946 = v943[i]

															if v946 then
																local v947 = createRegisters(v945)
																moveValues(registers, i, i + v945 - 1, 1, v947)
																v946[5] = v947
																v946[4] = 1
																v943[i] = nil
															end
														end
													end
												end

												return false, false
											end

											if v798 ~= 50 then
												local v948 = u12
												local v949 = u13

												if v948 then
													for i in nextEntry, v948 do
														local v950 = v948[i]

														if v950 then
															v950[5] = v950
															v950[6] = registers[i]
															v950[4] = 6
															v948[i] = nil
														end
													end
												end

												if v949 then
													for i, v in nextEntry, v949 do
														local v951 = v[6]

														if v949 then
															local v952 = v949[i]

															if v952 then
																local v953 = createRegisters(v951)
																moveValues(registers, i, i + v951 - 1, 1, v953)
																v952[5] = v953
																v952[4] = 1
																v949[i] = nil
															end
														end
													end
												end

												return true,
													true,
													captured.operandB[pc],
													packValues(
														captured.constantA[pc],
														unpackValues(
															registers[captured.operandC[pc]],
															1,
															registers[captured.operandC[pc]].n
														)
													)
											end

											v36 = registers[captured.operandC[pc]]
											v34 = captured.operandB[pc]
											v32 = captured.operandA[pc]
											moveValues(v36, 1, v32, v34, registers)
										end
									elseif v798 >= 66 then
										if v798 >= 69 then
											if v798 >= 70 then
												if v798 == 71 then
													v36 = captured.capturedValues[captured.operandA[pc]]
													v36[5][v36[4]][captured.constantB[pc]] = captured.operandC[pc]
												else
													registers[captured.operandA[pc]] = captured.opcodes
												end
											else
												v36 = captured.operandA[pc]
												v34 = captured.operandB[pc]
												v32 = bitXor(
													seedB,
													bitAnd(rightShift(seedB, 14), 262143),
													(bitAnd(rightShift(seedB, 28), 15))
												)
												v35 = captured.operandC[pc]
												v33 = v36 < 2097152 and 7 or 14
												v37 = rightShift(v36, v33)
												local v954 = bitAnd(v36, leftShift(1, v33) - 1)
												captured.operandC[pc] = bitXor(v35, 66, (bitAnd(v32, 127)))
												captured.operandB[pc] =
													bitXor(v34, 83, (bitAnd(rightShift(v32, 7), 127)))
												captured.opcodes[pc] =
													bitXor(v37, 60, (bitAnd(rightShift(v32, 21), 127)))
												captured.operandA[pc] =
													bitXor(v954, 7, (bitAnd(rightShift(v32, 14), 127)))
												pc = pc - 1
											end
										elseif v798 < 67 then
											environment[captured.constantB[pc]] = registers[captured.operandA[pc]]
										elseif v798 == 68 then
											if u12 then
												local v955 = u12
												local v956 = captured.operandA[pc]
												local v957 = v955[v956]

												if v957 then
													v957[5] = v957
													v957[6] = registers[v956]
													v957[4] = 6
													v955[v956] = nil
												end

												local v958 = u12
												local v959 = captured.operandC[pc]
												local v960 = v958[v959]

												if v960 then
													v960[5] = v960
													v960[6] = registers[v959]
													v960[4] = 6
													v958[v959] = nil
												end

												local v961 = u12
												local v962 = captured.operandB[pc]
												local v963 = v961[v962]

												if v963 then
													v963[5] = v963
													v963[6] = registers[v962]
													v963[4] = 6
													v961[v962] = nil
												end
											end
										else
											registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
												// registers[captured.operandC[pc]]
										end
									elseif v798 >= 63 then
										if v798 < 64 then
											registers[captured.operandC[pc]] = {}
										elseif v798 == 65 then
											registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
												== registers[captured.operandC[pc]]
										else
											registers[captured.operandC[pc]] =
												registers[captured.operandB[pc]](captured.constantA[pc])
										end
									elseif v798 < 61 then
										registers[captured.operandC[pc]] =
											bitAnd(registers[captured.operandA[pc]], captured.constantB[pc])
									elseif v798 == 62 then
										if captured.operandA[pc] >= registers[captured.operandB[pc]] then
											pc = captured.operandC[pc]
										end
									else
										registers[captured.operandB[pc]] = captured.operandC[pc]
											^ registers[captured.operandA[pc]]
									end
								elseif v798 >= 84 then
									if v798 < 90 then
										if v798 < 87 then
											if v798 < 85 then
												registers[captured.operandA[pc]] = #registers[captured.operandC[pc]]
											elseif v798 ~= 86 then
												local v964 = captured.operandC[pc]
												local v965 = registers[captured.operandB[pc]]
												local v966 = bitAnd(captured.constantA[pc], 4294967295)
												local v967 = bitAnd(v965, 4294967295)
												local v968 = bitAnd(v966, 65535)
												local v969 = rightShift(v966, 16)
												local v970 = bitAnd(v967, 65535)
												local v971 = rightShift(v967, 16)
												local v972 = bitAnd(
													v968 * v970
														+ leftShift(bitAnd(v968 * v971 + v969 * v970, 65535), 16),
													4294967295
												) % 4294967296
												registers[v964] = v972 ~= v972 and 0 or v972 - v972 % 1
											end
										elseif v798 < 88 then
											registers[captured.operandB[pc]] =
												leftShift(registers[captured.operandC[pc]], captured.operandA[pc])
										else
											if v798 == 89 then
												local v973 = u12
												local v974 = u13

												if v973 then
													for i in nextEntry, v973 do
														local v975 = v973[i]

														if v975 then
															v975[5] = v975
															v975[6] = registers[i]
															v975[4] = 6
															v973[i] = nil
														end
													end
												end

												if v974 then
													for i, v in nextEntry, v974 do
														local v976 = v[6]

														if v974 then
															local v977 = v974[i]

															if v977 then
																local v978 = createRegisters(v976)
																moveValues(registers, i, i + v976 - 1, 1, v978)
																v977[5] = v978
																v977[4] = 1
																v974[i] = nil
															end
														end
													end
												end

												local v979 = captured.operandB[pc]

												return false, false, v979, v979 + captured.operandA[pc] - 1
											end

											registers[captured.operandB[pc]][captured.constantC[pc]] =
												captured.operandA[pc]
										end
									elseif v798 < 93 then
										if v798 >= 91 then
											if v798 == 92 then
												local v980 = u12
												local v981 = u13

												if v980 then
													for i in nextEntry, v980 do
														local v982 = v980[i]

														if v982 then
															v982[5] = v982
															v982[6] = registers[i]
															v982[4] = 6
															v980[i] = nil
														end
													end
												end

												if v981 then
													for i, v in nextEntry, v981 do
														local v983 = v[6]

														if v981 then
															local v984 = v981[i]

															if v984 then
																local v985 = createRegisters(v983)
																moveValues(registers, i, i + v983 - 1, 1, v985)
																v984[5] = v985
																v984[4] = 1
																v981[i] = nil
															end
														end
													end
												end

												return false, true, packValues(registers[captured.operandB[pc]])
											end

											registers[captured.operandA[pc]](captured.constantB[pc])
										else
											registers[captured.operandA[pc]] =
												bitXor(captured.constantB[pc], captured.constantC[pc])
										end
									else
										if v798 >= 94 then
											if v798 == 95 then
												local v986 = u12
												local v987 = u13

												if v986 then
													for i in nextEntry, v986 do
														local v988 = v986[i]

														if v988 then
															v988[5] = v988
															v988[6] = registers[i]
															v988[4] = 6
															v986[i] = nil
														end
													end
												end

												if v987 then
													for i, v in nextEntry, v987 do
														local v989 = v[6]

														if v987 then
															local v990 = v987[i]

															if v990 then
																local v991 = createRegisters(v989)
																moveValues(registers, i, i + v989 - 1, 1, v991)
																v990[5] = v991
																v990[4] = 1
																v987[i] = nil
															end
														end
													end
												end

												return false, true, registers[captured.operandA[pc]]
											end

											local v992 = u12
											local v993 = u13

											if v992 then
												for i in nextEntry, v992 do
													local v994 = v992[i]

													if v994 then
														v994[5] = v994
														v994[6] = registers[i]
														v994[4] = 6
														v992[i] = nil
													end
												end
											end

											if v993 then
												for i, v in nextEntry, v993 do
													local v995 = v[6]

													if v993 then
														local v996 = v993[i]

														if v996 then
															local v997 = createRegisters(v995)
															moveValues(registers, i, i + v995 - 1, 1, v997)
															v996[5] = v997
															v996[4] = 1
															v993[i] = nil
														end
													end
												end
											end

											return true, true, captured.operandB[pc], registers[captured.operandC[pc]]
										end

										registers[captured.operandA[pc]] =
											environment[captured.constantC[pc]][registers[captured.operandB[pc]]]
									end
								elseif v798 >= 78 then
									if v798 >= 81 then
										if v798 < 82 then
											registers[captured.operandA[pc]][captured.constantB[pc]] =
												captured.constantC[pc]
										elseif v798 == 83 then
											v36 = captured.operandA[pc]
											v34 = captured.operandC[pc]
											v32 = captured.operandB[pc]
											v35 = registers[v36]
											v33 = v36 + v34
											v37 = registers[v33]
											moveValues(registers, v36 + 1, v33 - 1, v32 + 1, v35)
											moveValues(v37, 1, v37.n, v32 + v34, v35)
										else
											registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
												.. captured.constantA[pc]
										end
									elseif v798 >= 79 then
										if v798 == 80 then
											v36 = captured.operandA[pc]
											v34 = captured.operandB[pc]
											v32 = captured.operandC[pc]
											v35 = bitXor(
												seedB,
												bitAnd(rightShift(seedB, 14), 262143),
												(bitAnd(rightShift(seedB, 28), 15))
											)
											v33 = v32 < 16384 and 7 or (v32 < 2097152 and 14 or 21)
											v37 = rightShift(v32, v33)
											captured.operandC[pc] =
												bitXor(bitAnd(v32, leftShift(1, v33) - 1), 58, (bitAnd(v35, 127)))
											captured.operandB[pc] = bitXor(v34, 44, (bitAnd(rightShift(v35, 7), 127)))
											captured.operandA[pc] = bitXor(v36, 38, (bitAnd(rightShift(v35, 14), 127)))
											captured.opcodes[pc] = bitXor(v37, 20, (bitAnd(rightShift(v35, 21), 127)))
											pc = pc - 1
										else
											v36 = captured.operandB[pc]
											v34 = registers[captured.operandC[pc]]
											registers[v36 + 1] = v34
											registers[v36] = v34[captured.constantA[pc]]
										end
									else
										registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
											% registers[captured.operandA[pc]]
									end
								elseif v798 >= 75 then
									if v798 < 76 then
										registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
											> captured.operandB[pc]
									elseif v798 == 77 then
										if registers[captured.operandC[pc]] >= registers[captured.operandA[pc]] then
											pc = captured.operandB[pc]
										end
									else
										registers[captured.operandC[pc]]()
									end
								elseif v798 >= 73 then
									if v798 == 74 then
										environment[captured.constantB[pc]][registers[captured.operandC[pc]]] =
											registers[captured.operandA[pc]]
									else
										v36 = captured.capturedValues[captured.operandA[pc]]
										v36[5][v36[4]] = registers[captured.operandB[pc]]
									end
								else
									pc = captured.operandC[pc]
								end

								v797 = 1
								continue
							end

							if v798 < 24 then
								if v798 < 12 then
									if v798 < 6 then
										if v798 >= 3 then
											if v798 < 4 then
												v36 = captured.operandA[pc]
												local v998 = captured.constantB[pc]
												registers[v36] = captured.constantC[pc]
												registers[v36 + 1] = v998
											else
												if v798 ~= 5 then
													local v999 = u12
													local v1000 = u13

													if v999 then
														for i in nextEntry, v999 do
															local v1001 = v999[i]

															if v1001 then
																v1001[5] = v1001
																v1001[6] = registers[i]
																v1001[4] = 6
																v999[i] = nil
															end
														end
													end

													if v1000 then
														for i, v in nextEntry, v1000 do
															local v1002 = v[6]

															if v1000 then
																local v1003 = v1000[i]

																if v1003 then
																	local v1004 = createRegisters(v1002)
																	moveValues(registers, i, i + v1002 - 1, 1, v1004)
																	v1003[5] = v1004
																	v1003[4] = 1
																	v1000[i] = nil
																end
															end
														end
													end

													return true,
														true,
														captured.operandB[pc],
														packValues(
															registers[captured.operandA[pc]],
															captured.constantC[pc]
														)
												end

												if captured.constantA[pc] >= registers[captured.operandB[pc]] then
													pc = captured.operandC[pc]
												end
											end
										elseif v798 >= 1 then
											if v798 == 2 then
												registers[captured.operandA[pc]] = captured.constantB[pc]
													.. registers[captured.operandC[pc]]
											elseif
												registers[captured.operandB[pc]] > registers[captured.operandC[pc]]
											then
												pc = captured.operandA[pc]
											end
										else
											registers[captured.operandC[pc]] = bitOr(
												registers[captured.operandA[pc]],
												registers[captured.operandB[pc]]
											)
										end
									elseif v798 < 9 then
										if v798 < 7 then
											local v1005 = u12
											local v1006 = u13

											if v1005 then
												for i in nextEntry, v1005 do
													local v1007 = v1005[i]

													if v1007 then
														v1007[5] = v1007
														v1007[6] = registers[i]
														v1007[4] = 6
														v1005[i] = nil
													end
												end
											end

											if v1006 then
												for i, v in nextEntry, v1006 do
													local v1008 = v[6]

													if v1006 then
														local v1009 = v1006[i]

														if v1009 then
															local v1010 = createRegisters(v1008)
															moveValues(registers, i, i + v1008 - 1, 1, v1010)
															v1009[5] = v1010
															v1009[4] = 1
															v1006[i] = nil
														end
													end
												end
											end

											return false, true, packValues(captured.constantA[pc])
										end

										if v798 == 8 then
											registers[captured.operandA[pc]] = bitXor(
												registers[captured.operandB[pc]],
												registers[captured.operandC[pc]]
											)
										else
											u8 = u7[8]
											u9 = u7[5]
											u10 = u7[7]
											u11 = u7[6]
											u7 = u7[9]
										end
									elseif v798 < 10 then
										if registers[captured.operandB[pc]] ~= captured.operandC[pc] then
											pc = captured.operandA[pc]
										end
									elseif v798 == 11 then
										registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
											.. registers[captured.operandB[pc]]
									elseif captured.constantA[pc] > registers[captured.operandB[pc]] then
										pc = captured.operandC[pc]
									end
								elseif v798 >= 18 then
									if v798 < 21 then
										if v798 >= 19 then
											if v798 == 20 then
												local v1011 = captured.operandA[pc]
												local v1012 = captured.operandC[pc]
												local v1013 = v1011 + v1012
												local v1014 = registers[v1013]
												local n = v1014.n
												local v1015 = u12
												local v1016 = u13

												if v1015 then
													for i in nextEntry, v1015 do
														local v1017 = v1015[i]

														if v1017 then
															v1017[5] = v1017
															v1017[6] = registers[i]
															v1017[4] = 6
															v1015[i] = nil
														end
													end
												end

												if v1016 then
													for i, v in nextEntry, v1016 do
														local v1018 = v[6]

														if v1016 then
															local v1019 = v1016[i]

															if v1019 then
																local v1020 = createRegisters(v1018)
																moveValues(registers, i, i + v1018 - 1, 1, v1020)
																v1019[5] = v1020
																v1019[4] = 1
																v1016[i] = nil
															end
														end
													end
												end

												v1014.n = v1012 + n - 1
												moveValues(v1014, 1, n, v1012, v1014)
												moveValues(registers, v1011 + 1, v1013 - 1, 1, v1014)

												return true, true, v1011, v1014
											end

											registers[captured.operandB[pc]] = registers[captured.operandA[pc]]
												~= captured.operandC[pc]
										else
											pc = registers[captured.operandA[pc]]
										end
									elseif v798 < 22 then
										registers[captured.operandA[pc]] =
											captured.capturedValues[captured.operandC[pc]]
									elseif v798 == 23 then
										registers[captured.operandC[pc]] = captured.constantState
									else
										registers[captured.operandA[pc]] = not registers[captured.operandB[pc]]
									end
								elseif v798 >= 15 then
									if v798 >= 16 then
										if v798 == 17 then
											registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
												== captured.operandA[pc]
										elseif registers[captured.operandC[pc]] >= captured.constantB[pc] then
											pc = captured.operandA[pc]
										end
									else
										v36 = captured.operandC[pc] + 1
										v34 = bitXor(
											captured.operandB[pc],
											(bitAnd(bitXor(seedB, (bitAnd(rightShift(seedB, 29), 7))), 536870911))
										)

										for i = 1, captured.operandA[pc] do
											local v1021 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
											local v1022 = bitXor(v1021, (rightShift(v1021, 13)))
											v34 = bitAnd(bitXor(v1022, (leftShift(v1022, 14))), 536870911)
											captured.operandC[v36] =
												bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 0), 127)))
											captured.operandB[v36] =
												bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 7), 127)))
											captured.operandA[v36] =
												bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 14), 127)))
											captured.opcodes[v36] =
												bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 21), 127)))
											v36 = v36 + 1
											local _ = i
										end

										captured.opcodes[pc] = 86
									end
								elseif v798 < 13 then
									registers[captured.operandA[pc]] = registers[captured.operandC[pc]][1]
								elseif v798 == 14 then
									v36 = captured.operandC[pc]
									v34 = { ... }
									v32 = captured.operandA[pc]
									moveValues(v34, 1, v36 - 1, v32, registers)
									registers[v32 + v36 - 1] = packValues(selectValues(v36, ...))
								else
									v36 = captured.operandC[pc]
									local v1023 = captured.constantB[pc]
									registers[v36] = captured.operandA[pc]
									registers[v36 + 1] = v1023
								end

								v797 = 1
								continue
							end

							if v798 >= 36 then
								if v798 < 42 then
									if v798 < 39 then
										if v798 < 37 then
											registers[captured.operandB[pc]](registers[captured.operandA[pc]])
										elseif v798 == 38 then
											registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
										else
											v36 = captured.operandC[pc]
											v34 = captured.operandB[pc]
											v32 = captured.operandA[pc]
											v35 = v36 + v32 - 1
											v33 = v36 + v34
											v37 = registers[v33]
											local n = v37.n
											v37.n = v34 + n - 1
											moveValues(v37, 1, n, v34, v37)
											moveValues(registers, v36 + 1, v33 - 1, 1, v37)
											moveValues(
												packValues(registers[v36](unpackValues(v37, 1, v37.n))),
												1,
												v32,
												v36,
												registers
											)
										end
									elseif v798 < 40 then
										registers[captured.operandA[pc]] = registers[captured.operandC[pc]]
											+ captured.operandB[pc]
									elseif v798 == 41 then
										registers[captured.operandC[pc]](
											captured.constantB[pc],
											registers[captured.operandA[pc]]
										)
									else
										registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
											* registers[captured.operandB[pc]]
									end
								elseif v798 < 45 then
									if v798 >= 43 then
										if v798 == 44 then
											for i = captured.operandB[pc], captured.operandA[pc] do
												registers[i] = nil
												local _ = i
											end
										else
											registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
												/ registers[captured.operandC[pc]]
										end
									else
										registers[captured.operandB[pc]] = -registers[captured.operandA[pc]]
									end
								elseif v798 < 46 then
									registers[captured.operandC[pc]] =
										bitXor(registers[captured.operandB[pc]], captured.operandA[pc])
								elseif v798 == 47 then
									registers[captured.operandC[pc]](
										unpackValues(
											registers[captured.operandB[pc]],
											1,
											registers[captured.operandB[pc]].n
										)
									)
								else
									registers[captured.operandB[pc]] =
										bitOr(registers[captured.operandC[pc]], captured.constantA[pc])
								end
							elseif v798 >= 30 then
								if v798 < 33 then
									if v798 < 31 then
										registers[captured.operandC[pc]] = registers[captured.operandA[pc]]
											< registers[captured.operandB[pc]]
									elseif v798 == 32 then
										registers[captured.operandA[pc]](
											registers[captured.operandB[pc]],
											registers[captured.operandC[pc]]
										)
									else
										registers[captured.operandC[pc]][registers[captured.operandB[pc]]] =
											registers[captured.operandA[pc]]
									end
								elseif v798 < 34 then
									v36 = captured.operandB[pc]
									v34 = registers[captured.operandC[pc]]
									registers[v36 + 1] = v34
									registers[v36] = v34[captured.constantA[pc]]
									registers[captured.operandB[pc + 1]] = registers[captured.operandC[pc + 1]]
									registers[captured.operandB[pc + 2]] = captured.constantA[pc + 2]
									registers[captured.operandB[pc + 3]] = registers[captured.operandC[pc + 3]]
									pc = pc + 3
								else
									if v798 ~= 35 then
										local v1024 = u12
										local v1025 = u13

										if v1024 then
											for i in nextEntry, v1024 do
												local v1026 = v1024[i]

												if v1026 then
													v1026[5] = v1026
													v1026[6] = registers[i]
													v1026[4] = 6
													v1024[i] = nil
												end
											end
										end

										if v1025 then
											for i, v in nextEntry, v1025 do
												local v1027 = v[6]

												if v1025 then
													local v1028 = v1025[i]

													if v1028 then
														local v1029 = createRegisters(v1027)
														moveValues(registers, i, i + v1027 - 1, 1, v1029)
														v1028[5] = v1029
														v1028[4] = 1
														v1025[i] = nil
													end
												end
											end
										end

										return true, true, captured.operandA[pc], packValues()
									end

									registers[captured.operandC[pc]] =
										captured.capturedValues[captured.operandB[pc]][registers[captured.operandA[pc]]]
								end
							else
								if v798 < 27 then
									if v798 < 25 then
										registers[captured.operandB[pc]] = registers[captured.operandC[pc]]
										v36 = captured.operandA[pc + 1]
										v34 = captured.operandC[pc + 1]
										v32 = captured.operandB[pc + 1]
										v35 = v36 + v32 - 1
										v33 = v36 + v34
										v37 = packValues(registers[v36](unpackValues(registers, v36 + 1, v36 + v34)))
										moveValues(v37, 1, v32, v36, registers)
										pc = pc + 1
									elseif v798 == 26 then
										registers[captured.operandB[pc]] = captured.operandB
									else
										local v1030 = captured.operandC[pc]
										local v1031 = registers[captured.operandA[pc]]
										local v1032 = bitAnd(registers[captured.operandB[pc]], 4294967295)
										local v1033 = bitAnd(v1031, 4294967295)
										local v1034 = bitAnd(v1032, 65535)
										local v1035 = rightShift(v1032, 16)
										local v1036 = bitAnd(v1033, 65535)
										local v1037 = rightShift(v1033, 16)
										local v1038 = bitAnd(
											v1034 * v1036 + leftShift(bitAnd(v1034 * v1037 + v1035 * v1036, 65535), 16),
											4294967295
										) % 4294967296
										registers[v1030] = v1038 ~= v1038 and 0 or v1038 - v1038 % 1
									end

									v797 = 1
									continue
								end

								if v798 < 28 then
									v36 = captured.operandC[pc] + 1
									v34 = bitXor(
										captured.operandB[pc],
										(bitAnd(bitXor(seedA, (bitAnd(rightShift(seedA, 29), 7))), 536870911))
									)

									for i = 1, captured.operandA[pc] do
										local v1039 = bitAnd(bitXor(v34, (leftShift(v34, 13))), 536870911)
										local v1040 = bitXor(v1039, (rightShift(v1039, 13)))
										v34 = bitAnd(bitXor(v1040, (leftShift(v1040, 14))), 536870911)
										captured.operandC[v36] =
											bitXor(captured.operandC[v36], (bitAnd(rightShift(v34, 0), 127)))
										captured.operandB[v36] =
											bitXor(captured.operandB[v36], (bitAnd(rightShift(v34, 7), 127)))
										captured.operandA[v36] =
											bitXor(captured.operandA[v36], (bitAnd(rightShift(v34, 14), 127)))
										captured.opcodes[v36] =
											bitXor(captured.opcodes[v36], (bitAnd(rightShift(v34, 21), 127)))
										v36 = v36 + 1
										local _ = i
									end

									captured.opcodes[pc] = 86
									v797 = 1
									continue
								end

								if v798 == 29 then
									mode = captured.operandA[pc]
									pc = captured.operandB[pc] + 1
									v38 = 1
									break
								end

								registers[captured.operandA[pc]] = registers[captured.operandB[pc]]
									/ captured.operandC[pc]
							end

							v797 = 1
							continue
						elseif v797 == 1 then
							v797 = -1
							pc = pc + 1
							break
						else
							break
						end
					end

					if v38 ~= -1 then
						break
					end
				end

				if v38 ~= -1 then
					continue
				end

				break
			else
				break
			end
		end
	end, ...)

	if v1041 then
		if v1042 then
			if v1043 then
				return registers[v1044](unpackValues(v1045, 1, v1045.n))
			end

			return registers[v1044](unpackValues(registers, v1044 + 1, v1045))
		end

		if v1044 then
			if v1043 then
				return unpackValues(v1044, 1, v1044.n)
			end

			return unpackValues(registers, v1044, v1045)
		end
	else
		local v1046 = u12
		local v1047 = u13

		if v1046 then
			for i in nextEntry, v1046 do
				local v1048 = v1046[i]

				if v1048 then
					v1048[5] = v1048
					v1048[6] = registers[i]
					v1048[4] = 6
					v1046[i] = nil
				end
			end
		end

		if v1047 then
			for i, v in nextEntry, v1047 do
				local v1049 = v[6]

				if v1047 then
					local v1050 = v1047[i]

					if v1050 then
						local v1051 = createRegisters(v1049)
						moveValues(registers, i, i + v1049 - 1, 1, v1051)
						v1050[5] = v1051
						v1050[4] = 1
						v1047[i] = nil
					end
				end
			end
		end

		captured.raiseVMError(captured.runtime, v1042, pc, captured.lineInfo)
	end
end
