-- Decompiled with Potassium's decompiler.

local v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14;
local v15 = 0;

while true do
    if v15 == 0 then
        v15 = -1;
        v6 = nil;
        v7 = nil;
        v8 = nil;
        v9 = nil;
        v10 = UNNAMED_2819735058728(UNNAMED_2819735057624);
        v11 = nil;
        v12 = nil;
        v13 = nil;

        if UNNAMED_2819735069672 ~= 104 then
            v1 = UNNAMED_2819735050760;
            v2 = UNNAMED_2819735050184;
            v3 = UNNAMED_2819735076728;
            v4 = UNNAMED_2819735069672;
            v15 = 6;
            continue;
        end;

        v5 = UNNAMED_2819735076728;
        v2 = UNNAMED_2819735050184;
        v1 = UNNAMED_2819735050760;
        v15 = 1;
        continue;
    elseif v15 == 1 then
        v15 = -1;
        v14 = UNNAMED_2819735079176[v5];

        if v14 < 36 then
            v15 = 15;
            continue;
        end;

        if v14 >= 54 then
            v15 = 2;
            continue;
        end;

        if v14 < 45 then
            if v14 < 40 then
                if v14 < 38 then
                    if v14 == 37 then
                        if UNNAMED_2819735040872[v5] >= v10[UNNAMED_2819735062040[v5]] then
                            v5 = UNNAMED_2819735053592[v5];
                        end;
                    elseif v10[UNNAMED_2819735062040[v5]] ~= UNNAMED_2819735040872[v5] then
                        v5 = UNNAMED_2819735053592[v5];
                    end;
                elseif v14 == 39 then
                    if v10[UNNAMED_2819735053592[v5]] then
                        v5 = UNNAMED_2819735062040[v5];
                    else
                        v5 = UNNAMED_2819735040872[v5];
                    end;
                else
                    local v16 = UNNAMED_2819735053592[v5];
                    local v17 = UNNAMED_2819735065784(v2, UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 28), 15)));
                    local v18 = UNNAMED_2819735062040[v5];
                    local v19 = UNNAMED_2819735040872[v5];
                    local v20 = v18 < 16384 and 7 or (v18 < 2097152 and 14 or 21);
                    local v21 = UNNAMED_2819735072408(v18, UNNAMED_2819735042360(1, v20) - 1);
                    local v22 = UNNAMED_2819735089496(v18, v20);
                    UNNAMED_2819735053592[v5] = UNNAMED_2819735065784(v16, 7, (UNNAMED_2819735072408(UNNAMED_2819735089496(v17, 7), 127)));
                    UNNAMED_2819735079176[v5] = UNNAMED_2819735065784(v22, 31, (UNNAMED_2819735072408(UNNAMED_2819735089496(v17, 21), 127)));
                    UNNAMED_2819735040872[v5] = UNNAMED_2819735065784(v19, 111, (UNNAMED_2819735072408(UNNAMED_2819735089496(v17, 14), 127)));
                    UNNAMED_2819735062040[v5] = UNNAMED_2819735065784(v21, 38, (UNNAMED_2819735072408(v17, 127)));
                    v5 = v5 - 1;
                end;
            elseif v14 < 42 then
                if v14 == 41 then
                    v10[UNNAMED_2819735053592[v5]]();
                else
                    local v23 = UNNAMED_2819735051432[UNNAMED_2819735062040[v5]];
                    v23[5][v23[4]] = v10[UNNAMED_2819735040872[v5]];
                end;
            elseif v14 >= 43 then
                if v14 == 44 then
                    v5 = v10[UNNAMED_2819735040872[v5]];
                else
                    local v24 = UNNAMED_2819735040872[v5];
                    local v25 = UNNAMED_2819735062040[v5];
                    local v26 = UNNAMED_2819735061992[5];
                    local v27 = UNNAMED_2819735065784(v26[v24], 109162203);
                    v26[v24] = v27;
                    local v28 = UNNAMED_2819735061992[4];
                    local v29 = v27 + 1;
                    local v30 = UNNAMED_2819735082584(v28, v29);
                    local v31;

                    if v30 < 128 then
                        v31 = v29 + 1;
                    else
                        local v32 = UNNAMED_2819735082584(v28, v29 + 1);

                        if v32 < 128 then
                            v30 = v30 - 128 + v32 * 128;
                            v31 = v29 + 2;
                        else
                            local v33 = UNNAMED_2819735082584(v28, v29 + 2);

                            if v33 < 128 then
                                v30 = v30 - 128 + (v32 - 128) * 16384 + v33 * 128;
                                v31 = v29 + 3;
                            else
                                local v34 = UNNAMED_2819735082584(v28, v29 + 3);
                                v30 = (v30 - 128) * 16384 + (v32 - 128) * 128 + (v33 - 128) + v34 % 128 * 2097152 + (v34 - v34 % 128) * 2097152;
                                v31 = v29 + 4;
                            end;
                        end;
                    end;

                    local v35 = v25 * 16843009;
                    local v36 = v31 + v30;
                    local v37 = v36 - v30 % 4;

                    for i = v31, v37 - 1, 4 do
                        UNNAMED_2819735074184(v28, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v28, i), v35)));
                        local _ = i;
                    end;

                    for i = v37, v36 - 1 do
                        UNNAMED_2819735081960(v28, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v28, i), v25)));
                        local _ = i;
                    end;

                    UNNAMED_2819735040872[v5] = 78;
                    UNNAMED_2819735062040[v5] = 1;
                    UNNAMED_2819735053592[v5] = 188;
                    UNNAMED_2819735079176[v5] = 62;
                end;
            else
                local v38 = UNNAMED_2819735062040[v5];
                local v39 = UNNAMED_2819735065784(UNNAMED_2819735053592[v5], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                local v40 = UNNAMED_2819735061992[5];
                local v41 = UNNAMED_2819735065784(v40[v38], 109162203);
                v40[v38] = v41;
                local v42 = UNNAMED_2819735061992[4];
                local v43 = v41 + 1;
                local v44 = UNNAMED_2819735082584(v42, v43);
                local v45;

                if v44 < 128 then
                    v45 = v43 + 1;
                else
                    local v46 = UNNAMED_2819735082584(v42, v43 + 1);

                    if v46 < 128 then
                        v44 = v44 - 128 + v46 * 128;
                        v45 = v43 + 2;
                    else
                        local v47 = UNNAMED_2819735082584(v42, v43 + 2);

                        if v47 < 128 then
                            v44 = v44 - 128 + (v46 - 128) * 16384 + v47 * 128;
                            v45 = v43 + 3;
                        else
                            local v48 = UNNAMED_2819735082584(v42, v43 + 3);
                            v44 = (v44 - 128) * 16384 + (v46 - 128) * 128 + (v47 - 128) + v48 % 128 * 2097152 + (v48 - v48 % 128) * 2097152;
                            v45 = v43 + 4;
                        end;
                    end;
                end;

                local v49 = v39 * 16843009;
                local v50 = v45 + v44;
                local v51 = v50 - v44 % 4;

                for i = v45, v51 - 1, 4 do
                    UNNAMED_2819735074184(v42, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v42, i), v49)));
                    local _ = i;
                end;

                for i = v51, v50 - 1 do
                    UNNAMED_2819735081960(v42, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v42, i), v39)));
                    local _ = i;
                end;

                UNNAMED_2819735062040[v5] = 60;
                UNNAMED_2819735053592[v5] = 83;
                UNNAMED_2819735040872[v5] = 210;
                UNNAMED_2819735079176[v5] = 62;
            end;
        elseif v14 >= 49 then
            if v14 >= 51 then
                if v14 >= 52 then
                    if v14 == 53 then
                        v10[UNNAMED_2819735053592[v5]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v5]];
                    else
                        UNNAMED_2819735077736({ ... }, 1, UNNAMED_2819735053592[v5], UNNAMED_2819735040872[v5], v10);
                    end;
                else
                    v10[UNNAMED_2819735062040[v5]](v10[UNNAMED_2819735040872[v5]]);
                end;
            elseif v14 == 50 then
                local v52 = UNNAMED_2819735065784(UNNAMED_2819735053592[v5], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                local v53 = UNNAMED_2819735062040[v5] + 1;

                for i = 1, UNNAMED_2819735040872[v5] do
                    local v54 = UNNAMED_2819735072408(UNNAMED_2819735065784(v52, (UNNAMED_2819735042360(v52, 13))), 536870911);
                    local v55 = UNNAMED_2819735065784(v54, (UNNAMED_2819735089496(v54, 13)));
                    v52 = UNNAMED_2819735072408(UNNAMED_2819735065784(v55, (UNNAMED_2819735042360(v55, 14))), 536870911);
                    UNNAMED_2819735062040[v53] = UNNAMED_2819735065784(UNNAMED_2819735062040[v53], (UNNAMED_2819735072408(UNNAMED_2819735089496(v52, 0), 127)));
                    UNNAMED_2819735053592[v53] = UNNAMED_2819735065784(UNNAMED_2819735053592[v53], (UNNAMED_2819735072408(UNNAMED_2819735089496(v52, 7), 127)));
                    UNNAMED_2819735040872[v53] = UNNAMED_2819735065784(UNNAMED_2819735040872[v53], (UNNAMED_2819735072408(UNNAMED_2819735089496(v52, 14), 127)));
                    UNNAMED_2819735079176[v53] = UNNAMED_2819735065784(UNNAMED_2819735079176[v53], (UNNAMED_2819735072408(UNNAMED_2819735089496(v52, 21), 127)));
                    v53 = v53 + 1;
                    local _ = i;
                end;

                UNNAMED_2819735079176[v5] = 62;
            else
                v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735053592[v5]][UNNAMED_2819735040872[v5]];
            end;
        elseif v14 >= 47 then
            if v14 == 48 then
                v8 = v11[8];
                v12 = v11[5];
                v9 = v11[7];
                v6 = v11[6];
                v11 = v11[9];
            else
                local v56 = UNNAMED_2819735062040[v5];
                local v57 = UNNAMED_2819735053592[v5];
                UNNAMED_2819735077736({ ... }, 1, v56 - 1, v57, v10);
                v10[v57 + v56 - 1] = UNNAMED_2819735092424(UNNAMED_2819735057240(v56, ...));
            end;
        elseif v14 == 46 then
            v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735053592[v5]] + UNNAMED_2819735040872[v5];
        else
            v10[UNNAMED_2819735053592[v5]] = UNNAMED_2819735059640(v10[UNNAMED_2819735062040[v5]], v10[UNNAMED_2819735040872[v5]]);
        end;

        v15 = 14;
        continue;
    elseif v15 == 2 then
        v15 = -1;

        if v14 < 63 then
            v15 = 3;
            continue;
        end;

        if v14 >= 68 then
            if v14 >= 70 then
                if v14 < 71 then
                    if v10[UNNAMED_2819735040872[v5]] >= UNNAMED_2819735053592[v5] then
                        v5 = UNNAMED_2819735062040[v5];
                    end;
                elseif v14 == 72 then
                    v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735040872[v5]] < UNNAMED_2819735062040[v5];
                else
                    v10[UNNAMED_2819735053592[v5]] = UNNAMED_2819735040872[v5];
                end;
            elseif v14 == 69 then
                v11 = {
                    [9] = v11,
                    [7] = v9,
                    [8] = v8,
                    [5] = v12,
                    [6] = v6
                };
                local v58 = UNNAMED_2819735053592[v5];
                v9 = v10[v58 + 2] + 0;
                v12 = v10[v58 + 1] + 0;
                v8 = v10[v58] - v9;
                v5 = UNNAMED_2819735040872[v5];
            else
                v2 = v10[UNNAMED_2819735040872[v5]];
            end;
        elseif v14 < 65 then
            if v14 == 64 then
                v10[UNNAMED_2819735062040[v5]] = UNNAMED_2819735065784(UNNAMED_2819735028104[v5], UNNAMED_2819735045192[v5]);
            else
                local v59 = UNNAMED_2819735062040[v5];
                local v60 = UNNAMED_2819735040872[v5];
                local v61 = UNNAMED_2819735053592[v5];
                local v62 = UNNAMED_2819735065784(v2, UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 28), 15)));
                local v63 = v59 < 2097152 and 7 or 14;
                local v64 = UNNAMED_2819735072408(v59, UNNAMED_2819735042360(1, v63) - 1);
                local v65 = UNNAMED_2819735089496(v59, v63);
                UNNAMED_2819735062040[v5] = UNNAMED_2819735065784(v64, 56, (UNNAMED_2819735072408(v62, 127)));
                UNNAMED_2819735040872[v5] = UNNAMED_2819735065784(v60, 77, (UNNAMED_2819735072408(UNNAMED_2819735089496(v62, 14), 127)));
                UNNAMED_2819735053592[v5] = UNNAMED_2819735065784(v61, 39, (UNNAMED_2819735072408(UNNAMED_2819735089496(v62, 7), 127)));
                UNNAMED_2819735079176[v5] = UNNAMED_2819735065784(v65, 72, (UNNAMED_2819735072408(UNNAMED_2819735089496(v62, 21), 127)));
                v5 = v5 - 1;
            end;
        elseif v14 >= 66 then
            if v14 == 67 then
                local v66 = UNNAMED_2819735062040[v5];
                v10[v66] = v10[v66](v10[v66 + 1], v10[v66 + 2]);
            else
                local v67 = UNNAMED_2819735053592[v5];
                local v68 = UNNAMED_2819735040872[v5] + 1;

                for i = 1, UNNAMED_2819735062040[v5] do
                    local v69 = UNNAMED_2819735072408(UNNAMED_2819735065784(v67, (UNNAMED_2819735042360(v67, 13))), 536870911);
                    local v70 = UNNAMED_2819735065784(v69, (UNNAMED_2819735089496(v69, 13)));
                    v67 = UNNAMED_2819735072408(UNNAMED_2819735065784(v70, (UNNAMED_2819735042360(v70, 14))), 536870911);
                    UNNAMED_2819735062040[v68] = UNNAMED_2819735065784(UNNAMED_2819735062040[v68], (UNNAMED_2819735072408(UNNAMED_2819735089496(v67, 0), 127)));
                    UNNAMED_2819735053592[v68] = UNNAMED_2819735065784(UNNAMED_2819735053592[v68], (UNNAMED_2819735072408(UNNAMED_2819735089496(v67, 7), 127)));
                    UNNAMED_2819735040872[v68] = UNNAMED_2819735065784(UNNAMED_2819735040872[v68], (UNNAMED_2819735072408(UNNAMED_2819735089496(v67, 14), 127)));
                    UNNAMED_2819735079176[v68] = UNNAMED_2819735065784(UNNAMED_2819735079176[v68], (UNNAMED_2819735072408(UNNAMED_2819735089496(v67, 21), 127)));
                    v68 = v68 + 1;
                    local _ = i;
                end;

                UNNAMED_2819735079176[v5] = 62;
            end;
        else
            v10[UNNAMED_2819735040872[v5]] = v10[UNNAMED_2819735062040[v5]] + UNNAMED_2819735045192[v5];
        end;

        v15 = 14;
        continue;
    elseif v15 == 3 then
        v15 = -1;

        if v14 >= 58 then
            v15 = 13;
            continue;
        end;

        if v14 >= 56 then
            v15 = 4;
            continue;
        end;

        if v14 == 55 then
            local v71 = UNNAMED_2819735051432[UNNAMED_2819735040872[v5]];
            v10[UNNAMED_2819735053592[v5]] = v71[5][v71[4]][v10[UNNAMED_2819735062040[v5]]];
        else
            v10[UNNAMED_2819735053592[v5]] = UNNAMED_2819735065784(v10[UNNAMED_2819735062040[v5]], UNNAMED_2819735028104[v5]);
        end;

        v15 = 12;
        continue;
    elseif v15 == 4 then
        v15 = -1;

        if v14 ~= 57 then
            v15 = 5;
            continue;
        end;

        v15 = 11;
        continue;
    elseif v15 == 5 then
        v15 = -1;
        v4 = UNNAMED_2819735040872[v5];
        v3 = UNNAMED_2819735062040[v5] + 1;
        v15 = 6;
        continue;
    elseif v15 == 6 then
        v15 = -1;

        if v4 ~= 138 then
            v15 = 7;
            continue;
        end;

        v15 = 10;
        continue;
    elseif v15 == 7 then
        v15 = -1;

        if v4 ~= 144 then
            v15 = 8;
            continue;
        end;

        v15 = 9;
        continue;
    elseif v15 == 8 then
        v15 = -1;

        if v4 ~= 156 then
            return;
        end;

        while true do
            local v72 = UNNAMED_2819735040872[v3];

            if v72 >= 69 then
                if v72 >= 103 then
                    if v72 < 120 then
                        if v72 < 111 then
                            if v72 < 107 then
                                if v72 < 105 then
                                    if v72 == 104 then
                                        if UNNAMED_2819735053592[v3] >= v10[UNNAMED_2819735079176[v3]] then
                                            v3 = UNNAMED_2819735062040[v3];
                                        end;
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735031560[v3]);
                                    end;
                                elseif v72 == 106 then
                                    v10[UNNAMED_2819735079176[v3]][UNNAMED_2819735062040[v3]] = UNNAMED_2819735045192[v3];
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] == UNNAMED_2819735031560[v3];
                                end;
                            elseif v72 < 109 then
                                if v72 == 108 then
                                    local v73 = UNNAMED_2819735079176[v3];
                                    local v74 = v10[UNNAMED_2819735053592[v3]];
                                    local v75 = UNNAMED_2819735072408(v10[UNNAMED_2819735062040[v3]], 4294967295);
                                    local v76 = UNNAMED_2819735072408(v74, 4294967295);
                                    local v77 = UNNAMED_2819735072408(v75, 65535);
                                    local v78 = UNNAMED_2819735089496(v75, 16);
                                    local v79 = UNNAMED_2819735072408(v76, 65535);
                                    local v80 = UNNAMED_2819735089496(v76, 16);
                                    local v81 = UNNAMED_2819735072408(v77 * v79 + UNNAMED_2819735042360(UNNAMED_2819735072408(v77 * v80 + v78 * v79, 65535), 16), 4294967295) % 4294967296;
                                    v10[v73] = v81 ~= v81 and 0 or v81 - v81 % 1;
                                else
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735062040[v3];
                                end;
                            elseif v72 == 110 then
                                if v10[UNNAMED_2819735079176[v3]] >= UNNAMED_2819735062040[v3] then
                                    v3 = UNNAMED_2819735053592[v3];
                                end;
                            else
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]][v10[UNNAMED_2819735062040[v3]]];
                            end;
                        elseif v72 < 115 then
                            if v72 >= 113 then
                                if v72 == 114 then
                                    v10[UNNAMED_2819735079176[v3]][UNNAMED_2819735045192[v3]] = UNNAMED_2819735062040[v3];
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] < v10[UNNAMED_2819735062040[v3]];
                                end;
                            elseif v72 == 112 then
                                v3 = v10[UNNAMED_2819735053592[v3]];
                            else
                                local v82 = UNNAMED_2819735051432[UNNAMED_2819735053592[v3]];
                                v82[5][v82[4]] = v10[UNNAMED_2819735062040[v3]];
                            end;
                        elseif v72 >= 117 then
                            if v72 < 118 then
                                v10[UNNAMED_2819735062040[v3]](v10[UNNAMED_2819735053592[v3]]);
                            elseif v72 == 119 then
                                v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735059640(v10[UNNAMED_2819735053592[v3]], v10[UNNAMED_2819735062040[v3]]);
                            else
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]]();
                            end;
                        elseif v72 == 116 then
                            v10[UNNAMED_2819735053592[v3]](UNNAMED_2819735060072[v3], v10[UNNAMED_2819735062040[v3]]);
                        elseif v7 then
                            local v83 = UNNAMED_2819735062040[v3];
                            local v84 = v7[v83];

                            if v84 then
                                v84[5] = v84;
                                v84[6] = v10[v83];
                                v84[4] = 6;
                                v7[v83] = nil;
                            end;

                            local v85 = UNNAMED_2819735053592[v3];
                            local v86 = v7[v85];

                            if v86 then
                                v86[5] = v86;
                                v86[6] = v10[v85];
                                v86[4] = 6;
                                v7[v85] = nil;
                            end;

                            local v87 = UNNAMED_2819735079176[v3];
                            local v88 = v7[v87];

                            if v88 then
                                v88[5] = v88;
                                v88[6] = v10[v87];
                                v88[4] = 6;
                                v7[v87] = nil;
                            end;
                        end;
                    elseif v72 >= 129 then
                        if v72 < 133 then
                            if v72 < 131 then
                                if v72 == 130 then
                                    local v89 = UNNAMED_2819735079176[v3];
                                    UNNAMED_2819735077736(v10, v89 + 1, v89 + UNNAMED_2819735062040[v3], UNNAMED_2819735053592[v3] + 1, v10[v89]);
                                else
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735088440[UNNAMED_2819735031560[v3]];
                                end;
                            elseif v72 == 132 then
                                local v90 = nil;
                                local v91 = UNNAMED_2819735053592[v3];
                                local v92 = UNNAMED_2819735031560[v3];
                                local v93 = UNNAMED_2819735060072[v3];
                                local v94 = v93[0];

                                if v94 then
                                    local v95 = #v94 / 3;

                                    if v95 > 0 then
                                        v90 = {};

                                        for i = 1, v95 do
                                            local v96 = (i - 1) * 3;
                                            local v97 = v94[v96 + 2];
                                            local v98 = v94[v96 + 1];
                                            local v99;

                                            if v97 == 2 then
                                                v7 = v7 or {};
                                                local v100 = v7[v98];

                                                if not v100 then
                                                    v100 = {
                                                        [5] = v10,
                                                        [4] = v98
                                                    };
                                                    v7[v98] = v100;
                                                end;

                                                v90[i] = v100;
                                                v99 = i;
                                            elseif v97 == 0 then
                                                v90[i] = v10[v98];
                                                v99 = i;
                                            elseif v97 == 3 then
                                                v90[i] = UNNAMED_2819735051432[v98];
                                                v99 = i;
                                            elseif v97 == 1 then
                                                v13 = v13 or {};
                                                local v101 = v13[v98];

                                                if not v101 then
                                                    v101 = {
                                                        [5] = v10,
                                                        [4] = v98,
                                                        [6] = v94[v96 + 3]
                                                    };
                                                    v13[v98] = v101;
                                                end;

                                                v90[i] = v101;
                                                v99 = i;
                                            else
                                                v99 = i;
                                            end;
                                        end;
                                    end;
                                end;

                                local v102 = v93[-2];
                                v93[v102] = v90;
                                local v103 = v92(UNNAMED_2819735089688(v93, 1, v93[-1]));
                                v93[v102] = nil;
                                v10[v91] = v103;
                            else
                                v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] <= v10[UNNAMED_2819735079176[v3]];
                            end;
                        elseif v72 < 135 then
                            if v72 == 134 then
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] % UNNAMED_2819735062040[v3];
                            else
                                v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735079176[v3]] // v10[UNNAMED_2819735062040[v3]];
                            end;
                        elseif v72 >= 136 then
                            if v72 == 137 then
                                if v7 then
                                    local v104 = UNNAMED_2819735079176[v3];
                                    local v105 = v7[v104];

                                    if v105 then
                                        v105[5] = v105;
                                        v105[6] = v10[v104];
                                        v105[4] = 6;
                                        v7[v104] = nil;
                                    end;

                                    local v106 = UNNAMED_2819735053592[v3];
                                    local v107 = v7[v106];

                                    if v107 then
                                        v107[5] = v107;
                                        v107[6] = v10[v106];
                                        v107[4] = 6;
                                        v7[v106] = nil;
                                    end;
                                end;
                            else
                                v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735089496(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735062040[v3]);
                            end;
                        else
                            v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735068856[UNNAMED_2819735045192[v3]];
                        end;
                    elseif v72 < 124 then
                        if v72 < 122 then
                            if v72 == 121 then
                                local v108 = UNNAMED_2819735062040[v3];
                                local v109 = UNNAMED_2819735077352(UNNAMED_2819735064680);
                                v109(UNNAMED_2819735068856, v10[v108], v10[v108 + 1], v10[v108 + 2]);
                                local v110 = UNNAMED_2819735053592[v3];
                                v3 = UNNAMED_2819735079176[v3];
                                v8 = v109;
                                v6 = v110;
                                v11 = {
                                    [9] = v11,
                                    [7] = v9,
                                    [8] = v8,
                                    [5] = v12,
                                    [6] = v6
                                };
                            else
                                v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] * UNNAMED_2819735045192[v3];
                            end;
                        elseif v72 == 123 then
                            UNNAMED_2819735068856[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]];
                        else
                            v10[UNNAMED_2819735053592[v3]] = not v10[UNNAMED_2819735079176[v3]];
                        end;
                    elseif v72 >= 126 then
                        if v72 < 127 then
                            local v111 = UNNAMED_2819735053592[v3];
                            local v112 = UNNAMED_2819735062040[v3];
                            local v113 = UNNAMED_2819735061992[5];
                            local v114 = UNNAMED_2819735065784(v113[v111], 109162203);
                            v113[v111] = v114;
                            local v115 = UNNAMED_2819735061992[4];
                            local v116 = v114 + 1;
                            local v117 = UNNAMED_2819735082584(v115, v116);
                            local v118;

                            if v117 < 128 then
                                v118 = v116 + 1;
                            else
                                local v119 = UNNAMED_2819735082584(v115, v116 + 1);

                                if v119 < 128 then
                                    v117 = v117 - 128 + v119 * 128;
                                    v118 = v116 + 2;
                                else
                                    local v120 = UNNAMED_2819735082584(v115, v116 + 2);

                                    if v120 < 128 then
                                        v117 = v117 - 128 + (v119 - 128) * 16384 + v120 * 128;
                                        v118 = v116 + 3;
                                    else
                                        local v121 = UNNAMED_2819735082584(v115, v116 + 3);
                                        v117 = (v117 - 128) * 16384 + (v119 - 128) * 128 + (v120 - 128) + v121 % 128 * 2097152 + (v121 - v121 % 128) * 2097152;
                                        v118 = v116 + 4;
                                    end;
                                end;
                            end;

                            local v122 = v112 * 16843009;
                            local v123 = v118 + v117;
                            local v124 = v123 - v117 % 4;

                            for i = v118, v124 - 1, 4 do
                                UNNAMED_2819735074184(v115, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v115, i), v122)));
                                local _ = i;
                            end;

                            for i = v124, v123 - 1 do
                                UNNAMED_2819735081960(v115, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v115, i), v112)));
                                local _ = i;
                            end;

                            UNNAMED_2819735053592[v3] = 221;
                            UNNAMED_2819735062040[v3] = 131;
                            UNNAMED_2819735079176[v3] = 226;
                            UNNAMED_2819735040872[v3] = 11;
                        elseif v72 == 128 then
                            local v125 = UNNAMED_2819735051432[UNNAMED_2819735053592[v3]];
                            v10[UNNAMED_2819735079176[v3]] = v125[5][v125[4]][v10[UNNAMED_2819735062040[v3]]];
                        else
                            v10[UNNAMED_2819735079176[v3]][UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]];
                        end;
                    elseif v72 == 125 then
                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735059640(v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735060072[v3]);
                    else
                        v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735079176[v3]], v10[UNNAMED_2819735053592[v3]]);
                    end;
                elseif v72 >= 86 then
                    if v72 < 94 then
                        if v72 >= 90 then
                            if v72 < 92 then
                                if v72 == 91 then
                                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] + UNNAMED_2819735079176[v3];
                                else
                                    v10[UNNAMED_2819735053592[v3]](v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735031560[v3]);
                                end;
                            else
                                if v72 ~= 93 then
                                    if v7 then
                                        for i in UNNAMED_2819735091272, v7 do
                                            local v126 = v7[i];

                                            if v126 then
                                                v126[5] = v126;
                                                v126[6] = v10[i];
                                                v126[4] = 6;
                                                v7[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v13 then
                                        for i, v in UNNAMED_2819735091272, v13 do
                                            local v127 = v[6];

                                            if v13 then
                                                local v128 = v13[i];

                                                if v128 then
                                                    local v129 = UNNAMED_2819735058728(v127);
                                                    UNNAMED_2819735077736(v10, i, i + v127 - 1, 1, v129);
                                                    v128[5] = v129;
                                                    v128[4] = 1;
                                                    v13[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return;
                                end;

                                local v130 = UNNAMED_2819735053592[v3];
                                local v131 = UNNAMED_2819735062040[v3];
                                local v132 = UNNAMED_2819735079176[v3];
                                local v133 = UNNAMED_2819735065784(v1, UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 28), 15)));
                                local v134 = v130 < 2097152 and 7 or 14;
                                local v135 = UNNAMED_2819735089496(v130, v134);
                                local v136 = UNNAMED_2819735072408(v130, UNNAMED_2819735042360(1, v134) - 1);
                                UNNAMED_2819735079176[v3] = UNNAMED_2819735065784(v132, 17, (UNNAMED_2819735072408(UNNAMED_2819735089496(v133, 7), 127)));
                                UNNAMED_2819735040872[v3] = UNNAMED_2819735065784(v135, 102, (UNNAMED_2819735072408(UNNAMED_2819735089496(v133, 21), 127)));
                                UNNAMED_2819735062040[v3] = UNNAMED_2819735065784(v131, 100, (UNNAMED_2819735072408(UNNAMED_2819735089496(v133, 14), 127)));
                                UNNAMED_2819735053592[v3] = UNNAMED_2819735065784(v136, 69, (UNNAMED_2819735072408(v133, 127)));
                                v3 = v3 - 1;
                            end;
                        elseif v72 >= 88 then
                            if v72 == 89 then
                                if v10[UNNAMED_2819735053592[v3]] > UNNAMED_2819735079176[v3] then
                                    v3 = UNNAMED_2819735062040[v3];
                                end;
                            else
                                v10[UNNAMED_2819735062040[v3]][v10[UNNAMED_2819735079176[v3]]] = UNNAMED_2819735045192[v3];
                            end;
                        elseif v72 == 87 then
                            v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735068856;
                        else
                            local v137 = UNNAMED_2819735079176[v3];
                            local v138, v139 = v8();

                            if v138 then
                                v10[v137] = v139;
                                v3 = UNNAMED_2819735053592[v3];
                            else
                                v3 = UNNAMED_2819735062040[v3];
                            end;
                        end;
                    elseif v72 >= 98 then
                        if v72 >= 100 then
                            if v72 >= 101 then
                                if v72 == 102 then
                                    if v7 then
                                        for i in UNNAMED_2819735091272, v7 do
                                            local v140 = v7[i];

                                            if v140 then
                                                v140[5] = v140;
                                                v140[6] = v10[i];
                                                v140[4] = 6;
                                                v7[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v13 then
                                        for i, v in UNNAMED_2819735091272, v13 do
                                            local v141 = v[6];

                                            if v13 then
                                                local v142 = v13[i];

                                                if v142 then
                                                    local v143 = UNNAMED_2819735058728(v141);
                                                    UNNAMED_2819735077736(v10, i, i + v141 - 1, 1, v143);
                                                    v142[5] = v143;
                                                    v142[4] = 1;
                                                    v13[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return v10[UNNAMED_2819735079176[v3]];
                                end;

                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] * v10[UNNAMED_2819735062040[v3]];
                            elseif UNNAMED_2819735062040[v3] > v10[UNNAMED_2819735053592[v3]] then
                                v3 = UNNAMED_2819735079176[v3];
                            end;
                        elseif v72 == 99 then
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] // UNNAMED_2819735062040[v3];
                        else
                            local v144 = UNNAMED_2819735062040[v3];
                            local v145, v146, v147 = v8();

                            if v145 then
                                v10[v144] = v146;
                                v10[v144 + 1] = v147;
                                v3 = UNNAMED_2819735053592[v3];
                            else
                                v3 = UNNAMED_2819735079176[v3];
                            end;
                        end;
                    elseif v72 < 96 then
                        if v72 == 95 then
                            local v148 = UNNAMED_2819735062040[v3];
                            local v149 = UNNAMED_2819735053592[v3];
                            local v150 = UNNAMED_2819735079176[v3];
                            local _ = v148 + v150 - 1;
                            local v151 = v148 + v149;
                            local v152 = v10[v151];
                            local n = v152.n;
                            v152.n = v149 + n - 1;
                            UNNAMED_2819735077736(v152, 1, n, v149, v152);
                            UNNAMED_2819735077736(v10, v148 + 1, v151 - 1, 1, v152);
                            UNNAMED_2819735077736(UNNAMED_2819735092424(v10[v148](UNNAMED_2819735089688(v152, 1, v152.n))), 1, v150, v148, v10);
                        else
                            local v153 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                            v153[5][v153[4]] = UNNAMED_2819735060072[v3];
                        end;
                    elseif v72 == 97 then
                        v10[UNNAMED_2819735053592[v3]]();
                    else
                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735065784(UNNAMED_2819735045192[v3], UNNAMED_2819735031560[v3]);
                    end;
                elseif v72 < 77 then
                    if v72 < 73 then
                        if v72 < 71 then
                            if v72 == 70 then
                                v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]][UNNAMED_2819735060072[v3]];
                            else
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] >= v10[UNNAMED_2819735053592[v3]];
                            end;
                        elseif v72 == 72 then
                            v10[UNNAMED_2819735062040[v3]] = {};
                        else
                            local v154 = UNNAMED_2819735053592[v3];
                            local _ = UNNAMED_2819735079176[v3];
                            v10[v154] = UNNAMED_2819735092424(v10[v154](UNNAMED_2819735089688(v10, v154 + 1, v154 + UNNAMED_2819735062040[v3])));
                        end;
                    elseif v72 >= 75 then
                        if v72 == 76 then
                            v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] == UNNAMED_2819735079176[v3];
                        else
                            v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735053592[v3]], v10[UNNAMED_2819735062040[v3]]);
                        end;
                    else
                        if v72 == 74 then
                            if v7 then
                                for i in UNNAMED_2819735091272, v7 do
                                    local v155 = v7[i];

                                    if v155 then
                                        v155[5] = v155;
                                        v155[6] = v10[i];
                                        v155[4] = 6;
                                        v7[i] = nil;
                                    end;
                                end;
                            end;

                            if v13 then
                                for i, v in UNNAMED_2819735091272, v13 do
                                    local v156 = v[6];

                                    if v13 then
                                        local v157 = v13[i];

                                        if v157 then
                                            local v158 = UNNAMED_2819735058728(v156);
                                            UNNAMED_2819735077736(v10, i, i + v156 - 1, 1, v158);
                                            v157[5] = v158;
                                            v157[4] = 1;
                                            v13[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return UNNAMED_2819735031560[v3];
                        end;

                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735058728(UNNAMED_2819735053592[v3]);
                    end;
                elseif v72 >= 81 then
                    if v72 >= 83 then
                        if v72 >= 84 then
                            if v72 == 85 then
                                local v159 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                v10[UNNAMED_2819735053592[v3]] = v159[5][v159[4]];
                            else
                                v2 = v10[UNNAMED_2819735062040[v3]];
                            end;
                        else
                            v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735053592[v3]);
                        end;
                    elseif v72 == 82 then
                        local v160 = UNNAMED_2819735062040[v3];
                        local v161 = UNNAMED_2819735053592[v3] + 1;

                        for i = 1, UNNAMED_2819735079176[v3] do
                            local v162 = UNNAMED_2819735072408(UNNAMED_2819735065784(v160, (UNNAMED_2819735042360(v160, 13))), 536870911);
                            local v163 = UNNAMED_2819735065784(v162, (UNNAMED_2819735089496(v162, 13)));
                            v160 = UNNAMED_2819735072408(UNNAMED_2819735065784(v163, (UNNAMED_2819735042360(v163, 14))), 536870911);
                            UNNAMED_2819735053592[v161] = UNNAMED_2819735065784(UNNAMED_2819735053592[v161], (UNNAMED_2819735072408(UNNAMED_2819735089496(v160, 0), 127)));
                            UNNAMED_2819735079176[v161] = UNNAMED_2819735065784(UNNAMED_2819735079176[v161], (UNNAMED_2819735072408(UNNAMED_2819735089496(v160, 7), 127)));
                            UNNAMED_2819735062040[v161] = UNNAMED_2819735065784(UNNAMED_2819735062040[v161], (UNNAMED_2819735072408(UNNAMED_2819735089496(v160, 14), 127)));
                            UNNAMED_2819735040872[v161] = UNNAMED_2819735065784(UNNAMED_2819735040872[v161], (UNNAMED_2819735072408(UNNAMED_2819735089496(v160, 21), 127)));
                            v161 = v161 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735040872[v3] = 11;
                    else
                        local v164 = UNNAMED_2819735053592[v3];
                        local v165 = UNNAMED_2819735060072[v3];
                        local v166 = UNNAMED_2819735072408(UNNAMED_2819735031560[v3], 4294967295);
                        local v167 = UNNAMED_2819735072408(v165, 4294967295);
                        local v168 = UNNAMED_2819735072408(v166, 65535);
                        local v169 = UNNAMED_2819735089496(v166, 16);
                        local v170 = UNNAMED_2819735072408(v167, 65535);
                        local v171 = UNNAMED_2819735089496(v167, 16);
                        local v172 = UNNAMED_2819735072408(v168 * v170 + UNNAMED_2819735042360(UNNAMED_2819735072408(v168 * v171 + v169 * v170, 65535), 16), 4294967295) % 4294967296;
                        v10[v164] = v172 ~= v172 and 0 or v172 - v172 % 1;
                    end;
                elseif v72 < 79 then
                    if v72 == 78 then
                        v10[UNNAMED_2819735062040[v3]] = v10;
                    else
                        UNNAMED_2819735068856[UNNAMED_2819735060072[v3]] = v10[UNNAMED_2819735062040[v3]];
                    end;
                elseif v72 == 80 then
                    local v173 = UNNAMED_2819735062040[v3];
                    local v174 = UNNAMED_2819735079176[v3];
                    local v175 = UNNAMED_2819735053592[v3];
                    local v176 = v10[v173];
                    local v177 = v173 + v174;
                    local v178 = v10[v177];
                    UNNAMED_2819735077736(v10, v173 + 1, v177 - 1, v175 + 1, v176);
                    UNNAMED_2819735077736(v178, 1, v178.n, v175 + v174, v176);
                else
                    v10[UNNAMED_2819735053592[v3]](v10[UNNAMED_2819735062040[v3]], v10[UNNAMED_2819735079176[v3]]);
                end;
            elseif v72 >= 34 then
                if v72 >= 51 then
                    if v72 >= 60 then
                        if v72 < 64 then
                            if v72 < 62 then
                                if v72 == 61 then
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735053592[v3] + v10[UNNAMED_2819735062040[v3]];
                                else
                                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] - UNNAMED_2819735045192[v3];
                                end;
                            elseif v72 == 63 then
                                v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735060072[v3];
                            else
                                local v179 = UNNAMED_2819735062040[v3];
                                local v180 = UNNAMED_2819735053592[v3];
                                local v181 = UNNAMED_2819735079176[v3];
                                local _ = v179 + v181 - 1;
                                local _ = v179 + v180;
                                UNNAMED_2819735077736(UNNAMED_2819735092424(v10[v179](UNNAMED_2819735089688(v10, v179 + 1, v179 + v180))), 1, v181, v179, v10);
                            end;
                        elseif v72 < 66 then
                            if v72 == 65 then
                                v1 = v10[UNNAMED_2819735062040[v3]];
                            else
                                local v182 = UNNAMED_2819735079176[v3];
                                local v183 = v10[UNNAMED_2819735062040[v3]];
                                v10[v182 + 1] = v183;
                                v10[v182] = v183[UNNAMED_2819735045192[v3]];
                            end;
                        elseif v72 >= 67 then
                            if v72 == 68 then
                                v10[UNNAMED_2819735062040[v3]][v10[UNNAMED_2819735053592[v3]]] = v10[UNNAMED_2819735079176[v3]];
                            elseif v10[UNNAMED_2819735053592[v3]] ~= UNNAMED_2819735062040[v3] then
                                v3 = UNNAMED_2819735079176[v3];
                            end;
                        else
                            v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] * UNNAMED_2819735053592[v3];
                        end;
                    elseif v72 >= 55 then
                        if v72 >= 57 then
                            if v72 >= 58 then
                                if v72 == 59 then
                                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] - v10[UNNAMED_2819735053592[v3]];
                                else
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735088440[UNNAMED_2819735031560[v3]][UNNAMED_2819735045192[v3]];
                                end;
                            else
                                v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735045192[v3] + UNNAMED_2819735060072[v3];
                            end;
                        else
                            if v72 ~= 56 then
                                if v7 then
                                    for i in UNNAMED_2819735091272, v7 do
                                        local v184 = v7[i];

                                        if v184 then
                                            v184[5] = v184;
                                            v184[6] = v10[i];
                                            v184[4] = 6;
                                            v7[i] = nil;
                                        end;
                                    end;
                                end;

                                if v13 then
                                    for i, v in UNNAMED_2819735091272, v13 do
                                        local v185 = v[6];

                                        if v13 then
                                            local v186 = v13[i];

                                            if v186 then
                                                local v187 = UNNAMED_2819735058728(v185);
                                                UNNAMED_2819735077736(v10, i, i + v185 - 1, 1, v187);
                                                v186[5] = v187;
                                                v186[4] = 1;
                                                v13[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return v10[UNNAMED_2819735062040[v3]], v10[UNNAMED_2819735079176[v3]];
                            end;

                            if v10[UNNAMED_2819735062040[v3]] then
                                v3 = UNNAMED_2819735053592[v3];
                            else
                                v3 = UNNAMED_2819735079176[v3];
                            end;
                        end;
                    elseif v72 < 53 then
                        if v72 == 52 then
                            v10[UNNAMED_2819735062040[v3]] = v2;
                        else
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]][UNNAMED_2819735053592[v3]];
                        end;
                    elseif v72 == 54 then
                        v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735031560[v3], UNNAMED_2819735045192[v3]);
                        v10[UNNAMED_2819735079176[v3 + 1]] = UNNAMED_2819735062040[v3 + 1];
                        v10[UNNAMED_2819735053592[v3 + 2]]();
                        v3 = v3 + 2;
                    else
                        v10[UNNAMED_2819735079176[v3]][UNNAMED_2819735031560[v3]] = v10[UNNAMED_2819735053592[v3]];
                    end;
                elseif v72 < 42 then
                    if v72 < 38 then
                        if v72 >= 36 then
                            if v72 == 37 then
                                v10[UNNAMED_2819735079176[v3]][UNNAMED_2819735053592[v3]] = UNNAMED_2819735062040[v3];
                            else
                                v10[UNNAMED_2819735079176[v3]] = v1;
                            end;
                        elseif v72 == 35 then
                            v8 = v11[8];
                            v12 = v11[5];
                            v9 = v11[7];
                            v6 = v11[6];
                            v11 = v11[9];
                        else
                            v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735031560[v3], UNNAMED_2819735045192[v3]);
                        end;
                    elseif v72 >= 40 then
                        if v72 == 41 then
                            v10[UNNAMED_2819735079176[v3]] = #v10[UNNAMED_2819735062040[v3]];
                        else
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] ~= UNNAMED_2819735031560[v3];
                        end;
                    elseif v72 == 39 then
                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] + v10[UNNAMED_2819735079176[v3]];
                    else
                        local v188 = UNNAMED_2819735053592[v3];
                        local v189 = UNNAMED_2819735062040[v3];
                        v10[v188] = UNNAMED_2819735060072[v3];
                        v10[v188 + 1] = v189;
                    end;
                elseif v72 >= 46 then
                    if v72 >= 48 then
                        if v72 < 49 then
                            v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735031560[v3], UNNAMED_2819735045192[v3]);
                            v10[UNNAMED_2819735079176[v3 + 1]] = UNNAMED_2819735062040[v3 + 1];
                            v10[UNNAMED_2819735053592[v3 + 2]]();
                            v10[UNNAMED_2819735079176[v3 + 3]] = UNNAMED_2819735062040[v3 + 3];
                            v3 = v3 + 3;
                        elseif v72 == 50 then
                            local v190 = UNNAMED_2819735079176[v3];
                            local v191 = UNNAMED_2819735045192[v3];
                            v10[v190] = UNNAMED_2819735062040[v3];
                            v10[v190 + 1] = v191;
                        else
                            local v192 = UNNAMED_2819735053592[v3];
                            local v193 = v10[UNNAMED_2819735062040[v3]];
                            v10[v192] = UNNAMED_2819735079176[v3];
                            v10[v192 + 1] = v193;
                        end;
                    elseif v72 == 47 then
                        v10[UNNAMED_2819735053592[v3]](v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735031560[v3]);
                        v10[UNNAMED_2819735053592[v3 + 1]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v3 + 1]];
                        v10[UNNAMED_2819735053592[v3 + 2]](v10[UNNAMED_2819735079176[v3 + 2]], UNNAMED_2819735031560[v3 + 2]);
                        v3 = v3 + 2;
                    elseif v10[UNNAMED_2819735079176[v3]] then
                        v3 = UNNAMED_2819735062040[v3];
                    else
                        v3 = UNNAMED_2819735053592[v3];
                    end;
                elseif v72 >= 44 then
                    if v72 == 45 then
                        local v194 = UNNAMED_2819735053592[v3];
                        local v195 = v10[UNNAMED_2819735079176[v3]];
                        v10[v194] = UNNAMED_2819735031560[v3];
                        v10[v194 + 1] = v195;
                    else
                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] ~= UNNAMED_2819735053592[v3];
                    end;
                elseif v72 == 43 then
                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v3]];
                    v10[UNNAMED_2819735053592[v3 + 1]](v10[UNNAMED_2819735079176[v3 + 1]], UNNAMED_2819735031560[v3 + 1]);
                    v10[UNNAMED_2819735053592[v3 + 2]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v3 + 2]];
                    v3 = v3 + 2;
                else
                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] <= UNNAMED_2819735079176[v3];
                end;
            elseif v72 >= 17 then
                if v72 >= 25 then
                    if v72 < 29 then
                        if v72 < 27 then
                            if v72 == 26 then
                                v3 = UNNAMED_2819735062040[v3];
                            else
                                v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735045192[v3] + v10[UNNAMED_2819735079176[v3]];
                            end;
                        elseif v72 == 28 then
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] - UNNAMED_2819735053592[v3];
                        else
                            local v196 = UNNAMED_2819735079176[v3];
                            local v197 = UNNAMED_2819735053592[v3];
                            local v198 = UNNAMED_2819735062040[v3];
                            local v199 = UNNAMED_2819735065784(v1, UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 28), 15)));
                            local v200 = v198 < 16384 and 7 or (v198 < 2097152 and 14 or 21);
                            local v201 = UNNAMED_2819735072408(v198, UNNAMED_2819735042360(1, v200) - 1);
                            UNNAMED_2819735040872[v3] = UNNAMED_2819735065784(UNNAMED_2819735089496(v198, v200), 104, (UNNAMED_2819735072408(UNNAMED_2819735089496(v199, 21), 127)));
                            UNNAMED_2819735079176[v3] = UNNAMED_2819735065784(v196, 5, (UNNAMED_2819735072408(UNNAMED_2819735089496(v199, 7), 127)));
                            UNNAMED_2819735062040[v3] = UNNAMED_2819735065784(v201, 49, (UNNAMED_2819735072408(UNNAMED_2819735089496(v199, 14), 127)));
                            UNNAMED_2819735053592[v3] = UNNAMED_2819735065784(v197, 2, (UNNAMED_2819735072408(v199, 127)));
                            v3 = v3 - 1;
                        end;
                    elseif v72 >= 31 then
                        if v72 >= 32 then
                            if v72 == 33 then
                                local v202 = v10[UNNAMED_2819735079176[v3]] % 4294967296;
                                v10[UNNAMED_2819735053592[v3]] = v202 ~= v202 and 0 or v202 - v202 % 1;
                            elseif v7 then
                                local v203 = UNNAMED_2819735079176[v3];
                                local v204 = v7[v203];

                                if v204 then
                                    v204[5] = v204;
                                    v204[6] = v10[v203];
                                    v204[4] = 6;
                                    v7[v203] = nil;
                                end;
                            end;
                        else
                            local v205 = UNNAMED_2819735065784(UNNAMED_2819735079176[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
                            local v206 = UNNAMED_2819735053592[v3] + 1;

                            for i = 1, UNNAMED_2819735062040[v3] do
                                local v207 = UNNAMED_2819735072408(UNNAMED_2819735065784(v205, (UNNAMED_2819735042360(v205, 13))), 536870911);
                                local v208 = UNNAMED_2819735065784(v207, (UNNAMED_2819735089496(v207, 13)));
                                v205 = UNNAMED_2819735072408(UNNAMED_2819735065784(v208, (UNNAMED_2819735042360(v208, 14))), 536870911);
                                UNNAMED_2819735053592[v206] = UNNAMED_2819735065784(UNNAMED_2819735053592[v206], (UNNAMED_2819735072408(UNNAMED_2819735089496(v205, 0), 127)));
                                UNNAMED_2819735079176[v206] = UNNAMED_2819735065784(UNNAMED_2819735079176[v206], (UNNAMED_2819735072408(UNNAMED_2819735089496(v205, 7), 127)));
                                UNNAMED_2819735062040[v206] = UNNAMED_2819735065784(UNNAMED_2819735062040[v206], (UNNAMED_2819735072408(UNNAMED_2819735089496(v205, 14), 127)));
                                UNNAMED_2819735040872[v206] = UNNAMED_2819735065784(UNNAMED_2819735040872[v206], (UNNAMED_2819735072408(UNNAMED_2819735089496(v205, 21), 127)));
                                v206 = v206 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735040872[v3] = 11;
                        end;
                    elseif v72 == 30 then
                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735036216(v10[UNNAMED_2819735053592[v3]]);
                    else
                        local v209 = UNNAMED_2819735065784(UNNAMED_2819735079176[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                        local v210 = UNNAMED_2819735053592[v3] + 1;

                        for i = 1, UNNAMED_2819735062040[v3] do
                            local v211 = UNNAMED_2819735072408(UNNAMED_2819735065784(v209, (UNNAMED_2819735042360(v209, 13))), 536870911);
                            local v212 = UNNAMED_2819735065784(v211, (UNNAMED_2819735089496(v211, 13)));
                            v209 = UNNAMED_2819735072408(UNNAMED_2819735065784(v212, (UNNAMED_2819735042360(v212, 14))), 536870911);
                            UNNAMED_2819735053592[v210] = UNNAMED_2819735065784(UNNAMED_2819735053592[v210], (UNNAMED_2819735072408(UNNAMED_2819735089496(v209, 0), 127)));
                            UNNAMED_2819735079176[v210] = UNNAMED_2819735065784(UNNAMED_2819735079176[v210], (UNNAMED_2819735072408(UNNAMED_2819735089496(v209, 7), 127)));
                            UNNAMED_2819735062040[v210] = UNNAMED_2819735065784(UNNAMED_2819735062040[v210], (UNNAMED_2819735072408(UNNAMED_2819735089496(v209, 14), 127)));
                            UNNAMED_2819735040872[v210] = UNNAMED_2819735065784(UNNAMED_2819735040872[v210], (UNNAMED_2819735072408(UNNAMED_2819735089496(v209, 21), 127)));
                            v210 = v210 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735040872[v3] = 11;
                    end;
                elseif v72 < 21 then
                    if v72 < 19 then
                        if v72 == 18 then
                            v10[UNNAMED_2819735053592[v3]][UNNAMED_2819735031560[v3]] = UNNAMED_2819735060072[v3];
                        else
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] + UNNAMED_2819735031560[v3];
                        end;
                    elseif v72 == 20 then
                        local v213 = UNNAMED_2819735062040[v3];
                        local v214 = UNNAMED_2819735053592[v3];
                        v10[v213] = UNNAMED_2819735079176[v3];
                        v10[v213 + 1] = v214;
                    else
                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] < UNNAMED_2819735053592[v3];
                    end;
                elseif v72 < 23 then
                    if v72 == 22 then
                        v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735053592[v3]);
                    else
                        local v215 = UNNAMED_2819735062040[v3];
                        local v216 = UNNAMED_2819735060072[v3];
                        v10[v215] = UNNAMED_2819735045192[v3];
                        v10[v215 + 1] = v216;
                    end;
                elseif v72 == 24 then
                    for i = UNNAMED_2819735053592[v3], UNNAMED_2819735079176[v3] do
                        v10[i] = nil;
                        local _ = i;
                    end;
                else
                    v11 = {
                        [9] = v11,
                        [7] = v9,
                        [8] = v8,
                        [5] = v12,
                        [6] = v6
                    };
                    local v217 = UNNAMED_2819735079176[v3];
                    v9 = v10[v217 + 2] + 0;
                    v12 = v10[v217 + 1] + 0;
                    v8 = v10[v217] - v9;
                    v3 = UNNAMED_2819735053592[v3];
                end;
            elseif v72 >= 8 then
                if v72 >= 12 then
                    if v72 < 14 then
                        if v72 == 13 then
                            v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735079176[v3] * v10[UNNAMED_2819735053592[v3]];
                        else
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]];
                        end;
                    elseif v72 < 15 then
                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]](v10[UNNAMED_2819735053592[v3]]);
                    elseif v72 == 16 then
                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v3]];
                    else
                        v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735053592[v3] - v10[UNNAMED_2819735079176[v3]];
                    end;
                elseif v72 < 10 then
                    if v72 == 9 then
                        if v7 then
                            for i in UNNAMED_2819735091272, v7 do
                                local v218 = v7[i];

                                if v218 then
                                    v218[5] = v218;
                                    v218[6] = v10[i];
                                    v218[4] = 6;
                                    v7[i] = nil;
                                end;
                            end;
                        end;

                        if v13 then
                            for i, v in UNNAMED_2819735091272, v13 do
                                local v219 = v[6];

                                if v13 then
                                    local v220 = v13[i];

                                    if v220 then
                                        local v221 = UNNAMED_2819735058728(v219);
                                        UNNAMED_2819735077736(v10, i, i + v219 - 1, 1, v221);
                                        v220[5] = v221;
                                        v220[4] = 1;
                                        v13[i] = nil;
                                    end;
                                end;
                            end;
                        end;

                        return v10[UNNAMED_2819735053592[v3]](UNNAMED_2819735089688(v10[UNNAMED_2819735062040[v3]], 1, v10[UNNAMED_2819735062040[v3]].n));
                    end;

                    local v222 = UNNAMED_2819735079176[v3];
                    local v223 = v10[UNNAMED_2819735062040[v3]];
                    v10[v222] = v10[UNNAMED_2819735053592[v3]];
                    v10[v222 + 1] = v223;
                elseif v72 ~= 11 then
                    v10[UNNAMED_2819735062040[v3]](v10[UNNAMED_2819735053592[v3]]);
                    v10[UNNAMED_2819735053592[v3 + 1]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v3 + 1]];
                    v10[UNNAMED_2819735062040[v3 + 2]](v10[UNNAMED_2819735053592[v3 + 2]]);
                    v10[UNNAMED_2819735053592[v3 + 3]] = UNNAMED_2819735068856[UNNAMED_2819735062040[v3 + 3]];
                    v3 = v3 + 3;
                end;
            elseif v72 < 4 then
                if v72 >= 2 then
                    if v72 == 3 then
                        v8 = v8 + v9;
                        local v224;

                        if v9 <= 0 then
                            v224 = v12 <= v8;
                        else
                            v224 = v8 <= v12;
                        end;

                        if v224 then
                            v10[UNNAMED_2819735062040[v3]] = v8;
                            v3 = UNNAMED_2819735053592[v3];
                        else
                            v3 = UNNAMED_2819735079176[v3];
                        end;
                    else
                        local v225 = UNNAMED_2819735053592[v3];
                        local v226 = UNNAMED_2819735079176[v3];
                        local _ = UNNAMED_2819735062040[v3];
                        local v227 = v225 + v226;
                        local v228 = v10[v227];
                        local n = v228.n;
                        v228.n = v226 + n - 1;
                        UNNAMED_2819735077736(v228, 1, n, v226, v228);
                        UNNAMED_2819735077736(v10, v225 + 1, v227 - 1, 1, v228);
                        v10[v225] = UNNAMED_2819735092424(v10[v225](UNNAMED_2819735089688(v228, 1, v228.n)));
                    end;
                elseif v72 == 1 then
                    v10[UNNAMED_2819735062040[v3]](UNNAMED_2819735060072[v3]);
                else
                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]](UNNAMED_2819735060072[v3]);
                end;
            elseif v72 < 6 then
                if v72 == 5 then
                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735042360(v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735079176[v3]);
                else
                    UNNAMED_2819735068856[UNNAMED_2819735045192[v3]] = UNNAMED_2819735031560[v3];
                end;
            elseif v72 == 7 then
                local v229 = UNNAMED_2819735062040[v3];
                local v230 = v10[UNNAMED_2819735053592[v3]];
                local v231 = UNNAMED_2819735072408(UNNAMED_2819735060072[v3], 4294967295);
                local v232 = UNNAMED_2819735072408(v230, 4294967295);
                local v233 = UNNAMED_2819735072408(v231, 65535);
                local v234 = UNNAMED_2819735089496(v231, 16);
                local v235 = UNNAMED_2819735072408(v232, 65535);
                local v236 = UNNAMED_2819735089496(v232, 16);
                local v237 = UNNAMED_2819735072408(v233 * v235 + UNNAMED_2819735042360(UNNAMED_2819735072408(v233 * v236 + v234 * v235, 65535), 16), 4294967295) % 4294967296;
                v10[v229] = v237 ~= v237 and 0 or v237 - v237 % 1;
            else
                v3 = v10[UNNAMED_2819735079176[v3]];
            end;

            v3 = v3 + 1;
        end;

        v15 = 9;
        continue;
    elseif v15 == 9 then
        v15 = -1;

        while true do
            local v3;
            local v238 = 0;

            while true do
                if v238 == 0 then
                    v238 = -1;
                    local v239 = UNNAMED_2819735040872[v3];

                    if v239 >= 69 then
                        if v239 < 103 then
                            if v239 >= 86 then
                                if v239 < 94 then
                                    if v239 < 90 then
                                        if v239 >= 88 then
                                            if v239 == 89 then
                                                v10[UNNAMED_2819735062040[v3]](UNNAMED_2819735060072[v3], v10[UNNAMED_2819735053592[v3]]);
                                            else
                                                v10[UNNAMED_2819735053592[v3]][UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]];
                                            end;
                                        elseif v239 == 87 then
                                            local v240 = UNNAMED_2819735062040[v3];
                                            local v241 = v10[UNNAMED_2819735079176[v3]];
                                            v10[v240] = v10[UNNAMED_2819735053592[v3]];
                                            v10[v240 + 1] = v241;
                                        else
                                            local v242 = UNNAMED_2819735079176[v3];
                                            local v243 = v10[UNNAMED_2819735053592[v3]];
                                            v10[v242 + 1] = v243;
                                            v10[v242] = v243[UNNAMED_2819735031560[v3]];
                                        end;
                                    elseif v239 >= 92 then
                                        if v239 == 93 then
                                            v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735053592[v3];
                                        else
                                            v1 = v10[UNNAMED_2819735062040[v3]];
                                        end;
                                    elseif v239 == 91 then
                                        local v244 = UNNAMED_2819735051432[UNNAMED_2819735053592[v3]];
                                        v10[UNNAMED_2819735079176[v3]] = v244[5][v244[4]][UNNAMED_2819735031560[v3]];
                                    else
                                        v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735053592[v3] % v10[UNNAMED_2819735079176[v3]];
                                    end;
                                elseif v239 < 98 then
                                    if v239 >= 96 then
                                        if v239 == 97 then
                                            if v10[UNNAMED_2819735062040[v3]] then
                                                v3 = UNNAMED_2819735053592[v3];
                                            else
                                                v3 = UNNAMED_2819735079176[v3];
                                            end;
                                        elseif v10[UNNAMED_2819735062040[v3]] >= UNNAMED_2819735053592[v3] then
                                            v3 = UNNAMED_2819735079176[v3];
                                        end;
                                    elseif v239 == 95 then
                                        v10[UNNAMED_2819735053592[v3]](UNNAMED_2819735031560[v3]);
                                    elseif v10[UNNAMED_2819735062040[v3]] >= v10[UNNAMED_2819735079176[v3]] then
                                        v3 = UNNAMED_2819735053592[v3];
                                    end;
                                elseif v239 < 100 then
                                    if v239 == 99 then
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735068856[UNNAMED_2819735079176[v3]];
                                    else
                                        v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]][UNNAMED_2819735045192[v3]];
                                    end;
                                elseif v239 < 101 then
                                    v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735060072[v3] + UNNAMED_2819735045192[v3];
                                elseif v239 == 102 then
                                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735058728(UNNAMED_2819735079176[v3]);
                                else
                                    local v245 = UNNAMED_2819735079176[v3];
                                    local v246 = UNNAMED_2819735062040[v3];
                                    local v247 = UNNAMED_2819735053592[v3];
                                    local _ = v245 + v247 - 1;
                                    local _ = v245 + v246;
                                    UNNAMED_2819735077736(UNNAMED_2819735092424(v10[v245](UNNAMED_2819735089688(v10, v245 + 1, v245 + v246))), 1, v247, v245, v10);
                                end;
                            elseif v239 >= 77 then
                                if v239 < 81 then
                                    if v239 >= 79 then
                                        if v239 == 80 then
                                            local v248 = UNNAMED_2819735062040[v3];
                                            local v249 = UNNAMED_2819735065784(v2, UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 28), 15)));
                                            local v250 = UNNAMED_2819735079176[v3];
                                            local v251 = UNNAMED_2819735053592[v3];
                                            local v252 = v250 < 16384 and 7 or (v250 < 2097152 and 14 or 21);
                                            local v253 = UNNAMED_2819735072408(v250, UNNAMED_2819735042360(1, v252) - 1);
                                            local v254 = UNNAMED_2819735089496(v250, v252);
                                            UNNAMED_2819735053592[v3] = UNNAMED_2819735065784(v251, 97, (UNNAMED_2819735072408(UNNAMED_2819735089496(v249, 7), 127)));
                                            UNNAMED_2819735040872[v3] = UNNAMED_2819735065784(v254, 120, (UNNAMED_2819735072408(UNNAMED_2819735089496(v249, 21), 127)));
                                            UNNAMED_2819735079176[v3] = UNNAMED_2819735065784(v253, 63, (UNNAMED_2819735072408(v249, 127)));
                                            UNNAMED_2819735062040[v3] = UNNAMED_2819735065784(v248, 93, (UNNAMED_2819735072408(UNNAMED_2819735089496(v249, 14), 127)));
                                            v3 = v3 - 1;
                                        else
                                            v8 = v11[8];
                                            v12 = v11[5];
                                            v9 = v11[7];
                                            v6 = v11[6];
                                            v11 = v11[9];
                                        end;
                                    elseif v239 == 78 then
                                        local v255 = UNNAMED_2819735053592[v3];
                                        local v256 = v10[UNNAMED_2819735079176[v3]];
                                        local v257 = UNNAMED_2819735072408(UNNAMED_2819735062040[v3], 4294967295);
                                        local v258 = UNNAMED_2819735072408(v256, 4294967295);
                                        local v259 = UNNAMED_2819735072408(v257, 65535);
                                        local v260 = UNNAMED_2819735089496(v257, 16);
                                        local v261 = UNNAMED_2819735072408(v258, 65535);
                                        local v262 = UNNAMED_2819735089496(v258, 16);
                                        local v263 = UNNAMED_2819735072408(v259 * v261 + UNNAMED_2819735042360(UNNAMED_2819735072408(v259 * v262 + v260 * v261, 65535), 16), 4294967295) % 4294967296;
                                        v10[v255] = v263 ~= v263 and 0 or v263 - v263 % 1;
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735059640(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735062040[v3]);
                                    end;
                                elseif v239 < 83 then
                                    if v239 == 82 then
                                        v10[UNNAMED_2819735053592[v3]](v10[UNNAMED_2819735062040[v3]]);
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = v1;
                                    end;
                                elseif v239 >= 84 then
                                    if v239 == 85 then
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735072408(UNNAMED_2819735060072[v3], v10[UNNAMED_2819735062040[v3]]);
                                    else
                                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] >= v10[UNNAMED_2819735079176[v3]];
                                    end;
                                else
                                    local v264 = UNNAMED_2819735065784(UNNAMED_2819735053592[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
                                    local v265 = UNNAMED_2819735079176[v3] + 1;

                                    for i = 1, UNNAMED_2819735062040[v3] do
                                        local v266 = UNNAMED_2819735072408(UNNAMED_2819735065784(v264, (UNNAMED_2819735042360(v264, 13))), 536870911);
                                        local v267 = UNNAMED_2819735065784(v266, (UNNAMED_2819735089496(v266, 13)));
                                        v264 = UNNAMED_2819735072408(UNNAMED_2819735065784(v267, (UNNAMED_2819735042360(v267, 14))), 536870911);
                                        UNNAMED_2819735079176[v265] = UNNAMED_2819735065784(UNNAMED_2819735079176[v265], (UNNAMED_2819735072408(UNNAMED_2819735089496(v264, 0), 127)));
                                        UNNAMED_2819735053592[v265] = UNNAMED_2819735065784(UNNAMED_2819735053592[v265], (UNNAMED_2819735072408(UNNAMED_2819735089496(v264, 7), 127)));
                                        UNNAMED_2819735062040[v265] = UNNAMED_2819735065784(UNNAMED_2819735062040[v265], (UNNAMED_2819735072408(UNNAMED_2819735089496(v264, 14), 127)));
                                        UNNAMED_2819735040872[v265] = UNNAMED_2819735065784(UNNAMED_2819735040872[v265], (UNNAMED_2819735072408(UNNAMED_2819735089496(v264, 21), 127)));
                                        v265 = v265 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735040872[v3] = 64;
                                end;
                            elseif v239 >= 73 then
                                if v239 >= 75 then
                                    if v239 == 76 then
                                        v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735065784(UNNAMED_2819735053592[v3], v10[UNNAMED_2819735079176[v3]]);
                                    else
                                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] == v10[UNNAMED_2819735079176[v3]];
                                    end;
                                elseif v239 == 74 then
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735053592[v3]], UNNAMED_2819735062040[v3]);
                                else
                                    local v268 = UNNAMED_2819735062040[v3];
                                    local v269 = UNNAMED_2819735079176[v3];
                                    v10[v268] = UNNAMED_2819735045192[v3];
                                    v10[v268 + 1] = v269;
                                end;
                            elseif v239 < 71 then
                                if v239 == 70 then
                                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735068856;
                                else
                                    local v270 = UNNAMED_2819735053592[v3];
                                    local v271 = UNNAMED_2819735060072[v3];
                                    v10[v270] = UNNAMED_2819735062040[v3];
                                    v10[v270 + 1] = v271;
                                end;
                            elseif v239 == 72 then
                                if UNNAMED_2819735079176[v3] >= v10[UNNAMED_2819735053592[v3]] then
                                    v3 = UNNAMED_2819735062040[v3];
                                end;
                            else
                                v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735059640(UNNAMED_2819735079176[v3], v10[UNNAMED_2819735062040[v3]]);
                            end;
                        elseif v239 < 120 then
                            if v239 >= 111 then
                                if v239 >= 115 then
                                    if v239 >= 117 then
                                        if v239 >= 118 then
                                            if v239 == 119 then
                                                if v10[UNNAMED_2819735053592[v3]] then
                                                    v3 = UNNAMED_2819735079176[v3];
                                                else
                                                    v3 = UNNAMED_2819735062040[v3];
                                                end;
                                            else
                                                v10[UNNAMED_2819735062040[v3]](v10[UNNAMED_2819735053592[v3]], UNNAMED_2819735060072[v3]);
                                            end;
                                        else
                                            local v272 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                                            v272[5][v272[4]][v10[UNNAMED_2819735053592[v3]]] = UNNAMED_2819735079176[v3];
                                        end;
                                    elseif v239 == 116 then
                                        local v273 = UNNAMED_2819735079176[v3];
                                        local v274 = UNNAMED_2819735065784(UNNAMED_2819735053592[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
                                        local v275 = UNNAMED_2819735061992[5];
                                        local v276 = UNNAMED_2819735065784(v275[v273], 109162203);
                                        v275[v273] = v276;
                                        local v277 = UNNAMED_2819735061992[4];
                                        local v278 = v276 + 1;
                                        local v279 = UNNAMED_2819735082584(v277, v278);
                                        local v280;

                                        if v279 < 128 then
                                            v280 = v278 + 1;
                                        else
                                            local v281 = UNNAMED_2819735082584(v277, v278 + 1);

                                            if v281 < 128 then
                                                v279 = v279 - 128 + v281 * 128;
                                                v280 = v278 + 2;
                                            else
                                                local v282 = UNNAMED_2819735082584(v277, v278 + 2);

                                                if v282 < 128 then
                                                    v279 = v279 - 128 + (v281 - 128) * 16384 + v282 * 128;
                                                    v280 = v278 + 3;
                                                else
                                                    local v283 = UNNAMED_2819735082584(v277, v278 + 3);
                                                    v279 = (v279 - 128) * 16384 + (v281 - 128) * 128 + (v282 - 128) + v283 % 128 * 2097152 + (v283 - v283 % 128) * 2097152;
                                                    v280 = v278 + 4;
                                                end;
                                            end;
                                        end;

                                        local v284 = v274 * 16843009;
                                        local v285 = v280 + v279;
                                        local v286 = v285 - v279 % 4;

                                        for i = v280, v286 - 1, 4 do
                                            UNNAMED_2819735074184(v277, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v277, i), v284)));
                                            local _ = i;
                                        end;

                                        for i = v286, v285 - 1 do
                                            UNNAMED_2819735081960(v277, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v277, i), v274)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735079176[v3] = 38;
                                        UNNAMED_2819735053592[v3] = 98;
                                        UNNAMED_2819735062040[v3] = 203;
                                        UNNAMED_2819735040872[v3] = 64;
                                    else
                                        v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] // UNNAMED_2819735053592[v3];
                                    end;
                                elseif v239 >= 113 then
                                    if v239 == 114 then
                                        local v287 = UNNAMED_2819735079176[v3];
                                        v10[v287] = v10[v287](v10[v287 + 1], v10[v287 + 2]);
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] ~= UNNAMED_2819735079176[v3];
                                    end;
                                elseif v239 == 112 then
                                    v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735042360(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735053592[v3]);
                                elseif v7 then
                                    local v288 = UNNAMED_2819735079176[v3];
                                    local v289 = v7[v288];

                                    if v289 then
                                        v289[5] = v289;
                                        v289[6] = v10[v288];
                                        v289[4] = 6;
                                        v7[v288] = nil;
                                    end;

                                    local v290 = UNNAMED_2819735062040[v3];
                                    local v291 = v7[v290];

                                    if v291 then
                                        v291[5] = v291;
                                        v291[6] = v10[v290];
                                        v291[4] = 6;
                                        v7[v290] = nil;
                                    end;
                                end;
                            elseif v239 < 107 then
                                if v239 < 105 then
                                    if v239 == 104 then
                                        v10[UNNAMED_2819735079176[v3]](v10[UNNAMED_2819735062040[v3]], v10[UNNAMED_2819735053592[v3]]);
                                    else
                                        local v292 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                                        v292[5][v292[4]] = UNNAMED_2819735060072[v3];
                                    end;
                                elseif v239 == 106 then
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735036216(v10[UNNAMED_2819735053592[v3]]);
                                else
                                    local v293 = UNNAMED_2819735079176[v3];
                                    local _ = UNNAMED_2819735053592[v3];
                                    v10[v293] = UNNAMED_2819735092424(v10[v293](UNNAMED_2819735089688(v10, v293 + 1, v293 + UNNAMED_2819735062040[v3])));
                                end;
                            elseif v239 >= 109 then
                                if v239 == 110 then
                                    local v294 = UNNAMED_2819735079176[v3];
                                    local v295 = UNNAMED_2819735062040[v3];
                                    local v296 = UNNAMED_2819735061992[5];
                                    local v297 = UNNAMED_2819735065784(v296[v294], 109162203);
                                    v296[v294] = v297;
                                    local v298 = UNNAMED_2819735061992[4];
                                    local v299 = v297 + 1;
                                    local v300 = UNNAMED_2819735082584(v298, v299);
                                    local v301;

                                    if v300 < 128 then
                                        v301 = v299 + 1;
                                    else
                                        local v302 = UNNAMED_2819735082584(v298, v299 + 1);

                                        if v302 < 128 then
                                            v300 = v300 - 128 + v302 * 128;
                                            v301 = v299 + 2;
                                        else
                                            local v303 = UNNAMED_2819735082584(v298, v299 + 2);

                                            if v303 < 128 then
                                                v300 = v300 - 128 + (v302 - 128) * 16384 + v303 * 128;
                                                v301 = v299 + 3;
                                            else
                                                local v304 = UNNAMED_2819735082584(v298, v299 + 3);
                                                v300 = (v300 - 128) * 16384 + (v302 - 128) * 128 + (v303 - 128) + v304 % 128 * 2097152 + (v304 - v304 % 128) * 2097152;
                                                v301 = v299 + 4;
                                            end;
                                        end;
                                    end;

                                    local v305 = v295 * 16843009;
                                    local v306 = v301 + v300;
                                    local v307 = v306 - v300 % 4;

                                    for i = v301, v307 - 1, 4 do
                                        UNNAMED_2819735074184(v298, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v298, i), v305)));
                                        local _ = i;
                                    end;

                                    for i = v307, v306 - 1 do
                                        UNNAMED_2819735081960(v298, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v298, i), v295)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735079176[v3] = 28;
                                    UNNAMED_2819735062040[v3] = 57;
                                    UNNAMED_2819735053592[v3] = 9;
                                    UNNAMED_2819735040872[v3] = 64;
                                else
                                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735060072[v3];
                                end;
                            elseif v239 == 108 then
                                local v308 = UNNAMED_2819735062040[v3];
                                local v309 = UNNAMED_2819735045192[v3];
                                v10[v308] = UNNAMED_2819735060072[v3];
                                v10[v308 + 1] = v309;
                            else
                                v10[UNNAMED_2819735053592[v3]]();
                            end;
                        elseif v239 < 129 then
                            if v239 < 124 then
                                if v239 < 122 then
                                    if v239 == 121 then
                                        v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735031560[v3], UNNAMED_2819735045192[v3]);
                                    else
                                        local v310 = UNNAMED_2819735062040[v3];
                                        local v311 = UNNAMED_2819735079176[v3];
                                        local v312 = UNNAMED_2819735072408(v10[UNNAMED_2819735053592[v3]], 4294967295);
                                        local v313 = UNNAMED_2819735072408(v311, 4294967295);
                                        local v314 = UNNAMED_2819735072408(v312, 65535);
                                        local v315 = UNNAMED_2819735089496(v312, 16);
                                        local v316 = UNNAMED_2819735072408(v313, 65535);
                                        local v317 = UNNAMED_2819735089496(v313, 16);
                                        local v318 = UNNAMED_2819735072408(v314 * v316 + UNNAMED_2819735042360(UNNAMED_2819735072408(v314 * v317 + v315 * v316, 65535), 16), 4294967295) % 4294967296;
                                        v10[v310] = v318 ~= v318 and 0 or v318 - v318 % 1;
                                    end;
                                elseif v239 == 123 then
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] // v10[UNNAMED_2819735053592[v3]];
                                else
                                    v10[UNNAMED_2819735079176[v3]] = -v10[UNNAMED_2819735062040[v3]];
                                end;
                            elseif v239 >= 126 then
                                if v239 < 127 then
                                    local v319 = UNNAMED_2819735053592[v3];
                                    local v320 = v10[UNNAMED_2819735062040[v3]];
                                    local v321 = UNNAMED_2819735072408(UNNAMED_2819735060072[v3], 4294967295);
                                    local v322 = UNNAMED_2819735072408(v320, 4294967295);
                                    local v323 = UNNAMED_2819735072408(v321, 65535);
                                    local v324 = UNNAMED_2819735089496(v321, 16);
                                    local v325 = UNNAMED_2819735072408(v322, 65535);
                                    local v326 = UNNAMED_2819735089496(v322, 16);
                                    local v327 = UNNAMED_2819735072408(v323 * v325 + UNNAMED_2819735042360(UNNAMED_2819735072408(v323 * v326 + v324 * v325, 65535), 16), 4294967295) % 4294967296;
                                    v10[v319] = v327 ~= v327 and 0 or v327 - v327 % 1;
                                elseif v239 == 128 then
                                    v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] * v10[UNNAMED_2819735079176[v3]];
                                else
                                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735079176[v3]);
                                end;
                            elseif v239 == 125 then
                                v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] + UNNAMED_2819735079176[v3];
                            else
                                v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] - UNNAMED_2819735060072[v3];
                            end;
                        elseif v239 < 133 then
                            if v239 >= 131 then
                                if v239 == 132 then
                                    local v328 = UNNAMED_2819735053592[v3];
                                    local v329 = UNNAMED_2819735062040[v3] + 1;

                                    for i = 1, UNNAMED_2819735079176[v3] do
                                        local v330 = UNNAMED_2819735072408(UNNAMED_2819735065784(v328, (UNNAMED_2819735042360(v328, 13))), 536870911);
                                        local v331 = UNNAMED_2819735065784(v330, (UNNAMED_2819735089496(v330, 13)));
                                        v328 = UNNAMED_2819735072408(UNNAMED_2819735065784(v331, (UNNAMED_2819735042360(v331, 14))), 536870911);
                                        UNNAMED_2819735079176[v329] = UNNAMED_2819735065784(UNNAMED_2819735079176[v329], (UNNAMED_2819735072408(UNNAMED_2819735089496(v328, 0), 127)));
                                        UNNAMED_2819735053592[v329] = UNNAMED_2819735065784(UNNAMED_2819735053592[v329], (UNNAMED_2819735072408(UNNAMED_2819735089496(v328, 7), 127)));
                                        UNNAMED_2819735062040[v329] = UNNAMED_2819735065784(UNNAMED_2819735062040[v329], (UNNAMED_2819735072408(UNNAMED_2819735089496(v328, 14), 127)));
                                        UNNAMED_2819735040872[v329] = UNNAMED_2819735065784(UNNAMED_2819735040872[v329], (UNNAMED_2819735072408(UNNAMED_2819735089496(v328, 21), 127)));
                                        v329 = v329 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735040872[v3] = 64;
                                else
                                    local v332 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                                    v332[5][v332[4]][v10[UNNAMED_2819735079176[v3]]] = v10[UNNAMED_2819735053592[v3]];
                                end;
                            elseif v239 == 130 then
                                v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735053592[v3]], v10[UNNAMED_2819735079176[v3]]);
                            else
                                local v333 = UNNAMED_2819735079176[v3];
                                local v334 = UNNAMED_2819735065784(v2, UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 28), 15)));
                                local v335 = UNNAMED_2819735053592[v3];
                                local v336 = UNNAMED_2819735062040[v3];
                                local v337 = v335 < 2097152 and 7 or 14;
                                local v338 = UNNAMED_2819735089496(v335, v337);
                                UNNAMED_2819735053592[v3] = UNNAMED_2819735065784(UNNAMED_2819735072408(v335, UNNAMED_2819735042360(1, v337) - 1), 52, (UNNAMED_2819735072408(UNNAMED_2819735089496(v334, 7), 127)));
                                UNNAMED_2819735079176[v3] = UNNAMED_2819735065784(v333, 86, (UNNAMED_2819735072408(v334, 127)));
                                UNNAMED_2819735040872[v3] = UNNAMED_2819735065784(v338, 22, (UNNAMED_2819735072408(UNNAMED_2819735089496(v334, 21), 127)));
                                UNNAMED_2819735062040[v3] = UNNAMED_2819735065784(v336, 111, (UNNAMED_2819735072408(UNNAMED_2819735089496(v334, 14), 127)));
                                v3 = v3 - 1;
                            end;
                        elseif v239 >= 135 then
                            if v239 < 136 then
                                v10[UNNAMED_2819735079176[v3]](v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735089688(v10[UNNAMED_2819735053592[v3]], 1, v10[UNNAMED_2819735053592[v3]].n));
                            elseif v239 == 137 then
                                local v339 = UNNAMED_2819735062040[v3];
                                local v340 = UNNAMED_2819735079176[v3];
                                v10[v339] = UNNAMED_2819735053592[v3];
                                v10[v339 + 1] = v340;
                            else
                                v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735079176[v3] + v10[UNNAMED_2819735053592[v3]];
                            end;
                        elseif v239 == 134 then
                            if v7 then
                                local v341 = UNNAMED_2819735062040[v3];
                                local v342 = v7[v341];

                                if v342 then
                                    v342[5] = v342;
                                    v342[6] = v10[v341];
                                    v342[4] = 6;
                                    v7[v341] = nil;
                                end;
                            end;
                        else
                            local v343 = UNNAMED_2819735062040[v3];
                            local v344 = v10[UNNAMED_2819735079176[v3]];
                            local v345 = UNNAMED_2819735072408(v10[UNNAMED_2819735053592[v3]], 4294967295);
                            local v346 = UNNAMED_2819735072408(v344, 4294967295);
                            local v347 = UNNAMED_2819735072408(v345, 65535);
                            local v348 = UNNAMED_2819735089496(v345, 16);
                            local v349 = UNNAMED_2819735072408(v346, 65535);
                            local v350 = UNNAMED_2819735089496(v346, 16);
                            local v351 = UNNAMED_2819735072408(v347 * v349 + UNNAMED_2819735042360(UNNAMED_2819735072408(v347 * v350 + v348 * v349, 65535), 16), 4294967295) % 4294967296;
                            v10[v343] = v351 ~= v351 and 0 or v351 - v351 % 1;
                        end;

                        v238 = 1;
                        continue;
                    end;

                    if v239 >= 34 then
                        if v239 >= 51 then
                            if v239 < 60 then
                                if v239 < 55 then
                                    if v239 < 53 then
                                        if v239 == 52 then
                                            v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735031560[v3] + v10[UNNAMED_2819735079176[v3]];
                                        else
                                            v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735088440[UNNAMED_2819735031560[v3]][UNNAMED_2819735045192[v3]];
                                        end;
                                    elseif v239 == 54 then
                                        v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735079176[v3] - v10[UNNAMED_2819735053592[v3]];
                                    else
                                        UNNAMED_2819735068856[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]];
                                    end;
                                elseif v239 < 57 then
                                    if v239 == 56 then
                                        local v352 = nil;
                                        local v353 = UNNAMED_2819735079176[v3];
                                        local v354 = UNNAMED_2819735045192[v3];
                                        local v355 = UNNAMED_2819735031560[v3];
                                        local v356 = v355[0];

                                        if v356 then
                                            local v357 = #v356 / 3;

                                            if v357 > 0 then
                                                v352 = {};

                                                for i = 1, v357 do
                                                    local v358 = (i - 1) * 3;
                                                    local v359 = v356[v358 + 2];
                                                    local v360 = v356[v358 + 1];
                                                    local v361;

                                                    if v359 == 2 then
                                                        v7 = v7 or {};
                                                        local v362 = v7[v360];

                                                        if not v362 then
                                                            v362 = {
                                                                [5] = v10,
                                                                [4] = v360
                                                            };
                                                            v7[v360] = v362;
                                                        end;

                                                        v352[i] = v362;
                                                        v361 = i;
                                                    elseif v359 == 0 then
                                                        v352[i] = v10[v360];
                                                        v361 = i;
                                                    elseif v359 == 3 then
                                                        v352[i] = UNNAMED_2819735051432[v360];
                                                        v361 = i;
                                                    elseif v359 == 1 then
                                                        v13 = v13 or {};
                                                        local v363 = v13[v360];

                                                        if not v363 then
                                                            v363 = {
                                                                [5] = v10,
                                                                [4] = v360,
                                                                [6] = v356[v358 + 3]
                                                            };
                                                            v13[v360] = v363;
                                                        end;

                                                        v352[i] = v363;
                                                        v361 = i;
                                                    else
                                                        v361 = i;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v364 = v355[-2];
                                        v355[v364] = v352;
                                        local v365 = v354(UNNAMED_2819735089688(v355, 1, v355[-1]));
                                        v355[v364] = nil;
                                        v10[v353] = v365;
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                                    end;
                                elseif v239 < 58 then
                                    v10[UNNAMED_2819735079176[v3]][UNNAMED_2819735045192[v3]] = v10[UNNAMED_2819735062040[v3]];
                                elseif v239 == 59 then
                                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] - UNNAMED_2819735079176[v3];
                                else
                                    v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] - v10[UNNAMED_2819735079176[v3]];
                                end;
                            elseif v239 >= 64 then
                                if v239 < 66 then
                                    if v239 == 65 then
                                        v10[UNNAMED_2819735053592[v3]][v10[UNNAMED_2819735062040[v3]]] = UNNAMED_2819735079176[v3];
                                    end;
                                elseif v239 < 67 then
                                    v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735079176[v3]](v10[UNNAMED_2819735062040[v3]]);
                                elseif v239 == 68 then
                                    v3 = UNNAMED_2819735079176[v3];
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]][UNNAMED_2819735062040[v3]];
                                end;
                            elseif v239 < 62 then
                                if v239 ~= 61 then
                                    if v7 then
                                        for i in UNNAMED_2819735091272, v7 do
                                            local v366 = v7[i];

                                            if v366 then
                                                v366[5] = v366;
                                                v366[6] = v10[i];
                                                v366[4] = 6;
                                                v7[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v13 then
                                        for i, v in UNNAMED_2819735091272, v13 do
                                            local v367 = v[6];

                                            if v13 then
                                                local v368 = v13[i];

                                                if v368 then
                                                    local v369 = UNNAMED_2819735058728(v367);
                                                    UNNAMED_2819735077736(v10, i, i + v367 - 1, 1, v369);
                                                    v368[5] = v369;
                                                    v368[4] = 1;
                                                    v13[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return;
                                end;

                                v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735089688(v10[UNNAMED_2819735053592[v3]], 1, v10[UNNAMED_2819735053592[v3]].n));
                            elseif v239 == 63 then
                                v10[UNNAMED_2819735053592[v3]] = not v10[UNNAMED_2819735079176[v3]];
                            else
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] <= v10[UNNAMED_2819735062040[v3]];
                            end;
                        elseif v239 >= 42 then
                            if v239 < 46 then
                                if v239 >= 44 then
                                    if v239 == 45 then
                                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735045192[v3]);
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735068856[UNNAMED_2819735079176[v3]];
                                        v10[UNNAMED_2819735053592[v3 + 1]] = v10[UNNAMED_2819735062040[v3 + 1]] + UNNAMED_2819735079176[v3 + 1];
                                        local v370 = UNNAMED_2819735062040[v3 + 2];
                                        local v371 = v10[UNNAMED_2819735079176[v3 + 2]];
                                        v10[v370] = v10[UNNAMED_2819735053592[v3 + 2]];
                                        v10[v370 + 1] = v371;
                                        local v372 = UNNAMED_2819735079176[v3 + 3];
                                        v10[v372] = v10[v372](v10[v372 + 1], v10[v372 + 2]);
                                        v3 = v3 + 3;
                                    end;
                                elseif v239 == 43 then
                                    v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735089496(v10[UNNAMED_2819735053592[v3]], UNNAMED_2819735079176[v3]);
                                else
                                    local v373 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                                    v373[5][v373[4]] = v10[UNNAMED_2819735079176[v3]];
                                end;
                            elseif v239 >= 48 then
                                if v239 < 49 then
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735053592[v3] * v10[UNNAMED_2819735062040[v3]];
                                else
                                    if v239 == 50 then
                                        if v7 then
                                            for i in UNNAMED_2819735091272, v7 do
                                                local v374 = v7[i];

                                                if v374 then
                                                    v374[5] = v374;
                                                    v374[6] = v10[i];
                                                    v374[4] = 6;
                                                    v7[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v13 then
                                            for i, v in UNNAMED_2819735091272, v13 do
                                                local v375 = v[6];

                                                if v13 then
                                                    local v376 = v13[i];

                                                    if v376 then
                                                        local v377 = UNNAMED_2819735058728(v375);
                                                        UNNAMED_2819735077736(v10, i, i + v375 - 1, 1, v377);
                                                        v376[5] = v377;
                                                        v376[4] = 1;
                                                        v13[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return UNNAMED_2819735060072[v3];
                                    end;

                                    v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]] / v10[UNNAMED_2819735053592[v3]];
                                end;
                            elseif v239 == 47 then
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] % UNNAMED_2819735053592[v3];
                            else
                                v8 = v8 + v9;
                                local v378;

                                if v9 <= 0 then
                                    v378 = v12 <= v8;
                                else
                                    v378 = v8 <= v12;
                                end;

                                if v378 then
                                    v10[UNNAMED_2819735062040[v3]] = v8;
                                    v3 = UNNAMED_2819735079176[v3];
                                else
                                    v3 = UNNAMED_2819735053592[v3];
                                end;
                            end;
                        elseif v239 >= 38 then
                            if v239 < 40 then
                                if v239 == 39 then
                                    local v379 = UNNAMED_2819735062040[v3];
                                    UNNAMED_2819735077736(v10, v379 + 1, v379 + UNNAMED_2819735053592[v3], UNNAMED_2819735079176[v3] + 1, v10[v379]);
                                else
                                    local v380 = v10[UNNAMED_2819735053592[v3]] % 4294967296;
                                    v10[UNNAMED_2819735062040[v3]] = v380 ~= v380 and 0 or v380 - v380 % 1;
                                end;
                            elseif v239 == 41 then
                                local v381 = UNNAMED_2819735079176[v3];
                                local v382 = UNNAMED_2819735065784(UNNAMED_2819735053592[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                                local v383 = UNNAMED_2819735061992[5];
                                local v384 = UNNAMED_2819735065784(v383[v381], 109162203);
                                v383[v381] = v384;
                                local v385 = UNNAMED_2819735061992[4];
                                local v386 = v384 + 1;
                                local v387 = UNNAMED_2819735082584(v385, v386);
                                local v388;

                                if v387 < 128 then
                                    v388 = v386 + 1;
                                else
                                    local v389 = UNNAMED_2819735082584(v385, v386 + 1);

                                    if v389 < 128 then
                                        v387 = v387 - 128 + v389 * 128;
                                        v388 = v386 + 2;
                                    else
                                        local v390 = UNNAMED_2819735082584(v385, v386 + 2);

                                        if v390 < 128 then
                                            v387 = v387 - 128 + (v389 - 128) * 16384 + v390 * 128;
                                            v388 = v386 + 3;
                                        else
                                            local v391 = UNNAMED_2819735082584(v385, v386 + 3);
                                            v387 = (v387 - 128) * 16384 + (v389 - 128) * 128 + (v390 - 128) + v391 % 128 * 2097152 + (v391 - v391 % 128) * 2097152;
                                            v388 = v386 + 4;
                                        end;
                                    end;
                                end;

                                local v392 = v382 * 16843009;
                                local v393 = v388 + v387;
                                local v394 = v393 - v387 % 4;

                                for i = v388, v394 - 1, 4 do
                                    UNNAMED_2819735074184(v385, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v385, i), v392)));
                                    local _ = i;
                                end;

                                for i = v394, v393 - 1 do
                                    UNNAMED_2819735081960(v385, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v385, i), v382)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735079176[v3] = 238;
                                UNNAMED_2819735053592[v3] = 226;
                                UNNAMED_2819735062040[v3] = 165;
                                UNNAMED_2819735040872[v3] = 64;
                            else
                                v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735059640(v10[UNNAMED_2819735053592[v3]], v10[UNNAMED_2819735062040[v3]]);
                            end;
                        elseif v239 >= 36 then
                            if v239 == 37 then
                                v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735088440[UNNAMED_2819735031560[v3]];
                            else
                                v10[UNNAMED_2819735053592[v3]][v10[UNNAMED_2819735079176[v3]]] = v10[UNNAMED_2819735062040[v3]];
                            end;
                        elseif v239 == 35 then
                            v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]];
                        else
                            v10[UNNAMED_2819735062040[v3]] = UNNAMED_2819735068856[UNNAMED_2819735060072[v3]];
                        end;
                    else
                        if v239 >= 17 then
                            if v239 >= 25 then
                                if v239 >= 29 then
                                    if v239 >= 31 then
                                        if v239 >= 32 then
                                            if v239 == 33 then
                                                v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(UNNAMED_2819735062040[v3], v10[UNNAMED_2819735053592[v3]]);
                                            else
                                                v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735089688(v10[UNNAMED_2819735053592[v3]], 1, v10[UNNAMED_2819735053592[v3]].n));
                                            end;
                                        else
                                            local v395 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3]];
                                            v10[UNNAMED_2819735079176[v3]] = v395[5][v395[4]][v10[UNNAMED_2819735053592[v3]]];
                                        end;
                                    elseif v239 == 30 then
                                        v3 = v10[UNNAMED_2819735079176[v3]];
                                    elseif v10[UNNAMED_2819735062040[v3]] ~= UNNAMED_2819735053592[v3] then
                                        v3 = UNNAMED_2819735079176[v3];
                                    end;
                                elseif v239 < 27 then
                                    if v239 == 26 then
                                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735062040[v3]], v10[UNNAMED_2819735053592[v3]]);
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] * UNNAMED_2819735079176[v3];
                                    end;
                                else
                                    if v239 ~= 28 then
                                        if v7 then
                                            for i in UNNAMED_2819735091272, v7 do
                                                local v396 = v7[i];

                                                if v396 then
                                                    v396[5] = v396;
                                                    v396[6] = v10[i];
                                                    v396[4] = 6;
                                                    v7[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v13 then
                                            for i, v in UNNAMED_2819735091272, v13 do
                                                local v397 = v[6];

                                                if v13 then
                                                    local v398 = v13[i];

                                                    if v398 then
                                                        local v399 = UNNAMED_2819735058728(v397);
                                                        UNNAMED_2819735077736(v10, i, i + v397 - 1, 1, v399);
                                                        v398[5] = v399;
                                                        v398[4] = 1;
                                                        v13[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return v10[UNNAMED_2819735079176[v3]];
                                    end;

                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] + UNNAMED_2819735031560[v3];
                                end;
                            elseif v239 >= 21 then
                                if v239 < 23 then
                                    if v239 == 22 then
                                        v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]][UNNAMED_2819735062040[v3]];
                                        v10[UNNAMED_2819735079176[v3 + 1]] = v10[UNNAMED_2819735053592[v3 + 1]][UNNAMED_2819735062040[v3 + 1]];
                                        v10[UNNAMED_2819735079176[v3 + 2]] = v10[UNNAMED_2819735053592[v3 + 2]][UNNAMED_2819735062040[v3 + 2]];
                                        v10[UNNAMED_2819735079176[v3 + 3]] = v10[UNNAMED_2819735062040[v3 + 3]] + v10[UNNAMED_2819735053592[v3 + 3]];
                                        v10[UNNAMED_2819735079176[v3 + 4]] = v10[UNNAMED_2819735053592[v3 + 4]] <= UNNAMED_2819735062040[v3 + 4];
                                        v3 = v3 + 4;
                                    else
                                        v10[UNNAMED_2819735079176[v3]] = {};
                                    end;
                                elseif v239 == 24 then
                                    local v400 = UNNAMED_2819735062040[v3];
                                    local v401 = v10[UNNAMED_2819735053592[v3]];
                                    v10[v400] = UNNAMED_2819735079176[v3];
                                    v10[v400 + 1] = v401;
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]]();
                                end;
                            elseif v239 < 19 then
                                if v239 == 18 then
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] % v10[UNNAMED_2819735053592[v3]];
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] % UNNAMED_2819735045192[v3];
                                end;
                            elseif v239 == 20 then
                                v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735062040[v3]] / UNNAMED_2819735079176[v3];
                            else
                                v10[UNNAMED_2819735062040[v3]] = v2;
                            end;

                            v238 = 1;
                            continue;
                        end;

                        if v239 >= 8 then
                            if v239 >= 12 then
                                if v239 >= 14 then
                                    if v239 < 15 then
                                        v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]][v10[UNNAMED_2819735053592[v3]]];
                                    elseif v239 == 16 then
                                        v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735045192[v3]);
                                    else
                                        local v402 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                        v10[UNNAMED_2819735062040[v3]] = v402[5][v402[4]];
                                    end;
                                elseif v239 == 13 then
                                    v3 = v10[UNNAMED_2819735053592[v3]];
                                elseif v10[UNNAMED_2819735062040[v3]] > UNNAMED_2819735079176[v3] then
                                    v3 = UNNAMED_2819735053592[v3];
                                end;
                            elseif v239 < 10 then
                                if v239 == 9 then
                                    v2 = v10[UNNAMED_2819735062040[v3]];
                                else
                                    local v403 = UNNAMED_2819735065784(UNNAMED_2819735053592[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                                    local v404 = UNNAMED_2819735079176[v3] + 1;

                                    for i = 1, UNNAMED_2819735062040[v3] do
                                        local v405 = UNNAMED_2819735072408(UNNAMED_2819735065784(v403, (UNNAMED_2819735042360(v403, 13))), 536870911);
                                        local v406 = UNNAMED_2819735065784(v405, (UNNAMED_2819735089496(v405, 13)));
                                        v403 = UNNAMED_2819735072408(UNNAMED_2819735065784(v406, (UNNAMED_2819735042360(v406, 14))), 536870911);
                                        UNNAMED_2819735079176[v404] = UNNAMED_2819735065784(UNNAMED_2819735079176[v404], (UNNAMED_2819735072408(UNNAMED_2819735089496(v403, 0), 127)));
                                        UNNAMED_2819735053592[v404] = UNNAMED_2819735065784(UNNAMED_2819735053592[v404], (UNNAMED_2819735072408(UNNAMED_2819735089496(v403, 7), 127)));
                                        UNNAMED_2819735062040[v404] = UNNAMED_2819735065784(UNNAMED_2819735062040[v404], (UNNAMED_2819735072408(UNNAMED_2819735089496(v403, 14), 127)));
                                        UNNAMED_2819735040872[v404] = UNNAMED_2819735065784(UNNAMED_2819735040872[v404], (UNNAMED_2819735072408(UNNAMED_2819735089496(v403, 21), 127)));
                                        v404 = v404 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735040872[v3] = 64;
                                end;
                            elseif v239 == 11 then
                                v10[UNNAMED_2819735053592[v3]] = #v10[UNNAMED_2819735062040[v3]];
                            else
                                v10[UNNAMED_2819735062040[v3]] = v10[UNNAMED_2819735053592[v3]] == UNNAMED_2819735079176[v3];
                            end;

                            v238 = 1;
                            continue;
                        end;

                        if v239 >= 4 then
                            if v239 >= 6 then
                                if v239 == 7 then
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] + v10[UNNAMED_2819735053592[v3]];
                                else
                                    local v407 = UNNAMED_2819735053592[v3];
                                    local v408 = UNNAMED_2819735062040[v3];
                                    v10[v407] = v10[UNNAMED_2819735079176[v3]];
                                    v10[v407 + 1] = v408;
                                end;
                            elseif v239 == 5 then
                                v11 = {
                                    [9] = v11,
                                    [7] = v9,
                                    [8] = v8,
                                    [5] = v12,
                                    [6] = v6
                                };
                                local v409 = UNNAMED_2819735062040[v3];
                                v9 = v10[v409 + 2] + 0;
                                v12 = v10[v409 + 1] + 0;
                                v8 = v10[v409] - v9;
                                v3 = UNNAMED_2819735079176[v3];
                            else
                                local v410 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                v10[UNNAMED_2819735062040[v3]] = v410[5][v410[4]];
                                v10[UNNAMED_2819735079176[v3 + 1]](UNNAMED_2819735031560[v3 + 1], UNNAMED_2819735045192[v3 + 1]);
                                local v411 = UNNAMED_2819735051432[UNNAMED_2819735062040[v3 + 2]];
                                v411[5][v411[4]] = UNNAMED_2819735060072[v3 + 2];
                                local v412 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3 + 3]];
                                v10[UNNAMED_2819735062040[v3 + 3]] = v412[5][v412[4]];
                                v10[UNNAMED_2819735053592[v3 + 4]]();
                                v3 = v3 + 4;
                            end;

                            v238 = 1;
                            continue;
                        end;

                        if v239 >= 2 then
                            if v239 == 3 then
                                v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735062040[v3]], UNNAMED_2819735060072[v3]);
                            else
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735062040[v3]] < UNNAMED_2819735053592[v3];
                            end;

                            v238 = 1;
                            continue;
                        end;

                        if v239 == 1 then
                            v4 = UNNAMED_2819735053592[v3];
                            v3 = UNNAMED_2819735079176[v3] + 1;
                            v15 = 8;
                            break;
                        end;

                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735059640(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735031560[v3]);
                    end;

                    v238 = 1;
                    continue;
                elseif v238 == 1 then
                    v238 = -1;
                    v3 = v3 + 1;
                    break;
                else
                    break;
                end;
            end;

            if v15 ~= -1 then
                break;
            end;
        end;

        if v15 ~= -1 then
            continue;
        end;

        v15 = 10;
        continue;
    elseif v15 == 10 then
        v15 = -1;

        while true do
            local v3;
            local v413 = 0;

            while true do
                if v413 == 0 then
                    v413 = -1;
                    local v414 = UNNAMED_2819735062040[v3];

                    if v414 < 43 then
                        if v414 >= 21 then
                            if v414 < 32 then
                                if v414 >= 26 then
                                    if v414 < 29 then
                                        if v414 < 27 then
                                            local v415 = UNNAMED_2819735040872[v3];
                                            local v416, v417 = v8();

                                            if v416 then
                                                v10[v415] = v417;
                                                v3 = UNNAMED_2819735079176[v3];
                                            else
                                                v3 = UNNAMED_2819735053592[v3];
                                            end;
                                        elseif v414 == 28 then
                                            local v418 = UNNAMED_2819735051432[UNNAMED_2819735040872[v3]];
                                            v418[5][v418[4]] = UNNAMED_2819735045192[v3];
                                        else
                                            v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735062040;
                                        end;
                                    elseif v414 < 30 then
                                        v8 = v8 + v9;
                                        local v419;

                                        if v9 <= 0 then
                                            v419 = v12 <= v8;
                                        else
                                            v419 = v8 <= v12;
                                        end;

                                        if v419 then
                                            v10[UNNAMED_2819735079176[v3]] = v8;
                                            v3 = UNNAMED_2819735053592[v3];
                                        else
                                            v3 = UNNAMED_2819735040872[v3];
                                        end;
                                    elseif v414 == 31 then
                                        local v420 = UNNAMED_2819735053592[v3];
                                        local v421 = UNNAMED_2819735040872[v3];
                                        local v422 = UNNAMED_2819735079176[v3];
                                        local _ = v420 + v422 - 1;
                                        local _ = v420 + v421;
                                        UNNAMED_2819735077736(UNNAMED_2819735092424(v10[v420](UNNAMED_2819735089688(v10, v420 + 1, v420 + v421))), 1, v422, v420, v10);
                                    else
                                        v1 = v10[UNNAMED_2819735040872[v3]];
                                    end;
                                elseif v414 < 23 then
                                    if v414 == 22 then
                                        v10[UNNAMED_2819735053592[v3]][UNNAMED_2819735060072[v3]] = v10[UNNAMED_2819735040872[v3]];
                                    else
                                        local v423 = UNNAMED_2819735079176[v3];
                                        local v424 = v10[UNNAMED_2819735040872[v3]];
                                        v10[v423] = v10[UNNAMED_2819735053592[v3]];
                                        v10[v423 + 1] = v424;
                                    end;
                                elseif v414 >= 24 then
                                    if v414 == 25 then
                                        local v425 = UNNAMED_2819735053592[v3];
                                        local v426 = UNNAMED_2819735065784(UNNAMED_2819735079176[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                                        local v427 = UNNAMED_2819735061992[5];
                                        local v428 = UNNAMED_2819735065784(v427[v425], 109162203);
                                        v427[v425] = v428;
                                        local v429 = UNNAMED_2819735061992[4];
                                        local v430 = v428 + 1;
                                        local v431 = UNNAMED_2819735082584(v429, v430);
                                        local v432;

                                        if v431 < 128 then
                                            v432 = v430 + 1;
                                        else
                                            local v433 = UNNAMED_2819735082584(v429, v430 + 1);

                                            if v433 < 128 then
                                                v431 = v431 - 128 + v433 * 128;
                                                v432 = v430 + 2;
                                            else
                                                local v434 = UNNAMED_2819735082584(v429, v430 + 2);

                                                if v434 < 128 then
                                                    v431 = v431 - 128 + (v433 - 128) * 16384 + v434 * 128;
                                                    v432 = v430 + 3;
                                                else
                                                    local v435 = UNNAMED_2819735082584(v429, v430 + 3);
                                                    v431 = (v431 - 128) * 16384 + (v433 - 128) * 128 + (v434 - 128) + v435 % 128 * 2097152 + (v435 - v435 % 128) * 2097152;
                                                    v432 = v430 + 4;
                                                end;
                                            end;
                                        end;

                                        local v436 = v426 * 16843009;
                                        local v437 = v432 + v431;
                                        local v438 = v437 - v431 % 4;

                                        for i = v432, v438 - 1, 4 do
                                            UNNAMED_2819735074184(v429, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v429, i), v436)));
                                            local _ = i;
                                        end;

                                        for i = v438, v437 - 1 do
                                            UNNAMED_2819735081960(v429, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v429, i), v426)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735053592[v3] = 232;
                                        UNNAMED_2819735079176[v3] = 48;
                                        UNNAMED_2819735040872[v3] = 59;
                                        UNNAMED_2819735062040[v3] = 17;
                                    else
                                        local v439 = UNNAMED_2819735040872[v3];
                                        local v440 = UNNAMED_2819735077352(UNNAMED_2819735064680);
                                        v440(UNNAMED_2819735068856, v10[v439], v10[v439 + 1], v10[v439 + 2]);
                                        local v441 = UNNAMED_2819735079176[v3];
                                        v3 = UNNAMED_2819735053592[v3];
                                        v6 = v441;
                                        v8 = v440;
                                        v11 = {
                                            [9] = v11,
                                            [7] = v9,
                                            [8] = v8,
                                            [5] = v12,
                                            [6] = v6
                                        };
                                    end;
                                elseif v10[UNNAMED_2819735079176[v3]] > UNNAMED_2819735053592[v3] then
                                    v3 = UNNAMED_2819735040872[v3];
                                end;
                            elseif v414 >= 37 then
                                if v414 < 40 then
                                    if v414 < 38 then
                                        local v442 = UNNAMED_2819735053592[v3];
                                        local v443 = UNNAMED_2819735079176[v3];
                                        local v444 = UNNAMED_2819735065784(v2, UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 28), 15)));
                                        local v445 = UNNAMED_2819735040872[v3];
                                        local v446 = v445 < 2097152 and 7 or 14;
                                        local v447 = UNNAMED_2819735072408(v445, UNNAMED_2819735042360(1, v446) - 1);
                                        local v448 = UNNAMED_2819735089496(v445, v446);
                                        UNNAMED_2819735079176[v3] = UNNAMED_2819735065784(v443, 95, (UNNAMED_2819735072408(UNNAMED_2819735089496(v444, 7), 127)));
                                        UNNAMED_2819735040872[v3] = UNNAMED_2819735065784(v447, 67, (UNNAMED_2819735072408(UNNAMED_2819735089496(v444, 14), 127)));
                                        UNNAMED_2819735053592[v3] = UNNAMED_2819735065784(v442, 77, (UNNAMED_2819735072408(v444, 127)));
                                        UNNAMED_2819735062040[v3] = UNNAMED_2819735065784(v448, 1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v444, 21), 127)));
                                        v3 = v3 - 1;
                                    elseif v414 == 39 then
                                        v10[UNNAMED_2819735040872[v3]](UNNAMED_2819735060072[v3], UNNAMED_2819735045192[v3]);
                                    else
                                        v10[UNNAMED_2819735040872[v3]] = not v10[UNNAMED_2819735053592[v3]];
                                    end;
                                elseif v414 < 41 then
                                    local v449 = UNNAMED_2819735040872[v3];
                                    local v450 = UNNAMED_2819735065784(v2, UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 14), 262143), (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 28), 15)));
                                    local v451 = UNNAMED_2819735079176[v3];
                                    local v452 = UNNAMED_2819735053592[v3];
                                    local v453 = v449 < 16384 and 7 or (v449 < 2097152 and 14 or 21);
                                    local v454 = UNNAMED_2819735089496(v449, v453);
                                    local v455 = UNNAMED_2819735072408(v449, UNNAMED_2819735042360(1, v453) - 1);
                                    UNNAMED_2819735062040[v3] = UNNAMED_2819735065784(v454, 28, (UNNAMED_2819735072408(UNNAMED_2819735089496(v450, 21), 127)));
                                    UNNAMED_2819735079176[v3] = UNNAMED_2819735065784(v451, 63, (UNNAMED_2819735072408(UNNAMED_2819735089496(v450, 7), 127)));
                                    UNNAMED_2819735053592[v3] = UNNAMED_2819735065784(v452, 27, (UNNAMED_2819735072408(v450, 127)));
                                    UNNAMED_2819735040872[v3] = UNNAMED_2819735065784(v455, 23, (UNNAMED_2819735072408(UNNAMED_2819735089496(v450, 14), 127)));
                                    v3 = v3 - 1;
                                elseif v414 == 42 then
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735040872;
                                else
                                    v10[UNNAMED_2819735040872[v3]] = UNNAMED_2819735053592[v3] * v10[UNNAMED_2819735079176[v3]];
                                end;
                            elseif v414 >= 34 then
                                if v414 >= 35 then
                                    if v414 == 36 then
                                        v10[UNNAMED_2819735079176[v3]] = v1;
                                    else
                                        v10[UNNAMED_2819735040872[v3]] = v2;
                                    end;
                                else
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735040872[v3] + v10[UNNAMED_2819735053592[v3]];
                                end;
                            elseif v414 == 33 then
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735040872[v3]] + UNNAMED_2819735053592[v3];
                            else
                                v10[UNNAMED_2819735040872[v3]] = -v10[UNNAMED_2819735053592[v3]];
                            end;
                        elseif v414 < 10 then
                            if v414 < 5 then
                                if v414 >= 2 then
                                    if v414 < 3 then
                                        local v456 = UNNAMED_2819735053592[v3];
                                        local v457 = UNNAMED_2819735079176[v3];
                                        local v458 = {
                                            n = v457 - v456 + 1
                                        };
                                        UNNAMED_2819735077736(v10, v456, v457, 1, v458);
                                        v10[UNNAMED_2819735040872[v3]] = v458;
                                    elseif v414 == 4 then
                                        v10[UNNAMED_2819735040872[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735053592[v3]], UNNAMED_2819735079176[v3]);
                                    else
                                        v3 = UNNAMED_2819735079176[v3];
                                    end;
                                elseif v414 == 1 then
                                    local v459 = v10[UNNAMED_2819735079176[v3]] % 4294967296;
                                    v10[UNNAMED_2819735053592[v3]] = v459 ~= v459 and 0 or v459 - v459 % 1;
                                else
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735068856[UNNAMED_2819735053592[v3]];
                                end;
                            elseif v414 >= 7 then
                                if v414 >= 8 then
                                    if v414 == 9 then
                                        v11 = {
                                            [9] = v11,
                                            [7] = v9,
                                            [8] = v8,
                                            [5] = v12,
                                            [6] = v6
                                        };
                                        local v460 = UNNAMED_2819735053592[v3];
                                        v9 = v10[v460 + 2] + 0;
                                        v12 = v10[v460 + 1] + 0;
                                        v8 = v10[v460] - v9;
                                        v3 = UNNAMED_2819735079176[v3];
                                    else
                                        v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] < UNNAMED_2819735040872[v3];
                                    end;
                                else
                                    v10[UNNAMED_2819735053592[v3]][v10[UNNAMED_2819735079176[v3]]] = v10[UNNAMED_2819735040872[v3]];
                                end;
                            elseif v414 == 6 then
                                v10[UNNAMED_2819735040872[v3]] = v10[UNNAMED_2819735053592[v3]] == UNNAMED_2819735079176[v3];
                            else
                                v10[UNNAMED_2819735079176[v3]](UNNAMED_2819735028104[v3]);
                            end;
                        elseif v414 >= 15 then
                            if v414 < 18 then
                                if v414 < 16 then
                                    v10[UNNAMED_2819735040872[v3]] = v10[UNNAMED_2819735053592[v3]] - UNNAMED_2819735060072[v3];
                                elseif v414 ~= 17 then
                                    v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735040872[v3]], v10[UNNAMED_2819735053592[v3]]);
                                end;
                            elseif v414 < 19 then
                                v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735079176[v3]] % v10[UNNAMED_2819735040872[v3]];
                            elseif v414 == 20 then
                                local v461 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                v10[UNNAMED_2819735040872[v3]] = v461[5][v461[4]][v10[UNNAMED_2819735053592[v3]]];
                            else
                                local v462 = UNNAMED_2819735079176[v3];
                                local v463 = v10[UNNAMED_2819735040872[v3]];
                                local v464 = UNNAMED_2819735072408(v10[UNNAMED_2819735053592[v3]], 4294967295);
                                local v465 = UNNAMED_2819735072408(v463, 4294967295);
                                local v466 = UNNAMED_2819735072408(v464, 65535);
                                local v467 = UNNAMED_2819735089496(v464, 16);
                                local v468 = UNNAMED_2819735072408(v465, 65535);
                                local v469 = UNNAMED_2819735089496(v465, 16);
                                local v470 = UNNAMED_2819735072408(v466 * v468 + UNNAMED_2819735042360(UNNAMED_2819735072408(v466 * v469 + v467 * v468, 65535), 16), 4294967295) % 4294967296;
                                v10[v462] = v470 ~= v470 and 0 or v470 - v470 % 1;
                            end;
                        elseif v414 >= 12 then
                            if v414 < 13 then
                                v10[UNNAMED_2819735040872[v3]]();
                            elseif v414 == 14 then
                                v10[UNNAMED_2819735079176[v3]] = {};
                            else
                                local v471 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                v10[UNNAMED_2819735053592[v3]] = v471[5][v471[4]];
                            end;
                        elseif v414 == 11 then
                            v10[UNNAMED_2819735040872[v3]] = v10[UNNAMED_2819735079176[v3]] + v10[UNNAMED_2819735053592[v3]];
                        else
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] ~= UNNAMED_2819735040872[v3];
                        end;
                    elseif v414 < 65 then
                        if v414 >= 54 then
                            if v414 < 59 then
                                if v414 >= 56 then
                                    if v414 < 57 then
                                        v10[UNNAMED_2819735040872[v3]] = UNNAMED_2819735045192[v3];
                                    elseif v414 == 58 then
                                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735059640(v10[UNNAMED_2819735053592[v3]], v10[UNNAMED_2819735040872[v3]]);
                                    elseif v10[UNNAMED_2819735040872[v3]] then
                                        v3 = UNNAMED_2819735079176[v3];
                                    else
                                        v3 = UNNAMED_2819735053592[v3];
                                    end;
                                elseif v414 == 55 then
                                    local v472 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                    v472[5][v472[4]][UNNAMED_2819735028104[v3]] = v10[UNNAMED_2819735053592[v3]];
                                else
                                    v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735040872[v3]] % UNNAMED_2819735079176[v3];
                                end;
                            elseif v414 >= 62 then
                                if v414 < 63 then
                                    if v7 then
                                        for i in UNNAMED_2819735091272, v7 do
                                            local v473 = v7[i];

                                            if v473 then
                                                v473[5] = v473;
                                                v473[6] = v10[i];
                                                v473[4] = 6;
                                                v7[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v13 then
                                        for i, v in UNNAMED_2819735091272, v13 do
                                            local v474 = v[6];

                                            if v13 then
                                                local v475 = v13[i];

                                                if v475 then
                                                    local v476 = UNNAMED_2819735058728(v474);
                                                    UNNAMED_2819735077736(v10, i, i + v474 - 1, 1, v476);
                                                    v475[5] = v476;
                                                    v475[4] = 1;
                                                    v13[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return;
                                end;

                                if v414 == 64 then
                                    v10[UNNAMED_2819735040872[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735079176[v3]], UNNAMED_2819735045192[v3]);
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] == v10[UNNAMED_2819735040872[v3]];
                                end;
                            elseif v414 < 60 then
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735040872[v3]] * UNNAMED_2819735053592[v3];
                            elseif v414 == 61 then
                                v3 = v10[UNNAMED_2819735053592[v3]];
                            else
                                v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735053592[v3];
                            end;
                        elseif v414 >= 48 then
                            if v414 >= 51 then
                                if v414 >= 52 then
                                    if v414 == 53 then
                                        v10[UNNAMED_2819735040872[v3]] = UNNAMED_2819735061992;
                                    else
                                        v10[UNNAMED_2819735079176[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735053592[v3]], UNNAMED_2819735040872[v3]);
                                    end;
                                else
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] // UNNAMED_2819735040872[v3];
                                end;
                            elseif v414 >= 49 then
                                if v414 == 50 then
                                    v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735040872[v3]] - UNNAMED_2819735079176[v3];
                                else
                                    local v477 = UNNAMED_2819735053592[v3];
                                    local v478 = UNNAMED_2819735079176[v3] + 1;

                                    for i = 1, UNNAMED_2819735040872[v3] do
                                        local v479 = UNNAMED_2819735072408(UNNAMED_2819735065784(v477, (UNNAMED_2819735042360(v477, 13))), 536870911);
                                        local v480 = UNNAMED_2819735065784(v479, (UNNAMED_2819735089496(v479, 13)));
                                        v477 = UNNAMED_2819735072408(UNNAMED_2819735065784(v480, (UNNAMED_2819735042360(v480, 14))), 536870911);
                                        UNNAMED_2819735053592[v478] = UNNAMED_2819735065784(UNNAMED_2819735053592[v478], (UNNAMED_2819735072408(UNNAMED_2819735089496(v477, 0), 127)));
                                        UNNAMED_2819735079176[v478] = UNNAMED_2819735065784(UNNAMED_2819735079176[v478], (UNNAMED_2819735072408(UNNAMED_2819735089496(v477, 7), 127)));
                                        UNNAMED_2819735040872[v478] = UNNAMED_2819735065784(UNNAMED_2819735040872[v478], (UNNAMED_2819735072408(UNNAMED_2819735089496(v477, 14), 127)));
                                        UNNAMED_2819735062040[v478] = UNNAMED_2819735065784(UNNAMED_2819735062040[v478], (UNNAMED_2819735072408(UNNAMED_2819735089496(v477, 21), 127)));
                                        v478 = v478 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735062040[v3] = 17;
                                end;
                            else
                                v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735079176[v3]](v10[UNNAMED_2819735040872[v3]]);
                            end;
                        elseif v414 < 45 then
                            if v414 == 44 then
                                if v10[UNNAMED_2819735040872[v3]] then
                                    v3 = UNNAMED_2819735079176[v3];
                                else
                                    v3 = UNNAMED_2819735053592[v3];
                                end;
                            else
                                v3 = v10[UNNAMED_2819735079176[v3]];
                            end;
                        elseif v414 >= 46 then
                            if v414 == 47 then
                                local v481 = UNNAMED_2819735065784(UNNAMED_2819735079176[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
                                local v482 = UNNAMED_2819735053592[v3] + 1;

                                for i = 1, UNNAMED_2819735040872[v3] do
                                    local v483 = UNNAMED_2819735072408(UNNAMED_2819735065784(v481, (UNNAMED_2819735042360(v481, 13))), 536870911);
                                    local v484 = UNNAMED_2819735065784(v483, (UNNAMED_2819735089496(v483, 13)));
                                    v481 = UNNAMED_2819735072408(UNNAMED_2819735065784(v484, (UNNAMED_2819735042360(v484, 14))), 536870911);
                                    UNNAMED_2819735053592[v482] = UNNAMED_2819735065784(UNNAMED_2819735053592[v482], (UNNAMED_2819735072408(UNNAMED_2819735089496(v481, 0), 127)));
                                    UNNAMED_2819735079176[v482] = UNNAMED_2819735065784(UNNAMED_2819735079176[v482], (UNNAMED_2819735072408(UNNAMED_2819735089496(v481, 7), 127)));
                                    UNNAMED_2819735040872[v482] = UNNAMED_2819735065784(UNNAMED_2819735040872[v482], (UNNAMED_2819735072408(UNNAMED_2819735089496(v481, 14), 127)));
                                    UNNAMED_2819735062040[v482] = UNNAMED_2819735065784(UNNAMED_2819735062040[v482], (UNNAMED_2819735072408(UNNAMED_2819735089496(v481, 21), 127)));
                                    v482 = v482 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735062040[v3] = 17;
                            elseif v7 then
                                local v485 = UNNAMED_2819735079176[v3];
                                local v486 = v7[v485];

                                if v486 then
                                    v486[5] = v486;
                                    v486[6] = v10[v485];
                                    v486[4] = 6;
                                    v7[v485] = nil;
                                end;

                                local v487 = UNNAMED_2819735040872[v3];
                                local v488 = v7[v487];

                                if v488 then
                                    v488[5] = v488;
                                    v488[6] = v10[v487];
                                    v488[4] = 6;
                                    v7[v487] = nil;
                                end;
                            end;
                        else
                            v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] + UNNAMED_2819735028104[v3];
                        end;
                    elseif v414 >= 76 then
                        if v414 >= 81 then
                            if v414 < 84 then
                                if v414 >= 82 then
                                    if v414 == 83 then
                                        local v489 = UNNAMED_2819735065784(UNNAMED_2819735079176[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v1, (UNNAMED_2819735072408(UNNAMED_2819735089496(v1, 29), 7))), 536870911)));
                                        local v490 = UNNAMED_2819735053592[v3] + 1;

                                        for i = 1, UNNAMED_2819735040872[v3] do
                                            local v491 = UNNAMED_2819735072408(UNNAMED_2819735065784(v489, (UNNAMED_2819735042360(v489, 13))), 536870911);
                                            local v492 = UNNAMED_2819735065784(v491, (UNNAMED_2819735089496(v491, 13)));
                                            v489 = UNNAMED_2819735072408(UNNAMED_2819735065784(v492, (UNNAMED_2819735042360(v492, 14))), 536870911);
                                            UNNAMED_2819735053592[v490] = UNNAMED_2819735065784(UNNAMED_2819735053592[v490], (UNNAMED_2819735072408(UNNAMED_2819735089496(v489, 0), 127)));
                                            UNNAMED_2819735079176[v490] = UNNAMED_2819735065784(UNNAMED_2819735079176[v490], (UNNAMED_2819735072408(UNNAMED_2819735089496(v489, 7), 127)));
                                            UNNAMED_2819735040872[v490] = UNNAMED_2819735065784(UNNAMED_2819735040872[v490], (UNNAMED_2819735072408(UNNAMED_2819735089496(v489, 14), 127)));
                                            UNNAMED_2819735062040[v490] = UNNAMED_2819735065784(UNNAMED_2819735062040[v490], (UNNAMED_2819735072408(UNNAMED_2819735089496(v489, 21), 127)));
                                            v490 = v490 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735062040[v3] = 17;
                                    else
                                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735065784(v10[UNNAMED_2819735079176[v3]], v10[UNNAMED_2819735040872[v3]]);
                                    end;
                                else
                                    v10[UNNAMED_2819735040872[v3]] = v10[UNNAMED_2819735079176[v3]] * v10[UNNAMED_2819735053592[v3]];
                                end;
                            elseif v414 < 85 then
                                v2 = v10[UNNAMED_2819735040872[v3]];
                            elseif v414 == 86 then
                                v8 = v11[8];
                                v12 = v11[5];
                                v9 = v11[7];
                                v6 = v11[6];
                                v11 = v11[9];
                            else
                                v10[UNNAMED_2819735079176[v3]](v10[UNNAMED_2819735040872[v3]]);
                            end;
                        elseif v414 < 78 then
                            if v414 == 77 then
                                if v10[UNNAMED_2819735040872[v3]] >= UNNAMED_2819735079176[v3] then
                                    v3 = UNNAMED_2819735053592[v3];
                                end;
                            else
                                local v493 = UNNAMED_2819735040872[v3];
                                local v494 = UNNAMED_2819735079176[v3];
                                local v495 = UNNAMED_2819735061992[5];
                                local v496 = UNNAMED_2819735065784(v495[v493], 109162203);
                                v495[v493] = v496;
                                local v497 = UNNAMED_2819735061992[4];
                                local v498 = v496 + 1;
                                local v499 = UNNAMED_2819735082584(v497, v498);
                                local v500;

                                if v499 < 128 then
                                    v500 = v498 + 1;
                                else
                                    local v501 = UNNAMED_2819735082584(v497, v498 + 1);

                                    if v501 < 128 then
                                        v499 = v499 - 128 + v501 * 128;
                                        v500 = v498 + 2;
                                    else
                                        local v502 = UNNAMED_2819735082584(v497, v498 + 2);

                                        if v502 < 128 then
                                            v499 = v499 - 128 + (v501 - 128) * 16384 + v502 * 128;
                                            v500 = v498 + 3;
                                        else
                                            local v503 = UNNAMED_2819735082584(v497, v498 + 3);
                                            v499 = (v499 - 128) * 16384 + (v501 - 128) * 128 + (v502 - 128) + v503 % 128 * 2097152 + (v503 - v503 % 128) * 2097152;
                                            v500 = v498 + 4;
                                        end;
                                    end;
                                end;

                                local v504 = v494 * 16843009;
                                local v505 = v500 + v499;
                                local v506 = v505 - v499 % 4;

                                for i = v500, v506 - 1, 4 do
                                    UNNAMED_2819735074184(v497, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v497, i), v504)));
                                    local _ = i;
                                end;

                                for i = v506, v505 - 1 do
                                    UNNAMED_2819735081960(v497, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v497, i), v494)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735040872[v3] = 176;
                                UNNAMED_2819735079176[v3] = 125;
                                UNNAMED_2819735053592[v3] = 24;
                                UNNAMED_2819735062040[v3] = 17;
                            end;
                        elseif v414 < 79 then
                            local v507 = UNNAMED_2819735053592[v3];
                            local v508 = UNNAMED_2819735065784(UNNAMED_2819735079176[v3], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
                            local v509 = UNNAMED_2819735061992[5];
                            local v510 = UNNAMED_2819735065784(v509[v507], 109162203);
                            v509[v507] = v510;
                            local v511 = UNNAMED_2819735061992[4];
                            local v512 = v510 + 1;
                            local v513 = UNNAMED_2819735082584(v511, v512);
                            local v514;

                            if v513 < 128 then
                                v514 = v512 + 1;
                            else
                                local v515 = UNNAMED_2819735082584(v511, v512 + 1);

                                if v515 < 128 then
                                    v513 = v513 - 128 + v515 * 128;
                                    v514 = v512 + 2;
                                else
                                    local v516 = UNNAMED_2819735082584(v511, v512 + 2);

                                    if v516 < 128 then
                                        v513 = v513 - 128 + (v515 - 128) * 16384 + v516 * 128;
                                        v514 = v512 + 3;
                                    else
                                        local v517 = UNNAMED_2819735082584(v511, v512 + 3);
                                        v513 = (v513 - 128) * 16384 + (v515 - 128) * 128 + (v516 - 128) + v517 % 128 * 2097152 + (v517 - v517 % 128) * 2097152;
                                        v514 = v512 + 4;
                                    end;
                                end;
                            end;

                            local v518 = v508 * 16843009;
                            local v519 = v514 + v513;
                            local v520 = v519 - v513 % 4;

                            for i = v514, v520 - 1, 4 do
                                UNNAMED_2819735074184(v511, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v511, i), v518)));
                                local _ = i;
                            end;

                            for i = v520, v519 - 1 do
                                UNNAMED_2819735081960(v511, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v511, i), v508)));
                                local _ = i;
                            end;

                            UNNAMED_2819735053592[v3] = 117;
                            UNNAMED_2819735079176[v3] = 65;
                            UNNAMED_2819735040872[v3] = 128;
                            UNNAMED_2819735062040[v3] = 17;
                        elseif v414 == 80 then
                            local v521 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                            v521[5][v521[4]] = v10[UNNAMED_2819735040872[v3]];
                        elseif v10[UNNAMED_2819735053592[v3]] ~= UNNAMED_2819735079176[v3] then
                            v3 = UNNAMED_2819735040872[v3];
                        end;
                    else
                        if v414 < 70 then
                            if v414 < 67 then
                                if v414 == 66 then
                                    v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735040872[v3]];
                                else
                                    v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735079176;
                                end;
                            elseif v414 >= 68 then
                                if v414 == 69 then
                                    if v10[UNNAMED_2819735079176[v3]] ~= v10[UNNAMED_2819735053592[v3]] then
                                        v3 = UNNAMED_2819735040872[v3];
                                    end;
                                elseif UNNAMED_2819735040872[v3] >= v10[UNNAMED_2819735053592[v3]] then
                                    v3 = UNNAMED_2819735079176[v3];
                                end;
                            else
                                local v522 = nil;
                                local v523 = UNNAMED_2819735053592[v3];
                                local v524 = UNNAMED_2819735028104[v3];
                                local v525 = UNNAMED_2819735060072[v3];
                                local v526 = v525[0];

                                if v526 then
                                    local v527 = #v526 / 3;

                                    if v527 > 0 then
                                        v522 = {};

                                        for i = 1, v527 do
                                            local v528 = (i - 1) * 3;
                                            local v529 = v526[v528 + 2];
                                            local v530 = v526[v528 + 1];
                                            local v531;

                                            if v529 == 2 then
                                                v7 = v7 or {};
                                                local v532 = v7[v530];

                                                if not v532 then
                                                    v532 = {
                                                        [5] = v10,
                                                        [4] = v530
                                                    };
                                                    v7[v530] = v532;
                                                end;

                                                v522[i] = v532;
                                                v531 = i;
                                            elseif v529 == 0 then
                                                v522[i] = v10[v530];
                                                v531 = i;
                                            elseif v529 == 3 then
                                                v522[i] = UNNAMED_2819735051432[v530];
                                                v531 = i;
                                            elseif v529 == 1 then
                                                v13 = v13 or {};
                                                local v533 = v13[v530];

                                                if not v533 then
                                                    v533 = {
                                                        [5] = v10,
                                                        [4] = v530,
                                                        [6] = v526[v528 + 3]
                                                    };
                                                    v13[v530] = v533;
                                                end;

                                                v522[i] = v533;
                                                v531 = i;
                                            else
                                                v531 = i;
                                            end;
                                        end;
                                    end;
                                end;

                                local v534 = v525[-2];
                                v525[v534] = v522;
                                local v535 = v524(UNNAMED_2819735089688(v525, 1, v525[-1]));
                                v525[v534] = nil;
                                v10[v523] = v535;
                            end;

                            v413 = 1;
                            continue;
                        end;

                        if v414 >= 73 then
                            if v414 >= 74 then
                                if v414 == 75 then
                                    v10[UNNAMED_2819735053592[v3]] = v10[UNNAMED_2819735079176[v3]]();
                                else
                                    local v536 = UNNAMED_2819735051432[UNNAMED_2819735079176[v3]];
                                    v536[5][v536[4]][v10[UNNAMED_2819735053592[v3]]] = v10[UNNAMED_2819735040872[v3]];
                                end;
                            else
                                v10[UNNAMED_2819735040872[v3]] = UNNAMED_2819735053592;
                            end;

                            v413 = 1;
                            continue;
                        end;

                        if v414 >= 71 then
                            if v414 ~= 72 then
                                v10[UNNAMED_2819735079176[v3]] = v10[UNNAMED_2819735053592[v3]] - v10[UNNAMED_2819735040872[v3]];
                                v413 = 1;
                                continue;
                            end;

                            v4 = UNNAMED_2819735079176[v3];
                            v3 = UNNAMED_2819735040872[v3] + 1;
                            v15 = 7;
                            break;
                        end;

                        v10[UNNAMED_2819735053592[v3]] = UNNAMED_2819735072408(v10[UNNAMED_2819735040872[v3]], UNNAMED_2819735060072[v3]);
                    end;

                    v413 = 1;
                    continue;
                elseif v413 == 1 then
                    v413 = -1;
                    v3 = v3 + 1;
                    break;
                else
                    break;
                end;
            end;

            if v15 ~= -1 then
                break;
            end;
        end;

        if v15 ~= -1 then
            continue;
        end;

        v15 = 11;
        continue;
    elseif v15 == 11 then
        v15 = -1;
        v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735040872[v5]] * v10[UNNAMED_2819735053592[v5]];
        v15 = 12;
        continue;
    elseif v15 == 12 then
        v15 = -1;
        v15 = 14;
        continue;
    elseif v15 == 13 then
        v15 = -1;

        if v14 < 60 then
            if v14 == 59 then
                v8 = v8 + v9;
                local v537;

                if v9 <= 0 then
                    v537 = v12 <= v8;
                else
                    v537 = v8 <= v12;
                end;

                if v537 then
                    v10[UNNAMED_2819735053592[v5]] = v8;
                    v5 = UNNAMED_2819735062040[v5];
                else
                    v5 = UNNAMED_2819735040872[v5];
                end;
            else
                v10[UNNAMED_2819735062040[v5]] = UNNAMED_2819735065784(v10[UNNAMED_2819735040872[v5]], UNNAMED_2819735053592[v5]);
            end;
        elseif v14 >= 61 then
            if v14 ~= 62 and UNNAMED_2819735028104[v5] > v10[UNNAMED_2819735062040[v5]] then
                v5 = UNNAMED_2819735053592[v5];
            end;
        else
            local v538 = UNNAMED_2819735062040[v5];
            local v539 = UNNAMED_2819735065784(UNNAMED_2819735053592[v5], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
            local v540 = UNNAMED_2819735061992[5];
            local v541 = UNNAMED_2819735065784(v540[v538], 109162203);
            v540[v538] = v541;
            local v542 = UNNAMED_2819735061992[4];
            local v543 = v541 + 1;
            local v544 = UNNAMED_2819735082584(v542, v543);
            local v545;

            if v544 < 128 then
                v545 = v543 + 1;
            else
                local v546 = UNNAMED_2819735082584(v542, v543 + 1);

                if v546 < 128 then
                    v544 = v544 - 128 + v546 * 128;
                    v545 = v543 + 2;
                else
                    local v547 = UNNAMED_2819735082584(v542, v543 + 2);

                    if v547 < 128 then
                        v544 = v544 - 128 + (v546 - 128) * 16384 + v547 * 128;
                        v545 = v543 + 3;
                    else
                        local v548 = UNNAMED_2819735082584(v542, v543 + 3);
                        v544 = (v544 - 128) * 16384 + (v546 - 128) * 128 + (v547 - 128) + v548 % 128 * 2097152 + (v548 - v548 % 128) * 2097152;
                        v545 = v543 + 4;
                    end;
                end;
            end;

            local v549 = v539 * 16843009;
            local v550 = v545 + v544;
            local v551 = v550 - v544 % 4;

            for i = v545, v551 - 1, 4 do
                UNNAMED_2819735074184(v542, i, (UNNAMED_2819735065784(UNNAMED_2819735032760(v542, i), v549)));
                local _ = i;
            end;

            for i = v551, v550 - 1 do
                UNNAMED_2819735081960(v542, i, (UNNAMED_2819735065784(UNNAMED_2819735082584(v542, i), v539)));
                local _ = i;
            end;

            UNNAMED_2819735062040[v5] = 22;
            UNNAMED_2819735053592[v5] = 188;
            UNNAMED_2819735040872[v5] = 154;
            UNNAMED_2819735079176[v5] = 62;
        end;

        v15 = 14;
        continue;
    elseif v15 == 14 then
        v15 = -1;
        v15 = 16;
        continue;
    elseif v15 == 15 then
        v15 = -1;

        if v14 < 18 then
            if v14 < 9 then
                if v14 >= 4 then
                    if v14 >= 6 then
                        if v14 < 7 then
                            v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735062040[v5]];
                        else
                            if v14 == 8 then
                                return;
                            end;

                            v5 = UNNAMED_2819735040872[v5];
                        end;
                    elseif v14 == 5 then
                        v10[UNNAMED_2819735040872[v5]] = v10[UNNAMED_2819735053592[v5]] - UNNAMED_2819735031560[v5];
                    else
                        v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735062040[v5]] % UNNAMED_2819735040872[v5];
                    end;
                elseif v14 >= 2 then
                    if v14 == 3 then
                        local v552 = UNNAMED_2819735051432[UNNAMED_2819735053592[v5]];
                        v10[UNNAMED_2819735062040[v5]] = v552[5][v552[4]];
                    else
                        local v553 = UNNAMED_2819735053592[v5];
                        local v554 = v10[UNNAMED_2819735062040[v5]];
                        v10[v553] = v10[UNNAMED_2819735040872[v5]];
                        v10[v553 + 1] = v554;
                    end;
                elseif v14 == 1 then
                    local v555 = UNNAMED_2819735062040[v5];
                    local v556 = UNNAMED_2819735040872[v5];
                    local v557 = UNNAMED_2819735053592[v5];
                    local _ = v555 + v557 - 1;
                    local _ = v555 + v556;
                    UNNAMED_2819735077736(UNNAMED_2819735092424(v10[v555](UNNAMED_2819735089688(v10, v555 + 1, v555 + v556))), 1, v557, v555, v10);
                else
                    v10[UNNAMED_2819735040872[v5]] = v10[UNNAMED_2819735062040[v5]] == UNNAMED_2819735053592[v5];
                end;
            elseif v14 < 13 then
                if v14 < 11 then
                    if v14 == 10 then
                        v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735040872[v5]] == v10[UNNAMED_2819735053592[v5]];
                    else
                        v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735040872[v5]] // UNNAMED_2819735053592[v5];
                    end;
                elseif v14 == 12 then
                    v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735040872[v5]] > UNNAMED_2819735053592[v5];
                else
                    v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735040872[v5]] - UNNAMED_2819735062040[v5];
                end;
            elseif v14 < 15 then
                if v14 == 14 then
                    if v10[UNNAMED_2819735062040[v5]] > UNNAMED_2819735040872[v5] then
                        v5 = UNNAMED_2819735053592[v5];
                    end;
                else
                    v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735040872[v5]][UNNAMED_2819735031560[v5]];
                end;
            elseif v14 < 16 then
                v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735062040[v5]] + v10[UNNAMED_2819735040872[v5]];
            else
                if v14 ~= 17 then
                    return UNNAMED_2819735045192[v5];
                end;

                v10[UNNAMED_2819735053592[v5]] = UNNAMED_2819735062040[v5] + v10[UNNAMED_2819735040872[v5]];
            end;
        elseif v14 >= 27 then
            if v14 >= 31 then
                if v14 < 33 then
                    if v14 == 32 then
                        v10[UNNAMED_2819735040872[v5]] = v2;
                    else
                        v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735040872[v5]] - v10[UNNAMED_2819735062040[v5]];
                    end;
                elseif v14 >= 34 then
                    if v14 == 35 then
                        local v558 = UNNAMED_2819735065784(UNNAMED_2819735053592[v5], (UNNAMED_2819735072408(UNNAMED_2819735065784(v2, (UNNAMED_2819735072408(UNNAMED_2819735089496(v2, 29), 7))), 536870911)));
                        local v559 = UNNAMED_2819735062040[v5] + 1;

                        for i = 1, UNNAMED_2819735040872[v5] do
                            local v560 = UNNAMED_2819735072408(UNNAMED_2819735065784(v558, (UNNAMED_2819735042360(v558, 13))), 536870911);
                            local v561 = UNNAMED_2819735065784(v560, (UNNAMED_2819735089496(v560, 13)));
                            v558 = UNNAMED_2819735072408(UNNAMED_2819735065784(v561, (UNNAMED_2819735042360(v561, 14))), 536870911);
                            UNNAMED_2819735062040[v559] = UNNAMED_2819735065784(UNNAMED_2819735062040[v559], (UNNAMED_2819735072408(UNNAMED_2819735089496(v558, 0), 127)));
                            UNNAMED_2819735053592[v559] = UNNAMED_2819735065784(UNNAMED_2819735053592[v559], (UNNAMED_2819735072408(UNNAMED_2819735089496(v558, 7), 127)));
                            UNNAMED_2819735040872[v559] = UNNAMED_2819735065784(UNNAMED_2819735040872[v559], (UNNAMED_2819735072408(UNNAMED_2819735089496(v558, 14), 127)));
                            UNNAMED_2819735079176[v559] = UNNAMED_2819735065784(UNNAMED_2819735079176[v559], (UNNAMED_2819735072408(UNNAMED_2819735089496(v558, 21), 127)));
                            v559 = v559 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735079176[v5] = 62;
                    else
                        v10[UNNAMED_2819735062040[v5]] = UNNAMED_2819735051432[UNNAMED_2819735053592[v5]][v10[UNNAMED_2819735040872[v5]]];
                    end;
                else
                    v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735053592[v5]] * UNNAMED_2819735040872[v5];
                end;
            elseif v14 >= 29 then
                if v14 == 30 then
                    v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735053592[v5]] * UNNAMED_2819735028104[v5];
                else
                    v10[UNNAMED_2819735062040[v5]] = v10[UNNAMED_2819735040872[v5]](v10[UNNAMED_2819735053592[v5]]);
                end;
            elseif v14 == 28 then
                v10[UNNAMED_2819735040872[v5]] = UNNAMED_2819735065784(v10[UNNAMED_2819735053592[v5]], v10[UNNAMED_2819735062040[v5]]);
            else
                v10[UNNAMED_2819735053592[v5]] = v1;
            end;
        elseif v14 < 22 then
            if v14 >= 20 then
                if v14 == 21 then
                    local v562 = UNNAMED_2819735040872[v5];
                    local v563 = v10[UNNAMED_2819735062040[v5]];
                    v10[v562] = UNNAMED_2819735053592[v5];
                    v10[v562 + 1] = v563;
                else
                    v1 = v10[UNNAMED_2819735040872[v5]];
                end;
            elseif v14 == 19 then
                v10[UNNAMED_2819735062040[v5]] = UNNAMED_2819735042360(v10[UNNAMED_2819735053592[v5]], UNNAMED_2819735040872[v5]);
            elseif v10[UNNAMED_2819735062040[v5]] then
                v5 = UNNAMED_2819735040872[v5];
            else
                v5 = UNNAMED_2819735053592[v5];
            end;
        elseif v14 < 24 then
            if v14 == 23 then
                v10[UNNAMED_2819735040872[v5]] = UNNAMED_2819735051432[UNNAMED_2819735053592[v5]];
            else
                v10[UNNAMED_2819735040872[v5]] = UNNAMED_2819735053592[v5] * v10[UNNAMED_2819735062040[v5]];
            end;
        elseif v14 >= 25 then
            if v14 == 26 then
                local v564 = v10[UNNAMED_2819735062040[v5]] % 4294967296;
                v10[UNNAMED_2819735053592[v5]] = v564 ~= v564 and 0 or v564 - v564 % 1;
            else
                v10[UNNAMED_2819735040872[v5]] = v10[UNNAMED_2819735053592[v5]] // v10[UNNAMED_2819735062040[v5]];
            end;
        else
            v10[UNNAMED_2819735053592[v5]] = v10[UNNAMED_2819735062040[v5]][v10[UNNAMED_2819735040872[v5]]];
        end;

        v15 = 16;
        continue;
    elseif v15 == 16 then
        v15 = -1;
        v5 = v5 + 1;
        v15 = 1;
        continue;
    elseif v15 == 17 then
        v15 = -1;
        break;
    else
        break;
    end;
end;