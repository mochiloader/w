-- Captured auxiliary state; names assigned for analysis.
return {
	tags = {
		["enabled"] = false,
		["tagNum"] = "7",
		["tagRole"] = "QB",
	},
	diveBoost = {
		["on"] = false,
		["mult"] = 0,
	},
	autoCaptainBox = {
		[6] = false,
		[4] = 6,
	},
	tungSahorBallBox = {
		[6] = false,
		[4] = 6,
	},
	antiBenchBox = {
		[6] = false,
		[4] = 6,
	},
	antiAce = {
		["Enabled"] = false,
		["Distance"] = 30,
		["Smooth"] = 0.35,
	},
	flight = {
		["enabled"] = false,
		["speed"] = 50,
	},
	cframeMovement = {
		["enabled"] = false,
		["cframeSpeed"] = 0,
	},
	endzoneZoneBox = {
		[6] = "Fieldgoal 1",
		[4] = 6,
	},
	autoRush = {
		["ShowBeam"] = false,
		["Enabled"] = false,
		["Delay"] = 0,
		["ShowEndPart"] = false,
	},
	targetBox = {
		[6] = "",
		[4] = 6,
	},
	autoReel = {
		["on"] = false,
		["strength"] = 5,
	},
	flingTargetBox = {
		[6] = "",
		[4] = 6,
	},
}
