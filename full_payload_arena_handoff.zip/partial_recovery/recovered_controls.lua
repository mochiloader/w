-- Reconstructed gameplay control callbacks from a live VM capture.
-- This module contains recovered control handlers, not the complete gameplay program.
-- settings/state are explicit parameters replacing captured objects. State names are assigned for analysis.
-- VM instruction-cache writes are omitted. See recovery_notes.txt for limits.
local controls = {}

controls["Misc/Tag Role"] = function(settings, state, value)
	state.tags["tagRole"] = value
end

controls["Misc/Fake Global"] = function(settings, state, value)
	state.tags["enabled"] = value
end

controls["Misc/Admin Detector"] = function(settings, state, value)
	settings.Player["AdminDetector"] = value
end

controls["Physics/Dive Boost"] = function(settings, state, value)
	state.diveBoost["on"] = value
end

controls["Physics/Dive Power Value"] = function(settings, state, value)
	settings.Physics["DivePowerValue"] = value
end

controls["Physics/Dive Power"] = function(settings, state, value)
	settings.Physics["DivePower"] = value
end

controls["Physics/No Freeze"] = function(settings, state, value)
	settings.Physics["NoFreeze"] = value
end

controls["Physics/No Jump Cooldown"] = function(settings, state, value)
	settings.Physics["NoJumpCooldown"] = value
end

controls["Physics/Block Range"] = function(settings, state, value)
	settings.Physics["BlockReachRange"] = value
end

controls["Misc/Anti Bench"] = function(settings, state, value)
	state.antiBenchBox[6] = value
end

controls["Physics/Show Block Reach"] = function(settings, state, value)
	settings.Physics["BlockReachHitbox"] = value
end

controls["Physics/Block Reach"] = function(settings, state, value)
	settings.Physics["BlockReach"] = value
end

controls["Physics/Anti Jam"] = function(settings, state, value)
	settings.Physics["AntiJam"] = value
end

controls["Physics/Anti Block"] = function(settings, state, value)
	settings.Physics["AntiBlock"] = value
end

controls["Player/No Move Restrictions"] = function(settings, state, value)
	settings.Player["NoMoveRestrictions"] = value
end

controls["Player/Anti Ace Smooth"] = function(settings, state, value)
	state.antiAce["Smooth"] = (value / 100)
end

controls["Player/Anti Ace Distance"] = function(settings, state, value)
	state.antiAce["Distance"] = value
end

controls["Player/Anti Ace"] = function(settings, state, value)
	state.antiAce["Enabled"] = value
end

controls["Player/Angle Notifier"] = function(settings, state, value)
	settings.Player["AngleNotifier"] = value
end

controls["Player/Angle Power"] = function(settings, state, value)
	settings.Player["AngleVal"] = value
end

controls["Player/Angle Enhancer"] = function(settings, state, value)
	settings.Player["AngleEnhancer"] = value
end

controls["Player/Hip Height Value"] = function(settings, state, value)
	settings.Player["HipHeightValue"] = value
end

controls["Player/Hip Height"] = function(settings, state, value)
	settings.Player["HipHeight"] = value
end

controls["Player/Fly Speed"] = function(settings, state, value)
	state.flight["speed"] = value
end

controls["Player/Infinite Power"] = function(settings, state, value)
	settings.Player["IJPower"] = value
end

controls["Player/Infinite Jump"] = function(settings, state, value)
	settings.Player["InfiniteJump"] = value
end

controls["Player/Velocity Boost"] = function(settings, state, value)
	settings.Player["VJBoost"] = value
end

controls["Player/Velocity Jump"] = function(settings, state, value)
	settings.Player["VelocityJump"] = value
end

controls["Player/Jump Power#2"] = function(settings, state, value)
	settings.Player["JPower"] = value
end

controls["Player/Jump Power"] = function(settings, state, value)
	settings.Player["JumpPower"] = value
end

controls["Player/CF Speed"] = function(settings, state, value)
	state.cframeMovement["cframeSpeed"] = value
end

controls["Player/CFrame Speed"] = function(settings, state, value)
	state.cframeMovement["enabled"] = value
end

controls["Physics/Gravity"] = function(settings, state, value)
	settings.Physics["Gravity"] = value
end

controls["Catching/Football Resize"] = function(settings, state, value)
	settings.Catching["BallResize"] = value
end

controls["Catching/Arm Size"] = function(settings, state, value)
	settings.Catching["ArmSize"] = value
end

controls["Misc/Endzone Zone"] = function(settings, state, value)
	state.endzoneZoneBox[6] = value
end

controls["Catching/Arm Resize"] = function(settings, state, value)
	settings.Catching["ArmResize"] = value
end

controls["Catching/Catch Size"] = function(settings, state, value)
	settings.Catching["HandSize"] = value
end

controls["Catching/Catch Resize"] = function(settings, state, value)
	settings.Catching["HandResize"] = value
end

controls["Catching/Fake Ball"] = function(settings, state, value)
	settings.Catching["FakeBall"] = value
end

controls["Catching/Dive Radius"] = function(settings, state, value)
	settings.Catching["DiveRadius"] = value
end

controls["Catching/Dive Vector"] = function(settings, state, value)
	settings.Catching["DiveVector"] = value
end

controls["Catching/Pull Tween Time"] = function(settings, state, value)
	settings.Catching["PullTweenTime"] = value
end

controls["Catching/Pull Radius"] = function(settings, state, value)
	settings.Catching["PullRadius"] = value
end

controls["Catching/Pull Vector"] = function(settings, state, value)
	settings.Catching["PullVector"] = value
end

controls["Catching/Swat Reach Distance"] = function(settings, state, value)
	settings.Catching["SwatRadius"] = value
end

controls["Catching/Swat Reach"] = function(settings, state, value)
	settings.Catching["SwatReach"] = value
end

controls["Physics/TP Distance"] = function(settings, state, value)
	settings.Physics["QuickTPDistance"] = value
end

controls["Catching/Freeze Tech Duration"] = function(settings, state, value)
	settings.Catching["FreezeDuration"] = value
end

controls["Catching/Freeze Tech"] = function(settings, state, value)
	settings.Catching["FreezeTech"] = value
end

controls["Physics/Gravity Value"] = function(settings, state, value)
	settings.Physics["GravityValue"] = value
end

controls["Physics/Click Tackle"] = function(settings, state, value)
	settings.Physics["ClickTackle"] = value
end

controls["Catching/Magnets Hitbox Color"] = function(settings, state, value)
	settings.Catching["HitboxColor"] = value
end

controls["Catching/Magnets Hitbox Shape"] = function(settings, state, value)
	settings.Catching["HitboxShape"] = value
end

controls["Catching/Visualize Magnets Hitbox"] = function(settings, state, value)
	settings.Catching["ShowHitbox"] = value
end

controls["Catching/Magnets Type"] = function(settings, state, value)
	settings.Catching["MagnetType"] = value
end

controls["Physics/Click Tackle Distance"] = function(settings, state, value)
	settings.Physics["ClickTackleDistance"] = value
end

controls["Catching/Magnets Mode"] = function(settings, state, value)
	settings.Catching["MagnetMode"] = value
end

controls["Catching/Magnets Delay"] = function(settings, state, value)
	settings.Catching["Delay"] = value
end

controls["Catching/Football Magnets"] = function(settings, state, value)
	settings.Catching["Magnets"] = value
end

controls["Visuals/Replay FPS"] = function(settings, state, value)
	settings.Visuals[0.28] = math.clamp(value, 30, 360)
end

controls["Visuals/Free Replay Camera"] = function(settings, state, value)
	settings.Visuals["ReplayCamera"] = value
end

controls["Visuals/Fog Color"] = function(settings, state, value)
	settings.Visuals["FogColor"] = value
end

controls["Visuals/Fog Distance"] = function(settings, state, value)
	settings.Visuals["FogDistance"] = value
end

controls["Visuals/Camera Zoom Unlock"] = function(settings, state, value)
	settings.Visuals["CameraZoom"] = value
end

controls["Visuals/Catch Effect Color"] = function(settings, state, value)
	settings.Visuals["CatchEffectColor"] = value
end

controls["Visuals/Catch Effects"] = function(settings, state, value)
	settings.Visuals["CatchEffects"] = value
end

controls["Visuals/Optimal Jump Color"] = function(settings, state, value)
	settings.Visuals["OptimalJumpColor"] = value
end

controls["Visuals/Trajectory Color"] = function(settings, state, value)
	settings.Visuals["TrajectoryColor"] = value
end

controls["Visuals/Path Color"] = function(settings, state, value)
	settings.Visuals["PathColor"] = value
end

controls["Visuals/Highlight Color"] = function(settings, state, value)
	settings.Visuals["HLColor"] = value
end

controls["Automatics/Guard Delay"] = function(settings, state, value)
	settings.Automatics["AutoGuardDelay"] = value
end

controls["Automatics/Auto Guard"] = function(settings, state, value)
	settings.Automatics["AutoGuard"] = value
end

controls["Automatics/Rush Delay"] = function(settings, state, value)
	state.autoRush["Delay"] = value
end

controls["Automatics/Rush Beam"] = function(settings, state, value)
	state.autoRush["ShowBeam"] = value
end

controls["Automatics/Auto Rush"] = function(settings, state, value)
	state.autoRush["Enabled"] = value
end

controls["Automatics/Kick Accuracy"] = function(settings, state, value)
	settings.Automatics["KickAccuracy"] = value
end

controls["Misc/Target"] = function(settings, state, value)
	state.targetBox[6] = value
end

controls["Automatics/Auto Kick"] = function(settings, state, value)
	settings.Automatics["AutoKick"] = value
end

controls["Automatics/Swat Radius"] = function(settings, state, value)
	settings.Automatics["AutoSwatRadius"] = value
end

controls["Physics/Auto Reel"] = function(settings, state, value)
	state.autoReel["on"] = value
end

controls["Automatics/Auto Swat"] = function(settings, state, value)
	settings.Automatics["AutoSwat"] = value
end

controls["Automatics/Catch Radius"] = function(settings, state, value)
	settings.Automatics["AutoCatchRadius"] = value
end

controls["Automatics/Auto Catch"] = function(settings, state, value)
	settings.Automatics["AutoCatch"] = value
end

controls["Misc/Or type name"] = function(settings, state, value)
	-- No application-state writes in the completed trace.
end

controls["Automatics/QB Type"] = function(settings, state, value)
	settings.Automatics["AutoQBType"] = value
end

controls["Automatics/Auto QB"] = function(settings, state, value)
	settings.Automatics["AutoQB"] = value
end

controls["Misc/Fling Target"] = function(settings, state, value)
	state.flingTargetBox[6] = value
end

return controls
