-- Decompiled with Potassium's decompiler.

return true, 41, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil;