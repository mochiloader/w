-- Decompiled with Potassium's decompiler.

if UNNAMED_2819735056856 > 15 then
    local v1 = UNNAMED_2819735062712[22](UNNAMED_2819735080376, UNNAMED_2819735028152);

    return v1 < 128 and 111 or 4, UNNAMED_2819735065016, v1;
end;

local v2 = UNNAMED_2819735059208[1];
local v3 = UNNAMED_2819735059208[2];
local v4 = UNNAMED_2819735059208[3] + v2;
local v5 = v2 <= 0;
local v6 = v3 <= v4;
UNNAMED_2819735059208[3] = v4;

if v5 and v6 and v6 or not v5 and v4 <= v3 then
    return 53, v4, UNNAMED_2819735043464;
end;

return 100, UNNAMED_2819735065016, UNNAMED_2819735043464;