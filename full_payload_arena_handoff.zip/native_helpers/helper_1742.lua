-- Decompiled with Potassium's decompiler.

local v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18, v19, v20, v21 = UNNAMED_2819735074808:n();

while v1 do
    if v2 <= 80 then
        if v2 <= 39 then
            if v2 <= 19 then
                if v2 <= 9 then
                    if v2 <= 4 then
                        if v2 <= 1 then
                            v2, v6, v14, v17 = UNNAMED_2819735074808:S(v6, v17, v16, v15, v14, UNNAMED_2819735039288, v2);
                        else
                            v2, v6, v7, v10, v19 = UNNAMED_2819735074808:f(v2, v6, v19, v11, v10, v7, UNNAMED_2819735039288, v12);
                        end;
                    else
                        v2, v3, v5, v6, v7, v8, v10, v11 = UNNAMED_2819735074808:k(v2, v5, v6, v3, v10, UNNAMED_2819735039288, v7, v11, v8, v12, v4);
                    end;
                elseif v2 <= 14 then
                    v2, UNNAMED_2819735039288, UNNAMED_2819735032232, v4, v6, v9, v11 = UNNAMED_2819735074808:X(v11, v9, UNNAMED_2819735032232, v5, v6, v4, v2, UNNAMED_2819735039288);
                elseif v2 <= 16 then
                    v2, v9, v18 = UNNAMED_2819735074808:r(v6, v3, UNNAMED_2819735039288, v2, v9, v18);
                else
                    v2, v6, v7, v11, v14 = UNNAMED_2819735074808:w(v11, v8, v2, v13, v6, v14, UNNAMED_2819735039288, v7, v12);
                end;
            elseif v2 <= 29 then
                if v2 <= 24 then
                    if v2 <= 21 then
                        v2, v8, v11 = UNNAMED_2819735074808:K(v2, v8, v6, UNNAMED_2819735039288, v3, v11);
                    else
                        v2, v3, v5, v6, v14 = UNNAMED_2819735074808:U(v2, v7, v6, v16, v14, v15, v5, UNNAMED_2819735039288, v3);
                    end;
                else
                    v2, v5, v6, v8, v13, v14 = UNNAMED_2819735074808:F(v10, v2, v8, v7, UNNAMED_2819735039288, v11, v4, v5, v13, v14, v6);
                end;
            elseif v2 <= 34 then
                v2, v3, UNNAMED_2819735032232, v4, v6, v7, v8, v9, v11 = UNNAMED_2819735074808:l(v6, v3, v8, v9, UNNAMED_2819735039288, UNNAMED_2819735032232, v4, v2, v10, v11, v7, v5);
            else
                v2, UNNAMED_2819735039288, v6, v8, v10, v17, v19 = UNNAMED_2819735074808:Y(v4, v2, v10, v8, v17, UNNAMED_2819735039288, v18, v6, v19);
            end;
        elseif v2 <= 59 then
            if v2 <= 49 then
                if v2 <= 44 then
                    if v2 <= 41 then
                        v2, UNNAMED_2819735039288, v6, v10, v21 = UNNAMED_2819735074808:m(v21, v10, UNNAMED_2819735039288, v11, v6, v2);
                    else
                        v2, v4, v5, v18 = UNNAMED_2819735074808:O(v3, v8, v4, v6, v18, v5, v2, UNNAMED_2819735039288);
                    end;
                else
                    v2, v6, v7, v9, v10, v11 = UNNAMED_2819735074808:v(v10, UNNAMED_2819735039288, v3, v7, v11, v9, v4, v6, v2);
                end;
            elseif v2 <= 54 then
                if v2 <= 51 then
                    v2, v6, v11 = UNNAMED_2819735074808:A(v12, v11, v6, UNNAMED_2819735039288, v2, v13);
                else
                    v2, v6, v7, v14 = UNNAMED_2819735074808:c(v2, UNNAMED_2819735039288, v5, v16, v14, v6, v15, v9, v7);
                end;
            elseif v2 <= 56 then
                local v22, v23, v24, v25 = UNNAMED_2819735074808:E(v9, UNNAMED_2819735039288, v4, v8, v2);

                if v22 == 1 then
                    v2 = v23;
                    UNNAMED_2819735039288 = v24;
                    v4 = v25;
                elseif v22 == 2 then
                    return UNNAMED_2819735032232, UNNAMED_2819735039288, v6;
                end;
            else
                v2, UNNAMED_2819735039288, v4, v8, v20 = UNNAMED_2819735074808:i(v3, v6, v9, v4, v8, v20, UNNAMED_2819735039288, v2, v10);
            end;
        elseif v2 <= 69 then
            if v2 <= 64 then
                v2, UNNAMED_2819735032232, v6, v8, v17, v19 = UNNAMED_2819735074808:y(v2, v17, v20, v5, v19, v18, v4, v6, UNNAMED_2819735039288, v8, v7, v9, UNNAMED_2819735032232);
            else
                v2, UNNAMED_2819735032232, v4, v6, v9, v13, v14, v18 = UNNAMED_2819735074808:s(v15, v14, v4, v18, v13, v6, v9, v5, UNNAMED_2819735039288, UNNAMED_2819735032232, v19, v2);
            end;
        elseif v2 <= 74 then
            if v2 <= 71 then
                v2, v6, v17, v20 = UNNAMED_2819735074808:M(v2, v18, v20, v17, v6, v19, UNNAMED_2819735039288);
            else
                v2, v4, v9, v12, v14 = UNNAMED_2819735074808:R(v4, v12, UNNAMED_2819735039288, v6, v2, v9, v14, v11, v10);
            end;
        elseif v2 <= 77 then
            v2, v5, v6, v14, v16 = UNNAMED_2819735074808:p(v15, v14, v16, v6, v5, v2, v3);
        else
            v2, v3, v4, v9, v19 = UNNAMED_2819735074808:j(v9, v6, v4, v19, v2, v3, UNNAMED_2819735039288, v10);
        end;
    elseif v2 <= 121 then
        if v2 <= 100 then
            if v2 <= 90 then
                if v2 <= 85 then
                    if v2 <= 82 then
                        v2, v3, v5, v16, v17 = UNNAMED_2819735074808:J(v5, v17, v3, v16, v2);
                    else
                        v2, v3, v6, v11, v12, v19 = UNNAMED_2819735074808:x(v20, v6, v19, v2, v11, UNNAMED_2819735039288, v21, v4, v3, v12);
                    end;
                else
                    v2, v6, v8, v9 = UNNAMED_2819735074808:T(v2, v9, v8, UNNAMED_2819735039288, v6);
                end;
            elseif v2 <= 95 then
                v2, v6, v10, v18, v19, v21 = UNNAMED_2819735074808:G(v21, v6, v10, v16, v2, v20, UNNAMED_2819735039288, v18, v19);
            else
                v2, v3, v4, v6, v7 = UNNAMED_2819735074808:_(v9, v7, v8, v6, v5, v2, v4, v3);
            end;
        elseif v2 <= 110 then
            if v2 <= 105 then
                v2, UNNAMED_2819735039288, v6, v7, v8, v15, v19 = UNNAMED_2819735074808:q(v19, v20, v15, v17, v21, v16, v14, v8, v6, v7, v2, UNNAMED_2819735039288);
            elseif v2 <= 107 then
                v2, v3, v6, v16 = UNNAMED_2819735074808:P(v6, v2, v17, v3, v16);
            else
                v2, v3, v6, v7, v16, v18 = UNNAMED_2819735074808:N(v17, v7, v19, v6, v16, v3, v20, UNNAMED_2819735039288, v2, v18);
            end;
        elseif v2 <= 115 then
            v2, v4, v6, v16, v18 = UNNAMED_2819735074808:V(v6, v4, UNNAMED_2819735039288, v16, v2, v18);
        else
            v2, v3, v4, v5, v6, v13, v16, v17 = UNNAMED_2819735074808:t(v17, v3, v16, v5, v4, v13, UNNAMED_2819735039288, v6, v2);
        end;
    elseif v2 <= 141 then
        if v2 <= 131 then
            if v2 <= 126 then
                v2, v4, v5, v6, v9, v12 = UNNAMED_2819735074808:L(UNNAMED_2819735039288, v4, v11, v6, v5, v2, v9, v10, v12);
            else
                v2, v3, v6, v8, v12, v14, v15, v16 = UNNAMED_2819735074808:z(v9, v2 <= 128, v12, v6, v2, v14, v8, v16, v10, v3, v15, UNNAMED_2819735039288);
            end;
        elseif v2 <= 136 then
            v2, v3, v6, v11, v15, v16 = UNNAMED_2819735074808:Z(v16, v3, v15, v12, v17, UNNAMED_2819735039288, v18, v2, v6, v11);
        else
            v2, UNNAMED_2819735039288, v4, v6, v11 = UNNAMED_2819735074808:C(v5, v4, v19, UNNAMED_2819735039288, v13, v20, v12, v11, v6, v2);
        end;
    elseif v2 <= 151 then
        if v2 <= 146 then
            if v2 <= 143 then
                v2, v4, v5, v13 = UNNAMED_2819735074808:h(v6, v5, v8, v4, v2, v3, v13);
            else
                v2, UNNAMED_2819735039288, UNNAMED_2819735032232, v6, v13, v14 = UNNAMED_2819735074808:o(v10, v8, v15, v14, v11, UNNAMED_2819735032232, v7, v5, v2, v17, v16, v9, v18, v12, v6, UNNAMED_2819735039288, v4, v13);
            end;
        else
            v2, v3, v6, v7, v15 = UNNAMED_2819735074808:e(v9, v2, v5, v3, v8, v15, v7, UNNAMED_2819735039288, v6);
        end;
    elseif v2 <= 156 then
        v2, UNNAMED_2819735039288, v4, v6, v18, v20 = UNNAMED_2819735074808:u(v14, v4, v20, v2, v19, v13, v11, v18, UNNAMED_2819735039288, v8, v6);
    else
        v2, v3, UNNAMED_2819735039288, v5, v6, v10, v13 = UNNAMED_2819735074808:B(UNNAMED_2819735039288, v5, v14, v2, v3, v4, v13, v10, v6);
    end;
end;