-- Decompiled with Potassium's decompiler.

local v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12 = UNNAMED_2819735085416:HF();

while v1 do
    if v2 <= 15 then
        if v2 <= 7 then
            if v2 <= 3 then
                v2, v3, v5, v6, v10 = UNNAMED_2819735085416:gF(UNNAMED_2819735088296, v2, v10, v8, v5, v3, v11, v6, v7, v9);
            else
                v2, UNNAMED_2819735086616, UNNAMED_2819735088296, v5, v6 = UNNAMED_2819735085416:IF(v6, v8, UNNAMED_2819735088296, v9, v12, v2, v5, v4, v10, v7, UNNAMED_2819735086616);
            end;
        elseif v2 <= 11 then
            if v2 <= 9 then
                v2, UNNAMED_2819735088296, v6, v7 = UNNAMED_2819735085416:aF(v7, v9, v10, v8, v6, v2, UNNAMED_2819735088296);
            else
                v2, v3, UNNAMED_2819735073368, UNNAMED_2819735086616, UNNAMED_2819735088296, v6, v7, v8, v9, v10, v11 = UNNAMED_2819735085416:WF(v2, v3, v7, v11, v10, UNNAMED_2819735073368, UNNAMED_2819735086616, v8, UNNAMED_2819735088296, v6, v9);
            end;
        else
            v2, UNNAMED_2819735088296, v6, v7 = UNNAMED_2819735085416:bF(v8, v10, UNNAMED_2819735088296, v2, v6, v3, v7);
        end;
    elseif v2 <= 23 then
        if v2 <= 19 then
            v2, UNNAMED_2819735088296, v4, v5, v6, v7, v12 = UNNAMED_2819735085416:dF(v4, v2, v8, UNNAMED_2819735073368, v3, UNNAMED_2819735086616, v5, v12, v6, UNNAMED_2819735088296, v7);
        else
            local v13, v14, v15, v16, v17 = UNNAMED_2819735085416:DF(UNNAMED_2819735088296, v2, v7, v9, v6, v8);

            if v13 == 1 then
                v2 = v14;
                v6 = v16;
                UNNAMED_2819735088296 = v15;
                v7 = v17;
            elseif v13 == 2 then
                return UNNAMED_2819735073368, UNNAMED_2819735086616;
            end;
        end;
    elseif v2 <= 27 then
        v2, v3, v8 = UNNAMED_2819735085416:QF(v2, v9, v8, v7, v6, v4, v5, UNNAMED_2819735088296, v3);
    else
        v2, UNNAMED_2819735086616, UNNAMED_2819735088296, v8 = UNNAMED_2819735085416:nF(v4, v9, UNNAMED_2819735086616, v7, UNNAMED_2819735088296, v6, v2, v8, v5);
    end;
end;