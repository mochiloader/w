-- Decompiled with Potassium's decompiler.

if UNNAMED_2819735073656 then
    local v1 = nil;

    for i = 3, UNNAMED_2819735037752 do
        v1 = { UNNAMED_2819735089976(UNNAMED_2819735060840, function() -- Line: 60
                -- upvalues: UNNAMED_2819735074040 (ref)
                for i2 = 1, UNNAMED_2819735074040 do
                    local _ = i2;
                end;
            end) };
        local _ = i;
    end;

    return v1[3];
end;