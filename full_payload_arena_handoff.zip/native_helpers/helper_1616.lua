-- Decompiled with Potassium's decompiler.

return function(p1, p2) -- Line: 3
    -- upvalues: UNNAMED_2819735066408 (copy)
    local u3 = p2[1];
    local u4 = p2[2];

    return function(p5, p6, p7) -- Line: 3
        -- upvalues: UNNAMED_2819735066408 (ref), u3 (copy), u4 (copy)
        local v8 = 17;
        local v9 = nil;
        local v10 = nil;
        local v11 = nil;
        local v12 = nil;
        local v13 = nil;
        local v14 = nil;
        local v15 = nil;
        local v16 = nil;
        local v17 = nil;
        local v18 = nil;

        while true do
            while v8 <= 14 do
                if v8 <= 6 then
                    if v8 <= 2 then
                        if v8 <= 0 then
                            local v19 = UNNAMED_2819735066408[22](v9, p7 + 3);
                            v10 = (v10 - 128) * 16384 + (v11 - 128) * 128 + (v12 - 128) + v19 % 128 * 2097152 + (v19 - v19 % 128) * 2097152;
                            p7 = p7 + 4;
                            v8 = 26;
                        elseif v8 <= 1 then
                            v10 = v10 - 128 + v11 * 128;
                            v13 = v13 + 2;
                            v8 = 11;
                        else
                            local v20 = UNNAMED_2819735066408[22](v9, p7 + 3);
                            v11 = (v11 - 128) * 16384 + (v12 - 128) * 128 + (v14 - 128) + v20 % 128 * 2097152 + (v20 - v20 % 128) * 2097152;
                            p7 = p7 + 4;
                            v8 = 9;
                        end;
                    elseif v8 <= 4 then
                        if v8 <= 3 then
                            local v21 = v15[2];
                            local v22 = v15[3];
                            local v23 = v15[5] + v21;
                            local v24 = v21 <= 0;
                            local v25 = v22 <= v23;
                            v15[5] = v23;

                            if v24 and v25 and v25 or not v24 and v23 <= v22 then
                                v17 = v23;
                                v8 = 6;
                            else
                                v8 = 16;
                            end;
                        else
                            p6 = (v11 * p6 + v12) % 256;
                            UNNAMED_2819735066408[93](v9, v10, (UNNAMED_2819735066408[11](UNNAMED_2819735066408[22](v16, v13 + v10), p7, p6)));
                            v8 = 14;
                        end;
                    elseif v8 <= 5 then
                        local v26 = UNNAMED_2819735066408[22](v16, v13 + 3);
                        v10 = (v10 - 128) * 16384 + (v11 - 128) * 128 + (v12 - 128) + v26 % 128 * 2097152 + (v26 - v26 % 128) * 2097152;
                        v13 = v13 + 4;
                        v8 = 11;
                    else
                        local v27 = UNNAMED_2819735066408[105];
                        local v28 = UNNAMED_2819735066408[5](v16, v13 + v17);
                        v27(v9, v17, (UNNAMED_2819735066408[11](v28, u3[5][u3[4]][p6], v14)));
                        p6 = u4[5][u4[4]][p6];
                        v8 = 3;
                    end;
                elseif v8 <= 10 then
                    if v8 <= 8 then
                        if v8 > 7 then
                            return p5, p6;
                        end;

                        v10 = v10 - 128 + (v11 - 128) * 16384 + v12 * 128;
                        v13 = v13 + 3;
                        v8 = 11;
                    elseif v8 <= 9 then
                        local v29 = UNNAMED_2819735066408[22](v9, p7);
                        local _ = p7 + 1;
                        UNNAMED_2819735066408[25](v16, v13 + v10, v29, v11);
                        v8 = 8;
                    else
                        v11 = v11 - 128 + (v12 - 128) * 16384 + v14 * 128;
                        p7 = p7 + 3;
                        v8 = 9;
                    end;
                elseif v8 <= 12 then
                    if v8 <= 11 then
                        p6 = (p7 + p6) % 256;
                        v9 = UNNAMED_2819735066408[4](v10);
                        v14 = p7 * 16843009;
                        v18 = v10 - v10 % 4;
                        v15 = {
                            v15,
                            4,
                            v18 - 1 + 0,
                            nil,
                            -4
                        };
                        v8 = 3;
                        v11 = 41;
                        v12 = 135;
                    else
                        v8 = v14 < 128 and 10 or 2;
                    end;
                elseif v8 <= 13 then
                    v15 = v15[1];
                    p5[6] = UNNAMED_2819735066408[28](p5);
                    p5, p6, p7 = UNNAMED_2819735066408:T3(p5, v9);
                    v10 = UNNAMED_2819735066408[22](v9, p7);
                    v8 = v10 < 128 and 20 or 25;
                else
                    local v30 = v15[5];
                    local v31 = v15[4];
                    local v32 = v15[3] + v30;
                    local v33 = v30 <= 0;
                    local v34 = v31 <= v32;
                    v15[3] = v32;

                    if v33 and v34 and v34 or not v33 and v32 <= v31 then
                        v10 = v32;
                        v8 = 4;
                    else
                        v8 = 13;
                    end;
                end;
            end;

            if v8 <= 22 then
                if v8 <= 18 then
                    if v8 <= 16 then
                        if v8 <= 15 then
                            v11 = v11 - 128 + v12 * 128;
                            p7 = p7 + 2;
                            v8 = 9;
                        else
                            v15 = v15[1];
                            v8 = 19;
                        end;
                    elseif v8 <= 17 then
                        v16 = p5[4];
                        v13 = p5[5][p6] + 1;
                        v10 = UNNAMED_2819735066408[22](v16, v13);
                        v8 = v10 < 128 and 21 or 29;
                    else
                        v10 = v10 - 128 + (v11 - 128) * 16384 + v12 * 128;
                        p7 = p7 + 3;
                        v8 = 26;
                    end;
                elseif v8 <= 20 then
                    if v8 <= 19 then
                        v15 = {
                            v15,
                            nil,
                            v18 - 1,
                            v10 - 1 + 0,
                            1
                        };
                        v8 = 14;
                    else
                        p7 = p7 + 1;
                        v8 = 26;
                    end;
                elseif v8 <= 21 then
                    v13 = v13 + 1;
                    v8 = 11;
                else
                    v10 = v10 - 128 + v11 * 128;
                    p7 = p7 + 2;
                    v8 = 26;
                end;
            elseif v8 <= 26 then
                if v8 <= 24 then
                    if v8 <= 23 then
                        v12 = UNNAMED_2819735066408[22](v9, p7 + 2);
                        v8 = v12 < 128 and 18 or 0;
                    else
                        v14 = UNNAMED_2819735066408[22](v9, p7 + 2);
                        v8 = 12;
                    end;
                elseif v8 <= 25 then
                    v11 = UNNAMED_2819735066408[22](v9, p7 + 1);
                    v8 = v11 < 128 and 22 or 23;
                else
                    v11 = UNNAMED_2819735066408[22](v9, p7);
                    v8 = v11 < 128 and 30 or 28;
                end;
            elseif v8 <= 28 then
                if v8 <= 27 then
                    v12 = UNNAMED_2819735066408[22](v16, v13 + 2);
                    v8 = v12 < 128 and 7 or 5;
                else
                    v12 = UNNAMED_2819735066408[22](v9, p7 + 1);
                    v8 = v12 < 128 and 15 or 24;
                end;
            elseif v8 <= 29 then
                v11 = UNNAMED_2819735066408[22](v16, v13 + 1);
                v8 = v11 < 128 and 1 or 27;
            else
                p7 = p7 + 1;
                v8 = 9;
            end;
        end;
    end;
end;