-- Decompiled with Potassium's decompiler.

return function(u1, p2) -- Line: 3
    local u3 = u1[1];

    return function() -- Line: 3
        -- upvalues: u3 (copy), u1 (copy)
        u3(function() -- Line: 3
            -- upvalues: u1 (ref)
            u1[2][5][u1[2][4]]();
        end, function() -- Line: 3
            -- upvalues: u1 (ref)
            u1[5][5][u1[5][4]] = u1[3](u1[4]);
        end);
    end;
end;