-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735059448;
local u2 = UNNAMED_2819735073560;
local u3 = UNNAMED_2819735037704;
local u4 = UNNAMED_2819735073080;
local u5 = UNNAMED_2819735044856;
local u6 = UNNAMED_2819735089256;
local u7 = UNNAMED_2819735031464;
local u8 = UNNAMED_2819735080136;
local u9 = UNNAMED_2819735074952;
local u10 = UNNAMED_2819735031032;
local u11 = UNNAMED_2819735079704;
local u12 = UNNAMED_2819735076248;
local u13 = UNNAMED_2819735080424;
local u14 = UNNAMED_2819735077112;
local u15 = UNNAMED_2819735045144;
local u16 = UNNAMED_2819735057240;
local u17 = UNNAMED_2819735050952;
local u18 = UNNAMED_2819735048408;
local u19 = UNNAMED_2819735063384;
local u20 = UNNAMED_2819735050904;
local u21 = UNNAMED_2819735075480;

return function(...) -- Line: 313
    -- upvalues: UNNAMED_2819769586696 (copy), UNNAMED_2819769586792 (copy), u1 (copy), UNNAMED_2819735060216 (ref), UNNAMED_2819735066888 (ref), UNNAMED_2819735090360 (ref), u5 (copy), u8 (copy), u3 (copy), u4 (copy), u6 (copy), u7 (copy), u9 (copy), u10 (copy), u11 (copy), u12 (copy), u13 (copy), u14 (copy), u15 (copy), u16 (copy), u17 (copy), u18 (copy), u19 (copy), u20 (copy), u2 (copy), UNNAMED_2819735069192 (ref), UNNAMED_2819735036840 (ref), UNNAMED_2819735072456 (ref), UNNAMED_2819735050040 (ref), UNNAMED_2819735067512 (ref), UNNAMED_2819735036168 (ref), UNNAMED_2819769586744 (copy), UNNAMED_2819735043176 (ref), UNNAMED_2819735071256 (ref), UNNAMED_2819735031272 (ref), UNNAMED_2819735032328 (ref), u21 (copy), UNNAMED_2819735075336 (ref)
    local u22 = UNNAMED_2819769586696;
    local u23 = UNNAMED_2819769586792;
    local u24 = u1;
    local u25 = u24(UNNAMED_2819735060216);
    local u26 = UNNAMED_2819735066888;
    local u27 = UNNAMED_2819735090360;
    local u28 = nil;
    local u29 = nil;
    local u30 = nil;
    local u31 = nil;
    local u32 = nil;
    local u33 = nil;
    local u34 = nil;
    local u35 = u5;
    local u36 = u8;
    local u37 = u3;
    local u38 = u4;
    local u39 = u6;
    local u40 = u7;
    local u41 = u9;
    local u42 = u10;
    local u43 = u11;
    local u44 = u12;
    local u45 = u13;
    local u46 = u14;
    local u47 = u15;
    local u48 = u16;
    local u49 = u17;
    local u50 = u18;
    local u51 = u19;
    local u52 = u20;
    local v1062, v1063, v1064, v1065, v1066 = u2(function(...) -- Line: 3
        -- upvalues: u27 (ref), UNNAMED_2819735069192 (ref), u26 (ref), u25 (copy), UNNAMED_2819735036840 (ref), UNNAMED_2819735072456 (ref), UNNAMED_2819735050040 (ref), u37 (copy), u38 (copy), u35 (copy), UNNAMED_2819735067512 (ref), u39 (copy), u40 (copy), UNNAMED_2819735036168 (ref), UNNAMED_2819769586744 (ref), u33 (ref), u34 (ref), u36 (copy), u24 (copy), u42 (copy), u22 (ref), u41 (copy), u43 (copy), UNNAMED_2819735043176 (ref), u29 (ref), u28 (ref), u30 (ref), u31 (ref), u32 (ref), UNNAMED_2819735071256 (ref), u23 (ref), u44 (copy), u45 (copy), u46 (copy), u47 (copy), u48 (copy), UNNAMED_2819735031272 (ref), u49 (copy), u50 (copy), u51 (copy), u52 (copy), UNNAMED_2819735032328 (ref)
        local v53, v54, v55, v56, v57, v58;
        local u27, v53, v54, v55, v56, v57, v58, u28, u22, u34, u29, u23, u31, u32, u30, u26, u33;
        local v59 = 0;

        while true do
            if v59 == 0 then
                v59 = -1;
                v53 = nil;
                v54 = nil;
                v55 = nil;
                v56 = nil;
                v57 = nil;
                v58 = nil;

                if u27 ~= 113 then
                    v59 = 1;
                    continue;
                end;

                v59 = 6;
                continue;
            elseif v59 == 1 then
                v59 = -1;

                if u27 ~= 127 then
                    v59 = 2;
                    continue;
                end;

                v59 = 5;
                continue;
            elseif v59 == 2 then
                v59 = -1;

                if u27 ~= 240 then
                    v59 = 3;
                    continue;
                end;

                v59 = 4;
                continue;
            elseif v59 == 3 then
                v59 = -1;

                if u27 ~= 31 then
                    return;
                end;

                while true do
                    local v60 = UNNAMED_2819735050040[u26];

                    if v60 < 95 then
                        if v60 < 47 then
                            if v60 < 23 then
                                if v60 < 11 then
                                    if v60 < 5 then
                                        if v60 >= 2 then
                                            if v60 < 3 then
                                                v57 = UNNAMED_2819735036840[u26];
                                                local v61 = UNNAMED_2819735072456[u26];
                                                u25[v57] = UNNAMED_2819735032328[u26];
                                                u25[v57 + 1] = v61;
                                            elseif v60 == 4 then
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] // u25[UNNAMED_2819735069192[u26]];
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]];
                                                v57 = UNNAMED_2819735072456[u26 + 1];
                                                v55 = UNNAMED_2819735069192[u26 + 1];
                                                v53 = UNNAMED_2819735036840[u26 + 1];
                                                v56 = v57 + v53 - 1;
                                                v54 = v57 + v55;
                                                v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                                u37(v58, 1, v53, v57, u25);
                                                u26 = u26 + 1;
                                            end;
                                        elseif v60 == 1 then
                                            if u25[UNNAMED_2819735036840[u26]] ~= u25[UNNAMED_2819735069192[u26]] then
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735069192[u26]]] = UNNAMED_2819735072456[u26];
                                        end;
                                    elseif v60 >= 8 then
                                        if v60 >= 9 then
                                            if v60 == 10 then
                                                u29 = u29 + u31;

                                                if u31 <= 0 then
                                                    v57 = u30 <= u29;
                                                else
                                                    v57 = u29 <= u30;
                                                end;

                                                if v57 then
                                                    u25[UNNAMED_2819735072456[u26]] = u29;
                                                    u26 = UNNAMED_2819735069192[u26];
                                                else
                                                    u26 = UNNAMED_2819735036840[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735036168[u26] * UNNAMED_2819735032328[u26];
                                            end;
                                        else
                                            v57 = UNNAMED_2819735072456[u26];
                                            v55 = UNNAMED_2819735069192[u26];
                                            v53 = UNNAMED_2819735036840[u26];
                                            v56 = v57 + v53 - 1;
                                            v54 = v57 + v55;
                                            v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                            u37(v58, 1, v53, v57, u25);
                                        end;
                                    elseif v60 >= 6 then
                                        if v60 == 7 then
                                            v57 = UNNAMED_2819735069192[u26];
                                            local v62 = u25[UNNAMED_2819735072456[u26]];
                                            u25[v57] = u25[UNNAMED_2819735036840[u26]];
                                            u25[v57 + 1] = v62;
                                        elseif UNNAMED_2819735072456[u26] > u25[UNNAMED_2819735036840[u26]] then
                                            u26 = UNNAMED_2819735069192[u26];
                                        end;
                                    else
                                        u45[UNNAMED_2819735067512[u26]][UNNAMED_2819735032328[u26]] = u25[UNNAMED_2819735072456[u26]];
                                    end;
                                elseif v60 < 17 then
                                    if v60 >= 14 then
                                        if v60 < 15 then
                                            local v63 = u33;
                                            local v64 = u34;

                                            if v63 then
                                                for i in u36, v63 do
                                                    local v65 = v63[i];

                                                    if v65 then
                                                        v65[5] = v65;
                                                        v65[6] = u25[i];
                                                        v65[4] = 6;
                                                        v63[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v64 then
                                                for i, v in u36, v64 do
                                                    local v66 = v[6];

                                                    if v64 then
                                                        local v67 = v64[i];

                                                        if v67 then
                                                            local v68 = u24(v66);
                                                            u37(u25, i, i + v66 - 1, 1, v68);
                                                            v67[5] = v68;
                                                            v67[4] = 1;
                                                            v64[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(u25[UNNAMED_2819735069192[u26]], u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                                        end;

                                        if v60 ~= 16 and u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735067512[u26] then
                                            u26 = UNNAMED_2819735069192[u26];
                                        end;
                                    elseif v60 >= 12 then
                                        if v60 == 13 then
                                            u25[UNNAMED_2819735072456[u26]] = #u25[UNNAMED_2819735069192[u26]];
                                        else
                                            local v69 = UNNAMED_2819735036840[u26];
                                            local v70 = UNNAMED_2819735032328[u26];
                                            local v71 = u42(UNNAMED_2819735072456[u26], 4294967295);
                                            local v72 = u42(v70, 4294967295);
                                            local v73 = u42(v71, 65535);
                                            local v74 = u41(v71, 16);
                                            local v75 = u42(v72, 65535);
                                            local v76 = u41(v72, 16);
                                            local v77 = u42(v73 * v75 + u43(u42(v73 * v76 + v74 * v75, 65535), 16), 4294967295) % 4294967296;
                                            u25[v69] = v77 ~= v77 and 0 or v77 - v77 % 1;
                                        end;
                                    else
                                        v57 = UNNAMED_2819735069192[u26];
                                        v55, v53 = u29();

                                        if v55 then
                                            u25[v57] = v53;
                                            u26 = UNNAMED_2819735072456[u26];
                                        else
                                            u26 = UNNAMED_2819735036840[u26];
                                        end;
                                    end;
                                elseif v60 < 20 then
                                    if v60 < 18 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] - u25[UNNAMED_2819735069192[u26]];
                                    elseif v60 == 19 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] ~= u25[UNNAMED_2819735036840[u26]];
                                    else
                                        v57 = UNNAMED_2819735069192[u26];
                                        v55 = UNNAMED_2819735072456[u26];
                                        v53 = UNNAMED_2819735036840[u26];
                                        v56 = v57 + v55;
                                        u25[v57] = u38(u25[v57](u35(u25, v57 + 1, v56)));
                                    end;
                                elseif v60 >= 21 then
                                    if v60 == 22 then
                                        u25[UNNAMED_2819735072456[u26]] = {};
                                    else
                                        local v78 = UNNAMED_2819735036840[u26];
                                        local v79 = u25[UNNAMED_2819735072456[u26]];
                                        local v80 = u42(UNNAMED_2819735032328[u26], 4294967295);
                                        local v81 = u42(v79, 4294967295);
                                        local v82 = u42(v80, 65535);
                                        local v83 = u41(v80, 16);
                                        local v84 = u42(v81, 65535);
                                        local v85 = u41(v81, 16);
                                        local v86 = u42(v82 * v84 + u43(u42(v82 * v85 + v83 * v84, 65535), 16), 4294967295) % 4294967296;
                                        u25[v78] = v86 ~= v86 and 0 or v86 - v86 % 1;
                                    end;
                                else
                                    v57 = UNNAMED_2819735069192[u26];
                                    v55 = u39(u22, u42(u41(u22, 14), 262143), (u42(u41(u22, 28), 15)));
                                    v53 = UNNAMED_2819735036840[u26];
                                    v56 = UNNAMED_2819735072456[u26];
                                    v54 = v53 < 2097152 and 7 or 14;
                                    v58 = u42(v53, u43(1, v54) - 1);
                                    UNNAMED_2819735050040[u26] = u39(u41(v53, v54), 55, (u42(u41(v55, 21), 127)));
                                    UNNAMED_2819735069192[u26] = u39(v57, 33, (u42(v55, 127)));
                                    UNNAMED_2819735072456[u26] = u39(v56, 2, (u42(u41(v55, 7), 127)));
                                    UNNAMED_2819735036840[u26] = u39(v58, 53, (u42(u41(v55, 14), 127)));
                                    u26 = u26 - 1;
                                end;
                            elseif v60 >= 35 then
                                if v60 >= 41 then
                                    if v60 < 44 then
                                        if v60 < 42 then
                                            u45[UNNAMED_2819735036168[u26]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735032328[u26];
                                        elseif v60 == 43 then
                                            local v87 = UNNAMED_2819735069192[u26];
                                            local v88 = u25[UNNAMED_2819735072456[u26]];
                                            local v89 = u42(u25[UNNAMED_2819735036840[u26]], 4294967295);
                                            local v90 = u42(v88, 4294967295);
                                            local v91 = u42(v89, 65535);
                                            local v92 = u41(v89, 16);
                                            local v93 = u42(v90, 65535);
                                            local v94 = u41(v90, 16);
                                            local v95 = u42(v91 * v93 + u43(u42(v91 * v94 + v92 * v93, 65535), 16), 4294967295) % 4294967296;
                                            u25[v87] = v95 ~= v95 and 0 or v95 - v95 % 1;
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = u42(u25[UNNAMED_2819735069192[u26]], u25[UNNAMED_2819735072456[u26]]);
                                        end;
                                    else
                                        if v60 < 45 then
                                            local v96 = u33;
                                            local v97 = u34;

                                            if v96 then
                                                for i in u36, v96 do
                                                    local v98 = v96[i];

                                                    if v98 then
                                                        v98[5] = v98;
                                                        v98[6] = u25[i];
                                                        v98[4] = 6;
                                                        v96[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v97 then
                                                for i, v in u36, v97 do
                                                    local v99 = v[6];

                                                    if v97 then
                                                        local v100 = v97[i];

                                                        if v100 then
                                                            local v101 = u24(v99);
                                                            u37(u25, i, i + v99 - 1, 1, v101);
                                                            v100[5] = v101;
                                                            v100[4] = 1;
                                                            v97[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(u25[UNNAMED_2819735036840[u26]]);
                                        end;

                                        if v60 == 46 then
                                            u25[UNNAMED_2819735069192[u26]]();
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] ~= UNNAMED_2819735069192[u26];
                                        end;
                                    end;
                                elseif v60 < 38 then
                                    if v60 < 36 then
                                        u25[UNNAMED_2819735072456[u26]] = u42(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735036840[u26]);
                                    elseif v60 == 37 then
                                        if u33 then
                                            local v102 = u33;
                                            local v103 = UNNAMED_2819735036840[u26];
                                            local v104 = v102[v103];

                                            if v104 then
                                                v104[5] = v104;
                                                v104[6] = u25[v103];
                                                v104[4] = 6;
                                                v102[v103] = nil;
                                            end;

                                            local v105 = u33;
                                            local v106 = UNNAMED_2819735069192[u26];
                                            local v107 = v105[v106];

                                            if v107 then
                                                v107[5] = v107;
                                                v107[6] = u25[v106];
                                                v107[4] = 6;
                                                v105[v106] = nil;
                                            end;

                                            local v108 = u33;
                                            local v109 = UNNAMED_2819735072456[u26];
                                            local v110 = v108[v109];

                                            if v110 then
                                                v110[5] = v110;
                                                v110[6] = u25[v109];
                                                v110[4] = 6;
                                                v108[v109] = nil;
                                            end;
                                        end;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735032328[u26]];
                                    end;
                                elseif v60 < 39 then
                                    v57 = UNNAMED_2819735072456[u26];
                                    v55 = UNNAMED_2819735036840[u26];
                                    v53 = UNNAMED_2819735069192[u26];
                                    v56 = u25[v57];
                                    u37(u25, v57 + 1, v57 + v55, v53 + 1, v56);
                                elseif v60 == 40 then
                                    u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735072456[u26]]];
                                else
                                    u25[UNNAMED_2819735072456[u26]] = u39(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735032328[u26]);
                                end;
                            elseif v60 >= 29 then
                                if v60 >= 32 then
                                    if v60 < 33 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] // UNNAMED_2819735036840[u26];
                                    elseif v60 == 34 then
                                        v57 = UNNAMED_2819735072456[u26];
                                        v55, v53, v56 = u29();

                                        if v55 then
                                            u25[v57] = v53;
                                            u25[v57 + 1] = v56;
                                            u26 = UNNAMED_2819735069192[u26];
                                        else
                                            u26 = UNNAMED_2819735036840[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735067512[u26]] = u25[UNNAMED_2819735069192[u26]];
                                    end;
                                else
                                    if v60 >= 30 then
                                        if v60 ~= 31 then
                                            local v111 = u33;
                                            local v112 = u34;

                                            if v111 then
                                                for i in u36, v111 do
                                                    local v113 = v111[i];

                                                    if v113 then
                                                        v113[5] = v113;
                                                        v113[6] = u25[i];
                                                        v113[4] = 6;
                                                        v111[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v112 then
                                                for i, v in u36, v112 do
                                                    local v114 = v[6];

                                                    if v112 then
                                                        local v115 = v112[i];

                                                        if v115 then
                                                            local v116 = u24(v114);
                                                            u37(u25, i, i + v114 - 1, 1, v116);
                                                            v115[5] = v116;
                                                            v115[4] = 1;
                                                            v112[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, false;
                                        end;

                                        local v117 = UNNAMED_2819735072456[u26];
                                        local v118 = UNNAMED_2819735036840[u26];
                                        local v119 = v117 + v118;
                                        local v120 = u25[v119];
                                        local n = v120.n;
                                        local v121 = u33;
                                        local v122 = u34;

                                        if v121 then
                                            for i in u36, v121 do
                                                local v123 = v121[i];

                                                if v123 then
                                                    v123[5] = v123;
                                                    v123[6] = u25[i];
                                                    v123[4] = 6;
                                                    v121[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v122 then
                                            for i, v in u36, v122 do
                                                local v124 = v[6];

                                                if v122 then
                                                    local v125 = v122[i];

                                                    if v125 then
                                                        local v126 = u24(v124);
                                                        u37(u25, i, i + v124 - 1, 1, v126);
                                                        v125[5] = v126;
                                                        v125[4] = 1;
                                                        v122[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        v120.n = v118 + n - 1;
                                        u37(v120, 1, n, v118, v120);
                                        u37(u25, v117 + 1, v119 - 1, 1, v120);

                                        return true, true, v117, v120;
                                    end;

                                    u25[UNNAMED_2819735069192[u26]] = u39(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735072456[u26]);
                                end;
                            elseif v60 < 26 then
                                if v60 < 24 then
                                    u23 = u25[UNNAMED_2819735036840[u26]];
                                elseif v60 == 25 then
                                    UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735032328[u26];
                                else
                                    u45[UNNAMED_2819735067512[u26]] = UNNAMED_2819735036168[u26];
                                end;
                            elseif v60 < 27 then
                                local v127 = nil;
                                local v128 = UNNAMED_2819735072456[u26];
                                local v129 = UNNAMED_2819735067512[u26];
                                local v130 = UNNAMED_2819735032328[u26];
                                local v131 = u33;
                                local v132 = u34;
                                local v133 = v130[0];

                                if v133 then
                                    local v134 = #v133 / 3;

                                    if v134 > 0 then
                                        v127 = {};

                                        for i = 1, v134 do
                                            local v135 = (i - 1) * 3;
                                            local v136 = v133[v135 + 2];
                                            local v137 = v133[v135 + 1];
                                            local v138;

                                            if v136 == 2 then
                                                v131 = v131 or {};
                                                local v139 = v131[v137];

                                                if not v139 then
                                                    v139 = {
                                                        [5] = u25,
                                                        [4] = v137
                                                    };
                                                    v131[v137] = v139;
                                                end;

                                                v127[i] = v139;
                                                v138 = i;
                                            elseif v136 == 0 then
                                                v127[i] = u25[v137];
                                                v138 = i;
                                            elseif v136 == 3 then
                                                v127[i] = UNNAMED_2819769586744[v137];
                                                v138 = i;
                                            elseif v136 == 1 then
                                                v132 = v132 or {};
                                                local v140 = v132[v137];

                                                if not v140 then
                                                    v140 = {
                                                        [5] = u25,
                                                        [4] = v137,
                                                        [6] = v133[v135 + 3]
                                                    };
                                                    v132[v137] = v140;
                                                end;

                                                v127[i] = v140;
                                                v138 = i;
                                            else
                                                v138 = i;
                                            end;
                                        end;
                                    end;
                                end;

                                local v141 = v130[-2];
                                v130[v141] = v127;
                                local v142 = v129(u35(v130, 1, v130[-1]));
                                v130[v141] = nil;
                                u25[v128] = v142;
                                u33 = v131;
                                u34 = v132;
                            elseif v60 == 28 then
                                v57 = UNNAMED_2819735072456[u26];
                                v55 = UNNAMED_2819735069192[u26];
                                v53 = UNNAMED_2819735036840[u26];
                                v56 = u25[v57];
                                v54 = v57 + v55;
                                v58 = u25[v54];
                                u37(u25, v57 + 1, v54 - 1, v53 + 1, v56);
                                u37(v58, 1, v58.n, v53 + v55, v56);
                            else
                                u25[UNNAMED_2819735069192[u26]] = u40(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735067512[u26]);
                            end;
                        elseif v60 < 71 then
                            if v60 < 59 then
                                if v60 >= 53 then
                                    if v60 < 56 then
                                        if v60 < 54 then
                                            u25[UNNAMED_2819735036840[u26]](UNNAMED_2819735032328[u26]);
                                        elseif v60 == 55 then
                                            if u25[UNNAMED_2819735036840[u26]] >= UNNAMED_2819735072456[u26] then
                                                u26 = UNNAMED_2819735069192[u26];
                                            end;
                                        else
                                            v57 = UNNAMED_2819735036840[u26] + 1;
                                            v55 = UNNAMED_2819735072456[u26];

                                            for i = 1, UNNAMED_2819735069192[u26] do
                                                local v143 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                local v144 = u39(v143, (u41(v143, 13)));
                                                v55 = u42(u39(v144, (u43(v144, 14))), 536870911);
                                                UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                                UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                                UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 14), 127)));
                                                UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 21), 127)));
                                                v57 = v57 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735050040[u26] = 16;
                                        end;
                                    elseif v60 < 57 then
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] - UNNAMED_2819735036168[u26];
                                    elseif v60 == 58 then
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] / UNNAMED_2819735036840[u26];
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u23;
                                    end;
                                elseif v60 >= 50 then
                                    if v60 < 51 then
                                        local v145 = u33;
                                        local v146 = u34;

                                        if v145 then
                                            for i in u36, v145 do
                                                local v147 = v145[i];

                                                if v147 then
                                                    v147[5] = v147;
                                                    v147[6] = u25[i];
                                                    v147[4] = 6;
                                                    v145[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v146 then
                                            for i, v in u36, v146 do
                                                local v148 = v[6];

                                                if v146 then
                                                    local v149 = v146[i];

                                                    if v149 then
                                                        local v150 = u24(v148);
                                                        u37(u25, i, i + v148 - 1, 1, v150);
                                                        v149[5] = v150;
                                                        v149[4] = 1;
                                                        v146[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u38(UNNAMED_2819735067512[u26], u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n));
                                    end;

                                    if v60 == 52 then
                                        if u25[UNNAMED_2819735069192[u26]] > u25[UNNAMED_2819735036840[u26]] then
                                            u26 = UNNAMED_2819735072456[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735036840[u26]]);
                                    end;
                                elseif v60 >= 48 then
                                    if v60 == 49 then
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26] + u25[UNNAMED_2819735036840[u26]];
                                    else
                                        u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735036840[u26]]);
                                    end;
                                else
                                    v57 = UNNAMED_2819735069192[u26];
                                    v55 = UNNAMED_2819735072456[u26];
                                    v53 = UNNAMED_2819735036840[u26];
                                    v56 = v57 + v55;
                                    v54 = u25[v56];
                                    v58 = v54.n;
                                    v54.n = v55 + v58 - 1;
                                    u37(v54, 1, v58, v55, v54);
                                    u37(u25, v57 + 1, v56 - 1, 1, v54);
                                    u25[v57] = u38(u25[v57](u35(v54, 1, v54.n)));
                                end;
                            elseif v60 < 65 then
                                if v60 < 62 then
                                    if v60 >= 60 then
                                        if v60 == 61 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]][u25[UNNAMED_2819735036840[u26]]];
                                        else
                                            u26 = u25[UNNAMED_2819735036840[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26] .. u25[UNNAMED_2819735036840[u26]];
                                    end;
                                else
                                    if v60 < 63 then
                                        local v151 = u33;
                                        local v152 = u34;

                                        if v151 then
                                            for i in u36, v151 do
                                                local v153 = v151[i];

                                                if v153 then
                                                    v153[5] = v153;
                                                    v153[6] = u25[i];
                                                    v153[4] = 6;
                                                    v151[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v152 then
                                            for i, v in u36, v152 do
                                                local v154 = v[6];

                                                if v152 then
                                                    local v155 = v152[i];

                                                    if v155 then
                                                        local v156 = u24(v154);
                                                        u37(u25, i, i + v154 - 1, 1, v156);
                                                        v155[5] = v156;
                                                        v155[4] = 1;
                                                        v152[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u25[UNNAMED_2819735036840[u26]];
                                    end;

                                    if v60 == 64 then
                                        v57 = u25[UNNAMED_2819735036840[u26]];
                                        u25[UNNAMED_2819735069192[u26]] = u38(u35(v57, UNNAMED_2819735072456[u26], v57.n));
                                    else
                                        u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036840[u26] - u25[UNNAMED_2819735072456[u26]];
                                    end;
                                end;
                            elseif v60 >= 68 then
                                if v60 < 69 then
                                    local v157 = u33;
                                    local v158 = u34;

                                    if v157 then
                                        for i in u36, v157 do
                                            local v159 = v157[i];

                                            if v159 then
                                                v159[5] = v159;
                                                v159[6] = u25[i];
                                                v159[4] = 6;
                                                v157[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v158 then
                                        for i, v in u36, v158 do
                                            local v160 = v[6];

                                            if v158 then
                                                local v161 = v158[i];

                                                if v161 then
                                                    local v162 = u24(v160);
                                                    u37(u25, i, i + v160 - 1, 1, v162);
                                                    v161[5] = v162;
                                                    v161[4] = 1;
                                                    v158[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819735072456[u26], u38(u25[UNNAMED_2819735069192[u26]]);
                                end;

                                if v60 ~= 70 then
                                    local v163 = u33;
                                    local v164 = u34;

                                    if v163 then
                                        for i in u36, v163 do
                                            local v165 = v163[i];

                                            if v165 then
                                                v165[5] = v165;
                                                v165[6] = u25[i];
                                                v165[4] = 6;
                                                v163[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v164 then
                                        for i, v in u36, v164 do
                                            local v166 = v[6];

                                            if v164 then
                                                local v167 = v164[i];

                                                if v167 then
                                                    local v168 = u24(v166);
                                                    u37(u25, i, i + v166 - 1, 1, v168);
                                                    v167[5] = v168;
                                                    v167[4] = 1;
                                                    v164[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819735036840[u26], u38(u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735069192[u26]]);
                                end;

                                UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735036840[u26]]] = UNNAMED_2819735032328[u26];
                            elseif v60 >= 66 then
                                if v60 == 67 then
                                    u25[UNNAMED_2819735069192[u26]](UNNAMED_2819735067512[u26], UNNAMED_2819735036168[u26]);
                                else
                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] == u25[UNNAMED_2819735069192[u26]];
                                end;
                            else
                                v57 = UNNAMED_2819735072456[u26];
                                v55 = u39(u22, u42(u41(u22, 14), 262143), (u42(u41(u22, 28), 15)));
                                v53 = UNNAMED_2819735069192[u26];
                                v56 = UNNAMED_2819735036840[u26];
                                v54 = v57 < 16384 and 7 or (v57 < 2097152 and 14 or 21);
                                v58 = u42(v57, u43(1, v54) - 1);
                                local v169 = u41(v57, v54);
                                UNNAMED_2819735036840[u26] = u39(v56, 116, (u42(u41(v55, 14), 127)));
                                UNNAMED_2819735069192[u26] = u39(v53, 74, (u42(v55, 127)));
                                UNNAMED_2819735072456[u26] = u39(v58, 92, (u42(u41(v55, 7), 127)));
                                UNNAMED_2819735050040[u26] = u39(v169, 66, (u42(u41(v55, 21), 127)));
                                u26 = u26 - 1;
                            end;
                        elseif v60 < 83 then
                            if v60 >= 77 then
                                if v60 < 80 then
                                    if v60 < 78 then
                                        u25[UNNAMED_2819735036840[u26]] = u45[UNNAMED_2819735032328[u26]];
                                    elseif v60 == 79 then
                                        v57 = UNNAMED_2819735072456[u26];
                                        local v170 = u25[UNNAMED_2819735069192[u26]];
                                        u25[v57] = UNNAMED_2819735067512[u26];
                                        u25[v57 + 1] = v170;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] % u25[UNNAMED_2819735069192[u26]];
                                    end;
                                elseif v60 < 81 then
                                    u25[UNNAMED_2819735069192[u26]] = -u25[UNNAMED_2819735072456[u26]];
                                elseif v60 == 82 then
                                    u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] > UNNAMED_2819735036840[u26];
                                else
                                    u25[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735069192[u26]]] = u25[UNNAMED_2819735036840[u26]];
                                end;
                            elseif v60 < 74 then
                                if v60 < 72 then
                                    u25[UNNAMED_2819735036840[u26]] = u41(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735069192[u26]);
                                elseif v60 == 73 then
                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] > UNNAMED_2819735032328[u26];
                                else
                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]] * UNNAMED_2819735036168[u26];
                                end;
                            elseif v60 < 75 then
                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]] .. UNNAMED_2819735036168[u26];
                            else
                                if v60 ~= 76 then
                                    local v171 = u33;
                                    local v172 = u34;

                                    if v171 then
                                        for i in u36, v171 do
                                            local v173 = v171[i];

                                            if v173 then
                                                v173[5] = v173;
                                                v173[6] = u25[i];
                                                v173[4] = 6;
                                                v171[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v172 then
                                        for i, v in u36, v172 do
                                            local v174 = v[6];

                                            if v172 then
                                                local v175 = v172[i];

                                                if v175 then
                                                    local v176 = u24(v174);
                                                    u37(u25, i, i + v174 - 1, 1, v176);
                                                    v175[5] = v176;
                                                    v175[4] = 1;
                                                    v172[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u38(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735036168[u26]);
                                end;

                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] + u25[UNNAMED_2819735072456[u26]];
                            end;
                        elseif v60 >= 89 then
                            if v60 >= 92 then
                                if v60 < 93 then
                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] + UNNAMED_2819735067512[u26];
                                elseif v60 == 94 then
                                    v57 = UNNAMED_2819735069192[u26];
                                    local v177 = u25[UNNAMED_2819735036840[u26]];
                                    u25[v57] = UNNAMED_2819735072456[u26];
                                    u25[v57 + 1] = v177;
                                else
                                    local v178;

                                    if u25[UNNAMED_2819735069192[u26]] then
                                        v178 = UNNAMED_2819735036840[u26];
                                    else
                                        v178 = UNNAMED_2819735072456[u26];
                                    end;

                                    u26 = v178;
                                end;
                            elseif v60 >= 90 then
                                if v60 == 91 then
                                    local v179 = u33;
                                    local v180 = u34;

                                    if v179 then
                                        for i in u36, v179 do
                                            local v181 = v179[i];

                                            if v181 then
                                                v181[5] = v181;
                                                v181[6] = u25[i];
                                                v181[4] = 6;
                                                v179[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v180 then
                                        for i, v in u36, v180 do
                                            local v182 = v[6];

                                            if v180 then
                                                local v183 = v180[i];

                                                if v183 then
                                                    local v184 = u24(v182);
                                                    u37(u25, i, i + v182 - 1, 1, v184);
                                                    v183[5] = v184;
                                                    v183[4] = 1;
                                                    v180[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819735069192[u26], u25[UNNAMED_2819735072456[u26]];
                                end;

                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] % UNNAMED_2819735036168[u26];
                            else
                                v57 = UNNAMED_2819735069192[u26];
                                local v185 = UNNAMED_2819735036840[u26];
                                u25[v57] = UNNAMED_2819735072456[u26];
                                u25[v57 + 1] = v185;
                            end;
                        elseif v60 < 86 then
                            if v60 < 84 then
                                local v186 = u33;
                                local v187 = u34;

                                if v186 then
                                    for i in u36, v186 do
                                        local v188 = v186[i];

                                        if v188 then
                                            v188[5] = v188;
                                            v188[6] = u25[i];
                                            v188[4] = 6;
                                            v186[i] = nil;
                                        end;
                                    end;
                                end;

                                if v187 then
                                    for i, v in u36, v187 do
                                        local v189 = v[6];

                                        if v187 then
                                            local v190 = v187[i];

                                            if v190 then
                                                local v191 = u24(v189);
                                                u37(u25, i, i + v189 - 1, 1, v191);
                                                v190[5] = v191;
                                                v190[4] = 1;
                                                v187[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return false, true, u38(UNNAMED_2819735032328[u26]);
                            end;

                            if v60 == 85 then
                                v57 = UNNAMED_2819735072456[u26];
                                local v192 = UNNAMED_2819735069192[u26];
                                u25[v57] = u25[UNNAMED_2819735036840[u26]];
                                u25[v57 + 1] = v192;
                            else
                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] * UNNAMED_2819735036840[u26];
                            end;
                        elseif v60 >= 87 then
                            if v60 == 88 then
                                v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                v57[5][v57[4]] = u25[UNNAMED_2819735036840[u26]];
                            else
                                u29 = u28[8];
                                u30 = u28[5];
                                u31 = u28[7];
                                u32 = u28[6];
                                u28 = u28[9];
                            end;
                        else
                            u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036840[u26] + u25[UNNAMED_2819735072456[u26]];
                        end;
                    elseif v60 < 142 then
                        if v60 < 118 then
                            if v60 < 106 then
                                if v60 < 100 then
                                    if v60 >= 97 then
                                        if v60 >= 98 then
                                            if v60 == 99 then
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] % UNNAMED_2819735036840[u26];
                                            else
                                                UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735032328[u26]] = u25[UNNAMED_2819735036840[u26]];
                                            end;
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] < u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    elseif v60 == 96 then
                                        local v193 = u25[UNNAMED_2819735072456[u26]] % 4294967296;
                                        u25[UNNAMED_2819735036840[u26]] = v193 ~= v193 and 0 or v193 - v193 % 1;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u43(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735069192[u26]);
                                    end;
                                elseif v60 < 103 then
                                    if v60 >= 101 then
                                        if v60 == 102 then
                                            u26 = u25[UNNAMED_2819735069192[u26]];
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = u38(u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735032328[u26]));
                                        end;
                                    else
                                        local v194 = UNNAMED_2819735069192[u26];
                                        local v195 = UNNAMED_2819735072456[u26];
                                        local v196, v197 = u25[UNNAMED_2819735036840[u26]]();
                                        u25[v194] = v196;
                                        u25[v195] = v197;
                                    end;
                                elseif v60 < 104 then
                                    u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735072456[u26]], u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                                elseif v60 == 105 then
                                    u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735032328[u26]] = UNNAMED_2819735036840[u26];
                                else
                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                    v57[5][v57[4]][UNNAMED_2819735032328[u26]] = UNNAMED_2819735067512[u26];
                                end;
                            elseif v60 >= 112 then
                                if v60 < 115 then
                                    if v60 < 113 then
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735067512[u26]);
                                    else
                                        if v60 == 114 then
                                            local v198 = u33;
                                            local v199 = u34;

                                            if v198 then
                                                for i in u36, v198 do
                                                    local v200 = v198[i];

                                                    if v200 then
                                                        v200[5] = v200;
                                                        v200[6] = u25[i];
                                                        v200[4] = 6;
                                                        v198[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v199 then
                                                for i, v in u36, v199 do
                                                    local v201 = v[6];

                                                    if v199 then
                                                        local v202 = v199[i];

                                                        if v202 then
                                                            local v203 = u24(v201);
                                                            u37(u25, i, i + v201 - 1, 1, v203);
                                                            v202[5] = v203;
                                                            v202[4] = 1;
                                                            v199[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735036840[u26], u38();
                                        end;

                                        v57 = UNNAMED_2819735069192[u26];
                                        local v204 = UNNAMED_2819735067512[u26];
                                        u25[v57] = UNNAMED_2819735072456[u26];
                                        u25[v57 + 1] = v204;
                                    end;
                                elseif v60 >= 116 then
                                    if v60 == 117 then
                                        u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]];
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u46(u25[UNNAMED_2819735069192[u26]]);
                                    end;
                                else
                                    u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]];
                                end;
                            elseif v60 < 109 then
                                if v60 >= 107 then
                                    if v60 ~= 108 then
                                        local v205 = u33;
                                        local v206 = u34;

                                        if v205 then
                                            for i in u36, v205 do
                                                local v207 = v205[i];

                                                if v207 then
                                                    v207[5] = v207;
                                                    v207[6] = u25[i];
                                                    v207[4] = 6;
                                                    v205[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v206 then
                                            for i, v in u36, v206 do
                                                local v208 = v[6];

                                                if v206 then
                                                    local v209 = v206[i];

                                                    if v209 then
                                                        local v210 = u24(v208);
                                                        u37(u25, i, i + v208 - 1, 1, v210);
                                                        v209[5] = v210;
                                                        v209[4] = 1;
                                                        v206[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819735036840[u26], u38(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735032328[u26]);
                                    end;

                                    u28 = {
                                        [6] = u32,
                                        [5] = u30,
                                        [9] = u28,
                                        [8] = u29,
                                        [7] = u31
                                    };
                                    v57 = UNNAMED_2819735072456[u26];
                                    u31 = u25[v57 + 2] + 0;
                                    u30 = u25[v57 + 1] + 0;
                                    u29 = u25[v57] - u31;
                                    u26 = UNNAMED_2819735069192[u26];
                                elseif UNNAMED_2819735032328[u26] >= u25[UNNAMED_2819735036840[u26]] then
                                    u26 = UNNAMED_2819735072456[u26];
                                end;
                            elseif v60 >= 110 then
                                if v60 == 111 then
                                    if u25[UNNAMED_2819735036840[u26]] >= u25[UNNAMED_2819735072456[u26]] then
                                        u26 = UNNAMED_2819735069192[u26];
                                    end;
                                else
                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735069192[u26]]);
                                end;
                            else
                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735067512[u26] * u25[UNNAMED_2819735069192[u26]];
                            end;
                        elseif v60 >= 130 then
                            if v60 >= 136 then
                                if v60 >= 139 then
                                    if v60 < 140 then
                                        local v211 = u33;
                                        local v212 = u34;

                                        if v211 then
                                            for i in u36, v211 do
                                                local v213 = v211[i];

                                                if v213 then
                                                    v213[5] = v213;
                                                    v213[6] = u25[i];
                                                    v213[4] = 6;
                                                    v211[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v212 then
                                            for i, v in u36, v212 do
                                                local v214 = v[6];

                                                if v212 then
                                                    local v215 = v212[i];

                                                    if v215 then
                                                        local v216 = u24(v214);
                                                        u37(u25, i, i + v214 - 1, 1, v216);
                                                        v215[5] = v216;
                                                        v215[4] = 1;
                                                        v212[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u38(UNNAMED_2819735036168[u26], UNNAMED_2819735032328[u26]);
                                    end;

                                    if v60 == 141 then
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26];
                                    else
                                        v57 = UNNAMED_2819735069192[u26] + 1;
                                        v55 = u39(UNNAMED_2819735072456[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));

                                        for i = 1, UNNAMED_2819735036840[u26] do
                                            local v217 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                            local v218 = u39(v217, (u41(v217, 13)));
                                            v55 = u42(u39(v218, (u43(v218, 14))), 536870911);
                                            UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                            UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                            UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 14), 127)));
                                            UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 21), 127)));
                                            v57 = v57 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735050040[u26] = 16;
                                    end;
                                elseif v60 < 137 then
                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]][UNNAMED_2819735036840[u26]];
                                elseif v60 == 138 then
                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]];
                                    v57[5][v57[4]] = UNNAMED_2819735032328[u26];
                                else
                                    UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735072456[u26];
                                end;
                            elseif v60 < 133 then
                                if v60 < 131 then
                                    u25[UNNAMED_2819735069192[u26]](u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                                else
                                    if v60 == 132 then
                                        local v219 = u33;
                                        local v220 = u34;

                                        if v219 then
                                            for i in u36, v219 do
                                                local v221 = v219[i];

                                                if v221 then
                                                    v221[5] = v221;
                                                    v221[6] = u25[i];
                                                    v221[4] = 6;
                                                    v219[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v220 then
                                            for i, v in u36, v220 do
                                                local v222 = v[6];

                                                if v220 then
                                                    local v223 = v220[i];

                                                    if v223 then
                                                        local v224 = u24(v222);
                                                        u37(u25, i, i + v222 - 1, 1, v224);
                                                        v223[5] = v224;
                                                        v223[4] = 1;
                                                        v220[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819735069192[u26], u38(UNNAMED_2819735067512[u26], u25[UNNAMED_2819735072456[u26]]);
                                    end;

                                    u25[UNNAMED_2819735036840[u26]] = u45[UNNAMED_2819735032328[u26]][u25[UNNAMED_2819735072456[u26]]];
                                end;
                            elseif v60 >= 134 then
                                if v60 == 135 then
                                    u25[UNNAMED_2819735036840[u26]] = u38(u25[UNNAMED_2819735069192[u26]]());
                                else
                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]]();
                                end;
                            else
                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] * u25[UNNAMED_2819735036840[u26]];
                            end;
                        elseif v60 < 124 then
                            if v60 >= 121 then
                                if v60 < 122 then
                                    u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036840[u26] ^ u25[UNNAMED_2819735072456[u26]];
                                elseif v60 == 123 then
                                    u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735067512[u26]];
                                else
                                    local v225 = UNNAMED_2819735072456[u26];
                                    local v226 = UNNAMED_2819735036840[u26];
                                    local v227 = UNNAMED_2819735071256[5];
                                    local v228 = u39(v227[v225], 109162203);
                                    v227[v225] = v228;
                                    local v229 = UNNAMED_2819735071256[4];
                                    local v230 = v228 + 1;
                                    local v231 = u49(v229, v230);
                                    local v232;

                                    if v231 < 128 then
                                        v232 = v230 + 1;
                                    else
                                        local v233 = u49(v229, v230 + 1);

                                        if v233 < 128 then
                                            v231 = v231 - 128 + v233 * 128;
                                            v232 = v230 + 2;
                                        else
                                            local v234 = u49(v229, v230 + 2);

                                            if v234 < 128 then
                                                v231 = v231 - 128 + (v233 - 128) * 16384 + v234 * 128;
                                                v232 = v230 + 3;
                                            else
                                                local v235 = u49(v229, v230 + 3);
                                                v231 = (v231 - 128) * 16384 + (v233 - 128) * 128 + (v234 - 128) + v235 % 128 * 2097152 + (v235 - v235 % 128) * 2097152;
                                                v232 = v230 + 4;
                                            end;
                                        end;
                                    end;

                                    local v236 = v226 * 16843009;
                                    local v237 = v232 + v231;
                                    local v238 = v237 - v231 % 4;

                                    for i = v232, v238 - 1, 4 do
                                        u50(v229, i, (u39(u51(v229, i), v236)));
                                        local _ = i;
                                    end;

                                    for i = v238, v237 - 1 do
                                        u52(v229, i, (u39(u49(v229, i), v226)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735072456[u26] = 229;
                                    UNNAMED_2819735036840[u26] = 199;
                                    UNNAMED_2819735069192[u26] = 60;
                                    UNNAMED_2819735050040[u26] = 16;
                                end;
                            elseif v60 >= 119 then
                                if v60 == 120 then
                                    UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735036840[u26]]] = u25[UNNAMED_2819735069192[u26]];
                                else
                                    u25[UNNAMED_2819735072456[u26]] = u40(u25[UNNAMED_2819735069192[u26]], u25[UNNAMED_2819735036840[u26]]);
                                end;
                            else
                                u26 = UNNAMED_2819735069192[u26];
                            end;
                        elseif v60 >= 127 then
                            if v60 < 128 then
                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] .. u25[UNNAMED_2819735069192[u26]];
                            elseif v60 == 129 then
                                u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                            else
                                local v239;

                                if u25[UNNAMED_2819735072456[u26]] then
                                    v239 = UNNAMED_2819735036840[u26];
                                else
                                    v239 = UNNAMED_2819735069192[u26];
                                end;

                                u26 = v239;
                            end;
                        elseif v60 < 125 then
                            u25[UNNAMED_2819735036840[u26]] = u22;
                        elseif v60 == 126 then
                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]](u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                        else
                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] / UNNAMED_2819735032328[u26];
                        end;
                    elseif v60 < 166 then
                        if v60 < 154 then
                            if v60 < 148 then
                                if v60 >= 145 then
                                    if v60 < 146 then
                                        u25[UNNAMED_2819735036840[u26]] = u39(u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735069192[u26]]);
                                    elseif v60 == 147 then
                                        u25[UNNAMED_2819735036840[u26]](UNNAMED_2819735032328[u26], u25[UNNAMED_2819735072456[u26]]);
                                    else
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] >= UNNAMED_2819735072456[u26];
                                    end;
                                elseif v60 >= 143 then
                                    if v60 == 144 then
                                        v57 = UNNAMED_2819735069192[u26];
                                        v55 = u25[UNNAMED_2819735036840[u26]];
                                        u25[v57 + 1] = v55;
                                        u25[v57] = v55[UNNAMED_2819735036168[u26]];
                                    else
                                        v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                        u25[UNNAMED_2819735069192[u26]] = v57[5][v57[4]][UNNAMED_2819735067512[u26]];
                                    end;
                                else
                                    u25[UNNAMED_2819735069192[u26]] = u25;
                                end;
                            elseif v60 >= 151 then
                                if v60 >= 152 then
                                    if v60 == 153 then
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] == UNNAMED_2819735072456[u26];
                                    else
                                        v57 = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]];
                                        u25[UNNAMED_2819735072456[u26]] = v57[5][v57[4]];
                                    end;
                                else
                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] / u25[UNNAMED_2819735069192[u26]];
                                end;
                            elseif v60 >= 149 then
                                if v60 ~= 150 then
                                    local v240 = UNNAMED_2819735036840[u26];
                                    local v241 = v240 + UNNAMED_2819735069192[u26];
                                    local v242 = u33;
                                    local v243 = u34;

                                    if v242 then
                                        for i in u36, v242 do
                                            local v244 = v242[i];

                                            if v244 then
                                                v244[5] = v244;
                                                v244[6] = u25[i];
                                                v244[4] = 6;
                                                v242[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v243 then
                                        for i, v in u36, v243 do
                                            local v245 = v[6];

                                            if v243 then
                                                local v246 = v243[i];

                                                if v246 then
                                                    local v247 = u24(v245);
                                                    u37(u25, i, i + v245 - 1, 1, v247);
                                                    v246[5] = v247;
                                                    v246[4] = 1;
                                                    v243[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, false, v240, v241;
                                end;

                                u28 = {
                                    [6] = u32,
                                    [5] = u30,
                                    [9] = u28,
                                    [8] = u29,
                                    [7] = u31
                                };
                                v57 = UNNAMED_2819735072456[u26];
                                v55 = u47(u48);
                                v55(UNNAMED_2819735031272, u25[v57], u25[v57 + 1], u25[v57 + 2]);
                                u29 = v55;
                                u32 = UNNAMED_2819735036840[u26];
                                u26 = UNNAMED_2819735069192[u26];
                            else
                                local v248 = UNNAMED_2819735069192[u26];
                                local v249 = u39(UNNAMED_2819735072456[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));
                                local v250 = UNNAMED_2819735071256[5];
                                local v251 = u39(v250[v248], 109162203);
                                v250[v248] = v251;
                                local v252 = UNNAMED_2819735071256[4];
                                local v253 = v251 + 1;
                                local v254 = u49(v252, v253);
                                local v255;

                                if v254 < 128 then
                                    v255 = v253 + 1;
                                else
                                    local v256 = u49(v252, v253 + 1);

                                    if v256 < 128 then
                                        v254 = v254 - 128 + v256 * 128;
                                        v255 = v253 + 2;
                                    else
                                        local v257 = u49(v252, v253 + 2);

                                        if v257 < 128 then
                                            v254 = v254 - 128 + (v256 - 128) * 16384 + v257 * 128;
                                            v255 = v253 + 3;
                                        else
                                            local v258 = u49(v252, v253 + 3);
                                            v254 = (v254 - 128) * 16384 + (v256 - 128) * 128 + (v257 - 128) + v258 % 128 * 2097152 + (v258 - v258 % 128) * 2097152;
                                            v255 = v253 + 4;
                                        end;
                                    end;
                                end;

                                local v259 = v249 * 16843009;
                                local v260 = v255 + v254;
                                local v261 = v260 - v254 % 4;

                                for i = v255, v261 - 1, 4 do
                                    u50(v252, i, (u39(u51(v252, i), v259)));
                                    local _ = i;
                                end;

                                for i = v261, v260 - 1 do
                                    u52(v252, i, (u39(u49(v252, i), v249)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735069192[u26] = 113;
                                UNNAMED_2819735072456[u26] = 125;
                                UNNAMED_2819735036840[u26] = 38;
                                UNNAMED_2819735050040[u26] = 16;
                            end;
                        elseif v60 < 160 then
                            if v60 < 157 then
                                if v60 >= 155 then
                                    if v60 == 156 then
                                        local v262 = UNNAMED_2819735072456[u26];
                                        local v263 = UNNAMED_2819735032328[u26];
                                        local v264 = u42(UNNAMED_2819735067512[u26], 4294967295);
                                        local v265 = u42(v263, 4294967295);
                                        local v266 = u42(v264, 65535);
                                        local v267 = u41(v264, 16);
                                        local v268 = u42(v265, 65535);
                                        local v269 = u41(v265, 16);
                                        local v270 = u42(v266 * v268 + u43(u42(v266 * v269 + v267 * v268, 65535), 16), 4294967295) % 4294967296;
                                        u25[v262] = v270 ~= v270 and 0 or v270 - v270 % 1;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] - UNNAMED_2819735069192[u26];
                                    end;
                                else
                                    u25[UNNAMED_2819735072456[u26]] = u42(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735032328[u26]);
                                end;
                            elseif v60 >= 158 then
                                if v60 == 159 then
                                    local v271 = u33;
                                    local v272 = u34;

                                    if v271 then
                                        for i in u36, v271 do
                                            local v273 = v271[i];

                                            if v273 then
                                                v273[5] = v273;
                                                v273[6] = u25[i];
                                                v273[4] = 6;
                                                v271[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v272 then
                                        for i, v in u36, v272 do
                                            local v274 = v[6];

                                            if v272 then
                                                local v275 = v272[i];

                                                if v275 then
                                                    local v276 = u24(v274);
                                                    u37(u25, i, i + v274 - 1, 1, v276);
                                                    v275[5] = v276;
                                                    v275[4] = 1;
                                                    v272[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    local v277 = UNNAMED_2819735036840[u26];
                                    local v278 = UNNAMED_2819735069192[u26];
                                    local v279 = v277 + v278 - 1;
                                    local v280 = u25[v279];
                                    local n = v280.n;
                                    v280.n = v278 + n - 1;
                                    u37(v280, 1, n, v278, v280);
                                    u37(u25, v277, v279 - 1, 1, v280);

                                    return false, true, v280;
                                end;

                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735067512[u26] - u25[UNNAMED_2819735069192[u26]];
                            elseif UNNAMED_2819735036840[u26] >= u25[UNNAMED_2819735072456[u26]] then
                                u26 = UNNAMED_2819735069192[u26];
                            end;
                        elseif v60 < 163 then
                            if v60 >= 161 then
                                if v60 ~= 162 then
                                    local v281 = u33;
                                    local v282 = u34;

                                    if v281 then
                                        for i in u36, v281 do
                                            local v283 = v281[i];

                                            if v283 then
                                                v283[5] = v283;
                                                v283[6] = u25[i];
                                                v283[4] = 6;
                                                v281[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v282 then
                                        for i, v in u36, v282 do
                                            local v284 = v[6];

                                            if v282 then
                                                local v285 = v282[i];

                                                if v285 then
                                                    local v286 = u24(v284);
                                                    u37(u25, i, i + v284 - 1, 1, v286);
                                                    v285[5] = v286;
                                                    v285[4] = 1;
                                                    v282[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u38(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735067512[u26], UNNAMED_2819735036168[u26]);
                                end;

                                if u33 then
                                    local v287 = u33;
                                    local v288 = UNNAMED_2819735036840[u26];
                                    local v289 = v287[v288];

                                    if v289 then
                                        v289[5] = v289;
                                        v289[6] = u25[v288];
                                        v289[4] = 6;
                                        v287[v288] = nil;
                                    end;

                                    local v290 = u33;
                                    local v291 = UNNAMED_2819735072456[u26];
                                    local v292 = v290[v291];

                                    if v292 then
                                        v292[5] = v292;
                                        v292[6] = u25[v291];
                                        v292[4] = 6;
                                        v290[v291] = nil;
                                    end;
                                end;
                            else
                                u25[UNNAMED_2819735069192[u26]] = not u25[UNNAMED_2819735072456[u26]];
                            end;
                        elseif v60 >= 164 then
                            if v60 == 165 then
                                v57 = UNNAMED_2819735069192[u26];
                                v55 = UNNAMED_2819735036840[u26];
                                v53 = UNNAMED_2819735072456[u26];
                                v56 = v57 + v53 - 1;
                                v54 = v57 + v55;
                                v58 = u25[v54];
                                local n = v58.n;
                                v58.n = v55 + n - 1;
                                u37(v58, 1, n, v55, v58);
                                u37(u25, v57 + 1, v54 - 1, 1, v58);
                                u37(u38(u25[v57](u35(v58, 1, v58.n))), 1, v53, v57, u25);
                            else
                                u25[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735072456[u26]]] = UNNAMED_2819735032328[u26];
                            end;
                        else
                            u25[UNNAMED_2819735072456[u26]] = u45[UNNAMED_2819735067512[u26]][UNNAMED_2819735032328[u26]];
                        end;
                    elseif v60 >= 178 then
                        if v60 >= 184 then
                            if v60 >= 187 then
                                if v60 < 188 then
                                    if u33 then
                                        local v293 = u33;
                                        local v294 = UNNAMED_2819735072456[u26];
                                        local v295 = v293[v294];

                                        if v295 then
                                            v295[5] = v295;
                                            v295[6] = u25[v294];
                                            v295[4] = 6;
                                            v293[v294] = nil;
                                        end;
                                    end;
                                elseif v60 == 189 then
                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] + UNNAMED_2819735069192[u26];
                                elseif u25[UNNAMED_2819735036840[u26]] > UNNAMED_2819735069192[u26] then
                                    u26 = UNNAMED_2819735072456[u26];
                                end;
                            elseif v60 >= 185 then
                                if v60 == 186 then
                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                    v57[5][v57[4]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735036840[u26]];
                                else
                                    local v296 = UNNAMED_2819735069192[u26];
                                    local v297 = UNNAMED_2819735072456[u26];
                                    local v298 = u42(u25[UNNAMED_2819735036840[u26]], 4294967295);
                                    local v299 = u42(v297, 4294967295);
                                    local v300 = u42(v298, 65535);
                                    local v301 = u41(v298, 16);
                                    local v302 = u42(v299, 65535);
                                    local v303 = u41(v299, 16);
                                    local v304 = u42(v300 * v302 + u43(u42(v300 * v303 + v301 * v302, 65535), 16), 4294967295) % 4294967296;
                                    u25[v296] = v304 ~= v304 and 0 or v304 - v304 % 1;
                                end;
                            else
                                u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735036840[u26]](u25[UNNAMED_2819735069192[u26]]));
                            end;
                        elseif v60 < 181 then
                            if v60 < 179 then
                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] == UNNAMED_2819735036168[u26];
                            elseif v60 == 180 then
                                u25[UNNAMED_2819735069192[u26]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735067512[u26];
                            else
                                local v305 = UNNAMED_2819735069192[u26];
                                local v306 = u39(UNNAMED_2819735072456[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));
                                local v307 = UNNAMED_2819735071256[5];
                                local v308 = u39(v307[v305], 109162203);
                                v307[v305] = v308;
                                local v309 = UNNAMED_2819735071256[4];
                                local v310 = v308 + 1;
                                local v311 = u49(v309, v310);
                                local v312;

                                if v311 < 128 then
                                    v312 = v310 + 1;
                                else
                                    local v313 = u49(v309, v310 + 1);

                                    if v313 < 128 then
                                        v311 = v311 - 128 + v313 * 128;
                                        v312 = v310 + 2;
                                    else
                                        local v314 = u49(v309, v310 + 2);

                                        if v314 < 128 then
                                            v311 = v311 - 128 + (v313 - 128) * 16384 + v314 * 128;
                                            v312 = v310 + 3;
                                        else
                                            local v315 = u49(v309, v310 + 3);
                                            v311 = (v311 - 128) * 16384 + (v313 - 128) * 128 + (v314 - 128) + v315 % 128 * 2097152 + (v315 - v315 % 128) * 2097152;
                                            v312 = v310 + 4;
                                        end;
                                    end;
                                end;

                                local v316 = v306 * 16843009;
                                local v317 = v312 + v311;
                                local v318 = v317 - v311 % 4;

                                for i = v312, v318 - 1, 4 do
                                    u50(v309, i, (u39(u51(v309, i), v316)));
                                    local _ = i;
                                end;

                                for i = v318, v317 - 1 do
                                    u52(v309, i, (u39(u49(v309, i), v306)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735069192[u26] = 249;
                                UNNAMED_2819735072456[u26] = 231;
                                UNNAMED_2819735036840[u26] = 181;
                                UNNAMED_2819735050040[u26] = 16;
                            end;
                        elseif v60 >= 182 then
                            if v60 == 183 then
                                u22 = u25[UNNAMED_2819735069192[u26]];
                            else
                                u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735069192[u26];
                            end;
                        elseif u25[UNNAMED_2819735069192[u26]] ~= UNNAMED_2819735036168[u26] then
                            u26 = UNNAMED_2819735036840[u26];
                        end;
                    elseif v60 >= 172 then
                        if v60 < 175 then
                            if v60 < 173 then
                                local v319 = u33;
                                local v320 = u34;

                                if v319 then
                                    for i in u36, v319 do
                                        local v321 = v319[i];

                                        if v321 then
                                            v321[5] = v321;
                                            v321[6] = u25[i];
                                            v321[4] = 6;
                                            v319[i] = nil;
                                        end;
                                    end;
                                end;

                                if v320 then
                                    for i, v in u36, v320 do
                                        local v322 = v[6];

                                        if v320 then
                                            local v323 = v320[i];

                                            if v323 then
                                                local v324 = u24(v322);
                                                u37(u25, i, i + v322 - 1, 1, v324);
                                                v323[5] = v324;
                                                v323[4] = 1;
                                                v320[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return true, true, UNNAMED_2819735036840[u26], u38(UNNAMED_2819735032328[u26]);
                            end;

                            if v60 == 174 then
                                local v325 = u33;
                                local v326 = u34;

                                if v325 then
                                    for i in u36, v325 do
                                        local v327 = v325[i];

                                        if v327 then
                                            v327[5] = v327;
                                            v327[6] = u25[i];
                                            v327[4] = 6;
                                            v325[i] = nil;
                                        end;
                                    end;
                                end;

                                if v326 then
                                    for i, v in u36, v326 do
                                        local v328 = v[6];

                                        if v326 then
                                            local v329 = v326[i];

                                            if v329 then
                                                local v330 = u24(v328);
                                                u37(u25, i, i + v328 - 1, 1, v330);
                                                v329[5] = v330;
                                                v329[4] = 1;
                                                v326[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return false, true, u38(UNNAMED_2819735032328[u26], u25[UNNAMED_2819735072456[u26]]);
                            end;

                            u45[UNNAMED_2819735032328[u26]] = u25[UNNAMED_2819735072456[u26]];
                        elseif v60 < 176 then
                            if u25[UNNAMED_2819735069192[u26]] ~= UNNAMED_2819735072456[u26] then
                                u26 = UNNAMED_2819735036840[u26];
                            end;
                        else
                            if v60 ~= 177 then
                                local v331 = u33;
                                local v332 = u34;

                                if v331 then
                                    for i in u36, v331 do
                                        local v333 = v331[i];

                                        if v333 then
                                            v333[5] = v333;
                                            v333[6] = u25[i];
                                            v333[4] = 6;
                                            v331[i] = nil;
                                        end;
                                    end;
                                end;

                                if v332 then
                                    for i, v in u36, v332 do
                                        local v334 = v[6];

                                        if v332 then
                                            local v335 = v332[i];

                                            if v335 then
                                                local v336 = u24(v334);
                                                u37(u25, i, i + v334 - 1, 1, v336);
                                                v335[5] = v336;
                                                v335[4] = 1;
                                                v332[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return false, true, u38(u25[UNNAMED_2819735036840[u26]], u25[UNNAMED_2819735072456[u26]]);
                            end;

                            u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735067512[u26]);
                        end;
                    elseif v60 >= 169 then
                        if v60 >= 170 then
                            if v60 ~= 171 then
                                local v337 = u33;
                                local v338 = u34;

                                if v337 then
                                    for i in u36, v337 do
                                        local v339 = v337[i];

                                        if v339 then
                                            v339[5] = v339;
                                            v339[6] = u25[i];
                                            v339[4] = 6;
                                            v337[i] = nil;
                                        end;
                                    end;
                                end;

                                if v338 then
                                    for i, v in u36, v338 do
                                        local v340 = v[6];

                                        if v338 then
                                            local v341 = v338[i];

                                            if v341 then
                                                local v342 = u24(v340);
                                                u37(u25, i, i + v340 - 1, 1, v342);
                                                v341[5] = v342;
                                                v341[4] = 1;
                                                v338[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return true, true, UNNAMED_2819735036840[u26], u38(u25[UNNAMED_2819735069192[u26]], u35(u25[UNNAMED_2819735072456[u26]], 1, u25[UNNAMED_2819735072456[u26]].n));
                            end;

                            if UNNAMED_2819735067512[u26] > u25[UNNAMED_2819735069192[u26]] then
                                u26 = UNNAMED_2819735072456[u26];
                            end;
                        else
                            u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] < UNNAMED_2819735067512[u26];
                        end;
                    elseif v60 >= 167 then
                        if v60 == 168 then
                            v57 = UNNAMED_2819735072456[u26];
                            local v343 = UNNAMED_2819735032328[u26];
                            u25[v57] = UNNAMED_2819735067512[u26];
                            u25[v57 + 1] = v343;
                        else
                            u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] ~= UNNAMED_2819735036168[u26];
                        end;
                    else
                        v57 = UNNAMED_2819735069192[u26] + 1;
                        v55 = u39(UNNAMED_2819735072456[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));

                        for i = 1, UNNAMED_2819735036840[u26] do
                            local v344 = u42(u39(v55, (u43(v55, 13))), 536870911);
                            local v345 = u39(v344, (u41(v344, 13)));
                            v55 = u42(u39(v345, (u43(v345, 14))), 536870911);
                            UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                            UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                            UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 14), 127)));
                            UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 21), 127)));
                            v57 = v57 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735050040[u26] = 16;
                    end;

                    u26 = u26 + 1;
                end;

                v59 = 4;
                continue;
            elseif v59 == 4 then
                v59 = -1;

                while true do
                    local u26;
                    local v346 = 0;

                    while true do
                        if v346 == 0 then
                            v346 = -1;
                            local v347 = UNNAMED_2819735036840[u26];

                            if v347 < 103 then
                                if v347 >= 51 then
                                    if v347 >= 77 then
                                        if v347 < 90 then
                                            if v347 >= 83 then
                                                if v347 >= 86 then
                                                    if v347 >= 88 then
                                                        if v347 == 89 then
                                                            v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                                            v57[5][v57[4]][UNNAMED_2819735043176[u26]] = UNNAMED_2819735069192[u26];
                                                        else
                                                            local v348 = UNNAMED_2819735050040[u26];
                                                            local v349 = UNNAMED_2819735032328[u26];
                                                            local v350 = u42(UNNAMED_2819735036168[u26], 4294967295);
                                                            local v351 = u42(v349, 4294967295);
                                                            local v352 = u42(v350, 65535);
                                                            local v353 = u41(v350, 16);
                                                            local v354 = u42(v351, 65535);
                                                            local v355 = u41(v351, 16);
                                                            local v356 = u42(v352 * v354 + u43(u42(v352 * v355 + v353 * v354, 65535), 16), 4294967295) % 4294967296;
                                                            u25[v348] = v356 ~= v356 and 0 or v356 - v356 % 1;
                                                        end;
                                                    elseif v347 == 87 then
                                                        v57 = u25[UNNAMED_2819735069192[u26]];
                                                        u25[UNNAMED_2819735072456[u26]] = u38(u35(v57, UNNAMED_2819735050040[u26], v57.n));
                                                    else
                                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735050040[u26]] % UNNAMED_2819735072456[u26];
                                                    end;
                                                elseif v347 >= 84 then
                                                    if v347 == 85 then
                                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735032328[u26];
                                                    else
                                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]];
                                                        v57 = UNNAMED_2819735072456[u26 + 1];
                                                        v55 = UNNAMED_2819735050040[u26 + 1];
                                                        v53 = UNNAMED_2819735069192[u26 + 1];
                                                        v56 = v57 + v53 - 1;
                                                        v54 = v57 + v55;
                                                        v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                                        u37(v58, 1, v53, v57, u25);
                                                        u26 = u26 + 1;
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735050040[u26]] = u42(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735072456[u26]);
                                                end;
                                            elseif v347 < 80 then
                                                if v347 < 78 then
                                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                                    v57[5][v57[4]] = UNNAMED_2819735043176[u26];
                                                elseif v347 == 79 then
                                                    u25[UNNAMED_2819735050040[u26]] = u40(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735032328[u26]);
                                                else
                                                    u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735036168[u26]);
                                                end;
                                            elseif v347 >= 81 then
                                                if v347 == 82 then
                                                    local v357 = u25[UNNAMED_2819735050040[u26]] % 4294967296;
                                                    u25[UNNAMED_2819735069192[u26]] = v357 ~= v357 and 0 or v357 - v357 % 1;
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735050040[u26]]));
                                                end;
                                            end;
                                        elseif v347 >= 96 then
                                            if v347 < 99 then
                                                if v347 >= 97 then
                                                    if v347 == 98 then
                                                        local v358 = u33;
                                                        local v359 = u34;

                                                        if v358 then
                                                            for i in u36, v358 do
                                                                local v360 = v358[i];

                                                                if v360 then
                                                                    v360[5] = v360;
                                                                    v360[6] = u25[i];
                                                                    v360[4] = 6;
                                                                    v358[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v359 then
                                                            for i, v in u36, v359 do
                                                                local v361 = v[6];

                                                                if v359 then
                                                                    local v362 = v359[i];

                                                                    if v362 then
                                                                        local v363 = u24(v361);
                                                                        u37(u25, i, i + v361 - 1, 1, v363);
                                                                        v362[5] = v363;
                                                                        v362[4] = 1;
                                                                        v359[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return true, true, UNNAMED_2819735050040[u26], u38(u25[UNNAMED_2819735072456[u26]]);
                                                    end;

                                                    local v364 = UNNAMED_2819735069192[u26];
                                                    local v365 = u25[UNNAMED_2819735072456[u26]];
                                                    local v366 = u42(UNNAMED_2819735043176[u26], 4294967295);
                                                    local v367 = u42(v365, 4294967295);
                                                    local v368 = u42(v366, 65535);
                                                    local v369 = u41(v366, 16);
                                                    local v370 = u42(v367, 65535);
                                                    local v371 = u41(v367, 16);
                                                    local v372 = u42(v368 * v370 + u43(u42(v368 * v371 + v369 * v370, 65535), 16), 4294967295) % 4294967296;
                                                    u25[v364] = v372 ~= v372 and 0 or v372 - v372 % 1;
                                                else
                                                    local v373 = UNNAMED_2819735072456[u26];
                                                    local v374 = u25[UNNAMED_2819735050040[u26]];
                                                    local v375 = u42(u25[UNNAMED_2819735069192[u26]], 4294967295);
                                                    local v376 = u42(v374, 4294967295);
                                                    local v377 = u42(v375, 65535);
                                                    local v378 = u41(v375, 16);
                                                    local v379 = u42(v376, 65535);
                                                    local v380 = u41(v376, 16);
                                                    local v381 = u42(v377 * v379 + u43(u42(v377 * v380 + v378 * v379, 65535), 16), 4294967295) % 4294967296;
                                                    u25[v373] = v381 ~= v381 and 0 or v381 - v381 % 1;
                                                end;
                                            elseif v347 < 101 then
                                                if v347 == 100 then
                                                    local v382 = u33;
                                                    local v383 = u34;

                                                    if v382 then
                                                        for i in u36, v382 do
                                                            local v384 = v382[i];

                                                            if v384 then
                                                                v384[5] = v384;
                                                                v384[6] = u25[i];
                                                                v384[4] = 6;
                                                                v382[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v383 then
                                                        for i, v in u36, v383 do
                                                            local v385 = v[6];

                                                            if v383 then
                                                                local v386 = v383[i];

                                                                if v386 then
                                                                    local v387 = u24(v385);
                                                                    u37(u25, i, i + v385 - 1, 1, v387);
                                                                    v386[5] = v387;
                                                                    v386[4] = 1;
                                                                    v383[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(UNNAMED_2819735032328[u26], u25[UNNAMED_2819735072456[u26]]);
                                                end;

                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] % UNNAMED_2819735032328[u26];
                                            elseif v347 == 102 then
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26] * u25[UNNAMED_2819735050040[u26]];
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][UNNAMED_2819735036168[u26]];
                                            end;
                                        elseif v347 < 93 then
                                            if v347 < 91 then
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]] .. UNNAMED_2819735036168[u26];
                                            elseif v347 == 92 then
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036168[u26] - u25[UNNAMED_2819735050040[u26]];
                                            else
                                                u45[UNNAMED_2819735036168[u26]][UNNAMED_2819735032328[u26]] = UNNAMED_2819735043176[u26];
                                            end;
                                        elseif v347 >= 94 then
                                            if v347 == 95 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55, v53, v56 = u29();

                                                if v55 then
                                                    u25[v57] = v53;
                                                    u25[v57 + 1] = v56;
                                                    u26 = UNNAMED_2819735069192[u26];
                                                else
                                                    u26 = UNNAMED_2819735050040[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] < UNNAMED_2819735043176[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735069192[u26]]);
                                        end;
                                    elseif v347 >= 64 then
                                        if v347 < 70 then
                                            if v347 < 67 then
                                                if v347 >= 65 then
                                                    if v347 == 66 then
                                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] > UNNAMED_2819735069192[u26];
                                                    else
                                                        v57 = UNNAMED_2819735069192[u26] + 1;
                                                        v55 = u39(UNNAMED_2819735072456[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));

                                                        for i = 1, UNNAMED_2819735050040[u26] do
                                                            local v388 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                            local v389 = u39(v388, (u41(v388, 13)));
                                                            v55 = u42(u39(v389, (u43(v389, 14))), 536870911);
                                                            UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                                            UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                                            UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 14), 127)));
                                                            UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 21), 127)));
                                                            v57 = v57 + 1;
                                                            local _ = i;
                                                        end;

                                                        UNNAMED_2819735036840[u26] = 80;
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735050040[u26]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735032328[u26];
                                                end;
                                            elseif v347 < 68 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = UNNAMED_2819735050040[u26];
                                                v53 = UNNAMED_2819735069192[u26];
                                                v56 = v57 + v53 - 1;
                                                v54 = v57 + v55;
                                                v58 = u25[v54];
                                                local n = v58.n;
                                                v58.n = v55 + n - 1;
                                                u37(v58, 1, n, v55, v58);
                                                u37(u25, v57 + 1, v54 - 1, 1, v58);
                                                u37(u38(u25[v57](u35(v58, 1, v58.n))), 1, v53, v57, u25);
                                            elseif v347 == 69 then
                                                local v390;

                                                if u25[UNNAMED_2819735072456[u26]] then
                                                    v390 = UNNAMED_2819735069192[u26];
                                                else
                                                    v390 = UNNAMED_2819735050040[u26];
                                                end;

                                                u26 = v390;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] - UNNAMED_2819735069192[u26];
                                            end;
                                        elseif v347 >= 73 then
                                            if v347 >= 75 then
                                                if v347 == 76 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] >= u25[UNNAMED_2819735050040[u26]];
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = {};
                                                end;
                                            elseif v347 == 74 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                local v391 = u25[UNNAMED_2819735069192[u26]];
                                                u25[v57] = UNNAMED_2819735050040[u26];
                                                u25[v57 + 1] = v391;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u42(u25[UNNAMED_2819735050040[u26]], u25[UNNAMED_2819735069192[u26]]);
                                            end;
                                        elseif v347 >= 71 then
                                            if v347 == 72 then
                                                v57 = UNNAMED_2819769586744[UNNAMED_2819735050040[u26]];
                                                u25[UNNAMED_2819735069192[u26]] = v57[5][v57[4]][UNNAMED_2819735072456[u26]];
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] + u25[UNNAMED_2819735069192[u26]];
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u46(u25[UNNAMED_2819735050040[u26]]);
                                        end;
                                    elseif v347 < 57 then
                                        if v347 >= 54 then
                                            if v347 >= 55 then
                                                if v347 == 56 then
                                                    u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]][u25[UNNAMED_2819735072456[u26]]];
                                                else
                                                    u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735072456[u26] ^ u25[UNNAMED_2819735050040[u26]];
                                                end;
                                            else
                                                UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735050040[u26]]] = UNNAMED_2819735032328[u26];
                                            end;
                                        elseif v347 >= 52 then
                                            if v347 == 53 then
                                                u25[UNNAMED_2819735050040[u26]] = u40(u25[UNNAMED_2819735069192[u26]], u25[UNNAMED_2819735072456[u26]]);
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u42(UNNAMED_2819735036168[u26], u25[UNNAMED_2819735050040[u26]]);
                                            end;
                                        else
                                            v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                            u25[UNNAMED_2819735050040[u26]] = v57[5][v57[4]][UNNAMED_2819735036168[u26]];
                                        end;
                                    elseif v347 < 60 then
                                        if v347 < 58 then
                                            u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819735072456[u26] + u25[UNNAMED_2819735069192[u26]];
                                        elseif v347 == 59 then
                                            u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]] == UNNAMED_2819735072456[u26];
                                        else
                                            u26 = u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    elseif v347 < 62 then
                                        if v347 == 61 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] + UNNAMED_2819735032328[u26];
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]](u35(u25[UNNAMED_2819735050040[u26]], 1, u25[UNNAMED_2819735050040[u26]].n));
                                        end;
                                    elseif v347 == 63 then
                                        if UNNAMED_2819735072456[u26] > u25[UNNAMED_2819735050040[u26]] then
                                            u26 = UNNAMED_2819735069192[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735069192[u26]] = u39(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735050040[u26]);
                                    end;
                                elseif v347 >= 25 then
                                    if v347 >= 38 then
                                        if v347 >= 44 then
                                            if v347 >= 47 then
                                                if v347 >= 49 then
                                                    if v347 == 50 then
                                                        v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                                        v57[5][v57[4]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735050040[u26]];
                                                    else
                                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] > u25[UNNAMED_2819735069192[u26]];
                                                    end;
                                                elseif v347 == 48 then
                                                    u25[UNNAMED_2819735050040[u26]]();
                                                else
                                                    u25[UNNAMED_2819735050040[u26]][u25[UNNAMED_2819735069192[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                                end;
                                            elseif v347 < 45 then
                                                u25[UNNAMED_2819735050040[u26]] = u42(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735036168[u26]);
                                            elseif v347 == 46 then
                                                u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735036168[u26], u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n));
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                            end;
                                        elseif v347 < 41 then
                                            if v347 >= 39 then
                                                if v347 ~= 40 then
                                                    local v392 = u33;
                                                    local v393 = u34;

                                                    if v392 then
                                                        for i in u36, v392 do
                                                            local v394 = v392[i];

                                                            if v394 then
                                                                v394[5] = v394;
                                                                v394[6] = u25[i];
                                                                v394[4] = 6;
                                                                v392[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v393 then
                                                        for i, v in u36, v393 do
                                                            local v395 = v[6];

                                                            if v393 then
                                                                local v396 = v393[i];

                                                                if v396 then
                                                                    local v397 = u24(v395);
                                                                    u37(u25, i, i + v395 - 1, 1, v397);
                                                                    v396[5] = v397;
                                                                    v396[4] = 1;
                                                                    v393[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735050040[u26]]);
                                                end;

                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735032328[u26]];
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036168[u26] + u25[UNNAMED_2819735050040[u26]];
                                            end;
                                        elseif v347 < 42 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] * UNNAMED_2819735032328[u26];
                                        else
                                            if v347 == 43 then
                                                local v398 = u33;
                                                local v399 = u34;

                                                if v398 then
                                                    for i in u36, v398 do
                                                        local v400 = v398[i];

                                                        if v400 then
                                                            v400[5] = v400;
                                                            v400[6] = u25[i];
                                                            v400[4] = 6;
                                                            v398[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v399 then
                                                    for i, v in u36, v399 do
                                                        local v401 = v[6];

                                                        if v399 then
                                                            local v402 = v399[i];

                                                            if v402 then
                                                                local v403 = u24(v401);
                                                                u37(u25, i, i + v401 - 1, 1, v403);
                                                                v402[5] = v403;
                                                                v402[4] = 1;
                                                                v399[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735072456[u26], u25[UNNAMED_2819735050040[u26]];
                                            end;

                                            v57 = UNNAMED_2819735069192[u26];
                                            local v404 = UNNAMED_2819735072456[u26];
                                            u25[v57] = UNNAMED_2819735043176[u26];
                                            u25[v57 + 1] = v404;
                                        end;
                                    elseif v347 < 31 then
                                        if v347 >= 28 then
                                            if v347 >= 29 then
                                                if v347 == 30 then
                                                    v57 = u39(u22, u42(u41(u22, 14), 262143), (u42(u41(u22, 28), 15)));
                                                    v55 = UNNAMED_2819735069192[u26];
                                                    v53 = UNNAMED_2819735072456[u26];
                                                    v56 = UNNAMED_2819735050040[u26];
                                                    v54 = v53 < 16384 and 7 or (v53 < 2097152 and 14 or 21);
                                                    v58 = u41(v53, v54);
                                                    local v405 = u42(v53, u43(1, v54) - 1);
                                                    UNNAMED_2819735050040[u26] = u39(v56, 108, (u42(u41(v57, 14), 127)));
                                                    UNNAMED_2819735069192[u26] = u39(v55, 127, (u42(v57, 127)));
                                                    UNNAMED_2819735072456[u26] = u39(v405, 67, (u42(u41(v57, 7), 127)));
                                                    UNNAMED_2819735036840[u26] = u39(v58, 124, (u42(u41(v57, 21), 127)));
                                                    u26 = u26 - 1;
                                                else
                                                    local v406 = UNNAMED_2819735069192[u26];
                                                    local v407 = u39(UNNAMED_2819735072456[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));
                                                    local v408 = UNNAMED_2819735071256[5];
                                                    local v409 = u39(v408[v406], 109162203);
                                                    v408[v406] = v409;
                                                    local v410 = UNNAMED_2819735071256[4];
                                                    local v411 = v409 + 1;
                                                    local v412 = u49(v410, v411);
                                                    local v413;

                                                    if v412 < 128 then
                                                        v413 = v411 + 1;
                                                    else
                                                        local v414 = u49(v410, v411 + 1);

                                                        if v414 < 128 then
                                                            v412 = v412 - 128 + v414 * 128;
                                                            v413 = v411 + 2;
                                                        else
                                                            local v415 = u49(v410, v411 + 2);

                                                            if v415 < 128 then
                                                                v412 = v412 - 128 + (v414 - 128) * 16384 + v415 * 128;
                                                                v413 = v411 + 3;
                                                            else
                                                                local v416 = u49(v410, v411 + 3);
                                                                v412 = (v412 - 128) * 16384 + (v414 - 128) * 128 + (v415 - 128) + v416 % 128 * 2097152 + (v416 - v416 % 128) * 2097152;
                                                                v413 = v411 + 4;
                                                            end;
                                                        end;
                                                    end;

                                                    local v417 = v407 * 16843009;
                                                    local v418 = v413 + v412;
                                                    local v419 = v418 - v412 % 4;

                                                    for i = v413, v419 - 1, 4 do
                                                        u50(v410, i, (u39(u51(v410, i), v417)));
                                                        local _ = i;
                                                    end;

                                                    for i = v419, v418 - 1 do
                                                        u52(v410, i, (u39(u49(v410, i), v407)));
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819735069192[u26] = 42;
                                                    UNNAMED_2819735072456[u26] = 156;
                                                    UNNAMED_2819735050040[u26] = 248;
                                                    UNNAMED_2819735036840[u26] = 80;
                                                end;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735050040[u26]] ~= UNNAMED_2819735072456[u26];
                                            end;
                                        else
                                            if v347 < 26 then
                                                local v420 = u33;
                                                local v421 = u34;

                                                if v420 then
                                                    for i in u36, v420 do
                                                        local v422 = v420[i];

                                                        if v422 then
                                                            v422[5] = v422;
                                                            v422[6] = u25[i];
                                                            v422[4] = 6;
                                                            v420[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v421 then
                                                    for i, v in u36, v421 do
                                                        local v423 = v[6];

                                                        if v421 then
                                                            local v424 = v421[i];

                                                            if v424 then
                                                                local v425 = u24(v423);
                                                                u37(u25, i, i + v423 - 1, 1, v425);
                                                                v424[5] = v425;
                                                                v424[4] = 1;
                                                                v421[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735050040[u26], u38(u25[UNNAMED_2819735069192[u26]], u35(u25[UNNAMED_2819735072456[u26]], 1, u25[UNNAMED_2819735072456[u26]].n));
                                            end;

                                            if v347 == 27 then
                                                u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735072456[u26]], u35(u25[UNNAMED_2819735050040[u26]], 1, u25[UNNAMED_2819735050040[u26]].n));
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] - u25[UNNAMED_2819735069192[u26]];
                                            end;
                                        end;
                                    elseif v347 < 34 then
                                        if v347 < 32 then
                                            UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735050040[u26]];
                                        elseif v347 == 33 then
                                            u25[UNNAMED_2819735050040[u26]](u25[UNNAMED_2819735072456[u26]]);
                                        else
                                            u26 = u25[UNNAMED_2819735050040[u26]];
                                        end;
                                    elseif v347 < 36 then
                                        if v347 == 35 then
                                            local v426 = UNNAMED_2819735069192[u26];
                                            local v427 = u39(UNNAMED_2819735072456[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));
                                            local v428 = UNNAMED_2819735071256[5];
                                            local v429 = u39(v428[v426], 109162203);
                                            v428[v426] = v429;
                                            local v430 = UNNAMED_2819735071256[4];
                                            local v431 = v429 + 1;
                                            local v432 = u49(v430, v431);
                                            local v433;

                                            if v432 < 128 then
                                                v433 = v431 + 1;
                                            else
                                                local v434 = u49(v430, v431 + 1);

                                                if v434 < 128 then
                                                    v432 = v432 - 128 + v434 * 128;
                                                    v433 = v431 + 2;
                                                else
                                                    local v435 = u49(v430, v431 + 2);

                                                    if v435 < 128 then
                                                        v432 = v432 - 128 + (v434 - 128) * 16384 + v435 * 128;
                                                        v433 = v431 + 3;
                                                    else
                                                        local v436 = u49(v430, v431 + 3);
                                                        v432 = (v432 - 128) * 16384 + (v434 - 128) * 128 + (v435 - 128) + v436 % 128 * 2097152 + (v436 - v436 % 128) * 2097152;
                                                        v433 = v431 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v437 = v427 * 16843009;
                                            local v438 = v433 + v432;
                                            local v439 = v438 - v432 % 4;

                                            for i = v433, v439 - 1, 4 do
                                                u50(v430, i, (u39(u51(v430, i), v437)));
                                                local _ = i;
                                            end;

                                            for i = v439, v438 - 1 do
                                                u52(v430, i, (u39(u49(v430, i), v427)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735069192[u26] = 21;
                                            UNNAMED_2819735072456[u26] = 205;
                                            UNNAMED_2819735050040[u26] = 192;
                                            UNNAMED_2819735036840[u26] = 80;
                                        else
                                            v57 = UNNAMED_2819735069192[u26] + 1;
                                            v55 = u39(UNNAMED_2819735072456[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));

                                            for i = 1, UNNAMED_2819735050040[u26] do
                                                local v440 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                local v441 = u39(v440, (u41(v440, 13)));
                                                v55 = u42(u39(v441, (u43(v441, 14))), 536870911);
                                                UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                                UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                                UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 14), 127)));
                                                UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 21), 127)));
                                                v57 = v57 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735036840[u26] = 80;
                                        end;
                                    elseif v347 == 37 then
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][u25[UNNAMED_2819735050040[u26]]];
                                    else
                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]] / UNNAMED_2819735072456[u26];
                                    end;
                                elseif v347 < 12 then
                                    if v347 >= 6 then
                                        if v347 >= 9 then
                                            if v347 < 10 then
                                                v57 = UNNAMED_2819735050040[u26];
                                                local v442 = UNNAMED_2819735072456[u26];
                                                u25[v57] = UNNAMED_2819735069192[u26];
                                                u25[v57 + 1] = v442;
                                            elseif v347 == 11 then
                                                for i = UNNAMED_2819735050040[u26], UNNAMED_2819735072456[u26] do
                                                    u25[i] = nil;
                                                    local _ = i;
                                                end;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735072456[u26] - u25[UNNAMED_2819735050040[u26]];
                                            end;
                                        elseif v347 >= 7 then
                                            if v347 == 8 then
                                                if UNNAMED_2819735069192[u26] >= u25[UNNAMED_2819735050040[u26]] then
                                                    u26 = UNNAMED_2819735072456[u26];
                                                end;
                                            elseif u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735032328[u26] then
                                                u26 = UNNAMED_2819735050040[u26];
                                            end;
                                        else
                                            v57 = UNNAMED_2819769586744[UNNAMED_2819735050040[u26]];
                                            u25[UNNAMED_2819735072456[u26]] = v57[5][v57[4]];
                                        end;
                                    elseif v347 >= 3 then
                                        if v347 < 4 then
                                            u28 = {
                                                [6] = u32,
                                                [5] = u30,
                                                [9] = u28,
                                                [8] = u29,
                                                [7] = u31
                                            };
                                            v57 = UNNAMED_2819735050040[u26];
                                            u31 = u25[v57 + 2] + 0;
                                            u30 = u25[v57 + 1] + 0;
                                            u29 = u25[v57] - u31;
                                            u26 = UNNAMED_2819735072456[u26];
                                        elseif v347 == 5 then
                                            u25[UNNAMED_2819735069192[u26]] = u45[UNNAMED_2819735043176[u26]];
                                        elseif u33 then
                                            local v443 = u33;
                                            local v444 = UNNAMED_2819735072456[u26];
                                            local v445 = v443[v444];

                                            if v445 then
                                                v445[5] = v445;
                                                v445[6] = u25[v444];
                                                v445[4] = 6;
                                                v443[v444] = nil;
                                            end;
                                        end;
                                    elseif v347 >= 1 then
                                        if v347 == 2 then
                                            u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819735036168[u26] .. u25[UNNAMED_2819735069192[u26]];
                                        else
                                            u22 = u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] * u25[UNNAMED_2819735050040[u26]];
                                    end;
                                elseif v347 >= 18 then
                                    if v347 < 21 then
                                        if v347 >= 19 then
                                            if v347 == 20 then
                                                u25[UNNAMED_2819735072456[u26]] = u40(UNNAMED_2819735043176[u26], u25[UNNAMED_2819735069192[u26]]);
                                            elseif u25[UNNAMED_2819735069192[u26]] ~= UNNAMED_2819735050040[u26] then
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        else
                                            u45[UNNAMED_2819735032328[u26]][UNNAMED_2819735043176[u26]] = u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    elseif v347 >= 23 then
                                        if v347 == 24 then
                                            u25[UNNAMED_2819735072456[u26]] = #u25[UNNAMED_2819735050040[u26]];
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] ~= u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    elseif v347 == 22 then
                                        u23 = u25[UNNAMED_2819735050040[u26]];
                                    else
                                        u25[UNNAMED_2819735069192[u26]][u25[UNNAMED_2819735072456[u26]]] = UNNAMED_2819735043176[u26];
                                    end;
                                elseif v347 >= 15 then
                                    if v347 >= 16 then
                                        if v347 == 17 then
                                            local v446 = UNNAMED_2819735050040[u26];
                                            local v447 = UNNAMED_2819735072456[u26];
                                            local v448 = UNNAMED_2819735071256[5];
                                            local v449 = u39(v448[v446], 109162203);
                                            v448[v446] = v449;
                                            local v450 = UNNAMED_2819735071256[4];
                                            local v451 = v449 + 1;
                                            local v452 = u49(v450, v451);
                                            local v453;

                                            if v452 < 128 then
                                                v453 = v451 + 1;
                                            else
                                                local v454 = u49(v450, v451 + 1);

                                                if v454 < 128 then
                                                    v452 = v452 - 128 + v454 * 128;
                                                    v453 = v451 + 2;
                                                else
                                                    local v455 = u49(v450, v451 + 2);

                                                    if v455 < 128 then
                                                        v452 = v452 - 128 + (v454 - 128) * 16384 + v455 * 128;
                                                        v453 = v451 + 3;
                                                    else
                                                        local v456 = u49(v450, v451 + 3);
                                                        v452 = (v452 - 128) * 16384 + (v454 - 128) * 128 + (v455 - 128) + v456 % 128 * 2097152 + (v456 - v456 % 128) * 2097152;
                                                        v453 = v451 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v457 = v447 * 16843009;
                                            local v458 = v453 + v452;
                                            local v459 = v458 - v452 % 4;

                                            for i = v453, v459 - 1, 4 do
                                                u50(v450, i, (u39(u51(v450, i), v457)));
                                                local _ = i;
                                            end;

                                            for i = v459, v458 - 1 do
                                                u52(v450, i, (u39(u49(v450, i), v447)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735050040[u26] = 78;
                                            UNNAMED_2819735072456[u26] = 229;
                                            UNNAMED_2819735069192[u26] = 8;
                                            UNNAMED_2819735036840[u26] = 80;
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819735072456[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735069192[u26]] = u41(u25[UNNAMED_2819735050040[u26]], UNNAMED_2819735072456[u26]);
                                    end;
                                elseif v347 >= 13 then
                                    if v347 == 14 then
                                        if u25[UNNAMED_2819735072456[u26]] ~= u25[UNNAMED_2819735069192[u26]] then
                                            u26 = UNNAMED_2819735050040[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735050040[u26] * u25[UNNAMED_2819735069192[u26]];
                                    end;
                                else
                                    v57 = UNNAMED_2819735050040[u26] + 1;
                                    v55 = UNNAMED_2819735072456[u26];

                                    for i = 1, UNNAMED_2819735069192[u26] do
                                        local v460 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                        local v461 = u39(v460, (u41(v460, 13)));
                                        v55 = u42(u39(v461, (u43(v461, 14))), 536870911);
                                        UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                        UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                        UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 14), 127)));
                                        UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 21), 127)));
                                        v57 = v57 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735036840[u26] = 80;
                                end;
                            else
                                if v347 >= 155 then
                                    if v347 >= 181 then
                                        if v347 >= 194 then
                                            if v347 >= 200 then
                                                if v347 >= 203 then
                                                    if v347 < 205 then
                                                        if v347 == 204 then
                                                            u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]] < u25[UNNAMED_2819735072456[u26]];
                                                        else
                                                            v57 = UNNAMED_2819735072456[u26];
                                                            v55, v53 = u29();

                                                            if v55 then
                                                                u25[v57] = v53;
                                                                u26 = UNNAMED_2819735050040[u26];
                                                            else
                                                                u26 = UNNAMED_2819735069192[u26];
                                                            end;
                                                        end;
                                                    else
                                                        if v347 == 206 then
                                                            local v462 = u33;
                                                            local v463 = u34;

                                                            if v462 then
                                                                for i in u36, v462 do
                                                                    local v464 = v462[i];

                                                                    if v464 then
                                                                        v464[5] = v464;
                                                                        v464[6] = u25[i];
                                                                        v464[4] = 6;
                                                                        v462[i] = nil;
                                                                    end;
                                                                end;
                                                            end;

                                                            if v463 then
                                                                for i, v in u36, v463 do
                                                                    local v465 = v[6];

                                                                    if v463 then
                                                                        local v466 = v463[i];

                                                                        if v466 then
                                                                            local v467 = u24(v465);
                                                                            u37(u25, i, i + v465 - 1, 1, v467);
                                                                            v466[5] = v467;
                                                                            v466[4] = 1;
                                                                            v463[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;
                                                            end;

                                                            return false, true, u38(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735043176[u26], UNNAMED_2819735032328[u26]);
                                                        end;

                                                        u25[UNNAMED_2819735072456[u26]] = -u25[UNNAMED_2819735050040[u26]];
                                                    end;
                                                elseif v347 < 201 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] // UNNAMED_2819735050040[u26];
                                                else
                                                    if v347 == 202 then
                                                        local v468 = UNNAMED_2819735069192[u26];
                                                        local v469 = v468 + UNNAMED_2819735072456[u26];
                                                        local v470 = u33;
                                                        local v471 = u34;

                                                        if v470 then
                                                            for i in u36, v470 do
                                                                local v472 = v470[i];

                                                                if v472 then
                                                                    v472[5] = v472;
                                                                    v472[6] = u25[i];
                                                                    v472[4] = 6;
                                                                    v470[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v471 then
                                                            for i, v in u36, v471 do
                                                                local v473 = v[6];

                                                                if v471 then
                                                                    local v474 = v471[i];

                                                                    if v474 then
                                                                        local v475 = u24(v473);
                                                                        u37(u25, i, i + v473 - 1, 1, v475);
                                                                        v474[5] = v475;
                                                                        v474[4] = 1;
                                                                        v471[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return true, false, v468, v469;
                                                    end;

                                                    u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]] % u25[UNNAMED_2819735072456[u26]];
                                                end;
                                            elseif v347 >= 197 then
                                                if v347 < 198 then
                                                    u25[UNNAMED_2819735072456[u26]] = not u25[UNNAMED_2819735069192[u26]];
                                                elseif v347 == 199 then
                                                    u26 = UNNAMED_2819735072456[u26];
                                                else
                                                    v57 = UNNAMED_2819735050040[u26];
                                                    v55 = u25[UNNAMED_2819735069192[u26]];
                                                    u25[v57 + 1] = v55;
                                                    u25[v57] = v55[UNNAMED_2819735036168[u26]];
                                                end;
                                            elseif v347 < 195 then
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] .. u25[UNNAMED_2819735050040[u26]];
                                            else
                                                if v347 ~= 196 then
                                                    local v476 = u33;
                                                    local v477 = u34;

                                                    if v476 then
                                                        for i in u36, v476 do
                                                            local v478 = v476[i];

                                                            if v478 then
                                                                v478[5] = v478;
                                                                v478[6] = u25[i];
                                                                v478[4] = 6;
                                                                v476[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v477 then
                                                        for i, v in u36, v477 do
                                                            local v479 = v[6];

                                                            if v477 then
                                                                local v480 = v477[i];

                                                                if v480 then
                                                                    local v481 = u24(v479);
                                                                    u37(u25, i, i + v479 - 1, 1, v481);
                                                                    v480[5] = v481;
                                                                    v480[4] = 1;
                                                                    v477[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819735072456[u26], u38(u25[UNNAMED_2819735050040[u26]], u25[UNNAMED_2819735069192[u26]]);
                                                end;

                                                local v482 = UNNAMED_2819735050040[u26];
                                                local v483 = UNNAMED_2819735072456[u26];
                                                local v484 = u42(u25[UNNAMED_2819735069192[u26]], 4294967295);
                                                local v485 = u42(v483, 4294967295);
                                                local v486 = u42(v484, 65535);
                                                local v487 = u41(v484, 16);
                                                local v488 = u42(v485, 65535);
                                                local v489 = u41(v485, 16);
                                                local v490 = u42(v486 * v488 + u43(u42(v486 * v489 + v487 * v488, 65535), 16), 4294967295) % 4294967296;
                                                u25[v482] = v490 ~= v490 and 0 or v490 - v490 % 1;
                                            end;
                                        elseif v347 < 187 then
                                            if v347 >= 184 then
                                                if v347 >= 185 then
                                                    if v347 == 186 then
                                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] == u25[UNNAMED_2819735069192[u26]];
                                                    else
                                                        v57 = UNNAMED_2819735072456[u26];
                                                        v55 = UNNAMED_2819735050040[u26];
                                                        v53 = UNNAMED_2819735069192[u26];
                                                        v56 = v57 + v53 - 1;
                                                        v54 = v57 + v55;
                                                        v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                                        u37(v58, 1, v53, v57, u25);
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036168[u26] % u25[UNNAMED_2819735050040[u26]];
                                                end;
                                            elseif v347 >= 182 then
                                                if v347 == 183 then
                                                    u25[UNNAMED_2819735050040[u26]] = u23;
                                                elseif UNNAMED_2819735032328[u26] > u25[UNNAMED_2819735050040[u26]] then
                                                    u26 = UNNAMED_2819735072456[u26];
                                                end;
                                            else
                                                v57 = UNNAMED_2819735050040[u26];
                                                local v491 = u25[UNNAMED_2819735069192[u26]];
                                                u25[v57] = u25[UNNAMED_2819735072456[u26]];
                                                u25[v57 + 1] = v491;
                                            end;
                                        elseif v347 >= 190 then
                                            if v347 < 192 then
                                                if v347 == 191 then
                                                    v57 = UNNAMED_2819735072456[u26];
                                                    local v492 = UNNAMED_2819735043176[u26];
                                                    u25[v57] = u25[UNNAMED_2819735069192[u26]];
                                                    u25[v57 + 1] = v492;
                                                else
                                                    v57 = UNNAMED_2819735069192[u26];
                                                    local v493 = u25[UNNAMED_2819735072456[u26]];
                                                    u25[v57] = UNNAMED_2819735043176[u26];
                                                    u25[v57 + 1] = v493;
                                                end;
                                            elseif v347 == 193 then
                                                u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735036168[u26], UNNAMED_2819735032328[u26]);
                                            else
                                                UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735043176[u26]] = UNNAMED_2819735032328[u26];
                                            end;
                                        elseif v347 < 188 then
                                            if u25[UNNAMED_2819735072456[u26]] >= u25[UNNAMED_2819735069192[u26]] then
                                                u26 = UNNAMED_2819735050040[u26];
                                            end;
                                        elseif v347 == 189 then
                                            u25[UNNAMED_2819735072456[u26]](u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n));
                                        else
                                            v57 = UNNAMED_2819735050040[u26];
                                            v55 = UNNAMED_2819735069192[u26];
                                            v53 = UNNAMED_2819735072456[u26];
                                            v56 = u25[v57];
                                            v54 = v57 + v55;
                                            v58 = u25[v54];
                                            u37(u25, v57 + 1, v54 - 1, v53 + 1, v56);
                                            u37(v58, 1, v58.n, v53 + v55, v56);
                                        end;
                                    elseif v347 >= 168 then
                                        if v347 >= 174 then
                                            if v347 >= 177 then
                                                if v347 < 179 then
                                                    if v347 == 178 then
                                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] <= UNNAMED_2819735069192[u26];
                                                    else
                                                        u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735050040[u26]];
                                                    end;
                                                elseif v347 == 180 then
                                                    local v494 = UNNAMED_2819735069192[u26];
                                                    local v495 = UNNAMED_2819735050040[u26];
                                                    local v496, v497 = u25[UNNAMED_2819735072456[u26]]();
                                                    u25[v494] = v496;
                                                    u25[v495] = v497;
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] // u25[UNNAMED_2819735069192[u26]];
                                                end;
                                            elseif v347 >= 175 then
                                                if v347 == 176 then
                                                    local v498 = u33;
                                                    local v499 = u34;

                                                    if v498 then
                                                        for i in u36, v498 do
                                                            local v500 = v498[i];

                                                            if v500 then
                                                                v500[5] = v500;
                                                                v500[6] = u25[i];
                                                                v500[4] = 6;
                                                                v498[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v499 then
                                                        for i, v in u36, v499 do
                                                            local v501 = v[6];

                                                            if v499 then
                                                                local v502 = v499[i];

                                                                if v502 then
                                                                    local v503 = u24(v501);
                                                                    u37(u25, i, i + v501 - 1, 1, v503);
                                                                    v502[5] = v503;
                                                                    v502[4] = 1;
                                                                    v499[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(UNNAMED_2819735032328[u26]);
                                                end;

                                                u25[UNNAMED_2819735069192[u26]] = u25;
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = u22;
                                            end;
                                        elseif v347 >= 171 then
                                            if v347 >= 172 then
                                                if v347 ~= 173 then
                                                    local v504 = u33;
                                                    local v505 = u34;

                                                    if v504 then
                                                        for i in u36, v504 do
                                                            local v506 = v504[i];

                                                            if v506 then
                                                                v506[5] = v506;
                                                                v506[6] = u25[i];
                                                                v506[4] = 6;
                                                                v504[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v505 then
                                                        for i, v in u36, v505 do
                                                            local v507 = v[6];

                                                            if v505 then
                                                                local v508 = v505[i];

                                                                if v508 then
                                                                    local v509 = u24(v507);
                                                                    u37(u25, i, i + v507 - 1, 1, v509);
                                                                    v508[5] = v509;
                                                                    v508[4] = 1;
                                                                    v505[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(UNNAMED_2819735043176[u26], UNNAMED_2819735032328[u26]);
                                                end;

                                                local v510 = UNNAMED_2819735069192[u26];
                                                local v511 = u25[UNNAMED_2819735050040[u26]];
                                                local v512 = u42(UNNAMED_2819735072456[u26], 4294967295);
                                                local v513 = u42(v511, 4294967295);
                                                local v514 = u42(v512, 65535);
                                                local v515 = u41(v512, 16);
                                                local v516 = u42(v513, 65535);
                                                local v517 = u41(v513, 16);
                                                local v518 = u42(v514 * v516 + u43(u42(v514 * v517 + v515 * v516, 65535), 16), 4294967295) % 4294967296;
                                                u25[v510] = v518 ~= v518 and 0 or v518 - v518 % 1;
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] <= UNNAMED_2819735032328[u26];
                                            end;
                                        elseif v347 >= 169 then
                                            if v347 == 170 then
                                                u28 = {
                                                    [6] = u32,
                                                    [5] = u30,
                                                    [9] = u28,
                                                    [8] = u29,
                                                    [7] = u31
                                                };
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = u47(u48);
                                                v55(UNNAMED_2819735031272, u25[v57], u25[v57 + 1], u25[v57 + 2]);
                                                u29 = v55;
                                                u32 = UNNAMED_2819735050040[u26];
                                                u26 = UNNAMED_2819735069192[u26];
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735069192[u26]]());
                                            end;
                                        else
                                            u45[UNNAMED_2819735043176[u26]][u25[UNNAMED_2819735069192[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    elseif v347 < 161 then
                                        if v347 < 158 then
                                            if v347 < 156 then
                                                v57 = UNNAMED_2819735050040[u26];
                                                v55 = UNNAMED_2819735072456[u26];
                                                v53 = UNNAMED_2819735069192[u26];
                                                v56 = u25[v57];
                                                u37(u25, v57 + 1, v57 + v55, v53 + 1, v56);
                                            else
                                                if v347 == 157 then
                                                    local v519 = u33;
                                                    local v520 = u34;

                                                    if v519 then
                                                        for i in u36, v519 do
                                                            local v521 = v519[i];

                                                            if v521 then
                                                                v521[5] = v521;
                                                                v521[6] = u25[i];
                                                                v521[4] = 6;
                                                                v519[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v520 then
                                                        for i, v in u36, v520 do
                                                            local v522 = v[6];

                                                            if v520 then
                                                                local v523 = v520[i];

                                                                if v523 then
                                                                    local v524 = u24(v522);
                                                                    u37(u25, i, i + v522 - 1, 1, v524);
                                                                    v523[5] = v524;
                                                                    v523[4] = 1;
                                                                    v520[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735043176[u26]);
                                                end;

                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = UNNAMED_2819735050040[u26];
                                                v53 = UNNAMED_2819735069192[u26];
                                                v56 = v57 + v55;
                                                u25[v57] = u38(u25[v57](u35(u25, v57 + 1, v56)));
                                            end;
                                        elseif v347 >= 159 then
                                            if v347 == 160 then
                                                v57 = UNNAMED_2819735069192[u26];
                                                v55 = UNNAMED_2819735072456[u26];
                                                v53 = UNNAMED_2819735050040[u26];
                                                v56 = v57 + v55;
                                                v54 = u25[v56];
                                                v58 = v54.n;
                                                v54.n = v55 + v58 - 1;
                                                u37(v54, 1, v58, v55, v54);
                                                u37(u25, v57 + 1, v56 - 1, 1, v54);
                                                u25[v57] = u38(u25[v57](u35(v54, 1, v54.n)));
                                            else
                                                u45[UNNAMED_2819735032328[u26]] = UNNAMED_2819735043176[u26];
                                            end;
                                        else
                                            u29 = u28[8];
                                            u30 = u28[5];
                                            u31 = u28[7];
                                            u32 = u28[6];
                                            u28 = u28[9];
                                        end;
                                    elseif v347 >= 164 then
                                        if v347 >= 166 then
                                            if v347 ~= 167 then
                                                local v525 = u33;
                                                local v526 = u34;

                                                if v525 then
                                                    for i in u36, v525 do
                                                        local v527 = v525[i];

                                                        if v527 then
                                                            v527[5] = v527;
                                                            v527[6] = u25[i];
                                                            v527[4] = 6;
                                                            v525[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v526 then
                                                    for i, v in u36, v526 do
                                                        local v528 = v[6];

                                                        if v526 then
                                                            local v529 = v526[i];

                                                            if v529 then
                                                                local v530 = u24(v528);
                                                                u37(u25, i, i + v528 - 1, 1, v530);
                                                                v529[5] = v530;
                                                                v529[4] = 1;
                                                                v526[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u38(u25[UNNAMED_2819735069192[u26]]);
                                            end;

                                            if UNNAMED_2819735032328[u26] >= u25[UNNAMED_2819735072456[u26]] then
                                                u26 = UNNAMED_2819735050040[u26];
                                            end;
                                        elseif v347 == 165 then
                                            local v531 = UNNAMED_2819735050040[u26];
                                            local v532 = UNNAMED_2819735032328[u26];
                                            local v533 = u42(u25[UNNAMED_2819735072456[u26]], 4294967295);
                                            local v534 = u42(v532, 4294967295);
                                            local v535 = u42(v533, 65535);
                                            local v536 = u41(v533, 16);
                                            local v537 = u42(v534, 65535);
                                            local v538 = u41(v534, 16);
                                            local v539 = u42(v535 * v537 + u43(u42(v535 * v538 + v536 * v537, 65535), 16), 4294967295) % 4294967296;
                                            u25[v531] = v539 ~= v539 and 0 or v539 - v539 % 1;
                                        else
                                            u45[UNNAMED_2819735043176[u26]] = u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    elseif v347 >= 162 then
                                        if v347 == 163 then
                                            u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735050040[u26]](u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n)));
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] + UNNAMED_2819735050040[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] / UNNAMED_2819735032328[u26];
                                    end;

                                    v346 = 1;
                                    continue;
                                end;

                                if v347 < 129 then
                                    if v347 < 116 then
                                        if v347 < 109 then
                                            if v347 >= 106 then
                                                if v347 >= 107 then
                                                    if v347 ~= 108 then
                                                        local v540 = u33;
                                                        local v541 = u34;

                                                        if v540 then
                                                            for i in u36, v540 do
                                                                local v542 = v540[i];

                                                                if v542 then
                                                                    v542[5] = v542;
                                                                    v542[6] = u25[i];
                                                                    v542[4] = 6;
                                                                    v540[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v541 then
                                                            for i, v in u36, v541 do
                                                                local v543 = v[6];

                                                                if v541 then
                                                                    local v544 = v541[i];

                                                                    if v544 then
                                                                        local v545 = u24(v543);
                                                                        u37(u25, i, i + v543 - 1, 1, v545);
                                                                        v544[5] = v545;
                                                                        v544[4] = 1;
                                                                        v541[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u25[UNNAMED_2819735050040[u26]];
                                                    end;

                                                    u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819735036168[u26];
                                                else
                                                    UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][u25[UNNAMED_2819735050040[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                                end;
                                            elseif v347 < 104 then
                                                u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819735031272[UNNAMED_2819735072456[u26]];
                                            else
                                                if v347 ~= 105 then
                                                    local v546 = u33;
                                                    local v547 = u34;

                                                    if v546 then
                                                        for i in u36, v546 do
                                                            local v548 = v546[i];

                                                            if v548 then
                                                                v548[5] = v548;
                                                                v548[6] = u25[i];
                                                                v548[4] = 6;
                                                                v546[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v547 then
                                                        for i, v in u36, v547 do
                                                            local v549 = v[6];

                                                            if v547 then
                                                                local v550 = v547[i];

                                                                if v550 then
                                                                    local v551 = u24(v549);
                                                                    u37(u25, i, i + v549 - 1, 1, v551);
                                                                    v550[5] = v551;
                                                                    v550[4] = 1;
                                                                    v547[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, false;
                                                end;

                                                v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                                v57[5][v57[4]] = u25[UNNAMED_2819735072456[u26]];
                                            end;
                                        elseif v347 < 112 then
                                            if v347 >= 110 then
                                                if v347 == 111 then
                                                    u25[UNNAMED_2819735050040[u26]] = u45[UNNAMED_2819735032328[u26]][UNNAMED_2819735036168[u26]];
                                                elseif u25[UNNAMED_2819735069192[u26]] > u25[UNNAMED_2819735050040[u26]] then
                                                    u26 = UNNAMED_2819735072456[u26];
                                                end;
                                            else
                                                u29 = u29 + u31;

                                                if u31 <= 0 then
                                                    v57 = u30 <= u29;
                                                else
                                                    v57 = u29 <= u30;
                                                end;

                                                if v57 then
                                                    u25[UNNAMED_2819735072456[u26]] = u29;
                                                    u26 = UNNAMED_2819735069192[u26];
                                                else
                                                    u26 = UNNAMED_2819735050040[u26];
                                                end;
                                            end;
                                        elseif v347 < 114 then
                                            if v347 == 113 then
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]][UNNAMED_2819735069192[u26]];
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] <= u25[UNNAMED_2819735050040[u26]];
                                            end;
                                        elseif v347 == 115 then
                                            u25[UNNAMED_2819735069192[u26]] = u39(u25[UNNAMED_2819735050040[u26]], UNNAMED_2819735036168[u26]);
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735032328[u26]));
                                        end;
                                    elseif v347 < 122 then
                                        if v347 >= 119 then
                                            if v347 < 120 then
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]]();
                                            elseif v347 == 121 then
                                                if u25[UNNAMED_2819735069192[u26]] > UNNAMED_2819735043176[u26] then
                                                    u26 = UNNAMED_2819735072456[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735069192[u26]][UNNAMED_2819735043176[u26]] = UNNAMED_2819735072456[u26];
                                            end;
                                        elseif v347 >= 117 then
                                            if v347 == 118 then
                                                local v552;

                                                if u25[UNNAMED_2819735050040[u26]] then
                                                    v552 = UNNAMED_2819735072456[u26];
                                                else
                                                    v552 = UNNAMED_2819735069192[u26];
                                                end;

                                                u26 = v552;
                                            elseif u25[UNNAMED_2819735050040[u26]] ~= UNNAMED_2819735032328[u26] then
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        else
                                            v57 = UNNAMED_2819735072456[u26];
                                            local v553 = UNNAMED_2819735032328[u26];
                                            u25[v57] = UNNAMED_2819735050040[u26];
                                            u25[v57 + 1] = v553;
                                        end;
                                    elseif v347 >= 125 then
                                        if v347 < 127 then
                                            if v347 == 126 then
                                                local v554 = u33;
                                                local v555 = u34;

                                                if v554 then
                                                    for i in u36, v554 do
                                                        local v556 = v554[i];

                                                        if v556 then
                                                            v556[5] = v556;
                                                            v556[6] = u25[i];
                                                            v556[4] = 6;
                                                            v554[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v555 then
                                                    for i, v in u36, v555 do
                                                        local v557 = v[6];

                                                        if v555 then
                                                            local v558 = v555[i];

                                                            if v558 then
                                                                local v559 = u24(v557);
                                                                u37(u25, i, i + v557 - 1, 1, v559);
                                                                v558[5] = v559;
                                                                v558[4] = 1;
                                                                v555[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735050040[u26], u38(UNNAMED_2819735036168[u26], u25[UNNAMED_2819735069192[u26]]);
                                            end;

                                            u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735069192[u26]] ~= UNNAMED_2819735036168[u26];
                                        elseif v347 == 128 then
                                            v57 = UNNAMED_2819735050040[u26];
                                            local v560 = UNNAMED_2819735032328[u26];
                                            u25[v57] = UNNAMED_2819735036168[u26];
                                            u25[v57 + 1] = v560;
                                        else
                                            local v561 = nil;
                                            local v562 = UNNAMED_2819735069192[u26];
                                            local v563 = UNNAMED_2819735036168[u26];
                                            local v564 = UNNAMED_2819735043176[u26];
                                            local v565 = u33;
                                            local v566 = u34;
                                            local v567 = v564[0];

                                            if v567 then
                                                local v568 = #v567 / 3;

                                                if v568 > 0 then
                                                    v561 = {};

                                                    for i = 1, v568 do
                                                        local v569 = (i - 1) * 3;
                                                        local v570 = v567[v569 + 2];
                                                        local v571 = v567[v569 + 1];
                                                        local v572;

                                                        if v570 == 2 then
                                                            v565 = v565 or {};
                                                            local v573 = v565[v571];

                                                            if not v573 then
                                                                v573 = {
                                                                    [5] = u25,
                                                                    [4] = v571
                                                                };
                                                                v565[v571] = v573;
                                                            end;

                                                            v561[i] = v573;
                                                            v572 = i;
                                                        elseif v570 == 0 then
                                                            v561[i] = u25[v571];
                                                            v572 = i;
                                                        elseif v570 == 3 then
                                                            v561[i] = UNNAMED_2819769586744[v571];
                                                            v572 = i;
                                                        elseif v570 == 1 then
                                                            v566 = v566 or {};
                                                            local v574 = v566[v571];

                                                            if not v574 then
                                                                v574 = {
                                                                    [5] = u25,
                                                                    [4] = v571,
                                                                    [6] = v567[v569 + 3]
                                                                };
                                                                v566[v571] = v574;
                                                            end;

                                                            v561[i] = v574;
                                                            v572 = i;
                                                        else
                                                            v572 = i;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            local v575 = v564[-2];
                                            v564[v575] = v561;
                                            local v576 = v563(u35(v564, 1, v564[-1]));
                                            v564[v575] = nil;
                                            u25[v562] = v576;
                                            u33 = v565;
                                            u34 = v566;
                                        end;
                                    elseif v347 >= 123 then
                                        if v347 == 124 then
                                            u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] * UNNAMED_2819735050040[u26];
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u39(UNNAMED_2819735043176[u26], u25[UNNAMED_2819735069192[u26]]);
                                        end;
                                    elseif u33 then
                                        local v577 = u33;
                                        local v578 = UNNAMED_2819735072456[u26];
                                        local v579 = v577[v578];

                                        if v579 then
                                            v579[5] = v579;
                                            v579[6] = u25[v578];
                                            v579[4] = 6;
                                            v577[v578] = nil;
                                        end;

                                        local v580 = u33;
                                        local v581 = UNNAMED_2819735069192[u26];
                                        local v582 = v580[v581];

                                        if v582 then
                                            v582[5] = v582;
                                            v582[6] = u25[v581];
                                            v582[4] = 6;
                                            v580[v581] = nil;
                                        end;
                                    end;
                                else
                                    if v347 >= 142 then
                                        if v347 < 148 then
                                            if v347 < 145 then
                                                if v347 < 143 then
                                                    if u25[UNNAMED_2819735069192[u26]] > UNNAMED_2819735072456[u26] then
                                                        u26 = UNNAMED_2819735050040[u26];
                                                    end;
                                                elseif v347 == 144 then
                                                    u25[UNNAMED_2819735050040[u26]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735069192[u26]];
                                                else
                                                    v57 = u39(u22, u42(u41(u22, 14), 262143), (u42(u41(u22, 28), 15)));
                                                    v55 = UNNAMED_2819735050040[u26];
                                                    v53 = UNNAMED_2819735069192[u26];
                                                    v56 = UNNAMED_2819735072456[u26];
                                                    v54 = v55 < 2097152 and 7 or 14;
                                                    v58 = u42(v55, u43(1, v54) - 1);
                                                    local v583 = u41(v55, v54);
                                                    UNNAMED_2819735072456[u26] = u39(v56, 67, (u42(u41(v57, 7), 127)));
                                                    UNNAMED_2819735036840[u26] = u39(v583, 121, (u42(u41(v57, 21), 127)));
                                                    UNNAMED_2819735069192[u26] = u39(v53, 3, (u42(v57, 127)));
                                                    UNNAMED_2819735050040[u26] = u39(v58, 31, (u42(u41(v57, 14), 127)));
                                                    u26 = u26 - 1;
                                                end;
                                            elseif v347 < 146 then
                                                v57 = UNNAMED_2819769586744[UNNAMED_2819735050040[u26]];
                                                v57[5][v57[4]][UNNAMED_2819735032328[u26]] = UNNAMED_2819735036168[u26];
                                            elseif v347 == 147 then
                                                u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735032328[u26], u25[UNNAMED_2819735072456[u26]]);
                                            else
                                                v57 = UNNAMED_2819735072456[u26];
                                                local v584 = UNNAMED_2819735069192[u26];
                                                u25[v57] = u25[UNNAMED_2819735050040[u26]];
                                                u25[v57 + 1] = v584;
                                            end;
                                        elseif v347 < 151 then
                                            if v347 < 149 then
                                                if u25[UNNAMED_2819735069192[u26]] >= UNNAMED_2819735072456[u26] then
                                                    u26 = UNNAMED_2819735050040[u26];
                                                end;
                                            elseif v347 == 150 then
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735050040[u26] / u25[UNNAMED_2819735069192[u26]];
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735069192[u26];
                                            end;
                                        elseif v347 >= 153 then
                                            if v347 == 154 then
                                                u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735050040[u26]], UNNAMED_2819735036168[u26]);
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] == UNNAMED_2819735043176[u26];
                                            end;
                                        elseif v347 == 152 then
                                            UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735043176[u26]] = UNNAMED_2819735069192[u26];
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = u39(u25[UNNAMED_2819735069192[u26]], u25[UNNAMED_2819735072456[u26]]);
                                        end;

                                        v346 = 1;
                                        continue;
                                    end;

                                    if v347 >= 135 then
                                        if v347 < 138 then
                                            if v347 >= 136 then
                                                if v347 == 137 then
                                                    u25[UNNAMED_2819735072456[u26]] = u43(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735050040[u26]);
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u45[UNNAMED_2819735043176[u26]][u25[UNNAMED_2819735069192[u26]]];
                                                end;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]];
                                            end;
                                        elseif v347 >= 140 then
                                            if v347 == 141 then
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] / u25[UNNAMED_2819735050040[u26]];
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26] + UNNAMED_2819735043176[u26];
                                            end;
                                        elseif v347 == 139 then
                                            u25[UNNAMED_2819735069192[u26]][UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]];
                                        elseif u33 then
                                            local v585 = u33;
                                            local v586 = UNNAMED_2819735050040[u26];
                                            local v587 = v585[v586];

                                            if v587 then
                                                v587[5] = v587;
                                                v587[6] = u25[v586];
                                                v587[4] = 6;
                                                v585[v586] = nil;
                                            end;

                                            local v588 = u33;
                                            local v589 = UNNAMED_2819735069192[u26];
                                            local v590 = v588[v589];

                                            if v590 then
                                                v590[5] = v590;
                                                v590[6] = u25[v589];
                                                v590[4] = 6;
                                                v588[v589] = nil;
                                            end;

                                            local v591 = u33;
                                            local v592 = UNNAMED_2819735072456[u26];
                                            local v593 = v591[v592];

                                            if v593 then
                                                v593[5] = v593;
                                                v593[6] = u25[v592];
                                                v593[4] = 6;
                                                v591[v592] = nil;
                                            end;
                                        end;
                                    elseif v347 >= 132 then
                                        if v347 < 133 then
                                            u25[UNNAMED_2819735050040[u26]] = u24(UNNAMED_2819735069192[u26]);
                                        elseif v347 == 134 then
                                            local v594 = UNNAMED_2819735069192[u26];
                                            local v595 = UNNAMED_2819735036168[u26];
                                            local v596 = u42(UNNAMED_2819735050040[u26], 4294967295);
                                            local v597 = u42(v595, 4294967295);
                                            local v598 = u42(v596, 65535);
                                            local v599 = u41(v596, 16);
                                            local v600 = u42(v597, 65535);
                                            local v601 = u41(v597, 16);
                                            local v602 = u42(v598 * v600 + u43(u42(v598 * v601 + v599 * v600, 65535), 16), 4294967295) % 4294967296;
                                            u25[v594] = v602 ~= v602 and 0 or v602 - v602 % 1;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] - UNNAMED_2819735032328[u26];
                                        end;
                                    else
                                        if v347 < 130 then
                                            u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735050040[u26]], u25[UNNAMED_2819735072456[u26]]);
                                            v346 = 1;
                                            continue;
                                        end;

                                        if v347 == 131 then
                                            u27 = UNNAMED_2819735072456[u26];
                                            u26 = UNNAMED_2819735050040[u26] + 1;
                                            v59 = 3;
                                            break;
                                        end;

                                        u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735036168[u26]);
                                    end;
                                end;
                            end;

                            v346 = 1;
                            continue;
                        elseif v346 == 1 then
                            v346 = -1;
                            u26 = u26 + 1;
                            break;
                        else
                            break;
                        end;
                    end;

                    if v59 ~= -1 then
                        break;
                    end;
                end;

                if v59 ~= -1 then
                    continue;
                end;

                v59 = 5;
                continue;
            elseif v59 == 5 then
                v59 = -1;

                while true do
                    local u26;
                    local v603 = 0;

                    while true do
                        if v603 == 0 then
                            v603 = -1;
                            local v604 = UNNAMED_2819735050040[u26];

                            if v604 < 95 then
                                if v604 < 47 then
                                    if v604 < 23 then
                                        if v604 >= 11 then
                                            if v604 >= 17 then
                                                if v604 >= 20 then
                                                    if v604 < 21 then
                                                        u25[UNNAMED_2819735036840[u26]] = not u25[UNNAMED_2819735072456[u26]];
                                                    else
                                                        if v604 ~= 22 then
                                                            local v605 = u33;
                                                            local v606 = u34;

                                                            if v605 then
                                                                for i in u36, v605 do
                                                                    local v607 = v605[i];

                                                                    if v607 then
                                                                        v607[5] = v607;
                                                                        v607[6] = u25[i];
                                                                        v607[4] = 6;
                                                                        v605[i] = nil;
                                                                    end;
                                                                end;
                                                            end;

                                                            if v606 then
                                                                for i, v in u36, v606 do
                                                                    local v608 = v[6];

                                                                    if v606 then
                                                                        local v609 = v606[i];

                                                                        if v609 then
                                                                            local v610 = u24(v608);
                                                                            u37(u25, i, i + v608 - 1, 1, v610);
                                                                            v609[5] = v610;
                                                                            v609[4] = 1;
                                                                            v606[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;
                                                            end;

                                                            return true, true, UNNAMED_2819735072456[u26], u38(UNNAMED_2819735067512[u26], u25[UNNAMED_2819735069192[u26]]);
                                                        end;

                                                        v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                                        v57[5][v57[4]] = u25[UNNAMED_2819735072456[u26]];
                                                    end;
                                                elseif v604 < 18 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] == UNNAMED_2819735036840[u26];
                                                elseif v604 == 19 then
                                                    u25[UNNAMED_2819735069192[u26]] = u39(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735036168[u26]);
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] < u25[UNNAMED_2819735069192[u26]];
                                                end;
                                            elseif v604 < 14 then
                                                if v604 >= 12 then
                                                    if v604 == 13 then
                                                        u45[UNNAMED_2819735032328[u26]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735067512[u26];
                                                    else
                                                        u26 = u25[UNNAMED_2819735036840[u26]];
                                                    end;
                                                else
                                                    v57 = UNNAMED_2819735072456[u26];
                                                    v55 = u25[UNNAMED_2819735069192[u26]];
                                                    u25[v57 + 1] = v55;
                                                    u25[v57] = v55[UNNAMED_2819735067512[u26]];
                                                end;
                                            elseif v604 < 15 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55, v53, v56 = u29();

                                                if v55 then
                                                    u25[v57] = v53;
                                                    u25[v57 + 1] = v56;
                                                    u26 = UNNAMED_2819735069192[u26];
                                                else
                                                    u26 = UNNAMED_2819735036840[u26];
                                                end;
                                            elseif v604 == 16 then
                                                v57 = UNNAMED_2819735069192[u26];
                                                v55 = UNNAMED_2819735072456[u26];
                                                v53 = UNNAMED_2819735036840[u26];
                                                v56 = u39(u22, u42(u41(u22, 14), 262143), (u42(u41(u22, 28), 15)));
                                                v54 = v55 < 2097152 and 7 or 14;
                                                v58 = u42(v55, u43(1, v54) - 1);
                                                local v611 = u41(v55, v54);
                                                UNNAMED_2819735072456[u26] = u39(v58, 9, (u42(u41(v56, 7), 127)));
                                                UNNAMED_2819735036840[u26] = u39(v53, 109, (u42(u41(v56, 14), 127)));
                                                UNNAMED_2819735069192[u26] = u39(v57, 42, (u42(v56, 127)));
                                                UNNAMED_2819735050040[u26] = u39(v611, 126, (u42(u41(v56, 21), 127)));
                                                u26 = u26 - 1;
                                            else
                                                v57 = UNNAMED_2819735036840[u26];
                                                local v612 = UNNAMED_2819735032328[u26];
                                                u25[v57] = UNNAMED_2819735072456[u26];
                                                u25[v57 + 1] = v612;
                                            end;
                                        elseif v604 >= 5 then
                                            if v604 < 8 then
                                                if v604 >= 6 then
                                                    if v604 == 7 then
                                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]] > UNNAMED_2819735036168[u26];
                                                    else
                                                        u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735032328[u26], u25[UNNAMED_2819735036840[u26]]);
                                                    end;
                                                else
                                                    u23 = u25[UNNAMED_2819735036840[u26]];
                                                end;
                                            elseif v604 < 9 then
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]] / UNNAMED_2819735072456[u26];
                                            else
                                                if v604 == 10 then
                                                    local v613 = u33;
                                                    local v614 = u34;

                                                    if v613 then
                                                        for i in u36, v613 do
                                                            local v615 = v613[i];

                                                            if v615 then
                                                                v615[5] = v615;
                                                                v615[6] = u25[i];
                                                                v615[4] = 6;
                                                                v613[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v614 then
                                                        for i, v in u36, v614 do
                                                            local v616 = v[6];

                                                            if v614 then
                                                                local v617 = v614[i];

                                                                if v617 then
                                                                    local v618 = u24(v616);
                                                                    u37(u25, i, i + v616 - 1, 1, v618);
                                                                    v617[5] = v618;
                                                                    v617[4] = 1;
                                                                    v614[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, false;
                                                end;

                                                if u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735069192[u26] then
                                                    u26 = UNNAMED_2819735036840[u26];
                                                end;
                                            end;
                                        elseif v604 >= 2 then
                                            if v604 < 3 then
                                                v57 = UNNAMED_2819735036840[u26];
                                                local v619 = UNNAMED_2819735072456[u26];
                                                u25[v57] = u25[UNNAMED_2819735069192[u26]];
                                                u25[v57 + 1] = v619;
                                            elseif v604 == 4 then
                                                v57 = UNNAMED_2819735036840[u26];
                                                local v620 = u25[UNNAMED_2819735072456[u26]];
                                                u25[v57] = u25[UNNAMED_2819735069192[u26]];
                                                u25[v57 + 1] = v620;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735036840[u26]]];
                                            end;
                                        elseif v604 == 1 then
                                            v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                            v57[5][v57[4]] = UNNAMED_2819735036168[u26];
                                        else
                                            v57 = UNNAMED_2819735072456[u26];
                                            v55 = u25[UNNAMED_2819735069192[u26]];
                                            u25[v57 + 1] = v55;
                                            u25[v57] = v55[UNNAMED_2819735067512[u26]];
                                            u25[UNNAMED_2819735072456[u26 + 1]] = u25[UNNAMED_2819735069192[u26 + 1]];
                                            u25[UNNAMED_2819735072456[u26 + 2]] = UNNAMED_2819735067512[u26 + 2];
                                            u25[UNNAMED_2819735072456[u26 + 3]] = u25[UNNAMED_2819735069192[u26 + 3]];
                                            u26 = u26 + 3;
                                        end;
                                    elseif v604 >= 35 then
                                        if v604 >= 41 then
                                            if v604 < 44 then
                                                if v604 >= 42 then
                                                    if v604 == 43 then
                                                        v57 = UNNAMED_2819735069192[u26];
                                                        v55, v53 = u29();

                                                        if v55 then
                                                            u25[v57] = v53;
                                                            u26 = UNNAMED_2819735036840[u26];
                                                        else
                                                            u26 = UNNAMED_2819735072456[u26];
                                                        end;
                                                    else
                                                        u25[UNNAMED_2819735036840[u26]] = u46(u25[UNNAMED_2819735072456[u26]]);
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735072456;
                                                end;
                                            elseif v604 >= 45 then
                                                if v604 == 46 then
                                                    u25[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735069192[u26]]] = UNNAMED_2819735067512[u26];
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] - u25[UNNAMED_2819735069192[u26]];
                                                end;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]][UNNAMED_2819735036168[u26]];
                                            end;
                                        elseif v604 < 38 then
                                            if v604 < 36 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = UNNAMED_2819735036840[u26];
                                                v53 = UNNAMED_2819735069192[u26];
                                                v56 = v57 + v55;
                                                v54 = u25[v56];
                                                v58 = v54.n;
                                                v54.n = v55 + v58 - 1;
                                                u37(v54, 1, v58, v55, v54);
                                                u37(u25, v57 + 1, v56 - 1, 1, v54);
                                                u25[v57] = u38(u25[v57](u35(v54, 1, v54.n)));
                                            elseif v604 == 37 then
                                                v57 = UNNAMED_2819735036840[u26];
                                                v55 = UNNAMED_2819735072456[u26];
                                                v53 = UNNAMED_2819735069192[u26];
                                                v56 = u25[v57];
                                                u37(u25, v57 + 1, v57 + v55, v53 + 1, v56);
                                            elseif u25[UNNAMED_2819735069192[u26]] ~= UNNAMED_2819735036840[u26] then
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        elseif v604 >= 39 then
                                            if v604 == 40 then
                                                u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] .. u25[UNNAMED_2819735072456[u26]];
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] % u25[UNNAMED_2819735069192[u26]];
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26] + u25[UNNAMED_2819735036840[u26]];
                                        end;
                                    elseif v604 < 29 then
                                        if v604 < 26 then
                                            if v604 >= 24 then
                                                if v604 == 25 then
                                                    u45[UNNAMED_2819735036168[u26]][u25[UNNAMED_2819735069192[u26]]] = UNNAMED_2819735067512[u26];
                                                else
                                                    u25[UNNAMED_2819735036840[u26]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735069192[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] - UNNAMED_2819735032328[u26];
                                            end;
                                        elseif v604 < 27 then
                                            u25[UNNAMED_2819735036840[u26]] = u45[UNNAMED_2819735032328[u26]][u25[UNNAMED_2819735072456[u26]]];
                                        elseif v604 == 28 then
                                            if UNNAMED_2819735072456[u26] > u25[UNNAMED_2819735069192[u26]] then
                                                u26 = UNNAMED_2819735036840[u26];
                                            end;
                                        else
                                            v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                            u25[UNNAMED_2819735069192[u26]] = v57[5][v57[4]][UNNAMED_2819735067512[u26]];
                                        end;
                                    elseif v604 >= 32 then
                                        if v604 < 33 then
                                            u29 = u29 + u31;

                                            if u31 <= 0 then
                                                v57 = u30 <= u29;
                                            else
                                                v57 = u29 <= u30;
                                            end;

                                            if v57 then
                                                u25[UNNAMED_2819735036840[u26]] = u29;
                                                u26 = UNNAMED_2819735069192[u26];
                                            else
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        elseif v604 == 34 then
                                            u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735067512[u26];
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] / u25[UNNAMED_2819735036840[u26]];
                                        end;
                                    elseif v604 >= 30 then
                                        if v604 == 31 then
                                            local v621 = u33;
                                            local v622 = u34;

                                            if v621 then
                                                for i in u36, v621 do
                                                    local v623 = v621[i];

                                                    if v623 then
                                                        v623[5] = v623;
                                                        v623[6] = u25[i];
                                                        v623[4] = 6;
                                                        v621[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v622 then
                                                for i, v in u36, v622 do
                                                    local v624 = v[6];

                                                    if v622 then
                                                        local v625 = v622[i];

                                                        if v625 then
                                                            local v626 = u24(v624);
                                                            u37(u25, i, i + v624 - 1, 1, v626);
                                                            v625[5] = v626;
                                                            v625[4] = 1;
                                                            v622[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(u25[UNNAMED_2819735036840[u26]], u25[UNNAMED_2819735069192[u26]]);
                                        end;

                                        u25[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735036840[u26]]] = u25[UNNAMED_2819735069192[u26]];
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                    end;
                                elseif v604 >= 71 then
                                    if v604 >= 83 then
                                        if v604 < 89 then
                                            if v604 < 86 then
                                                if v604 >= 84 then
                                                    if v604 == 85 then
                                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] + UNNAMED_2819735067512[u26];
                                                    else
                                                        v57 = UNNAMED_2819735069192[u26];
                                                        v55 = UNNAMED_2819735036840[u26];
                                                        v53 = UNNAMED_2819735072456[u26];
                                                        v56 = v57 + v53 - 1;
                                                        v54 = v57 + v55;
                                                        v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                                        u37(v58, 1, v53, v57, u25);
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]] > UNNAMED_2819735072456[u26];
                                                end;
                                            elseif v604 < 87 then
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735067512[u26] .. u25[UNNAMED_2819735072456[u26]];
                                            elseif v604 == 88 then
                                                if UNNAMED_2819735067512[u26] >= u25[UNNAMED_2819735072456[u26]] then
                                                    u26 = UNNAMED_2819735069192[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = {};
                                            end;
                                        elseif v604 < 92 then
                                            if v604 < 90 then
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735071256;
                                            elseif v604 == 91 then
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] + UNNAMED_2819735069192[u26];
                                            elseif u25[UNNAMED_2819735069192[u26]] > UNNAMED_2819735067512[u26] then
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        elseif v604 >= 93 then
                                            if v604 == 94 then
                                                u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036840[u26] ^ u25[UNNAMED_2819735072456[u26]];
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u42(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735069192[u26]);
                                            end;
                                        else
                                            local v627 = UNNAMED_2819735036840[u26];
                                            local v628 = u25[UNNAMED_2819735072456[u26]];
                                            local v629 = u42(UNNAMED_2819735032328[u26], 4294967295);
                                            local v630 = u42(v628, 4294967295);
                                            local v631 = u42(v629, 65535);
                                            local v632 = u41(v629, 16);
                                            local v633 = u42(v630, 65535);
                                            local v634 = u41(v630, 16);
                                            local v635 = u42(v631 * v633 + u43(u42(v631 * v634 + v632 * v633, 65535), 16), 4294967295) % 4294967296;
                                            u25[v627] = v635 ~= v635 and 0 or v635 - v635 % 1;
                                        end;
                                    elseif v604 >= 77 then
                                        if v604 < 80 then
                                            if v604 >= 78 then
                                                if v604 == 79 then
                                                    if u33 then
                                                        local v636 = u33;
                                                        local v637 = UNNAMED_2819735069192[u26];
                                                        local v638 = v636[v637];

                                                        if v638 then
                                                            v638[5] = v638;
                                                            v638[6] = u25[v637];
                                                            v638[4] = 6;
                                                            v636[v637] = nil;
                                                        end;

                                                        local v639 = u33;
                                                        local v640 = UNNAMED_2819735072456[u26];
                                                        local v641 = v639[v640];

                                                        if v641 then
                                                            v641[5] = v641;
                                                            v641[6] = u25[v640];
                                                            v641[4] = 6;
                                                            v639[v640] = nil;
                                                        end;

                                                        local v642 = u33;
                                                        local v643 = UNNAMED_2819735036840[u26];
                                                        local v644 = v642[v643];

                                                        if v644 then
                                                            v644[5] = v644;
                                                            v644[6] = u25[v643];
                                                            v644[4] = 6;
                                                            v642[v643] = nil;
                                                        end;
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] % UNNAMED_2819735067512[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735032328[u26] * UNNAMED_2819735067512[u26];
                                            end;
                                        elseif v604 < 81 then
                                            u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]]();
                                        else
                                            if v604 == 82 then
                                                local v645 = u33;
                                                local v646 = u34;

                                                if v645 then
                                                    for i in u36, v645 do
                                                        local v647 = v645[i];

                                                        if v647 then
                                                            v647[5] = v647;
                                                            v647[6] = u25[i];
                                                            v647[4] = 6;
                                                            v645[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v646 then
                                                    for i, v in u36, v646 do
                                                        local v648 = v[6];

                                                        if v646 then
                                                            local v649 = v646[i];

                                                            if v649 then
                                                                local v650 = u24(v648);
                                                                u37(u25, i, i + v648 - 1, 1, v650);
                                                                v649[5] = v650;
                                                                v649[4] = 1;
                                                                v646[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735072456[u26], u38(UNNAMED_2819735067512[u26]);
                                            end;

                                            v57 = UNNAMED_2819735072456[u26];
                                            local v651 = UNNAMED_2819735067512[u26];
                                            u25[v57] = UNNAMED_2819735032328[u26];
                                            u25[v57 + 1] = v651;
                                        end;
                                    elseif v604 < 74 then
                                        if v604 < 72 then
                                            u22 = u25[UNNAMED_2819735069192[u26]];
                                        elseif v604 == 73 then
                                            local v652 = UNNAMED_2819735069192[u26];
                                            local v653 = u39(UNNAMED_2819735072456[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));
                                            local v654 = UNNAMED_2819735071256[5];
                                            local v655 = u39(v654[v652], 109162203);
                                            v654[v652] = v655;
                                            local v656 = UNNAMED_2819735071256[4];
                                            local v657 = v655 + 1;
                                            local v658 = u49(v656, v657);
                                            local v659;

                                            if v658 < 128 then
                                                v659 = v657 + 1;
                                            else
                                                local v660 = u49(v656, v657 + 1);

                                                if v660 < 128 then
                                                    v658 = v658 - 128 + v660 * 128;
                                                    v659 = v657 + 2;
                                                else
                                                    local v661 = u49(v656, v657 + 2);

                                                    if v661 < 128 then
                                                        v658 = v658 - 128 + (v660 - 128) * 16384 + v661 * 128;
                                                        v659 = v657 + 3;
                                                    else
                                                        local v662 = u49(v656, v657 + 3);
                                                        v658 = (v658 - 128) * 16384 + (v660 - 128) * 128 + (v661 - 128) + v662 % 128 * 2097152 + (v662 - v662 % 128) * 2097152;
                                                        v659 = v657 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v663 = v653 * 16843009;
                                            local v664 = v659 + v658;
                                            local v665 = v664 - v658 % 4;

                                            for i = v659, v665 - 1, 4 do
                                                u50(v656, i, (u39(u51(v656, i), v663)));
                                                local _ = i;
                                            end;

                                            for i = v665, v664 - 1 do
                                                u52(v656, i, (u39(u49(v656, i), v653)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735069192[u26] = 163;
                                            UNNAMED_2819735072456[u26] = 35;
                                            UNNAMED_2819735036840[u26] = 219;
                                            UNNAMED_2819735050040[u26] = 190;
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = u43(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735069192[u26]);
                                        end;
                                    else
                                        if v604 < 75 then
                                            local v666 = u33;
                                            local v667 = u34;

                                            if v666 then
                                                for i in u36, v666 do
                                                    local v668 = v666[i];

                                                    if v668 then
                                                        v668[5] = v668;
                                                        v668[6] = u25[i];
                                                        v668[4] = 6;
                                                        v666[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v667 then
                                                for i, v in u36, v667 do
                                                    local v669 = v[6];

                                                    if v667 then
                                                        local v670 = v667[i];

                                                        if v670 then
                                                            local v671 = u24(v669);
                                                            u37(u25, i, i + v669 - 1, 1, v671);
                                                            v670[5] = v671;
                                                            v670[4] = 1;
                                                            v667[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(u25[UNNAMED_2819735069192[u26]]);
                                        end;

                                        if v604 == 76 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]];
                                            u25[UNNAMED_2819735072456[u26 + 1]] = UNNAMED_2819735067512[u26 + 1];
                                            u25[UNNAMED_2819735072456[u26 + 2]] = u25[UNNAMED_2819735069192[u26 + 2]];
                                            v57 = UNNAMED_2819735069192[u26 + 3];
                                            v55 = u25[v57];
                                            v53 = u25[v57 + 1];
                                            v56 = u25[v57 + 2];
                                            u25[v57] = v55(v53, v56);
                                            u26 = u26 + 3;
                                        else
                                            u45[UNNAMED_2819735067512[u26]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    end;
                                elseif v604 < 59 then
                                    if v604 < 53 then
                                        if v604 < 50 then
                                            if v604 >= 48 then
                                                if v604 == 49 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] // UNNAMED_2819735069192[u26];
                                                else
                                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                                    u25[UNNAMED_2819735036840[u26]] = v57[5][v57[4]];
                                                end;
                                            else
                                                u26 = u25[UNNAMED_2819735072456[u26]];
                                            end;
                                        elseif v604 >= 51 then
                                            if v604 ~= 52 then
                                                local v672 = u33;
                                                local v673 = u34;

                                                if v672 then
                                                    for i in u36, v672 do
                                                        local v674 = v672[i];

                                                        if v674 then
                                                            v674[5] = v674;
                                                            v674[6] = u25[i];
                                                            v674[4] = 6;
                                                            v672[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v673 then
                                                    for i, v in u36, v673 do
                                                        local v675 = v[6];

                                                        if v673 then
                                                            local v676 = v673[i];

                                                            if v676 then
                                                                local v677 = u24(v675);
                                                                u37(u25, i, i + v675 - 1, 1, v677);
                                                                v676[5] = v677;
                                                                v676[4] = 1;
                                                                v673[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735072456[u26], u38(u25[UNNAMED_2819735069192[u26]]);
                                            end;

                                            v57 = UNNAMED_2819735036840[u26] + 1;
                                            v55 = UNNAMED_2819735069192[u26];

                                            for i = 1, UNNAMED_2819735072456[u26] do
                                                local v678 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                local v679 = u39(v678, (u41(v678, 13)));
                                                v55 = u42(u39(v679, (u43(v679, 14))), 536870911);
                                                UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                                UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                                UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 14), 127)));
                                                UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 21), 127)));
                                                v57 = v57 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735050040[u26] = 190;
                                        elseif UNNAMED_2819735036840[u26] >= u25[UNNAMED_2819735072456[u26]] then
                                            u26 = UNNAMED_2819735069192[u26];
                                        end;
                                    elseif v604 < 56 then
                                        if v604 < 54 then
                                            u45[UNNAMED_2819735032328[u26]][u25[UNNAMED_2819735036840[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                        elseif v604 == 55 then
                                            u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735069192[u26] - u25[UNNAMED_2819735036840[u26]];
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735036840;
                                        end;
                                    elseif v604 < 57 then
                                        if u25[UNNAMED_2819735036840[u26]] > u25[UNNAMED_2819735072456[u26]] then
                                            u26 = UNNAMED_2819735069192[u26];
                                        end;
                                    elseif v604 == 58 then
                                        u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735036840[u26]]);
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]][UNNAMED_2819735032328[u26]];
                                    end;
                                elseif v604 < 65 then
                                    if v604 < 62 then
                                        if v604 < 60 then
                                            u25[UNNAMED_2819735072456[u26]]();
                                        elseif v604 == 61 then
                                            local v680 = UNNAMED_2819735072456[u26];
                                            local v681 = u25[UNNAMED_2819735069192[u26]];
                                            u25[v680 + 1] = v681;
                                            u25[v680] = v681[UNNAMED_2819735067512[u26]];
                                            u25[UNNAMED_2819735072456[u26 + 1]] = u25[UNNAMED_2819735069192[u26 + 1]];
                                            u25[UNNAMED_2819735072456[u26 + 2]] = UNNAMED_2819735067512[u26 + 2];
                                            u25[UNNAMED_2819735072456[u26 + 3]] = u25[UNNAMED_2819735069192[u26 + 3]];
                                            v57 = UNNAMED_2819735069192[u26 + 4];
                                            v55 = u25[v57];
                                            v53 = u25[v57 + 1];
                                            v56 = u25[v57 + 2];
                                            u25[v57] = v55(v53, v56);
                                            u26 = u26 + 4;
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735069192;
                                        end;
                                    else
                                        if v604 < 63 then
                                            local v682 = u33;
                                            local v683 = u34;

                                            if v682 then
                                                for i in u36, v682 do
                                                    local v684 = v682[i];

                                                    if v684 then
                                                        v684[5] = v684;
                                                        v684[6] = u25[i];
                                                        v684[4] = 6;
                                                        v682[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v683 then
                                                for i, v in u36, v683 do
                                                    local v685 = v[6];

                                                    if v683 then
                                                        local v686 = v683[i];

                                                        if v686 then
                                                            local v687 = u24(v685);
                                                            u37(u25, i, i + v685 - 1, 1, v687);
                                                            v686[5] = v687;
                                                            v686[4] = 1;
                                                            v683[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(u25[UNNAMED_2819735072456[u26]], u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n));
                                        end;

                                        if v604 == 64 then
                                            u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] ~= UNNAMED_2819735036840[u26];
                                        else
                                            u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735032328[u26]);
                                        end;
                                    end;
                                elseif v604 >= 68 then
                                    if v604 < 69 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] * UNNAMED_2819735067512[u26];
                                    elseif v604 == 70 then
                                        u25[UNNAMED_2819735069192[u26]] = u40(u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735036840[u26]]);
                                    else
                                        u25[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735036840[u26]]] = UNNAMED_2819735069192[u26];
                                    end;
                                elseif v604 < 66 then
                                    UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735036840[u26];
                                elseif v604 == 67 then
                                    u25[UNNAMED_2819735072456[u26]] = u39(u25[UNNAMED_2819735069192[u26]], UNNAMED_2819735036840[u26]);
                                else
                                    local v688 = UNNAMED_2819735069192[u26];
                                    local v689 = u25[UNNAMED_2819735036840[u26]];
                                    local v690 = u42(u25[UNNAMED_2819735072456[u26]], 4294967295);
                                    local v691 = u42(v689, 4294967295);
                                    local v692 = u42(v690, 65535);
                                    local v693 = u41(v690, 16);
                                    local v694 = u42(v691, 65535);
                                    local v695 = u41(v691, 16);
                                    local v696 = u42(v692 * v694 + u43(u42(v692 * v695 + v693 * v694, 65535), 16), 4294967295) % 4294967296;
                                    u25[v688] = v696 ~= v696 and 0 or v696 - v696 % 1;
                                end;
                            elseif v604 < 143 then
                                if v604 < 119 then
                                    if v604 >= 107 then
                                        if v604 >= 113 then
                                            if v604 < 116 then
                                                if v604 < 114 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] // u25[UNNAMED_2819735069192[u26]];
                                                elseif v604 == 115 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] ~= u25[UNNAMED_2819735036840[u26]];
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735067512[u26];
                                                    u25[UNNAMED_2819735072456[u26 + 1]] = u25[UNNAMED_2819735069192[u26 + 1]];
                                                    v57 = UNNAMED_2819735069192[u26 + 2];
                                                    v55 = u25[v57];
                                                    v53 = u25[v57 + 1];
                                                    v56 = u25[v57 + 2];
                                                    u25[v57] = v55(v53, v56);
                                                    u26 = u26 + 2;
                                                end;
                                            elseif v604 < 117 then
                                                UNNAMED_2819769586744[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735069192[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                            elseif v604 == 118 then
                                                local v697;

                                                if u25[UNNAMED_2819735072456[u26]] then
                                                    v697 = UNNAMED_2819735069192[u26];
                                                else
                                                    v697 = UNNAMED_2819735036840[u26];
                                                end;

                                                u26 = v697;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u41(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735072456[u26]);
                                            end;
                                        elseif v604 < 110 then
                                            if v604 >= 108 then
                                                if v604 ~= 109 then
                                                    local v698 = u33;
                                                    local v699 = u34;

                                                    if v698 then
                                                        for i in u36, v698 do
                                                            local v700 = v698[i];

                                                            if v700 then
                                                                v700[5] = v700;
                                                                v700[6] = u25[i];
                                                                v700[4] = 6;
                                                                v698[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v699 then
                                                        for i, v in u36, v699 do
                                                            local v701 = v[6];

                                                            if v699 then
                                                                local v702 = v699[i];

                                                                if v702 then
                                                                    local v703 = u24(v701);
                                                                    u37(u25, i, i + v701 - 1, 1, v703);
                                                                    v702[5] = v703;
                                                                    v702[4] = 1;
                                                                    v699[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(UNNAMED_2819735067512[u26], UNNAMED_2819735032328[u26]);
                                                end;

                                                u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735050040;
                                            else
                                                v57 = UNNAMED_2819735072456[u26];
                                                local v704 = UNNAMED_2819735036840[u26];
                                                u25[v57] = UNNAMED_2819735069192[u26];
                                                u25[v57 + 1] = v704;
                                            end;
                                        elseif v604 >= 111 then
                                            if v604 == 112 then
                                                UNNAMED_2819769586744[UNNAMED_2819735069192[u26]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735036840[u26]];
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735032328[u26]);
                                            end;
                                        elseif u33 then
                                            local v705 = u33;
                                            local v706 = UNNAMED_2819735069192[u26];
                                            local v707 = v705[v706];

                                            if v707 then
                                                v707[5] = v707;
                                                v707[6] = u25[v706];
                                                v707[4] = 6;
                                                v705[v706] = nil;
                                            end;

                                            local v708 = u33;
                                            local v709 = UNNAMED_2819735036840[u26];
                                            local v710 = v708[v709];

                                            if v710 then
                                                v710[5] = v710;
                                                v710[6] = u25[v709];
                                                v710[4] = 6;
                                                v708[v709] = nil;
                                            end;
                                        end;
                                    elseif v604 < 101 then
                                        if v604 < 98 then
                                            if v604 < 96 then
                                                local v711 = u33;
                                                local v712 = u34;

                                                if v711 then
                                                    for i in u36, v711 do
                                                        local v713 = v711[i];

                                                        if v713 then
                                                            v713[5] = v713;
                                                            v713[6] = u25[i];
                                                            v713[4] = 6;
                                                            v711[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v712 then
                                                    for i, v in u36, v712 do
                                                        local v714 = v[6];

                                                        if v712 then
                                                            local v715 = v712[i];

                                                            if v715 then
                                                                local v716 = u24(v714);
                                                                u37(u25, i, i + v714 - 1, 1, v716);
                                                                v715[5] = v716;
                                                                v715[4] = 1;
                                                                v712[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u38(UNNAMED_2819735067512[u26]);
                                            end;

                                            if v604 == 97 then
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]](u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n));
                                            else
                                                u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735036840[u26]]);
                                            end;
                                        elseif v604 < 99 then
                                            if u25[UNNAMED_2819735072456[u26]] ~= u25[UNNAMED_2819735036840[u26]] then
                                                u26 = UNNAMED_2819735069192[u26];
                                            end;
                                        elseif v604 == 100 then
                                            u25[UNNAMED_2819735072456[u26]] = u45[UNNAMED_2819735032328[u26]];
                                        else
                                            local v717 = nil;
                                            local v718 = UNNAMED_2819735072456[u26];
                                            local v719 = UNNAMED_2819735067512[u26];
                                            local v720 = UNNAMED_2819735032328[u26];
                                            local v721 = u33;
                                            local v722 = u34;
                                            local v723 = v720[0];

                                            if v723 then
                                                local v724 = #v723 / 3;

                                                if v724 > 0 then
                                                    v717 = {};

                                                    for i = 1, v724 do
                                                        local v725 = (i - 1) * 3;
                                                        local v726 = v723[v725 + 2];
                                                        local v727 = v723[v725 + 1];
                                                        local v728;

                                                        if v726 == 2 then
                                                            v721 = v721 or {};
                                                            local v729 = v721[v727];

                                                            if not v729 then
                                                                v729 = {
                                                                    [5] = u25,
                                                                    [4] = v727
                                                                };
                                                                v721[v727] = v729;
                                                            end;

                                                            v717[i] = v729;
                                                            v728 = i;
                                                        elseif v726 == 0 then
                                                            v717[i] = u25[v727];
                                                            v728 = i;
                                                        elseif v726 == 3 then
                                                            v717[i] = UNNAMED_2819769586744[v727];
                                                            v728 = i;
                                                        elseif v726 == 1 then
                                                            v722 = v722 or {};
                                                            local v730 = v722[v727];

                                                            if not v730 then
                                                                v730 = {
                                                                    [5] = u25,
                                                                    [4] = v727,
                                                                    [6] = v723[v725 + 3]
                                                                };
                                                                v722[v727] = v730;
                                                            end;

                                                            v717[i] = v730;
                                                            v728 = i;
                                                        else
                                                            v728 = i;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            local v731 = v720[-2];
                                            v720[v731] = v717;
                                            local v732 = v719(u35(v720, 1, v720[-1]));
                                            v720[v731] = nil;
                                            u25[v718] = v732;
                                            u33 = v721;
                                            u34 = v722;
                                        end;
                                    elseif v604 < 104 then
                                        if v604 >= 102 then
                                            if v604 == 103 then
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735069192[u26] * u25[UNNAMED_2819735036840[u26]];
                                            elseif u25[UNNAMED_2819735072456[u26]] ~= UNNAMED_2819735032328[u26] then
                                                u26 = UNNAMED_2819735036840[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735069192[u26]] = u38(u25[UNNAMED_2819735036840[u26]]());
                                        end;
                                    elseif v604 >= 105 then
                                        if v604 == 106 then
                                            v57 = UNNAMED_2819769586744[UNNAMED_2819735069192[u26]];
                                            v57[5][v57[4]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735036168[u26];
                                        else
                                            u45[UNNAMED_2819735032328[u26]] = u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] == UNNAMED_2819735067512[u26];
                                    end;
                                elseif v604 < 131 then
                                    if v604 < 125 then
                                        if v604 < 122 then
                                            if v604 >= 120 then
                                                if v604 == 121 then
                                                    u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]] % UNNAMED_2819735072456[u26];
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] / UNNAMED_2819735032328[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] >= UNNAMED_2819735069192[u26];
                                            end;
                                        elseif v604 < 123 then
                                            u25[UNNAMED_2819735072456[u26]] = u39(u25[UNNAMED_2819735036840[u26]], u25[UNNAMED_2819735069192[u26]]);
                                        elseif v604 == 124 then
                                            v57 = UNNAMED_2819735069192[u26] + 1;
                                            v55 = u39(UNNAMED_2819735072456[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));

                                            for i = 1, UNNAMED_2819735036840[u26] do
                                                local v733 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                local v734 = u39(v733, (u41(v733, 13)));
                                                v55 = u42(u39(v734, (u43(v734, 14))), 536870911);
                                                UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                                UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                                UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 14), 127)));
                                                UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 21), 127)));
                                                v57 = v57 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735050040[u26] = 190;
                                        else
                                            u25[UNNAMED_2819735069192[u26]] = #u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    elseif v604 >= 128 then
                                        if v604 >= 129 then
                                            if v604 == 130 then
                                                u28 = {
                                                    [6] = u32,
                                                    [5] = u30,
                                                    [9] = u28,
                                                    [8] = u29,
                                                    [7] = u31
                                                };
                                                v57 = UNNAMED_2819735069192[u26];
                                                v55 = u47(u48);
                                                v55(UNNAMED_2819735031272, u25[v57], u25[v57 + 1], u25[v57 + 2]);
                                                u29 = v55;
                                                u32 = UNNAMED_2819735072456[u26];
                                                u26 = UNNAMED_2819735036840[u26];
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] <= UNNAMED_2819735069192[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735069192[u26]], u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                                        end;
                                    elseif v604 >= 126 then
                                        if v604 == 127 then
                                            u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735067512[u26]] = u25[UNNAMED_2819735069192[u26]];
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] * u25[UNNAMED_2819735069192[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]];
                                    end;
                                elseif v604 >= 137 then
                                    if v604 < 140 then
                                        if v604 < 138 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] - UNNAMED_2819735036840[u26];
                                        elseif v604 == 139 then
                                            v57 = UNNAMED_2819735072456[u26];
                                            v55 = UNNAMED_2819735069192[u26];
                                            v53 = UNNAMED_2819735036840[u26];
                                            v56 = v57 + v53 - 1;
                                            v54 = v57 + v55;
                                            v58 = u25[v54];
                                            local n = v58.n;
                                            v58.n = v55 + n - 1;
                                            u37(v58, 1, n, v55, v58);
                                            u37(u25, v57 + 1, v54 - 1, 1, v58);
                                            u37(u38(u25[v57](u35(v58, 1, v58.n))), 1, v53, v57, u25);
                                        else
                                            u25[UNNAMED_2819735069192[u26]] = -u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    elseif v604 < 141 then
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735036840[u26]](u25[UNNAMED_2819735072456[u26]]);
                                    else
                                        if v604 == 142 then
                                            local v735 = u33;
                                            local v736 = u34;

                                            if v735 then
                                                for i in u36, v735 do
                                                    local v737 = v735[i];

                                                    if v737 then
                                                        v737[5] = v737;
                                                        v737[6] = u25[i];
                                                        v737[4] = 6;
                                                        v735[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v736 then
                                                for i, v in u36, v736 do
                                                    local v738 = v[6];

                                                    if v736 then
                                                        local v739 = v736[i];

                                                        if v739 then
                                                            local v740 = u24(v738);
                                                            u37(u25, i, i + v738 - 1, 1, v740);
                                                            v739[5] = v740;
                                                            v739[4] = 1;
                                                            v736[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735032328[u26]);
                                        end;

                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735032328[u26];
                                    end;
                                elseif v604 >= 134 then
                                    if v604 < 135 then
                                        local v741 = u33;
                                        local v742 = u34;

                                        if v741 then
                                            for i in u36, v741 do
                                                local v743 = v741[i];

                                                if v743 then
                                                    v743[5] = v743;
                                                    v743[6] = u25[i];
                                                    v743[4] = 6;
                                                    v741[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v742 then
                                            for i, v in u36, v742 do
                                                local v744 = v[6];

                                                if v742 then
                                                    local v745 = v742[i];

                                                    if v745 then
                                                        local v746 = u24(v744);
                                                        u37(u25, i, i + v744 - 1, 1, v746);
                                                        v745[5] = v746;
                                                        v745[4] = 1;
                                                        v742[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u38(UNNAMED_2819735036168[u26], u25[UNNAMED_2819735069192[u26]]);
                                    end;

                                    if v604 == 136 then
                                        u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735036840[u26]];
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735069192[u26]]];
                                    end;
                                elseif v604 >= 132 then
                                    if v604 == 133 then
                                        u25[UNNAMED_2819735069192[u26]](UNNAMED_2819735067512[u26], u35(u25[UNNAMED_2819735072456[u26]], 1, u25[UNNAMED_2819735072456[u26]].n));
                                    else
                                        local v747;

                                        if u25[UNNAMED_2819735036840[u26]] then
                                            v747 = UNNAMED_2819735072456[u26];
                                        else
                                            v747 = UNNAMED_2819735069192[u26];
                                        end;

                                        u26 = v747;
                                    end;
                                else
                                    u25[UNNAMED_2819735036840[u26]] = u23;
                                end;
                            elseif v604 >= 167 then
                                if v604 >= 179 then
                                    if v604 >= 185 then
                                        if v604 >= 188 then
                                            if v604 < 189 then
                                                u25[UNNAMED_2819735036840[u26]] = u22;
                                            elseif v604 ~= 190 then
                                                v57 = UNNAMED_2819735069192[u26] + 1;
                                                v55 = u39(UNNAMED_2819735072456[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));

                                                for i = 1, UNNAMED_2819735036840[u26] do
                                                    local v748 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                    local v749 = u39(v748, (u41(v748, 13)));
                                                    v55 = u42(u39(v749, (u43(v749, 14))), 536870911);
                                                    UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 0), 127)));
                                                    UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 7), 127)));
                                                    UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 14), 127)));
                                                    UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 21), 127)));
                                                    v57 = v57 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735050040[u26] = 190;
                                            end;
                                        elseif v604 < 186 then
                                            UNNAMED_2819769586744[UNNAMED_2819735036840[u26]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735032328[u26];
                                        elseif v604 == 187 then
                                            local v750 = UNNAMED_2819735069192[u26];
                                            local v751 = UNNAMED_2819735036168[u26];
                                            local v752 = u42(UNNAMED_2819735067512[u26], 4294967295);
                                            local v753 = u42(v751, 4294967295);
                                            local v754 = u42(v752, 65535);
                                            local v755 = u41(v752, 16);
                                            local v756 = u42(v753, 65535);
                                            local v757 = u41(v753, 16);
                                            local v758 = u42(v754 * v756 + u43(u42(v754 * v757 + v755 * v756, 65535), 16), 4294967295) % 4294967296;
                                            u25[v750] = v758 ~= v758 and 0 or v758 - v758 % 1;
                                        elseif u25[UNNAMED_2819735069192[u26]] > UNNAMED_2819735036840[u26] then
                                            u26 = UNNAMED_2819735072456[u26];
                                        end;
                                    elseif v604 < 182 then
                                        if v604 >= 180 then
                                            if v604 == 181 then
                                                u25[UNNAMED_2819735072456[u26]] = u42(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735032328[u26]);
                                            elseif UNNAMED_2819735032328[u26] > u25[UNNAMED_2819735072456[u26]] then
                                                u26 = UNNAMED_2819735036840[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735069192[u26]][UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]];
                                        end;
                                    elseif v604 < 183 then
                                        v57 = UNNAMED_2819735069192[u26];
                                        v55 = u25[v57];
                                        v53 = u25[v57 + 1];
                                        v56 = u25[v57 + 2];
                                        u25[v57] = v55(v53, v56);
                                    elseif v604 == 184 then
                                        u25[UNNAMED_2819735036840[u26]](u35(u25[UNNAMED_2819735069192[u26]], 1, u25[UNNAMED_2819735069192[u26]].n));
                                    else
                                        local v759 = UNNAMED_2819735069192[u26];
                                        local v760 = u39(UNNAMED_2819735072456[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));
                                        local v761 = UNNAMED_2819735071256[5];
                                        local v762 = u39(v761[v759], 109162203);
                                        v761[v759] = v762;
                                        local v763 = UNNAMED_2819735071256[4];
                                        local v764 = v762 + 1;
                                        local v765 = u49(v763, v764);
                                        local v766;

                                        if v765 < 128 then
                                            v766 = v764 + 1;
                                        else
                                            local v767 = u49(v763, v764 + 1);

                                            if v767 < 128 then
                                                v765 = v765 - 128 + v767 * 128;
                                                v766 = v764 + 2;
                                            else
                                                local v768 = u49(v763, v764 + 2);

                                                if v768 < 128 then
                                                    v765 = v765 - 128 + (v767 - 128) * 16384 + v768 * 128;
                                                    v766 = v764 + 3;
                                                else
                                                    local v769 = u49(v763, v764 + 3);
                                                    v765 = (v765 - 128) * 16384 + (v767 - 128) * 128 + (v768 - 128) + v769 % 128 * 2097152 + (v769 - v769 % 128) * 2097152;
                                                    v766 = v764 + 4;
                                                end;
                                            end;
                                        end;

                                        local v770 = v760 * 16843009;
                                        local v771 = v766 + v765;
                                        local v772 = v771 - v765 % 4;

                                        for i = v766, v772 - 1, 4 do
                                            u50(v763, i, (u39(u51(v763, i), v770)));
                                            local _ = i;
                                        end;

                                        for i = v772, v771 - 1 do
                                            u52(v763, i, (u39(u49(v763, i), v760)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735069192[u26] = 133;
                                        UNNAMED_2819735072456[u26] = 151;
                                        UNNAMED_2819735036840[u26] = 44;
                                        UNNAMED_2819735050040[u26] = 190;
                                    end;
                                elseif v604 >= 173 then
                                    if v604 >= 176 then
                                        if v604 >= 177 then
                                            if v604 == 178 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = UNNAMED_2819735069192[u26];
                                                v53 = UNNAMED_2819735036840[u26];
                                                v56 = u39(u22, u42(u41(u22, 14), 262143), (u42(u41(u22, 28), 15)));
                                                v54 = v55 < 16384 and 7 or (v55 < 2097152 and 14 or 21);
                                                v58 = u41(v55, v54);
                                                local v773 = u42(v55, u43(1, v54) - 1);
                                                UNNAMED_2819735036840[u26] = u39(v53, 120, (u42(u41(v56, 14), 127)));
                                                UNNAMED_2819735069192[u26] = u39(v773, 92, (u42(v56, 127)));
                                                UNNAMED_2819735050040[u26] = u39(v58, 2, (u42(u41(v56, 21), 127)));
                                                UNNAMED_2819735072456[u26] = u39(v57, 109, (u42(u41(v56, 7), 127)));
                                                u26 = u26 - 1;
                                            else
                                                u25[UNNAMED_2819735069192[u26]] = u45[UNNAMED_2819735036168[u26]][UNNAMED_2819735067512[u26]];
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u40(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735032328[u26]);
                                        end;
                                    elseif v604 >= 174 then
                                        if v604 == 175 then
                                            v57 = UNNAMED_2819735072456[u26];
                                            v55 = UNNAMED_2819735036840[u26];
                                            v53 = UNNAMED_2819735069192[u26];
                                            v56 = v57 + v55;
                                            u25[v57] = u38(u25[v57](u35(u25, v57 + 1, v56)));
                                        else
                                            u25[UNNAMED_2819735069192[u26]] = u25[UNNAMED_2819735072456[u26]] < UNNAMED_2819735036840[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735032328[u26];
                                    end;
                                elseif v604 < 170 then
                                    if v604 < 168 then
                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735069192[u26]] > u25[UNNAMED_2819735072456[u26]];
                                    else
                                        if v604 == 169 then
                                            local v774 = u33;
                                            local v775 = u34;

                                            if v774 then
                                                for i in u36, v774 do
                                                    local v776 = v774[i];

                                                    if v776 then
                                                        v776[5] = v776;
                                                        v776[6] = u25[i];
                                                        v776[4] = 6;
                                                        v774[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v775 then
                                                for i, v in u36, v775 do
                                                    local v777 = v[6];

                                                    if v775 then
                                                        local v778 = v775[i];

                                                        if v778 then
                                                            local v779 = u24(v777);
                                                            u37(u25, i, i + v777 - 1, 1, v779);
                                                            v778[5] = v779;
                                                            v778[4] = 1;
                                                            v775[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735069192[u26], u38();
                                        end;

                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] == u25[UNNAMED_2819735036840[u26]];
                                    end;
                                elseif v604 >= 171 then
                                    if v604 == 172 then
                                        if u33 then
                                            local v780 = u33;
                                            local v781 = UNNAMED_2819735036840[u26];
                                            local v782 = v780[v781];

                                            if v782 then
                                                v782[5] = v782;
                                                v782[6] = u25[v781];
                                                v782[4] = 6;
                                                v780[v781] = nil;
                                            end;
                                        end;
                                    else
                                        v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                        v57[5][v57[4]][UNNAMED_2819735032328[u26]] = u25[UNNAMED_2819735036840[u26]];
                                    end;
                                else
                                    local v783 = u25[UNNAMED_2819735072456[u26]] % 4294967296;
                                    u25[UNNAMED_2819735069192[u26]] = v783 ~= v783 and 0 or v783 - v783 % 1;
                                end;
                            else
                                if v604 < 155 then
                                    if v604 >= 149 then
                                        if v604 < 152 then
                                            if v604 < 150 then
                                                v57 = UNNAMED_2819735036840[u26];
                                                local v784 = u25[UNNAMED_2819735072456[u26]];
                                                u25[v57] = UNNAMED_2819735032328[u26];
                                                u25[v57 + 1] = v784;
                                            elseif v604 == 151 then
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] .. UNNAMED_2819735032328[u26];
                                            else
                                                u28 = {
                                                    [6] = u32,
                                                    [5] = u30,
                                                    [9] = u28,
                                                    [8] = u29,
                                                    [7] = u31
                                                };
                                                v57 = UNNAMED_2819735069192[u26];
                                                u31 = u25[v57 + 2] + 0;
                                                u30 = u25[v57 + 1] + 0;
                                                u29 = u25[v57] - u31;
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        elseif v604 >= 153 then
                                            if v604 == 154 then
                                                local v785 = UNNAMED_2819735069192[u26];
                                                local v786 = UNNAMED_2819735072456[u26];
                                                local v787 = UNNAMED_2819735071256[5];
                                                local v788 = u39(v787[v785], 109162203);
                                                v787[v785] = v788;
                                                local v789 = UNNAMED_2819735071256[4];
                                                local v790 = v788 + 1;
                                                local v791 = u49(v789, v790);
                                                local v792;

                                                if v791 < 128 then
                                                    v792 = v790 + 1;
                                                else
                                                    local v793 = u49(v789, v790 + 1);

                                                    if v793 < 128 then
                                                        v791 = v791 - 128 + v793 * 128;
                                                        v792 = v790 + 2;
                                                    else
                                                        local v794 = u49(v789, v790 + 2);

                                                        if v794 < 128 then
                                                            v791 = v791 - 128 + (v793 - 128) * 16384 + v794 * 128;
                                                            v792 = v790 + 3;
                                                        else
                                                            local v795 = u49(v789, v790 + 3);
                                                            v791 = (v791 - 128) * 16384 + (v793 - 128) * 128 + (v794 - 128) + v795 % 128 * 2097152 + (v795 - v795 % 128) * 2097152;
                                                            v792 = v790 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v796 = v786 * 16843009;
                                                local v797 = v792 + v791;
                                                local v798 = v797 - v791 % 4;

                                                for i = v792, v798 - 1, 4 do
                                                    u50(v789, i, (u39(u51(v789, i), v796)));
                                                    local _ = i;
                                                end;

                                                for i = v798, v797 - 1 do
                                                    u52(v789, i, (u39(u49(v789, i), v786)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735069192[u26] = 212;
                                                UNNAMED_2819735072456[u26] = 21;
                                                UNNAMED_2819735036840[u26] = 154;
                                                UNNAMED_2819735050040[u26] = 190;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] * UNNAMED_2819735036840[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735069192[u26]](UNNAMED_2819735067512[u26]));
                                        end;
                                    elseif v604 >= 146 then
                                        if v604 < 147 then
                                            v57 = UNNAMED_2819735072456[u26];
                                            local v799 = u25[UNNAMED_2819735069192[u26]];
                                            u25[v57] = UNNAMED_2819735036840[u26];
                                            u25[v57 + 1] = v799;
                                        elseif v604 == 148 then
                                            u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036840[u26];
                                        else
                                            u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735067512[u26] * u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    elseif v604 < 144 then
                                        if u25[UNNAMED_2819735069192[u26]] >= u25[UNNAMED_2819735036840[u26]] then
                                            u26 = UNNAMED_2819735072456[u26];
                                        end;
                                    elseif v604 == 145 then
                                        v57 = UNNAMED_2819735072456[u26];
                                        local v800 = UNNAMED_2819735069192[u26];
                                        u25[v57] = UNNAMED_2819735067512[u26];
                                        u25[v57 + 1] = v800;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u38(u25[UNNAMED_2819735069192[u26]](u25[UNNAMED_2819735072456[u26]]));
                                    end;

                                    v603 = 1;
                                    continue;
                                end;

                                if v604 < 161 then
                                    if v604 < 158 then
                                        if v604 >= 156 then
                                            if v604 == 157 then
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735069192[u26]] + u25[UNNAMED_2819735036840[u26]];
                                            else
                                                u26 = UNNAMED_2819735036840[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735069192[u26]] = UNNAMED_2819735036840[u26] + u25[UNNAMED_2819735072456[u26]];
                                        end;

                                        v603 = 1;
                                        continue;
                                    end;

                                    if v604 >= 159 then
                                        if v604 == 160 then
                                            u25[UNNAMED_2819735036840[u26]] = u42(u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735069192[u26]]);
                                        else
                                            local v801 = UNNAMED_2819735072456[u26];
                                            local v802 = UNNAMED_2819735036840[u26];
                                            local v803 = u42(u25[UNNAMED_2819735069192[u26]], 4294967295);
                                            local v804 = u42(v802, 4294967295);
                                            local v805 = u42(v803, 65535);
                                            local v806 = u41(v803, 16);
                                            local v807 = u42(v804, 65535);
                                            local v808 = u41(v804, 16);
                                            local v809 = u42(v805 * v807 + u43(u42(v805 * v808 + v806 * v807, 65535), 16), 4294967295) % 4294967296;
                                            u25[v801] = v809 ~= v809 and 0 or v809 - v809 % 1;
                                        end;

                                        v603 = 1;
                                        continue;
                                    end;

                                    u27 = UNNAMED_2819735072456[u26];
                                    u26 = UNNAMED_2819735036840[u26] + 1;
                                    v59 = 2;
                                    break;
                                end;

                                if v604 >= 164 then
                                    if v604 < 165 then
                                        local v810 = UNNAMED_2819735072456[u26];
                                        local v811 = v810 + UNNAMED_2819735069192[u26];
                                        local v812 = u33;
                                        local v813 = u34;

                                        if v812 then
                                            for i in u36, v812 do
                                                local v814 = v812[i];

                                                if v814 then
                                                    v814[5] = v814;
                                                    v814[6] = u25[i];
                                                    v814[4] = 6;
                                                    v812[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v813 then
                                            for i, v in u36, v813 do
                                                local v815 = v[6];

                                                if v813 then
                                                    local v816 = v813[i];

                                                    if v816 then
                                                        local v817 = u24(v815);
                                                        u37(u25, i, i + v815 - 1, 1, v817);
                                                        v816[5] = v817;
                                                        v816[4] = 1;
                                                        v813[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, false, v810, v811;
                                    end;

                                    if v604 == 166 then
                                        u25[UNNAMED_2819735036840[u26]](u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735032328[u26]);
                                    else
                                        u29 = u28[8];
                                        u30 = u28[5];
                                        u31 = u28[7];
                                        u32 = u28[6];
                                        u28 = u28[9];
                                    end;
                                elseif v604 >= 162 then
                                    if v604 == 163 then
                                        v57 = UNNAMED_2819735036840[u26];
                                        v55 = UNNAMED_2819735072456[u26];
                                        v53 = UNNAMED_2819735069192[u26];
                                        v56 = u25[v57];
                                        v54 = v57 + v55;
                                        v58 = u25[v54];
                                        u37(u25, v57 + 1, v54 - 1, v53 + 1, v56);
                                        u37(v58, 1, v58.n, v53 + v55, v56);
                                    elseif u25[UNNAMED_2819735036840[u26]] >= UNNAMED_2819735032328[u26] then
                                        u26 = UNNAMED_2819735072456[u26];
                                    end;
                                else
                                    u25[UNNAMED_2819735069192[u26]] = u25;
                                end;
                            end;

                            v603 = 1;
                            continue;
                        elseif v603 == 1 then
                            v603 = -1;
                            u26 = u26 + 1;
                            break;
                        else
                            break;
                        end;
                    end;

                    if v59 ~= -1 then
                        break;
                    end;
                end;

                if v59 ~= -1 then
                    continue;
                end;

                v59 = 6;
                continue;
            elseif v59 == 6 then
                v59 = -1;

                while true do
                    local u26;
                    local v818 = 0;

                    while true do
                        if v818 == 0 then
                            v818 = -1;
                            local v819 = UNNAMED_2819735069192[u26];

                            if v819 >= 96 then
                                if v819 >= 144 then
                                    if v819 >= 168 then
                                        if v819 >= 180 then
                                            if v819 < 186 then
                                                if v819 < 183 then
                                                    if v819 >= 181 then
                                                        if v819 == 182 then
                                                            v57 = u25[UNNAMED_2819735050040[u26]];
                                                            u25[UNNAMED_2819735036840[u26]] = u38(u35(v57, UNNAMED_2819735072456[u26], v57.n));
                                                        else
                                                            local v820 = UNNAMED_2819735036840[u26];
                                                            local v821 = UNNAMED_2819735050040[u26];
                                                            local v822, v823 = u25[UNNAMED_2819735072456[u26]]();
                                                            u25[v820] = v822;
                                                            u25[v821] = v823;
                                                        end;
                                                    else
                                                        v57 = UNNAMED_2819735050040[u26];
                                                        v55, v53 = u29();

                                                        if v55 then
                                                            u25[v57] = v53;
                                                            u26 = UNNAMED_2819735072456[u26];
                                                        else
                                                            u26 = UNNAMED_2819735036840[u26];
                                                        end;
                                                    end;
                                                elseif v819 < 184 then
                                                    u25[UNNAMED_2819735050040[u26]] = u46(u25[UNNAMED_2819735072456[u26]]);
                                                elseif v819 == 185 then
                                                    u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735043176[u26]];
                                                elseif u25[UNNAMED_2819735072456[u26]] ~= UNNAMED_2819735067512[u26] then
                                                    u26 = UNNAMED_2819735050040[u26];
                                                end;
                                            elseif v819 >= 189 then
                                                if v819 >= 190 then
                                                    if v819 == 191 then
                                                        u22 = u25[UNNAMED_2819735050040[u26]];
                                                    else
                                                        local v824;

                                                        if u25[UNNAMED_2819735036840[u26]] then
                                                            v824 = UNNAMED_2819735050040[u26];
                                                        else
                                                            v824 = UNNAMED_2819735072456[u26];
                                                        end;

                                                        u26 = v824;
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735036168[u26];
                                                end;
                                            elseif v819 >= 187 then
                                                if v819 == 188 then
                                                    u45[UNNAMED_2819735043176[u26]] = UNNAMED_2819735067512[u26];
                                                else
                                                    UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][UNNAMED_2819735043176[u26]] = UNNAMED_2819735067512[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]](u25[UNNAMED_2819735072456[u26]]);
                                            end;
                                        elseif v819 < 174 then
                                            if v819 >= 171 then
                                                if v819 >= 172 then
                                                    if v819 == 173 then
                                                        u25[UNNAMED_2819735036840[u26]] = u45[UNNAMED_2819735036168[u26]][UNNAMED_2819735043176[u26]];
                                                    else
                                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] - u25[UNNAMED_2819735036840[u26]];
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] % UNNAMED_2819735072456[u26];
                                                end;
                                            elseif v819 >= 169 then
                                                if v819 == 170 then
                                                    u25[UNNAMED_2819735036840[u26]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735050040[u26]];
                                                else
                                                    u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735036840[u26]] // UNNAMED_2819735072456[u26];
                                                end;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735067512[u26] * u25[UNNAMED_2819735050040[u26]];
                                            end;
                                        elseif v819 >= 177 then
                                            if v819 < 178 then
                                                UNNAMED_2819769586744[UNNAMED_2819735072456[u26]][u25[UNNAMED_2819735036840[u26]]] = UNNAMED_2819735043176[u26];
                                            else
                                                if v819 == 179 then
                                                    local v825 = u33;
                                                    local v826 = u34;

                                                    if v825 then
                                                        for i in u36, v825 do
                                                            local v827 = v825[i];

                                                            if v827 then
                                                                v827[5] = v827;
                                                                v827[6] = u25[i];
                                                                v827[4] = 6;
                                                                v825[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v826 then
                                                        for i, v in u36, v826 do
                                                            local v828 = v[6];

                                                            if v826 then
                                                                local v829 = v826[i];

                                                                if v829 then
                                                                    local v830 = u24(v828);
                                                                    u37(u25, i, i + v828 - 1, 1, v830);
                                                                    v829[5] = v830;
                                                                    v829[4] = 1;
                                                                    v826[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(UNNAMED_2819735043176[u26], u25[UNNAMED_2819735036840[u26]]);
                                                end;

                                                u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735072456;
                                            end;
                                        elseif v819 < 175 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] * UNNAMED_2819735036840[u26];
                                        elseif v819 == 176 then
                                            u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735036840[u26]]());
                                        elseif u25[UNNAMED_2819735036840[u26]] ~= u25[UNNAMED_2819735072456[u26]] then
                                            u26 = UNNAMED_2819735050040[u26];
                                        end;
                                    elseif v819 >= 156 then
                                        if v819 < 162 then
                                            if v819 < 159 then
                                                if v819 >= 157 then
                                                    if v819 == 158 then
                                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735043176[u26] + u25[UNNAMED_2819735036840[u26]];
                                                    else
                                                        u45[UNNAMED_2819735043176[u26]][UNNAMED_2819735067512[u26]] = u25[UNNAMED_2819735072456[u26]];
                                                    end;
                                                else
                                                    u25[UNNAMED_2819735050040[u26]] = u41(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735036840[u26]);
                                                end;
                                            elseif v819 >= 160 then
                                                if v819 == 161 then
                                                    if u25[UNNAMED_2819735072456[u26]] > UNNAMED_2819735067512[u26] then
                                                        u26 = UNNAMED_2819735050040[u26];
                                                    end;
                                                else
                                                    v57 = { ... };
                                                    v55 = UNNAMED_2819735036840[u26];
                                                    u37(v57, 1, UNNAMED_2819735050040[u26], v55, u25);
                                                end;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] > UNNAMED_2819735043176[u26];
                                            end;
                                        elseif v819 < 165 then
                                            if v819 >= 163 then
                                                if v819 == 164 then
                                                    u28 = {
                                                        [6] = u32,
                                                        [5] = u30,
                                                        [9] = u28,
                                                        [8] = u29,
                                                        [7] = u31
                                                    };
                                                    v57 = UNNAMED_2819735036840[u26];
                                                    v55 = u47(u48);
                                                    v55(UNNAMED_2819735031272, u25[v57], u25[v57 + 1], u25[v57 + 2]);
                                                    u29 = v55;
                                                    u32 = UNNAMED_2819735050040[u26];
                                                    u26 = UNNAMED_2819735072456[u26];
                                                else
                                                    u25[UNNAMED_2819735050040[u26]][u25[UNNAMED_2819735036840[u26]]] = UNNAMED_2819735036168[u26];
                                                end;
                                            else
                                                local v831 = UNNAMED_2819735036840[u26];
                                                local v832 = UNNAMED_2819735050040[u26];
                                                local v833 = UNNAMED_2819735071256[5];
                                                local v834 = u39(v833[v831], 109162203);
                                                v833[v831] = v834;
                                                local v835 = UNNAMED_2819735071256[4];
                                                local v836 = v834 + 1;
                                                local v837 = u49(v835, v836);
                                                local v838;

                                                if v837 < 128 then
                                                    v838 = v836 + 1;
                                                else
                                                    local v839 = u49(v835, v836 + 1);

                                                    if v839 < 128 then
                                                        v837 = v837 - 128 + v839 * 128;
                                                        v838 = v836 + 2;
                                                    else
                                                        local v840 = u49(v835, v836 + 2);

                                                        if v840 < 128 then
                                                            v837 = v837 - 128 + (v839 - 128) * 16384 + v840 * 128;
                                                            v838 = v836 + 3;
                                                        else
                                                            local v841 = u49(v835, v836 + 3);
                                                            v837 = (v837 - 128) * 16384 + (v839 - 128) * 128 + (v840 - 128) + v841 % 128 * 2097152 + (v841 - v841 % 128) * 2097152;
                                                            v838 = v836 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v842 = v832 * 16843009;
                                                local v843 = v838 + v837;
                                                local v844 = v843 - v837 % 4;

                                                for i = v838, v844 - 1, 4 do
                                                    u50(v835, i, (u39(u51(v835, i), v842)));
                                                    local _ = i;
                                                end;

                                                for i = v844, v843 - 1 do
                                                    u52(v835, i, (u39(u49(v835, i), v832)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735036840[u26] = 164;
                                                UNNAMED_2819735050040[u26] = 52;
                                                UNNAMED_2819735072456[u26] = 243;
                                                UNNAMED_2819735069192[u26] = 86;
                                            end;
                                        else
                                            if v819 < 166 then
                                                local v845 = u33;
                                                local v846 = u34;

                                                if v845 then
                                                    for i in u36, v845 do
                                                        local v847 = v845[i];

                                                        if v847 then
                                                            v847[5] = v847;
                                                            v847[6] = u25[i];
                                                            v847[4] = 6;
                                                            v845[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v846 then
                                                    for i, v in u36, v846 do
                                                        local v848 = v[6];

                                                        if v846 then
                                                            local v849 = v846[i];

                                                            if v849 then
                                                                local v850 = u24(v848);
                                                                u37(u25, i, i + v848 - 1, 1, v850);
                                                                v849[5] = v850;
                                                                v849[4] = 1;
                                                                v846[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735036840[u26], u38(u25[UNNAMED_2819735050040[u26]], u25[UNNAMED_2819735072456[u26]]);
                                            end;

                                            if v819 == 167 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = UNNAMED_2819735050040[u26];
                                                v53 = UNNAMED_2819735036840[u26];
                                                v56 = v57 + v55;
                                                u25[v57] = u38(u25[v57](u35(u25, v57 + 1, v56)));
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] % UNNAMED_2819735067512[u26];
                                            end;
                                        end;
                                    elseif v819 < 150 then
                                        if v819 >= 147 then
                                            if v819 < 148 then
                                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]][UNNAMED_2819735067512[u26]];
                                            elseif v819 == 149 then
                                                u25[UNNAMED_2819735072456[u26]] = u23;
                                            else
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]](u35(u25[UNNAMED_2819735072456[u26]], 1, u25[UNNAMED_2819735072456[u26]].n));
                                            end;
                                        elseif v819 < 145 then
                                            u28 = {
                                                [6] = u32,
                                                [5] = u30,
                                                [9] = u28,
                                                [8] = u29,
                                                [7] = u31
                                            };
                                            v57 = UNNAMED_2819735036840[u26];
                                            u31 = u25[v57 + 2] + 0;
                                            u30 = u25[v57 + 1] + 0;
                                            u29 = u25[v57] - u31;
                                            u26 = UNNAMED_2819735050040[u26];
                                        elseif v819 == 146 then
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] < UNNAMED_2819735072456[u26];
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735036840[u26]] + UNNAMED_2819735036168[u26];
                                        end;
                                    elseif v819 >= 153 then
                                        if v819 < 154 then
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] == UNNAMED_2819735036168[u26];
                                        elseif v819 == 155 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735050040[u26]]];
                                        else
                                            UNNAMED_2819769586744[UNNAMED_2819735050040[u26]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735072456[u26];
                                        end;
                                    elseif v819 < 151 then
                                        UNNAMED_2819769586744[UNNAMED_2819735050040[u26]][UNNAMED_2819735036168[u26]] = u25[UNNAMED_2819735036840[u26]];
                                    elseif v819 == 152 then
                                        v57 = UNNAMED_2819735036840[u26];
                                        local v851 = u25[UNNAMED_2819735072456[u26]];
                                        u25[v57] = UNNAMED_2819735043176[u26];
                                        u25[v57 + 1] = v851;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = u38(u25[UNNAMED_2819735036840[u26]](u25[UNNAMED_2819735050040[u26]]));
                                    end;
                                elseif v819 >= 120 then
                                    if v819 >= 132 then
                                        if v819 >= 138 then
                                            if v819 >= 141 then
                                                if v819 < 142 then
                                                    local v852 = u33;
                                                    local v853 = u34;

                                                    if v852 then
                                                        for i in u36, v852 do
                                                            local v854 = v852[i];

                                                            if v854 then
                                                                v854[5] = v854;
                                                                v854[6] = u25[i];
                                                                v854[4] = 6;
                                                                v852[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v853 then
                                                        for i, v in u36, v853 do
                                                            local v855 = v[6];

                                                            if v853 then
                                                                local v856 = v853[i];

                                                                if v856 then
                                                                    local v857 = u24(v855);
                                                                    u37(u25, i, i + v855 - 1, 1, v857);
                                                                    v856[5] = v857;
                                                                    v856[4] = 1;
                                                                    v853[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u38(u25[UNNAMED_2819735050040[u26]], u25[UNNAMED_2819735072456[u26]]);
                                                end;

                                                if v819 == 143 then
                                                    u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735050040[u26]], u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                                                else
                                                    u25[UNNAMED_2819735036840[u26]] = u42(u25[UNNAMED_2819735050040[u26]], u25[UNNAMED_2819735072456[u26]]);
                                                end;
                                            elseif v819 < 139 then
                                                u25[UNNAMED_2819735072456[u26]] = u22;
                                            elseif v819 == 140 then
                                                u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] - UNNAMED_2819735072456[u26];
                                            else
                                                v57 = UNNAMED_2819769586744[UNNAMED_2819735050040[u26]];
                                                u25[UNNAMED_2819735072456[u26]] = v57[5][v57[4]];
                                            end;
                                        elseif v819 < 135 then
                                            if v819 >= 133 then
                                                if v819 == 134 then
                                                    v57 = UNNAMED_2819735050040[u26];
                                                    v55 = UNNAMED_2819735072456[u26];
                                                    v53 = UNNAMED_2819735036840[u26];
                                                    v56 = v57 + v55;
                                                    v54 = u25[v56];
                                                    v58 = v54.n;
                                                    v54.n = v55 + v58 - 1;
                                                    u37(v54, 1, v58, v55, v54);
                                                    u37(u25, v57 + 1, v56 - 1, 1, v54);
                                                    u25[v57] = u38(u25[v57](u35(v54, 1, v54.n)));
                                                else
                                                    local v858;

                                                    if u25[UNNAMED_2819735036840[u26]] then
                                                        v858 = UNNAMED_2819735072456[u26];
                                                    else
                                                        v858 = UNNAMED_2819735050040[u26];
                                                    end;

                                                    u26 = v858;
                                                end;
                                            else
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735036840[u26];
                                            end;
                                        elseif v819 >= 136 then
                                            if v819 == 137 then
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735050040;
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]]();
                                            end;
                                        else
                                            v57 = UNNAMED_2819735036840[u26];
                                            local v859 = UNNAMED_2819735050040[u26];
                                            u25[v57] = u25[UNNAMED_2819735072456[u26]];
                                            u25[v57 + 1] = v859;
                                        end;
                                    elseif v819 >= 126 then
                                        if v819 < 129 then
                                            if v819 >= 127 then
                                                if v819 == 128 then
                                                    u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]][UNNAMED_2819735072456[u26]];
                                                else
                                                    local v860 = UNNAMED_2819735072456[u26];
                                                    local v861 = UNNAMED_2819735050040[u26];
                                                    local v862 = u42(u25[UNNAMED_2819735036840[u26]], 4294967295);
                                                    local v863 = u42(v861, 4294967295);
                                                    local v864 = u42(v862, 65535);
                                                    local v865 = u41(v862, 16);
                                                    local v866 = u42(v863, 65535);
                                                    local v867 = u41(v863, 16);
                                                    local v868 = u42(v864 * v866 + u43(u42(v864 * v867 + v865 * v866, 65535), 16), 4294967295) % 4294967296;
                                                    u25[v860] = v868 ~= v868 and 0 or v868 - v868 % 1;
                                                end;
                                            else
                                                v57 = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]];
                                                u25[UNNAMED_2819735072456[u26]] = v57[5][v57[4]][UNNAMED_2819735043176[u26]];
                                            end;
                                        elseif v819 < 130 then
                                            u25[UNNAMED_2819735050040[u26]] = u39(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735036168[u26]);
                                        elseif v819 == 131 then
                                            local v869 = nil;
                                            local v870 = UNNAMED_2819735050040[u26];
                                            local v871 = UNNAMED_2819735036168[u26];
                                            local v872 = UNNAMED_2819735067512[u26];
                                            local v873 = u33;
                                            local v874 = u34;
                                            local v875 = v872[0];

                                            if v875 then
                                                local v876 = #v875 / 3;

                                                if v876 > 0 then
                                                    v869 = {};

                                                    for i = 1, v876 do
                                                        local v877 = (i - 1) * 3;
                                                        local v878 = v875[v877 + 2];
                                                        local v879 = v875[v877 + 1];
                                                        local v880;

                                                        if v878 == 2 then
                                                            v873 = v873 or {};
                                                            local v881 = v873[v879];

                                                            if not v881 then
                                                                v881 = {
                                                                    [5] = u25,
                                                                    [4] = v879
                                                                };
                                                                v873[v879] = v881;
                                                            end;

                                                            v869[i] = v881;
                                                            v880 = i;
                                                        elseif v878 == 0 then
                                                            v869[i] = u25[v879];
                                                            v880 = i;
                                                        elseif v878 == 3 then
                                                            v869[i] = UNNAMED_2819769586744[v879];
                                                            v880 = i;
                                                        elseif v878 == 1 then
                                                            v874 = v874 or {};
                                                            local v882 = v874[v879];

                                                            if not v882 then
                                                                v882 = {
                                                                    [5] = u25,
                                                                    [4] = v879,
                                                                    [6] = v875[v877 + 3]
                                                                };
                                                                v874[v879] = v882;
                                                            end;

                                                            v869[i] = v882;
                                                            v880 = i;
                                                        else
                                                            v880 = i;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            local v883 = v872[-2];
                                            v872[v883] = v869;
                                            local v884 = v871(u35(v872, 1, v872[-1]));
                                            v872[v883] = nil;
                                            u25[v870] = v884;
                                            u33 = v873;
                                            u34 = v874;
                                        else
                                            v57 = UNNAMED_2819735072456[u26];
                                            local v885 = UNNAMED_2819735036840[u26];
                                            u25[v57] = UNNAMED_2819735043176[u26];
                                            u25[v57 + 1] = v885;
                                        end;
                                    elseif v819 < 123 then
                                        if v819 < 121 then
                                            u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735050040[u26] * u25[UNNAMED_2819735036840[u26]];
                                        elseif v819 == 122 then
                                            local v886 = u25[UNNAMED_2819735036840[u26]] % 4294967296;
                                            u25[UNNAMED_2819735072456[u26]] = v886 ~= v886 and 0 or v886 - v886 % 1;
                                        else
                                            v57 = UNNAMED_2819735050040[u26];
                                            v55, v53, v56 = u29();

                                            if v55 then
                                                u25[v57] = v53;
                                                u25[v57 + 1] = v56;
                                                u26 = UNNAMED_2819735072456[u26];
                                            else
                                                u26 = UNNAMED_2819735036840[u26];
                                            end;
                                        end;
                                    elseif v819 < 124 then
                                        u25[UNNAMED_2819735050040[u26]](u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735067512[u26]);
                                    elseif v819 == 125 then
                                        local v887 = UNNAMED_2819735072456[u26];
                                        local v888 = UNNAMED_2819735043176[u26];
                                        local v889 = u42(UNNAMED_2819735067512[u26], 4294967295);
                                        local v890 = u42(v888, 4294967295);
                                        local v891 = u42(v889, 65535);
                                        local v892 = u41(v889, 16);
                                        local v893 = u42(v890, 65535);
                                        local v894 = u41(v890, 16);
                                        local v895 = u42(v891 * v893 + u43(u42(v891 * v894 + v892 * v893, 65535), 16), 4294967295) % 4294967296;
                                        u25[v887] = v895 ~= v895 and 0 or v895 - v895 % 1;
                                    else
                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735036840[u26]] * UNNAMED_2819735036168[u26];
                                    end;
                                elseif v819 >= 108 then
                                    if v819 >= 114 then
                                        if v819 < 117 then
                                            if v819 >= 115 then
                                                if v819 == 116 then
                                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]];
                                                    v57[5][v57[4]] = UNNAMED_2819735043176[u26];
                                                else
                                                    u25[UNNAMED_2819735036840[u26]] = u38(u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735036168[u26]));
                                                end;
                                            else
                                                u29 = u29 + u31;

                                                if u31 <= 0 then
                                                    v57 = u30 <= u29;
                                                else
                                                    v57 = u29 <= u30;
                                                end;

                                                if v57 then
                                                    u25[UNNAMED_2819735050040[u26]] = u29;
                                                    u26 = UNNAMED_2819735072456[u26];
                                                else
                                                    u26 = UNNAMED_2819735036840[u26];
                                                end;
                                            end;
                                        elseif v819 >= 118 then
                                            if v819 == 119 then
                                                if u33 then
                                                    local v896 = u33;
                                                    local v897 = UNNAMED_2819735036840[u26];
                                                    local v898 = v896[v897];

                                                    if v898 then
                                                        v898[5] = v898;
                                                        v898[6] = u25[v897];
                                                        v898[4] = 6;
                                                        v896[v897] = nil;
                                                    end;
                                                end;
                                            else
                                                v57 = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]];
                                                v57[5][v57[4]][UNNAMED_2819735036168[u26]] = UNNAMED_2819735043176[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = u42(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735072456[u26]);
                                        end;
                                    elseif v819 >= 111 then
                                        if v819 >= 112 then
                                            if v819 ~= 113 then
                                                local v899 = u33;
                                                local v900 = u34;

                                                if v899 then
                                                    for i in u36, v899 do
                                                        local v901 = v899[i];

                                                        if v901 then
                                                            v901[5] = v901;
                                                            v901[6] = u25[i];
                                                            v901[4] = 6;
                                                            v899[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v900 then
                                                    for i, v in u36, v900 do
                                                        local v902 = v[6];

                                                        if v900 then
                                                            local v903 = v900[i];

                                                            if v903 then
                                                                local v904 = u24(v902);
                                                                u37(u25, i, i + v902 - 1, 1, v904);
                                                                v903[5] = v904;
                                                                v903[4] = 1;
                                                                v900[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735036840[u26], u38(u25[UNNAMED_2819735050040[u26]], u35(u25[UNNAMED_2819735072456[u26]], 1, u25[UNNAMED_2819735072456[u26]].n));
                                            end;

                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] - UNNAMED_2819735067512[u26];
                                        else
                                            v57 = UNNAMED_2819735072456[u26];
                                            local v905 = UNNAMED_2819735050040[u26];
                                            u25[v57] = UNNAMED_2819735036840[u26];
                                            u25[v57 + 1] = v905;
                                        end;
                                    elseif v819 < 109 then
                                        if u33 then
                                            local v906 = u33;
                                            local v907 = UNNAMED_2819735036840[u26];
                                            local v908 = v906[v907];

                                            if v908 then
                                                v908[5] = v908;
                                                v908[6] = u25[v907];
                                                v908[4] = 6;
                                                v906[v907] = nil;
                                            end;

                                            local v909 = u33;
                                            local v910 = UNNAMED_2819735050040[u26];
                                            local v911 = v909[v910];

                                            if v911 then
                                                v911[5] = v911;
                                                v911[6] = u25[v910];
                                                v911[4] = 6;
                                                v909[v910] = nil;
                                            end;
                                        end;
                                    elseif v819 == 110 then
                                        local v912 = UNNAMED_2819735050040[u26];
                                        local v913 = u39(UNNAMED_2819735036840[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));
                                        local v914 = UNNAMED_2819735071256[5];
                                        local v915 = u39(v914[v912], 109162203);
                                        v914[v912] = v915;
                                        local v916 = UNNAMED_2819735071256[4];
                                        local v917 = v915 + 1;
                                        local v918 = u49(v916, v917);
                                        local v919;

                                        if v918 < 128 then
                                            v919 = v917 + 1;
                                        else
                                            local v920 = u49(v916, v917 + 1);

                                            if v920 < 128 then
                                                v918 = v918 - 128 + v920 * 128;
                                                v919 = v917 + 2;
                                            else
                                                local v921 = u49(v916, v917 + 2);

                                                if v921 < 128 then
                                                    v918 = v918 - 128 + (v920 - 128) * 16384 + v921 * 128;
                                                    v919 = v917 + 3;
                                                else
                                                    local v922 = u49(v916, v917 + 3);
                                                    v918 = (v918 - 128) * 16384 + (v920 - 128) * 128 + (v921 - 128) + v922 % 128 * 2097152 + (v922 - v922 % 128) * 2097152;
                                                    v919 = v917 + 4;
                                                end;
                                            end;
                                        end;

                                        local v923 = v913 * 16843009;
                                        local v924 = v919 + v918;
                                        local v925 = v924 - v918 % 4;

                                        for i = v919, v925 - 1, 4 do
                                            u50(v916, i, (u39(u51(v916, i), v923)));
                                            local _ = i;
                                        end;

                                        for i = v925, v924 - 1 do
                                            u52(v916, i, (u39(u49(v916, i), v913)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735050040[u26] = 239;
                                        UNNAMED_2819735036840[u26] = 197;
                                        UNNAMED_2819735072456[u26] = 41;
                                        UNNAMED_2819735069192[u26] = 86;
                                    else
                                        v57 = UNNAMED_2819735072456[u26];
                                        v55 = UNNAMED_2819735050040[u26];
                                        v53 = UNNAMED_2819735036840[u26];
                                        v56 = v57 + v53 - 1;
                                        v54 = v57 + v55;
                                        v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                        u37(v58, 1, v53, v57, u25);
                                    end;
                                elseif v819 < 102 then
                                    if v819 < 99 then
                                        if v819 >= 97 then
                                            if v819 == 98 then
                                                local v926 = u33;
                                                local v927 = u34;

                                                if v926 then
                                                    for i in u36, v926 do
                                                        local v928 = v926[i];

                                                        if v928 then
                                                            v928[5] = v928;
                                                            v928[6] = u25[i];
                                                            v928[4] = 6;
                                                            v926[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v927 then
                                                    for i, v in u36, v927 do
                                                        local v929 = v[6];

                                                        if v927 then
                                                            local v930 = v927[i];

                                                            if v930 then
                                                                local v931 = u24(v929);
                                                                u37(u25, i, i + v929 - 1, 1, v931);
                                                                v930[5] = v931;
                                                                v930[4] = 1;
                                                                v927[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735050040[u26], u38(u25[UNNAMED_2819735072456[u26]]);
                                            end;

                                            u25[UNNAMED_2819735050040[u26]] = u45[UNNAMED_2819735036168[u26]];
                                        else
                                            v57 = UNNAMED_2819735036840[u26];
                                            local v932 = u25[UNNAMED_2819735050040[u26]];
                                            u25[v57] = u25[UNNAMED_2819735072456[u26]];
                                            u25[v57 + 1] = v932;
                                        end;
                                    elseif v819 >= 100 then
                                        if v819 == 101 then
                                            local v933 = UNNAMED_2819735050040[u26];
                                            local v934 = u39(UNNAMED_2819735036840[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));
                                            local v935 = UNNAMED_2819735071256[5];
                                            local v936 = u39(v935[v933], 109162203);
                                            v935[v933] = v936;
                                            local v937 = UNNAMED_2819735071256[4];
                                            local v938 = v936 + 1;
                                            local v939 = u49(v937, v938);
                                            local v940;

                                            if v939 < 128 then
                                                v940 = v938 + 1;
                                            else
                                                local v941 = u49(v937, v938 + 1);

                                                if v941 < 128 then
                                                    v939 = v939 - 128 + v941 * 128;
                                                    v940 = v938 + 2;
                                                else
                                                    local v942 = u49(v937, v938 + 2);

                                                    if v942 < 128 then
                                                        v939 = v939 - 128 + (v941 - 128) * 16384 + v942 * 128;
                                                        v940 = v938 + 3;
                                                    else
                                                        local v943 = u49(v937, v938 + 3);
                                                        v939 = (v939 - 128) * 16384 + (v941 - 128) * 128 + (v942 - 128) + v943 % 128 * 2097152 + (v943 - v943 % 128) * 2097152;
                                                        v940 = v938 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v944 = v934 * 16843009;
                                            local v945 = v940 + v939;
                                            local v946 = v945 - v939 % 4;

                                            for i = v940, v946 - 1, 4 do
                                                u50(v937, i, (u39(u51(v937, i), v944)));
                                                local _ = i;
                                            end;

                                            for i = v946, v945 - 1 do
                                                u52(v937, i, (u39(u49(v937, i), v934)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735050040[u26] = 187;
                                            UNNAMED_2819735036840[u26] = 245;
                                            UNNAMED_2819735072456[u26] = 185;
                                            UNNAMED_2819735069192[u26] = 86;
                                        else
                                            u26 = u25[UNNAMED_2819735036840[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735067512[u26], u35(u25[UNNAMED_2819735050040[u26]], 1, u25[UNNAMED_2819735050040[u26]].n));
                                    end;
                                elseif v819 >= 105 then
                                    if v819 < 106 then
                                        local v947 = UNNAMED_2819735072456[u26];
                                        local v948 = v947 + UNNAMED_2819735050040[u26];
                                        local v949 = u33;
                                        local v950 = u34;

                                        if v949 then
                                            for i in u36, v949 do
                                                local v951 = v949[i];

                                                if v951 then
                                                    v951[5] = v951;
                                                    v951[6] = u25[i];
                                                    v951[4] = 6;
                                                    v949[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v950 then
                                            for i, v in u36, v950 do
                                                local v952 = v[6];

                                                if v950 then
                                                    local v953 = v950[i];

                                                    if v953 then
                                                        local v954 = u24(v952);
                                                        u37(u25, i, i + v952 - 1, 1, v954);
                                                        v953[5] = v954;
                                                        v953[4] = 1;
                                                        v950[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, false, v947, v948;
                                    end;

                                    if v819 == 107 then
                                        local v955 = u33;
                                        local v956 = u34;

                                        if v955 then
                                            for i in u36, v955 do
                                                local v957 = v955[i];

                                                if v957 then
                                                    v957[5] = v957;
                                                    v957[6] = u25[i];
                                                    v957[4] = 6;
                                                    v955[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v956 then
                                            for i, v in u36, v956 do
                                                local v958 = v[6];

                                                if v956 then
                                                    local v959 = v956[i];

                                                    if v959 then
                                                        local v960 = u24(v958);
                                                        u37(u25, i, i + v958 - 1, 1, v960);
                                                        v959[5] = v960;
                                                        v959[4] = 1;
                                                        v956[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u38(UNNAMED_2819735067512[u26], UNNAMED_2819735043176[u26]);
                                    end;

                                    if u25[UNNAMED_2819735072456[u26]] >= UNNAMED_2819735036840[u26] then
                                        u26 = UNNAMED_2819735050040[u26];
                                    end;
                                elseif v819 < 103 then
                                    if UNNAMED_2819735036840[u26] > u25[UNNAMED_2819735072456[u26]] then
                                        u26 = UNNAMED_2819735050040[u26];
                                    end;
                                elseif v819 == 104 then
                                    u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] ~= UNNAMED_2819735067512[u26];
                                else
                                    v57 = UNNAMED_2819735036840[u26];
                                    v55 = UNNAMED_2819735072456[u26];
                                    v53 = UNNAMED_2819735050040[u26];
                                    v56 = u25[v57];
                                    u37(u25, v57 + 1, v57 + v55, v53 + 1, v56);
                                end;

                                v818 = 1;
                                continue;
                            end;

                            if v819 >= 48 then
                                if v819 < 72 then
                                    if v819 < 60 then
                                        if v819 >= 54 then
                                            if v819 >= 57 then
                                                if v819 < 58 then
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] + u25[UNNAMED_2819735036840[u26]];
                                                elseif v819 == 59 then
                                                    UNNAMED_2819769586744[UNNAMED_2819735050040[u26]][u25[UNNAMED_2819735072456[u26]]] = u25[UNNAMED_2819735036840[u26]];
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] < UNNAMED_2819735067512[u26];
                                                end;
                                            elseif v819 < 55 then
                                                u23 = u25[UNNAMED_2819735072456[u26]];
                                            elseif v819 == 56 then
                                                u25[UNNAMED_2819735050040[u26]] = u25;
                                            else
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] ~= u25[UNNAMED_2819735036840[u26]];
                                            end;
                                        elseif v819 >= 51 then
                                            if v819 < 52 then
                                                v57 = UNNAMED_2819735050040[u26] + 1;
                                                v55 = UNNAMED_2819735036840[u26];

                                                for i = 1, UNNAMED_2819735072456[u26] do
                                                    local v961 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                                    local v962 = u39(v961, (u41(v961, 13)));
                                                    v55 = u42(u39(v962, (u43(v962, 14))), 536870911);
                                                    UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 0), 127)));
                                                    UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 7), 127)));
                                                    UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 14), 127)));
                                                    UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 21), 127)));
                                                    v57 = v57 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735069192[u26] = 86;
                                            elseif v819 == 53 then
                                                u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735036840[u26]] > u25[UNNAMED_2819735072456[u26]];
                                            elseif u25[UNNAMED_2819735072456[u26]] > UNNAMED_2819735050040[u26] then
                                                u26 = UNNAMED_2819735036840[u26];
                                            end;
                                        else
                                            if v819 < 49 then
                                                local v963 = u33;
                                                local v964 = u34;

                                                if v963 then
                                                    for i in u36, v963 do
                                                        local v965 = v963[i];

                                                        if v965 then
                                                            v965[5] = v965;
                                                            v965[6] = u25[i];
                                                            v965[4] = 6;
                                                            v963[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v964 then
                                                    for i, v in u36, v964 do
                                                        local v966 = v[6];

                                                        if v964 then
                                                            local v967 = v964[i];

                                                            if v967 then
                                                                local v968 = u24(v966);
                                                                u37(u25, i, i + v966 - 1, 1, v968);
                                                                v967[5] = v968;
                                                                v967[4] = 1;
                                                                v964[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, false;
                                            end;

                                            if v819 ~= 50 then
                                                local v969 = u33;
                                                local v970 = u34;

                                                if v969 then
                                                    for i in u36, v969 do
                                                        local v971 = v969[i];

                                                        if v971 then
                                                            v971[5] = v971;
                                                            v971[6] = u25[i];
                                                            v971[4] = 6;
                                                            v969[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v970 then
                                                    for i, v in u36, v970 do
                                                        local v972 = v[6];

                                                        if v970 then
                                                            local v973 = v970[i];

                                                            if v973 then
                                                                local v974 = u24(v972);
                                                                u37(u25, i, i + v972 - 1, 1, v974);
                                                                v973[5] = v974;
                                                                v973[4] = 1;
                                                                v970[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819735036840[u26], u38(UNNAMED_2819735036168[u26], u35(u25[UNNAMED_2819735050040[u26]], 1, u25[UNNAMED_2819735050040[u26]].n));
                                            end;

                                            v57 = u25[UNNAMED_2819735050040[u26]];
                                            v55 = UNNAMED_2819735036840[u26];
                                            v53 = UNNAMED_2819735072456[u26];
                                            u37(v57, 1, v53, v55, u25);
                                        end;
                                    elseif v819 >= 66 then
                                        if v819 >= 69 then
                                            if v819 >= 70 then
                                                if v819 == 71 then
                                                    v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                                    v57[5][v57[4]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735050040[u26];
                                                else
                                                    u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735069192;
                                                end;
                                            else
                                                v57 = UNNAMED_2819735072456[u26];
                                                v55 = UNNAMED_2819735036840[u26];
                                                v53 = u39(u23, u42(u41(u23, 14), 262143), (u42(u41(u23, 28), 15)));
                                                v56 = UNNAMED_2819735050040[u26];
                                                v54 = v57 < 2097152 and 7 or 14;
                                                v58 = u41(v57, v54);
                                                local v975 = u42(v57, u43(1, v54) - 1);
                                                UNNAMED_2819735050040[u26] = u39(v56, 66, (u42(v53, 127)));
                                                UNNAMED_2819735036840[u26] = u39(v55, 83, (u42(u41(v53, 7), 127)));
                                                UNNAMED_2819735069192[u26] = u39(v58, 60, (u42(u41(v53, 21), 127)));
                                                UNNAMED_2819735072456[u26] = u39(v975, 7, (u42(u41(v53, 14), 127)));
                                                u26 = u26 - 1;
                                            end;
                                        elseif v819 < 67 then
                                            u45[UNNAMED_2819735067512[u26]] = u25[UNNAMED_2819735072456[u26]];
                                        elseif v819 == 68 then
                                            if u33 then
                                                local v976 = u33;
                                                local v977 = UNNAMED_2819735072456[u26];
                                                local v978 = v976[v977];

                                                if v978 then
                                                    v978[5] = v978;
                                                    v978[6] = u25[v977];
                                                    v978[4] = 6;
                                                    v976[v977] = nil;
                                                end;

                                                local v979 = u33;
                                                local v980 = UNNAMED_2819735050040[u26];
                                                local v981 = v979[v980];

                                                if v981 then
                                                    v981[5] = v981;
                                                    v981[6] = u25[v980];
                                                    v981[4] = 6;
                                                    v979[v980] = nil;
                                                end;

                                                local v982 = u33;
                                                local v983 = UNNAMED_2819735036840[u26];
                                                local v984 = v982[v983];

                                                if v984 then
                                                    v984[5] = v984;
                                                    v984[6] = u25[v983];
                                                    v984[4] = 6;
                                                    v982[v983] = nil;
                                                end;
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] // u25[UNNAMED_2819735050040[u26]];
                                        end;
                                    elseif v819 >= 63 then
                                        if v819 < 64 then
                                            u25[UNNAMED_2819735050040[u26]] = {};
                                        elseif v819 == 65 then
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] == u25[UNNAMED_2819735050040[u26]];
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735036840[u26]](UNNAMED_2819735036168[u26]);
                                        end;
                                    elseif v819 < 61 then
                                        u25[UNNAMED_2819735050040[u26]] = u42(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735067512[u26]);
                                    elseif v819 == 62 then
                                        if UNNAMED_2819735072456[u26] >= u25[UNNAMED_2819735036840[u26]] then
                                            u26 = UNNAMED_2819735050040[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735050040[u26] ^ u25[UNNAMED_2819735072456[u26]];
                                    end;
                                elseif v819 >= 84 then
                                    if v819 < 90 then
                                        if v819 < 87 then
                                            if v819 < 85 then
                                                u25[UNNAMED_2819735072456[u26]] = #u25[UNNAMED_2819735050040[u26]];
                                            elseif v819 ~= 86 then
                                                local v985 = UNNAMED_2819735050040[u26];
                                                local v986 = u25[UNNAMED_2819735036840[u26]];
                                                local v987 = u42(UNNAMED_2819735036168[u26], 4294967295);
                                                local v988 = u42(v986, 4294967295);
                                                local v989 = u42(v987, 65535);
                                                local v990 = u41(v987, 16);
                                                local v991 = u42(v988, 65535);
                                                local v992 = u41(v988, 16);
                                                local v993 = u42(v989 * v991 + u43(u42(v989 * v992 + v990 * v991, 65535), 16), 4294967295) % 4294967296;
                                                u25[v985] = v993 ~= v993 and 0 or v993 - v993 % 1;
                                            end;
                                        elseif v819 < 88 then
                                            u25[UNNAMED_2819735036840[u26]] = u43(u25[UNNAMED_2819735050040[u26]], UNNAMED_2819735072456[u26]);
                                        else
                                            if v819 == 89 then
                                                local v994 = u33;
                                                local v995 = u34;

                                                if v994 then
                                                    for i in u36, v994 do
                                                        local v996 = v994[i];

                                                        if v996 then
                                                            v996[5] = v996;
                                                            v996[6] = u25[i];
                                                            v996[4] = 6;
                                                            v994[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v995 then
                                                    for i, v in u36, v995 do
                                                        local v997 = v[6];

                                                        if v995 then
                                                            local v998 = v995[i];

                                                            if v998 then
                                                                local v999 = u24(v997);
                                                                u37(u25, i, i + v997 - 1, 1, v999);
                                                                v998[5] = v999;
                                                                v998[4] = 1;
                                                                v995[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                local v1000 = UNNAMED_2819735036840[u26];

                                                return false, false, v1000, v1000 + UNNAMED_2819735072456[u26] - 1;
                                            end;

                                            u25[UNNAMED_2819735036840[u26]][UNNAMED_2819735043176[u26]] = UNNAMED_2819735072456[u26];
                                        end;
                                    elseif v819 < 93 then
                                        if v819 >= 91 then
                                            if v819 == 92 then
                                                local v1001 = u33;
                                                local v1002 = u34;

                                                if v1001 then
                                                    for i in u36, v1001 do
                                                        local v1003 = v1001[i];

                                                        if v1003 then
                                                            v1003[5] = v1003;
                                                            v1003[6] = u25[i];
                                                            v1003[4] = 6;
                                                            v1001[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v1002 then
                                                    for i, v in u36, v1002 do
                                                        local v1004 = v[6];

                                                        if v1002 then
                                                            local v1005 = v1002[i];

                                                            if v1005 then
                                                                local v1006 = u24(v1004);
                                                                u37(u25, i, i + v1004 - 1, 1, v1006);
                                                                v1005[5] = v1006;
                                                                v1005[4] = 1;
                                                                v1002[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u38(u25[UNNAMED_2819735036840[u26]]);
                                            end;

                                            u25[UNNAMED_2819735072456[u26]](UNNAMED_2819735067512[u26]);
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u39(UNNAMED_2819735067512[u26], UNNAMED_2819735043176[u26]);
                                        end;
                                    else
                                        if v819 >= 94 then
                                            if v819 == 95 then
                                                local v1007 = u33;
                                                local v1008 = u34;

                                                if v1007 then
                                                    for i in u36, v1007 do
                                                        local v1009 = v1007[i];

                                                        if v1009 then
                                                            v1009[5] = v1009;
                                                            v1009[6] = u25[i];
                                                            v1009[4] = 6;
                                                            v1007[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v1008 then
                                                    for i, v in u36, v1008 do
                                                        local v1010 = v[6];

                                                        if v1008 then
                                                            local v1011 = v1008[i];

                                                            if v1011 then
                                                                local v1012 = u24(v1010);
                                                                u37(u25, i, i + v1010 - 1, 1, v1012);
                                                                v1011[5] = v1012;
                                                                v1011[4] = 1;
                                                                v1008[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u25[UNNAMED_2819735072456[u26]];
                                            end;

                                            local v1013 = u33;
                                            local v1014 = u34;

                                            if v1013 then
                                                for i in u36, v1013 do
                                                    local v1015 = v1013[i];

                                                    if v1015 then
                                                        v1015[5] = v1015;
                                                        v1015[6] = u25[i];
                                                        v1015[4] = 6;
                                                        v1013[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v1014 then
                                                for i, v in u36, v1014 do
                                                    local v1016 = v[6];

                                                    if v1014 then
                                                        local v1017 = v1014[i];

                                                        if v1017 then
                                                            local v1018 = u24(v1016);
                                                            u37(u25, i, i + v1016 - 1, 1, v1018);
                                                            v1017[5] = v1018;
                                                            v1017[4] = 1;
                                                            v1014[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819735036840[u26], u25[UNNAMED_2819735050040[u26]];
                                        end;

                                        u25[UNNAMED_2819735072456[u26]] = u45[UNNAMED_2819735043176[u26]][u25[UNNAMED_2819735036840[u26]]];
                                    end;
                                elseif v819 >= 78 then
                                    if v819 >= 81 then
                                        if v819 < 82 then
                                            u25[UNNAMED_2819735072456[u26]][UNNAMED_2819735067512[u26]] = UNNAMED_2819735043176[u26];
                                        elseif v819 == 83 then
                                            v57 = UNNAMED_2819735072456[u26];
                                            v55 = UNNAMED_2819735050040[u26];
                                            v53 = UNNAMED_2819735036840[u26];
                                            v56 = u25[v57];
                                            v54 = v57 + v55;
                                            v58 = u25[v54];
                                            u37(u25, v57 + 1, v54 - 1, v53 + 1, v56);
                                            u37(v58, 1, v58.n, v53 + v55, v56);
                                        else
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] .. UNNAMED_2819735036168[u26];
                                        end;
                                    elseif v819 >= 79 then
                                        if v819 == 80 then
                                            v57 = UNNAMED_2819735072456[u26];
                                            v55 = UNNAMED_2819735036840[u26];
                                            v53 = UNNAMED_2819735050040[u26];
                                            v56 = u39(u23, u42(u41(u23, 14), 262143), (u42(u41(u23, 28), 15)));
                                            v54 = v53 < 16384 and 7 or (v53 < 2097152 and 14 or 21);
                                            v58 = u41(v53, v54);
                                            UNNAMED_2819735050040[u26] = u39(u42(v53, u43(1, v54) - 1), 58, (u42(v56, 127)));
                                            UNNAMED_2819735036840[u26] = u39(v55, 44, (u42(u41(v56, 7), 127)));
                                            UNNAMED_2819735072456[u26] = u39(v57, 38, (u42(u41(v56, 14), 127)));
                                            UNNAMED_2819735069192[u26] = u39(v58, 20, (u42(u41(v56, 21), 127)));
                                            u26 = u26 - 1;
                                        else
                                            v57 = UNNAMED_2819735036840[u26];
                                            v55 = u25[UNNAMED_2819735050040[u26]];
                                            u25[v57 + 1] = v55;
                                            u25[v57] = v55[UNNAMED_2819735036168[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] % u25[UNNAMED_2819735072456[u26]];
                                    end;
                                elseif v819 >= 75 then
                                    if v819 < 76 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] > UNNAMED_2819735036840[u26];
                                    elseif v819 == 77 then
                                        if u25[UNNAMED_2819735050040[u26]] >= u25[UNNAMED_2819735072456[u26]] then
                                            u26 = UNNAMED_2819735036840[u26];
                                        end;
                                    else
                                        u25[UNNAMED_2819735050040[u26]]();
                                    end;
                                elseif v819 >= 73 then
                                    if v819 == 74 then
                                        u45[UNNAMED_2819735067512[u26]][u25[UNNAMED_2819735050040[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                    else
                                        v57 = UNNAMED_2819769586744[UNNAMED_2819735072456[u26]];
                                        v57[5][v57[4]] = u25[UNNAMED_2819735036840[u26]];
                                    end;
                                else
                                    u26 = UNNAMED_2819735050040[u26];
                                end;

                                v818 = 1;
                                continue;
                            end;

                            if v819 < 24 then
                                if v819 < 12 then
                                    if v819 < 6 then
                                        if v819 >= 3 then
                                            if v819 < 4 then
                                                v57 = UNNAMED_2819735072456[u26];
                                                local v1019 = UNNAMED_2819735067512[u26];
                                                u25[v57] = UNNAMED_2819735043176[u26];
                                                u25[v57 + 1] = v1019;
                                            else
                                                if v819 ~= 5 then
                                                    local v1020 = u33;
                                                    local v1021 = u34;

                                                    if v1020 then
                                                        for i in u36, v1020 do
                                                            local v1022 = v1020[i];

                                                            if v1022 then
                                                                v1022[5] = v1022;
                                                                v1022[6] = u25[i];
                                                                v1022[4] = 6;
                                                                v1020[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v1021 then
                                                        for i, v in u36, v1021 do
                                                            local v1023 = v[6];

                                                            if v1021 then
                                                                local v1024 = v1021[i];

                                                                if v1024 then
                                                                    local v1025 = u24(v1023);
                                                                    u37(u25, i, i + v1023 - 1, 1, v1025);
                                                                    v1024[5] = v1025;
                                                                    v1024[4] = 1;
                                                                    v1021[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819735036840[u26], u38(u25[UNNAMED_2819735072456[u26]], UNNAMED_2819735043176[u26]);
                                                end;

                                                if UNNAMED_2819735036168[u26] >= u25[UNNAMED_2819735036840[u26]] then
                                                    u26 = UNNAMED_2819735050040[u26];
                                                end;
                                            end;
                                        elseif v819 >= 1 then
                                            if v819 == 2 then
                                                u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819735067512[u26] .. u25[UNNAMED_2819735050040[u26]];
                                            elseif u25[UNNAMED_2819735036840[u26]] > u25[UNNAMED_2819735050040[u26]] then
                                                u26 = UNNAMED_2819735072456[u26];
                                            end;
                                        else
                                            u25[UNNAMED_2819735050040[u26]] = u40(u25[UNNAMED_2819735072456[u26]], u25[UNNAMED_2819735036840[u26]]);
                                        end;
                                    elseif v819 < 9 then
                                        if v819 < 7 then
                                            local v1026 = u33;
                                            local v1027 = u34;

                                            if v1026 then
                                                for i in u36, v1026 do
                                                    local v1028 = v1026[i];

                                                    if v1028 then
                                                        v1028[5] = v1028;
                                                        v1028[6] = u25[i];
                                                        v1028[4] = 6;
                                                        v1026[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v1027 then
                                                for i, v in u36, v1027 do
                                                    local v1029 = v[6];

                                                    if v1027 then
                                                        local v1030 = v1027[i];

                                                        if v1030 then
                                                            local v1031 = u24(v1029);
                                                            u37(u25, i, i + v1029 - 1, 1, v1031);
                                                            v1030[5] = v1031;
                                                            v1030[4] = 1;
                                                            v1027[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u38(UNNAMED_2819735036168[u26]);
                                        end;

                                        if v819 == 8 then
                                            u25[UNNAMED_2819735072456[u26]] = u39(u25[UNNAMED_2819735036840[u26]], u25[UNNAMED_2819735050040[u26]]);
                                        else
                                            u29 = u28[8];
                                            u30 = u28[5];
                                            u31 = u28[7];
                                            u32 = u28[6];
                                            u28 = u28[9];
                                        end;
                                    elseif v819 < 10 then
                                        if u25[UNNAMED_2819735036840[u26]] ~= UNNAMED_2819735050040[u26] then
                                            u26 = UNNAMED_2819735072456[u26];
                                        end;
                                    elseif v819 == 11 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] .. u25[UNNAMED_2819735036840[u26]];
                                    elseif UNNAMED_2819735036168[u26] > u25[UNNAMED_2819735036840[u26]] then
                                        u26 = UNNAMED_2819735050040[u26];
                                    end;
                                elseif v819 >= 18 then
                                    if v819 < 21 then
                                        if v819 >= 19 then
                                            if v819 == 20 then
                                                local v1032 = UNNAMED_2819735072456[u26];
                                                local v1033 = UNNAMED_2819735050040[u26];
                                                local v1034 = v1032 + v1033;
                                                local v1035 = u25[v1034];
                                                local n = v1035.n;
                                                local v1036 = u33;
                                                local v1037 = u34;

                                                if v1036 then
                                                    for i in u36, v1036 do
                                                        local v1038 = v1036[i];

                                                        if v1038 then
                                                            v1038[5] = v1038;
                                                            v1038[6] = u25[i];
                                                            v1038[4] = 6;
                                                            v1036[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v1037 then
                                                    for i, v in u36, v1037 do
                                                        local v1039 = v[6];

                                                        if v1037 then
                                                            local v1040 = v1037[i];

                                                            if v1040 then
                                                                local v1041 = u24(v1039);
                                                                u37(u25, i, i + v1039 - 1, 1, v1041);
                                                                v1040[5] = v1041;
                                                                v1040[4] = 1;
                                                                v1037[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                v1035.n = v1033 + n - 1;
                                                u37(v1035, 1, n, v1033, v1035);
                                                u37(u25, v1032 + 1, v1034 - 1, 1, v1035);

                                                return true, true, v1032, v1035;
                                            end;

                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735072456[u26]] ~= UNNAMED_2819735050040[u26];
                                        else
                                            u26 = u25[UNNAMED_2819735072456[u26]];
                                        end;
                                    elseif v819 < 22 then
                                        u25[UNNAMED_2819735072456[u26]] = UNNAMED_2819769586744[UNNAMED_2819735050040[u26]];
                                    elseif v819 == 23 then
                                        u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819735071256;
                                    else
                                        u25[UNNAMED_2819735072456[u26]] = not u25[UNNAMED_2819735036840[u26]];
                                    end;
                                elseif v819 >= 15 then
                                    if v819 >= 16 then
                                        if v819 == 17 then
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]] == UNNAMED_2819735072456[u26];
                                        elseif u25[UNNAMED_2819735050040[u26]] >= UNNAMED_2819735067512[u26] then
                                            u26 = UNNAMED_2819735072456[u26];
                                        end;
                                    else
                                        v57 = UNNAMED_2819735050040[u26] + 1;
                                        v55 = u39(UNNAMED_2819735036840[u26], (u42(u39(u23, (u42(u41(u23, 29), 7))), 536870911)));

                                        for i = 1, UNNAMED_2819735072456[u26] do
                                            local v1042 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                            local v1043 = u39(v1042, (u41(v1042, 13)));
                                            v55 = u42(u39(v1043, (u43(v1043, 14))), 536870911);
                                            UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 0), 127)));
                                            UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 7), 127)));
                                            UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 14), 127)));
                                            UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 21), 127)));
                                            v57 = v57 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735069192[u26] = 86;
                                    end;
                                elseif v819 < 13 then
                                    u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]][1];
                                elseif v819 == 14 then
                                    v57 = UNNAMED_2819735050040[u26];
                                    v55 = { ... };
                                    v53 = UNNAMED_2819735072456[u26];
                                    u37(v55, 1, v57 - 1, v53, u25);
                                    u25[v53 + v57 - 1] = u38(u44(v57, ...));
                                else
                                    v57 = UNNAMED_2819735050040[u26];
                                    local v1044 = UNNAMED_2819735067512[u26];
                                    u25[v57] = UNNAMED_2819735072456[u26];
                                    u25[v57 + 1] = v1044;
                                end;

                                v818 = 1;
                                continue;
                            end;

                            if v819 >= 36 then
                                if v819 < 42 then
                                    if v819 < 39 then
                                        if v819 < 37 then
                                            u25[UNNAMED_2819735036840[u26]](u25[UNNAMED_2819735072456[u26]]);
                                        elseif v819 == 38 then
                                            u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]];
                                        else
                                            v57 = UNNAMED_2819735050040[u26];
                                            v55 = UNNAMED_2819735036840[u26];
                                            v53 = UNNAMED_2819735072456[u26];
                                            v56 = v57 + v53 - 1;
                                            v54 = v57 + v55;
                                            v58 = u25[v54];
                                            local n = v58.n;
                                            v58.n = v55 + n - 1;
                                            u37(v58, 1, n, v55, v58);
                                            u37(u25, v57 + 1, v54 - 1, 1, v58);
                                            u37(u38(u25[v57](u35(v58, 1, v58.n))), 1, v53, v57, u25);
                                        end;
                                    elseif v819 < 40 then
                                        u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735050040[u26]] + UNNAMED_2819735036840[u26];
                                    elseif v819 == 41 then
                                        u25[UNNAMED_2819735050040[u26]](UNNAMED_2819735067512[u26], u25[UNNAMED_2819735072456[u26]]);
                                    else
                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] * u25[UNNAMED_2819735036840[u26]];
                                    end;
                                elseif v819 < 45 then
                                    if v819 >= 43 then
                                        if v819 == 44 then
                                            for i = UNNAMED_2819735036840[u26], UNNAMED_2819735072456[u26] do
                                                u25[i] = nil;
                                                local _ = i;
                                            end;
                                        else
                                            u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] / u25[UNNAMED_2819735050040[u26]];
                                        end;
                                    else
                                        u25[UNNAMED_2819735036840[u26]] = -u25[UNNAMED_2819735072456[u26]];
                                    end;
                                elseif v819 < 46 then
                                    u25[UNNAMED_2819735050040[u26]] = u39(u25[UNNAMED_2819735036840[u26]], UNNAMED_2819735072456[u26]);
                                elseif v819 == 47 then
                                    u25[UNNAMED_2819735050040[u26]](u35(u25[UNNAMED_2819735036840[u26]], 1, u25[UNNAMED_2819735036840[u26]].n));
                                else
                                    u25[UNNAMED_2819735036840[u26]] = u40(u25[UNNAMED_2819735050040[u26]], UNNAMED_2819735036168[u26]);
                                end;
                            elseif v819 >= 30 then
                                if v819 < 33 then
                                    if v819 < 31 then
                                        u25[UNNAMED_2819735050040[u26]] = u25[UNNAMED_2819735072456[u26]] < u25[UNNAMED_2819735036840[u26]];
                                    elseif v819 == 32 then
                                        u25[UNNAMED_2819735072456[u26]](u25[UNNAMED_2819735036840[u26]], u25[UNNAMED_2819735050040[u26]]);
                                    else
                                        u25[UNNAMED_2819735050040[u26]][u25[UNNAMED_2819735036840[u26]]] = u25[UNNAMED_2819735072456[u26]];
                                    end;
                                elseif v819 < 34 then
                                    v57 = UNNAMED_2819735036840[u26];
                                    v55 = u25[UNNAMED_2819735050040[u26]];
                                    u25[v57 + 1] = v55;
                                    u25[v57] = v55[UNNAMED_2819735036168[u26]];
                                    u25[UNNAMED_2819735036840[u26 + 1]] = u25[UNNAMED_2819735050040[u26 + 1]];
                                    u25[UNNAMED_2819735036840[u26 + 2]] = UNNAMED_2819735036168[u26 + 2];
                                    u25[UNNAMED_2819735036840[u26 + 3]] = u25[UNNAMED_2819735050040[u26 + 3]];
                                    u26 = u26 + 3;
                                else
                                    if v819 ~= 35 then
                                        local v1045 = u33;
                                        local v1046 = u34;

                                        if v1045 then
                                            for i in u36, v1045 do
                                                local v1047 = v1045[i];

                                                if v1047 then
                                                    v1047[5] = v1047;
                                                    v1047[6] = u25[i];
                                                    v1047[4] = 6;
                                                    v1045[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v1046 then
                                            for i, v in u36, v1046 do
                                                local v1048 = v[6];

                                                if v1046 then
                                                    local v1049 = v1046[i];

                                                    if v1049 then
                                                        local v1050 = u24(v1048);
                                                        u37(u25, i, i + v1048 - 1, 1, v1050);
                                                        v1049[5] = v1050;
                                                        v1049[4] = 1;
                                                        v1046[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819735072456[u26], u38();
                                    end;

                                    u25[UNNAMED_2819735050040[u26]] = UNNAMED_2819769586744[UNNAMED_2819735036840[u26]][u25[UNNAMED_2819735072456[u26]]];
                                end;
                            else
                                if v819 < 27 then
                                    if v819 < 25 then
                                        u25[UNNAMED_2819735036840[u26]] = u25[UNNAMED_2819735050040[u26]];
                                        v57 = UNNAMED_2819735072456[u26 + 1];
                                        v55 = UNNAMED_2819735050040[u26 + 1];
                                        v53 = UNNAMED_2819735036840[u26 + 1];
                                        v56 = v57 + v53 - 1;
                                        v54 = v57 + v55;
                                        v58 = u38(u25[v57](u35(u25, v57 + 1, v57 + v55)));
                                        u37(v58, 1, v53, v57, u25);
                                        u26 = u26 + 1;
                                    elseif v819 == 26 then
                                        u25[UNNAMED_2819735036840[u26]] = UNNAMED_2819735036840;
                                    else
                                        local v1051 = UNNAMED_2819735050040[u26];
                                        local v1052 = u25[UNNAMED_2819735072456[u26]];
                                        local v1053 = u42(u25[UNNAMED_2819735036840[u26]], 4294967295);
                                        local v1054 = u42(v1052, 4294967295);
                                        local v1055 = u42(v1053, 65535);
                                        local v1056 = u41(v1053, 16);
                                        local v1057 = u42(v1054, 65535);
                                        local v1058 = u41(v1054, 16);
                                        local v1059 = u42(v1055 * v1057 + u43(u42(v1055 * v1058 + v1056 * v1057, 65535), 16), 4294967295) % 4294967296;
                                        u25[v1051] = v1059 ~= v1059 and 0 or v1059 - v1059 % 1;
                                    end;

                                    v818 = 1;
                                    continue;
                                end;

                                if v819 < 28 then
                                    v57 = UNNAMED_2819735050040[u26] + 1;
                                    v55 = u39(UNNAMED_2819735036840[u26], (u42(u39(u22, (u42(u41(u22, 29), 7))), 536870911)));

                                    for i = 1, UNNAMED_2819735072456[u26] do
                                        local v1060 = u42(u39(v55, (u43(v55, 13))), 536870911);
                                        local v1061 = u39(v1060, (u41(v1060, 13)));
                                        v55 = u42(u39(v1061, (u43(v1061, 14))), 536870911);
                                        UNNAMED_2819735050040[v57] = u39(UNNAMED_2819735050040[v57], (u42(u41(v55, 0), 127)));
                                        UNNAMED_2819735036840[v57] = u39(UNNAMED_2819735036840[v57], (u42(u41(v55, 7), 127)));
                                        UNNAMED_2819735072456[v57] = u39(UNNAMED_2819735072456[v57], (u42(u41(v55, 14), 127)));
                                        UNNAMED_2819735069192[v57] = u39(UNNAMED_2819735069192[v57], (u42(u41(v55, 21), 127)));
                                        v57 = v57 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735069192[u26] = 86;
                                    v818 = 1;
                                    continue;
                                end;

                                if v819 == 29 then
                                    u27 = UNNAMED_2819735072456[u26];
                                    u26 = UNNAMED_2819735036840[u26] + 1;
                                    v59 = 1;
                                    break;
                                end;

                                u25[UNNAMED_2819735072456[u26]] = u25[UNNAMED_2819735036840[u26]] / UNNAMED_2819735050040[u26];
                            end;

                            v818 = 1;
                            continue;
                        elseif v818 == 1 then
                            v818 = -1;
                            u26 = u26 + 1;
                            break;
                        else
                            break;
                        end;
                    end;

                    if v59 ~= -1 then
                        break;
                    end;
                end;

                if v59 ~= -1 then
                    continue;
                end;

                break;
            else
                break;
            end;
        end;
    end, ...);

    if v1062 then
        if v1063 then
            if v1064 then
                return u25[v1065](u35(v1066, 1, v1066.n));
            end;

            return u25[v1065](u35(u25, v1065 + 1, v1066));
        end;

        if v1065 then
            if v1064 then
                return u35(v1065, 1, v1065.n);
            end;

            return u35(u25, v1065, v1066);
        end;
    else
        local v1067 = u33;
        local v1068 = u34;

        if v1067 then
            for i in u36, v1067 do
                local v1069 = v1067[i];

                if v1069 then
                    v1069[5] = v1069;
                    v1069[6] = u25[i];
                    v1069[4] = 6;
                    v1067[i] = nil;
                end;
            end;
        end;

        if v1068 then
            for i, v in u36, v1068 do
                local v1070 = v[6];

                if v1068 then
                    local v1071 = v1068[i];

                    if v1071 then
                        local v1072 = u24(v1070);
                        u37(u25, i, i + v1070 - 1, 1, v1072);
                        v1071[5] = v1072;
                        v1071[4] = 1;
                        v1068[i] = nil;
                    end;
                end;
            end;
        end;

        u21(UNNAMED_2819735031272, v1063, u26, UNNAMED_2819735075336);
    end;
end;