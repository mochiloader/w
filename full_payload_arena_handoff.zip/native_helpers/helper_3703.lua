-- Decompiled with Potassium's decompiler.

local v1, v2 = UNNAMED_2819712486216:z3(UNNAMED_2819712485976, UNNAMED_2819712486504, UNNAMED_2819712487032);

if v1 == 1 then
    return v2;
end;