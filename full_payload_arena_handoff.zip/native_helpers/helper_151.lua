-- Decompiled with Potassium's decompiler.

local v1 = UNNAMED_2819735068616[114];
v1();

for i, v in UNNAMED_2819735065592, UNNAMED_2819735050088, UNNAMED_2819735051480 do
    v1(true, i, v);
end;