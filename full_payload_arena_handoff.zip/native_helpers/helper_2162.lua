-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735069144;
local u2 = UNNAMED_2819735074760;
local u3 = UNNAMED_2819735037080;
local u4 = UNNAMED_2819735049176;
local u5 = UNNAMED_2819735083496;
local u6 = UNNAMED_2819735033816;
local u7 = UNNAMED_2819735079848;
local u8 = UNNAMED_2819735055224;
local u9 = UNNAMED_2819735087336;
local u10 = UNNAMED_2819735030168;
local u11 = UNNAMED_2819735030504;
local u12 = UNNAMED_2819735083832;
local u13 = UNNAMED_2819735042600;

return function(...) -- Line: 3
    -- upvalues: u1 (copy), UNNAMED_2819735081240 (ref), UNNAMED_2819735035928 (ref), UNNAMED_2819735090312 (ref), UNNAMED_2819735030936 (ref), u2 (copy), UNNAMED_2819735055704 (ref), u3 (copy), UNNAMED_2819735087720 (ref), UNNAMED_2819735037128 (ref), UNNAMED_2819735077544 (copy), u4 (copy), u5 (copy), u6 (copy), UNNAMED_2819735071496 (copy), UNNAMED_2819735069816 (ref), u7 (copy), u8 (copy), u9 (copy), u10 (copy), UNNAMED_2819735068472 (copy), UNNAMED_2819735084600 (ref), UNNAMED_2819735036552 (ref), u11 (copy), UNNAMED_2819735035496 (ref), UNNAMED_2819735052968 (ref), u12 (copy), u13 (copy)
    local v14, v15, v16, v17, v18, v19, v20, v21, v22, v23;
    local v24 = 0;

    while true do
        if v24 == 0 then
            v24 = -1;
            v14 = u1(UNNAMED_2819735081240);

            if UNNAMED_2819735035928 ~= 94 then
                v15 = UNNAMED_2819735090312;
                v16 = UNNAMED_2819735035928;
                v24 = 4;
                continue;
            end;

            v17 = UNNAMED_2819735090312;
            v18 = UNNAMED_2819735035928;
            v24 = 1;
            continue;
        elseif v24 == 1 then
            v24 = -1;
            v19 = UNNAMED_2819735030936[v17];

            if v19 >= 5 then
                v24 = 2;
                continue;
            end;

            if v19 < 2 then
                if v19 ~= 1 then
                    u6({ ... }, 1, 6, UNNAMED_2819735030936[v17 + 1], v14);
                    v14[UNNAMED_2819735055704[v17]] = 50;
                    local v25 = v14[81];
                    v14[1] = v14[53];
                    v14[2] = v25;
                    v14[21] = v14[UNNAMED_2819735087720[v17]];
                    v14[6] = v14[UNNAMED_2819735087720[v17 + 1]];
                    v14[UNNAMED_2819735037128[v17 + 1]] = v14[73];
                    v14[5] = v14[88];
                    v14[23] = v14[113];
                    v17 = v17 + 1;
                end;
            elseif v19 >= 3 then
                if v19 == 4 then
                    v17 = u2(UNNAMED_2819735037128[v17], (u3(u2(UNNAMED_2819735030936[v17], 92, v18), 127)));
                else
                    local v26 = u2(UNNAMED_2819735055704[v17], (u3(u2(UNNAMED_2819735071496, (u3(u4(UNNAMED_2819735071496, 29), 7))), 536870911)));
                    local v27 = UNNAMED_2819735087720[v17] + 1;

                    for i = 1, UNNAMED_2819735037128[v17] do
                        local v28 = u3(u2(v26, (u5(v26, 13))), 536870911);
                        local v29 = u2(v28, (u4(v28, 13)));
                        v26 = u3(u2(v29, (u5(v29, 14))), 536870911);
                        UNNAMED_2819735087720[v27] = u2(UNNAMED_2819735087720[v27], (u3(u4(v26, 0), 127)));
                        UNNAMED_2819735055704[v27] = u2(UNNAMED_2819735055704[v27], (u3(u4(v26, 7), 127)));
                        UNNAMED_2819735037128[v27] = u2(UNNAMED_2819735037128[v27], (u3(u4(v26, 14), 127)));
                        UNNAMED_2819735030936[v27] = u2(UNNAMED_2819735030936[v27], (u3(u4(v26, 21), 127)));
                        v27 = v27 + 1;
                        local _ = i;
                    end;

                    UNNAMED_2819735030936[v17] = 1;
                end;
            else
                v14[u2(UNNAMED_2819735087720[v17], (u3(u2(1, UNNAMED_2819735030936[v17]), 127)))] = v14[UNNAMED_2819735055704[v17]];
            end;

            v24 = 18;
            continue;
        elseif v24 == 2 then
            v24 = -1;

            if v19 >= 8 then
                v24 = 17;
                continue;
            end;

            if v19 < 6 then
                v24 = 3;
                continue;
            end;

            v24 = 16;
            continue;
        elseif v24 == 3 then
            v24 = -1;
            v16 = UNNAMED_2819735055704[v17];
            v15 = u2(UNNAMED_2819735037128[v17], (u3(u2(UNNAMED_2819735030936[v17], 28), 127))) + 1;
            v24 = 4;
            continue;
        elseif v24 == 4 then
            v24 = -1;

            if v16 == 127 then
                local v30;
                local v15, v16, v30;
                local v31 = 0;

                while true do
                    if v31 == 0 then
                        v31 = -1;
                        v30 = UNNAMED_2819735037128[v15];

                        if v30 < 5 then
                            if v30 >= 2 then
                                if v30 < 3 then
                                    v14[u2(UNNAMED_2819735055704[v15], 58)] = v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735037128[v15], 127)))];
                                elseif v30 == 4 then
                                    local v32 = UNNAMED_2819735087720[v15];
                                    local v33 = u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735077544, (u3(u4(UNNAMED_2819735077544, 29), 7))), 536870911)));
                                    local v34 = UNNAMED_2819735069816[5];
                                    local v35 = u2(v34[v32], 109162203);
                                    v34[v32] = v35;
                                    local v36 = UNNAMED_2819735069816[4];
                                    local v37 = v35 + 1;
                                    local v38 = u7(v36, v37);
                                    local v39;

                                    if v38 < 128 then
                                        v39 = v37 + 1;
                                    else
                                        local v40 = u7(v36, v37 + 1);

                                        if v40 < 128 then
                                            v38 = v38 - 128 + v40 * 128;
                                            v39 = v37 + 2;
                                        else
                                            local v41 = u7(v36, v37 + 2);

                                            if v41 < 128 then
                                                v38 = v38 - 128 + (v40 - 128) * 16384 + v41 * 128;
                                                v39 = v37 + 3;
                                            else
                                                local v42 = u7(v36, v37 + 3);
                                                v38 = (v38 - 128) * 16384 + (v40 - 128) * 128 + (v41 - 128) + v42 % 128 * 2097152 + (v42 - v42 % 128) * 2097152;
                                                v39 = v37 + 4;
                                            end;
                                        end;
                                    end;

                                    local v43 = v33 * 16843009;
                                    local v44 = v39 + v38;
                                    local v45 = v44 - v38 % 4;

                                    for i = v39, v45 - 1, 4 do
                                        u8(v36, i, (u2(u9(v36, i), v43)));
                                        local _ = i;
                                    end;

                                    for i = v45, v44 - 1 do
                                        u10(v36, i, (u2(u7(v36, i), v33)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735087720[v15] = 168;
                                    UNNAMED_2819735030936[v15] = 126;
                                    UNNAMED_2819735055704[v15] = 198;
                                    UNNAMED_2819735037128[v15] = 8;
                                elseif v14[UNNAMED_2819735030936[v15]] > u2(UNNAMED_2819735055704[v15], (u3(u2(v16, UNNAMED_2819735037128[v15]), 127))) then
                                    v15 = UNNAMED_2819735087720[v15];
                                end;
                            elseif v30 == 1 then
                                v15 = u2(UNNAMED_2819735087720[v15], (u3(u2(v16, 126, UNNAMED_2819735037128[v15]), 127)));
                            else
                                local v46 = UNNAMED_2819735030936[v15];
                                local v47 = UNNAMED_2819735055704[v15];
                                local v48 = u2(UNNAMED_2819735071496, u3(u4(UNNAMED_2819735071496, 14), 262143), (u3(u4(UNNAMED_2819735071496, 28), 15)));
                                local v49 = UNNAMED_2819735087720[v15];
                                local v50 = v46 < 16384 and 7 or (v46 < 2097152 and 14 or 21);
                                local v51 = u3(v46, u5(1, v50) - 1);
                                local v52 = u4(v46, v50);
                                UNNAMED_2819735087720[v15] = u2(v49, 122, (u3(v48, 127)));
                                UNNAMED_2819735030936[v15] = u2(v51, 107, (u3(u4(v48, 7), 127)));
                                UNNAMED_2819735037128[v15] = u2(v52, 39, (u3(u4(v48, 21), 127)));
                                UNNAMED_2819735055704[v15] = u2(v47, 77, (u3(u4(v48, 14), 127)));
                                v15 = v15 - 1;
                            end;

                            v31 = 1;
                            continue;
                        end;

                        if v30 >= 7 then
                            v31 = 2;
                            continue;
                        end;

                        if v30 == 6 then
                            v14[UNNAMED_2819735087720[v15]] = UNNAMED_2819735055704[v15];
                        else
                            v15 = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v16, 67), 127)))];
                        end;

                        v31 = 1;
                        continue;
                    elseif v31 == 1 then
                        v31 = -1;
                        v15 = v15 + 1;
                        v31 = 0;
                        continue;
                    elseif v31 == 2 then
                        v31 = -1;

                        if v30 >= 8 then
                            if v30 == 9 then
                                local v53 = u2(UNNAMED_2819735087720[v15], (u3(v15, 127)));
                                local v54 = v14[UNNAMED_2819735030936[v15]];
                                local v55 = v14[u2(UNNAMED_2819735055704[v15], (u3(u2(v16, v15), 127)))];
                                v14[v53] = v54;
                                v14[v53 + 1] = v55;
                            end;

                            v31 = 1;
                            continue;
                        end;

                        v16 = u2(UNNAMED_2819735087720[v15], (u3(UNNAMED_2819735037128[v15], 127)));
                        v15 = u2(UNNAMED_2819735055704[v15], 92) + 1;
                        break;
                    else
                        break;
                    end;
                end;
            end;

            if v16 == 236 then
                while true do
                    local v15;
                    local v56 = 0;

                    while true do
                        if v56 == 0 then
                            v56 = -1;
                            local v57 = UNNAMED_2819735087720[v15];

                            if v57 < 3 then
                                if v57 < 1 then
                                    local v58 = UNNAMED_2819735037128[v15];
                                    local v59 = UNNAMED_2819735055704[v15];
                                    local v60 = UNNAMED_2819735030936[v15];
                                    local v61 = u2(UNNAMED_2819735068472, u3(u4(UNNAMED_2819735068472, 14), 262143), (u3(u4(UNNAMED_2819735068472, 28), 15)));
                                    local v62 = v60 < 16384 and 7 or (v60 < 2097152 and 14 or 21);
                                    local v63 = u3(v60, u5(1, v62) - 1);
                                    UNNAMED_2819735087720[v15] = u2(u4(v60, v62), 7, (u3(u4(v61, 21), 127)));
                                    UNNAMED_2819735037128[v15] = u2(v58, 116, (u3(u4(v61, 7), 127)));
                                    UNNAMED_2819735030936[v15] = u2(v63, 109, (u3(u4(v61, 14), 127)));
                                    UNNAMED_2819735055704[v15] = u2(v59, 27, (u3(v61, 127)));
                                    v15 = v15 - 1;
                                elseif v57 == 2 then
                                    if v14[u2(UNNAMED_2819735030936[v15], 117)] > u2(UNNAMED_2819735055704[v15], (u3(u2(v16, 41), 127))) then
                                        v15 = UNNAMED_2819735037128[v15];
                                    end;
                                else
                                    v15 = u2(UNNAMED_2819735055704[v15], (u3(u2(UNNAMED_2819735087720[v15], 61, v16), 127)));
                                end;

                                v56 = 1;
                                continue;
                            end;

                            if v57 < 4 then
                                v15 = v14[u2(UNNAMED_2819735055704[v15], (u3(u2(77, v16, UNNAMED_2819735087720[v15]), 127)))];
                                v56 = 1;
                                continue;
                            end;

                            if v57 == 5 then
                                v56 = -2;
                                break;
                            end;

                            v14[UNNAMED_2819735030936[v15]] = UNNAMED_2819735055704[v15];
                            v56 = 1;
                            continue;
                        elseif v56 == 1 then
                            v56 = -1;
                            v15 = v15 + 1;
                            break;
                        else
                            break;
                        end;
                    end;

                    if v56 == -2 then
                        break;
                    end;
                end;

                v16 = u2(UNNAMED_2819735055704[v15], 102);
                v15 = u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735087720[v15], 127))) + 1;
            end;

            if v16 ~= 124 then
                v21 = UNNAMED_2819735077544;
                v24 = 10;
                continue;
            end;

            v22 = UNNAMED_2819735071496;
            v21 = UNNAMED_2819735077544;
            v20 = UNNAMED_2819735068472;
            v24 = 5;
            continue;
        elseif v24 == 5 then
            v24 = -1;
            v23 = UNNAMED_2819735055704[v15];

            if v23 >= 52 then
                v24 = 14;
                continue;
            end;

            if v23 < 26 then
                v24 = 6;
                continue;
            end;

            if v23 < 39 then
                if v23 < 32 then
                    if v23 >= 29 then
                        if v23 >= 30 then
                            if v23 == 31 then
                                if v14[UNNAMED_2819735030936[v15]] ~= u2(UNNAMED_2819735037128[v15], (u3(v16, 127))) then
                                    v15 = u2(UNNAMED_2819735087720[v15], (u3(u2(UNNAMED_2819735055704[v15], v16), 127)));
                                end;
                            else
                                local v64 = u2(UNNAMED_2819735087720[v15], (u3(u2(v20, (u3(u4(v20, 29), 7))), 536870911)));
                                local v65 = UNNAMED_2819735030936[v15] + 1;

                                for i = 1, UNNAMED_2819735037128[v15] do
                                    local v66 = u3(u2(v64, (u5(v64, 13))), 536870911);
                                    local v67 = u2(v66, (u4(v66, 13)));
                                    v64 = u3(u2(v67, (u5(v67, 14))), 536870911);
                                    UNNAMED_2819735030936[v65] = u2(UNNAMED_2819735030936[v65], (u3(u4(v64, 0), 127)));
                                    UNNAMED_2819735087720[v65] = u2(UNNAMED_2819735087720[v65], (u3(u4(v64, 7), 127)));
                                    UNNAMED_2819735037128[v65] = u2(UNNAMED_2819735037128[v65], (u3(u4(v64, 14), 127)));
                                    UNNAMED_2819735055704[v65] = u2(UNNAMED_2819735055704[v65], (u3(u4(v64, 21), 127)));
                                    v65 = v65 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735055704[v15] = 96;
                            end;
                        else
                            v14[UNNAMED_2819735030936[v15]] = u3(v14[UNNAMED_2819735087720[v15]], v14[u2(UNNAMED_2819735037128[v15], (u3(v16, 127)))]);
                        end;
                    elseif v23 < 27 then
                        v14[u2(UNNAMED_2819735037128[v15], (u3(v16, 127)))] = v14[UNNAMED_2819735030936[v15]] % v14[UNNAMED_2819735087720[v15]];
                    elseif v23 == 28 then
                        v14[u2(UNNAMED_2819735087720[v15], (u3(u2(108, UNNAMED_2819735055704[v15], v16), 127)))] = v14[UNNAMED_2819735037128[v15]] >= v14[u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735055704[v15], v15, v16), 127)))];
                    else
                        v14[33] = UNNAMED_2819735036552[v15 + 2];
                        v14[5] = UNNAMED_2819735035496[v15 + 2];
                        v14[23] = UNNAMED_2819735036552[v15];
                        v14[UNNAMED_2819735055704[v15 + 1]] = 67108864;
                        v14[551] = UNNAMED_2819735035496[v15 + 1];
                        v14[552] = 46628761;
                        v14[553] = UNNAMED_2819735055704[v15 + 2];
                        v14[UNNAMED_2819735030936[v15 + 1]] = v14[UNNAMED_2819735030936[v15 + 2]];
                        v15 = v15 + 2;
                    end;
                elseif v23 < 35 then
                    if v23 < 33 then
                        if v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v16, UNNAMED_2819735055704[v15]), 127)))] then
                            v15 = u2(UNNAMED_2819735087720[v15], (u3(u2(57, UNNAMED_2819735055704[v15]), 127)));
                        else
                            v15 = u2(UNNAMED_2819735030936[v15], (u3(u2(v16, 45, UNNAMED_2819735055704[v15]), 127)));
                        end;
                    elseif v23 == 34 then
                        v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127))) + v14[UNNAMED_2819735087720[v15]]] = v14[u2(UNNAMED_2819735037128[v15], (u3(u2(118, UNNAMED_2819735055704[v15]), 127)))];
                    else
                        local v68 = u2(UNNAMED_2819735037128[v15], (u3(UNNAMED_2819735055704[v15], 127)));
                        local v69 = UNNAMED_2819735035496[v15];
                        v14[v68] = UNNAMED_2819735084600[v15];
                        v14[v68 + 1] = v69;
                    end;
                elseif v23 < 37 then
                    if v23 == 36 then
                        v14[UNNAMED_2819735087720[v15]] = v14[UNNAMED_2819735037128[v15]] <= u2(UNNAMED_2819735030936[v15], (u3(u2(60, v15, v16), 127)));
                    else
                        local v70 = UNNAMED_2819735037128[v15];
                        local v71 = UNNAMED_2819735087720[v15] + 1;

                        for i = 1, UNNAMED_2819735030936[v15] do
                            local v72 = u3(u2(v70, (u5(v70, 13))), 536870911);
                            local v73 = u2(v72, (u4(v72, 13)));
                            v70 = u3(u2(v73, (u5(v73, 14))), 536870911);
                            UNNAMED_2819735030936[v71] = u2(UNNAMED_2819735030936[v71], (u3(u4(v70, 0), 127)));
                            UNNAMED_2819735087720[v71] = u2(UNNAMED_2819735087720[v71], (u3(u4(v70, 7), 127)));
                            UNNAMED_2819735037128[v71] = u2(UNNAMED_2819735037128[v71], (u3(u4(v70, 14), 127)));
                            UNNAMED_2819735055704[v71] = u2(UNNAMED_2819735055704[v71], (u3(u4(v70, 21), 127)));
                            v71 = v71 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735055704[v15] = 96;
                    end;
                elseif v23 == 38 then
                    v14[u2(UNNAMED_2819735030936[v15], (u3(v16, 127)))] = v22;
                else
                    v14[u2(UNNAMED_2819735087720[v15], (u3(u2(40, v15, UNNAMED_2819735055704[v15]), 127)))] = {};
                end;
            elseif v23 >= 45 then
                if v23 >= 48 then
                    if v23 >= 50 then
                        if v23 == 51 then
                            local v74 = UNNAMED_2819735030936[v15];
                            local v75 = v14[u2(UNNAMED_2819735087720[v15], 27)];
                            local v76 = v14[UNNAMED_2819735037128[v15]];
                            v14[v74] = v75;
                            v14[v74 + 1] = v76;
                        else
                            v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v15, v16, 49), 127)))] = v21;
                        end;
                    elseif v23 == 49 then
                        local v77 = UNNAMED_2819735087720[v15];
                        local v78 = u2(v20, u3(u4(v20, 14), 262143), (u3(u4(v20, 28), 15)));
                        local v79 = UNNAMED_2819735030936[v15];
                        local v80 = UNNAMED_2819735037128[v15];
                        local v81 = v79 < 2097152 and 7 or 14;
                        local v82 = u4(v79, v81);
                        UNNAMED_2819735030936[v15] = u2(u3(v79, u5(1, v81) - 1), 3, (u3(v78, 127)));
                        UNNAMED_2819735087720[v15] = u2(v77, 69, (u3(u4(v78, 7), 127)));
                        UNNAMED_2819735037128[v15] = u2(v80, 84, (u3(u4(v78, 14), 127)));
                        UNNAMED_2819735055704[v15] = u2(v82, 94, (u3(u4(v78, 21), 127)));
                        v15 = v15 - 1;
                    else
                        v14[1] = v14[UNNAMED_2819735055704[v15 + 1]] - v14[1];
                        v14[1] = v14[UNNAMED_2819735087720[v15 + 1]] / v14[551];
                        v14[13][v14[UNNAMED_2819735037128[v15]]] = v14[1];
                        v14[1] = v22;
                        v14[1] = u2(v14[1], UNNAMED_2819735084600[v15]);
                        v22 = v14[1];
                        v14[20] = 1;
                        v15 = v15 + 1;
                    end;
                elseif v23 >= 46 then
                    if v23 == 47 then
                        local v83 = UNNAMED_2819735037128[v15];
                        local v84 = UNNAMED_2819735087720[v15];
                        local v85 = u2(UNNAMED_2819735030936[v15], 103);
                        local _ = v83 + v85 - 1;
                        local _ = v83 + v84;
                        u6(u12(v14[v83](u13(v14, v83 + 1, v83 + v84))), 1, v85, v83, v14);
                    else
                        v14[u2(UNNAMED_2819735037128[v15], (u3(u2(4, v16), 127)))] = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735055704[v15], v16, v15), 127)))] + UNNAMED_2819735087720[v15];
                    end;
                else
                    v14[UNNAMED_2819735087720[v15]] = UNNAMED_2819735037128[v15];
                end;
            elseif v23 < 42 then
                if v23 < 40 then
                    v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v15, UNNAMED_2819735055704[v15], 63), 127)))] = u1(UNNAMED_2819735087720[v15]);
                elseif v23 == 41 then
                    local v86 = UNNAMED_2819735087720[v15];
                    local v87 = UNNAMED_2819735030936[v15];
                    local v88 = u2(v20, u3(u4(v20, 14), 262143), (u3(u4(v20, 28), 15)));
                    local v89 = UNNAMED_2819735037128[v15];
                    local v90 = v86 < 16384 and 7 or (v86 < 2097152 and 14 or 21);
                    local v91 = u4(v86, v90);
                    local v92 = u3(v86, u5(1, v90) - 1);
                    UNNAMED_2819735037128[v15] = u2(v89, 84, (u3(u4(v88, 14), 127)));
                    UNNAMED_2819735030936[v15] = u2(v87, 97, (u3(v88, 127)));
                    UNNAMED_2819735087720[v15] = u2(v92, 22, (u3(u4(v88, 7), 127)));
                    UNNAMED_2819735055704[v15] = u2(v91, 122, (u3(u4(v88, 21), 127)));
                    v15 = v15 - 1;
                else
                    v14[u2(UNNAMED_2819735087720[v15], 89)] = UNNAMED_2819735037128[v15] - v14[u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735055704[v15], v15), 127)))];
                end;
            elseif v23 >= 43 then
                if v23 == 44 then
                    v14[u2(UNNAMED_2819735087720[v15], (u3(v16, 127)))] = v14[UNNAMED_2819735030936[v15] + v14[UNNAMED_2819735037128[v15]]];
                else
                    v21 = v14[1];
                    v14[32][70] = UNNAMED_2819735087720[v15];
                    v14[32][53] = 5;
                    v14[32][UNNAMED_2819735030936[v15]] = UNNAMED_2819735037128[v15];
                    v14[32][67] = 12;
                    v14[33] = v22;
                end;
            else
                v14[2] = v14[2] * v14[552];
                v14[1] = v14[UNNAMED_2819735055704[v15 + 1]] * v14[25];
                v14[UNNAMED_2819735055704[v15 + 2]] = v14[UNNAMED_2819735030936[v15 + 2]] + v14[2];
                v14[1] = v14[UNNAMED_2819735087720[v15 + 2]] % v14[UNNAMED_2819735037128[v15 + 2]];
                v14[UNNAMED_2819735030936[v15]] = v14[UNNAMED_2819735087720[v15 + 1]] + v14[UNNAMED_2819735030936[v15 + 1]];
                v14[UNNAMED_2819735037128[v15]] = v14[UNNAMED_2819735037128[v15 + 1]] % v14[23];
                v14[UNNAMED_2819735087720[v15]] = v20;
                v15 = v15 + 2;
            end;

            v24 = 13;
            continue;
        elseif v24 == 6 then
            v24 = -1;

            if v23 >= 13 then
                v24 = 7;
                continue;
            end;

            if v23 < 6 then
                if v23 >= 3 then
                    if v23 < 4 then
                        v14[u2(UNNAMED_2819735037128[v15], (u3(u2(UNNAMED_2819735055704[v15], v16, v15), 127)))] = v14[UNNAMED_2819735087720[v15]] - v14[UNNAMED_2819735030936[v15]];
                    elseif v23 == 5 then
                        v14[15] = UNNAMED_2819735036552[v15 + 1] + UNNAMED_2819735035496[v15 + 1];
                        v14[17] = 1 - v14[15];
                        v14[18] = UNNAMED_2819735035496[v15] + UNNAMED_2819735084600[v15];
                        v14[14] = u1(UNNAMED_2819735055704[v15 + 1]);
                        v14[16] = v14[0];
                        v14[19] = v14[9];
                        v15 = v15 + 1;
                    else
                        v14[UNNAMED_2819735030936[v15]] = v14[u2(UNNAMED_2819735087720[v15], (u3(v16, 127)))] * v14[u2(UNNAMED_2819735037128[v15], (u3(v16, 127)))];
                    end;
                elseif v23 < 1 then
                    local v93 = u2(UNNAMED_2819735030936[v15], (u3(u2(v15, v16), 127)));
                    local v94 = UNNAMED_2819735037128[v15];
                    u2(UNNAMED_2819735087720[v15], 102);
                    v14[v93] = u12(v14[v93](u13(v14, v93 + 1, v93 + v94)));
                elseif v23 == 2 then
                    v14[u2(UNNAMED_2819735087720[v15], (u3(UNNAMED_2819735055704[v15], 127)))] = UNNAMED_2819735036552[v15];
                else
                    v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v16, 71), 127)))] = v14[UNNAMED_2819735037128[v15]] + v14[UNNAMED_2819735087720[v15]];
                end;
            elseif v23 >= 9 then
                if v23 >= 11 then
                    if v23 == 12 then
                        v14[UNNAMED_2819735037128[v15]] = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(26, UNNAMED_2819735055704[v15], v15), 127)))] < UNNAMED_2819735087720[v15];
                    else
                        v14[1] = v14[9][UNNAMED_2819735055704[v15 + 1]];
                        v14[2] = v14[9][4];
                        v14[3] = v14[UNNAMED_2819735087720[v15]][5];
                        v14[1] = v14[1] + v14[2];
                        v14[UNNAMED_2819735087720[v15 + 1]] = v14[UNNAMED_2819735037128[v15]] <= 0;
                        v14[4] = not v14[2];
                        v14[UNNAMED_2819735037128[v15 + 1]] = v14[1] >= v14[3];
                        v14[3] = v14[UNNAMED_2819735030936[v15 + 1]] <= v14[3];
                        v15 = v15 + 1;
                    end;
                elseif v23 == 10 then
                    v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127)))] = v14[UNNAMED_2819735037128[v15]] - u2(UNNAMED_2819735087720[v15], (u3(u2(56, v16), 127)));
                else
                    v14[u2(UNNAMED_2819735087720[v15], (u3(UNNAMED_2819735055704[v15], 127)))] = v14[UNNAMED_2819735030936[v15]] ~= v14[u2(UNNAMED_2819735037128[v15], (u3(u2(UNNAMED_2819735055704[v15], v15), 127)))];
                end;
            elseif v23 >= 7 then
                if v23 == 8 then
                    v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v16, UNNAMED_2819735055704[v15], v15), 127)))] = v14[UNNAMED_2819735087720[v15]] == UNNAMED_2819735030936[v15];
                else
                    v14[u2(UNNAMED_2819735030936[v15], (u3(v15, 127)))] = u2(v14[UNNAMED_2819735037128[v15]], UNNAMED_2819735035496[v15]);
                end;
            else
                v14[1] = v14[UNNAMED_2819735055704[v15 + 1]] % v14[25];
                v14[2] = v14[33] - v14[UNNAMED_2819735055704[v15 + 2]];
                v14[2] = v14[UNNAMED_2819735030936[v15 + 1]] / v14[UNNAMED_2819735087720[v15 + 2]];
                v14[UNNAMED_2819735030936[v15 + 2]] = v14[2] * v14[UNNAMED_2819735037128[v15 + 1]];
                v14[UNNAMED_2819735030936[v15]] = v14[1] * v14[553];
                v14[4] = v14[UNNAMED_2819735037128[v15 + 2]];
                v15 = v15 + 2;
            end;

            v24 = 13;
            continue;
        elseif v24 == 7 then
            v24 = -1;

            if v23 < 19 then
                v24 = 8;
                continue;
            end;

            if v23 >= 22 then
                if v23 >= 24 then
                    if v23 == 25 then
                        for i = u2(UNNAMED_2819735037128[v15], (u3(u2(v15, v16, 104), 127))), u2(UNNAMED_2819735087720[v15], (u3(u2(v16, 89), 127))) do
                            v14[i] = nil;
                            local _ = i;
                        end;
                    else
                        v14[1] = v14[9][2];
                        v14[UNNAMED_2819735055704[v15 + 1]] = v14[9][4];
                        v14[3] = v14[9][UNNAMED_2819735030936[v15]];
                        v14[UNNAMED_2819735037128[v15 + 1]] = v14[UNNAMED_2819735030936[v15 + 1]] + v14[2];
                        v14[UNNAMED_2819735037128[v15]] = v14[2] <= 0;
                        v14[4] = not v14[2];
                        v15 = v15 + 1;
                    end;
                elseif v23 == 23 then
                    v14[UNNAMED_2819735030936[v15]] = v14[u2(UNNAMED_2819735087720[v15], (u3(UNNAMED_2819735055704[v15], 127)))];
                else
                    v14[18] = UNNAMED_2819735035496[v15 + 3] + UNNAMED_2819735084600[v15];
                    v14[16] = UNNAMED_2819735055704[v15 + 3] - v14[UNNAMED_2819735055704[v15 + 1]];
                    v14[UNNAMED_2819735055704[v15 + 2]] = UNNAMED_2819735035496[v15 + 2] + UNNAMED_2819735036552[v15 + 1];
                    v14[UNNAMED_2819735037128[v15]] = u1(UNNAMED_2819735030936[v15 + 1]);
                    v14[UNNAMED_2819735087720[v15 + 1]] = v14[0];
                    v14[15] = v14[UNNAMED_2819735037128[v15 + 2]];
                    local v95 = UNNAMED_2819735030936[v15 + 3];
                    u6(v14, v95 + 1, v95 + UNNAMED_2819735030936[v15 + 2], 1, v14[v95]);
                    v14[20] = 62;
                    v15 = v15 + 3;
                end;
            elseif v23 < 20 then
                v14[u2(UNNAMED_2819735037128[v15], (u3(u2(87, v16), 127)))][v14[u2(UNNAMED_2819735087720[v15], 64)]] = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(85, v15), 127)))];
            elseif v23 == 21 then
                v15 = u2(UNNAMED_2819735030936[v15], (u3(u2(25, UNNAMED_2819735055704[v15]), 127)));
            else
                v14[1] = v14[13] - v14[25];
                v14[UNNAMED_2819735055704[v15 + 1]] = v14[1] / 2;
                v14[1] = v14[5] - v14[UNNAMED_2819735087720[v15]];
                v14[UNNAMED_2819735037128[v15]] = v14[1] / 2;
                v14[UNNAMED_2819735030936[v15]] = v14[13] % 2;
                v14[UNNAMED_2819735087720[v15 + 1]] = v14[UNNAMED_2819735037128[v15 + 1]] % 2;
                v15 = v15 + 1;
            end;

            v24 = 13;
            continue;
        elseif v24 == 8 then
            v24 = -1;

            if v23 < 16 then
                v24 = 12;
                continue;
            end;

            if v23 < 17 then
                v24 = 9;
                continue;
            end;

            v24 = 11;
            continue;
        elseif v24 == 9 then
            v24 = -1;
            v16 = UNNAMED_2819735030936[v15];
            v15 = u2(UNNAMED_2819735087720[v15], 13) + 1;
            v24 = 10;
            continue;
        elseif v24 == 10 then
            v24 = -1;

            if v16 == 84 then
                local v96;

                while true do
                    v96 = UNNAMED_2819735030936[v15];

                    if v96 >= 1 then
                        break;
                    end;

                    v14[UNNAMED_2819735055704[v15]] = u2(v14[UNNAMED_2819735087720[v15]], (u2(UNNAMED_2819735037128[v15], (u3(v15, 127)))));
                    v15 = v15 + 1;
                end;

                if v96 == 2 then
                    return v14[u2(UNNAMED_2819735087720[v15], (u3(u2(23, v16), 127)))];
                end;

                return v14[u2(UNNAMED_2819735055704[v15], (u3(u2(105, v15), 127)))], v14[UNNAMED_2819735087720[v15]];
            end;

            if v16 ~= 101 then
                return;
            end;

            while true do
                local v97 = UNNAMED_2819735037128[v15];

                if v97 >= 2 then
                    if v97 == 3 then
                        return v14[u2(UNNAMED_2819735055704[v15], (u3(u2(v15, v16), 127)))], v14[UNNAMED_2819735030936[v15]];
                    end;

                    v14[UNNAMED_2819735055704[v15]] = v14[u2(UNNAMED_2819735087720[v15], (u3(u2(UNNAMED_2819735037128[v15], v16, 22), 127)))] + UNNAMED_2819735084600[v15];
                elseif v97 == 1 then
                    v14[u2(UNNAMED_2819735055704[v15], (u3(u2(UNNAMED_2819735037128[v15], 49), 127)))] = v21;
                else
                    local v98 = u2(UNNAMED_2819735087720[v15], 93);
                    local v99 = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v15, 43), 127)))] % 4294967296;
                    v14[v98] = v99 ~= v99 and 0 or v99 - v99 % 1;
                end;

                v15 = v15 + 1;
            end;

            v24 = 11;
            continue;
        elseif v24 == 11 then
            v24 = -1;

            if v23 == 18 then
                if v14[u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735055704[v15], v16), 127)))] > u2(UNNAMED_2819735037128[v15], (u3(u2(113, v16, UNNAMED_2819735055704[v15]), 127))) then
                    v15 = UNNAMED_2819735087720[v15];
                end;
            else
                v14[33] = v14[1] + 1;
                v14[1] = v22;
                v14[1] = v14[1] + v14[UNNAMED_2819735087720[v15]];
                v22 = v14[1];
                v14[UNNAMED_2819735037128[v15]] = u2(v14[36], 308766547);
                v14[UNNAMED_2819735030936[v15]] = v21;
            end;

            v24 = 13;
            continue;
        elseif v24 == 12 then
            v24 = -1;

            if v23 >= 14 then
                if v23 == 15 then
                    v14[32][50] = 2;
                    v14[32][69] = 14;
                    v14[UNNAMED_2819735087720[v15]][102] = UNNAMED_2819735037128[v15];
                    v14[1] = v20;
                    v14[UNNAMED_2819735030936[v15]] = v14[1] // v14[36];
                    v20 = v14[1];
                else
                    v22 = v14[u2(UNNAMED_2819735037128[v15], (u3(v15, 127)))];
                end;
            else
                v14[u2(UNNAMED_2819735087720[v15], (u3(UNNAMED_2819735055704[v15], 127)))] = UNNAMED_2819735052968[u2(UNNAMED_2819735037128[v15], (u3(u2(v16, v15, UNNAMED_2819735055704[v15]), 127)))];
            end;

            v24 = 13;
            continue;
        elseif v24 == 13 then
            v24 = -1;
            v24 = 15;
            continue;
        elseif v24 == 14 then
            v24 = -1;

            if v23 < 78 then
                if v23 >= 65 then
                    if v23 >= 71 then
                        if v23 >= 74 then
                            if v23 >= 76 then
                                if v23 == 77 then
                                    v15 = v14[u2(UNNAMED_2819735030936[v15], 45)];
                                else
                                    v14[u2(UNNAMED_2819735087720[v15], (u3(v16, 127)))] = UNNAMED_2819735084600[v15] + UNNAMED_2819735036552[v15];
                                end;
                            elseif v23 == 75 then
                                local v100 = UNNAMED_2819735037128[v15];
                                local v101 = UNNAMED_2819735030936[v15];
                                local v102 = UNNAMED_2819735069816[5];
                                local v103 = u2(v102[v100], 109162203);
                                v102[v100] = v103;
                                local v104 = UNNAMED_2819735069816[4];
                                local v105 = v103 + 1;
                                local v106 = u7(v104, v105);
                                local v107;

                                if v106 < 128 then
                                    v107 = v105 + 1;
                                else
                                    local v108 = u7(v104, v105 + 1);

                                    if v108 < 128 then
                                        v106 = v106 - 128 + v108 * 128;
                                        v107 = v105 + 2;
                                    else
                                        local v109 = u7(v104, v105 + 2);

                                        if v109 < 128 then
                                            v106 = v106 - 128 + (v108 - 128) * 16384 + v109 * 128;
                                            v107 = v105 + 3;
                                        else
                                            local v110 = u7(v104, v105 + 3);
                                            v106 = (v106 - 128) * 16384 + (v108 - 128) * 128 + (v109 - 128) + v110 % 128 * 2097152 + (v110 - v110 % 128) * 2097152;
                                            v107 = v105 + 4;
                                        end;
                                    end;
                                end;

                                local v111 = v101 * 16843009;
                                local v112 = v107 + v106;
                                local v113 = v112 - v106 % 4;

                                for i = v107, v113 - 1, 4 do
                                    u8(v104, i, (u2(u9(v104, i), v111)));
                                    local _ = i;
                                end;

                                for i = v113, v112 - 1 do
                                    u10(v104, i, (u2(u7(v104, i), v101)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735037128[v15] = 198;
                                UNNAMED_2819735030936[v15] = 156;
                                UNNAMED_2819735087720[v15] = 253;
                                UNNAMED_2819735055704[v15] = 96;
                            else
                                local v114 = u2(UNNAMED_2819735087720[v15], (u3(u2(v22, (u3(u4(v22, 29), 7))), 536870911)));
                                local v115 = UNNAMED_2819735030936[v15] + 1;

                                for i = 1, UNNAMED_2819735037128[v15] do
                                    local v116 = u3(u2(v114, (u5(v114, 13))), 536870911);
                                    local v117 = u2(v116, (u4(v116, 13)));
                                    v114 = u3(u2(v117, (u5(v117, 14))), 536870911);
                                    UNNAMED_2819735030936[v115] = u2(UNNAMED_2819735030936[v115], (u3(u4(v114, 0), 127)));
                                    UNNAMED_2819735087720[v115] = u2(UNNAMED_2819735087720[v115], (u3(u4(v114, 7), 127)));
                                    UNNAMED_2819735037128[v115] = u2(UNNAMED_2819735037128[v115], (u3(u4(v114, 14), 127)));
                                    UNNAMED_2819735055704[v115] = u2(UNNAMED_2819735055704[v115], (u3(u4(v114, 21), 127)));
                                    v115 = v115 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735055704[v15] = 96;
                            end;
                        elseif v23 >= 72 then
                            if v23 == 73 then
                                v14[UNNAMED_2819735037128[v15]] = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v15, 63), 127)))] // v14[u2(UNNAMED_2819735087720[v15], (u3(u2(UNNAMED_2819735055704[v15], v16), 127)))];
                            else
                                v14[u2(UNNAMED_2819735087720[v15], 49)] = u2(UNNAMED_2819735037128[v15], (u3(u2(v16, 111), 127)));
                            end;
                        else
                            v14[UNNAMED_2819735030936[v15]] = v14[UNNAMED_2819735087720[v15]] * u2(UNNAMED_2819735037128[v15], (u3(u2(114, v15, v16), 127)));
                        end;
                    elseif v23 < 68 then
                        if v23 >= 66 then
                            if v23 == 67 then
                                v14[1] = v14[9][2];
                                v14[2] = v14[9][UNNAMED_2819735055704[v15 + 2]];
                                v14[3] = v14[9][UNNAMED_2819735055704[v15 + 1]];
                                v14[1] = v14[UNNAMED_2819735030936[v15 + 2]] + v14[UNNAMED_2819735087720[v15]];
                                v14[UNNAMED_2819735037128[v15]] = v14[2] <= 0;
                                v14[UNNAMED_2819735030936[v15 + 1]] = not v14[2];
                                v14[UNNAMED_2819735037128[v15 + 1]] = v14[UNNAMED_2819735030936[v15]] >= v14[3];
                                v14[UNNAMED_2819735087720[v15 + 1]] = v14[1] <= v14[3];
                                v15 = v15 + 2;
                            else
                                v14[UNNAMED_2819735030936[v15]] = v14[u2(UNNAMED_2819735087720[v15], (u3(v16, 127)))] ~= UNNAMED_2819735037128[v15];
                            end;
                        else
                            local v118 = u2(UNNAMED_2819735087720[v15], (u3(u2(v21, (u3(u4(v21, 29), 7))), 536870911)));
                            local v119 = UNNAMED_2819735030936[v15] + 1;

                            for i = 1, UNNAMED_2819735037128[v15] do
                                local v120 = u3(u2(v118, (u5(v118, 13))), 536870911);
                                local v121 = u2(v120, (u4(v120, 13)));
                                v118 = u3(u2(v121, (u5(v121, 14))), 536870911);
                                UNNAMED_2819735030936[v119] = u2(UNNAMED_2819735030936[v119], (u3(u4(v118, 0), 127)));
                                UNNAMED_2819735087720[v119] = u2(UNNAMED_2819735087720[v119], (u3(u4(v118, 7), 127)));
                                UNNAMED_2819735037128[v119] = u2(UNNAMED_2819735037128[v119], (u3(u4(v118, 14), 127)));
                                UNNAMED_2819735055704[v119] = u2(UNNAMED_2819735055704[v119], (u3(u4(v118, 21), 127)));
                                v119 = v119 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735055704[v15] = 96;
                        end;
                    elseif v23 < 69 then
                        local v122 = u2(UNNAMED_2819735030936[v15], 113);
                        local v123 = v14[u2(UNNAMED_2819735087720[v15], (u3(u2(v15, v16), 127)))];
                        local v124 = v14[UNNAMED_2819735037128[v15]];
                        local v125 = u3(v123, 4294967295);
                        local v126 = u3(v124, 4294967295);
                        local v127 = u3(v125, 65535);
                        local v128 = u4(v125, 16);
                        local v129 = u3(v126, 65535);
                        local v130 = u4(v126, 16);
                        local v131 = u3(v127 * v129 + u5(u3(v127 * v130 + v128 * v129, 65535), 16), 4294967295) % 4294967296;
                        v14[v122] = v131 ~= v131 and 0 or v131 - v131 % 1;
                    elseif v23 == 70 then
                        v14[UNNAMED_2819735037128[v15]][u2(UNNAMED_2819735030936[v15], (u3(u2(2, v16, v15), 127)))] = v14[UNNAMED_2819735087720[v15]];
                    else
                        v14[u2(UNNAMED_2819735030936[v15], (u3(u2(82, UNNAMED_2819735055704[v15], v15), 127)))] = u2(UNNAMED_2819735087720[v15], (u3(u2(v15, 37, v16), 127))) + v14[UNNAMED_2819735037128[v15]];
                    end;
                elseif v23 >= 58 then
                    if v23 < 61 then
                        if v23 < 59 then
                            v14[u2(UNNAMED_2819735087720[v15], (u3(u2(v16, UNNAMED_2819735055704[v15], 120), 127)))] = v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v16, 1), 127)))] <= v14[UNNAMED_2819735030936[v15]];
                        elseif v23 == 60 then
                            v14[u2(UNNAMED_2819735037128[v15], (u3(UNNAMED_2819735055704[v15], 127)))][UNNAMED_2819735030936[v15]] = UNNAMED_2819735087720[v15];
                        else
                            v14[1] = v14[UNNAMED_2819735030936[v15]][UNNAMED_2819735087720[v15]];
                            v14[2] = v14[9][5];
                            v14[3] = v14[9][3];
                            v14[1] = v14[1] + v14[2];
                            v14[UNNAMED_2819735037128[v15]] = v14[2] <= 0;
                            v14[4] = not v14[2];
                        end;
                    elseif v23 >= 63 then
                        if v23 == 64 then
                            v14[u2(UNNAMED_2819735087720[v15], (u3(u2(UNNAMED_2819735055704[v15], v15, 91), 127)))] = v20;
                        else
                            v20 = v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127)))];
                        end;
                    elseif v23 == 62 then
                        v14[UNNAMED_2819735037128[v15]] = u11(v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127)))], v14[UNNAMED_2819735087720[v15]]);
                    else
                        v14[1] = v14[21](v14[32]);
                        v14[UNNAMED_2819735087720[v15] + v14[32]] = v14[1];
                        v14[294 + v14[32]] = v14[UNNAMED_2819735037128[v15]];
                        v14[1] = v14[33] * v14[32];
                        v14[2] = v20;
                        v14[2] = v14[2] - v14[36];
                        v20 = v14[2];
                        v14[1] = v14[1] + v14[5];
                    end;
                elseif v23 < 55 then
                    if v23 < 53 then
                        v14[u2(UNNAMED_2819735087720[v15], (u3(v16, 127)))] = v14[UNNAMED_2819735030936[v15]] // u2(UNNAMED_2819735037128[v15], (u3(u2(v15, 52), 127)));
                    elseif v23 == 54 then
                        if v14[u2(UNNAMED_2819735037128[v15], (u3(v16, 127)))] then
                            v15 = UNNAMED_2819735030936[v15];
                        else
                            v15 = u2(UNNAMED_2819735087720[v15], 79);
                        end;
                    else
                        v14[1] = v14[UNNAMED_2819735055704[v15 + 1]] - v14[25];
                        v14[13] = v14[1] / UNNAMED_2819735037128[v15 + 1];
                        v14[1] = v14[UNNAMED_2819735037128[v15]] - v14[552];
                        v14[5] = v14[UNNAMED_2819735030936[v15]] / 2;
                        v14[1] = v20;
                        v14[36] = u2(v14[36], v14[UNNAMED_2819735030936[v15 + 1]]);
                        v15 = v15 + 1;
                    end;
                elseif v23 >= 56 then
                    if v23 == 57 then
                        v14[1] = v14[13] - v14[UNNAMED_2819735055704[v15 + 2]];
                        v14[13] = v14[UNNAMED_2819735055704[v15 + 1]] / UNNAMED_2819735037128[v15];
                        v14[1] = v14[UNNAMED_2819735030936[v15 + 1]] - v14[552];
                        v14[5] = v14[UNNAMED_2819735030936[v15]] / 2;
                        v14[25] = v14[UNNAMED_2819735087720[v15]] % 2;
                        v14[552] = v14[UNNAMED_2819735030936[v15 + 2]] % UNNAMED_2819735037128[v15 + 1];
                        v15 = v15 + 2;
                    else
                        local v132 = UNNAMED_2819735030936[v15];
                        local v133 = u2(UNNAMED_2819735087720[v15], (u3(v16, 127)));
                        local v134 = u2(UNNAMED_2819735037128[v15], (u3(u2(100, v15), 127)));
                        u6(v14, v132 + 1, v132 + v133, v134 + 1, v14[v132]);
                    end;
                else
                    v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v16, UNNAMED_2819735055704[v15], v15), 127)))] = v14[u2(UNNAMED_2819735087720[v15], (u3(u2(v16, 6, UNNAMED_2819735055704[v15]), 127)))] / UNNAMED_2819735037128[v15];
                end;
            elseif v23 < 91 then
                if v23 >= 84 then
                    if v23 >= 87 then
                        if v23 < 89 then
                            if v23 == 88 then
                                v14[16] = 0 - v14[19];
                                local v135 = u1(5);
                                v14[UNNAMED_2819735055704[v15 + 1]] = UNNAMED_2819735036552[v15 + 1] + UNNAMED_2819735035496[v15];
                                v14[UNNAMED_2819735037128[v15]] = v135;
                                v14[18] = v14[0];
                                v14[UNNAMED_2819735030936[v15]] = v14[9];
                                u6(v14, 15, 19, 1, v14[14]);
                                v14[20] = 49;
                                v15 = v15 + 1;
                            else
                                v14[u2(UNNAMED_2819735087720[v15], (u3(u2(1, v15, v16), 127)))] = v14[UNNAMED_2819735037128[v15]] .. v14[UNNAMED_2819735030936[v15]];
                            end;
                        elseif v23 == 90 then
                            v14[UNNAMED_2819735055704[v15 + 1]] = u2(v14[36], v14[1]);
                            v14[1] = v21;
                            v14[UNNAMED_2819735030936[v15 + 1]] = v22;
                            local v136 = v14[1];
                            local v137 = u3(v14[UNNAMED_2819735037128[v15 + 1]], 4294967295);
                            local v138 = u3(v136, 4294967295);
                            local v139 = u3(v137, 65535);
                            local v140 = u4(v137, 16);
                            local v141 = u3(v138, 65535);
                            local v142 = u4(v138, 16);
                            local v143 = u3(v139 * v141 + u5(u3(v139 * v142 + v140 * v141, 65535), 16), 4294967295) % 4294967296;
                            v14[1] = v143 ~= v143 and 0 or v143 - v143 % 1;
                            v22 = v14[UNNAMED_2819735037128[v15]];
                            v14[UNNAMED_2819735087720[v15]] = UNNAMED_2819735084600[v15] + UNNAMED_2819735035496[v15 + 1];
                            v15 = v15 + 1;
                        else
                            v14[u2(UNNAMED_2819735037128[v15], (u3(v16, 127)))] = v14[UNNAMED_2819735030936[v15]][u2(UNNAMED_2819735087720[v15], (u3(u2(UNNAMED_2819735055704[v15], v15, v16), 127)))];
                        end;
                    elseif v23 < 85 then
                        local v144 = u1(5);
                        v14[18] = UNNAMED_2819735036552[v15 + 1] + UNNAMED_2819735084600[v15];
                        v14[19] = 0 - v14[18];
                        v14[16] = UNNAMED_2819735035496[v15 + 1] + UNNAMED_2819735036552[v15];
                        v14[14] = v144;
                        v14[17] = v14[0];
                        v14[UNNAMED_2819735055704[v15 + 1]] = v14[9];
                        v15 = v15 + 1;
                    elseif v23 == 86 then
                        v14[u2(UNNAMED_2819735087720[v15], (u3(u2(v16, v15), 127)))] = u2(v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v15, 19), 127)))], (u2(UNNAMED_2819735030936[v15], 60)));
                    else
                        v15 = v14[u2(UNNAMED_2819735037128[v15], (u3(UNNAMED_2819735055704[v15], 127)))];
                    end;
                elseif v23 >= 81 then
                    if v23 < 82 then
                        v14[UNNAMED_2819735030936[v15]] = v14[UNNAMED_2819735037128[v15]] >= u2(UNNAMED_2819735087720[v15], (u3(UNNAMED_2819735055704[v15], 127)));
                    elseif v23 == 83 then
                        v14[u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735055704[v15], 115), 127)))] = not v14[u2(UNNAMED_2819735037128[v15], (u3(u2(UNNAMED_2819735055704[v15], v15, v16), 127)))];
                    else
                        v14[UNNAMED_2819735087720[v15]] = v14[u2(UNNAMED_2819735037128[v15], (u3(u2(UNNAMED_2819735055704[v15], v16), 127)))] % UNNAMED_2819735084600[v15];
                    end;
                elseif v23 >= 79 then
                    if v23 == 80 then
                        local v145 = u2(UNNAMED_2819735037128[v15], (u3(u2(118, UNNAMED_2819735055704[v15], v15), 127)));
                        local v146 = u2(UNNAMED_2819735030936[v15], 23);
                        local v147 = u2(UNNAMED_2819735087720[v15], (u3(u2(v15, UNNAMED_2819735055704[v15], v16), 127)));
                        v14[v145] = v146;
                        v14[v145 + 1] = v147;
                    else
                        v21 = v14[u2(UNNAMED_2819735087720[v15], (u3(u2(UNNAMED_2819735055704[v15], v16), 127)))];
                    end;
                else
                    v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v15, 57), 127)))] = v14[u2(UNNAMED_2819735037128[v15], (u3(v16, 127)))] - UNNAMED_2819735035496[v15];
                end;
            elseif v23 < 98 then
                if v23 >= 94 then
                    if v23 < 96 then
                        if v23 == 95 then
                            v14[u2(UNNAMED_2819735030936[v15], (u3(v15, 127)))] = v14[UNNAMED_2819735037128[v15]] / v14[UNNAMED_2819735087720[v15]];
                        else
                            v14[u2(UNNAMED_2819735030936[v15], (u3(v15, 127)))] = v14[UNNAMED_2819735037128[v15]] == v14[UNNAMED_2819735087720[v15]];
                        end;
                    elseif v23 == 97 then
                        v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127)))] = u2(UNNAMED_2819735037128[v15], (u3(u2(UNNAMED_2819735055704[v15], 83), 127))) * v14[UNNAMED_2819735087720[v15]];
                    end;
                elseif v23 < 92 then
                    v14[u2(UNNAMED_2819735087720[v15], (u3(v15, 127)))] = v14[UNNAMED_2819735037128[v15]][v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127)))]];
                elseif v23 == 93 then
                    v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v15, UNNAMED_2819735055704[v15]), 127)))] = u3(v14[u2(UNNAMED_2819735037128[v15], (u3(u2(v15, UNNAMED_2819735055704[v15]), 127)))], UNNAMED_2819735087720[v15]);
                else
                    v14[UNNAMED_2819735055704[v15 + 1]] = #v14[34];
                    v14[UNNAMED_2819735055704[v15 + 2]] = UNNAMED_2819735035496[v15 + 2] + UNNAMED_2819735084600[v15];
                    v14[UNNAMED_2819735030936[v15 + 2]] = 1 - v14[UNNAMED_2819735037128[v15 + 1]];
                    v14[UNNAMED_2819735030936[v15 + 1]] = v14[2] + 0;
                    v14[UNNAMED_2819735087720[v15 + 1]] = u1(UNNAMED_2819735037128[v15]);
                    v14[UNNAMED_2819735037128[v15 + 2]] = v14[0];
                    v15 = v15 + 2;
                end;
            elseif v23 < 101 then
                if v23 >= 99 then
                    if v23 == 100 then
                        v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v16, UNNAMED_2819735055704[v15], 23), 127)))] = v14[u2(UNNAMED_2819735037128[v15], (u3(u2(UNNAMED_2819735055704[v15], v16), 127)))] + UNNAMED_2819735035496[v15];
                    else
                        v14[u2(UNNAMED_2819735087720[v15], (u3(v15, 127)))] = v14[UNNAMED_2819735037128[v15]] % UNNAMED_2819735030936[v15];
                    end;
                else
                    local v148 = u2(UNNAMED_2819735037128[v15], (u3(UNNAMED_2819735055704[v15], 127)));
                    local v149 = v14[u2(UNNAMED_2819735030936[v15], (u3(u2(UNNAMED_2819735055704[v15], 49, v16), 127)))] % 4294967296;
                    v14[v148] = v149 ~= v149 and 0 or v149 - v149 % 1;
                end;
            elseif v23 >= 103 then
                if v23 == 104 then
                    v14[UNNAMED_2819735055704[v15 + 1]] = v14[9][5];
                    v14[2] = v14[9][UNNAMED_2819735030936[v15 + 1]];
                    v14[3] = v14[UNNAMED_2819735030936[v15]][2];
                    v14[1] = v14[1] + v14[UNNAMED_2819735037128[v15 + 1]];
                    v14[2] = v14[UNNAMED_2819735087720[v15]] <= UNNAMED_2819735037128[v15];
                    v14[UNNAMED_2819735087720[v15 + 1]] = not v14[2];
                    v15 = v15 + 1;
                elseif v14[u2(UNNAMED_2819735030936[v15], (u3(u2(v16, UNNAMED_2819735055704[v15], 59), 127)))] ~= v14[u2(UNNAMED_2819735087720[v15], (u3(u2(v16, UNNAMED_2819735055704[v15], 1), 127)))] then
                    v15 = u2(UNNAMED_2819735037128[v15], 65);
                end;
            elseif v23 == 102 then
                v14[u2(UNNAMED_2819735030936[v15], (u3(UNNAMED_2819735055704[v15], 127)))] = u2(v14[u2(UNNAMED_2819735037128[v15], (u3(v15, 127)))], v14[UNNAMED_2819735087720[v15]]);
            else
                v14[1] = v14[UNNAMED_2819735055704[v15 + 1]][5];
                v14[2] = v14[9][UNNAMED_2819735087720[v15 + 1]];
                v14[3] = v14[UNNAMED_2819735037128[v15]][1];
                v14[1] = v14[1] + v14[2];
                v14[UNNAMED_2819735087720[v15]] = v14[UNNAMED_2819735030936[v15]] <= 0;
                v15 = v15 + 1;
            end;

            v24 = 15;
            continue;
        elseif v24 == 15 then
            v24 = -1;
            v15 = v15 + 1;
            v24 = 5;
            continue;
        elseif v24 == 16 then
            v24 = -1;

            if v19 == 7 then
                local v150 = UNNAMED_2819735087720[v17];
                local v151 = UNNAMED_2819735055704[v17] + 1;

                for i = 1, UNNAMED_2819735037128[v17] do
                    local v152 = u3(u2(v150, (u5(v150, 13))), 536870911);
                    local v153 = u2(v152, (u4(v152, 13)));
                    v150 = u3(u2(v153, (u5(v153, 14))), 536870911);
                    UNNAMED_2819735087720[v151] = u2(UNNAMED_2819735087720[v151], (u3(u4(v150, 0), 127)));
                    UNNAMED_2819735055704[v151] = u2(UNNAMED_2819735055704[v151], (u3(u4(v150, 7), 127)));
                    UNNAMED_2819735037128[v151] = u2(UNNAMED_2819735037128[v151], (u3(u4(v150, 14), 127)));
                    UNNAMED_2819735030936[v151] = u2(UNNAMED_2819735030936[v151], (u3(u4(v150, 21), 127)));
                    v151 = v151 + 1;
                    local _ = i;
                end;

                UNNAMED_2819735030936[v17] = 1;
            else
                local v154 = UNNAMED_2819735087720[v17];
                local v155 = v14[u2(UNNAMED_2819735055704[v17], (u3(u2(v17, UNNAMED_2819735030936[v17]), 127)))];
                local v156 = v14[u2(UNNAMED_2819735037128[v17], (u3(u2(104, v17, UNNAMED_2819735030936[v17]), 127)))];
                v14[v154] = v155;
                v14[v154 + 1] = v156;
            end;

            v24 = 18;
            continue;
        elseif v24 == 17 then
            v24 = -1;

            if v19 >= 9 then
                if v19 == 10 then
                    v17 = v14[u2(UNNAMED_2819735055704[v17], (u3(u2(85, v18), 127)))];
                else
                    v14[UNNAMED_2819735087720[v17]] = UNNAMED_2819735055704[v17];
                end;
            else
                local v157 = UNNAMED_2819735037128[v17];
                local v158 = UNNAMED_2819735055704[v17];
                local v159 = UNNAMED_2819735087720[v17];
                local v160 = u2(UNNAMED_2819735077544, u3(u4(UNNAMED_2819735077544, 14), 262143), (u3(u4(UNNAMED_2819735077544, 28), 15)));
                local v161 = v158 < 16384 and 7 or (v158 < 2097152 and 14 or 21);
                local v162 = u4(v158, v161);
                UNNAMED_2819735055704[v17] = u2(u3(v158, u5(1, v161) - 1), 120, (u3(u4(v160, 7), 127)));
                UNNAMED_2819735030936[v17] = u2(v162, 13, (u3(u4(v160, 21), 127)));
                UNNAMED_2819735037128[v17] = u2(v157, 106, (u3(u4(v160, 14), 127)));
                UNNAMED_2819735087720[v17] = u2(v159, 0, (u3(v160, 127)));
                v17 = v17 - 1;
            end;

            v24 = 18;
            continue;
        elseif v24 == 18 then
            v24 = -1;
            v17 = v17 + 1;
            v24 = 1;
            continue;
        elseif v24 == 19 then
            v24 = -1;
            break;
        else
            break;
        end;
    end;
end;