-- Decompiled with Potassium's decompiler.

local v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13 = UNNAMED_2819735042408:v3();

while v1 do
    if v2 <= 20 then
        if v2 <= 9 then
            if v2 <= 4 then
                if v2 <= 1 then
                    v2, v5, v7 = UNNAMED_2819735042408:A3(v3, v8, v7, v2, v5, v9);
                else
                    v2, v3, v4, v5, v6, v10 = UNNAMED_2819735042408:c3(v9, v2, v4, v3, v6, v7, v10, v8, v5);
                end;
            else
                v2, v4, v5, v7, v8, v10, v11, v12, v13 = UNNAMED_2819735042408:E3(v10, v13, v9, v8, v2, v7, v6, v5, v12, v11, v4, v2 <= 6);
            end;
        elseif v2 <= 14 then
            local v14, v15, v16, v17, v18, v19 = UNNAMED_2819735042408:i3(v7, v8, v2 <= 11, v11, v10, v12, v2, v5, v9, v13, v4);

            if v14 == 1 then
                v5 = v16;
                v7 = v17;
                v2 = v15;
                v12 = v19;
                v10 = v18;
            elseif v14 == 2 then
                return v4;
            end;
        else
            v2, v3, v5, v7, v8, v10, v11 = UNNAMED_2819735042408:y3(v5, v10, v7, v3, v11, v4, v8, v2);
        end;
    elseif v2 <= 31 then
        if v2 <= 25 then
            if v2 <= 22 then
                v2, v5, v9, v10 = UNNAMED_2819735042408:s3(v4, v10, v9, v11, v5, v2);
            else
                v2, v5, v9, v10 = UNNAMED_2819735042408:M3(v10, v11, v12, v2, v5, v4, v9, v3);
            end;
        elseif v2 <= 28 then
            v2, v3, v4, v5, v6, v7, v10 = UNNAMED_2819735042408:R3(v5, v10, v6, v3, v4, v8, v7, v2, v9);
        else
            v2, v3, v7, v8, v9 = UNNAMED_2819735042408:p3(v2, v5, v9, v7, v6, v8, v3, v4);
        end;
    elseif v2 <= 36 then
        if v2 <= 33 then
            v2, v5, v8 = UNNAMED_2819735042408:j3(v4, v5, v2, v8, v10, v9);
        else
            v2, v5, v6, v9 = UNNAMED_2819735042408:J3(v5, v3, v2, v4, v6, v9);
        end;
    else
        v2, v3, v4, v5, v8, v9 = UNNAMED_2819735042408:x3(v9, v8, v5, v3, v2, v6, v11, v10, v4);
    end;
end;