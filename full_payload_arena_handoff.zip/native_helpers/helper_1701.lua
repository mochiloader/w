-- Decompiled with Potassium's decompiler.

if UNNAMED_2819735069912 <= 20 then
    local v1 = UNNAMED_2819735051384[22](UNNAMED_2819735039096, UNNAMED_2819735057528);

    return v1 < 128 and 97 or 127, UNNAMED_2819735060552, v1;
end;

local v2 = UNNAMED_2819735063576[3];
local v3 = UNNAMED_2819735063576[2];
local v4 = UNNAMED_2819735063576[1] + v2;
local v5 = v2 <= 0;
local v6 = v3 <= v4;
UNNAMED_2819735063576[1] = v4;

if v5 and v6 and v6 or not v5 and v4 <= v3 then
    return 45, v4, UNNAMED_2819735063288;
end;

return 116, UNNAMED_2819735060552, UNNAMED_2819735063288;