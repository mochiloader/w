-- Decompiled with Potassium's decompiler.

local v1, v2 = UNNAMED_2819735068952:SF({
    [2] = UNNAMED_2819735032088
});

if v1 == 1 then
    return v2;
end;