-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735070968;
local u2 = UNNAMED_2819735070680(UNNAMED_2819735072648);
local u3 = UNNAMED_2819735081576;
local u4 = UNNAMED_2819735029112;
local u5 = nil;
local u6 = nil;
local u7 = UNNAMED_2819735066840;
local u8 = UNNAMED_2819735046584;
local u9 = UNNAMED_2819735034872;
local u10 = UNNAMED_2819735068568;
local u11 = UNNAMED_2819735075864;
local u12 = UNNAMED_2819735046824;
local u13 = UNNAMED_2819735044904;
local u14 = UNNAMED_2819735065448;
local u15 = UNNAMED_2819735079800;
local u16 = UNNAMED_2819735070728;
local u17 = UNNAMED_2819735075432;
local u18 = UNNAMED_2819735092328;
local u19 = UNNAMED_2819735076296;
local v408, v409, v410, v411, v412 = UNNAMED_2819735091032(function(...) -- Line: 3
    -- upvalues: u4 (copy), UNNAMED_2819735057720 (ref), u3 (ref), u2 (copy), UNNAMED_2819735088488 (ref), UNNAMED_2819735084312 (ref), UNNAMED_2819735086280 (ref), UNNAMED_2819735082680 (ref), UNNAMED_2819735045000 (ref), u9 (copy), UNNAMED_2819735041784 (ref), UNNAMED_2819735072744 (ref), u10 (copy), u7 (copy), u8 (copy), u1 (ref), UNNAMED_2819735027864 (ref), u11 (copy), u12 (copy), u13 (copy), u14 (copy), u15 (copy), UNNAMED_2819735035496 (ref), u17 (copy), u16 (copy), u18 (copy), u19 (copy), UNNAMED_2819735079752 (ref), u5 (copy), u6 (copy)
    if u4 == 158 then
        while true do
            local v20 = UNNAMED_2819735057720[u3];

            if v20 < 54 then
                if v20 >= 27 then
                    if v20 < 40 then
                        if v20 >= 33 then
                            if v20 >= 36 then
                                if v20 < 38 then
                                    if v20 == 37 then
                                        u2[2] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                        u2[14] = u2[2]();
                                        local v21;

                                        if u2[UNNAMED_2819735057720[u3 + 1]] then
                                            v21 = UNNAMED_2819735086280[u3] - 1;
                                        else
                                            v21 = UNNAMED_2819735082680[u3] - 1;
                                        end;

                                        u3 = v21;
                                        u3 = u3 + 1;
                                    else
                                        u2[5] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 3]];
                                        local v22 = u2[UNNAMED_2819735057720[u3 + 1]];
                                        u2[4] = v22;
                                        u2[3] = v22[UNNAMED_2819735045000[u3 + 2]];
                                        local v23 = 3;
                                        u2[UNNAMED_2819735057720[u3 + 3]] = u2[3];
                                        u2[3] = u9[UNNAMED_2819735041784[u3 + 3]][UNNAMED_2819735072744[u3 + 1]];
                                        u2[5] = u2[3][UNNAMED_2819735045000[u3 + 3]];
                                        u2[3] = u2[2];
                                        local v24 = UNNAMED_2819735057720[u3 + 2];
                                        local v25 = UNNAMED_2819735082680[u3];
                                        local _ = v23 + v25 - 1;
                                        local _ = v23 + v24;
                                        u8(u10(u2[v23](u7(u2, 4, v23 + v24))), 1, v25, v23, u2);
                                        local v26;

                                        if u2[UNNAMED_2819735086280[u3 + 2]] then
                                            v26 = UNNAMED_2819735084312[u3] - 3;
                                        else
                                            v26 = UNNAMED_2819735084312[u3 + 2] - 3;
                                        end;

                                        u3 = v26;
                                        u3 = u3 + 3;
                                    end;
                                else
                                    if v20 == 39 then
                                        u2[1] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]][UNNAMED_2819735045000[u3]];
                                        local v27 = u2[32];
                                        u2[2] = u10(u7(v27, 1, v27.n));
                                        u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];

                                        return true, true, 1, u10(u2[3], u7(u2[2], 1, u2[2].n));
                                    end;

                                    u2[2] = u2[2][UNNAMED_2819735045000[u3]];
                                    local v28;

                                    if u2[2] then
                                        v28 = UNNAMED_2819735086280[u3];
                                    else
                                        v28 = UNNAMED_2819735084312[u3];
                                    end;

                                    u3 = v28;
                                end;
                            elseif v20 < 34 then
                                u2[2] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]][UNNAMED_2819735072744[u3 + 1]];
                                u2[2] = u2[2][UNNAMED_2819735045000[u3 + 1]];
                                u2[UNNAMED_2819735057720[u3 + 1]] = not u2[2];
                                local v29;

                                if u2[2] then
                                    v29 = UNNAMED_2819735086280[u3] - 1;
                                else
                                    v29 = UNNAMED_2819735084312[u3 + 1] - 1;
                                end;

                                u3 = v29;
                                u3 = u3 + 1;
                            elseif v20 == 35 then
                                u2[4] = UNNAMED_2819735045000[u3];
                                u3 = UNNAMED_2819735086280[u3];
                            else
                                u3 = UNNAMED_2819735082680[u3];
                            end;
                        elseif v20 < 30 then
                            if v20 < 28 then
                                local v30 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                                u2[UNNAMED_2819735057720[u3 + 2]] = v30[5][v30[4]];
                                local v31 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]];
                                u2[4] = v31[5][v31[4]];
                                u2[3] = 1 - u2[4];
                                u2[UNNAMED_2819735057720[u3 + 3]] = u2[3] * u2[8];
                                u2[UNNAMED_2819735057720[u3 + 1]] = u2[2] + u2[3];
                                local v32 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 3]];
                                v32[5][v32[4]] = u2[2];
                                local v33 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                u2[4] = v33[5][v33[4]];
                                local v34 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                v34[5][v34[4]][UNNAMED_2819735045000[u3 + 1]] = u2[UNNAMED_2819735086280[u3]];
                                local v35 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 2]];
                                u2[2] = v35[5][v35[4]];

                                if UNNAMED_2819735041784[u3] >= u2[2] then
                                    u3 = UNNAMED_2819735086280[u3 + 3] - 3;
                                end;

                                u3 = u3 + 3;
                            elseif v20 == 29 then
                                local v36 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                u2[2] = v36[5][v36[4]];
                                local v37;

                                if u2[2] then
                                    v37 = UNNAMED_2819735086280[u3];
                                else
                                    v37 = UNNAMED_2819735084312[u3];
                                end;

                                u3 = v37;
                            else
                                u2[4] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]][UNNAMED_2819735072744[u3 + 1]];
                                local v38;

                                if u2[4] then
                                    v38 = UNNAMED_2819735082680[u3 + 1] - 1;
                                else
                                    v38 = UNNAMED_2819735084312[u3 + 1] - 1;
                                end;

                                u3 = v38;
                                u3 = u3 + 1;
                            end;
                        elseif v20 < 31 then
                            local v39 = 1;
                            u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                            local v40 = u2[5];
                            u2[4] = v40;
                            u2[3] = v40[UNNAMED_2819735041784[u3 + 1]];
                            u2[2] = u2[3];
                            u2[3] = u9[UNNAMED_2819735041784[u3 + 2]][UNNAMED_2819735045000[u3]];
                            u2[5] = u2[3][UNNAMED_2819735072744[u3]];
                            u2[3] = u2[2];
                            local v41 = UNNAMED_2819735057720[u3 + 2];
                            local v42 = UNNAMED_2819735057720[u3 + 1];
                            local _ = v41 + v39 - 1;
                            local _ = v41 + v42;
                            u8(u10(u2[v41](u7(u2, v41 + 1, v41 + v42))), 1, v39, v41, u2);
                            local v43;

                            if u2[UNNAMED_2819735082680[u3 + 2]] then
                                v43 = UNNAMED_2819735086280[u3 + 2] - 2;
                            else
                                v43 = UNNAMED_2819735084312[u3] - 2;
                            end;

                            u3 = v43;
                            u3 = u3 + 2;
                        else
                            if v20 ~= 32 then
                                local v44 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                u2[9] = v44[5][v44[4]];
                                local v45 = u2[UNNAMED_2819735057720[u3 + 1]];
                                u2[5] = v45;
                                u2[4] = v45[UNNAMED_2819735072744[u3 + 1]];
                                u2[4](u2[5]);
                                local v46 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                                v46[5][v46[4]] = u2[11];

                                return false, false;
                            end;

                            u2[2] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]][UNNAMED_2819735045000[u3 + 4]];
                            u2[2] = u2[2](UNNAMED_2819735045000[u3 + 3]);
                            local v47 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                            v47[5][v47[4]] = u2[2];
                            u2[2] = 118289103;
                            u1 = u2[2];
                            local v48 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 4]];
                            v48[5][v48[4]][UNNAMED_2819735041784[u3]] = UNNAMED_2819735045000[u3 + 6];
                            local v49 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                            v49[5][v49[4]][UNNAMED_2819735041784[u3 + 5]] = UNNAMED_2819735072744[u3 + 6];
                            local v50 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                            v50[5][v50[4]][UNNAMED_2819735072744[u3 + 5]] = UNNAMED_2819735045000[u3];
                            local v51 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 4]];
                            v51[5][v51[4]][UNNAMED_2819735041784[u3 + 2]] = UNNAMED_2819735041784[u3 + 6];
                            local v52 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 3]];
                            v52[5][v52[4]][UNNAMED_2819735072744[u3]] = 1;
                            local v53 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 5]];
                            v53[5][v53[4]][UNNAMED_2819735072744[u3 + 2]] = UNNAMED_2819735072744[u3 + 3];
                            u3 = u3 + 6;
                        end;
                    elseif v20 >= 47 then
                        if v20 < 50 then
                            if v20 >= 48 then
                                if v20 == 49 then
                                    u2[5] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                                    local v54 = u2[5];
                                    u2[3] = v54;
                                    u2[2] = v54[UNNAMED_2819735041784[u3 + 2]];
                                    u2[4] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 2]];
                                    u2[UNNAMED_2819735057720[u3 + 2]](u2[UNNAMED_2819735057720[u3 + 1]], u2[4]);
                                    local v55 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                    u2[2] = v55[5][v55[4]];
                                    local v56;

                                    if u2[2] then
                                        v56 = UNNAMED_2819735086280[u3] - 2;
                                    else
                                        v56 = UNNAMED_2819735084312[u3] - 2;
                                    end;

                                    u3 = v56;
                                    u3 = u3 + 2;
                                else
                                    local v57 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                                    u2[2] = v57[5][v57[4]];
                                    u2[3] = not u2[2];
                                    local v58;

                                    if u2[2] then
                                        v58 = UNNAMED_2819735084312[u3];
                                    else
                                        v58 = UNNAMED_2819735082680[u3];
                                    end;

                                    u3 = v58;
                                end;
                            else
                                local v59 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                u2[UNNAMED_2819735057720[u3 + 1]] = v59[5][v59[4]];
                                local v60;

                                if u2[2] then
                                    v60 = UNNAMED_2819735086280[u3] - 1;
                                else
                                    v60 = UNNAMED_2819735084312[u3] - 1;
                                end;

                                u3 = v60;
                                u3 = u3 + 1;
                            end;
                        elseif v20 < 52 then
                            if v20 == 51 then
                                local v61 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                                u2[4] = v61[5][v61[4]];
                                local v62 = u2[4];
                                u2[2] = v62;
                                u2[1] = v62[UNNAMED_2819735045000[u3]];
                                u2[1](u2[2]);

                                return false, false;
                            end;

                            local v63 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                            u2[2] = v63[5][v63[4]];
                            u2[3] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            u2[9] = u2[3]();
                        elseif v20 == 53 then
                            u2[13] = u2[13] - UNNAMED_2819735045000[u3];
                            u3 = UNNAMED_2819735084312[u3];
                        else
                            u2[4] = -u2[31];
                            u2[UNNAMED_2819735057720[u3 + 1]] = u2[4] * 18;
                            u2[UNNAMED_2819735082680[u3 + 1]] = u2[UNNAMED_2819735082680[u3]](u2[UNNAMED_2819735084312[u3 + 1]]);
                            u2[8] = 1 - u2[3];
                            local v64;

                            if u2[7] then
                                v64 = UNNAMED_2819735084312[u3] - 1;
                            else
                                v64 = UNNAMED_2819735086280[u3 + 1] - 1;
                            end;

                            u3 = v64;
                            u3 = u3 + 1;
                        end;
                    elseif v20 >= 43 then
                        if v20 >= 45 then
                            if v20 == 46 then
                                u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 3]];
                                local v65 = u2[5];
                                u2[3] = v65;
                                u2[2] = v65[UNNAMED_2819735041784[u3]];
                                u2[12] = u2[2];
                                local v66 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]];
                                u2[4] = v66[5][v66[4]];
                                u2[2] = u9[UNNAMED_2819735045000[u3 + 4]][UNNAMED_2819735045000[u3]];
                                u2[5] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735072744[u3 + 3]];
                                u2[6] = u2[5][UNNAMED_2819735045000[u3 + 1]];
                                u2[5] = u9[UNNAMED_2819735041784[u3 + 1]][UNNAMED_2819735041784[u3 + 3]];
                                u2[7] = u2[5][UNNAMED_2819735072744[u3]];
                                u2[5] = u9[UNNAMED_2819735045000[u3 + 2]][UNNAMED_2819735072744[u3 + 4]];
                                u2[8] = u2[UNNAMED_2819735057720[u3 + 2]][UNNAMED_2819735041784[u3 + 4]];
                                u2[5] = u2[UNNAMED_2819735057720[u3 + 4]];
                                local v67 = UNNAMED_2819735057720[u3 + 1];
                                u2[v67] = u2[v67](u2[v67 + 1], u2[v67 + 2], u2[v67 + 3]);
                                u3 = UNNAMED_2819735086280[u3 + 2] - 4;
                                u3 = u3 + 4;
                            else
                                local v68 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                u2[2] = v68[5][v68[4]][UNNAMED_2819735072744[u3 + 1]];
                                local v69;

                                if u2[2] then
                                    v69 = UNNAMED_2819735084312[u3] - 1;
                                else
                                    v69 = UNNAMED_2819735082680[u3 + 1] - 1;
                                end;

                                u3 = v69;
                                u3 = u3 + 1;
                            end;
                        else
                            if v20 == 44 then
                                local v70 = 2;
                                u2[6] = {};
                                u2[7] = u2[14][UNNAMED_2819735041784[u3 + 1]];
                                u2[6][UNNAMED_2819735045000[u3]] = u2[7];
                                u2[2] = u2[12];
                                u8(u10(u2[v70](u7(u2, 3, 6))), 1, 1, v70, u2);
                                local v71 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                                v71[5][v71[4]] = u2[2];
                                local v72 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                                u2[5] = v72[5][v72[4]];
                                local v73 = u2[5];
                                u2[3] = v73;
                                u2[2] = v73[UNNAMED_2819735041784[u3]];
                                u2[2](u2[3]);

                                return false, false;
                            end;

                            u3 = UNNAMED_2819735084312[u3];
                        end;
                    elseif v20 < 41 then
                        local v74 = UNNAMED_2819735086280[u3];
                        local v75 = UNNAMED_2819735082680[u3];
                        local v76 = UNNAMED_2819735027864[5];
                        local v77 = u11(v76[v74], 109162203);
                        v76[v74] = v77;
                        local v78 = UNNAMED_2819735027864[4];
                        local v79 = v77 + 1;
                        local v80 = u12(v78, v79);
                        local v81;

                        if v80 < 128 then
                            v81 = v79 + 1;
                        else
                            local v82 = u12(v78, v79 + 1);

                            if v82 < 128 then
                                v80 = v80 - 128 + v82 * 128;
                                v81 = v79 + 2;
                            else
                                local v83 = u12(v78, v79 + 2);

                                if v83 < 128 then
                                    v80 = v80 - 128 + (v82 - 128) * 16384 + v83 * 128;
                                    v81 = v79 + 3;
                                else
                                    local v84 = u12(v78, v79 + 3);
                                    v80 = (v80 - 128) * 16384 + (v82 - 128) * 128 + (v83 - 128) + v84 % 128 * 2097152 + (v84 - v84 % 128) * 2097152;
                                    v81 = v79 + 4;
                                end;
                            end;
                        end;

                        local v85 = v75 * 16843009;
                        local v86 = v81 + v80;
                        local v87 = v86 - v80 % 4;

                        for i = v81, v87 - 1, 4 do
                            u13(v78, i, (u11(u14(v78, i), v85)));
                            local _ = i;
                        end;

                        for i = v87, v86 - 1 do
                            u15(v78, i, (u11(u12(v78, i), v75)));
                            local _ = i;
                        end;

                        UNNAMED_2819735086280[u3] = 114;
                        UNNAMED_2819735082680[u3] = 67;
                        UNNAMED_2819735084312[u3] = 35;
                        UNNAMED_2819735057720[u3] = 57;
                    elseif v20 == 42 then
                        local v88 = 1;
                        local v89 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                        v89[5][v89[4]][UNNAMED_2819735045000[u3 + 3]] = UNNAMED_2819735041784[u3];
                        u2[5] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                        local v90 = u2[5];
                        u2[3] = v90;
                        u2[2] = v90[UNNAMED_2819735045000[u3 + 2]];
                        u2[5] = u2[2];
                        u2[UNNAMED_2819735057720[u3 + 1]] = u9[UNNAMED_2819735072744[u3 + 2]][UNNAMED_2819735041784[u3 + 3]];
                        u2[UNNAMED_2819735057720[u3 + 3]] = u2[2][UNNAMED_2819735072744[u3 + 3]];
                        u2[2] = u2[UNNAMED_2819735057720[u3 + 2]];
                        local v91 = UNNAMED_2819735082680[u3];
                        local v92 = UNNAMED_2819735082680[u3 + 1];
                        local _ = v91 + v88 - 1;
                        local _ = v91 + v92;
                        u8(u10(u2[v91](u7(u2, v91 + 1, v91 + v92))), 1, v88, v91, u2);
                        u2[13] = UNNAMED_2819735041784[u3 + 2];
                        u3 = u3 + 3;
                    else
                        local v93 = {};
                        UNNAMED_2819735035496:q3(v93, 0, ...);
                        u8(v93, 1, 1, 31, u2);
                        u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                        u2[2] = u9[UNNAMED_2819735072744[u3 + 1]][u2[3]];
                        u2[3] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];

                        if u2[2] ~= u2[3] then
                            u3 = UNNAMED_2819735084312[u3 + 1] - 1;
                        end;

                        u3 = u3 + 1;
                    end;
                elseif v20 >= 13 then
                    if v20 >= 20 then
                        if v20 >= 23 then
                            if v20 < 25 then
                                if v20 == 24 then
                                    u2[31] = UNNAMED_2819735072744[u3];
                                    u3 = UNNAMED_2819735084312[u3];
                                else
                                    u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                                    local v94 = u2[5];
                                    u2[4] = v94;
                                    local v95 = 2;
                                    u2[3] = v94[UNNAMED_2819735041784[u3]];
                                    u2[UNNAMED_2819735057720[u3 + 2]] = u2[3];
                                    u2[UNNAMED_2819735057720[u3 + 1]] = u9[UNNAMED_2819735045000[u3]][UNNAMED_2819735072744[u3]];
                                    u2[5] = u2[3][UNNAMED_2819735072744[u3 + 2]];
                                    u2[3] = u2[2];
                                    local v96 = UNNAMED_2819735084312[u3 + 1];
                                    local v97 = UNNAMED_2819735082680[u3 + 1];
                                    local _ = v96 + v97 - 1;
                                    local _ = v96 + v95;
                                    u8(u10(u2[v96](u7(u2, v96 + 1, v96 + v95))), 1, v97, v96, u2);
                                    local v98;

                                    if u2[3] then
                                        v98 = UNNAMED_2819735084312[u3 + 2] - 2;
                                    else
                                        v98 = UNNAMED_2819735086280[u3 + 1] - 2;
                                    end;

                                    u3 = v98;
                                    u3 = u3 + 2;
                                end;
                            else
                                if v20 == 26 then
                                    u2[2][UNNAMED_2819735041784[u3]] = u2[UNNAMED_2819735057720[u3 + 1]];
                                    local v99 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                    u2[2] = v99[5][v99[4]];
                                    u2[UNNAMED_2819735086280[u3 + 1]] = u2[9][UNNAMED_2819735041784[u3 + 1]];
                                    u2[2][UNNAMED_2819735045000[u3 + 1]] = u2[UNNAMED_2819735086280[u3]];

                                    return false, false;
                                end;

                                if u2[UNNAMED_2819735086280[u3]] > u2[UNNAMED_2819735082680[u3]] then
                                    u3 = UNNAMED_2819735084312[u3];
                                end;
                            end;
                        elseif v20 < 21 then
                            if u2[UNNAMED_2819735086280[u3]] ~= u2[UNNAMED_2819735082680[u3]] then
                                u3 = UNNAMED_2819735084312[u3];
                            end;
                        elseif v20 == 22 then
                            u3 = UNNAMED_2819735086280[u3];
                        else
                            u2[2] = u2[9][UNNAMED_2819735072744[u3]];
                            u2[3] = UNNAMED_2819735041784[u3 + 2];
                            u1 = u2[3];
                            u2[2] = u2[2][UNNAMED_2819735041784[u3 + 1]];
                            u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735045000[u3 + 2] + u2[2];
                            u2[2] = not u2[UNNAMED_2819735057720[u3 + 2]];
                            local v100;

                            if u2[2] then
                                v100 = UNNAMED_2819735082680[u3] - 2;
                            else
                                v100 = UNNAMED_2819735082680[u3 + 1] - 2;
                            end;

                            u3 = v100;
                            u3 = u3 + 2;
                        end;
                    elseif v20 < 16 then
                        if v20 < 14 then
                            u2[3] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]][UNNAMED_2819735072744[u3 + 1]];
                            local v101;

                            if u2[31] then
                                v101 = UNNAMED_2819735084312[u3 + 1] - 1;
                            else
                                v101 = UNNAMED_2819735084312[u3] - 1;
                            end;

                            u3 = v101;
                            u3 = u3 + 1;
                        else
                            if v20 ~= 15 then
                                return false, false;
                            end;

                            u3 = UNNAMED_2819735086280[u3];
                        end;
                    elseif v20 < 18 then
                        if v20 == 17 then
                            local v102 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                            u2[2] = v102[5][v102[4]][UNNAMED_2819735045000[u3]];
                            u2[3] = u2[14][UNNAMED_2819735072744[u3]];
                            u2[2] = u2[2] - u2[3];
                            u2[2] = u2[2][UNNAMED_2819735072744[u3 + 2]];
                            u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]][UNNAMED_2819735045000[u3 + 1]];
                            u2[3] = u2[3][UNNAMED_2819735041784[u3 + 1]];

                            if u2[UNNAMED_2819735057720[u3 + 1]] > u2[3] then
                                u3 = UNNAMED_2819735082680[u3 + 2] - 2;
                            end;

                            u3 = u3 + 2;
                        elseif u2[UNNAMED_2819735084312[u3]] > UNNAMED_2819735082680[u3] then
                            u3 = UNNAMED_2819735086280[u3];
                        end;
                    else
                        if v20 == 19 then
                            local v103 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            v103[5][v103[4]] = u2[32];

                            return false, false;
                        end;

                        u2[3] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        local v104 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                        u2[4] = v104[5][v104[4]];
                        u2[3](u2[2], u2[4]);
                        u3 = UNNAMED_2819735084312[u3];
                    end;
                elseif v20 >= 6 then
                    if v20 >= 9 then
                        if v20 < 11 then
                            if v20 == 10 then
                                u2[2] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                                u2[2]();

                                return false, false;
                            end;

                            u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735041784[u3]];
                            local v105;

                            if u2[1] then
                                v105 = UNNAMED_2819735082680[u3 + 1] - 1;
                            else
                                v105 = UNNAMED_2819735084312[u3 + 1] - 1;
                            end;

                            u3 = v105;
                            u3 = u3 + 1;
                        elseif v20 == 12 then
                            u2[1] = 0;

                            if u2[1] > 0 then
                                u3 = UNNAMED_2819735082680[u3];
                            end;
                        else
                            local v106 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                            u2[2] = v106[5][v106[4]];
                            local v107;

                            if u2[UNNAMED_2819735057720[u3 + 1]] then
                                v107 = UNNAMED_2819735084312[u3 + 1] - 1;
                            else
                                v107 = UNNAMED_2819735082680[u3] - 1;
                            end;

                            u3 = v107;
                            u3 = u3 + 1;
                        end;
                    elseif v20 >= 7 then
                        if v20 == 8 then
                            u2[4] = u9[UNNAMED_2819735045000[u3 + 1]][UNNAMED_2819735041784[u3 + 3]];
                            u2[5] = u2[UNNAMED_2819735057720[u3 + 3]][UNNAMED_2819735072744[u3 + 3]];
                            u2[UNNAMED_2819735057720[u3 + 2]] = u2[UNNAMED_2819735057720[u3 + 1]](u2[5]);
                            u2[2][UNNAMED_2819735072744[u3 + 2]] = u2[UNNAMED_2819735082680[u3 + 2]];
                            local v108 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                            u2[4] = v108[5][v108[4]];
                            local v109 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            v109[5][v109[4]][UNNAMED_2819735072744[u3]] = u2[UNNAMED_2819735086280[u3 + 1]];

                            return false, false;
                        end;

                        u2[2] = 1564588;
                        u1 = u2[UNNAMED_2819735084312[u3]];
                        u3 = UNNAMED_2819735082680[u3];
                    else
                        u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                        local v110 = UNNAMED_2819735057720[u3 + 2];
                        local v111 = u2[5];
                        u2[v110 + 1] = v111;
                        u2[v110] = v111[UNNAMED_2819735041784[u3]];
                        local v112 = 3;
                        u2[2] = u2[3];
                        u2[3] = u9[UNNAMED_2819735072744[u3 + 1]][UNNAMED_2819735041784[u3 + 1]];
                        u2[5] = u2[3][UNNAMED_2819735072744[u3 + 2]];
                        u2[3] = u2[UNNAMED_2819735057720[u3 + 1]];
                        u8(u10(u2[v112](u7(u2, 4, 5))), 1, 1, v112, u2);
                        local v113;

                        if u2[3] then
                            v113 = UNNAMED_2819735086280[u3] - 2;
                        else
                            v113 = UNNAMED_2819735084312[u3 + 2] - 2;
                        end;

                        u3 = v113;
                        u3 = u3 + 2;
                    end;
                elseif v20 >= 3 then
                    if v20 >= 4 then
                        if v20 ~= 5 then
                            local v114 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                            u2[5] = v114[5][v114[4]];
                            local v115 = u2[5];
                            u2[3] = v115;
                            u2[2] = v115[UNNAMED_2819735045000[u3]];
                            u2[2](u2[UNNAMED_2819735084312[u3]]);

                            return false, false;
                        end;

                        local v116 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        u2[UNNAMED_2819735086280[u3]] = v116[5][v116[4]];
                    else
                        local v117 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                        v117[5][v117[4]][UNNAMED_2819735072744[u3 + 1]] = u2[2];
                        local v118 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                        v118[5][v118[4]] = u2[2];
                        u3 = UNNAMED_2819735084312[u3 + 1] - 1;
                        u3 = u3 + 1;
                    end;
                elseif v20 < 1 then
                    local v119 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                    u2[3] = v119[5][v119[4]][UNNAMED_2819735072744[u3]];
                    local v120;

                    if u2[UNNAMED_2819735057720[u3 + 1]] then
                        v120 = UNNAMED_2819735084312[u3 + 1] - 1;
                    else
                        v120 = UNNAMED_2819735082680[u3] - 1;
                    end;

                    u3 = v120;
                    u3 = u3 + 1;
                elseif v20 == 2 then
                    local v121 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                    u2[2] = v121[5][v121[4]];
                    local v122 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]];
                    u2[UNNAMED_2819735057720[u3 + 2]] = v122[5][v122[4]];
                    u2[4] = UNNAMED_2819735072744[u3 + 2] - u2[UNNAMED_2819735057720[u3 + 1]];
                    u2[4] = u2[4] * u2[8];
                    u2[2] = u2[2] + u2[4];
                    local v123 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                    v123[5][v123[4]] = u2[2];
                    u2[UNNAMED_2819735082680[u3]] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                    u2[2] = u2[UNNAMED_2819735086280[u3]]();
                    local v124 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                    u2[4] = v124[5][v124[4]];

                    if u2[2] ~= u2[4] then
                        u3 = UNNAMED_2819735082680[u3 + 1] - 2;
                    end;

                    u3 = u3 + 2;
                else
                    u2[3] = UNNAMED_2819735082680[u3];
                    u3 = UNNAMED_2819735086280[u3];
                end;
            elseif v20 < 81 then
                if v20 >= 67 then
                    if v20 >= 74 then
                        if v20 < 77 then
                            if v20 < 75 then
                                local v125 = UNNAMED_2819735084312[u3];
                                local v126 = UNNAMED_2819735086280[u3];
                                local v127 = UNNAMED_2819735082680[u3];
                                local v128 = u11(u1, u17(u16(u1, 14), 262143), (u17(u16(u1, 28), 15)));
                                local v129 = v125 < 16384 and 7 or (v125 < 2097152 and 14 or 21);
                                local v130 = u17(v125, u18(1, v129) - 1);
                                UNNAMED_2819735057720[u3] = u11(u16(v125, v129), 45, (u17(u16(v128, 21), 127)));
                                UNNAMED_2819735084312[u3] = u11(v130, 77, (u17(u16(v128, 7), 127)));
                                UNNAMED_2819735082680[u3] = u11(v127, 125, (u17(v128, 127)));
                                UNNAMED_2819735086280[u3] = u11(v126, 78, (u17(u16(v128, 14), 127)));
                                u3 = u3 - 1;
                            else
                                if v20 == 76 then
                                    local v131 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                    u2[5] = v131[5][v131[4]];
                                    local v132 = u2[5];
                                    u2[3] = v132;
                                    u2[2] = v132[UNNAMED_2819735041784[u3]];
                                    u2[2](u2[UNNAMED_2819735057720[u3 + 1]]);
                                    local v133 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                                    v133[5][v133[4]] = u2[15];

                                    return false, false;
                                end;

                                local v134 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                u2[UNNAMED_2819735057720[u3 + 1]] = v134[5][v134[4]];
                                u2[2] = 494151920;
                                u1 = u2[2];
                                local v135 = UNNAMED_2819735084312[u3];
                                local v136 = u2[4];
                                u2[v135 + 1] = v136;
                                u2[v135] = v136[UNNAMED_2819735072744[u3]];
                                u2[2](u2[3]);
                                u2[2] = 1564588;
                                u1 = u2[2];
                                u3 = UNNAMED_2819735082680[u3] - 1;
                                u3 = u3 + 1;
                            end;
                        elseif v20 >= 79 then
                            if v20 == 80 then
                                u2[2] = UNNAMED_2819735041784[u3 + 1];
                                u1 = u2[2];
                                u2[5] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 2]];
                                local v137 = u2[5];
                                u2[4] = v137;
                                u2[3] = v137[UNNAMED_2819735041784[u3]];
                                u2[2] = u2[3];
                                u2[UNNAMED_2819735057720[u3 + 1]] = u9[UNNAMED_2819735045000[u3 + 2]][UNNAMED_2819735072744[u3]];
                                u2[5] = u2[3][UNNAMED_2819735045000[u3]];
                                u2[3] = u2[2];
                                u3 = UNNAMED_2819735084312[u3 + 2] - 2;
                                u3 = u3 + 2;
                            else
                                local v138 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                                u2[2] = v138[5][v138[4]][UNNAMED_2819735041784[u3]];
                                u2[3] = u2[UNNAMED_2819735057720[u3 + 1]][UNNAMED_2819735072744[u3 + 1]];

                                if u2[3] <= 0 then
                                    u3 = UNNAMED_2819735082680[u3 + 1] - 1;
                                end;

                                u3 = u3 + 1;
                            end;
                        elseif v20 == 78 then
                            local v139 = u11(u1, u17(u16(u1, 14), 262143), (u17(u16(u1, 28), 15)));
                            local v140 = UNNAMED_2819735086280[u3];
                            local v141 = UNNAMED_2819735084312[u3];
                            local v142 = UNNAMED_2819735082680[u3];
                            local v143 = v142 < 2097152 and 7 or 14;
                            local v144 = u16(v142, v143);
                            local v145 = u17(v142, u18(1, v143) - 1);
                            UNNAMED_2819735086280[u3] = u11(v140, 123, (u17(u16(v139, 14), 127)));
                            UNNAMED_2819735084312[u3] = u11(v141, 78, (u17(u16(v139, 7), 127)));
                            UNNAMED_2819735082680[u3] = u11(v145, 87, (u17(v139, 127)));
                            UNNAMED_2819735057720[u3] = u11(v144, 8, (u17(u16(v139, 21), 127)));
                            u3 = u3 - 1;
                        else
                            local v146 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                            u2[2] = v146[5][v146[4]];
                            u2[5] = u9[UNNAMED_2819735041784[u3 + 2]][UNNAMED_2819735045000[u3 + 1]];
                            u2[5] = u2[5][UNNAMED_2819735072744[u3 + 1]];
                            u2[2][UNNAMED_2819735045000[u3 + 3]] = u2[UNNAMED_2819735057720[u3 + 3]];
                            u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                            local v147 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 3]];
                            v147[5][v147[4]][UNNAMED_2819735041784[u3]] = u2[UNNAMED_2819735057720[u3 + 2]];
                            u2[5] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 2]];
                            local v148 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 4]];
                            v148[5][v148[4]][UNNAMED_2819735045000[u3 + 4]] = u2[5];
                            u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735057720[u3 + 4];
                            u1 = u2[4];
                            local v149 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 4]];
                            v149[5][v149[4]] = u2[32];
                            u3 = u3 + 4;
                        end;
                    elseif v20 >= 70 then
                        if v20 < 72 then
                            if v20 == 71 then
                                u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                local v150 = u2[5];
                                u2[3] = v150;
                                u2[2] = v150[UNNAMED_2819735045000[u3 + 1]];
                                u2[2](u2[3], UNNAMED_2819735041784[u3 + 1]);
                                u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                u2[UNNAMED_2819735086280[u3]]();

                                return false, false;
                            end;

                            local v151 = UNNAMED_2819735084312[u3];
                            u2[4] = UNNAMED_2819735057720[u3 + 1];
                            u2[5] = v151;
                            local v152 = 2;
                            u2[UNNAMED_2819735082680[u3]] = u2[6];
                            u2[v152] = u2[v152](u2[3], u2[4], u2[5]);
                            u2[3] = u2[2] + 2;
                            local v153 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                            u2[2] = v153[5][v153[4]];
                            u2[4] = not u2[2];
                            local v154;

                            if u2[2] then
                                v154 = UNNAMED_2819735086280[u3 + 1] - 1;
                            else
                                v154 = UNNAMED_2819735082680[u3 + 1] - 1;
                            end;

                            u3 = v154;
                            u3 = u3 + 1;
                        elseif v20 == 73 then
                            local v155 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                            u2[3] = v155[5][v155[4]];
                            local v156;

                            if u2[3] then
                                v156 = UNNAMED_2819735084312[u3];
                            else
                                v156 = UNNAMED_2819735082680[u3];
                            end;

                            u3 = v156;
                        else
                            u2[3] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                            u2[2] = u9[UNNAMED_2819735072744[u3]][u2[3]];
                            u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                            u2[2] = u2[UNNAMED_2819735057720[u3 + 1]] ~= u2[3];
                            u2[3] = UNNAMED_2819735072744[u3 + 1];
                            u1 = u2[3];
                            u3 = u3 + 1;
                        end;
                    else
                        if v20 < 68 then
                            local v157 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                            u2[9] = v157[5][v157[4]];
                            local v158 = u2[9];
                            u2[5] = v158;
                            u2[4] = v158[UNNAMED_2819735045000[u3 + 1]];
                            u2[4](u2[UNNAMED_2819735057720[u3 + 1]]);
                            local v159 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                            v159[5][v159[4]] = u2[11];

                            return false, false;
                        end;

                        if v20 == 69 then
                            local v160 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                            u2[3] = v160[5][v160[4]];
                            local v161 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            u2[5] = v161[5][v161[4]][UNNAMED_2819735072744[u3 + 1]];
                            u2[1] = u2[2] * u2[1];
                            u2[1] = u2[UNNAMED_2819735057720[u3 + 1]] * u2[UNNAMED_2819735082680[u3 + 1]];
                            u2[UNNAMED_2819735084312[u3]] = u2[5] + u2[1];
                            u2[3][UNNAMED_2819735041784[u3 + 1]] = u2[1];

                            return false, false;
                        end;

                        local v162 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                        u2[5] = v162[5][v162[4]];
                        local v163 = u2[5];
                        u2[3] = v163;
                        u2[2] = v163[UNNAMED_2819735045000[u3]];
                        u2[UNNAMED_2819735057720[u3 + 1]](u2[3]);
                        local v164 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                        v164[5][v164[4]] = u2[15];
                        u3 = UNNAMED_2819735086280[u3] - 1;
                        u3 = u3 + 1;
                    end;
                elseif v20 < 60 then
                    if v20 >= 57 then
                        if v20 >= 58 then
                            if v20 == 59 then
                                u3 = UNNAMED_2819735086280[u3];
                            else
                                local v165 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                                u2[2] = v165[5][v165[4]];
                                u2[UNNAMED_2819735057720[u3 + 1]] = u2[UNNAMED_2819735086280[u3]][UNNAMED_2819735072744[u3 + 1]];

                                if u2[UNNAMED_2819735082680[u3]] <= 0 then
                                    u3 = UNNAMED_2819735084312[u3] - 1;
                                end;

                                u3 = u3 + 1;
                            end;
                        end;
                    elseif v20 >= 55 then
                        if v20 == 56 then
                            u2[2] = UNNAMED_2819735045000[u3];
                            u1 = u2[UNNAMED_2819735084312[u3]];
                            u3 = UNNAMED_2819735086280[u3];
                        else
                            local v166 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                            u2[UNNAMED_2819735057720[u3 + 2]] = v166[5][v166[4]];
                            local v167 = u2[5];
                            u2[3] = v167;
                            u2[2] = v167[UNNAMED_2819735072744[u3]];
                            u2[2](u2[3]);
                            local v168 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            v168[5][v168[4]] = u2[15];
                            u2[2] = UNNAMED_2819735072744[u3 + 2];
                            u1 = u2[2];
                            u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735041784[u3 + 2];
                            u1 = u2[2];
                            u3 = UNNAMED_2819735084312[u3 + 1] - 2;
                            u3 = u3 + 2;
                        end;
                    else
                        local v169 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                        u2[3] = v169[5][v169[4]];
                        u2[3] = u11(u2[UNNAMED_2819735057720[u3 + 1]], UNNAMED_2819735072744[u3]);
                        local v170 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        v170[5][v170[4]] = u2[3];

                        if u2[1] ~= u2[2] then
                            u3 = UNNAMED_2819735086280[u3 + 1] - 1;
                        end;

                        u3 = u3 + 1;
                    end;
                elseif v20 >= 63 then
                    if v20 < 65 then
                        if v20 == 64 then
                            local v171 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            u2[5] = v171[5][v171[4]];
                            local v172 = u2[5];
                            u2[3] = v172;
                            u2[2] = v172[UNNAMED_2819735045000[u3 + 1]];
                            u2[2](u2[UNNAMED_2819735057720[u3 + 1]]);
                            u2[2] = 96702788;
                            u1 = u2[UNNAMED_2819735086280[u3 + 1]];
                            local v173 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                            v173[5][v173[4]] = u2[32];
                            local v174 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                            v174[5][v174[4]] = u2[32];
                            u2[UNNAMED_2819735084312[u3]] = 1564588;
                            u1 = u2[2];

                            return false, false;
                        end;

                        u2[7] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                        u2[UNNAMED_2819735057720[u3 + 1]] = u2[UNNAMED_2819735082680[u3 + 1]][UNNAMED_2819735072744[u3]];
                        local v175;

                        if u2[2] then
                            v175 = UNNAMED_2819735082680[u3] - 1;
                        else
                            v175 = UNNAMED_2819735084312[u3] - 1;
                        end;

                        u3 = v175;
                        u3 = u3 + 1;
                    elseif v20 == 66 then
                        local v176 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        u2[1] = v176[5][v176[4]];
                        local v177;

                        if u2[UNNAMED_2819735057720[u3 + 1]] then
                            v177 = UNNAMED_2819735084312[u3 + 1] - 1;
                        else
                            v177 = UNNAMED_2819735082680[u3 + 1] - 1;
                        end;

                        u3 = v177;
                        u3 = u3 + 1;
                    else
                        u2[1] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735072744[u3 + 1]];
                        local v178;

                        if u2[UNNAMED_2819735057720[u3 + 1]] then
                            v178 = UNNAMED_2819735086280[u3] - 1;
                        else
                            v178 = UNNAMED_2819735082680[u3] - 1;
                        end;

                        u3 = v178;
                        u3 = u3 + 1;
                    end;
                elseif v20 >= 61 then
                    if v20 == 62 then
                        u2[13] = u2[13] + UNNAMED_2819735045000[u3];
                        u3 = UNNAMED_2819735084312[u3];
                    else
                        u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]][UNNAMED_2819735045000[u3 + 1]];
                        u2[2] = u2[2][UNNAMED_2819735041784[u3 + 1]];
                        local v179;

                        if u2[2] then
                            v179 = UNNAMED_2819735086280[u3] - 1;
                        else
                            v179 = UNNAMED_2819735084312[u3] - 1;
                        end;

                        u3 = v179;
                        u3 = u3 + 1;
                    end;
                else
                    u2[UNNAMED_2819735057720[u3 + 1]] = u2[9][UNNAMED_2819735041784[u3 + 1]];
                    u2[UNNAMED_2819735082680[u3]] = u2[2][UNNAMED_2819735045000[u3 + 1]];
                    u2[13] = u2[13] - u2[2];
                    u3 = UNNAMED_2819735086280[u3 + 1] - 1;
                    u3 = u3 + 1;
                end;
            elseif v20 >= 95 then
                if v20 >= 102 then
                    if v20 >= 105 then
                        if v20 < 107 then
                            if v20 == 106 then
                                u2[7] = u2[19];
                                u3 = UNNAMED_2819735086280[u3];
                            else
                                u2[4] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                u2[UNNAMED_2819735057720[u3 + 1]] = not u2[4];
                                local v180;

                                if u2[UNNAMED_2819735084312[u3 + 1]] then
                                    v180 = UNNAMED_2819735082680[u3] - 1;
                                else
                                    v180 = UNNAMED_2819735086280[u3] - 1;
                                end;

                                u3 = v180;
                                u3 = u3 + 1;
                            end;
                        elseif v20 == 108 then
                            local v181 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                            u2[2] = v181[5][v181[4]][UNNAMED_2819735072744[u3]];
                            u2[3] = u9[UNNAMED_2819735041784[u3 + 1]][UNNAMED_2819735072744[u3 + 1]];
                            u2[3] = u2[3][UNNAMED_2819735045000[u3]];

                            if u2[2] ~= u2[3] then
                                u3 = UNNAMED_2819735084312[u3] - 1;
                            end;

                            u3 = u3 + 1;
                        else
                            u2[2] = u2[9][UNNAMED_2819735041784[u3 + 1]];
                            u2[2] = u2[2][UNNAMED_2819735045000[u3 + 1]];
                            u2[13] = u2[UNNAMED_2819735057720[u3 + 1]] - u2[UNNAMED_2819735084312[u3]];
                            u3 = UNNAMED_2819735082680[u3] - 1;
                            u3 = u3 + 1;
                        end;
                    elseif v20 < 103 then
                        local v182 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 4]];
                        u2[2] = v182[5][v182[4]];
                        u2[5] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]][UNNAMED_2819735072744[u3 + 3]];
                        u2[UNNAMED_2819735057720[u3 + 2]] = u2[5][UNNAMED_2819735041784[u3 + 1]];
                        u2[UNNAMED_2819735057720[u3 + 1]][UNNAMED_2819735045000[u3 + 4]] = u2[5];
                        local v183 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 3]];
                        u2[9] = v183[5][v183[4]];
                        u2[6] = u9[UNNAMED_2819735045000[u3 + 1]][UNNAMED_2819735072744[u3 + 2]];
                        u2[UNNAMED_2819735057720[u3 + 3]] = u2[6];
                        local v184 = u2[3];
                        u2[4] = u2[UNNAMED_2819735057720[u3 + 4]];
                        u2[5] = v184;
                        local v185 = 2;
                        u2[v185] = u2[v185](u2[3], u2[4], u2[5]);
                        u2[UNNAMED_2819735086280[u3 + 4]][UNNAMED_2819735072744[u3 + 1]] = u2[2];
                        local v186 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 3]];
                        u2[UNNAMED_2819735082680[u3 + 2]] = v186[5][v186[4]];
                        u3 = UNNAMED_2819735082680[u3] - 4;
                        u3 = u3 + 4;
                    elseif v20 == 104 then
                        u2[2] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                        u2[7] = u2[2]();
                        local v187;

                        if u2[7] then
                            v187 = UNNAMED_2819735082680[u3];
                        else
                            v187 = UNNAMED_2819735084312[u3];
                        end;

                        u3 = v187;
                    else
                        u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]];
                        u2[UNNAMED_2819735057720[u3 + 2]] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735045000[u3 + 1]];
                        u2[4] = u2[4] - u2[UNNAMED_2819735082680[u3]];
                        u2[4] = u2[UNNAMED_2819735086280[u3 + 2]][UNNAMED_2819735072744[u3 + 1]];
                        u2[5] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                        u3 = u3 + 2;
                    end;
                elseif v20 < 98 then
                    if v20 >= 96 then
                        if v20 == 97 then
                            u8({ ... }, 1, 2, 31, u2);

                            return false, true, u10(u2[31], u2[32]);
                        end;

                        local v188 = UNNAMED_2819735082680[u3];
                        local v189 = u11(UNNAMED_2819735084312[u3], (u17(u11(u1, (u17(u16(u1, 29), 7))), 536870911)));
                        local v190 = UNNAMED_2819735027864[5];
                        local v191 = u11(v190[v188], 109162203);
                        v190[v188] = v191;
                        local v192 = UNNAMED_2819735027864[4];
                        local v193 = v191 + 1;
                        local v194 = u12(v192, v193);
                        local v195;

                        if v194 < 128 then
                            v195 = v193 + 1;
                        else
                            local v196 = u12(v192, v193 + 1);

                            if v196 < 128 then
                                v194 = v194 - 128 + v196 * 128;
                                v195 = v193 + 2;
                            else
                                local v197 = u12(v192, v193 + 2);

                                if v197 < 128 then
                                    v194 = v194 - 128 + (v196 - 128) * 16384 + v197 * 128;
                                    v195 = v193 + 3;
                                else
                                    local v198 = u12(v192, v193 + 3);
                                    v194 = (v194 - 128) * 16384 + (v196 - 128) * 128 + (v197 - 128) + v198 % 128 * 2097152 + (v198 - v198 % 128) * 2097152;
                                    v195 = v193 + 4;
                                end;
                            end;
                        end;

                        local v199 = v189 * 16843009;
                        local v200 = v195 + v194;
                        local v201 = v200 - v194 % 4;

                        for i = v195, v201 - 1, 4 do
                            u13(v192, i, (u11(u14(v192, i), v199)));
                            local _ = i;
                        end;

                        for i = v201, v200 - 1 do
                            u15(v192, i, (u11(u12(v192, i), v189)));
                            local _ = i;
                        end;

                        UNNAMED_2819735082680[u3] = 239;
                        UNNAMED_2819735084312[u3] = 51;
                        UNNAMED_2819735086280[u3] = 184;
                        UNNAMED_2819735057720[u3] = 57;
                    else
                        local v202 = 3;
                        u8(u10(u2[v202](u7(u2, 4, 5))), 1, 1, v202, u2);
                        local v203;

                        if u2[3] then
                            v203 = UNNAMED_2819735086280[u3];
                        else
                            v203 = UNNAMED_2819735082680[u3];
                        end;

                        u3 = v203;
                    end;
                elseif v20 < 100 then
                    if v20 == 99 then
                        local v204 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                        u2[5] = v204[5][v204[4]];
                        local v205 = u2[5];
                        u2[3] = v205;
                        u2[2] = v205[UNNAMED_2819735045000[u3]];
                        u2[2](u2[3]);
                        u3 = UNNAMED_2819735084312[u3];
                    else
                        u2[1] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                        u2[UNNAMED_2819735082680[u3]] = u2[1]();
                    end;
                elseif v20 == 101 then
                    u2[6] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735045000[u3 + 2]];
                    u2[2] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735041784[u3]];
                    u2[3] = u2[2][UNNAMED_2819735045000[u3 + 1]];
                    local v206;

                    if u2[3] then
                        v206 = UNNAMED_2819735082680[u3] - 2;
                    else
                        v206 = UNNAMED_2819735086280[u3] - 2;
                    end;

                    u3 = v206;
                    u3 = u3 + 2;
                else
                    u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                    local v207 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                    u2[UNNAMED_2819735057720[u3 + 1]] = v207[5][v207[4]];
                    u2[3](u2[2], u2[4]);
                    u3 = UNNAMED_2819735086280[u3] - 1;
                    u3 = u3 + 1;
                end;
            elseif v20 < 88 then
                if v20 < 84 then
                    if v20 < 82 then
                        local v208 = UNNAMED_2819735084312[u3];
                        local v209 = UNNAMED_2819735082680[u3];
                        u8({ ... }, 1, v208 - 1, v209, u2);
                        u2[v209 + v208 - 1] = u10(u19(v208, ...));
                    elseif v20 == 83 then
                        u8({ ... }, 1, UNNAMED_2819735057720[u3 + 2], UNNAMED_2819735057720[u3 + 1], u2);
                        u2[2] = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 2]];
                        u2[1] = u9[UNNAMED_2819735072744[u3]][u2[UNNAMED_2819735082680[u3 + 2]]];
                        u2[2] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                        local v210 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]];
                        u2[UNNAMED_2819735084312[u3]] = v210[5][v210[4]];
                        u2[3] = u2[3] + 111040668;

                        if u2[UNNAMED_2819735084312[u3 + 1]] ~= UNNAMED_2819735082680[u3] then
                            u3 = UNNAMED_2819735086280[u3 + 1] - 2;
                        end;

                        u3 = u3 + 2;
                    else
                        local v211 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                        u2[2] = v211[5][v211[4]];
                        local v212 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                        u2[4] = v212[5][v212[4]];
                        u2[4] = u2[UNNAMED_2819735057720[u3 + 1]] == 176776780;
                        local v213;

                        if u2[4] then
                            v213 = UNNAMED_2819735082680[u3] - 1;
                        else
                            v213 = UNNAMED_2819735082680[u3 + 1] - 1;
                        end;

                        u3 = v213;
                        u3 = u3 + 1;
                    end;
                elseif v20 >= 86 then
                    if v20 == 87 then
                        u2[2] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        u2[2] = u2[UNNAMED_2819735057720[u3 + 1]]();
                        local v214;

                        if u2[2] then
                            v214 = UNNAMED_2819735082680[u3 + 1] - 1;
                        else
                            v214 = UNNAMED_2819735086280[u3 + 1] - 1;
                        end;

                        u3 = v214;
                        u3 = u3 + 1;
                    else
                        local v215 = UNNAMED_2819735082680[u3] + 1;
                        local v216 = u11(UNNAMED_2819735084312[u3], (u17(u11(u1, (u17(u16(u1, 29), 7))), 536870911)));

                        for i = 1, UNNAMED_2819735086280[u3] do
                            local v217 = u17(u11(v216, (u18(v216, 13))), 536870911);
                            local v218 = u11(v217, (u16(v217, 13)));
                            v216 = u17(u11(v218, (u18(v218, 14))), 536870911);
                            UNNAMED_2819735082680[v215] = u11(UNNAMED_2819735082680[v215], (u17(u16(v216, 0), 127)));
                            UNNAMED_2819735084312[v215] = u11(UNNAMED_2819735084312[v215], (u17(u16(v216, 7), 127)));
                            UNNAMED_2819735086280[v215] = u11(UNNAMED_2819735086280[v215], (u17(u16(v216, 14), 127)));
                            UNNAMED_2819735057720[v215] = u11(UNNAMED_2819735057720[v215], (u17(u16(v216, 21), 127)));
                            v215 = v215 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735057720[u3] = 57;
                    end;
                elseif v20 == 85 then
                    local v219 = UNNAMED_2819735082680[u3] + 1;
                    local v220 = UNNAMED_2819735086280[u3];

                    for i = 1, UNNAMED_2819735084312[u3] do
                        local v221 = u17(u11(v220, (u18(v220, 13))), 536870911);
                        local v222 = u11(v221, (u16(v221, 13)));
                        v220 = u17(u11(v222, (u18(v222, 14))), 536870911);
                        UNNAMED_2819735082680[v219] = u11(UNNAMED_2819735082680[v219], (u17(u16(v220, 0), 127)));
                        UNNAMED_2819735084312[v219] = u11(UNNAMED_2819735084312[v219], (u17(u16(v220, 7), 127)));
                        UNNAMED_2819735086280[v219] = u11(UNNAMED_2819735086280[v219], (u17(u16(v220, 14), 127)));
                        UNNAMED_2819735057720[v219] = u11(UNNAMED_2819735057720[v219], (u17(u16(v220, 21), 127)));
                        v219 = v219 + 1;
                        local _ = i;
                    end;

                    UNNAMED_2819735057720[u3] = 57;
                else
                    u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                    u2[2] = u9[UNNAMED_2819735072744[u3]][u2[3]];
                    u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];

                    if u2[2] ~= u2[3] then
                        u3 = UNNAMED_2819735086280[u3 + 1] - 1;
                    end;

                    u3 = u3 + 1;
                end;
            elseif v20 < 91 then
                if v20 >= 89 then
                    if v20 == 90 then
                        local v223 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        u2[2] = v223[5][v223[4]];
                        local v224;

                        if u2[2] then
                            v224 = UNNAMED_2819735084312[u3];
                        else
                            v224 = UNNAMED_2819735086280[u3];
                        end;

                        u3 = v224;
                    else
                        local v225 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3]];
                        u2[UNNAMED_2819735057720[u3 + 1]] = v225[5][v225[4]];
                        local v226;

                        if u2[2] then
                            v226 = UNNAMED_2819735082680[u3] - 1;
                        else
                            v226 = UNNAMED_2819735086280[u3 + 1] - 1;
                        end;

                        u3 = v226;
                        u3 = u3 + 1;
                    end;
                else
                    u2[2] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]][UNNAMED_2819735041784[u3 + 1]];
                    u2[2] = u2[2][UNNAMED_2819735045000[u3 + 1]];
                    local v227;

                    if u2[2] then
                        v227 = UNNAMED_2819735084312[u3] - 1;
                    else
                        v227 = UNNAMED_2819735086280[u3] - 1;
                    end;

                    u3 = v227;
                    u3 = u3 + 1;
                end;
            elseif v20 >= 93 then
                if v20 == 94 then
                    local v228 = UNNAMED_2819735088488[UNNAMED_2819735086280[u3 + 1]];
                    u2[5] = v228[5][v228[4]];
                    local v229 = u2[UNNAMED_2819735057720[u3 + 1]];
                    u2[3] = v229;
                    u2[2] = v229[UNNAMED_2819735045000[u3 + 1]];
                    u2[2](u2[3]);
                    local v230 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                    v230[5][v230[4]] = u2[15];

                    return false, false;
                end;

                local v231;

                if u2[UNNAMED_2819735082680[u3]] then
                    v231 = UNNAMED_2819735086280[u3];
                else
                    v231 = UNNAMED_2819735084312[u3];
                end;

                u3 = v231;
            elseif v20 == 92 then
                u2[2] = u2[UNNAMED_2819735057720[u3 + 1]][UNNAMED_2819735072744[u3 + 1]];
                u2[2] = u2[2][UNNAMED_2819735041784[u3]];
                u2[UNNAMED_2819735084312[u3 + 1]] = u2[13] + u2[UNNAMED_2819735082680[u3]];
                u3 = UNNAMED_2819735086280[u3] - 1;
                u3 = u3 + 1;
            else
                u2[4] = u2[13][UNNAMED_2819735041784[u3 + 1]];
                u2[UNNAMED_2819735057720[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]][UNNAMED_2819735072744[u3 + 1]];
                u2[4] = u2[4] * u2[5];
                local v232;

                if u2[4] then
                    v232 = UNNAMED_2819735084312[u3] - 1;
                else
                    v232 = UNNAMED_2819735082680[u3] - 1;
                end;

                u3 = v232;
                u3 = u3 + 1;
            end;

            u3 = u3 + 1;
        end;
    else
        if u4 ~= 83 then
            return;
        end;

        while true do
            local v233 = UNNAMED_2819735086280[u3];

            if v233 >= 52 then
                if v233 < 78 then
                    if v233 >= 65 then
                        if v233 >= 71 then
                            if v233 >= 74 then
                                if v233 < 76 then
                                    if v233 == 75 then
                                        local v234 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                        v234[5][v234[4]] = u2[14];

                                        return false, false;
                                    end;

                                    local v235 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                    u2[9] = v235[5][v235[4]];
                                    local v236 = u2[UNNAMED_2819735086280[u3 + 1]];
                                    u2[7] = v236;
                                    u2[6] = v236[UNNAMED_2819735045000[u3 + 1]];
                                    u2[6](u2[7]);
                                    local v237 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                                    v237[5][v237[4]] = u2[UNNAMED_2819735084312[u3]];
                                    u3 = UNNAMED_2819735057720[u3 + 1] - 1;
                                    u3 = u3 + 1;
                                elseif v233 == 77 then
                                    u2[4] = u9[UNNAMED_2819735079752[u3]];

                                    if u2[UNNAMED_2819735084312[u3]] >= u2[3] then
                                        u3 = UNNAMED_2819735082680[u3];
                                    end;
                                else
                                    u3 = UNNAMED_2819735084312[u3];
                                end;
                            else
                                if v233 < 72 then
                                    local v238 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                    v238[5][v238[4]] = u2[UNNAMED_2819735057720[u3]];

                                    return false, false;
                                end;

                                if v233 == 73 then
                                    local v239 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                                    v239[5][v239[4]] = u2[14];

                                    return false, false;
                                end;

                                u2[UNNAMED_2819735084312[u3]] = u2[6][UNNAMED_2819735045000[u3]];
                                u2[5] = u2[UNNAMED_2819735057720[u3]] - u2[6];
                            end;
                        elseif v233 < 68 then
                            if v233 >= 66 then
                                if v233 == 67 then
                                    local v240 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                    v240[5][v240[4]] = u2[14];

                                    return false, false;
                                end;

                                u9[UNNAMED_2819735079752[u3]] = u2[3];
                                u2[2] = u9[UNNAMED_2819735045000[u3]];
                                local v241;

                                if u2[2] then
                                    v241 = UNNAMED_2819735084312[u3] - 1;
                                else
                                    v241 = UNNAMED_2819735057720[u3 + 1] - 1;
                                end;

                                u3 = v241;
                                u3 = u3 + 1;
                            else
                                u2[6] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                u2[5] = u9[UNNAMED_2819735079752[u3]][u2[6]];
                                u2[6] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            end;
                        elseif v233 >= 69 then
                            if v233 == 70 then
                                local v242 = 5;
                                u2[10] = u9[UNNAMED_2819735041784[u3 + 2]][UNNAMED_2819735079752[u3 + 1]];
                                u2[5] = u2[11][UNNAMED_2819735041784[u3 + 1]];
                                u2[UNNAMED_2819735086280[u3 + 2]] = u2[5][UNNAMED_2819735079752[u3]];
                                u2[5] = u2[11][UNNAMED_2819735045000[u3 + 1]];
                                u2[8] = u2[5][UNNAMED_2819735045000[u3]];
                                u2[UNNAMED_2819735086280[u3 + 1]] = 0;
                                u2[5] = u2[10];
                                local v243 = UNNAMED_2819735057720[u3 + 2];
                                local _ = v242 + v243;
                                u8(u10(u2[v242](u7(u2, 6, v242 + v243))), 1, 1, v242, u2);
                                u2[10] = u2[5];
                                u2[5] = u2[10][UNNAMED_2819735041784[u3]];

                                if u2[5] >= 3 then
                                    u3 = UNNAMED_2819735082680[u3 + 2] - 2;
                                end;

                                u3 = u3 + 2;
                            else
                                u2[5] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                u2[11] = u2[5]();
                                local v244;

                                if u2[11] then
                                    v244 = UNNAMED_2819735082680[u3];
                                else
                                    v244 = UNNAMED_2819735057720[u3];
                                end;

                                u3 = v244;
                            end;
                        else
                            u2[UNNAMED_2819735086280[u3 + 1]] = u9[UNNAMED_2819735079752[u3 + 1]];
                            u2[9] = u9[UNNAMED_2819735045000[u3]];
                            local v245;

                            if u2[2] then
                                v245 = UNNAMED_2819735084312[u3] - 1;
                            else
                                v245 = UNNAMED_2819735082680[u3 + 1] - 1;
                            end;

                            u3 = v245;
                            u3 = u3 + 1;
                        end;
                    elseif v233 >= 58 then
                        if v233 < 61 then
                            if v233 >= 59 then
                                if v233 ~= 60 then
                                    u9[UNNAMED_2819735041784[u3 + 1]] = u2[17];
                                    u2[3] = u2[17][UNNAMED_2819735045000[u3 + 2]];
                                    u9[UNNAMED_2819735079752[u3]] = u2[UNNAMED_2819735086280[u3 + 2]];
                                    u9[UNNAMED_2819735045000[u3 + 1]] = u2[19];
                                    u2[3] = u9[UNNAMED_2819735079752[u3 + 2]][UNNAMED_2819735041784[u3]];
                                    u2[3] = u2[3]();
                                    u9[UNNAMED_2819735045000[u3]] = u2[3];
                                    u3 = UNNAMED_2819735057720[u3 + 1] - 2;
                                    u3 = u3 + 2;
                                end;
                            else
                                u2[5] = u2[11][UNNAMED_2819735041784[u3]];
                                local v246 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                u2[6] = v246[5][v246[4]];
                                u2[8] = not u2[UNNAMED_2819735086280[u3 + 1]];
                                u2[8] = not u2[8];
                                local v247;

                                if u2[8] then
                                    v247 = UNNAMED_2819735084312[u3 + 1] - 1;
                                else
                                    v247 = UNNAMED_2819735057720[u3 + 1] - 1;
                                end;

                                u3 = v247;
                                u3 = u3 + 1;
                            end;
                        elseif v233 >= 63 then
                            if v233 == 64 then
                                local v248 = 1;
                                u2[5] = u2[9][UNNAMED_2819735045000[u3]];
                                u2[5] = -u2[5];
                                local v249 = UNNAMED_2819735086280[u3 + 1];
                                local v250 = u2[5];
                                u2[v249 + 1] = v250;
                                u2[v249] = v250[UNNAMED_2819735045000[u3 + 2]];
                                local v251 = 2;
                                u2[5] = u2[6];
                                u2[8] = u2[10][UNNAMED_2819735041784[u3 + 1]];
                                u2[UNNAMED_2819735086280[u3 + 2]] = u2[5];
                                local v252 = UNNAMED_2819735084312[u3];
                                local _ = v252 + v248 - 1;
                                local _ = v252 + v251;
                                u8(u10(u2[v252](u7(u2, v252 + 1, v252 + v251))), 1, v248, v252, u2);

                                if u2[6] >= UNNAMED_2819735079752[u3] then
                                    u3 = UNNAMED_2819735057720[u3 + 1] - 2;
                                end;

                                u3 = u3 + 2;
                            else
                                local v253 = u2[7];
                                u2[9] = v253;
                                u2[8] = v253[UNNAMED_2819735079752[u3]];
                                u2[6] = u2[8];
                                local v254 = 8;
                                u2[10] = UNNAMED_2819735079752[u3 + 1];
                                u2[8] = u2[6];
                                local v255 = UNNAMED_2819735086280[u3 + 1];
                                local _ = v254 + v255;
                                u8(u10(u2[v254](u7(u2, 9, v254 + v255))), 1, 1, v254, u2);
                                local v256;

                                if u2[8] then
                                    v256 = UNNAMED_2819735084312[u3] - 1;
                                else
                                    v256 = UNNAMED_2819735084312[u3 + 1] - 1;
                                end;

                                u3 = v256;
                                u3 = u3 + 1;
                            end;
                        elseif v233 == 62 then
                            local v257 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 3]];
                            u2[10] = v257[5][v257[4]];
                            local v258 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 3]];
                            u2[9] = v258[5][v258[4]][UNNAMED_2819735041784[u3 + 2]];
                            local v259 = u2[UNNAMED_2819735086280[u3 + 2]];
                            u2[6] = v259;
                            u2[5] = v259[UNNAMED_2819735045000[u3 + 1]];
                            local v260 = 5;
                            u2[UNNAMED_2819735086280[u3 + 1]] = u2[5];
                            u2[8] = u2[8] * UNNAMED_2819735079752[u3];
                            u2[UNNAMED_2819735086280[u3 + 3]] = u2[9];
                            local v261 = UNNAMED_2819735082680[u3 + 3];
                            local v262 = UNNAMED_2819735082680[u3];
                            local _ = v260 + v262 - 1;
                            local _ = v260 + v261;
                            u8(u10(u2[v260](u7(u2, 6, v260 + v261))), 1, v262, v260, u2);
                            u2[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735041784[u3]] = u2[5];
                            u3 = UNNAMED_2819735057720[u3 + 1] - 3;
                            u3 = u3 + 3;
                        else
                            u2[6] = u2[7][UNNAMED_2819735041784[u3]];
                            u2[6] = u2[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735045000[u3]];

                            if u2[6] ~= UNNAMED_2819735045000[u3 + 1] then
                                u3 = UNNAMED_2819735057720[u3 + 1] - 1;
                            end;

                            u3 = u3 + 1;
                        end;
                    elseif v233 < 55 then
                        if v233 >= 53 then
                            if v233 == 54 then
                                u2[9] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                                u2[5] = u2[UNNAMED_2819735082680[u3]][UNNAMED_2819735041784[u3]];
                            else
                                u2[11] = u9[UNNAMED_2819735041784[u3]];
                                u3 = UNNAMED_2819735057720[u3];
                            end;
                        else
                            u3 = UNNAMED_2819735082680[u3];
                        end;
                    elseif v233 >= 56 then
                        if v233 ~= 57 then
                            u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735079752[u3];
                            u1 = u2[UNNAMED_2819735084312[u3]];
                            local v263 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 1]];
                            v263[5][v263[4]] = u2[15];

                            return false, false;
                        end;

                        u2[UNNAMED_2819735057720[u3]] = u2[19][UNNAMED_2819735045000[u3]];

                        if u2[2] <= 1 then
                            u3 = UNNAMED_2819735084312[u3];
                        end;
                    else
                        u2[9] = u9[UNNAMED_2819735041784[u3]][UNNAMED_2819735045000[u3 + 1]];
                        u2[6] = u2[5][UNNAMED_2819735041784[u3 + 1]];
                        u2[8] = u2[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735079752[u3]];
                        u2[7] = UNNAMED_2819735057720[u3 + 1];
                        u2[5] = u2[9];
                        u3 = UNNAMED_2819735082680[u3] - 1;
                        u3 = u3 + 1;
                    end;
                elseif v233 < 91 then
                    if v233 < 84 then
                        if v233 >= 81 then
                            if v233 < 82 then
                                local v264 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                                v264[5][v264[4]] = u2[15];

                                return false, false;
                            end;

                            if v233 == 83 then
                                u2[4] = u9[UNNAMED_2819735045000[u3]];
                                u2[4]();
                                u9[UNNAMED_2819735079752[u3 + 1]] = UNNAMED_2819735079752[u3];
                                u3 = UNNAMED_2819735082680[u3 + 1] - 1;
                                u3 = u3 + 1;
                            else
                                local v265 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                                u2[6] = v265[5][v265[4]];
                                local v266;

                                if u2[UNNAMED_2819735086280[u3 + 1]] then
                                    v266 = UNNAMED_2819735057720[u3 + 1] - 1;
                                else
                                    v266 = UNNAMED_2819735082680[u3] - 1;
                                end;

                                u3 = v266;
                                u3 = u3 + 1;
                            end;
                        elseif v233 < 79 then
                            local v267 = u11(u1, u17(u16(u1, 14), 262143), (u17(u16(u1, 28), 15)));
                            local v268 = UNNAMED_2819735057720[u3];
                            local v269 = UNNAMED_2819735084312[u3];
                            local v270 = UNNAMED_2819735082680[u3];
                            local v271 = v268 < 2097152 and 7 or 14;
                            local v272 = u17(v268, u18(1, v271) - 1);
                            local v273 = u16(v268, v271);
                            UNNAMED_2819735057720[u3] = u11(v272, 48, (u17(u16(v267, 14), 127)));
                            UNNAMED_2819735084312[u3] = u11(v269, 71, (u17(v267, 127)));
                            UNNAMED_2819735082680[u3] = u11(v270, 78, (u17(u16(v267, 7), 127)));
                            UNNAMED_2819735086280[u3] = u11(v273, 15, (u17(u16(v267, 21), 127)));
                            u3 = u3 - 1;
                        elseif v233 == 80 then
                            u2[2] = u9[UNNAMED_2819735079752[u3]];
                            local v274;

                            if u2[2] then
                                v274 = UNNAMED_2819735084312[u3];
                            else
                                v274 = UNNAMED_2819735082680[u3];
                            end;

                            u3 = v274;
                        else
                            u2[2] = u9[UNNAMED_2819735041784[u3]];
                            u2[2]();
                            u2[10] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 2]][UNNAMED_2819735045000[u3 + 3]];
                            u2[2] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 2]];
                            local v275 = 4;
                            local v276 = u2[8];
                            u2[4] = u2[UNNAMED_2819735086280[u3 + 2]];
                            u2[5] = v276;
                            u2[6] = u2[UNNAMED_2819735086280[u3 + 1]];
                            u8(u10(u2[v275](u7(u2, 5, 6))), 1, 1, v275, u2);
                            local v277 = UNNAMED_2819735086280[u3 + 3];
                            local v278 = UNNAMED_2819735082680[u3];
                            u2[v277] = UNNAMED_2819735041784[u3 + 1];
                            u2[v277 + 1] = v278;
                            u2[3] = u2[10];
                            local v279 = UNNAMED_2819735082680[u3 + 2];
                            local v280 = UNNAMED_2819735084312[u3 + 3];
                            local v281 = UNNAMED_2819735057720[u3 + 3];
                            local _ = v279 + v281 - 1;
                            local _ = v279 + v280;
                            u8(u10(u2[v279](u7(u2, v279 + 1, v279 + v280))), 1, v281, v279, u2);
                            u2[10] = u2[UNNAMED_2819735082680[u3 + 1]];
                            u3 = UNNAMED_2819735057720[u3 + 1] - 3;
                            u3 = u3 + 3;
                        end;
                    elseif v233 >= 87 then
                        if v233 >= 89 then
                            if v233 == 90 then
                                local v282 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                                u2[6] = v282[5][v282[4]];
                                local v283;

                                if u2[6] then
                                    v283 = UNNAMED_2819735084312[u3];
                                else
                                    v283 = UNNAMED_2819735057720[u3];
                                end;

                                u3 = v283;
                            else
                                u2[9] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                local v284 = u2[9];
                                u2[7] = v284;
                                u2[6] = v284[UNNAMED_2819735079752[u3 + 1]];
                                local v285 = 6;
                                u2[9] = u2[UNNAMED_2819735086280[u3 + 2]];
                                u2[8] = UNNAMED_2819735079752[u3];
                                u2[6] = u2[UNNAMED_2819735086280[u3 + 1]];
                                local v286 = UNNAMED_2819735084312[u3 + 2];
                                local v287 = UNNAMED_2819735082680[u3 + 2];
                                local _ = v285 + v287 - 1;
                                local _ = v285 + v286;
                                u8(u10(u2[v285](u7(u2, 7, v285 + v286))), 1, v287, v285, u2);
                                local v288;

                                if u2[UNNAMED_2819735057720[u3 + 2]] then
                                    v288 = UNNAMED_2819735082680[u3 + 1] - 2;
                                else
                                    v288 = UNNAMED_2819735084312[u3] - 2;
                                end;

                                u3 = v288;
                                u3 = u3 + 2;
                            end;
                        elseif v233 == 88 then
                            u2[3] = u9[UNNAMED_2819735045000[u3]];
                            u2[3]();
                            u2[3] = u9[UNNAMED_2819735045000[u3 + 1]];
                            local v289 = UNNAMED_2819735086280[u3 + 1];
                            local v290, v291 = u2[3]();
                            u2[v289] = v290;
                            u2[9] = v291;
                            local v292;

                            if u2[2] then
                                v292 = UNNAMED_2819735057720[u3 + 1] - 1;
                            else
                                v292 = UNNAMED_2819735084312[u3 + 1] - 1;
                            end;

                            u3 = v292;
                            u3 = u3 + 1;
                        else
                            u2[3] = u9[UNNAMED_2819735041784[u3]];
                            local v293;

                            if u2[UNNAMED_2819735086280[u3 + 1]] then
                                v293 = UNNAMED_2819735084312[u3 + 1] - 1;
                            else
                                v293 = UNNAMED_2819735082680[u3 + 1] - 1;
                            end;

                            u3 = v293;
                            u3 = u3 + 1;
                        end;
                    elseif v233 < 85 then
                        u2[3] = u9[UNNAMED_2819735045000[u3]][UNNAMED_2819735079752[u3]];
                        u2[3] = u2[3]();
                        u2[4] = u9[UNNAMED_2819735041784[u3 + 1]];
                        u2[3] = u2[3] - u2[4];
                        u2[4] = u1;
                        u2[UNNAMED_2819735086280[u3 + 1]] = u2[4] == UNNAMED_2819735082680[u3 + 1];
                        local v294;

                        if u2[4] then
                            v294 = UNNAMED_2819735057720[u3 + 1] - 1;
                        else
                            v294 = UNNAMED_2819735084312[u3] - 1;
                        end;

                        u3 = v294;
                        u3 = u3 + 1;
                    elseif v233 == 86 then
                        u2[2] = u9[UNNAMED_2819735041784[u3]][UNNAMED_2819735045000[u3]];
                        local v295;

                        if u2[2] then
                            v295 = UNNAMED_2819735057720[u3] - 1;
                        else
                            v295 = UNNAMED_2819735057720[u3 + 1] - 1;
                        end;

                        u3 = v295;
                        u3 = u3 + 1;
                    else
                        u2[3] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                        u2[17] = u2[3]();
                        u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735041784[u3 + 1];
                        u1 = u2[3];
                        u2[3] = UNNAMED_2819735041784[u3];
                        u1 = u2[UNNAMED_2819735082680[u3]];
                        local v296;

                        if u2[17] then
                            v296 = UNNAMED_2819735082680[u3 + 1] - 1;
                        else
                            v296 = UNNAMED_2819735057720[u3 + 1] - 1;
                        end;

                        u3 = v296;
                        u3 = u3 + 1;
                    end;
                elseif v233 >= 98 then
                    if v233 >= 101 then
                        if v233 < 103 then
                            if v233 == 102 then
                                local v297 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                                v297[5][v297[4]] = u2[UNNAMED_2819735057720[u3]];

                                return false, false;
                            end;

                            u2[11] = u2[3];
                            u3 = UNNAMED_2819735057720[u3];
                        elseif v233 == 104 then
                            u9[UNNAMED_2819735041784[u3]][UNNAMED_2819735079752[u3]] = UNNAMED_2819735079752[u3 + 1];
                            local v298;

                            if u2[14] then
                                v298 = UNNAMED_2819735084312[u3 + 1] - 1;
                            else
                                v298 = UNNAMED_2819735082680[u3] - 1;
                            end;

                            u3 = v298;
                            u3 = u3 + 1;
                        else
                            local v299 = UNNAMED_2819735057720[u3] + 1;
                            local v300 = UNNAMED_2819735082680[u3];

                            for i = 1, UNNAMED_2819735084312[u3] do
                                local v301 = u17(u11(v300, (u18(v300, 13))), 536870911);
                                local v302 = u11(v301, (u16(v301, 13)));
                                v300 = u17(u11(v302, (u18(v302, 14))), 536870911);
                                UNNAMED_2819735084312[v299] = u11(UNNAMED_2819735084312[v299], (u17(u16(v300, 0), 127)));
                                UNNAMED_2819735082680[v299] = u11(UNNAMED_2819735082680[v299], (u17(u16(v300, 7), 127)));
                                UNNAMED_2819735057720[v299] = u11(UNNAMED_2819735057720[v299], (u17(u16(v300, 14), 127)));
                                UNNAMED_2819735086280[v299] = u11(UNNAMED_2819735086280[v299], (u17(u16(v300, 21), 127)));
                                v299 = v299 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735086280[u3] = 60;
                        end;
                    elseif v233 < 99 then
                        u2[3] = u9[UNNAMED_2819735045000[u3 + 2]];
                        u2[4] = UNNAMED_2819735041784[u3 + 1];
                        u1 = u2[4];
                        u2[3]();
                        u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735079752[u3 + 1];
                        u1 = u2[3];
                        local v303 = UNNAMED_2819735086280[u3 + 2];
                        local v304 = u2[21];
                        u2[v303] = u2[21];
                        u2[v303 + 1] = v304;
                        local v305;

                        if u2[UNNAMED_2819735082680[u3]] then
                            v305 = UNNAMED_2819735057720[u3] - 2;
                        else
                            v305 = UNNAMED_2819735082680[u3 + 1] - 2;
                        end;

                        u3 = v305;
                        u3 = u3 + 2;
                    elseif v233 == 100 then
                        u2[2] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735041784[u3 + 8]];
                        u2[2] = u2[2](UNNAMED_2819735079752[u3 + 5]);
                        u9[UNNAMED_2819735045000[u3 + 7]] = u2[2];
                        u9[UNNAMED_2819735079752[u3]][UNNAMED_2819735045000[u3]] = UNNAMED_2819735041784[u3 + 5];
                        u2[2] = u9[UNNAMED_2819735045000[u3 + 8]];
                        u2[UNNAMED_2819735086280[u3 + 7]] = u9[UNNAMED_2819735079752[u3 + 1]][UNNAMED_2819735045000[u3 + 3]];
                        u2[4] = u2[4][UNNAMED_2819735041784[u3 + 7]];
                        u2[UNNAMED_2819735086280[u3 + 8]][UNNAMED_2819735079752[u3 + 6]] = u2[4];
                        u9[UNNAMED_2819735079752[u3 + 7]][UNNAMED_2819735041784[u3 + 2]] = UNNAMED_2819735079752[u3 + 4];
                        u9[UNNAMED_2819735041784[u3 + 6]][UNNAMED_2819735045000[u3 + 5]] = UNNAMED_2819735041784[u3 + 9];
                        u9[UNNAMED_2819735041784[u3 + 3]][UNNAMED_2819735045000[u3 + 4]] = UNNAMED_2819735045000[u3 + 1];
                        u9[UNNAMED_2819735079752[u3 + 2]][UNNAMED_2819735045000[u3 + 9]] = UNNAMED_2819735079752[u3 + 3];
                        u2[2] = u9[UNNAMED_2819735045000[u3 + 6]];
                        u2[4] = u9[UNNAMED_2819735079752[u3 + 8]][UNNAMED_2819735045000[u3 + 2]];
                        u3 = UNNAMED_2819735084312[u3 + 4] - 9;
                        u3 = u3 + 9;
                    elseif u2[UNNAMED_2819735084312[u3]] ~= u2[UNNAMED_2819735082680[u3]] then
                        u3 = UNNAMED_2819735057720[u3];
                    end;
                elseif v233 < 94 then
                    if v233 < 92 then
                        u9[UNNAMED_2819735079752[u3]] = UNNAMED_2819735045000[u3];

                        return false, false;
                    end;

                    if v233 == 93 then
                        local v306 = UNNAMED_2819735084312[u3] + 1;
                        local v307 = u11(UNNAMED_2819735082680[u3], (u17(u11(u1, (u17(u16(u1, 29), 7))), 536870911)));

                        for i = 1, UNNAMED_2819735057720[u3] do
                            local v308 = u17(u11(v307, (u18(v307, 13))), 536870911);
                            local v309 = u11(v308, (u16(v308, 13)));
                            v307 = u17(u11(v309, (u18(v309, 14))), 536870911);
                            UNNAMED_2819735084312[v306] = u11(UNNAMED_2819735084312[v306], (u17(u16(v307, 0), 127)));
                            UNNAMED_2819735082680[v306] = u11(UNNAMED_2819735082680[v306], (u17(u16(v307, 7), 127)));
                            UNNAMED_2819735057720[v306] = u11(UNNAMED_2819735057720[v306], (u17(u16(v307, 14), 127)));
                            UNNAMED_2819735086280[v306] = u11(UNNAMED_2819735086280[v306], (u17(u16(v307, 21), 127)));
                            v306 = v306 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735086280[u3] = 60;
                    else
                        u2[2] = u9[UNNAMED_2819735045000[u3]];
                        local v310;

                        if u2[2] then
                            v310 = UNNAMED_2819735084312[u3];
                        else
                            v310 = UNNAMED_2819735057720[u3];
                        end;

                        u3 = v310;
                    end;
                elseif v233 < 96 then
                    if v233 == 95 then
                        local v311 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                        u2[UNNAMED_2819735086280[u3 + 1]] = v311[5][v311[4]];
                        local v312;

                        if u2[UNNAMED_2819735084312[u3 + 1]] then
                            v312 = UNNAMED_2819735082680[u3] - 1;
                        else
                            v312 = UNNAMED_2819735084312[u3] - 1;
                        end;

                        u3 = v312;
                        u3 = u3 + 1;
                    else
                        u2[3] = u9[UNNAMED_2819735079752[u3]];
                        u2[UNNAMED_2819735086280[u3 + 1]] = u2[3](u2[17]);
                        local v313;

                        if u2[UNNAMED_2819735057720[u3 + 1]] then
                            v313 = UNNAMED_2819735082680[u3 + 1] - 1;
                        else
                            v313 = UNNAMED_2819735082680[u3] - 1;
                        end;

                        u3 = v313;
                        u3 = u3 + 1;
                    end;
                elseif v233 == 97 then
                    u2[UNNAMED_2819735082680[u3]] = u2[9];
                    u3 = UNNAMED_2819735057720[u3];
                else
                    local v314 = UNNAMED_2819735082680[u3];
                    local v315 = UNNAMED_2819735084312[u3];
                    local v316 = UNNAMED_2819735057720[u3];
                    local v317 = u11(u1, u17(u16(u1, 14), 262143), (u17(u16(u1, 28), 15)));
                    local v318 = v316 < 16384 and 7 or (v316 < 2097152 and 14 or 21);
                    local v319 = u16(v316, v318);
                    local v320 = u17(v316, u18(1, v318) - 1);
                    UNNAMED_2819735084312[u3] = u11(v315, 46, (u17(v317, 127)));
                    UNNAMED_2819735057720[u3] = u11(v320, 119, (u17(u16(v317, 14), 127)));
                    UNNAMED_2819735086280[u3] = u11(v319, 99, (u17(u16(v317, 21), 127)));
                    UNNAMED_2819735082680[u3] = u11(v314, 95, (u17(u16(v317, 7), 127)));
                    u3 = u3 - 1;
                end;
            elseif v233 >= 26 then
                if v233 < 39 then
                    if v233 >= 32 then
                        if v233 >= 35 then
                            if v233 < 37 then
                                if v233 == 36 then
                                    u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 1]];
                                    local v321 = u2[6];
                                    u2[5] = v321;
                                    u2[4] = v321[UNNAMED_2819735041784[u3]];
                                    u2[UNNAMED_2819735082680[u3 + 1]](u2[UNNAMED_2819735082680[u3]], UNNAMED_2819735041784[u3 + 1]);
                                    u2[2] = u9[UNNAMED_2819735079752[u3]];
                                    u2[2]();

                                    return false, false;
                                end;

                                u2[2] = u9[UNNAMED_2819735079752[u3 + 1]];
                                u2[4] = u9[UNNAMED_2819735041784[u3 + 2]][UNNAMED_2819735045000[u3 + 1]];
                                u2[UNNAMED_2819735086280[u3 + 2]] = u9[UNNAMED_2819735045000[u3 + 2]];
                                u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735041784[u3 + 1];
                                u1 = u2[UNNAMED_2819735057720[u3]];
                                u2[4] = u2[4](u2[5]);
                                u2[2][UNNAMED_2819735045000[u3]] = u2[4];
                                u2[2] = UNNAMED_2819735041784[u3];
                                u1 = u2[2];
                                u3 = UNNAMED_2819735057720[u3 + 2] - 2;
                                u3 = u3 + 2;
                            elseif v233 == 38 then
                                u2[UNNAMED_2819735086280[u3 + 1]] = u9[UNNAMED_2819735041784[u3 + 1]];
                                local v322;

                                if u2[4] then
                                    v322 = UNNAMED_2819735057720[u3 + 1] - 1;
                                else
                                    v322 = UNNAMED_2819735084312[u3] - 1;
                                end;

                                u3 = v322;
                                u3 = u3 + 1;
                            else
                                u3 = UNNAMED_2819735057720[u3];
                            end;
                        elseif v233 >= 33 then
                            if v233 == 34 then
                                u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                                u2[UNNAMED_2819735057720[u3 + 1]] = u9[UNNAMED_2819735045000[u3]][u2[UNNAMED_2819735057720[u3]]];
                                u2[7] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];

                                if u2[6] ~= u2[7] then
                                    u3 = UNNAMED_2819735082680[u3 + 1] - 1;
                                end;

                                u3 = u3 + 1;
                            else
                                u2[3] = u2[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735079752[u3 + 1]];
                                local v323;

                                if u2[3] then
                                    v323 = UNNAMED_2819735082680[u3] - 1;
                                else
                                    v323 = UNNAMED_2819735084312[u3] - 1;
                                end;

                                u3 = v323;
                                u3 = u3 + 1;
                            end;
                        else
                            u2[3] = u2[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735079752[u3]];
                            u2[4] = u9[UNNAMED_2819735041784[u3]];

                            if u2[4] >= u2[3] then
                                u3 = UNNAMED_2819735082680[u3] - 1;
                            end;

                            u3 = u3 + 1;
                        end;
                    elseif v233 >= 29 then
                        if v233 >= 30 then
                            if v233 == 31 then
                                local v324;

                                if u2[UNNAMED_2819735084312[u3]] then
                                    v324 = UNNAMED_2819735057720[u3];
                                else
                                    v324 = UNNAMED_2819735082680[u3];
                                end;

                                u3 = v324;
                            else
                                u2[2] = u9[UNNAMED_2819735079752[u3]];
                                u2[3] = not u2[UNNAMED_2819735082680[u3]];
                            end;
                        else
                            u2[UNNAMED_2819735086280[u3 + 1]] = u9[UNNAMED_2819735079752[u3 + 1]];

                            if u2[3] ~= u2[UNNAMED_2819735082680[u3 + 1]] then
                                u3 = UNNAMED_2819735082680[u3] - 1;
                            end;

                            u3 = u3 + 1;
                        end;
                    elseif v233 < 27 then
                        u2[2] = u9[UNNAMED_2819735041784[u3 + 1]];
                        u2[4] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 4]][UNNAMED_2819735079752[u3 + 2]];
                        u2[UNNAMED_2819735086280[u3 + 3]] = u2[UNNAMED_2819735086280[u3 + 2]][UNNAMED_2819735045000[u3 + 1]];
                        u2[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735079752[u3]] = u2[4];
                        u2[2] = u9[UNNAMED_2819735079752[u3 + 3]];
                        u2[UNNAMED_2819735086280[u3 + 4]] = u2[2](u2[17]);
                        u2[4] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 4]][UNNAMED_2819735041784[u3 + 3]];
                        u2[5] = -u2[16];
                        u2[5] = u2[UNNAMED_2819735057720[u3 + 1]] * 16;
                        u2[4] = u2[4](u2[UNNAMED_2819735082680[u3 + 3]]);
                        u2[12] = 1 - u2[UNNAMED_2819735084312[u3 + 2]];
                        u3 = UNNAMED_2819735084312[u3] - 4;
                        u3 = u3 + 4;
                    else
                        if v233 == 28 then
                            local v325 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                            v325[5][v325[4]] = u2[15];
                            u2[6] = UNNAMED_2819735045000[u3];
                            u1 = u2[6];

                            return false, false;
                        end;

                        if u2[UNNAMED_2819735082680[u3]] >= UNNAMED_2819735057720[u3] then
                            u3 = UNNAMED_2819735084312[u3];
                        end;
                    end;
                elseif v233 < 45 then
                    if v233 < 42 then
                        if v233 < 40 then
                            local v326 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                            u2[5] = v326[5][v326[4]][UNNAMED_2819735041784[u3]];
                            local v327 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                            v327[5][v327[4]] = u2[5];

                            return false, false;
                        end;

                        if v233 == 41 then
                            u2[4] = u2[4][UNNAMED_2819735041784[u3 + 3]];
                            u2[2][UNNAMED_2819735041784[u3 + 4]] = u2[4];
                            u9[UNNAMED_2819735079752[u3 + 1]][UNNAMED_2819735079752[u3]] = UNNAMED_2819735045000[u3];
                            u2[UNNAMED_2819735086280[u3 + 1]] = u9[UNNAMED_2819735045000[u3 + 1]];
                            u2[4] = UNNAMED_2819735045000[u3 + 2] * UNNAMED_2819735045000[u3 + 3];
                            u2[2][UNNAMED_2819735079752[u3 + 4]] = u2[4];
                            u2[4] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 2]];
                            u9[UNNAMED_2819735041784[u3]][UNNAMED_2819735041784[u3 + 2]] = u2[4];
                            u3 = UNNAMED_2819735057720[u3 + 3] - 4;
                            u3 = u3 + 4;
                        else
                            u9[UNNAMED_2819735041784[u3 + 1]][UNNAMED_2819735045000[u3]] = UNNAMED_2819735041784[u3];
                            local v328;

                            if u2[14] then
                                v328 = UNNAMED_2819735057720[u3 + 1] - 1;
                            else
                                v328 = UNNAMED_2819735057720[u3] - 1;
                            end;

                            u3 = v328;
                            u3 = u3 + 1;
                        end;
                    else
                        if v233 < 43 then
                            local v329 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                            u2[8] = v329[5][v329[4]];
                            local v330 = u2[8];
                            u2[6] = v330;
                            u2[5] = v330[UNNAMED_2819735041784[u3]];
                            u2[5](u2[6]);

                            return false, false;
                        end;

                        if v233 == 44 then
                            u9[UNNAMED_2819735041784[u3 + 1]] = UNNAMED_2819735045000[u3 + 1];
                            u2[4] = u9[UNNAMED_2819735045000[u3]];
                            local v331;

                            if u2[UNNAMED_2819735086280[u3 + 1]] then
                                v331 = UNNAMED_2819735084312[u3] - 1;
                            else
                                v331 = UNNAMED_2819735057720[u3 + 1] - 1;
                            end;

                            u3 = v331;
                            u3 = u3 + 1;
                        else
                            local v332 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 1]];
                            u2[5] = v332[5][v332[4]][UNNAMED_2819735041784[u3 + 1]];
                            local v333;

                            if u2[UNNAMED_2819735086280[u3 + 1]] then
                                v333 = UNNAMED_2819735082680[u3 + 1] - 1;
                            else
                                v333 = UNNAMED_2819735082680[u3] - 1;
                            end;

                            u3 = v333;
                            u3 = u3 + 1;
                        end;
                    end;
                elseif v233 >= 48 then
                    if v233 >= 50 then
                        if v233 == 51 then
                            u2[3] = u2[UNNAMED_2819735086280[u3 + 1]] + u2[UNNAMED_2819735057720[u3 + 1]];
                            u9[UNNAMED_2819735045000[u3]] = u2[3];
                            u2[3] = u9[UNNAMED_2819735041784[u3]];

                            if u2[3] >= UNNAMED_2819735041784[u3 + 1] then
                                u3 = UNNAMED_2819735082680[u3 + 1] - 1;
                            end;

                            u3 = u3 + 1;
                        else
                            u2[2] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 2]][UNNAMED_2819735045000[u3 + 2]];
                            u2[2] = u2[2][UNNAMED_2819735045000[u3]];
                            u2[4] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735045000[u3 + 1]];
                            u2[14] = u2[4][UNNAMED_2819735079752[u3]];
                            local v334;

                            if u2[2] then
                                v334 = UNNAMED_2819735084312[u3] - 2;
                            else
                                v334 = UNNAMED_2819735084312[u3 + 2] - 2;
                            end;

                            u3 = v334;
                            u3 = u3 + 2;
                        end;
                    elseif v233 == 49 then
                        u2[2] = u9[UNNAMED_2819735079752[u3]];
                        local v335;

                        if u2[2] then
                            v335 = UNNAMED_2819735082680[u3];
                        else
                            v335 = UNNAMED_2819735084312[u3];
                        end;

                        u3 = v335;
                    else
                        u2[UNNAMED_2819735086280[u3 + 4]] = u2[9](u2[10]);
                        u2[UNNAMED_2819735086280[u3 + 1]][UNNAMED_2819735041784[u3 + 4]] = u2[UNNAMED_2819735086280[u3 + 2]];
                        u9[UNNAMED_2819735079752[u3 + 4]][UNNAMED_2819735045000[u3 + 4]] = u2[UNNAMED_2819735086280[u3 + 3]];
                        u9[UNNAMED_2819735079752[u3 + 2]][UNNAMED_2819735041784[u3 + 2]] = u2[3];
                        u2[2] = u9[UNNAMED_2819735045000[u3 + 3]];
                        u2[3] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                        u2[UNNAMED_2819735086280[u3 + 5]](u2[UNNAMED_2819735082680[u3 + 2]], u2[4]);
                        u2[2] = u9[UNNAMED_2819735041784[u3 + 5]];
                        u2[UNNAMED_2819735084312[u3]] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 3]];
                        u2[3](u2[2], u2[5]);
                        u2[UNNAMED_2819735057720[u3 + 5]] = UNNAMED_2819735045000[u3 + 5];
                        u1 = u2[UNNAMED_2819735057720[u3 + 1]];
                        u2[UNNAMED_2819735057720[u3]] = UNNAMED_2819735041784[u3 + 3];
                        u1 = u2[2];
                        local v336;

                        if u2[14] then
                            v336 = UNNAMED_2819735082680[u3] - 5;
                        else
                            v336 = UNNAMED_2819735082680[u3 + 1] - 5;
                        end;

                        u3 = v336;
                        u3 = u3 + 5;
                    end;
                elseif v233 >= 46 then
                    if v233 == 47 then
                        u2[6] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                        u2[6](UNNAMED_2819735079752[u3]);

                        return false, false;
                    end;

                    local v337 = 5;
                    u8(u10(u2[v337](u7(u2, 6, 8))), 1, 1, v337, u2);
                    u2[9] = u2[5];
                    u2[5] = u2[9][UNNAMED_2819735079752[u3]];
                    u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]][UNNAMED_2819735041784[u3 + 1]];

                    if u2[6] >= u2[5] then
                        u3 = UNNAMED_2819735084312[u3] - 1;
                    end;

                    u3 = u3 + 1;
                else
                    local v338 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                    u2[10] = v338[5][v338[4]];
                    local v339 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 1]];
                    u2[13] = v339[5][v339[4]];
                    local v340 = u2[UNNAMED_2819735086280[u3 + 1]];
                    u2[6] = v340;
                    u2[5] = v340[UNNAMED_2819735079752[u3 + 1]];
                    local v341 = 5;
                    u2[9] = u2[5];
                    u2[5] = u2[9];
                    u8(u10(u2[v341](u7(u2, 6, 8))), 1, 1, v341, u2);
                    u2[UNNAMED_2819735084312[u3 + 1]][UNNAMED_2819735041784[u3]] = u2[5];
                    u3 = UNNAMED_2819735057720[u3] - 1;
                    u3 = u3 + 1;
                end;
            elseif v233 >= 13 then
                if v233 >= 19 then
                    if v233 >= 22 then
                        if v233 < 24 then
                            if v233 == 23 then
                                u2[3] = 0;
                                u3 = UNNAMED_2819735082680[u3];
                            else
                                local v342 = UNNAMED_2819735082680[u3];
                                local v343 = UNNAMED_2819735084312[u3];
                                local v344 = UNNAMED_2819735027864[5];
                                local v345 = u11(v344[v342], 109162203);
                                v344[v342] = v345;
                                local v346 = UNNAMED_2819735027864[4];
                                local v347 = v345 + 1;
                                local v348 = u12(v346, v347);
                                local v349;

                                if v348 < 128 then
                                    v349 = v347 + 1;
                                else
                                    local v350 = u12(v346, v347 + 1);

                                    if v350 < 128 then
                                        v348 = v348 - 128 + v350 * 128;
                                        v349 = v347 + 2;
                                    else
                                        local v351 = u12(v346, v347 + 2);

                                        if v351 < 128 then
                                            v348 = v348 - 128 + (v350 - 128) * 16384 + v351 * 128;
                                            v349 = v347 + 3;
                                        else
                                            local v352 = u12(v346, v347 + 3);
                                            v348 = (v348 - 128) * 16384 + (v350 - 128) * 128 + (v351 - 128) + v352 % 128 * 2097152 + (v352 - v352 % 128) * 2097152;
                                            v349 = v347 + 4;
                                        end;
                                    end;
                                end;

                                local v353 = v343 * 16843009;
                                local v354 = v349 + v348;
                                local v355 = v354 - v348 % 4;

                                for i = v349, v355 - 1, 4 do
                                    u13(v346, i, (u11(u14(v346, i), v353)));
                                    local _ = i;
                                end;

                                for i = v355, v354 - 1 do
                                    u15(v346, i, (u11(u12(v346, i), v343)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735082680[u3] = 77;
                                UNNAMED_2819735084312[u3] = 118;
                                UNNAMED_2819735057720[u3] = 62;
                                UNNAMED_2819735086280[u3] = 60;
                            end;
                        else
                            if v233 ~= 25 then
                                u2[4] = u9[UNNAMED_2819735041784[u3 + 1]];
                                local v356 = UNNAMED_2819735086280[u3 + 1];
                                local v357 = u2[UNNAMED_2819735084312[u3]];
                                u2[v356 + 1] = v357;
                                u2[v356] = v357[UNNAMED_2819735079752[u3]];
                                u2[2](u2[3]);
                                u9[UNNAMED_2819735045000[u3 + 1]] = u2[20];
                                u9[UNNAMED_2819735045000[u3]] = u2[UNNAMED_2819735057720[u3 + 1]];

                                return false, false;
                            end;

                            u2[17] = u2[21];
                            u3 = UNNAMED_2819735082680[u3];
                        end;
                    elseif v233 >= 20 then
                        if v233 == 21 then
                            local v358 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                            u2[6] = v358[5][v358[4]];
                            local v359;

                            if u2[6] then
                                v359 = UNNAMED_2819735084312[u3];
                            else
                                v359 = UNNAMED_2819735082680[u3];
                            end;

                            u3 = v359;
                        else
                            local v360 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                            u2[5] = v360[5][v360[4]];
                            local v361;

                            if u2[5] then
                                v361 = UNNAMED_2819735082680[u3];
                            else
                                v361 = UNNAMED_2819735084312[u3];
                            end;

                            u3 = v361;
                        end;
                    else
                        u2[UNNAMED_2819735084312[u3]] = u2[9][UNNAMED_2819735045000[u3]];

                        if u2[2] <= 1 then
                            u3 = UNNAMED_2819735057720[u3];
                        end;
                    end;
                elseif v233 < 16 then
                    if v233 >= 14 then
                        if v233 == 15 then
                            local v362 = 1;
                            local v363 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 2]];
                            u2[8] = v363[5][v363[4]];
                            local v364 = u2[8];
                            u2[6] = v364;
                            u2[5] = v364[UNNAMED_2819735079752[u3 + 2]];
                            u2[8] = u2[5];
                            u2[UNNAMED_2819735086280[u3 + 2]] = UNNAMED_2819735041784[u3 + 1];
                            u2[UNNAMED_2819735086280[u3 + 1]] = u2[8];
                            local v365 = UNNAMED_2819735057720[u3];
                            local v366 = UNNAMED_2819735084312[u3];
                            local _ = v365 + v362 - 1;
                            local _ = v365 + v366;
                            u8(u10(u2[v365](u7(u2, v365 + 1, v365 + v366))), 1, v362, v365, u2);
                            local v367;

                            if u2[5] then
                                v367 = UNNAMED_2819735084312[u3 + 2] - 2;
                            else
                                v367 = UNNAMED_2819735082680[u3] - 2;
                            end;

                            u3 = v367;
                            u3 = u3 + 2;
                        else
                            local v368 = 1;
                            local v369 = 3;
                            u2[9] = u2[UNNAMED_2819735086280[u3 + 1]];
                            local v370 = UNNAMED_2819735057720[u3 + 1];
                            local _ = v370 + v368 - 1;
                            local _ = v370 + v369;
                            u8(u10(u2[v370](u7(u2, v370 + 1, v370 + v369))), 1, v368, v370, u2);
                            local v371;

                            if u2[9] then
                                v371 = UNNAMED_2819735082680[u3] - 1;
                            else
                                v371 = UNNAMED_2819735082680[u3 + 1] - 1;
                            end;

                            u3 = v371;
                            u3 = u3 + 1;
                        end;
                    else
                        u2[11] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 3]];
                        u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735079752[u3 + 1];
                        local v372 = u2[12];
                        u2[2] = u2[UNNAMED_2819735086280[u3 + 2]];
                        u2[3] = v372;
                        local v373 = 2;
                        local v374 = u2[8];
                        u2[4] = u2[9];
                        u2[5] = v374;
                        u2[6] = u2[10];
                        u8(u10(u2[v373](u7(u2, 3, 6))), 1, 4, v373, u2);
                        u2[6] = u9[UNNAMED_2819735041784[u3 + 2]];
                        u2[9] = u9[UNNAMED_2819735041784[u3 + 1]][UNNAMED_2819735045000[u3 + 1]];
                        u2[UNNAMED_2819735086280[u3 + 3]] = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 3]][UNNAMED_2819735041784[u3]];
                        u2[UNNAMED_2819735057720[u3]] = u2[UNNAMED_2819735082680[u3]][UNNAMED_2819735079752[u3 + 2]];
                        u3 = UNNAMED_2819735082680[u3 + 2] - 3;
                        u3 = u3 + 3;
                    end;
                elseif v233 < 17 then
                    u2[5] = u9[UNNAMED_2819735041784[u3 + 6]][UNNAMED_2819735045000[u3 + 3]];
                    local v375 = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];
                    u2[8] = v375[5][v375[4]][UNNAMED_2819735045000[u3 + 5]];
                    local v376 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3 + 4]];
                    u2[6] = v376[5][v376[4]];
                    local v377 = 7;
                    u2[UNNAMED_2819735086280[u3 + 1]] = UNNAMED_2819735079752[u3];
                    u1 = u2[10];
                    u2[UNNAMED_2819735086280[u3 + 6]] = u2[6][UNNAMED_2819735079752[u3 + 3]];
                    u2[7] = u2[UNNAMED_2819735086280[u3 + 4]][UNNAMED_2819735079752[u3 + 1]];
                    u2[UNNAMED_2819735086280[u3 + 3]] = u2[UNNAMED_2819735086280[u3 + 2]] + u2[UNNAMED_2819735086280[u3 + 5]];
                    u2[7] = u2[5];
                    local v378 = UNNAMED_2819735084312[u3 + 2];
                    local _ = v377 + v378;
                    u8(u10(u2[v377](u7(u2, 8, v377 + v378))), 1, 1, v377, u2);
                    u2[UNNAMED_2819735084312[u3 + 3]] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 5]][UNNAMED_2819735045000[u3 + 1]];
                    u2[9] = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 6]][UNNAMED_2819735045000[u3 + 2]];
                    u2[10] = UNNAMED_2819735041784[u3 + 1];
                    local v379 = 8;
                    u2[11] = 1;
                    u2[UNNAMED_2819735084312[u3 + 4]] = u2[5];
                    u8(u10(u2[v379](u7(u2, 9, 11))), 1, 1, v379, u2);
                    local v380 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3 + 2]];
                    u2[5] = v380[5][v380[4]];
                    u3 = UNNAMED_2819735082680[u3 + 6] - 6;
                    u3 = u3 + 6;
                elseif v233 == 18 then
                    u2[2] = u9[UNNAMED_2819735045000[u3]];
                    local v381 = u2[2];
                    u2[10] = v381;
                    u2[9] = v381[UNNAMED_2819735041784[u3]];
                    u2[2] = u2[9];
                    local v382;

                    if u2[3] then
                        v382 = UNNAMED_2819735084312[u3 + 1] - 1;
                    else
                        v382 = UNNAMED_2819735057720[u3] - 1;
                    end;

                    u3 = v382;
                    u3 = u3 + 1;
                else
                    u2[5] = u2[11][UNNAMED_2819735045000[u3]];
                    u2[5] = u2[5][UNNAMED_2819735045000[u3 + 1]];

                    if u2[UNNAMED_2819735086280[u3 + 1]] >= UNNAMED_2819735084312[u3 + 1] then
                        u3 = UNNAMED_2819735057720[u3 + 1] - 1;
                    end;

                    u3 = u3 + 1;
                end;
            elseif v233 < 6 then
                if v233 < 3 then
                    if v233 < 1 then
                        local v383 = UNNAMED_2819735088488[UNNAMED_2819735082680[u3]];
                        u2[9] = v383[5][v383[4]];
                        local v384 = u2[9];
                        u2[7] = v384;
                        u2[6] = v384[UNNAMED_2819735041784[u3]];
                        u2[6](u2[7]);

                        return false, false;
                    end;

                    if v233 == 2 then
                        u2[UNNAMED_2819735082680[u3]] = u9[UNNAMED_2819735079752[u3]];
                    else
                        local v385 = 1;
                        local v386 = u2[6];
                        u2[8] = v386;
                        u2[7] = v386[UNNAMED_2819735041784[u3]];
                        local v387 = 2;
                        u2[6] = u2[7];
                        u2[9] = UNNAMED_2819735045000[u3];
                        u2[7] = u2[6];
                        local v388 = UNNAMED_2819735057720[u3];
                        local _ = v388 + v385 - 1;
                        local _ = v388 + v387;
                        u8(u10(u2[v388](u7(u2, v388 + 1, v388 + v387))), 1, v385, v388, u2);
                    end;
                elseif v233 >= 4 then
                    if v233 == 5 then
                        local v389 = UNNAMED_2819735084312[u3];
                        local v390 = u11(UNNAMED_2819735082680[u3], (u17(u11(u1, (u17(u16(u1, 29), 7))), 536870911)));
                        local v391 = UNNAMED_2819735027864[5];
                        local v392 = u11(v391[v389], 109162203);
                        v391[v389] = v392;
                        local v393 = UNNAMED_2819735027864[4];
                        local v394 = v392 + 1;
                        local v395 = u12(v393, v394);
                        local v396;

                        if v395 < 128 then
                            v396 = v394 + 1;
                        else
                            local v397 = u12(v393, v394 + 1);

                            if v397 < 128 then
                                v395 = v395 - 128 + v397 * 128;
                                v396 = v394 + 2;
                            else
                                local v398 = u12(v393, v394 + 2);

                                if v398 < 128 then
                                    v395 = v395 - 128 + (v397 - 128) * 16384 + v398 * 128;
                                    v396 = v394 + 3;
                                else
                                    local v399 = u12(v393, v394 + 3);
                                    v395 = (v395 - 128) * 16384 + (v397 - 128) * 128 + (v398 - 128) + v399 % 128 * 2097152 + (v399 - v399 % 128) * 2097152;
                                    v396 = v394 + 4;
                                end;
                            end;
                        end;

                        local v400 = v390 * 16843009;
                        local v401 = v396 + v395;
                        local v402 = v401 - v395 % 4;

                        for i = v396, v402 - 1, 4 do
                            u13(v393, i, (u11(u14(v393, i), v400)));
                            local _ = i;
                        end;

                        for i = v402, v401 - 1 do
                            u15(v393, i, (u11(u12(v393, i), v390)));
                            local _ = i;
                        end;

                        UNNAMED_2819735084312[u3] = 205;
                        UNNAMED_2819735082680[u3] = 61;
                        UNNAMED_2819735057720[u3] = 33;
                        UNNAMED_2819735086280[u3] = 60;
                    else
                        u8({ ... }, 1, 1, 3, u2);
                        u2[4] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3 + 1]];
                        u2[2] = u9[UNNAMED_2819735079752[u3]][u2[4]];
                        u2[4] = UNNAMED_2819735088488[UNNAMED_2819735084312[u3]];

                        if u2[2] ~= u2[4] then
                            u3 = UNNAMED_2819735057720[u3 + 1] - 1;
                        end;

                        u3 = u3 + 1;
                    end;
                else
                    u2[UNNAMED_2819735086280[u3 + 1]] = u9[UNNAMED_2819735079752[u3]];
                    u9[UNNAMED_2819735045000[u3 + 1]] = UNNAMED_2819735041784[u3];
                    local v403;

                    if u2[2] then
                        v403 = UNNAMED_2819735084312[u3 + 1] - 1;
                    else
                        v403 = UNNAMED_2819735082680[u3] - 1;
                    end;

                    u3 = v403;
                    u3 = u3 + 1;
                end;
            elseif v233 < 9 then
                if v233 >= 7 then
                    if v233 == 8 then
                        return false, false;
                    end;

                    u3 = UNNAMED_2819735084312[u3];
                else
                    u9[UNNAMED_2819735045000[u3 + 1]][UNNAMED_2819735041784[u3 + 1]] = UNNAMED_2819735079752[u3];
                    local v404;

                    if u2[14] then
                        v404 = UNNAMED_2819735057720[u3 + 1] - 1;
                    else
                        v404 = UNNAMED_2819735084312[u3] - 1;
                    end;

                    u3 = v404;
                    u3 = u3 + 1;
                end;
            elseif v233 < 11 then
                if v233 == 10 then
                    u9[UNNAMED_2819735041784[u3]][UNNAMED_2819735041784[u3 + 1]] = UNNAMED_2819735079752[u3];
                    local v405;

                    if u2[14] then
                        v405 = UNNAMED_2819735082680[u3] - 1;
                    else
                        v405 = UNNAMED_2819735057720[u3 + 1] - 1;
                    end;

                    u3 = v405;
                    u3 = u3 + 1;
                else
                    u3 = UNNAMED_2819735084312[u3];
                end;
            else
                if v233 == 12 then
                    local v406 = UNNAMED_2819735088488[UNNAMED_2819735057720[u3]];
                    v406[5][v406[4]] = u2[14];

                    return false, false;
                end;

                u2[2] = u9[UNNAMED_2819735041784[u3]];
                local v407;

                if u2[2] then
                    v407 = UNNAMED_2819735057720[u3];
                else
                    v407 = UNNAMED_2819735082680[u3];
                end;

                u3 = v407;
            end;

            u3 = u3 + 1;
        end;
    end;
end, ...);

if v408 then
    if v409 then
        if v410 then
            return u2[v411](u7(v412, 1, v412.n));
        end;

        return u2[v411](u7(u2, v411 + 1, v412));
    end;

    if v411 then
        if v410 then
            return u7(v411, 1, v411.n);
        end;

        return u7(u2, v411, v412);
    end;
else
    UNNAMED_2819735035928(UNNAMED_2819735035496, v409, u3, UNNAMED_2819735030936);
end;