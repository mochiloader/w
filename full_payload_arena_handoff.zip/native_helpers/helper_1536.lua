-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735031320[21];
local u2 = UNNAMED_2819735031320[80];
local u3 = UNNAMED_2819735031320[35];
local u4 = UNNAMED_2819735031320[110];
local u5 = UNNAMED_2819735031320[11];
local u6 = UNNAMED_2819735031320[84];
local u7 = UNNAMED_2819735031320[113];
local u8 = UNNAMED_2819735031320[92];
local u9 = UNNAMED_2819735031320[117];
local u10 = UNNAMED_2819735031320[47];
local u11 = UNNAMED_2819735031320[43];
local u12 = UNNAMED_2819735031320[67];
local G3 = UNNAMED_2819735031320.G3;

return function(p13, u14, u15, p16, u17, p18, u19, p20, p21) -- Line: 3, Name: G
    -- upvalues: u1 (copy), u2 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u12 (copy), G3 (copy), UNNAMED_2819735080088 (copy), UNNAMED_2819735055896 (copy), UNNAMED_2819735055512 (copy), UNNAMED_2819735043608 (copy), UNNAMED_2819735052104 (copy), UNNAMED_2819735040584 (copy), UNNAMED_2819735076680 (copy), UNNAMED_2819735051336 (copy), UNNAMED_2819735043224 (copy), UNNAMED_2819735034344 (copy), UNNAMED_2819735031320 (copy), UNNAMED_2819735092760 (copy)
    local u22 = u1;
    local u23 = u2;
    local u24 = u3;
    local u25 = u4;
    local u26 = u5;
    local u27 = u6;
    local u28 = u7;
    local u29 = u8;
    local u30 = u9;
    local u31 = u10;
    local u32 = u11;
    local u33 = u12;
    local u34 = G3;

    return function(...) -- Line: 3, Name: c
        -- upvalues: u14 (copy), u19 (copy), u15 (copy), u22 (copy), UNNAMED_2819735080088 (ref), UNNAMED_2819735055896 (ref), UNNAMED_2819735055512 (ref), u31 (copy), u28 (copy), u24 (copy), u25 (copy), u26 (copy), u27 (copy), u29 (copy), u30 (copy), u32 (copy), u23 (copy), UNNAMED_2819735043608 (ref), UNNAMED_2819735052104 (ref), UNNAMED_2819735040584 (ref), UNNAMED_2819735076680 (ref), UNNAMED_2819735051336 (ref), UNNAMED_2819735043224 (ref), UNNAMED_2819735034344 (ref), u17 (copy), UNNAMED_2819735031320 (ref), u33 (copy), u34 (copy), UNNAMED_2819735092760 (ref)
        local u35 = u14;
        local u36 = u19;
        local u37 = u15;
        local u38 = u22;
        local u39 = u38(UNNAMED_2819735080088);
        local u40 = UNNAMED_2819735055896;
        local u41 = UNNAMED_2819735055512;
        local u42 = nil;
        local u43 = nil;
        local u44 = u28;
        local u45 = u24;
        local u46 = u25;
        local u47 = u26;
        local u48 = u27;
        local u49 = u29;
        local u50 = u30;
        local u51 = u32;
        local v547, v548, v549, v550, v551 = u23(function(...) -- Line: 3
            -- upvalues: u41 (ref), UNNAMED_2819735043608 (ref), u40 (ref), u47 (copy), u35 (ref), u46 (copy), u45 (copy), UNNAMED_2819735052104 (ref), UNNAMED_2819735040584 (ref), UNNAMED_2819735076680 (ref), u48 (copy), u39 (copy), u44 (copy), u36 (ref), u37 (ref), UNNAMED_2819735051336 (ref), UNNAMED_2819735043224 (ref), UNNAMED_2819735034344 (ref), u49 (copy), u38 (copy), u17 (ref), UNNAMED_2819735031320 (ref), u50 (copy), u51 (copy), u42 (copy), u43 (copy)
            local u41, u40, u35, u37, u36;
            local v52 = 0;

            while true do
                if v52 == 0 then
                    v52 = -1;

                    if u41 ~= 131 then
                        v52 = 1;
                        continue;
                    end;

                    v52 = 6;
                    continue;
                elseif v52 == 1 then
                    v52 = -1;

                    if u41 ~= 162 then
                        v52 = 2;
                        continue;
                    end;

                    v52 = 5;
                    continue;
                elseif v52 == 2 then
                    v52 = -1;

                    if u41 ~= 247 then
                        v52 = 3;
                        continue;
                    end;

                    v52 = 4;
                    continue;
                elseif v52 == 3 then
                    v52 = -1;

                    if u41 == 224 then
                        while UNNAMED_2819735076680[u40] == 1 do
                            local v53 = UNNAMED_2819735043608[u40];
                            local v54 = UNNAMED_2819735052104[u40];
                            local v55 = UNNAMED_2819735040584[u40];
                            local v56 = u47(u37, u46(u45(u37, 14), 262143), (u46(u45(u37, 28), 15)));
                            local v57 = v55 < 16384 and 7 or (v55 < 2097152 and 14 or 21);
                            local v58 = u46(v55, u48(1, v57) - 1);
                            local v59 = u45(v55, v57);
                            UNNAMED_2819735043608[u40] = u47(v53, 111, (u46(u45(v56, 7), 127)));
                            UNNAMED_2819735040584[u40] = u47(v58, 73, (u46(u45(v56, 14), 127)));
                            UNNAMED_2819735052104[u40] = u47(v54, 115, (u46(v56, 127)));
                            UNNAMED_2819735076680[u40] = u47(v59, 50, (u46(u45(v56, 21), 127)));
                            u40 = u40 - 1;
                            u40 = u40 + 1;
                        end;

                        u41 = UNNAMED_2819735040584[u40];
                        u40 = u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735076680[u40], 107), 127))) + 1;
                    end;

                    local v60;

                    if u41 ~= 57 then
                        if u41 == 193 then
                            v60 = UNNAMED_2819735052104[u40];

                            return false, true, u51(u39[u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], 66, u40), 127)))]);
                        end;

                        return;
                    end;

                    while true do
                        local u40;
                        local v61 = 0;

                        while true do
                            if v61 == 0 then
                                v61 = -1;
                                local v62 = UNNAMED_2819735052104[u40];

                                if v62 < 53 then
                                    if v62 >= 26 then
                                        if v62 >= 39 then
                                            if v62 >= 46 then
                                                if v62 >= 49 then
                                                    if v62 < 51 then
                                                        if v62 == 50 then
                                                            u39[u47(UNNAMED_2819735040584[u40], (u46(u40, 127)))] = u39[UNNAMED_2819735076680[u40]];
                                                        else
                                                            u39[UNNAMED_2819735052104[u40 + 2]] = u47(UNNAMED_2819735051336[u40 + 2], u39[31]);
                                                            local v63 = u39[31];
                                                            local v64 = u46(314549645, 4294967295);
                                                            local v65 = u46(v63, 4294967295);
                                                            local v66 = u46(v64, 65535);
                                                            local v67 = u45(v64, 16);
                                                            local v68 = u46(v65, 65535);
                                                            local v69 = u45(v65, 16);
                                                            local v70 = u46(v66 * v68 + u48(u46(v66 * v69 + v67 * v68, 65535), 16), 4294967295) % 4294967296;
                                                            u39[31] = v70 ~= v70 and 0 or v70 - v70 % 1;
                                                            u39[UNNAMED_2819735052104[u40 + 1]] = u39[30] + u39[UNNAMED_2819735043608[u40 + 2]];
                                                            u39[29] = u39[29] + u39[30];
                                                            local v71 = u39[29] % 4294967296;
                                                            u39[29] = v71 ~= v71 and 0 or v71 - v71 % 1;
                                                            u39[30] = u39[9] * UNNAMED_2819735043608[u40 + 1];
                                                            u39[UNNAMED_2819735040584[u40]] = u39[30] + u39[29];
                                                            u39[UNNAMED_2819735040584[u40 + 1]] = u39[UNNAMED_2819735040584[u40 + 2]] / UNNAMED_2819735051336[u40 + 1];
                                                            u39[UNNAMED_2819735043608[u40]] = UNNAMED_2819735076680[u40] + u39[29];
                                                            u40 = u40 + 2;
                                                        end;
                                                    elseif v62 == 52 then
                                                        local v72 = u39[20] % 4294967296;
                                                        u39[UNNAMED_2819735052104[u40 + 1]] = v72 ~= v72 and 0 or v72 - v72 % 1;
                                                        u39[31] = u39[20] + UNNAMED_2819735043224[u40];
                                                        local v73 = u39[31];
                                                        local v74 = u46(UNNAMED_2819735043224[u40 + 1], 4294967295);
                                                        local v75 = u46(v73, 4294967295);
                                                        local v76 = u46(v74, 65535);
                                                        local v77 = u45(v74, 16);
                                                        local v78 = u46(v75, 65535);
                                                        local v79 = u45(v75, 16);
                                                        local v80 = u46(v76 * v78 + u48(u46(v76 * v79 + v77 * v78, 65535), 16), 4294967295) % 4294967296;
                                                        u39[30] = v80 ~= v80 and 0 or v80 - v80 % 1;
                                                        u39[29] = UNNAMED_2819735034344[u40 + 1] + u39[UNNAMED_2819735052104[u40 + 2]];
                                                        u39[32] = u49(UNNAMED_2819735034344[u40], u39[31]);
                                                        local v81 = u39[32];
                                                        local v82 = u46(UNNAMED_2819735034344[u40 + 2], 4294967295);
                                                        local v83 = u46(v81, 4294967295);
                                                        local v84 = u46(v82, 65535);
                                                        local v85 = u45(v82, 16);
                                                        local v86 = u46(v83, 65535);
                                                        local v87 = u45(v83, 16);
                                                        local v88 = u46(v84 * v86 + u48(u46(v84 * v87 + v85 * v86, 65535), 16), 4294967295) % 4294967296;
                                                        u39[30] = v88 ~= v88 and 0 or v88 - v88 % 1;
                                                        u39[31] = u47(UNNAMED_2819735043224[u40 + 2], u39[UNNAMED_2819735076680[u40 + 1]]);
                                                        local v89 = u39[31];
                                                        local v90 = u46(UNNAMED_2819735051336[u40], 4294967295);
                                                        local v91 = u46(v89, 4294967295);
                                                        local v92 = u46(v90, 65535);
                                                        local v93 = u45(v90, 16);
                                                        local v94 = u46(v91, 65535);
                                                        local v95 = u45(v91, 16);
                                                        local v96 = u46(v92 * v94 + u48(u46(v92 * v95 + v93 * v94, 65535), 16), 4294967295) % 4294967296;
                                                        u39[31] = v96 ~= v96 and 0 or v96 - v96 % 1;
                                                        u39[30] = u39[UNNAMED_2819735076680[u40 + 2]] + u39[31];
                                                        u40 = u40 + 2;
                                                    else
                                                        local v97 = UNNAMED_2819735043608[u40];
                                                        local v98 = u47(UNNAMED_2819735076680[u40], (u46(UNNAMED_2819735052104[u40], 127)));
                                                        local v99 = UNNAMED_2819735034344[u40];
                                                        u39[v97] = v98;
                                                        u39[v97 + 1] = v99;
                                                    end;
                                                elseif v62 < 47 then
                                                    u39[u47(UNNAMED_2819735076680[u40], 117)] = u39[UNNAMED_2819735043608[u40]] + UNNAMED_2819735034344[u40];
                                                elseif v62 == 48 then
                                                    u39[UNNAMED_2819735052104[u40 + 4]] = u46(UNNAMED_2819735034344[u40 + 1], u39[UNNAMED_2819735052104[u40 + 3]]);
                                                    local v100 = UNNAMED_2819735052104[u40 + 1];
                                                    local v101 = u39[UNNAMED_2819735052104[u40 + 2]];
                                                    local v102 = u46(UNNAMED_2819735051336[u40 + 3], 4294967295);
                                                    local v103 = u46(v101, 4294967295);
                                                    local v104 = u46(v102, 65535);
                                                    local v105 = u45(v102, 16);
                                                    local v106 = u46(v103, 65535);
                                                    local v107 = u45(v103, 16);
                                                    local v108 = u46(v104 * v106 + u48(u46(v104 * v107 + v105 * v106, 65535), 16), 4294967295) % 4294967296;
                                                    u39[v100] = v108 ~= v108 and 0 or v108 - v108 % 1;
                                                    u39[29] = u39[23] + u39[29];
                                                    u39[29] = u39[22] + u39[29];
                                                    local v109 = u39[29] % 4294967296;
                                                    u39[UNNAMED_2819735076680[u40]] = v109 ~= v109 and 0 or v109 - v109 % 1;
                                                    u39[31] = u39[20] + UNNAMED_2819735043224[u40 + 1];
                                                    local v110 = u39[31];
                                                    local v111 = u46(UNNAMED_2819735043224[u40 + 2], 4294967295);
                                                    local v112 = u46(v110, 4294967295);
                                                    local v113 = u46(v111, 65535);
                                                    local v114 = u45(v111, 16);
                                                    local v115 = u46(v112, 65535);
                                                    local v116 = u45(v112, 16);
                                                    local v117 = u46(v113 * v115 + u48(u46(v113 * v116 + v114 * v115, 65535), 16), 4294967295) % 4294967296;
                                                    u39[30] = v117 ~= v117 and 0 or v117 - v117 % 1;
                                                    u39[UNNAMED_2819735043608[u40 + 4]] = UNNAMED_2819735051336[u40 + 4] + u39[UNNAMED_2819735040584[u40 + 2]];
                                                    u39[32] = u49(UNNAMED_2819735043224[u40], u39[UNNAMED_2819735040584[u40]]);
                                                    local v118 = u39[UNNAMED_2819735043608[u40 + 3]];
                                                    local v119 = u46(UNNAMED_2819735051336[u40 + 2], 4294967295);
                                                    local v120 = u46(v118, 4294967295);
                                                    local v121 = u46(v119, 65535);
                                                    local v122 = u45(v119, 16);
                                                    local v123 = u46(v120, 65535);
                                                    local v124 = u45(v120, 16);
                                                    local v125 = u46(v121 * v123 + u48(u46(v121 * v124 + v122 * v123, 65535), 16), 4294967295) % 4294967296;
                                                    u39[30] = v125 ~= v125 and 0 or v125 - v125 % 1;
                                                    u40 = u40 + 4;
                                                else
                                                    u39[UNNAMED_2819735043608[u40]] = UNNAMED_2819735040584[u40] - u39[u47(UNNAMED_2819735076680[u40], (u46(UNNAMED_2819735052104[u40], 127)))];
                                                end;
                                            elseif v62 < 42 then
                                                if v62 >= 40 then
                                                    if v62 == 41 then
                                                        u39[u47(UNNAMED_2819735040584[u40], (u46(u40, 127)))] = u47(u39[u47(UNNAMED_2819735043608[u40], (u46(u41, 127)))], u39[UNNAMED_2819735076680[u40]]);
                                                    else
                                                        local v126 = UNNAMED_2819735076680[u40];
                                                        local v127 = u47(u37, u46(u45(u37, 14), 262143), (u46(u45(u37, 28), 15)));
                                                        local v128 = UNNAMED_2819735043608[u40];
                                                        local v129 = UNNAMED_2819735040584[u40];
                                                        local v130 = v126 < 16384 and 7 or (v126 < 2097152 and 14 or 21);
                                                        local v131 = u45(v126, v130);
                                                        UNNAMED_2819735076680[u40] = u47(u46(v126, u48(1, v130) - 1), 26, (u46(u45(v127, 7), 127)));
                                                        UNNAMED_2819735052104[u40] = u47(v131, 101, (u46(u45(v127, 21), 127)));
                                                        UNNAMED_2819735043608[u40] = u47(v128, 35, (u46(v127, 127)));
                                                        UNNAMED_2819735040584[u40] = u47(v129, 95, (u46(u45(v127, 14), 127)));
                                                        u40 = u40 - 1;
                                                    end;
                                                else
                                                    u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u41, UNNAMED_2819735052104[u40], u40), 127)))] = u39[UNNAMED_2819735040584[u40]] ^ u39[u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], 5), 127)))];
                                                end;
                                            elseif v62 < 44 then
                                                if v62 == 43 then
                                                    u39[31] = u39[31] + u39[UNNAMED_2819735052104[u40 + 2]];
                                                    u39[30] = u39[30] + u39[31];
                                                    u39[UNNAMED_2819735052104[u40 + 1]] = u39[29] + u39[30];
                                                    local v132 = u39[29] % 4294967296;
                                                    u39[21] = v132 ~= v132 and 0 or v132 - v132 % 1;
                                                    u39[22] = u39[UNNAMED_2819735043608[u40 + 2]] + UNNAMED_2819735034344[u40 + 1];
                                                    local v133 = u39[UNNAMED_2819735043608[u40 + 1]];
                                                    local v134 = u46(UNNAMED_2819735043224[u40], 4294967295);
                                                    local v135 = u46(v133, 4294967295);
                                                    local v136 = u46(v134, 65535);
                                                    local v137 = u45(v134, 16);
                                                    local v138 = u46(v135, 65535);
                                                    local v139 = u45(v135, 16);
                                                    local v140 = u46(v136 * v138 + u48(u46(v136 * v139 + v137 * v138, 65535), 16), 4294967295) % 4294967296;
                                                    u39[23] = v140 ~= v140 and 0 or v140 - v140 % 1;
                                                    u39[UNNAMED_2819735076680[u40]] = UNNAMED_2819735040584[u40 + 2];
                                                    u39[20] = 22800106;
                                                    u40 = u40 + 2;
                                                else
                                                    local v141 = u39[29] % 4294967296;
                                                    u39[UNNAMED_2819735052104[u40 + 2]] = v141 ~= v141 and 0 or v141 - v141 % 1;
                                                    u39[29] = u47(u39[UNNAMED_2819735052104[u40 + 1]], UNNAMED_2819735043224[u40 + 2]);
                                                    local v142 = u39[30] % 4294967296;
                                                    u39[30] = v142 ~= v142 and 0 or v142 - v142 % 1;
                                                    u39[30] = u47(u39[UNNAMED_2819735076680[u40 + 2]], UNNAMED_2819735051336[u40]);
                                                    u39[29] = u39[29] + u39[30];
                                                    u39[UNNAMED_2819735043608[u40 + 1]] = UNNAMED_2819735051336[u40 + 1] + u39[29];
                                                    local v143 = u39[31] % 4294967296;
                                                    u39[30] = v143 ~= v143 and 0 or v143 - v143 % 1;
                                                    u39[30] = u47(u39[30], UNNAMED_2819735043224[u40]);
                                                    u40 = u40 + 2;
                                                end;
                                            elseif v62 == 45 then
                                                u36 = u39[u47(UNNAMED_2819735040584[u40], 29)];
                                            else
                                                local v144 = UNNAMED_2819735040584[u40];
                                                local v145 = UNNAMED_2819735051336[u40];
                                                local v146 = u47(UNNAMED_2819735043608[u40], (u46(u47(u41, u40, UNNAMED_2819735052104[u40]), 127)));
                                                u39[v144] = v145;
                                                u39[v144 + 1] = v146;
                                            end;
                                        elseif v62 >= 32 then
                                            if v62 < 35 then
                                                if v62 >= 33 then
                                                    if v62 == 34 then
                                                        u39[u47(UNNAMED_2819735076680[u40], (u46(u47(u40, UNNAMED_2819735052104[u40]), 127)))] = u36;
                                                    else
                                                        u39[UNNAMED_2819735040584[u40]] = u47(u47(UNNAMED_2819735043608[u40], (u46(u47(u40, u41), 127))), u39[u47(UNNAMED_2819735076680[u40], (u46(u47(u40, u41, UNNAMED_2819735052104[u40]), 127)))]);
                                                    end;
                                                else
                                                    local v147;

                                                    if u39[u47(UNNAMED_2819735076680[u40], (u46(u47(55, u41, UNNAMED_2819735052104[u40]), 127)))] then
                                                        v147 = UNNAMED_2819735043608[u40];
                                                    else
                                                        v147 = u47(UNNAMED_2819735040584[u40], 45);
                                                    end;

                                                    u40 = v147;
                                                end;
                                            elseif v62 < 37 then
                                                if v62 == 36 then
                                                    u39[u47(UNNAMED_2819735040584[u40], (u46(u47(17, u40), 127)))] = u39[UNNAMED_2819735043608[u40]] // u39[UNNAMED_2819735076680[u40]];
                                                else
                                                    u39[30] = u39[UNNAMED_2819735052104[u40 + 1]] + u39[31];
                                                    u39[29] = u39[UNNAMED_2819735052104[u40 + 2]] + u39[30];
                                                    local v148 = u39[UNNAMED_2819735076680[u40 + 2]] % 4294967296;
                                                    u39[12] = v148 ~= v148 and 0 or v148 - v148 % 1;
                                                    u39[29] = u39[27] + UNNAMED_2819735043224[u40 + 2];
                                                    local v149 = u39[29] % 4294967296;
                                                    u39[UNNAMED_2819735043608[u40]] = v149 ~= v149 and 0 or v149 - v149 % 1;
                                                    u39[20] = u39[20] + UNNAMED_2819735043224[u40 + 1];
                                                    local v150 = u39[20];
                                                    local v151 = u46(UNNAMED_2819735051336[u40], 4294967295);
                                                    local v152 = u46(v150, 4294967295);
                                                    local v153 = u46(v151, 65535);
                                                    local v154 = u45(v151, 16);
                                                    local v155 = u46(v152, 65535);
                                                    local v156 = u45(v152, 16);
                                                    local v157 = u46(v153 * v155 + u48(u46(v153 * v156 + v154 * v155, 65535), 16), 4294967295) % 4294967296;
                                                    u39[30] = v157 ~= v157 and 0 or v157 - v157 % 1;
                                                    u39[UNNAMED_2819735040584[u40 + 1]] = UNNAMED_2819735051336[u40 + 1] + u39[UNNAMED_2819735040584[u40 + 2]];
                                                    u39[1] = UNNAMED_2819735040584[u40];
                                                    u40 = u40 + 2;
                                                end;
                                            elseif v62 == 38 then
                                                u39[29] = u49(u39[UNNAMED_2819735052104[u40 + 2]], u39[21]);
                                                local v158 = u39[29];
                                                local v159 = u46(u39[23], 4294967295);
                                                local v160 = u46(v158, 4294967295);
                                                local v161 = u46(v159, 65535);
                                                local v162 = u45(v159, 16);
                                                local v163 = u46(v160, 65535);
                                                local v164 = u45(v160, 16);
                                                local v165 = u46(v161 * v163 + u48(u46(v161 * v164 + v162 * v163, 65535), 16), 4294967295) % 4294967296;
                                                u39[29] = v165 ~= v165 and 0 or v165 - v165 % 1;
                                                u39[UNNAMED_2819735052104[u40 + 1]] = u47(UNNAMED_2819735043224[u40], u39[21]);
                                                local v166 = u39[31];
                                                local v167 = u46(UNNAMED_2819735051336[u40], 4294967295);
                                                local v168 = u46(v166, 4294967295);
                                                local v169 = u46(v167, 65535);
                                                local v170 = u45(v167, 16);
                                                local v171 = u46(v168, 65535);
                                                local v172 = u45(v168, 16);
                                                local v173 = u46(v169 * v171 + u48(u46(v169 * v172 + v170 * v171, 65535), 16), 4294967295) % 4294967296;
                                                u39[30] = v173 ~= v173 and 0 or v173 - v173 % 1;
                                                u39[29] = u39[29] + u39[30];
                                                u39[UNNAMED_2819735040584[u40 + 2]] = u39[UNNAMED_2819735040584[u40 + 1]] + u39[29];
                                                local v174 = u39[29] % 4294967296;
                                                u39[9] = v174 ~= v174 and 0 or v174 - v174 % 1;
                                                u39[31] = u39[UNNAMED_2819735076680[u40 + 1]] + UNNAMED_2819735043224[u40 + 1];
                                                local v175 = u39[31];
                                                local v176 = u46(UNNAMED_2819735034344[u40], 4294967295);
                                                local v177 = u46(v175, 4294967295);
                                                local v178 = u46(v176, 65535);
                                                local v179 = u45(v176, 16);
                                                local v180 = u46(v177, 65535);
                                                local v181 = u45(v177, 16);
                                                local v182 = u46(v178 * v180 + u48(u46(v178 * v181 + v179 * v180, 65535), 16), 4294967295) % 4294967296;
                                                u39[30] = v182 ~= v182 and 0 or v182 - v182 % 1;
                                                u40 = u40 + 2;
                                            else
                                                u39[UNNAMED_2819735040584[u40]] = u39[UNNAMED_2819735043608[u40]] ~= u47(UNNAMED_2819735076680[u40], (u46(UNNAMED_2819735052104[u40], 127)));
                                            end;
                                        elseif v62 >= 29 then
                                            if v62 >= 30 then
                                                if v62 == 31 then
                                                    u39[UNNAMED_2819735076680[u40]] = u39[u47(UNNAMED_2819735040584[u40], (u46(u47(84, UNNAMED_2819735052104[u40]), 127)))] * u39[u47(UNNAMED_2819735043608[u40], (u46(u47(10, u41), 127)))];
                                                else
                                                    u39[u47(UNNAMED_2819735040584[u40], (u46(u47(66, u41), 127)))] = u39[UNNAMED_2819735043608[u40]] * UNNAMED_2819735051336[u40];
                                                end;
                                            else
                                                u39[30] = u39[30] + u39[31];
                                                u39[29] = u39[29] + u39[30];
                                                local v183 = u39[29] % 4294967296;
                                                u39[29] = v183 ~= v183 and 0 or v183 - v183 % 1;
                                                u39[30] = u39[9] * 67108864;
                                                u39[29] = u39[UNNAMED_2819735052104[u40 + 2]] + u39[29];
                                                u39[UNNAMED_2819735052104[u40 + 1]] = u39[29] / UNNAMED_2819735043224[u40 + 2];
                                                u39[29] = UNNAMED_2819735040584[u40 + 2] + u39[29];
                                                u39[UNNAMED_2819735076680[u40 + 2]] = u39[8] - UNNAMED_2819735043608[u40 + 1];
                                                u39[30] = 2 ^ u39[31];
                                                u39[29] = u39[UNNAMED_2819735043608[u40]] * u39[30];
                                                u39[31] = UNNAMED_2819735076680[u40 + 1] * u39[6];
                                                u40 = u40 + 2;
                                            end;
                                        elseif v62 >= 27 then
                                            if v62 == 28 then
                                                local v184 = UNNAMED_2819735052104[u40 + 1];
                                                local v185 = u39[31];
                                                local v186 = u46(UNNAMED_2819735051336[u40 + 1], 4294967295);
                                                local v187 = u46(v185, 4294967295);
                                                local v188 = u46(v186, 65535);
                                                local v189 = u45(v186, 16);
                                                local v190 = u46(v187, 65535);
                                                local v191 = u45(v187, 16);
                                                local v192 = u46(v188 * v190 + u48(u46(v188 * v191 + v189 * v190, 65535), 16), 4294967295) % 4294967296;
                                                u39[v184] = v192 ~= v192 and 0 or v192 - v192 % 1;
                                                u39[30] = u39[30] + u39[31];
                                                u39[29] = u39[29] + u39[30];
                                                local v193 = u39[29] % 4294967296;
                                                u39[7] = v193 ~= v193 and 0 or v193 - v193 % 1;
                                                u39[27] = u39[UNNAMED_2819735052104[u40 + 2]] + 52275116;
                                                u39[UNNAMED_2819735040584[u40 + 1]] = u39[UNNAMED_2819735076680[u40]] + UNNAMED_2819735034344[u40 + 2];
                                                u39[1] = 69;
                                                local v194 = UNNAMED_2819735043224[u40];
                                                u39[21] = UNNAMED_2819735051336[u40 + 2];
                                                u39[22] = v194;
                                                u40 = u40 + 2;
                                            elseif u39[u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735052104[u40], 125), 127)))] > u47(UNNAMED_2819735076680[u40], (u46(u47(u41, 63), 127))) then
                                                u40 = UNNAMED_2819735043608[u40];
                                            end;
                                        end;
                                    elseif v62 >= 13 then
                                        if v62 < 19 then
                                            if v62 >= 16 then
                                                if v62 < 17 then
                                                    u39[UNNAMED_2819735076680[u40]] = u39[UNNAMED_2819735040584[u40]] / u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u41, UNNAMED_2819735052104[u40], u40), 127)))];
                                                elseif v62 == 18 then
                                                    u39[31] = u47(UNNAMED_2819735051336[u40], u39[UNNAMED_2819735052104[u40 + 2]]);
                                                    local v195 = u39[UNNAMED_2819735052104[u40 + 1]];
                                                    local v196 = u46(492948478, 4294967295);
                                                    local v197 = u46(v195, 4294967295);
                                                    local v198 = u46(v196, 65535);
                                                    local v199 = u45(v196, 16);
                                                    local v200 = u46(v197, 65535);
                                                    local v201 = u45(v197, 16);
                                                    local v202 = u46(v198 * v200 + u48(u46(v198 * v201 + v199 * v200, 65535), 16), 4294967295) % 4294967296;
                                                    u39[30] = v202 ~= v202 and 0 or v202 - v202 % 1;
                                                    u39[UNNAMED_2819735043608[u40 + 2]] = u39[29] + u39[30];
                                                    u39[UNNAMED_2819735040584[u40 + 2]] = u39[UNNAMED_2819735040584[u40]] + u39[UNNAMED_2819735076680[u40 + 2]];
                                                    local v203 = u39[29] % 4294967296;
                                                    u39[7] = v203 ~= v203 and 0 or v203 - v203 % 1;
                                                    u39[31] = u39[20] + UNNAMED_2819735043224[u40 + 1];
                                                    local v204 = u39[31];
                                                    local v205 = u46(UNNAMED_2819735043224[u40], 4294967295);
                                                    local v206 = u46(v204, 4294967295);
                                                    local v207 = u46(v205, 65535);
                                                    local v208 = u45(v205, 16);
                                                    local v209 = u46(v206, 65535);
                                                    local v210 = u45(v206, 16);
                                                    local v211 = u46(v207 * v209 + u48(u46(v207 * v210 + v208 * v209, 65535), 16), 4294967295) % 4294967296;
                                                    u39[30] = v211 ~= v211 and 0 or v211 - v211 % 1;
                                                    u39[29] = UNNAMED_2819735051336[u40 + 1] + u39[30];
                                                    u39[32] = u49(UNNAMED_2819735034344[u40 + 1], u39[31]);
                                                    u40 = u40 + 2;
                                                else
                                                    u39[u47(UNNAMED_2819735076680[u40], (u46(u47(u40, UNNAMED_2819735052104[u40]), 127)))] = u38(UNNAMED_2819735040584[u40]);
                                                end;
                                            elseif v62 >= 14 then
                                                if v62 == 15 then
                                                    u39[29] = u49(UNNAMED_2819735034344[u40 + 3], u39[20]);
                                                    local v212 = UNNAMED_2819735052104[u40 + 2];
                                                    local v213 = u39[29];
                                                    local v214 = u46(u39[22], 4294967295);
                                                    local v215 = u46(v213, 4294967295);
                                                    local v216 = u46(v214, 65535);
                                                    local v217 = u45(v214, 16);
                                                    local v218 = u46(v215, 65535);
                                                    local v219 = u45(v215, 16);
                                                    local v220 = u46(v216 * v218 + u48(u46(v216 * v219 + v217 * v218, 65535), 16), 4294967295) % 4294967296;
                                                    u39[v212] = v220 ~= v220 and 0 or v220 - v220 % 1;
                                                    u39[31] = u47(UNNAMED_2819735043224[u40 + 1], u39[20]);
                                                    local v221 = UNNAMED_2819735052104[u40 + 1];
                                                    local v222 = u39[31];
                                                    local v223 = u46(UNNAMED_2819735034344[u40 + 1], 4294967295);
                                                    local v224 = u46(v222, 4294967295);
                                                    local v225 = u46(v223, 65535);
                                                    local v226 = u45(v223, 16);
                                                    local v227 = u46(v224, 65535);
                                                    local v228 = u45(v224, 16);
                                                    local v229 = u46(v225 * v227 + u48(u46(v225 * v228 + v226 * v227, 65535), 16), 4294967295) % 4294967296;
                                                    u39[v221] = v229 ~= v229 and 0 or v229 - v229 % 1;
                                                    u39[29] = u39[UNNAMED_2819735052104[u40 + 3]] + u39[30];
                                                    u39[29] = u39[21] + u39[29];
                                                    local v230 = u39[29] % 4294967296;
                                                    u39[UNNAMED_2819735076680[u40 + 1]] = v230 ~= v230 and 0 or v230 - v230 % 1;
                                                    u39[30] = u39[12] * 67108864;
                                                    u39[UNNAMED_2819735076680[u40 + 2]] = u39[UNNAMED_2819735040584[u40]] + u39[29];
                                                    u39[UNNAMED_2819735076680[u40]] = u39[29] / UNNAMED_2819735043224[u40 + 3];
                                                    u39[29] = 1 + u39[UNNAMED_2819735043608[u40 + 2]];
                                                    u40 = u40 + 3;
                                                else
                                                    local v231 = u17[u47(UNNAMED_2819735040584[u40], 99)];
                                                    v231[5][v231[4]] = u39[UNNAMED_2819735076680[u40]];
                                                end;
                                            else
                                                local v232 = UNNAMED_2819735043608[u40] + 1;
                                                local v233 = u47(UNNAMED_2819735076680[u40], (u46(u47(u36, (u46(u45(u36, 29), 7))), 536870911)));

                                                for i = 1, UNNAMED_2819735040584[u40] do
                                                    local v234 = u46(u47(v233, (u48(v233, 13))), 536870911);
                                                    local v235 = u47(v234, (u45(v234, 13)));
                                                    v233 = u46(u47(v235, (u48(v235, 14))), 536870911);
                                                    UNNAMED_2819735043608[v232] = u47(UNNAMED_2819735043608[v232], (u46(u45(v233, 0), 127)));
                                                    UNNAMED_2819735076680[v232] = u47(UNNAMED_2819735076680[v232], (u46(u45(v233, 7), 127)));
                                                    UNNAMED_2819735040584[v232] = u47(UNNAMED_2819735040584[v232], (u46(u45(v233, 14), 127)));
                                                    UNNAMED_2819735052104[v232] = u47(UNNAMED_2819735052104[v232], (u46(u45(v233, 21), 127)));
                                                    v232 = v232 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735052104[u40] = 26;
                                            end;
                                        elseif v62 < 22 then
                                            if v62 < 20 then
                                                local v236 = UNNAMED_2819735043608[u40] + 1;
                                                local v237 = u47(UNNAMED_2819735076680[u40], (u46(u47(u35, (u46(u45(u35, 29), 7))), 536870911)));

                                                for i = 1, UNNAMED_2819735040584[u40] do
                                                    local v238 = u46(u47(v237, (u48(v237, 13))), 536870911);
                                                    local v239 = u47(v238, (u45(v238, 13)));
                                                    v237 = u46(u47(v239, (u48(v239, 14))), 536870911);
                                                    UNNAMED_2819735043608[v236] = u47(UNNAMED_2819735043608[v236], (u46(u45(v237, 0), 127)));
                                                    UNNAMED_2819735076680[v236] = u47(UNNAMED_2819735076680[v236], (u46(u45(v237, 7), 127)));
                                                    UNNAMED_2819735040584[v236] = u47(UNNAMED_2819735040584[v236], (u46(u45(v237, 14), 127)));
                                                    UNNAMED_2819735052104[v236] = u47(UNNAMED_2819735052104[v236], (u46(u45(v237, 21), 127)));
                                                    v236 = v236 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735052104[u40] = 26;
                                            elseif v62 == 21 then
                                                u39[UNNAMED_2819735043608[u40]] = u39[u47(UNNAMED_2819735040584[u40], (u46(u47(u41, u40, 99), 127)))] ~= UNNAMED_2819735051336[u40];
                                            else
                                                u39[u47(UNNAMED_2819735076680[u40], (u46(u47(u40, UNNAMED_2819735052104[u40]), 127)))] = u39[UNNAMED_2819735040584[u40]] * UNNAMED_2819735043608[u40];
                                            end;
                                        elseif v62 >= 24 then
                                            if v62 == 25 then
                                                u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u40, 37), 127)))] = UNNAMED_2819735076680[u40] ^ u39[u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735052104[u40], u41, 83), 127)))];
                                            else
                                                local v240 = u47(UNNAMED_2819735043608[u40], (u46(u40, 127)));
                                                local v241 = UNNAMED_2819735051336[u40];
                                                u39[v240] = UNNAMED_2819735034344[u40];
                                                u39[v240 + 1] = v241;
                                            end;
                                        elseif v62 == 23 then
                                            u39[u47(UNNAMED_2819735040584[u40], (u46(u47(44, u41, u40), 127)))] = u39[UNNAMED_2819735076680[u40]](u39[UNNAMED_2819735043608[u40]]);
                                        else
                                            local v242 = u39[UNNAMED_2819735052104[u40 + 1]] % 4294967296;
                                            u39[29] = v242 ~= v242 and 0 or v242 - v242 % 1;
                                            u39[29] = u47(u39[29], UNNAMED_2819735043224[u40 + 1]);
                                            local v243 = u39[30] % 4294967296;
                                            u39[30] = v243 ~= v243 and 0 or v243 - v243 % 1;
                                            u39[30] = u47(u39[UNNAMED_2819735052104[u40 + 2]], UNNAMED_2819735034344[u40]);
                                            u39[29] = u39[UNNAMED_2819735076680[u40]] + u39[30];
                                            u39[29] = UNNAMED_2819735043224[u40 + 2] + u39[29];
                                            local v244 = u39[UNNAMED_2819735043608[u40]] % 4294967296;
                                            u39[UNNAMED_2819735040584[u40 + 1]] = v244 ~= v244 and 0 or v244 - v244 % 1;
                                            u39[UNNAMED_2819735076680[u40 + 2]] = u47(u39[30], UNNAMED_2819735051336[u40 + 1]);
                                            u40 = u40 + 2;
                                        end;
                                    elseif v62 < 6 then
                                        if v62 < 3 then
                                            if v62 < 1 then
                                                u40 = u39[u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], u41, 34), 127)))];
                                            elseif v62 == 2 then
                                                u39[29] = u39[34][5];
                                                u39[30] = u39[UNNAMED_2819735052104[u40 + 1]][2];
                                                u39[31] = u39[34][UNNAMED_2819735040584[u40]];
                                                u39[29] = u39[29] + u39[UNNAMED_2819735076680[u40]];
                                                u39[30] = u39[30] <= 0;
                                                u39[UNNAMED_2819735043608[u40]] = not u39[30];
                                                u39[33] = u39[29] >= u39[31];
                                                u39[UNNAMED_2819735040584[u40 + 1]] = u39[29] <= u39[31];
                                                u40 = u40 + 1;
                                            else
                                                u39[32] = u39[20] + UNNAMED_2819735034344[u40];
                                                local v245 = UNNAMED_2819735052104[u40 + 1];
                                                local v246 = u39[UNNAMED_2819735052104[u40 + 3]];
                                                local v247 = u46(UNNAMED_2819735051336[u40], 4294967295);
                                                local v248 = u46(v246, 4294967295);
                                                local v249 = u46(v247, 65535);
                                                local v250 = u45(v247, 16);
                                                local v251 = u46(v248, 65535);
                                                local v252 = u45(v248, 16);
                                                local v253 = u46(v249 * v251 + u48(u46(v249 * v252 + v250 * v251, 65535), 16), 4294967295) % 4294967296;
                                                u39[v245] = v253 ~= v253 and 0 or v253 - v253 % 1;
                                                u39[30] = UNNAMED_2819735034344[u40 + 2] + u39[31];
                                                u39[33] = u49(UNNAMED_2819735052104[u40 + 2], u39[UNNAMED_2819735043608[u40 + 2]]);
                                                local v254 = u39[33];
                                                local v255 = u46(UNNAMED_2819735051336[u40 + 3], 4294967295);
                                                local v256 = u46(v254, 4294967295);
                                                local v257 = u46(v255, 65535);
                                                local v258 = u45(v255, 16);
                                                local v259 = u46(v256, 65535);
                                                local v260 = u45(v256, 16);
                                                local v261 = u46(v257 * v259 + u48(u46(v257 * v260 + v258 * v259, 65535), 16), 4294967295) % 4294967296;
                                                u39[31] = v261 ~= v261 and 0 or v261 - v261 % 1;
                                                u39[32] = u47(514011825, u39[32]);
                                                local v262 = UNNAMED_2819735043608[u40 + 1];
                                                local v263 = u39[UNNAMED_2819735043608[u40]];
                                                local v264 = u46(UNNAMED_2819735051336[u40 + 2], 4294967295);
                                                local v265 = u46(v263, 4294967295);
                                                local v266 = u46(v264, 65535);
                                                local v267 = u45(v264, 16);
                                                local v268 = u46(v265, 65535);
                                                local v269 = u45(v265, 16);
                                                local v270 = u46(v266 * v268 + u48(u46(v266 * v269 + v267 * v268, 65535), 16), 4294967295) % 4294967296;
                                                u39[v262] = v270 ~= v270 and 0 or v270 - v270 % 1;
                                                u39[UNNAMED_2819735040584[u40 + 3]] = u39[31] + u39[32];
                                                u39[30] = u39[30] + u39[31];
                                                local v271 = u39[UNNAMED_2819735076680[u40 + 1]] % 4294967296;
                                                u39[30] = v271 ~= v271 and 0 or v271 - v271 % 1;
                                                u39[UNNAMED_2819735040584[u40 + 1]] = u39[29] * 67108864;
                                                u39[29] = u39[29] + u39[UNNAMED_2819735043608[u40 + 3]];
                                                u40 = u40 + 3;
                                            end;
                                        elseif v62 >= 4 then
                                            if v62 == 5 then
                                                u39[u47(UNNAMED_2819735040584[u40], (u46(u47(105, u41), 127)))] = UNNAMED_2819735043224[u40];
                                            else
                                                u39[30] = u46(UNNAMED_2819735034344[u40 + 3], u39[UNNAMED_2819735052104[u40 + 2]]);
                                                local v272 = UNNAMED_2819735052104[u40 + 3];
                                                local v273 = u39[UNNAMED_2819735052104[u40 + 1]];
                                                local v274 = u46(UNNAMED_2819735043224[u40 + 3], 4294967295);
                                                local v275 = u46(v273, 4294967295);
                                                local v276 = u46(v274, 65535);
                                                local v277 = u45(v274, 16);
                                                local v278 = u46(v275, 65535);
                                                local v279 = u45(v275, 16);
                                                local v280 = u46(v276 * v278 + u48(u46(v276 * v279 + v277 * v278, 65535), 16), 4294967295) % 4294967296;
                                                u39[v272] = v280 ~= v280 and 0 or v280 - v280 % 1;
                                                u39[UNNAMED_2819735076680[u40 + 1]] = u39[UNNAMED_2819735040584[u40]] + u39[30];
                                                u39[29] = u39[29] + u39[30];
                                                local v281 = u39[29] % 4294967296;
                                                u39[UNNAMED_2819735076680[u40 + 3]] = v281 ~= v281 and 0 or v281 - v281 % 1;
                                                u39[UNNAMED_2819735043608[u40 + 1]] = u39[10] + UNNAMED_2819735040584[u40 + 2];
                                                local v282 = u39[UNNAMED_2819735040584[u40 + 1]];
                                                local v283 = u46(UNNAMED_2819735043224[u40], 4294967295);
                                                local v284 = u46(v282, 4294967295);
                                                local v285 = u46(v283, 65535);
                                                local v286 = u45(v283, 16);
                                                local v287 = u46(v284, 65535);
                                                local v288 = u45(v284, 16);
                                                local v289 = u46(v285 * v287 + u48(u46(v285 * v288 + v286 * v287, 65535), 16), 4294967295) % 4294967296;
                                                u39[31] = v289 ~= v289 and 0 or v289 - v289 % 1;
                                                u39[UNNAMED_2819735076680[u40 + 2]] = UNNAMED_2819735043224[u40 + 2] + u39[UNNAMED_2819735076680[u40]];
                                                u40 = u40 + 3;
                                            end;
                                        else
                                            u39[UNNAMED_2819735040584[u40]] = u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], 74), 127)));
                                        end;
                                    elseif v62 >= 9 then
                                        if v62 >= 11 then
                                            if v62 == 12 then
                                                u39[UNNAMED_2819735043608[u40]] = u39[u47(UNNAMED_2819735040584[u40], (u46(u40, 127)))] - UNNAMED_2819735076680[u40];
                                            else
                                                local v290 = UNNAMED_2819735076680[u40] + 1;
                                                local v291 = UNNAMED_2819735040584[u40];

                                                for i = 1, UNNAMED_2819735043608[u40] do
                                                    local v292 = u46(u47(v291, (u48(v291, 13))), 536870911);
                                                    local v293 = u47(v292, (u45(v292, 13)));
                                                    v291 = u46(u47(v293, (u48(v293, 14))), 536870911);
                                                    UNNAMED_2819735043608[v290] = u47(UNNAMED_2819735043608[v290], (u46(u45(v291, 0), 127)));
                                                    UNNAMED_2819735076680[v290] = u47(UNNAMED_2819735076680[v290], (u46(u45(v291, 7), 127)));
                                                    UNNAMED_2819735040584[v290] = u47(UNNAMED_2819735040584[v290], (u46(u45(v291, 14), 127)));
                                                    UNNAMED_2819735052104[v290] = u47(UNNAMED_2819735052104[v290], (u46(u45(v291, 21), 127)));
                                                    v290 = v290 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819735052104[u40] = 26;
                                            end;
                                        elseif v62 == 10 then
                                            local v294 = u47(UNNAMED_2819735076680[u40], (u46(u47(u41, u40, 86), 127)));
                                            local v295 = UNNAMED_2819735043224[u40];
                                            local v296 = u46(UNNAMED_2819735034344[u40], 4294967295);
                                            local v297 = u46(v295, 4294967295);
                                            local v298 = u46(v296, 65535);
                                            local v299 = u45(v296, 16);
                                            local v300 = u46(v297, 65535);
                                            local v301 = u45(v297, 16);
                                            local v302 = u46(v298 * v300 + u48(u46(v298 * v301 + v299 * v300, 65535), 16), 4294967295) % 4294967296;
                                            u39[v294] = v302 ~= v302 and 0 or v302 - v302 % 1;
                                        else
                                            u39[u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735052104[u40], 127)))] = UNNAMED_2819735043224[u40] + u39[UNNAMED_2819735076680[u40]];
                                        end;
                                    elseif v62 >= 7 then
                                        if v62 == 8 then
                                            local v303 = UNNAMED_2819735076680[u40];
                                            local v304 = UNNAMED_2819735043224[u40];
                                            local v305 = u39[u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735052104[u40], 127)))];
                                            local v306 = u46(v304, 4294967295);
                                            local v307 = u46(v305, 4294967295);
                                            local v308 = u46(v306, 65535);
                                            local v309 = u45(v306, 16);
                                            local v310 = u46(v307, 65535);
                                            local v311 = u45(v307, 16);
                                            local v312 = u46(v308 * v310 + u48(u46(v308 * v311 + v309 * v310, 65535), 16), 4294967295) % 4294967296;
                                            u39[v303] = v312 ~= v312 and 0 or v312 - v312 % 1;
                                        else
                                            u39[UNNAMED_2819735076680[u40]] = UNNAMED_2819735040584[u40];
                                        end;
                                    else
                                        u39[UNNAMED_2819735076680[u40]] = u39[UNNAMED_2819735040584[u40]] >= u39[u47(UNNAMED_2819735043608[u40], 68)];
                                    end;
                                elseif v62 < 79 then
                                    if v62 >= 66 then
                                        if v62 < 72 then
                                            if v62 >= 69 then
                                                if v62 < 70 then
                                                    u39[UNNAMED_2819735052104[u40 + 2]] = u47(UNNAMED_2819735034344[u40 + 1], u39[29]);
                                                    local v313 = u39[UNNAMED_2819735052104[u40 + 1]];
                                                    local v314 = u46(149991613, 4294967295);
                                                    local v315 = u46(v313, 4294967295);
                                                    local v316 = u46(v314, 65535);
                                                    local v317 = u45(v314, 16);
                                                    local v318 = u46(v315, 65535);
                                                    local v319 = u45(v315, 16);
                                                    local v320 = u46(v316 * v318 + u48(u46(v316 * v319 + v317 * v318, 65535), 16), 4294967295) % 4294967296;
                                                    u39[29] = v320 ~= v320 and 0 or v320 - v320 % 1;
                                                    u39[29] = u39[31] + u39[UNNAMED_2819735076680[u40]];
                                                    u39[29] = u39[30] + u39[29];
                                                    local v321 = u39[29] % 4294967296;
                                                    u39[7] = v321 ~= v321 and 0 or v321 - v321 % 1;
                                                    u39[UNNAMED_2819735043608[u40 + 1]] = u39[22] + UNNAMED_2819735043224[u40];
                                                    local v322 = u39[31];
                                                    local v323 = u46(UNNAMED_2819735051336[u40 + 1], 4294967295);
                                                    local v324 = u46(v322, 4294967295);
                                                    local v325 = u46(v323, 65535);
                                                    local v326 = u45(v323, 16);
                                                    local v327 = u46(v324, 65535);
                                                    local v328 = u45(v324, 16);
                                                    local v329 = u46(v325 * v327 + u48(u46(v325 * v328 + v326 * v327, 65535), 16), 4294967295) % 4294967296;
                                                    u39[30] = v329 ~= v329 and 0 or v329 - v329 % 1;
                                                    u39[UNNAMED_2819735076680[u40 + 2]] = UNNAMED_2819735034344[u40] + u39[30];
                                                    u40 = u40 + 2;
                                                elseif v62 == 71 then
                                                    u39[u47(UNNAMED_2819735076680[u40], (u46(u41, 127)))] = u17[UNNAMED_2819735043608[u40]];
                                                else
                                                    u39[u47(UNNAMED_2819735043608[u40], (u46(u40, 127)))][UNNAMED_2819735076680[u40]] = u39[UNNAMED_2819735040584[u40]];
                                                end;
                                            elseif v62 >= 67 then
                                                if v62 == 68 then
                                                    u39[u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735052104[u40], u40, u41), 127)))] = u39[u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], 121), 127)))] - UNNAMED_2819735043224[u40];
                                                else
                                                    u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u40, 86, UNNAMED_2819735052104[u40]), 127)))] = u39[UNNAMED_2819735040584[u40]] == u47(UNNAMED_2819735076680[u40], (u46(u47(u41, 26, u40), 127)));
                                                end;
                                            else
                                                u39[31] = u39[20] + 44041505;
                                                local v330 = u39[UNNAMED_2819735052104[u40 + 1]];
                                                local v331 = u46(207279645, 4294967295);
                                                local v332 = u46(v330, 4294967295);
                                                local v333 = u46(v331, 65535);
                                                local v334 = u45(v331, 16);
                                                local v335 = u46(v332, 65535);
                                                local v336 = u45(v332, 16);
                                                local v337 = u46(v333 * v335 + u48(u46(v333 * v336 + v334 * v335, 65535), 16), 4294967295) % 4294967296;
                                                u39[30] = v337 ~= v337 and 0 or v337 - v337 % 1;
                                                u39[21] = UNNAMED_2819735034344[u40] + u39[30];
                                                u39[29] = u37;
                                                u39[UNNAMED_2819735043608[u40 + 1]] = u47(u39[UNNAMED_2819735076680[u40 + 1]], u39[27]);
                                                u39[UNNAMED_2819735043608[u40]] = u35;
                                                u39[29] = u39[29] + 386030234;
                                                u39[29] = u39[29] ~= 219821230;
                                                u40 = u40 + 1;
                                            end;
                                        elseif v62 < 75 then
                                            if v62 < 73 then
                                                u39[29] = UNNAMED_2819735052104[u40 + 1] + u39[29];
                                                u39[UNNAMED_2819735052104[u40 + 2]] = u39[UNNAMED_2819735043608[u40]] - 1023;
                                                u39[30] = 2 ^ u39[31];
                                                u39[29] = u39[29] * u39[UNNAMED_2819735076680[u40]];
                                                u39[31] = 2 * u39[4];
                                                u39[30] = 1 - u39[31];
                                                u39[29] = u39[UNNAMED_2819735043608[u40 + 2]] * u39[UNNAMED_2819735043608[u40 + 1]];
                                                u39[4] = u39[UNNAMED_2819735076680[u40 + 1]] % u39[29];
                                                u39[UNNAMED_2819735076680[u40 + 2]] = UNNAMED_2819735040584[u40];
                                                u40 = u40 + 2;
                                            elseif v62 == 74 then
                                                u39[u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], u40, u41), 127)))] = u49(UNNAMED_2819735040584[u40], u39[UNNAMED_2819735076680[u40]]);
                                            else
                                                u39[UNNAMED_2819735052104[u40 + 1]] = u39[30] + u39[UNNAMED_2819735052104[u40 + 2]];
                                                local v338 = u39[29] % 4294967296;
                                                u39[UNNAMED_2819735076680[u40]] = v338 ~= v338 and 0 or v338 - v338 % 1;
                                                u39[31] = u39[20] + UNNAMED_2819735034344[u40];
                                                local v339 = UNNAMED_2819735043608[u40 + 2];
                                                local v340 = u39[31];
                                                local v341 = u46(310640981, 4294967295);
                                                local v342 = u46(v340, 4294967295);
                                                local v343 = u46(v341, 65535);
                                                local v344 = u45(v341, 16);
                                                local v345 = u46(v342, 65535);
                                                local v346 = u45(v342, 16);
                                                local v347 = u46(v343 * v345 + u48(u46(v343 * v346 + v344 * v345, 65535), 16), 4294967295) % 4294967296;
                                                u39[v339] = v347 ~= v347 and 0 or v347 - v347 % 1;
                                                u39[20] = UNNAMED_2819735076680[u40 + 1] + u39[30];
                                                u39[30] = u37;
                                                u39[30] = u39[27] + u39[30];
                                                local v348 = u39[UNNAMED_2819735043608[u40 + 1]] % 4294967296;
                                                u39[27] = v348 ~= v348 and 0 or v348 - v348 % 1;
                                                u39[UNNAMED_2819735076680[u40 + 2]] = u49(UNNAMED_2819735034344[u40 + 2], u39[31]);
                                                local v349 = u39[30];
                                                local v350 = u46(UNNAMED_2819735043224[u40], 4294967295);
                                                local v351 = u46(v349, 4294967295);
                                                local v352 = u46(v350, 65535);
                                                local v353 = u45(v350, 16);
                                                local v354 = u46(v351, 65535);
                                                local v355 = u45(v351, 16);
                                                local v356 = u46(v352 * v354 + u48(u46(v352 * v355 + v353 * v354, 65535), 16), 4294967295) % 4294967296;
                                                u39[21] = v356 ~= v356 and 0 or v356 - v356 % 1;
                                                u40 = u40 + 2;
                                            end;
                                        elseif v62 < 77 then
                                            if v62 == 76 then
                                                local v357 = u39[32];
                                                local v358 = u46(UNNAMED_2819735043224[u40 + 1], 4294967295);
                                                local v359 = u46(v357, 4294967295);
                                                local v360 = u46(v358, 65535);
                                                local v361 = u45(v358, 16);
                                                local v362 = u46(v359, 65535);
                                                local v363 = u45(v359, 16);
                                                local v364 = u46(v360 * v362 + u48(u46(v360 * v363 + v361 * v362, 65535), 16), 4294967295) % 4294967296;
                                                u39[30] = v364 ~= v364 and 0 or v364 - v364 % 1;
                                                u39[31] = u47(UNNAMED_2819735034344[u40], u39[31]);
                                                local v365 = u39[31];
                                                local v366 = u46(UNNAMED_2819735043224[u40 + 2], 4294967295);
                                                local v367 = u46(v365, 4294967295);
                                                local v368 = u46(v366, 65535);
                                                local v369 = u45(v366, 16);
                                                local v370 = u46(v367, 65535);
                                                local v371 = u45(v367, 16);
                                                local v372 = u46(v368 * v370 + u48(u46(v368 * v371 + v369 * v370, 65535), 16), 4294967295) % 4294967296;
                                                u39[31] = v372 ~= v372 and 0 or v372 - v372 % 1;
                                                u39[30] = u39[UNNAMED_2819735052104[u40 + 1]] + u39[31];
                                                u39[29] = u39[UNNAMED_2819735052104[u40 + 2]] + u39[UNNAMED_2819735076680[u40]];
                                                local v373 = u39[29] % 4294967296;
                                                u39[6] = v373 ~= v373 and 0 or v373 - v373 % 1;
                                                u39[UNNAMED_2819735040584[u40 + 2]] = u39[UNNAMED_2819735076680[u40 + 2]] + UNNAMED_2819735051336[u40 + 1];
                                                local v374 = u39[21];
                                                local v375 = u46(365667578, 4294967295);
                                                local v376 = u46(v374, 4294967295);
                                                local v377 = u46(v375, 65535);
                                                local v378 = u45(v375, 16);
                                                local v379 = u46(v376, 65535);
                                                local v380 = u45(v376, 16);
                                                local v381 = u46(v377 * v379 + u48(u46(v377 * v380 + v378 * v379, 65535), 16), 4294967295) % 4294967296;
                                                u39[30] = v381 ~= v381 and 0 or v381 - v381 % 1;
                                                u40 = u40 + 2;
                                            else
                                                u39[u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735052104[u40], u41, 19), 127)))] = u46(u39[UNNAMED_2819735043608[u40]], u39[u47(UNNAMED_2819735076680[u40], 98)]);
                                            end;
                                        elseif v62 == 78 then
                                            u39[30] = u39[UNNAMED_2819735052104[u40 + 1]] + u39[31];
                                            u39[29] = u39[UNNAMED_2819735052104[u40 + 2]] + u39[30];
                                            local v382 = u39[UNNAMED_2819735043608[u40]] % 4294967296;
                                            u39[7] = v382 ~= v382 and 0 or v382 - v382 % 1;
                                            u39[31] = u39[UNNAMED_2819735043608[u40 + 2]] + UNNAMED_2819735076680[u40 + 2];
                                            local v383 = UNNAMED_2819735040584[u40 + 2];
                                            local v384 = u39[31];
                                            local v385 = u46(84674327, 4294967295);
                                            local v386 = u46(v384, 4294967295);
                                            local v387 = u46(v385, 65535);
                                            local v388 = u45(v385, 16);
                                            local v389 = u46(v386, 65535);
                                            local v390 = u45(v386, 16);
                                            local v391 = u46(v387 * v389 + u48(u46(v387 * v390 + v388 * v389, 65535), 16), 4294967295) % 4294967296;
                                            u39[v383] = v391 ~= v391 and 0 or v391 - v391 % 1;
                                            u39[29] = UNNAMED_2819735034344[u40] + u39[UNNAMED_2819735040584[u40 + 1]];
                                            u39[32] = u49(UNNAMED_2819735076680[u40], u39[31]);
                                            local v392 = u39[32];
                                            local v393 = u46(UNNAMED_2819735043224[u40 + 1], 4294967295);
                                            local v394 = u46(v392, 4294967295);
                                            local v395 = u46(v393, 65535);
                                            local v396 = u45(v393, 16);
                                            local v397 = u46(v394, 65535);
                                            local v398 = u45(v394, 16);
                                            local v399 = u46(v395 * v397 + u48(u46(v395 * v398 + v396 * v397, 65535), 16), 4294967295) % 4294967296;
                                            u39[30] = v399 ~= v399 and 0 or v399 - v399 % 1;
                                            u39[31] = u46(310274988, u39[UNNAMED_2819735076680[u40 + 1]]);
                                            u40 = u40 + 2;
                                        else
                                            local v400;

                                            if u39[UNNAMED_2819735043608[u40]] then
                                                v400 = u47(UNNAMED_2819735076680[u40], (u46(u47(35, u41), 127)));
                                            else
                                                v400 = UNNAMED_2819735040584[u40];
                                            end;

                                            u40 = v400;
                                        end;
                                    elseif v62 < 59 then
                                        if v62 < 56 then
                                            if v62 >= 54 then
                                                if v62 == 55 then
                                                    local v401 = UNNAMED_2819735043608[u40] + 1;
                                                    local v402 = u47(UNNAMED_2819735076680[u40], (u46(u47(u37, (u46(u45(u37, 29), 7))), 536870911)));

                                                    for i = 1, UNNAMED_2819735040584[u40] do
                                                        local v403 = u46(u47(v402, (u48(v402, 13))), 536870911);
                                                        local v404 = u47(v403, (u45(v403, 13)));
                                                        v402 = u46(u47(v404, (u48(v404, 14))), 536870911);
                                                        UNNAMED_2819735043608[v401] = u47(UNNAMED_2819735043608[v401], (u46(u45(v402, 0), 127)));
                                                        UNNAMED_2819735076680[v401] = u47(UNNAMED_2819735076680[v401], (u46(u45(v402, 7), 127)));
                                                        UNNAMED_2819735040584[v401] = u47(UNNAMED_2819735040584[v401], (u46(u45(v402, 14), 127)));
                                                        UNNAMED_2819735052104[v401] = u47(UNNAMED_2819735052104[v401], (u46(u45(v402, 21), 127)));
                                                        v401 = v401 + 1;
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819735052104[u40] = 26;
                                                else
                                                    u39[UNNAMED_2819735076680[u40]] = u49(u39[UNNAMED_2819735040584[u40]], u39[u47(UNNAMED_2819735043608[u40], (u46(u47(126, u41), 127)))]);
                                                end;
                                            else
                                                u39[u47(UNNAMED_2819735043608[u40], (u46(u47(58, u41), 127)))] = u39[UNNAMED_2819735040584[u40]] - u39[u47(UNNAMED_2819735076680[u40], (u46(u47(72, u40, u41), 127)))];
                                            end;
                                        elseif v62 >= 57 then
                                            if v62 == 58 then
                                                local v405 = u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735052104[u40], 127)));
                                                local v406 = u39[UNNAMED_2819735076680[u40]];
                                                u39[v405] = UNNAMED_2819735043608[u40];
                                                u39[v405 + 1] = v406;
                                            else
                                                u39[u47(UNNAMED_2819735076680[u40], (u46(u47(u40, UNNAMED_2819735052104[u40], u41), 127)))] = UNNAMED_2819735043224[u40] + UNNAMED_2819735034344[u40];
                                            end;
                                        else
                                            local v407 = u47(UNNAMED_2819735043608[u40], (u46(u47(u41, UNNAMED_2819735052104[u40]), 127)));
                                            local v408 = u47(UNNAMED_2819735076680[u40], (u46(u47(u40, 41, u41), 127)));
                                            local v409 = u39[UNNAMED_2819735040584[u40]];
                                            local v410 = u46(v408, 4294967295);
                                            local v411 = u46(v409, 4294967295);
                                            local v412 = u46(v410, 65535);
                                            local v413 = u45(v410, 16);
                                            local v414 = u46(v411, 65535);
                                            local v415 = u45(v411, 16);
                                            local v416 = u46(v412 * v414 + u48(u46(v412 * v415 + v413 * v414, 65535), 16), 4294967295) % 4294967296;
                                            u39[v407] = v416 ~= v416 and 0 or v416 - v416 % 1;
                                        end;
                                    elseif v62 >= 62 then
                                        if v62 < 64 then
                                            if v62 == 63 then
                                                u39[UNNAMED_2819735040584[u40]] = u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u40, 57), 127)))][u47(UNNAMED_2819735076680[u40], (u46(u40, 127)))];
                                            else
                                                u39[u47(UNNAMED_2819735076680[u40], 115)] = u37;
                                            end;
                                        elseif v62 == 65 then
                                            u35 = u39[u47(UNNAMED_2819735040584[u40], (u46(u47(u41, u40), 127)))];
                                        else
                                            u40 = u47(UNNAMED_2819735043608[u40], (u46(u47(u41, 89), 127)));
                                        end;
                                    elseif v62 < 60 then
                                        local v417 = UNNAMED_2819735076680[u40];
                                        local v418 = u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], 88), 127)));
                                        u44(u39, v417 + 1, v417 + v418, UNNAMED_2819735040584[u40] + 1, u39[v417]);
                                    elseif v62 == 61 then
                                        u39[u47(UNNAMED_2819735043608[u40], (u46(u41, 127)))] = UNNAMED_2819735076680[u40] + u39[u47(UNNAMED_2819735040584[u40], (u46(u47(u41, 108, UNNAMED_2819735052104[u40]), 127)))];
                                    else
                                        u39[u47(UNNAMED_2819735043608[u40], (u46(UNNAMED_2819735052104[u40], 127)))] = u39[UNNAMED_2819735040584[u40]] % u39[UNNAMED_2819735076680[u40]];
                                    end;
                                else
                                    if v62 >= 92 then
                                        if v62 < 99 then
                                            if v62 >= 95 then
                                                if v62 >= 97 then
                                                    if v62 == 98 then
                                                        u39[u47(UNNAMED_2819735040584[u40], (u46(u47(2, u41), 127)))] = u47(u39[u47(UNNAMED_2819735043608[u40], 68)], UNNAMED_2819735051336[u40]);
                                                    else
                                                        u39[31] = u39[20] + UNNAMED_2819735034344[u40 + 2];
                                                        local v419 = u39[31];
                                                        local v420 = u46(UNNAMED_2819735043224[u40 + 3], 4294967295);
                                                        local v421 = u46(v419, 4294967295);
                                                        local v422 = u46(v420, 65535);
                                                        local v423 = u45(v420, 16);
                                                        local v424 = u46(v421, 65535);
                                                        local v425 = u45(v421, 16);
                                                        local v426 = u46(v422 * v424 + u48(u46(v422 * v425 + v423 * v424, 65535), 16), 4294967295) % 4294967296;
                                                        u39[30] = v426 ~= v426 and 0 or v426 - v426 % 1;
                                                        u39[29] = UNNAMED_2819735034344[u40 + 3] + u39[UNNAMED_2819735052104[u40 + 3]];
                                                        u39[32] = u49(UNNAMED_2819735043224[u40 + 2], u39[31]);
                                                        local v427 = u39[32];
                                                        local v428 = u46(UNNAMED_2819735051336[u40 + 1], 4294967295);
                                                        local v429 = u46(v427, 4294967295);
                                                        local v430 = u46(v428, 65535);
                                                        local v431 = u45(v428, 16);
                                                        local v432 = u46(v429, 65535);
                                                        local v433 = u45(v429, 16);
                                                        local v434 = u46(v430 * v432 + u48(u46(v430 * v433 + v431 * v432, 65535), 16), 4294967295) % 4294967296;
                                                        u39[30] = v434 ~= v434 and 0 or v434 - v434 % 1;
                                                        u39[UNNAMED_2819735052104[u40 + 1]] = u37;
                                                        u39[33] = u39[UNNAMED_2819735052104[u40 + 2]] + u39[UNNAMED_2819735076680[u40]];
                                                        local v435 = u39[UNNAMED_2819735076680[u40 + 2]] % 4294967296;
                                                        u39[27] = v435 ~= v435 and 0 or v435 - v435 % 1;
                                                        u39[UNNAMED_2819735076680[u40 + 3]] = u47(UNNAMED_2819735034344[u40], u39[31]);
                                                        local v436 = u39[31];
                                                        local v437 = u46(UNNAMED_2819735043224[u40 + 1], 4294967295);
                                                        local v438 = u46(v436, 4294967295);
                                                        local v439 = u46(v437, 65535);
                                                        local v440 = u45(v437, 16);
                                                        local v441 = u46(v438, 65535);
                                                        local v442 = u45(v438, 16);
                                                        local v443 = u46(v439 * v441 + u48(u46(v439 * v442 + v440 * v441, 65535), 16), 4294967295) % 4294967296;
                                                        u39[31] = v443 ~= v443 and 0 or v443 - v443 % 1;
                                                        u39[UNNAMED_2819735040584[u40 + 1]] = u39[30] + u39[UNNAMED_2819735043608[u40]];
                                                        u39[29] = u39[29] + u39[30];
                                                        u40 = u40 + 3;
                                                    end;
                                                elseif v62 == 96 then
                                                    u39[UNNAMED_2819735043608[u40]] = u39[UNNAMED_2819735076680[u40]] ~= u39[u47(UNNAMED_2819735040584[u40], (u46(u47(2, UNNAMED_2819735052104[u40]), 127)))];
                                                else
                                                    u39[u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], u41, 126), 127)))] = u39[u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735052104[u40], 127)))] + u39[u47(UNNAMED_2819735076680[u40], (u46(u47(102, u40, UNNAMED_2819735052104[u40]), 127)))];
                                                end;
                                            elseif v62 < 93 then
                                                u39[u47(UNNAMED_2819735040584[u40], 93)] = u39[u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], 23, u40), 127)))] / UNNAMED_2819735043224[u40];
                                            elseif v62 == 94 then
                                                u39[u47(UNNAMED_2819735040584[u40], 73)] = u46(u47(UNNAMED_2819735043608[u40], (u46(u47(u41, UNNAMED_2819735052104[u40]), 127))), u39[UNNAMED_2819735076680[u40]]);
                                            else
                                                local v444 = UNNAMED_2819735040584[u40];
                                                local v445 = u47(u37, u46(u45(u37, 14), 262143), (u46(u45(u37, 28), 15)));
                                                local v446 = UNNAMED_2819735076680[u40];
                                                local v447 = UNNAMED_2819735043608[u40];
                                                local v448 = v444 < 2097152 and 7 or 14;
                                                local v449 = u46(v444, u48(1, v448) - 1);
                                                local v450 = u45(v444, v448);
                                                UNNAMED_2819735043608[u40] = u47(v447, 89, (u46(v445, 127)));
                                                UNNAMED_2819735040584[u40] = u47(v449, 66, (u46(u45(v445, 14), 127)));
                                                UNNAMED_2819735076680[u40] = u47(v446, 79, (u46(u45(v445, 7), 127)));
                                                UNNAMED_2819735052104[u40] = u47(v450, 106, (u46(u45(v445, 21), 127)));
                                                u40 = u40 - 1;
                                            end;
                                        elseif v62 < 102 then
                                            if v62 >= 100 then
                                                if v62 == 101 then
                                                    u39[UNNAMED_2819735043608[u40]] = u39[u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735052104[u40], 127)))] == u39[u47(UNNAMED_2819735076680[u40], (u46(u47(88, u41), 127)))];
                                                else
                                                    u37 = u39[u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735052104[u40], u40), 127)))];
                                                end;
                                            else
                                                local v451 = u47(UNNAMED_2819735043608[u40], (u46(u47(95, u40, u41), 127)));
                                                local v452 = u39[u47(UNNAMED_2819735040584[u40], (u46(u47(94, u40), 127)))] % 4294967296;
                                                u39[v451] = v452 ~= v452 and 0 or v452 - v452 % 1;
                                            end;
                                        elseif v62 < 104 then
                                            if v62 == 103 then
                                                u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u40, UNNAMED_2819735052104[u40], 45), 127)))] = u47(UNNAMED_2819735034344[u40], u39[u47(UNNAMED_2819735076680[u40], (u46(u47(99, u41, UNNAMED_2819735052104[u40]), 127)))]);
                                            else
                                                u39[30] = 2 ^ u39[31];
                                                u39[29] = u39[29] * u39[30];
                                                u39[31] = 2 * u39[8];
                                                u39[30] = UNNAMED_2819735052104[u40 + 1] - u39[31];
                                                u39[29] = u39[30] * u39[29];
                                                u39[32] = UNNAMED_2819735051336[u40] + UNNAMED_2819735043224[u40 + 1];
                                                u39[33] = u39[UNNAMED_2819735040584[u40 + 1]] - u39[32];
                                                u39[UNNAMED_2819735076680[u40 + 1]] = u39[29] + 0;
                                                u40 = u40 + 1;
                                            end;
                                        elseif v62 == 105 then
                                            local v453 = UNNAMED_2819735076680[u40];
                                            local v454 = u39[u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], u41), 127)))];
                                            local v455 = u47(UNNAMED_2819735040584[u40], (u46(u47(21, u40), 127)));
                                            u39[v453] = v454;
                                            u39[v453 + 1] = v455;
                                        else
                                            u39[u47(UNNAMED_2819735043608[u40], (u46(u47(u40, 33, u41), 127)))] = u46(UNNAMED_2819735051336[u40], u39[UNNAMED_2819735040584[u40]]);
                                        end;

                                        v61 = 1;
                                        continue;
                                    end;

                                    if v62 < 85 then
                                        if v62 < 82 then
                                            if v62 < 80 then
                                                u39[u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], u41), 127)))] = u50(u39[u47(UNNAMED_2819735040584[u40], 108)]);
                                            elseif v62 == 81 then
                                                u39[u47(UNNAMED_2819735040584[u40], (u46(u47(u41, UNNAMED_2819735052104[u40]), 127)))] = u35;
                                            else
                                                local v456 = UNNAMED_2819735040584[u40];
                                                local v457 = u39[UNNAMED_2819735043608[u40]];
                                                local v458 = u39[u47(UNNAMED_2819735076680[u40], (u46(u40, 127)))];
                                                local v459 = u46(v457, 4294967295);
                                                local v460 = u46(v458, 4294967295);
                                                local v461 = u46(v459, 65535);
                                                local v462 = u45(v459, 16);
                                                local v463 = u46(v460, 65535);
                                                local v464 = u45(v460, 16);
                                                local v465 = u46(v461 * v463 + u48(u46(v461 * v464 + v462 * v463, 65535), 16), 4294967295) % 4294967296;
                                                u39[v456] = v465 ~= v465 and 0 or v465 - v465 % 1;
                                            end;
                                        elseif v62 < 83 then
                                            u39[UNNAMED_2819735052104[u40 + 1]] = u49(UNNAMED_2819735051336[u40], u39[21]);
                                            local v466 = UNNAMED_2819735052104[u40 + 3];
                                            local v467 = u39[UNNAMED_2819735052104[u40 + 2]];
                                            local v468 = u46(UNNAMED_2819735051336[u40 + 2], 4294967295);
                                            local v469 = u46(v467, 4294967295);
                                            local v470 = u46(v468, 65535);
                                            local v471 = u45(v468, 16);
                                            local v472 = u46(v469, 65535);
                                            local v473 = u45(v469, 16);
                                            local v474 = u46(v470 * v472 + u48(u46(v470 * v473 + v471 * v472, 65535), 16), 4294967295) % 4294967296;
                                            u39[v466] = v474 ~= v474 and 0 or v474 - v474 % 1;
                                            u39[31] = u46(UNNAMED_2819735043224[u40 + 2], u39[21]);
                                            local v475 = UNNAMED_2819735040584[u40 + 3];
                                            local v476 = u39[31];
                                            local v477 = u46(UNNAMED_2819735051336[u40 + 1], 4294967295);
                                            local v478 = u46(v476, 4294967295);
                                            local v479 = u46(v477, 65535);
                                            local v480 = u45(v477, 16);
                                            local v481 = u46(v478, 65535);
                                            local v482 = u45(v478, 16);
                                            local v483 = u46(v479 * v481 + u48(u46(v479 * v482 + v480 * v481, 65535), 16), 4294967295) % 4294967296;
                                            u39[v475] = v483 ~= v483 and 0 or v483 - v483 % 1;
                                            u39[29] = u39[29] + u39[30];
                                            u39[UNNAMED_2819735040584[u40 + 1]] = u39[22] + u39[UNNAMED_2819735076680[u40 + 3]];
                                            local v484 = u39[29] % 4294967296;
                                            u39[4] = v484 ~= v484 and 0 or v484 - v484 % 1;
                                            u39[UNNAMED_2819735043608[u40 + 3]] = u39[20] + UNNAMED_2819735043224[u40];
                                            u40 = u40 + 3;
                                        elseif v62 == 84 then
                                            u39[UNNAMED_2819735040584[u40]] = not u39[u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], u40, 24), 127)))];
                                        else
                                            u39[u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], u40, u41), 127)))] = u39[u47(UNNAMED_2819735043608[u40], (u46(UNNAMED_2819735052104[u40], 127)))] <= u39[u47(UNNAMED_2819735040584[u40], (u46(u47(u41, u40, UNNAMED_2819735052104[u40]), 127)))];
                                        end;

                                        v61 = 1;
                                        continue;
                                    end;

                                    if v62 >= 88 then
                                        if v62 >= 90 then
                                            if v62 == 91 then
                                                local v485 = u47(UNNAMED_2819735076680[u40], (u46(u47(UNNAMED_2819735052104[u40], u40), 127)));
                                                local v486 = u47(UNNAMED_2819735040584[u40], (u46(u47(u40, u41, UNNAMED_2819735052104[u40]), 127)));
                                                local v487 = UNNAMED_2819735043608[u40];
                                                u39[v485] = v486;
                                                u39[v485 + 1] = v487;
                                            else
                                                u39[u47(UNNAMED_2819735043608[u40], (u46(u47(28, u41, UNNAMED_2819735052104[u40]), 127)))] = UNNAMED_2819735076680[u40] * u39[u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735052104[u40], u40), 127)))];
                                            end;

                                            v61 = 1;
                                            continue;
                                        end;

                                        if v62 ~= 89 then
                                            u39[UNNAMED_2819735043608[u40]] = u49(UNNAMED_2819735051336[u40], u39[u47(UNNAMED_2819735040584[u40], (u46(u47(83, u41), 127)))]);
                                            v61 = 1;
                                            continue;
                                        end;

                                        u41 = UNNAMED_2819735040584[u40];
                                        u40 = u47(UNNAMED_2819735076680[u40], 68) + 1;

                                        if u41 == 193 then
                                            v60 = UNNAMED_2819735052104[u40];

                                            return false, true, u51(u39[u47(UNNAMED_2819735043608[u40], (u46(u47(UNNAMED_2819735052104[u40], 66, u40), 127)))]);
                                        end;

                                        return;
                                    end;

                                    if v62 >= 86 then
                                        if v62 == 87 then
                                            u39[u47(UNNAMED_2819735076680[u40], (u46(u40, 127)))] = UNNAMED_2819735031320[UNNAMED_2819735043608[u40]];
                                        else
                                            u39[UNNAMED_2819735043608[u40]] = u39[UNNAMED_2819735040584[u40]] <= u47(UNNAMED_2819735076680[u40], (u46(u40, 127)));
                                        end;
                                    else
                                        u39[u47(UNNAMED_2819735040584[u40], (u46(u41, 127)))] = u39[u47(UNNAMED_2819735076680[u40], (u46(u47(16, u40), 127)))] + UNNAMED_2819735043608[u40];
                                    end;
                                end;

                                v61 = 1;
                                continue;
                            elseif v61 == 1 then
                                v61 = -1;
                                u40 = u40 + 1;
                                break;
                            else
                                break;
                            end;
                        end;
                    end;

                    v52 = 4;
                    continue;
                elseif v52 == 4 then
                    v52 = -1;

                    while true do
                        local v488 = UNNAMED_2819735040584[u40];

                        if v488 >= 5 then
                            if v488 >= 7 then
                                if v488 >= 8 then
                                    if v488 == 9 then
                                        local v489 = u47(u37, u46(u45(u37, 14), 262143), (u46(u45(u37, 28), 15)));
                                        local v490 = UNNAMED_2819735043608[u40];
                                        local v491 = UNNAMED_2819735052104[u40];
                                        local v492 = UNNAMED_2819735076680[u40];
                                        local v493 = v491 < 16384 and 7 or (v491 < 2097152 and 14 or 21);
                                        local v494 = u45(v491, v493);
                                        UNNAMED_2819735052104[u40] = u47(u46(v491, u48(1, v493) - 1), 9, (u46(v489, 127)));
                                        UNNAMED_2819735043608[u40] = u47(v490, 68, (u46(u45(v489, 7), 127)));
                                        UNNAMED_2819735076680[u40] = u47(v492, 38, (u46(u45(v489, 14), 127)));
                                        UNNAMED_2819735040584[u40] = u47(v494, 26, (u46(u45(v489, 21), 127)));
                                        u40 = u40 - 1;
                                    elseif u39[u47(UNNAMED_2819735043608[u40], 112)] > u47(UNNAMED_2819735052104[u40], (u46(u47(u41, 2, UNNAMED_2819735040584[u40]), 127))) then
                                        u40 = UNNAMED_2819735076680[u40];
                                    end;
                                end;
                            elseif v488 == 6 then
                                local v495 = UNNAMED_2819735052104[u40] + 1;
                                local v496 = u47(UNNAMED_2819735043608[u40], (u46(u47(u37, (u46(u45(u37, 29), 7))), 536870911)));

                                for i = 1, UNNAMED_2819735076680[u40] do
                                    local v497 = u46(u47(v496, (u48(v496, 13))), 536870911);
                                    local v498 = u47(v497, (u45(v497, 13)));
                                    v496 = u46(u47(v498, (u48(v498, 14))), 536870911);
                                    UNNAMED_2819735052104[v495] = u47(UNNAMED_2819735052104[v495], (u46(u45(v496, 0), 127)));
                                    UNNAMED_2819735043608[v495] = u47(UNNAMED_2819735043608[v495], (u46(u45(v496, 7), 127)));
                                    UNNAMED_2819735076680[v495] = u47(UNNAMED_2819735076680[v495], (u46(u45(v496, 14), 127)));
                                    UNNAMED_2819735040584[v495] = u47(UNNAMED_2819735040584[v495], (u46(u45(v496, 21), 127)));
                                    v495 = v495 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735040584[u40] = 7;
                            else
                                u40 = u47(UNNAMED_2819735052104[u40], (u46(u47(98, u41), 127)));
                            end;
                        elseif v488 >= 2 then
                            if v488 >= 3 then
                                if v488 == 4 then
                                    u40 = u39[u47(UNNAMED_2819735076680[u40], (u46(u47(u41, UNNAMED_2819735040584[u40], 96), 127)))];
                                else
                                    local v499 = UNNAMED_2819735052104[u40] + 1;
                                    local v500 = u47(UNNAMED_2819735043608[u40], (u46(u47(u35, (u46(u45(u35, 29), 7))), 536870911)));

                                    for i = 1, UNNAMED_2819735076680[u40] do
                                        local v501 = u46(u47(v500, (u48(v500, 13))), 536870911);
                                        local v502 = u47(v501, (u45(v501, 13)));
                                        v500 = u46(u47(v502, (u48(v502, 14))), 536870911);
                                        UNNAMED_2819735052104[v499] = u47(UNNAMED_2819735052104[v499], (u46(u45(v500, 0), 127)));
                                        UNNAMED_2819735043608[v499] = u47(UNNAMED_2819735043608[v499], (u46(u45(v500, 7), 127)));
                                        UNNAMED_2819735076680[v499] = u47(UNNAMED_2819735076680[v499], (u46(u45(v500, 14), 127)));
                                        UNNAMED_2819735040584[v499] = u47(UNNAMED_2819735040584[v499], (u46(u45(v500, 21), 127)));
                                        v499 = v499 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735040584[u40] = 7;
                                end;
                            else
                                u39[UNNAMED_2819735076680[u40]] = UNNAMED_2819735052104[u40];
                            end;
                        else
                            if v488 == 1 then
                                u41 = u47(UNNAMED_2819735043608[u40], (u46(UNNAMED_2819735040584[u40], 127)));
                                u40 = u47(UNNAMED_2819735052104[u40], (u46(u47(54, UNNAMED_2819735040584[u40]), 127))) + 1;
                                v52 = 3;
                                break;
                            end;

                            local v503 = UNNAMED_2819735043608[u40] + 1;
                            local v504 = UNNAMED_2819735052104[u40];

                            for i = 1, UNNAMED_2819735076680[u40] do
                                local v505 = u46(u47(v504, (u48(v504, 13))), 536870911);
                                local v506 = u47(v505, (u45(v505, 13)));
                                v504 = u46(u47(v506, (u48(v506, 14))), 536870911);
                                UNNAMED_2819735052104[v503] = u47(UNNAMED_2819735052104[v503], (u46(u45(v504, 0), 127)));
                                UNNAMED_2819735043608[v503] = u47(UNNAMED_2819735043608[v503], (u46(u45(v504, 7), 127)));
                                UNNAMED_2819735076680[v503] = u47(UNNAMED_2819735076680[v503], (u46(u45(v504, 14), 127)));
                                UNNAMED_2819735040584[v503] = u47(UNNAMED_2819735040584[v503], (u46(u45(v504, 21), 127)));
                                v503 = v503 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735040584[u40] = 7;
                        end;

                        u40 = u40 + 1;
                    end;

                    if v52 ~= -1 then
                        continue;
                    end;

                    v52 = 5;
                    continue;
                elseif v52 == 5 then
                    v52 = -1;

                    while true do
                        local u40;
                        local v507 = 0;

                        while true do
                            if v507 == 0 then
                                v507 = -1;
                                local v508 = UNNAMED_2819735043608[u40];

                                if v508 < 5 then
                                    if v508 >= 2 then
                                        if v508 < 3 then
                                            local v509 = UNNAMED_2819735040584[u40] + 1;
                                            local v510 = UNNAMED_2819735052104[u40];

                                            for i = 1, UNNAMED_2819735076680[u40] do
                                                local v511 = u46(u47(v510, (u48(v510, 13))), 536870911);
                                                local v512 = u47(v511, (u45(v511, 13)));
                                                v510 = u46(u47(v512, (u48(v512, 14))), 536870911);
                                                UNNAMED_2819735052104[v509] = u47(UNNAMED_2819735052104[v509], (u46(u45(v510, 0), 127)));
                                                UNNAMED_2819735040584[v509] = u47(UNNAMED_2819735040584[v509], (u46(u45(v510, 7), 127)));
                                                UNNAMED_2819735076680[v509] = u47(UNNAMED_2819735076680[v509], (u46(u45(v510, 14), 127)));
                                                UNNAMED_2819735043608[v509] = u47(UNNAMED_2819735043608[v509], (u46(u45(v510, 21), 127)));
                                                v509 = v509 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735043608[u40] = 4;
                                        elseif v508 ~= 4 then
                                            local v513 = UNNAMED_2819735052104[u40] + 1;
                                            local v514 = u47(UNNAMED_2819735040584[u40], (u46(u47(u36, (u46(u45(u36, 29), 7))), 536870911)));

                                            for i = 1, UNNAMED_2819735076680[u40] do
                                                local v515 = u46(u47(v514, (u48(v514, 13))), 536870911);
                                                local v516 = u47(v515, (u45(v515, 13)));
                                                v514 = u46(u47(v516, (u48(v516, 14))), 536870911);
                                                UNNAMED_2819735052104[v513] = u47(UNNAMED_2819735052104[v513], (u46(u45(v514, 0), 127)));
                                                UNNAMED_2819735040584[v513] = u47(UNNAMED_2819735040584[v513], (u46(u45(v514, 7), 127)));
                                                UNNAMED_2819735076680[v513] = u47(UNNAMED_2819735076680[v513], (u46(u45(v514, 14), 127)));
                                                UNNAMED_2819735043608[v513] = u47(UNNAMED_2819735043608[v513], (u46(u45(v514, 21), 127)));
                                                v513 = v513 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735043608[u40] = 4;
                                        end;
                                    elseif v508 == 1 then
                                        if u39[u47(UNNAMED_2819735052104[u40], (u46(u41, 127)))] > UNNAMED_2819735076680[u40] then
                                            u40 = u47(UNNAMED_2819735040584[u40], (u46(u47(101, UNNAMED_2819735043608[u40], u41), 127)));
                                        end;
                                    else
                                        u39[u47(UNNAMED_2819735052104[u40], (u46(u47(UNNAMED_2819735043608[u40], 80), 127)))] = u39[u47(UNNAMED_2819735076680[u40], (u46(u41, 127)))];
                                    end;
                                else
                                    if v508 < 8 then
                                        if v508 < 6 then
                                            u40 = u47(UNNAMED_2819735052104[u40], (u46(u47(UNNAMED_2819735043608[u40], 77), 127)));
                                            v507 = 1;
                                            continue;
                                        end;

                                        if v508 ~= 7 then
                                            local v517 = u47(u36, u46(u45(u36, 14), 262143), (u46(u45(u36, 28), 15)));
                                            local v518 = UNNAMED_2819735040584[u40];
                                            local v519 = UNNAMED_2819735076680[u40];
                                            local v520 = UNNAMED_2819735052104[u40];
                                            local v521 = v518 < 16384 and 7 or (v518 < 2097152 and 14 or 21);
                                            local v522 = u45(v518, v521);
                                            local v523 = u46(v518, u48(1, v521) - 1);
                                            UNNAMED_2819735076680[u40] = u47(v519, 56, (u46(u45(v517, 14), 127)));
                                            UNNAMED_2819735052104[u40] = u47(v520, 40, (u46(v517, 127)));
                                            UNNAMED_2819735040584[u40] = u47(v523, 82, (u46(u45(v517, 7), 127)));
                                            UNNAMED_2819735043608[u40] = u47(v522, 7, (u46(u45(v517, 21), 127)));
                                            u40 = u40 - 1;
                                            v507 = 1;
                                            continue;
                                        end;

                                        u41 = UNNAMED_2819735052104[u40];
                                        u40 = u47(UNNAMED_2819735040584[u40], (u46(u47(UNNAMED_2819735043608[u40], 97), 127))) + 1;
                                        v52 = 2;
                                        break;
                                    end;

                                    if v508 < 9 then
                                        u40 = u39[u47(UNNAMED_2819735052104[u40], (u46(u47(37, u41, UNNAMED_2819735043608[u40]), 127)))];
                                    elseif v508 == 10 then
                                        u39[UNNAMED_2819735076680[u40]] = UNNAMED_2819735040584[u40];
                                    else
                                        local v524 = u47(UNNAMED_2819735040584[u40], (u46(u40, 127)));
                                        local v525 = u39[UNNAMED_2819735052104[u40]];
                                        u39[v524] = u39[UNNAMED_2819735076680[u40]];
                                        u39[v524 + 1] = v525;
                                    end;
                                end;

                                v507 = 1;
                                continue;
                            elseif v507 == 1 then
                                v507 = -1;
                                u40 = u40 + 1;
                                break;
                            else
                                break;
                            end;
                        end;

                        if v52 ~= -1 then
                            break;
                        end;
                    end;

                    if v52 ~= -1 then
                        continue;
                    end;

                    v52 = 6;
                    continue;
                elseif v52 == 6 then
                    v52 = -1;

                    while true do
                        local u40;
                        local v526 = 0;

                        while true do
                            if v526 == 0 then
                                v526 = -1;
                                local v527 = UNNAMED_2819735043608[u40];

                                if v527 < 6 then
                                    if v527 >= 3 then
                                        if v527 >= 4 then
                                            if v527 == 5 then
                                                local v528 = u47(u35, u46(u45(u35, 14), 262143), (u46(u45(u35, 28), 15)));
                                                local v529 = UNNAMED_2819735052104[u40];
                                                local v530 = UNNAMED_2819735040584[u40];
                                                local v531 = UNNAMED_2819735076680[u40];
                                                local v532 = v529 < 16384 and 7 or (v529 < 2097152 and 14 or 21);
                                                local v533 = u45(v529, v532);
                                                local v534 = u46(v529, u48(1, v532) - 1);
                                                UNNAMED_2819735043608[u40] = u47(v533, 2, (u46(u45(v528, 21), 127)));
                                                UNNAMED_2819735076680[u40] = u47(v531, 21, (u46(u45(v528, 14), 127)));
                                                UNNAMED_2819735052104[u40] = u47(v534, 97, (u46(u45(v528, 7), 127)));
                                                UNNAMED_2819735040584[u40] = u47(v530, 88, (u46(v528, 127)));
                                                u40 = u40 - 1;
                                            else
                                                local v535 = UNNAMED_2819735052104[u40];
                                                local v536 = u39[UNNAMED_2819735076680[u40]];
                                                local v537 = u39[u47(UNNAMED_2819735040584[u40], 59)];
                                                u39[v535] = v536;
                                                u39[v535 + 1] = v537;
                                            end;
                                        else
                                            local v538 = u47(UNNAMED_2819735052104[u40], (u46(u47(u41, 8), 127)));
                                            u44({ ... }, 1, UNNAMED_2819735076680[u40], v538, u39);
                                        end;
                                    elseif v527 >= 1 then
                                        if v527 == 2 then
                                            u39[u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735043608[u40], 127)))] = u39[UNNAMED_2819735052104[u40]];
                                        else
                                            u40 = u47(UNNAMED_2819735076680[u40], (u46(u47(71, u41, UNNAMED_2819735043608[u40]), 127)));
                                        end;
                                    end;
                                elseif v527 < 9 then
                                    if v527 >= 7 then
                                        if v527 == 8 then
                                            local v539 = UNNAMED_2819735052104[u40] + 1;
                                            local v540 = UNNAMED_2819735076680[u40];

                                            for i = 1, UNNAMED_2819735040584[u40] do
                                                local v541 = u46(u47(v540, (u48(v540, 13))), 536870911);
                                                local v542 = u47(v541, (u45(v541, 13)));
                                                v540 = u46(u47(v542, (u48(v542, 14))), 536870911);
                                                UNNAMED_2819735040584[v539] = u47(UNNAMED_2819735040584[v539], (u46(u45(v540, 0), 127)));
                                                UNNAMED_2819735052104[v539] = u47(UNNAMED_2819735052104[v539], (u46(u45(v540, 7), 127)));
                                                UNNAMED_2819735076680[v539] = u47(UNNAMED_2819735076680[v539], (u46(u45(v540, 14), 127)));
                                                UNNAMED_2819735043608[v539] = u47(UNNAMED_2819735043608[v539], (u46(u45(v540, 21), 127)));
                                                v539 = v539 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735043608[u40] = 0;
                                        else
                                            u39[u47(UNNAMED_2819735052104[u40], 22)] = u47(UNNAMED_2819735076680[u40], (u46(u47(u41, UNNAMED_2819735043608[u40]), 127)));
                                        end;
                                    else
                                        u39[UNNAMED_2819735052104[u40]] = UNNAMED_2819735040584[u40];
                                    end;
                                else
                                    if v527 < 10 then
                                        u40 = u39[u47(UNNAMED_2819735076680[u40], 31)];
                                        v526 = 1;
                                        continue;
                                    end;

                                    if v527 ~= 11 then
                                        u41 = UNNAMED_2819735052104[u40];
                                        u40 = u47(UNNAMED_2819735040584[u40], (u46(UNNAMED_2819735043608[u40], 127))) + 1;
                                        v52 = 1;
                                        break;
                                    end;

                                    local v543 = UNNAMED_2819735040584[u40] + 1;
                                    local v544 = u47(UNNAMED_2819735052104[u40], (u46(u47(u35, (u46(u45(u35, 29), 7))), 536870911)));

                                    for i = 1, UNNAMED_2819735076680[u40] do
                                        local v545 = u46(u47(v544, (u48(v544, 13))), 536870911);
                                        local v546 = u47(v545, (u45(v545, 13)));
                                        v544 = u46(u47(v546, (u48(v546, 14))), 536870911);
                                        UNNAMED_2819735040584[v543] = u47(UNNAMED_2819735040584[v543], (u46(u45(v544, 0), 127)));
                                        UNNAMED_2819735052104[v543] = u47(UNNAMED_2819735052104[v543], (u46(u45(v544, 7), 127)));
                                        UNNAMED_2819735076680[v543] = u47(UNNAMED_2819735076680[v543], (u46(u45(v544, 14), 127)));
                                        UNNAMED_2819735043608[v543] = u47(UNNAMED_2819735043608[v543], (u46(u45(v544, 21), 127)));
                                        v543 = v543 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735043608[u40] = 0;
                                end;

                                v526 = 1;
                                continue;
                            elseif v526 == 1 then
                                v526 = -1;
                                u40 = u40 + 1;
                                break;
                            else
                                break;
                            end;
                        end;

                        if v52 ~= -1 then
                            break;
                        end;
                    end;

                    if v52 ~= -1 then
                        continue;
                    end;

                    break;
                else
                    break;
                end;
            end;
        end, ...);

        if v547 then
            if v548 then
                if v549 then
                    return u39[v550](u33(v551, 1, v551.n));
                end;

                return u39[v550](u33(u39, v550 + 1, v551));
            end;

            if v550 then
                if v549 then
                    return u33(v550, 1, v550.n);
                end;

                return u33(u39, v550, v551);
            end;
        else
            u34(UNNAMED_2819735031320, v548, u40, UNNAMED_2819735092760);
        end;
    end;
end;