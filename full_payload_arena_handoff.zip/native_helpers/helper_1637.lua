-- Decompiled with Potassium's decompiler.

local _ = UNNAMED_2819735069528[2];
local v1 = 1;
local v2 = nil;

while true do
    while v1 <= 1 do
        if v1 <= 0 then
            return 1, v2;
        end;

        v1 = UNNAMED_2819735069528[2][7] and 4 or 2;
        local _ = UNNAMED_2819735069528[1];
        local _ = UNNAMED_2819735069528[2];
    end;

    if v1 <= 2 then
        local v3 = UNNAMED_2819735069528[2][6];

        if v3 then
            local _ = UNNAMED_2819735069528[1];
            local _ = UNNAMED_2819735069528[2];
            v2 = v3;
            v1 = 0;
        else
            local _ = UNNAMED_2819735069528[1];
            local _ = UNNAMED_2819735069528[2];
            v1 = 3;
        end;
    else
        if v1 > 3 then
            return 1, UNNAMED_2819735065832[28](UNNAMED_2819735069528[2]);
        end;

        UNNAMED_2819735069528[1] = UNNAMED_2819735069528[2][5];
        v2 = {
            __index = function(p4, p5) -- Line: 3, Name: __index
                -- upvalues: UNNAMED_2819735065832 (copy), UNNAMED_2819735069528 (copy)
                local v6, v7 = UNNAMED_2819735065832:z3(UNNAMED_2819735069528, p5, p4);

                if v6 == 1 then
                    return v7;
                end;
            end
        };
        UNNAMED_2819735069528[2][6] = v2;
        local _ = UNNAMED_2819735069528[1];
        local _ = UNNAMED_2819735069528[2];
        v1 = 0;
    end;
end;