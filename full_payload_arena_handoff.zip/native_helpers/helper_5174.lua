-- Decompiled with Potassium's decompiler.

local v1 = nil;

for i = 3, UNNAMED_2819735060312 do
    v1 = { UNNAMED_2819735052248(UNNAMED_2819735051096, function() -- Line: 50
            -- upvalues: UNNAMED_2819735076056 (ref)
            for i2 = 1, UNNAMED_2819735076056 do
                local _ = i2;
            end;
        end) };
    local _ = i;
end;

return v1[3];