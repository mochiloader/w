-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3, p4, p5) -- Line: 3
    local u6 = p3[1];
    local u7 = p3[2];
    local u8 = p3[3];

    return function() -- Line: 3
        -- upvalues: u6 (copy), u7 (copy), u8 (copy)
        local v9 = 1;

        while v9 > 0 do
            u6[5][u6[4]] = true;
            u7[5][u7[4]] = u7[5][u7[4]] - u7[5][u7[4]] % 2 + 1;
            u8[5][u8[4]] = (57233 * u8[5][u8[4]] + 43236253) % 268435456;
            u8[5][u8[4]] = (45661 * u8[5][u8[4]] + 7259597) % 268435456;
            v9 = 0;
        end;
    end;
end;