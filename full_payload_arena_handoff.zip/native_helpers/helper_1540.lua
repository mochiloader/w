-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819781304056[21];
local u2 = UNNAMED_2819781304056[43];
local u3 = UNNAMED_2819781304056[67];
local u4 = UNNAMED_2819781304056[113];
local u5 = UNNAMED_2819781304056[35];
local u6 = UNNAMED_2819781304056[110];
local u7 = UNNAMED_2819781304056[11];
local u8 = UNNAMED_2819781304056[84];
local u9 = UNNAMED_2819781304056[22];
local u10 = UNNAMED_2819781304056[105];
local u11 = UNNAMED_2819781304056[5];
local u12 = UNNAMED_2819781304056[93];
local u13 = UNNAMED_2819781304056[59];
local u14 = UNNAMED_2819781304056[92];
local u15 = UNNAMED_2819781304056[64];
local P3 = UNNAMED_2819781304056.P3;
local u16 = UNNAMED_2819781304056[47];
local _3 = UNNAMED_2819781304056._3;
local u17 = UNNAMED_2819781304056[117];

return function(u18, u19, p20, u21, p22, p23) -- Line: 3
    -- upvalues: u1 (copy), u2 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u12 (copy), u13 (copy), u14 (copy), u15 (copy), P3 (copy), u16 (copy), _3 (copy), u17 (copy), UNNAMED_2819781304104 (copy), UNNAMED_2819781304152 (copy), UNNAMED_2819781304200 (copy), UNNAMED_2819781304248 (copy), UNNAMED_2819781302040 (copy), UNNAMED_2819781301992 (copy), UNNAMED_2819781304296 (copy), UNNAMED_2819781303816 (copy), UNNAMED_2819781303864 (copy), UNNAMED_2819781303912 (copy), UNNAMED_2819781303960 (copy), UNNAMED_2819781304056 (copy), UNNAMED_2819781304008 (copy)
    local u24 = u1;
    local u25 = u2;
    local u26 = u3;
    local u27 = u4;
    local u28 = u5;
    local u29 = u6;
    local u30 = u7;
    local u31 = u8;
    local u32 = u9;
    local u33 = u10;
    local u34 = u11;
    local u35 = u12;
    local u36 = u13;
    local u37 = u14;
    local u38 = u15;
    local u39 = P3;
    local u40 = u16;
    local u41 = _3;
    local u42 = u17;

    return function(...) -- Line: 3
        -- upvalues: u24 (copy), UNNAMED_2819781304104 (ref), UNNAMED_2819781304152 (ref), UNNAMED_2819781304200 (ref), u19 (copy), u21 (copy), UNNAMED_2819781304248 (ref), UNNAMED_2819781302040 (ref), UNNAMED_2819781301992 (ref), UNNAMED_2819781304296 (ref), UNNAMED_2819781303816 (ref), u18 (copy), u25 (copy), u26 (copy), u27 (copy), UNNAMED_2819781303864 (ref), u30 (copy), u29 (copy), u28 (copy), u31 (copy), UNNAMED_2819781303912 (ref), UNNAMED_2819781303960 (ref), u32 (copy), u33 (copy), u34 (copy), u35 (copy), UNNAMED_2819781304056 (ref), u36 (copy), u37 (copy), UNNAMED_2819781304008 (ref), u38 (copy), u39 (copy), u40 (copy), u41 (copy), u42 (copy)
        local v43, v44, v45, v46, v47, v48, v49, v50, v51, v52, v53, v54, v55, v56;
        local v57 = 0;

        while true do
            if v57 == 0 then
                v57 = -1;
                v48 = nil;
                v49 = nil;
                v50 = nil;
                v51 = nil;
                v52 = u24(UNNAMED_2819781304104);
                v53 = nil;
                v54 = nil;
                v55 = nil;

                if UNNAMED_2819781304152 ~= 104 then
                    v43 = u21;
                    v44 = u19;
                    v45 = UNNAMED_2819781304200;
                    v46 = UNNAMED_2819781304152;
                    v57 = 6;
                    continue;
                end;

                v47 = UNNAMED_2819781304200;
                v44 = u19;
                v43 = u21;
                v57 = 1;
                continue;
            elseif v57 == 1 then
                v57 = -1;
                v56 = UNNAMED_2819781304248[v47];

                if v56 < 36 then
                    v57 = 15;
                    continue;
                end;

                if v56 >= 54 then
                    v57 = 2;
                    continue;
                end;

                if v56 < 45 then
                    if v56 < 40 then
                        if v56 < 38 then
                            if v56 == 37 then
                                if UNNAMED_2819781304296[v47] >= v52[UNNAMED_2819781301992[v47]] then
                                    v47 = UNNAMED_2819781302040[v47];
                                end;
                            elseif v52[UNNAMED_2819781301992[v47]] ~= UNNAMED_2819781304296[v47] then
                                v47 = UNNAMED_2819781302040[v47];
                            end;
                        elseif v56 == 39 then
                            if v52[UNNAMED_2819781302040[v47]] then
                                v47 = UNNAMED_2819781301992[v47];
                            else
                                v47 = UNNAMED_2819781304296[v47];
                            end;
                        else
                            local v58 = UNNAMED_2819781302040[v47];
                            local v59 = u30(v44, u29(u28(v44, 14), 262143), (u29(u28(v44, 28), 15)));
                            local v60 = UNNAMED_2819781301992[v47];
                            local v61 = UNNAMED_2819781304296[v47];
                            local v62 = v60 < 16384 and 7 or (v60 < 2097152 and 14 or 21);
                            local v63 = u29(v60, u31(1, v62) - 1);
                            local v64 = u28(v60, v62);
                            UNNAMED_2819781302040[v47] = u30(v58, 7, (u29(u28(v59, 7), 127)));
                            UNNAMED_2819781304248[v47] = u30(v64, 31, (u29(u28(v59, 21), 127)));
                            UNNAMED_2819781304296[v47] = u30(v61, 111, (u29(u28(v59, 14), 127)));
                            UNNAMED_2819781301992[v47] = u30(v63, 38, (u29(v59, 127)));
                            v47 = v47 - 1;
                        end;
                    elseif v56 < 42 then
                        if v56 == 41 then
                            v52[UNNAMED_2819781302040[v47]]();
                        else
                            local v65 = u18[UNNAMED_2819781301992[v47]];
                            v65[5][v65[4]] = v52[UNNAMED_2819781304296[v47]];
                        end;
                    elseif v56 >= 43 then
                        if v56 == 44 then
                            v47 = v52[UNNAMED_2819781304296[v47]];
                        else
                            local v66 = UNNAMED_2819781304296[v47];
                            local v67 = UNNAMED_2819781301992[v47];
                            local v68 = UNNAMED_2819781303960[5];
                            local v69 = u30(v68[v66], 109162203);
                            v68[v66] = v69;
                            local v70 = UNNAMED_2819781303960[4];
                            local v71 = v69 + 1;
                            local v72 = u32(v70, v71);
                            local v73;

                            if v72 < 128 then
                                v73 = v71 + 1;
                            else
                                local v74 = u32(v70, v71 + 1);

                                if v74 < 128 then
                                    v72 = v72 - 128 + v74 * 128;
                                    v73 = v71 + 2;
                                else
                                    local v75 = u32(v70, v71 + 2);

                                    if v75 < 128 then
                                        v72 = v72 - 128 + (v74 - 128) * 16384 + v75 * 128;
                                        v73 = v71 + 3;
                                    else
                                        local v76 = u32(v70, v71 + 3);
                                        v72 = (v72 - 128) * 16384 + (v74 - 128) * 128 + (v75 - 128) + v76 % 128 * 2097152 + (v76 - v76 % 128) * 2097152;
                                        v73 = v71 + 4;
                                    end;
                                end;
                            end;

                            local v77 = v67 * 16843009;
                            local v78 = v73 + v72;
                            local v79 = v78 - v72 % 4;

                            for i = v73, v79 - 1, 4 do
                                u33(v70, i, (u30(u34(v70, i), v77)));
                                local _ = i;
                            end;

                            for i = v79, v78 - 1 do
                                u35(v70, i, (u30(u32(v70, i), v67)));
                                local _ = i;
                            end;

                            UNNAMED_2819781304296[v47] = 78;
                            UNNAMED_2819781301992[v47] = 1;
                            UNNAMED_2819781302040[v47] = 188;
                            UNNAMED_2819781304248[v47] = 62;
                        end;
                    else
                        local v80 = UNNAMED_2819781301992[v47];
                        local v81 = u30(UNNAMED_2819781302040[v47], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                        local v82 = UNNAMED_2819781303960[5];
                        local v83 = u30(v82[v80], 109162203);
                        v82[v80] = v83;
                        local v84 = UNNAMED_2819781303960[4];
                        local v85 = v83 + 1;
                        local v86 = u32(v84, v85);
                        local v87;

                        if v86 < 128 then
                            v87 = v85 + 1;
                        else
                            local v88 = u32(v84, v85 + 1);

                            if v88 < 128 then
                                v86 = v86 - 128 + v88 * 128;
                                v87 = v85 + 2;
                            else
                                local v89 = u32(v84, v85 + 2);

                                if v89 < 128 then
                                    v86 = v86 - 128 + (v88 - 128) * 16384 + v89 * 128;
                                    v87 = v85 + 3;
                                else
                                    local v90 = u32(v84, v85 + 3);
                                    v86 = (v86 - 128) * 16384 + (v88 - 128) * 128 + (v89 - 128) + v90 % 128 * 2097152 + (v90 - v90 % 128) * 2097152;
                                    v87 = v85 + 4;
                                end;
                            end;
                        end;

                        local v91 = v81 * 16843009;
                        local v92 = v87 + v86;
                        local v93 = v92 - v86 % 4;

                        for i = v87, v93 - 1, 4 do
                            u33(v84, i, (u30(u34(v84, i), v91)));
                            local _ = i;
                        end;

                        for i = v93, v92 - 1 do
                            u35(v84, i, (u30(u32(v84, i), v81)));
                            local _ = i;
                        end;

                        UNNAMED_2819781301992[v47] = 60;
                        UNNAMED_2819781302040[v47] = 83;
                        UNNAMED_2819781304296[v47] = 210;
                        UNNAMED_2819781304248[v47] = 62;
                    end;
                elseif v56 >= 49 then
                    if v56 >= 51 then
                        if v56 >= 52 then
                            if v56 == 53 then
                                v52[UNNAMED_2819781302040[v47]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v47]];
                            else
                                u27({ ... }, 1, UNNAMED_2819781302040[v47], UNNAMED_2819781304296[v47], v52);
                            end;
                        else
                            v52[UNNAMED_2819781301992[v47]](v52[UNNAMED_2819781304296[v47]]);
                        end;
                    elseif v56 == 50 then
                        local v94 = u30(UNNAMED_2819781302040[v47], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                        local v95 = UNNAMED_2819781301992[v47] + 1;

                        for i = 1, UNNAMED_2819781304296[v47] do
                            local v96 = u29(u30(v94, (u31(v94, 13))), 536870911);
                            local v97 = u30(v96, (u28(v96, 13)));
                            v94 = u29(u30(v97, (u31(v97, 14))), 536870911);
                            UNNAMED_2819781301992[v95] = u30(UNNAMED_2819781301992[v95], (u29(u28(v94, 0), 127)));
                            UNNAMED_2819781302040[v95] = u30(UNNAMED_2819781302040[v95], (u29(u28(v94, 7), 127)));
                            UNNAMED_2819781304296[v95] = u30(UNNAMED_2819781304296[v95], (u29(u28(v94, 14), 127)));
                            UNNAMED_2819781304248[v95] = u30(UNNAMED_2819781304248[v95], (u29(u28(v94, 21), 127)));
                            v95 = v95 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819781304248[v47] = 62;
                    else
                        v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781302040[v47]][UNNAMED_2819781304296[v47]];
                    end;
                elseif v56 >= 47 then
                    if v56 == 48 then
                        v50 = v53[8];
                        v54 = v53[5];
                        v51 = v53[7];
                        v48 = v53[6];
                        v53 = v53[9];
                    else
                        local v98 = UNNAMED_2819781301992[v47];
                        local v99 = UNNAMED_2819781302040[v47];
                        u27({ ... }, 1, v98 - 1, v99, v52);
                        v52[v99 + v98 - 1] = u25(u36(v98, ...));
                    end;
                elseif v56 == 46 then
                    v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781302040[v47]] + UNNAMED_2819781304296[v47];
                else
                    v52[UNNAMED_2819781302040[v47]] = u37(v52[UNNAMED_2819781301992[v47]], v52[UNNAMED_2819781304296[v47]]);
                end;

                v57 = 14;
                continue;
            elseif v57 == 2 then
                v57 = -1;

                if v56 < 63 then
                    v57 = 3;
                    continue;
                end;

                if v56 >= 68 then
                    if v56 >= 70 then
                        if v56 < 71 then
                            if v52[UNNAMED_2819781304296[v47]] >= UNNAMED_2819781302040[v47] then
                                v47 = UNNAMED_2819781301992[v47];
                            end;
                        elseif v56 == 72 then
                            v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781304296[v47]] < UNNAMED_2819781301992[v47];
                        else
                            v52[UNNAMED_2819781302040[v47]] = UNNAMED_2819781304296[v47];
                        end;
                    elseif v56 == 69 then
                        v53 = {
                            [9] = v53,
                            [7] = v51,
                            [8] = v50,
                            [5] = v54,
                            [6] = v48
                        };
                        local v100 = UNNAMED_2819781302040[v47];
                        v51 = v52[v100 + 2] + 0;
                        v54 = v52[v100 + 1] + 0;
                        v50 = v52[v100] - v51;
                        v47 = UNNAMED_2819781304296[v47];
                    else
                        v44 = v52[UNNAMED_2819781304296[v47]];
                    end;
                elseif v56 < 65 then
                    if v56 == 64 then
                        v52[UNNAMED_2819781301992[v47]] = u30(UNNAMED_2819781303912[v47], UNNAMED_2819781303864[v47]);
                    else
                        local v101 = UNNAMED_2819781301992[v47];
                        local v102 = UNNAMED_2819781304296[v47];
                        local v103 = UNNAMED_2819781302040[v47];
                        local v104 = u30(v44, u29(u28(v44, 14), 262143), (u29(u28(v44, 28), 15)));
                        local v105 = v101 < 2097152 and 7 or 14;
                        local v106 = u29(v101, u31(1, v105) - 1);
                        local v107 = u28(v101, v105);
                        UNNAMED_2819781301992[v47] = u30(v106, 56, (u29(v104, 127)));
                        UNNAMED_2819781304296[v47] = u30(v102, 77, (u29(u28(v104, 14), 127)));
                        UNNAMED_2819781302040[v47] = u30(v103, 39, (u29(u28(v104, 7), 127)));
                        UNNAMED_2819781304248[v47] = u30(v107, 72, (u29(u28(v104, 21), 127)));
                        v47 = v47 - 1;
                    end;
                elseif v56 >= 66 then
                    if v56 == 67 then
                        local v108 = UNNAMED_2819781301992[v47];
                        v52[v108] = v52[v108](v52[v108 + 1], v52[v108 + 2]);
                    else
                        local v109 = UNNAMED_2819781302040[v47];
                        local v110 = UNNAMED_2819781304296[v47] + 1;

                        for i = 1, UNNAMED_2819781301992[v47] do
                            local v111 = u29(u30(v109, (u31(v109, 13))), 536870911);
                            local v112 = u30(v111, (u28(v111, 13)));
                            v109 = u29(u30(v112, (u31(v112, 14))), 536870911);
                            UNNAMED_2819781301992[v110] = u30(UNNAMED_2819781301992[v110], (u29(u28(v109, 0), 127)));
                            UNNAMED_2819781302040[v110] = u30(UNNAMED_2819781302040[v110], (u29(u28(v109, 7), 127)));
                            UNNAMED_2819781304296[v110] = u30(UNNAMED_2819781304296[v110], (u29(u28(v109, 14), 127)));
                            UNNAMED_2819781304248[v110] = u30(UNNAMED_2819781304248[v110], (u29(u28(v109, 21), 127)));
                            v110 = v110 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819781304248[v47] = 62;
                    end;
                else
                    v52[UNNAMED_2819781304296[v47]] = v52[UNNAMED_2819781301992[v47]] + UNNAMED_2819781303864[v47];
                end;

                v57 = 14;
                continue;
            elseif v57 == 3 then
                v57 = -1;

                if v56 >= 58 then
                    v57 = 13;
                    continue;
                end;

                if v56 >= 56 then
                    v57 = 4;
                    continue;
                end;

                if v56 == 55 then
                    local v113 = u18[UNNAMED_2819781304296[v47]];
                    v52[UNNAMED_2819781302040[v47]] = v113[5][v113[4]][v52[UNNAMED_2819781301992[v47]]];
                else
                    v52[UNNAMED_2819781302040[v47]] = u30(v52[UNNAMED_2819781301992[v47]], UNNAMED_2819781303912[v47]);
                end;

                v57 = 12;
                continue;
            elseif v57 == 4 then
                v57 = -1;

                if v56 ~= 57 then
                    v57 = 5;
                    continue;
                end;

                v57 = 11;
                continue;
            elseif v57 == 5 then
                v57 = -1;
                v46 = UNNAMED_2819781304296[v47];
                v45 = UNNAMED_2819781301992[v47] + 1;
                v57 = 6;
                continue;
            elseif v57 == 6 then
                v57 = -1;

                if v46 ~= 138 then
                    v57 = 7;
                    continue;
                end;

                v57 = 10;
                continue;
            elseif v57 == 7 then
                v57 = -1;

                if v46 ~= 144 then
                    v57 = 8;
                    continue;
                end;

                v57 = 9;
                continue;
            elseif v57 == 8 then
                v57 = -1;

                if v46 ~= 156 then
                    return;
                end;

                while true do
                    local v114 = UNNAMED_2819781304296[v45];

                    if v114 >= 69 then
                        if v114 >= 103 then
                            if v114 < 120 then
                                if v114 < 111 then
                                    if v114 < 107 then
                                        if v114 < 105 then
                                            if v114 == 104 then
                                                if UNNAMED_2819781302040[v45] >= v52[UNNAMED_2819781304248[v45]] then
                                                    v45 = UNNAMED_2819781301992[v45];
                                                end;
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = u30(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781303816[v45]);
                                            end;
                                        elseif v114 == 106 then
                                            v52[UNNAMED_2819781304248[v45]][UNNAMED_2819781301992[v45]] = UNNAMED_2819781303864[v45];
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] == UNNAMED_2819781303816[v45];
                                        end;
                                    elseif v114 < 109 then
                                        if v114 == 108 then
                                            local v115 = UNNAMED_2819781304248[v45];
                                            local v116 = v52[UNNAMED_2819781302040[v45]];
                                            local v117 = u29(v52[UNNAMED_2819781301992[v45]], 4294967295);
                                            local v118 = u29(v116, 4294967295);
                                            local v119 = u29(v117, 65535);
                                            local v120 = u28(v117, 16);
                                            local v121 = u29(v118, 65535);
                                            local v122 = u28(v118, 16);
                                            local v123 = u29(v119 * v121 + u31(u29(v119 * v122 + v120 * v121, 65535), 16), 4294967295) % 4294967296;
                                            v52[v115] = v123 ~= v123 and 0 or v123 - v123 % 1;
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781301992[v45];
                                        end;
                                    elseif v114 == 110 then
                                        if v52[UNNAMED_2819781304248[v45]] >= UNNAMED_2819781301992[v45] then
                                            v45 = UNNAMED_2819781302040[v45];
                                        end;
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]][v52[UNNAMED_2819781301992[v45]]];
                                    end;
                                elseif v114 < 115 then
                                    if v114 >= 113 then
                                        if v114 == 114 then
                                            v52[UNNAMED_2819781304248[v45]][UNNAMED_2819781303864[v45]] = UNNAMED_2819781301992[v45];
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] < v52[UNNAMED_2819781301992[v45]];
                                        end;
                                    elseif v114 == 112 then
                                        v45 = v52[UNNAMED_2819781302040[v45]];
                                    else
                                        local v124 = u18[UNNAMED_2819781302040[v45]];
                                        v124[5][v124[4]] = v52[UNNAMED_2819781301992[v45]];
                                    end;
                                elseif v114 >= 117 then
                                    if v114 < 118 then
                                        v52[UNNAMED_2819781301992[v45]](v52[UNNAMED_2819781302040[v45]]);
                                    elseif v114 == 119 then
                                        v52[UNNAMED_2819781304248[v45]] = u37(v52[UNNAMED_2819781302040[v45]], v52[UNNAMED_2819781301992[v45]]);
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]]();
                                    end;
                                elseif v114 == 116 then
                                    v52[UNNAMED_2819781302040[v45]](UNNAMED_2819781304008[v45], v52[UNNAMED_2819781301992[v45]]);
                                elseif v49 then
                                    local v125 = UNNAMED_2819781301992[v45];
                                    local v126 = v49[v125];

                                    if v126 then
                                        v126[5] = v126;
                                        v126[6] = v52[v125];
                                        v126[4] = 6;
                                        v49[v125] = nil;
                                    end;

                                    local v127 = UNNAMED_2819781302040[v45];
                                    local v128 = v49[v127];

                                    if v128 then
                                        v128[5] = v128;
                                        v128[6] = v52[v127];
                                        v128[4] = 6;
                                        v49[v127] = nil;
                                    end;

                                    local v129 = UNNAMED_2819781304248[v45];
                                    local v130 = v49[v129];

                                    if v130 then
                                        v130[5] = v130;
                                        v130[6] = v52[v129];
                                        v130[4] = 6;
                                        v49[v129] = nil;
                                    end;
                                end;
                            elseif v114 >= 129 then
                                if v114 < 133 then
                                    if v114 < 131 then
                                        if v114 == 130 then
                                            local v131 = UNNAMED_2819781304248[v45];
                                            u27(v52, v131 + 1, v131 + UNNAMED_2819781301992[v45], UNNAMED_2819781302040[v45] + 1, v52[v131]);
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = u41[UNNAMED_2819781303816[v45]];
                                        end;
                                    elseif v114 == 132 then
                                        local v132 = nil;
                                        local v133 = UNNAMED_2819781302040[v45];
                                        local v134 = UNNAMED_2819781303816[v45];
                                        local v135 = UNNAMED_2819781304008[v45];
                                        local v136 = v135[0];

                                        if v136 then
                                            local v137 = #v136 / 3;

                                            if v137 > 0 then
                                                v132 = {};

                                                for i = 1, v137 do
                                                    local v138 = (i - 1) * 3;
                                                    local v139 = v136[v138 + 2];
                                                    local v140 = v136[v138 + 1];
                                                    local v141;

                                                    if v139 == 2 then
                                                        v49 = v49 or {};
                                                        local v142 = v49[v140];

                                                        if not v142 then
                                                            v142 = {
                                                                [5] = v52,
                                                                [4] = v140
                                                            };
                                                            v49[v140] = v142;
                                                        end;

                                                        v132[i] = v142;
                                                        v141 = i;
                                                    elseif v139 == 0 then
                                                        v132[i] = v52[v140];
                                                        v141 = i;
                                                    elseif v139 == 3 then
                                                        v132[i] = u18[v140];
                                                        v141 = i;
                                                    elseif v139 == 1 then
                                                        v55 = v55 or {};
                                                        local v143 = v55[v140];

                                                        if not v143 then
                                                            v143 = {
                                                                [5] = v52,
                                                                [4] = v140,
                                                                [6] = v136[v138 + 3]
                                                            };
                                                            v55[v140] = v143;
                                                        end;

                                                        v132[i] = v143;
                                                        v141 = i;
                                                    else
                                                        v141 = i;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v144 = v135[-2];
                                        v135[v144] = v132;
                                        local v145 = v134(u26(v135, 1, v135[-1]));
                                        v135[v144] = nil;
                                        v52[v133] = v145;
                                    else
                                        v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] <= v52[UNNAMED_2819781304248[v45]];
                                    end;
                                elseif v114 < 135 then
                                    if v114 == 134 then
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] % UNNAMED_2819781301992[v45];
                                    else
                                        v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304248[v45]] // v52[UNNAMED_2819781301992[v45]];
                                    end;
                                elseif v114 >= 136 then
                                    if v114 == 137 then
                                        if v49 then
                                            local v146 = UNNAMED_2819781304248[v45];
                                            local v147 = v49[v146];

                                            if v147 then
                                                v147[5] = v147;
                                                v147[6] = v52[v146];
                                                v147[4] = 6;
                                                v49[v146] = nil;
                                            end;

                                            local v148 = UNNAMED_2819781302040[v45];
                                            local v149 = v49[v148];

                                            if v149 then
                                                v149[5] = v149;
                                                v149[6] = v52[v148];
                                                v149[4] = 6;
                                                v49[v148] = nil;
                                            end;
                                        end;
                                    else
                                        v52[UNNAMED_2819781302040[v45]] = u28(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781301992[v45]);
                                    end;
                                else
                                    v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781304056[UNNAMED_2819781303864[v45]];
                                end;
                            elseif v114 < 124 then
                                if v114 < 122 then
                                    if v114 == 121 then
                                        local v150 = UNNAMED_2819781301992[v45];
                                        local v151 = u38(u39);
                                        v151(UNNAMED_2819781304056, v52[v150], v52[v150 + 1], v52[v150 + 2]);
                                        local v152 = UNNAMED_2819781302040[v45];
                                        v45 = UNNAMED_2819781304248[v45];
                                        v50 = v151;
                                        v48 = v152;
                                        v53 = {
                                            [9] = v53,
                                            [7] = v51,
                                            [8] = v50,
                                            [5] = v54,
                                            [6] = v48
                                        };
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] * UNNAMED_2819781303864[v45];
                                    end;
                                elseif v114 == 123 then
                                    UNNAMED_2819781304056[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]];
                                else
                                    v52[UNNAMED_2819781302040[v45]] = not v52[UNNAMED_2819781304248[v45]];
                                end;
                            elseif v114 >= 126 then
                                if v114 < 127 then
                                    local v153 = UNNAMED_2819781302040[v45];
                                    local v154 = UNNAMED_2819781301992[v45];
                                    local v155 = UNNAMED_2819781303960[5];
                                    local v156 = u30(v155[v153], 109162203);
                                    v155[v153] = v156;
                                    local v157 = UNNAMED_2819781303960[4];
                                    local v158 = v156 + 1;
                                    local v159 = u32(v157, v158);
                                    local v160;

                                    if v159 < 128 then
                                        v160 = v158 + 1;
                                    else
                                        local v161 = u32(v157, v158 + 1);

                                        if v161 < 128 then
                                            v159 = v159 - 128 + v161 * 128;
                                            v160 = v158 + 2;
                                        else
                                            local v162 = u32(v157, v158 + 2);

                                            if v162 < 128 then
                                                v159 = v159 - 128 + (v161 - 128) * 16384 + v162 * 128;
                                                v160 = v158 + 3;
                                            else
                                                local v163 = u32(v157, v158 + 3);
                                                v159 = (v159 - 128) * 16384 + (v161 - 128) * 128 + (v162 - 128) + v163 % 128 * 2097152 + (v163 - v163 % 128) * 2097152;
                                                v160 = v158 + 4;
                                            end;
                                        end;
                                    end;

                                    local v164 = v154 * 16843009;
                                    local v165 = v160 + v159;
                                    local v166 = v165 - v159 % 4;

                                    for i = v160, v166 - 1, 4 do
                                        u33(v157, i, (u30(u34(v157, i), v164)));
                                        local _ = i;
                                    end;

                                    for i = v166, v165 - 1 do
                                        u35(v157, i, (u30(u32(v157, i), v154)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819781302040[v45] = 221;
                                    UNNAMED_2819781301992[v45] = 131;
                                    UNNAMED_2819781304248[v45] = 226;
                                    UNNAMED_2819781304296[v45] = 11;
                                elseif v114 == 128 then
                                    local v167 = u18[UNNAMED_2819781302040[v45]];
                                    v52[UNNAMED_2819781304248[v45]] = v167[5][v167[4]][v52[UNNAMED_2819781301992[v45]]];
                                else
                                    v52[UNNAMED_2819781304248[v45]][UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]];
                                end;
                            elseif v114 == 125 then
                                v52[UNNAMED_2819781302040[v45]] = u37(v52[UNNAMED_2819781301992[v45]], UNNAMED_2819781304008[v45]);
                            else
                                v52[UNNAMED_2819781301992[v45]] = u30(v52[UNNAMED_2819781304248[v45]], v52[UNNAMED_2819781302040[v45]]);
                            end;
                        elseif v114 >= 86 then
                            if v114 < 94 then
                                if v114 >= 90 then
                                    if v114 < 92 then
                                        if v114 == 91 then
                                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] + UNNAMED_2819781304248[v45];
                                        else
                                            v52[UNNAMED_2819781302040[v45]](v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781303816[v45]);
                                        end;
                                    else
                                        if v114 ~= 93 then
                                            if v49 then
                                                for i in u40, v49 do
                                                    local v168 = v49[i];

                                                    if v168 then
                                                        v168[5] = v168;
                                                        v168[6] = v52[i];
                                                        v168[4] = 6;
                                                        v49[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v55 then
                                                for i, v in u40, v55 do
                                                    local v169 = v[6];

                                                    if v55 then
                                                        local v170 = v55[i];

                                                        if v170 then
                                                            local v171 = u24(v169);
                                                            u27(v52, i, i + v169 - 1, 1, v171);
                                                            v170[5] = v171;
                                                            v170[4] = 1;
                                                            v55[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return;
                                        end;

                                        local v172 = UNNAMED_2819781302040[v45];
                                        local v173 = UNNAMED_2819781301992[v45];
                                        local v174 = UNNAMED_2819781304248[v45];
                                        local v175 = u30(v43, u29(u28(v43, 14), 262143), (u29(u28(v43, 28), 15)));
                                        local v176 = v172 < 2097152 and 7 or 14;
                                        local v177 = u28(v172, v176);
                                        local v178 = u29(v172, u31(1, v176) - 1);
                                        UNNAMED_2819781304248[v45] = u30(v174, 17, (u29(u28(v175, 7), 127)));
                                        UNNAMED_2819781304296[v45] = u30(v177, 102, (u29(u28(v175, 21), 127)));
                                        UNNAMED_2819781301992[v45] = u30(v173, 100, (u29(u28(v175, 14), 127)));
                                        UNNAMED_2819781302040[v45] = u30(v178, 69, (u29(v175, 127)));
                                        v45 = v45 - 1;
                                    end;
                                elseif v114 >= 88 then
                                    if v114 == 89 then
                                        if v52[UNNAMED_2819781302040[v45]] > UNNAMED_2819781304248[v45] then
                                            v45 = UNNAMED_2819781301992[v45];
                                        end;
                                    else
                                        v52[UNNAMED_2819781301992[v45]][v52[UNNAMED_2819781304248[v45]]] = UNNAMED_2819781303864[v45];
                                    end;
                                elseif v114 == 87 then
                                    v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304056;
                                else
                                    local v179 = UNNAMED_2819781304248[v45];
                                    local v180, v181 = v50();

                                    if v180 then
                                        v52[v179] = v181;
                                        v45 = UNNAMED_2819781302040[v45];
                                    else
                                        v45 = UNNAMED_2819781301992[v45];
                                    end;
                                end;
                            elseif v114 >= 98 then
                                if v114 >= 100 then
                                    if v114 >= 101 then
                                        if v114 == 102 then
                                            if v49 then
                                                for i in u40, v49 do
                                                    local v182 = v49[i];

                                                    if v182 then
                                                        v182[5] = v182;
                                                        v182[6] = v52[i];
                                                        v182[4] = 6;
                                                        v49[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v55 then
                                                for i, v in u40, v55 do
                                                    local v183 = v[6];

                                                    if v55 then
                                                        local v184 = v55[i];

                                                        if v184 then
                                                            local v185 = u24(v183);
                                                            u27(v52, i, i + v183 - 1, 1, v185);
                                                            v184[5] = v185;
                                                            v184[4] = 1;
                                                            v55[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return v52[UNNAMED_2819781304248[v45]];
                                        end;

                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] * v52[UNNAMED_2819781301992[v45]];
                                    elseif UNNAMED_2819781301992[v45] > v52[UNNAMED_2819781302040[v45]] then
                                        v45 = UNNAMED_2819781304248[v45];
                                    end;
                                elseif v114 == 99 then
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] // UNNAMED_2819781301992[v45];
                                else
                                    local v186 = UNNAMED_2819781301992[v45];
                                    local v187, v188, v189 = v50();

                                    if v187 then
                                        v52[v186] = v188;
                                        v52[v186 + 1] = v189;
                                        v45 = UNNAMED_2819781302040[v45];
                                    else
                                        v45 = UNNAMED_2819781304248[v45];
                                    end;
                                end;
                            elseif v114 < 96 then
                                if v114 == 95 then
                                    local v190 = UNNAMED_2819781301992[v45];
                                    local v191 = UNNAMED_2819781302040[v45];
                                    local v192 = UNNAMED_2819781304248[v45];
                                    local _ = v190 + v192 - 1;
                                    local v193 = v190 + v191;
                                    local v194 = v52[v193];
                                    local n = v194.n;
                                    v194.n = v191 + n - 1;
                                    u27(v194, 1, n, v191, v194);
                                    u27(v52, v190 + 1, v193 - 1, 1, v194);
                                    u27(u25(v52[v190](u26(v194, 1, v194.n))), 1, v192, v190, v52);
                                else
                                    local v195 = u18[UNNAMED_2819781301992[v45]];
                                    v195[5][v195[4]] = UNNAMED_2819781304008[v45];
                                end;
                            elseif v114 == 97 then
                                v52[UNNAMED_2819781302040[v45]]();
                            else
                                v52[UNNAMED_2819781304248[v45]] = u30(UNNAMED_2819781303864[v45], UNNAMED_2819781303816[v45]);
                            end;
                        elseif v114 < 77 then
                            if v114 < 73 then
                                if v114 < 71 then
                                    if v114 == 70 then
                                        v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]][UNNAMED_2819781304008[v45]];
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] >= v52[UNNAMED_2819781302040[v45]];
                                    end;
                                elseif v114 == 72 then
                                    v52[UNNAMED_2819781301992[v45]] = {};
                                else
                                    local v196 = UNNAMED_2819781302040[v45];
                                    local _ = UNNAMED_2819781304248[v45];
                                    v52[v196] = u25(v52[v196](u26(v52, v196 + 1, v196 + UNNAMED_2819781301992[v45])));
                                end;
                            elseif v114 >= 75 then
                                if v114 == 76 then
                                    v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] == UNNAMED_2819781304248[v45];
                                else
                                    v52[UNNAMED_2819781304248[v45]] = u29(v52[UNNAMED_2819781302040[v45]], v52[UNNAMED_2819781301992[v45]]);
                                end;
                            else
                                if v114 == 74 then
                                    if v49 then
                                        for i in u40, v49 do
                                            local v197 = v49[i];

                                            if v197 then
                                                v197[5] = v197;
                                                v197[6] = v52[i];
                                                v197[4] = 6;
                                                v49[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v55 then
                                        for i, v in u40, v55 do
                                            local v198 = v[6];

                                            if v55 then
                                                local v199 = v55[i];

                                                if v199 then
                                                    local v200 = u24(v198);
                                                    u27(v52, i, i + v198 - 1, 1, v200);
                                                    v199[5] = v200;
                                                    v199[4] = 1;
                                                    v55[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return UNNAMED_2819781303816[v45];
                                end;

                                v52[UNNAMED_2819781304248[v45]] = u24(UNNAMED_2819781302040[v45]);
                            end;
                        elseif v114 >= 81 then
                            if v114 >= 83 then
                                if v114 >= 84 then
                                    if v114 == 85 then
                                        local v201 = u18[UNNAMED_2819781304248[v45]];
                                        v52[UNNAMED_2819781302040[v45]] = v201[5][v201[4]];
                                    else
                                        v44 = v52[UNNAMED_2819781301992[v45]];
                                    end;
                                else
                                    v52[UNNAMED_2819781304248[v45]] = u29(v52[UNNAMED_2819781301992[v45]], UNNAMED_2819781302040[v45]);
                                end;
                            elseif v114 == 82 then
                                local v202 = UNNAMED_2819781301992[v45];
                                local v203 = UNNAMED_2819781302040[v45] + 1;

                                for i = 1, UNNAMED_2819781304248[v45] do
                                    local v204 = u29(u30(v202, (u31(v202, 13))), 536870911);
                                    local v205 = u30(v204, (u28(v204, 13)));
                                    v202 = u29(u30(v205, (u31(v205, 14))), 536870911);
                                    UNNAMED_2819781302040[v203] = u30(UNNAMED_2819781302040[v203], (u29(u28(v202, 0), 127)));
                                    UNNAMED_2819781304248[v203] = u30(UNNAMED_2819781304248[v203], (u29(u28(v202, 7), 127)));
                                    UNNAMED_2819781301992[v203] = u30(UNNAMED_2819781301992[v203], (u29(u28(v202, 14), 127)));
                                    UNNAMED_2819781304296[v203] = u30(UNNAMED_2819781304296[v203], (u29(u28(v202, 21), 127)));
                                    v203 = v203 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819781304296[v45] = 11;
                            else
                                local v206 = UNNAMED_2819781302040[v45];
                                local v207 = UNNAMED_2819781304008[v45];
                                local v208 = u29(UNNAMED_2819781303816[v45], 4294967295);
                                local v209 = u29(v207, 4294967295);
                                local v210 = u29(v208, 65535);
                                local v211 = u28(v208, 16);
                                local v212 = u29(v209, 65535);
                                local v213 = u28(v209, 16);
                                local v214 = u29(v210 * v212 + u31(u29(v210 * v213 + v211 * v212, 65535), 16), 4294967295) % 4294967296;
                                v52[v206] = v214 ~= v214 and 0 or v214 - v214 % 1;
                            end;
                        elseif v114 < 79 then
                            if v114 == 78 then
                                v52[UNNAMED_2819781301992[v45]] = v52;
                            else
                                UNNAMED_2819781304056[UNNAMED_2819781304008[v45]] = v52[UNNAMED_2819781301992[v45]];
                            end;
                        elseif v114 == 80 then
                            local v215 = UNNAMED_2819781301992[v45];
                            local v216 = UNNAMED_2819781304248[v45];
                            local v217 = UNNAMED_2819781302040[v45];
                            local v218 = v52[v215];
                            local v219 = v215 + v216;
                            local v220 = v52[v219];
                            u27(v52, v215 + 1, v219 - 1, v217 + 1, v218);
                            u27(v220, 1, v220.n, v217 + v216, v218);
                        else
                            v52[UNNAMED_2819781302040[v45]](v52[UNNAMED_2819781301992[v45]], v52[UNNAMED_2819781304248[v45]]);
                        end;
                    elseif v114 >= 34 then
                        if v114 >= 51 then
                            if v114 >= 60 then
                                if v114 < 64 then
                                    if v114 < 62 then
                                        if v114 == 61 then
                                            v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781302040[v45] + v52[UNNAMED_2819781301992[v45]];
                                        else
                                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] - UNNAMED_2819781303864[v45];
                                        end;
                                    elseif v114 == 63 then
                                        v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304008[v45];
                                    else
                                        local v221 = UNNAMED_2819781301992[v45];
                                        local v222 = UNNAMED_2819781302040[v45];
                                        local v223 = UNNAMED_2819781304248[v45];
                                        local _ = v221 + v223 - 1;
                                        local _ = v221 + v222;
                                        u27(u25(v52[v221](u26(v52, v221 + 1, v221 + v222))), 1, v223, v221, v52);
                                    end;
                                elseif v114 < 66 then
                                    if v114 == 65 then
                                        v43 = v52[UNNAMED_2819781301992[v45]];
                                    else
                                        local v224 = UNNAMED_2819781304248[v45];
                                        local v225 = v52[UNNAMED_2819781301992[v45]];
                                        v52[v224 + 1] = v225;
                                        v52[v224] = v225[UNNAMED_2819781303864[v45]];
                                    end;
                                elseif v114 >= 67 then
                                    if v114 == 68 then
                                        v52[UNNAMED_2819781301992[v45]][v52[UNNAMED_2819781302040[v45]]] = v52[UNNAMED_2819781304248[v45]];
                                    elseif v52[UNNAMED_2819781302040[v45]] ~= UNNAMED_2819781301992[v45] then
                                        v45 = UNNAMED_2819781304248[v45];
                                    end;
                                else
                                    v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] * UNNAMED_2819781302040[v45];
                                end;
                            elseif v114 >= 55 then
                                if v114 >= 57 then
                                    if v114 >= 58 then
                                        if v114 == 59 then
                                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] - v52[UNNAMED_2819781302040[v45]];
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = u41[UNNAMED_2819781303816[v45]][UNNAMED_2819781303864[v45]];
                                        end;
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781303864[v45] + UNNAMED_2819781304008[v45];
                                    end;
                                else
                                    if v114 ~= 56 then
                                        if v49 then
                                            for i in u40, v49 do
                                                local v226 = v49[i];

                                                if v226 then
                                                    v226[5] = v226;
                                                    v226[6] = v52[i];
                                                    v226[4] = 6;
                                                    v49[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v55 then
                                            for i, v in u40, v55 do
                                                local v227 = v[6];

                                                if v55 then
                                                    local v228 = v55[i];

                                                    if v228 then
                                                        local v229 = u24(v227);
                                                        u27(v52, i, i + v227 - 1, 1, v229);
                                                        v228[5] = v229;
                                                        v228[4] = 1;
                                                        v55[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return v52[UNNAMED_2819781301992[v45]], v52[UNNAMED_2819781304248[v45]];
                                    end;

                                    if v52[UNNAMED_2819781301992[v45]] then
                                        v45 = UNNAMED_2819781302040[v45];
                                    else
                                        v45 = UNNAMED_2819781304248[v45];
                                    end;
                                end;
                            elseif v114 < 53 then
                                if v114 == 52 then
                                    v52[UNNAMED_2819781301992[v45]] = v44;
                                else
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]][UNNAMED_2819781302040[v45]];
                                end;
                            elseif v114 == 54 then
                                v52[UNNAMED_2819781304248[v45]](UNNAMED_2819781303816[v45], UNNAMED_2819781303864[v45]);
                                v52[UNNAMED_2819781304248[v45 + 1]] = UNNAMED_2819781301992[v45 + 1];
                                v52[UNNAMED_2819781302040[v45 + 2]]();
                                v45 = v45 + 2;
                            else
                                v52[UNNAMED_2819781304248[v45]][UNNAMED_2819781303816[v45]] = v52[UNNAMED_2819781302040[v45]];
                            end;
                        elseif v114 < 42 then
                            if v114 < 38 then
                                if v114 >= 36 then
                                    if v114 == 37 then
                                        v52[UNNAMED_2819781304248[v45]][UNNAMED_2819781302040[v45]] = UNNAMED_2819781301992[v45];
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = v43;
                                    end;
                                elseif v114 == 35 then
                                    v50 = v53[8];
                                    v54 = v53[5];
                                    v51 = v53[7];
                                    v48 = v53[6];
                                    v53 = v53[9];
                                else
                                    v52[UNNAMED_2819781304248[v45]](UNNAMED_2819781303816[v45], UNNAMED_2819781303864[v45]);
                                end;
                            elseif v114 >= 40 then
                                if v114 == 41 then
                                    v52[UNNAMED_2819781304248[v45]] = #v52[UNNAMED_2819781301992[v45]];
                                else
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] ~= UNNAMED_2819781303816[v45];
                                end;
                            elseif v114 == 39 then
                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] + v52[UNNAMED_2819781304248[v45]];
                            else
                                local v230 = UNNAMED_2819781302040[v45];
                                local v231 = UNNAMED_2819781301992[v45];
                                v52[v230] = UNNAMED_2819781304008[v45];
                                v52[v230 + 1] = v231;
                            end;
                        elseif v114 >= 46 then
                            if v114 >= 48 then
                                if v114 < 49 then
                                    v52[UNNAMED_2819781304248[v45]](UNNAMED_2819781303816[v45], UNNAMED_2819781303864[v45]);
                                    v52[UNNAMED_2819781304248[v45 + 1]] = UNNAMED_2819781301992[v45 + 1];
                                    v52[UNNAMED_2819781302040[v45 + 2]]();
                                    v52[UNNAMED_2819781304248[v45 + 3]] = UNNAMED_2819781301992[v45 + 3];
                                    v45 = v45 + 3;
                                elseif v114 == 50 then
                                    local v232 = UNNAMED_2819781304248[v45];
                                    local v233 = UNNAMED_2819781303864[v45];
                                    v52[v232] = UNNAMED_2819781301992[v45];
                                    v52[v232 + 1] = v233;
                                else
                                    local v234 = UNNAMED_2819781302040[v45];
                                    local v235 = v52[UNNAMED_2819781301992[v45]];
                                    v52[v234] = UNNAMED_2819781304248[v45];
                                    v52[v234 + 1] = v235;
                                end;
                            elseif v114 == 47 then
                                v52[UNNAMED_2819781302040[v45]](v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781303816[v45]);
                                v52[UNNAMED_2819781302040[v45 + 1]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v45 + 1]];
                                v52[UNNAMED_2819781302040[v45 + 2]](v52[UNNAMED_2819781304248[v45 + 2]], UNNAMED_2819781303816[v45 + 2]);
                                v45 = v45 + 2;
                            elseif v52[UNNAMED_2819781304248[v45]] then
                                v45 = UNNAMED_2819781301992[v45];
                            else
                                v45 = UNNAMED_2819781302040[v45];
                            end;
                        elseif v114 >= 44 then
                            if v114 == 45 then
                                local v236 = UNNAMED_2819781302040[v45];
                                local v237 = v52[UNNAMED_2819781304248[v45]];
                                v52[v236] = UNNAMED_2819781303816[v45];
                                v52[v236 + 1] = v237;
                            else
                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] ~= UNNAMED_2819781302040[v45];
                            end;
                        elseif v114 == 43 then
                            v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v45]];
                            v52[UNNAMED_2819781302040[v45 + 1]](v52[UNNAMED_2819781304248[v45 + 1]], UNNAMED_2819781303816[v45 + 1]);
                            v52[UNNAMED_2819781302040[v45 + 2]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v45 + 2]];
                            v45 = v45 + 2;
                        else
                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] <= UNNAMED_2819781304248[v45];
                        end;
                    elseif v114 >= 17 then
                        if v114 >= 25 then
                            if v114 < 29 then
                                if v114 < 27 then
                                    if v114 == 26 then
                                        v45 = UNNAMED_2819781301992[v45];
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781303864[v45] + v52[UNNAMED_2819781304248[v45]];
                                    end;
                                elseif v114 == 28 then
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] - UNNAMED_2819781302040[v45];
                                else
                                    local v238 = UNNAMED_2819781304248[v45];
                                    local v239 = UNNAMED_2819781302040[v45];
                                    local v240 = UNNAMED_2819781301992[v45];
                                    local v241 = u30(v43, u29(u28(v43, 14), 262143), (u29(u28(v43, 28), 15)));
                                    local v242 = v240 < 16384 and 7 or (v240 < 2097152 and 14 or 21);
                                    local v243 = u29(v240, u31(1, v242) - 1);
                                    UNNAMED_2819781304296[v45] = u30(u28(v240, v242), 104, (u29(u28(v241, 21), 127)));
                                    UNNAMED_2819781304248[v45] = u30(v238, 5, (u29(u28(v241, 7), 127)));
                                    UNNAMED_2819781301992[v45] = u30(v243, 49, (u29(u28(v241, 14), 127)));
                                    UNNAMED_2819781302040[v45] = u30(v239, 2, (u29(v241, 127)));
                                    v45 = v45 - 1;
                                end;
                            elseif v114 >= 31 then
                                if v114 >= 32 then
                                    if v114 == 33 then
                                        local v244 = v52[UNNAMED_2819781304248[v45]] % 4294967296;
                                        v52[UNNAMED_2819781302040[v45]] = v244 ~= v244 and 0 or v244 - v244 % 1;
                                    elseif v49 then
                                        local v245 = UNNAMED_2819781304248[v45];
                                        local v246 = v49[v245];

                                        if v246 then
                                            v246[5] = v246;
                                            v246[6] = v52[v245];
                                            v246[4] = 6;
                                            v49[v245] = nil;
                                        end;
                                    end;
                                else
                                    local v247 = u30(UNNAMED_2819781304248[v45], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                                    local v248 = UNNAMED_2819781302040[v45] + 1;

                                    for i = 1, UNNAMED_2819781301992[v45] do
                                        local v249 = u29(u30(v247, (u31(v247, 13))), 536870911);
                                        local v250 = u30(v249, (u28(v249, 13)));
                                        v247 = u29(u30(v250, (u31(v250, 14))), 536870911);
                                        UNNAMED_2819781302040[v248] = u30(UNNAMED_2819781302040[v248], (u29(u28(v247, 0), 127)));
                                        UNNAMED_2819781304248[v248] = u30(UNNAMED_2819781304248[v248], (u29(u28(v247, 7), 127)));
                                        UNNAMED_2819781301992[v248] = u30(UNNAMED_2819781301992[v248], (u29(u28(v247, 14), 127)));
                                        UNNAMED_2819781304296[v248] = u30(UNNAMED_2819781304296[v248], (u29(u28(v247, 21), 127)));
                                        v248 = v248 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819781304296[v45] = 11;
                                end;
                            elseif v114 == 30 then
                                v52[UNNAMED_2819781304248[v45]] = u42(v52[UNNAMED_2819781302040[v45]]);
                            else
                                local v251 = u30(UNNAMED_2819781304248[v45], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                                local v252 = UNNAMED_2819781302040[v45] + 1;

                                for i = 1, UNNAMED_2819781301992[v45] do
                                    local v253 = u29(u30(v251, (u31(v251, 13))), 536870911);
                                    local v254 = u30(v253, (u28(v253, 13)));
                                    v251 = u29(u30(v254, (u31(v254, 14))), 536870911);
                                    UNNAMED_2819781302040[v252] = u30(UNNAMED_2819781302040[v252], (u29(u28(v251, 0), 127)));
                                    UNNAMED_2819781304248[v252] = u30(UNNAMED_2819781304248[v252], (u29(u28(v251, 7), 127)));
                                    UNNAMED_2819781301992[v252] = u30(UNNAMED_2819781301992[v252], (u29(u28(v251, 14), 127)));
                                    UNNAMED_2819781304296[v252] = u30(UNNAMED_2819781304296[v252], (u29(u28(v251, 21), 127)));
                                    v252 = v252 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819781304296[v45] = 11;
                            end;
                        elseif v114 < 21 then
                            if v114 < 19 then
                                if v114 == 18 then
                                    v52[UNNAMED_2819781302040[v45]][UNNAMED_2819781303816[v45]] = UNNAMED_2819781304008[v45];
                                else
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] + UNNAMED_2819781303816[v45];
                                end;
                            elseif v114 == 20 then
                                local v255 = UNNAMED_2819781301992[v45];
                                local v256 = UNNAMED_2819781302040[v45];
                                v52[v255] = UNNAMED_2819781304248[v45];
                                v52[v255 + 1] = v256;
                            else
                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] < UNNAMED_2819781302040[v45];
                            end;
                        elseif v114 < 23 then
                            if v114 == 22 then
                                v52[UNNAMED_2819781301992[v45]] = u30(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781302040[v45]);
                            else
                                local v257 = UNNAMED_2819781301992[v45];
                                local v258 = UNNAMED_2819781304008[v45];
                                v52[v257] = UNNAMED_2819781303864[v45];
                                v52[v257 + 1] = v258;
                            end;
                        elseif v114 == 24 then
                            for i = UNNAMED_2819781302040[v45], UNNAMED_2819781304248[v45] do
                                v52[i] = nil;
                                local _ = i;
                            end;
                        else
                            v53 = {
                                [9] = v53,
                                [7] = v51,
                                [8] = v50,
                                [5] = v54,
                                [6] = v48
                            };
                            local v259 = UNNAMED_2819781304248[v45];
                            v51 = v52[v259 + 2] + 0;
                            v54 = v52[v259 + 1] + 0;
                            v50 = v52[v259] - v51;
                            v45 = UNNAMED_2819781302040[v45];
                        end;
                    elseif v114 >= 8 then
                        if v114 >= 12 then
                            if v114 < 14 then
                                if v114 == 13 then
                                    v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304248[v45] * v52[UNNAMED_2819781302040[v45]];
                                else
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]];
                                end;
                            elseif v114 < 15 then
                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]](v52[UNNAMED_2819781302040[v45]]);
                            elseif v114 == 16 then
                                v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v45]];
                            else
                                v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781302040[v45] - v52[UNNAMED_2819781304248[v45]];
                            end;
                        elseif v114 < 10 then
                            if v114 == 9 then
                                if v49 then
                                    for i in u40, v49 do
                                        local v260 = v49[i];

                                        if v260 then
                                            v260[5] = v260;
                                            v260[6] = v52[i];
                                            v260[4] = 6;
                                            v49[i] = nil;
                                        end;
                                    end;
                                end;

                                if v55 then
                                    for i, v in u40, v55 do
                                        local v261 = v[6];

                                        if v55 then
                                            local v262 = v55[i];

                                            if v262 then
                                                local v263 = u24(v261);
                                                u27(v52, i, i + v261 - 1, 1, v263);
                                                v262[5] = v263;
                                                v262[4] = 1;
                                                v55[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return v52[UNNAMED_2819781302040[v45]](u26(v52[UNNAMED_2819781301992[v45]], 1, v52[UNNAMED_2819781301992[v45]].n));
                            end;

                            local v264 = UNNAMED_2819781304248[v45];
                            local v265 = v52[UNNAMED_2819781301992[v45]];
                            v52[v264] = v52[UNNAMED_2819781302040[v45]];
                            v52[v264 + 1] = v265;
                        elseif v114 ~= 11 then
                            v52[UNNAMED_2819781301992[v45]](v52[UNNAMED_2819781302040[v45]]);
                            v52[UNNAMED_2819781302040[v45 + 1]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v45 + 1]];
                            v52[UNNAMED_2819781301992[v45 + 2]](v52[UNNAMED_2819781302040[v45 + 2]]);
                            v52[UNNAMED_2819781302040[v45 + 3]] = UNNAMED_2819781304056[UNNAMED_2819781301992[v45 + 3]];
                            v45 = v45 + 3;
                        end;
                    elseif v114 < 4 then
                        if v114 >= 2 then
                            if v114 == 3 then
                                v50 = v50 + v51;
                                local v266;

                                if v51 <= 0 then
                                    v266 = v54 <= v50;
                                else
                                    v266 = v50 <= v54;
                                end;

                                if v266 then
                                    v52[UNNAMED_2819781301992[v45]] = v50;
                                    v45 = UNNAMED_2819781302040[v45];
                                else
                                    v45 = UNNAMED_2819781304248[v45];
                                end;
                            else
                                local v267 = UNNAMED_2819781302040[v45];
                                local v268 = UNNAMED_2819781304248[v45];
                                local _ = UNNAMED_2819781301992[v45];
                                local v269 = v267 + v268;
                                local v270 = v52[v269];
                                local n = v270.n;
                                v270.n = v268 + n - 1;
                                u27(v270, 1, n, v268, v270);
                                u27(v52, v267 + 1, v269 - 1, 1, v270);
                                v52[v267] = u25(v52[v267](u26(v270, 1, v270.n)));
                            end;
                        elseif v114 == 1 then
                            v52[UNNAMED_2819781301992[v45]](UNNAMED_2819781304008[v45]);
                        else
                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]](UNNAMED_2819781304008[v45]);
                        end;
                    elseif v114 < 6 then
                        if v114 == 5 then
                            v52[UNNAMED_2819781302040[v45]] = u31(v52[UNNAMED_2819781301992[v45]], UNNAMED_2819781304248[v45]);
                        else
                            UNNAMED_2819781304056[UNNAMED_2819781303864[v45]] = UNNAMED_2819781303816[v45];
                        end;
                    elseif v114 == 7 then
                        local v271 = UNNAMED_2819781301992[v45];
                        local v272 = v52[UNNAMED_2819781302040[v45]];
                        local v273 = u29(UNNAMED_2819781304008[v45], 4294967295);
                        local v274 = u29(v272, 4294967295);
                        local v275 = u29(v273, 65535);
                        local v276 = u28(v273, 16);
                        local v277 = u29(v274, 65535);
                        local v278 = u28(v274, 16);
                        local v279 = u29(v275 * v277 + u31(u29(v275 * v278 + v276 * v277, 65535), 16), 4294967295) % 4294967296;
                        v52[v271] = v279 ~= v279 and 0 or v279 - v279 % 1;
                    else
                        v45 = v52[UNNAMED_2819781304248[v45]];
                    end;

                    v45 = v45 + 1;
                end;

                v57 = 9;
                continue;
            elseif v57 == 9 then
                v57 = -1;

                while true do
                    local v45;
                    local v280 = 0;

                    while true do
                        if v280 == 0 then
                            v280 = -1;
                            local v281 = UNNAMED_2819781304296[v45];

                            if v281 >= 69 then
                                if v281 < 103 then
                                    if v281 >= 86 then
                                        if v281 < 94 then
                                            if v281 < 90 then
                                                if v281 >= 88 then
                                                    if v281 == 89 then
                                                        v52[UNNAMED_2819781301992[v45]](UNNAMED_2819781304008[v45], v52[UNNAMED_2819781302040[v45]]);
                                                    else
                                                        v52[UNNAMED_2819781302040[v45]][UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]];
                                                    end;
                                                elseif v281 == 87 then
                                                    local v282 = UNNAMED_2819781301992[v45];
                                                    local v283 = v52[UNNAMED_2819781304248[v45]];
                                                    v52[v282] = v52[UNNAMED_2819781302040[v45]];
                                                    v52[v282 + 1] = v283;
                                                else
                                                    local v284 = UNNAMED_2819781304248[v45];
                                                    local v285 = v52[UNNAMED_2819781302040[v45]];
                                                    v52[v284 + 1] = v285;
                                                    v52[v284] = v285[UNNAMED_2819781303816[v45]];
                                                end;
                                            elseif v281 >= 92 then
                                                if v281 == 93 then
                                                    v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781302040[v45];
                                                else
                                                    v43 = v52[UNNAMED_2819781301992[v45]];
                                                end;
                                            elseif v281 == 91 then
                                                local v286 = u18[UNNAMED_2819781302040[v45]];
                                                v52[UNNAMED_2819781304248[v45]] = v286[5][v286[4]][UNNAMED_2819781303816[v45]];
                                            else
                                                v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781302040[v45] % v52[UNNAMED_2819781304248[v45]];
                                            end;
                                        elseif v281 < 98 then
                                            if v281 >= 96 then
                                                if v281 == 97 then
                                                    if v52[UNNAMED_2819781301992[v45]] then
                                                        v45 = UNNAMED_2819781302040[v45];
                                                    else
                                                        v45 = UNNAMED_2819781304248[v45];
                                                    end;
                                                elseif v52[UNNAMED_2819781301992[v45]] >= UNNAMED_2819781302040[v45] then
                                                    v45 = UNNAMED_2819781304248[v45];
                                                end;
                                            elseif v281 == 95 then
                                                v52[UNNAMED_2819781302040[v45]](UNNAMED_2819781303816[v45]);
                                            elseif v52[UNNAMED_2819781301992[v45]] >= v52[UNNAMED_2819781304248[v45]] then
                                                v45 = UNNAMED_2819781302040[v45];
                                            end;
                                        elseif v281 < 100 then
                                            if v281 == 99 then
                                                v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304056[UNNAMED_2819781304248[v45]];
                                            else
                                                v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]][UNNAMED_2819781303864[v45]];
                                            end;
                                        elseif v281 < 101 then
                                            v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304008[v45] + UNNAMED_2819781303864[v45];
                                        elseif v281 == 102 then
                                            v52[UNNAMED_2819781302040[v45]] = u24(UNNAMED_2819781304248[v45]);
                                        else
                                            local v287 = UNNAMED_2819781304248[v45];
                                            local v288 = UNNAMED_2819781301992[v45];
                                            local v289 = UNNAMED_2819781302040[v45];
                                            local _ = v287 + v289 - 1;
                                            local _ = v287 + v288;
                                            u27(u25(v52[v287](u26(v52, v287 + 1, v287 + v288))), 1, v289, v287, v52);
                                        end;
                                    elseif v281 >= 77 then
                                        if v281 < 81 then
                                            if v281 >= 79 then
                                                if v281 == 80 then
                                                    local v290 = UNNAMED_2819781301992[v45];
                                                    local v291 = u30(v44, u29(u28(v44, 14), 262143), (u29(u28(v44, 28), 15)));
                                                    local v292 = UNNAMED_2819781304248[v45];
                                                    local v293 = UNNAMED_2819781302040[v45];
                                                    local v294 = v292 < 16384 and 7 or (v292 < 2097152 and 14 or 21);
                                                    local v295 = u29(v292, u31(1, v294) - 1);
                                                    local v296 = u28(v292, v294);
                                                    UNNAMED_2819781302040[v45] = u30(v293, 97, (u29(u28(v291, 7), 127)));
                                                    UNNAMED_2819781304296[v45] = u30(v296, 120, (u29(u28(v291, 21), 127)));
                                                    UNNAMED_2819781304248[v45] = u30(v295, 63, (u29(v291, 127)));
                                                    UNNAMED_2819781301992[v45] = u30(v290, 93, (u29(u28(v291, 14), 127)));
                                                    v45 = v45 - 1;
                                                else
                                                    v50 = v53[8];
                                                    v54 = v53[5];
                                                    v51 = v53[7];
                                                    v48 = v53[6];
                                                    v53 = v53[9];
                                                end;
                                            elseif v281 == 78 then
                                                local v297 = UNNAMED_2819781302040[v45];
                                                local v298 = v52[UNNAMED_2819781304248[v45]];
                                                local v299 = u29(UNNAMED_2819781301992[v45], 4294967295);
                                                local v300 = u29(v298, 4294967295);
                                                local v301 = u29(v299, 65535);
                                                local v302 = u28(v299, 16);
                                                local v303 = u29(v300, 65535);
                                                local v304 = u28(v300, 16);
                                                local v305 = u29(v301 * v303 + u31(u29(v301 * v304 + v302 * v303, 65535), 16), 4294967295) % 4294967296;
                                                v52[v297] = v305 ~= v305 and 0 or v305 - v305 % 1;
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = u37(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781301992[v45]);
                                            end;
                                        elseif v281 < 83 then
                                            if v281 == 82 then
                                                v52[UNNAMED_2819781302040[v45]](v52[UNNAMED_2819781301992[v45]]);
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = v43;
                                            end;
                                        elseif v281 >= 84 then
                                            if v281 == 85 then
                                                v52[UNNAMED_2819781302040[v45]] = u29(UNNAMED_2819781304008[v45], v52[UNNAMED_2819781301992[v45]]);
                                            else
                                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] >= v52[UNNAMED_2819781304248[v45]];
                                            end;
                                        else
                                            local v306 = u30(UNNAMED_2819781302040[v45], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                                            local v307 = UNNAMED_2819781304248[v45] + 1;

                                            for i = 1, UNNAMED_2819781301992[v45] do
                                                local v308 = u29(u30(v306, (u31(v306, 13))), 536870911);
                                                local v309 = u30(v308, (u28(v308, 13)));
                                                v306 = u29(u30(v309, (u31(v309, 14))), 536870911);
                                                UNNAMED_2819781304248[v307] = u30(UNNAMED_2819781304248[v307], (u29(u28(v306, 0), 127)));
                                                UNNAMED_2819781302040[v307] = u30(UNNAMED_2819781302040[v307], (u29(u28(v306, 7), 127)));
                                                UNNAMED_2819781301992[v307] = u30(UNNAMED_2819781301992[v307], (u29(u28(v306, 14), 127)));
                                                UNNAMED_2819781304296[v307] = u30(UNNAMED_2819781304296[v307], (u29(u28(v306, 21), 127)));
                                                v307 = v307 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819781304296[v45] = 64;
                                        end;
                                    elseif v281 >= 73 then
                                        if v281 >= 75 then
                                            if v281 == 76 then
                                                v52[UNNAMED_2819781301992[v45]] = u30(UNNAMED_2819781302040[v45], v52[UNNAMED_2819781304248[v45]]);
                                            else
                                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] == v52[UNNAMED_2819781304248[v45]];
                                            end;
                                        elseif v281 == 74 then
                                            v52[UNNAMED_2819781304248[v45]] = u29(v52[UNNAMED_2819781302040[v45]], UNNAMED_2819781301992[v45]);
                                        else
                                            local v310 = UNNAMED_2819781301992[v45];
                                            local v311 = UNNAMED_2819781304248[v45];
                                            v52[v310] = UNNAMED_2819781303864[v45];
                                            v52[v310 + 1] = v311;
                                        end;
                                    elseif v281 < 71 then
                                        if v281 == 70 then
                                            v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304056;
                                        else
                                            local v312 = UNNAMED_2819781302040[v45];
                                            local v313 = UNNAMED_2819781304008[v45];
                                            v52[v312] = UNNAMED_2819781301992[v45];
                                            v52[v312 + 1] = v313;
                                        end;
                                    elseif v281 == 72 then
                                        if UNNAMED_2819781304248[v45] >= v52[UNNAMED_2819781302040[v45]] then
                                            v45 = UNNAMED_2819781301992[v45];
                                        end;
                                    else
                                        v52[UNNAMED_2819781302040[v45]] = u37(UNNAMED_2819781304248[v45], v52[UNNAMED_2819781301992[v45]]);
                                    end;
                                elseif v281 < 120 then
                                    if v281 >= 111 then
                                        if v281 >= 115 then
                                            if v281 >= 117 then
                                                if v281 >= 118 then
                                                    if v281 == 119 then
                                                        if v52[UNNAMED_2819781302040[v45]] then
                                                            v45 = UNNAMED_2819781304248[v45];
                                                        else
                                                            v45 = UNNAMED_2819781301992[v45];
                                                        end;
                                                    else
                                                        v52[UNNAMED_2819781301992[v45]](v52[UNNAMED_2819781302040[v45]], UNNAMED_2819781304008[v45]);
                                                    end;
                                                else
                                                    local v314 = u18[UNNAMED_2819781301992[v45]];
                                                    v314[5][v314[4]][v52[UNNAMED_2819781302040[v45]]] = UNNAMED_2819781304248[v45];
                                                end;
                                            elseif v281 == 116 then
                                                local v315 = UNNAMED_2819781304248[v45];
                                                local v316 = u30(UNNAMED_2819781302040[v45], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                                                local v317 = UNNAMED_2819781303960[5];
                                                local v318 = u30(v317[v315], 109162203);
                                                v317[v315] = v318;
                                                local v319 = UNNAMED_2819781303960[4];
                                                local v320 = v318 + 1;
                                                local v321 = u32(v319, v320);
                                                local v322;

                                                if v321 < 128 then
                                                    v322 = v320 + 1;
                                                else
                                                    local v323 = u32(v319, v320 + 1);

                                                    if v323 < 128 then
                                                        v321 = v321 - 128 + v323 * 128;
                                                        v322 = v320 + 2;
                                                    else
                                                        local v324 = u32(v319, v320 + 2);

                                                        if v324 < 128 then
                                                            v321 = v321 - 128 + (v323 - 128) * 16384 + v324 * 128;
                                                            v322 = v320 + 3;
                                                        else
                                                            local v325 = u32(v319, v320 + 3);
                                                            v321 = (v321 - 128) * 16384 + (v323 - 128) * 128 + (v324 - 128) + v325 % 128 * 2097152 + (v325 - v325 % 128) * 2097152;
                                                            v322 = v320 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v326 = v316 * 16843009;
                                                local v327 = v322 + v321;
                                                local v328 = v327 - v321 % 4;

                                                for i = v322, v328 - 1, 4 do
                                                    u33(v319, i, (u30(u34(v319, i), v326)));
                                                    local _ = i;
                                                end;

                                                for i = v328, v327 - 1 do
                                                    u35(v319, i, (u30(u32(v319, i), v316)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819781304248[v45] = 38;
                                                UNNAMED_2819781302040[v45] = 98;
                                                UNNAMED_2819781301992[v45] = 203;
                                                UNNAMED_2819781304296[v45] = 64;
                                            else
                                                v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] // UNNAMED_2819781302040[v45];
                                            end;
                                        elseif v281 >= 113 then
                                            if v281 == 114 then
                                                local v329 = UNNAMED_2819781304248[v45];
                                                v52[v329] = v52[v329](v52[v329 + 1], v52[v329 + 2]);
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] ~= UNNAMED_2819781304248[v45];
                                            end;
                                        elseif v281 == 112 then
                                            v52[UNNAMED_2819781301992[v45]] = u31(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781302040[v45]);
                                        elseif v49 then
                                            local v330 = UNNAMED_2819781304248[v45];
                                            local v331 = v49[v330];

                                            if v331 then
                                                v331[5] = v331;
                                                v331[6] = v52[v330];
                                                v331[4] = 6;
                                                v49[v330] = nil;
                                            end;

                                            local v332 = UNNAMED_2819781301992[v45];
                                            local v333 = v49[v332];

                                            if v333 then
                                                v333[5] = v333;
                                                v333[6] = v52[v332];
                                                v333[4] = 6;
                                                v49[v332] = nil;
                                            end;
                                        end;
                                    elseif v281 < 107 then
                                        if v281 < 105 then
                                            if v281 == 104 then
                                                v52[UNNAMED_2819781304248[v45]](v52[UNNAMED_2819781301992[v45]], v52[UNNAMED_2819781302040[v45]]);
                                            else
                                                local v334 = u18[UNNAMED_2819781301992[v45]];
                                                v334[5][v334[4]] = UNNAMED_2819781304008[v45];
                                            end;
                                        elseif v281 == 106 then
                                            v52[UNNAMED_2819781304248[v45]] = u42(v52[UNNAMED_2819781302040[v45]]);
                                        else
                                            local v335 = UNNAMED_2819781304248[v45];
                                            local _ = UNNAMED_2819781302040[v45];
                                            v52[v335] = u25(v52[v335](u26(v52, v335 + 1, v335 + UNNAMED_2819781301992[v45])));
                                        end;
                                    elseif v281 >= 109 then
                                        if v281 == 110 then
                                            local v336 = UNNAMED_2819781304248[v45];
                                            local v337 = UNNAMED_2819781301992[v45];
                                            local v338 = UNNAMED_2819781303960[5];
                                            local v339 = u30(v338[v336], 109162203);
                                            v338[v336] = v339;
                                            local v340 = UNNAMED_2819781303960[4];
                                            local v341 = v339 + 1;
                                            local v342 = u32(v340, v341);
                                            local v343;

                                            if v342 < 128 then
                                                v343 = v341 + 1;
                                            else
                                                local v344 = u32(v340, v341 + 1);

                                                if v344 < 128 then
                                                    v342 = v342 - 128 + v344 * 128;
                                                    v343 = v341 + 2;
                                                else
                                                    local v345 = u32(v340, v341 + 2);

                                                    if v345 < 128 then
                                                        v342 = v342 - 128 + (v344 - 128) * 16384 + v345 * 128;
                                                        v343 = v341 + 3;
                                                    else
                                                        local v346 = u32(v340, v341 + 3);
                                                        v342 = (v342 - 128) * 16384 + (v344 - 128) * 128 + (v345 - 128) + v346 % 128 * 2097152 + (v346 - v346 % 128) * 2097152;
                                                        v343 = v341 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v347 = v337 * 16843009;
                                            local v348 = v343 + v342;
                                            local v349 = v348 - v342 % 4;

                                            for i = v343, v349 - 1, 4 do
                                                u33(v340, i, (u30(u34(v340, i), v347)));
                                                local _ = i;
                                            end;

                                            for i = v349, v348 - 1 do
                                                u35(v340, i, (u30(u32(v340, i), v337)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819781304248[v45] = 28;
                                            UNNAMED_2819781301992[v45] = 57;
                                            UNNAMED_2819781302040[v45] = 9;
                                            UNNAMED_2819781304296[v45] = 64;
                                        else
                                            v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304008[v45];
                                        end;
                                    elseif v281 == 108 then
                                        local v350 = UNNAMED_2819781301992[v45];
                                        local v351 = UNNAMED_2819781303864[v45];
                                        v52[v350] = UNNAMED_2819781304008[v45];
                                        v52[v350 + 1] = v351;
                                    else
                                        v52[UNNAMED_2819781302040[v45]]();
                                    end;
                                elseif v281 < 129 then
                                    if v281 < 124 then
                                        if v281 < 122 then
                                            if v281 == 121 then
                                                v52[UNNAMED_2819781304248[v45]](UNNAMED_2819781303816[v45], UNNAMED_2819781303864[v45]);
                                            else
                                                local v352 = UNNAMED_2819781301992[v45];
                                                local v353 = UNNAMED_2819781304248[v45];
                                                local v354 = u29(v52[UNNAMED_2819781302040[v45]], 4294967295);
                                                local v355 = u29(v353, 4294967295);
                                                local v356 = u29(v354, 65535);
                                                local v357 = u28(v354, 16);
                                                local v358 = u29(v355, 65535);
                                                local v359 = u28(v355, 16);
                                                local v360 = u29(v356 * v358 + u31(u29(v356 * v359 + v357 * v358, 65535), 16), 4294967295) % 4294967296;
                                                v52[v352] = v360 ~= v360 and 0 or v360 - v360 % 1;
                                            end;
                                        elseif v281 == 123 then
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] // v52[UNNAMED_2819781302040[v45]];
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = -v52[UNNAMED_2819781301992[v45]];
                                        end;
                                    elseif v281 >= 126 then
                                        if v281 < 127 then
                                            local v361 = UNNAMED_2819781302040[v45];
                                            local v362 = v52[UNNAMED_2819781301992[v45]];
                                            local v363 = u29(UNNAMED_2819781304008[v45], 4294967295);
                                            local v364 = u29(v362, 4294967295);
                                            local v365 = u29(v363, 65535);
                                            local v366 = u28(v363, 16);
                                            local v367 = u29(v364, 65535);
                                            local v368 = u28(v364, 16);
                                            local v369 = u29(v365 * v367 + u31(u29(v365 * v368 + v366 * v367, 65535), 16), 4294967295) % 4294967296;
                                            v52[v361] = v369 ~= v369 and 0 or v369 - v369 % 1;
                                        elseif v281 == 128 then
                                            v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] * v52[UNNAMED_2819781304248[v45]];
                                        else
                                            v52[UNNAMED_2819781302040[v45]] = u30(v52[UNNAMED_2819781301992[v45]], UNNAMED_2819781304248[v45]);
                                        end;
                                    elseif v281 == 125 then
                                        v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] + UNNAMED_2819781304248[v45];
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] - UNNAMED_2819781304008[v45];
                                    end;
                                elseif v281 < 133 then
                                    if v281 >= 131 then
                                        if v281 == 132 then
                                            local v370 = UNNAMED_2819781302040[v45];
                                            local v371 = UNNAMED_2819781301992[v45] + 1;

                                            for i = 1, UNNAMED_2819781304248[v45] do
                                                local v372 = u29(u30(v370, (u31(v370, 13))), 536870911);
                                                local v373 = u30(v372, (u28(v372, 13)));
                                                v370 = u29(u30(v373, (u31(v373, 14))), 536870911);
                                                UNNAMED_2819781304248[v371] = u30(UNNAMED_2819781304248[v371], (u29(u28(v370, 0), 127)));
                                                UNNAMED_2819781302040[v371] = u30(UNNAMED_2819781302040[v371], (u29(u28(v370, 7), 127)));
                                                UNNAMED_2819781301992[v371] = u30(UNNAMED_2819781301992[v371], (u29(u28(v370, 14), 127)));
                                                UNNAMED_2819781304296[v371] = u30(UNNAMED_2819781304296[v371], (u29(u28(v370, 21), 127)));
                                                v371 = v371 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819781304296[v45] = 64;
                                        else
                                            local v374 = u18[UNNAMED_2819781301992[v45]];
                                            v374[5][v374[4]][v52[UNNAMED_2819781304248[v45]]] = v52[UNNAMED_2819781302040[v45]];
                                        end;
                                    elseif v281 == 130 then
                                        v52[UNNAMED_2819781301992[v45]] = u30(v52[UNNAMED_2819781302040[v45]], v52[UNNAMED_2819781304248[v45]]);
                                    else
                                        local v375 = UNNAMED_2819781304248[v45];
                                        local v376 = u30(v44, u29(u28(v44, 14), 262143), (u29(u28(v44, 28), 15)));
                                        local v377 = UNNAMED_2819781302040[v45];
                                        local v378 = UNNAMED_2819781301992[v45];
                                        local v379 = v377 < 2097152 and 7 or 14;
                                        local v380 = u28(v377, v379);
                                        UNNAMED_2819781302040[v45] = u30(u29(v377, u31(1, v379) - 1), 52, (u29(u28(v376, 7), 127)));
                                        UNNAMED_2819781304248[v45] = u30(v375, 86, (u29(v376, 127)));
                                        UNNAMED_2819781304296[v45] = u30(v380, 22, (u29(u28(v376, 21), 127)));
                                        UNNAMED_2819781301992[v45] = u30(v378, 111, (u29(u28(v376, 14), 127)));
                                        v45 = v45 - 1;
                                    end;
                                elseif v281 >= 135 then
                                    if v281 < 136 then
                                        v52[UNNAMED_2819781304248[v45]](v52[UNNAMED_2819781301992[v45]], u26(v52[UNNAMED_2819781302040[v45]], 1, v52[UNNAMED_2819781302040[v45]].n));
                                    elseif v281 == 137 then
                                        local v381 = UNNAMED_2819781301992[v45];
                                        local v382 = UNNAMED_2819781304248[v45];
                                        v52[v381] = UNNAMED_2819781302040[v45];
                                        v52[v381 + 1] = v382;
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304248[v45] + v52[UNNAMED_2819781302040[v45]];
                                    end;
                                elseif v281 == 134 then
                                    if v49 then
                                        local v383 = UNNAMED_2819781301992[v45];
                                        local v384 = v49[v383];

                                        if v384 then
                                            v384[5] = v384;
                                            v384[6] = v52[v383];
                                            v384[4] = 6;
                                            v49[v383] = nil;
                                        end;
                                    end;
                                else
                                    local v385 = UNNAMED_2819781301992[v45];
                                    local v386 = v52[UNNAMED_2819781304248[v45]];
                                    local v387 = u29(v52[UNNAMED_2819781302040[v45]], 4294967295);
                                    local v388 = u29(v386, 4294967295);
                                    local v389 = u29(v387, 65535);
                                    local v390 = u28(v387, 16);
                                    local v391 = u29(v388, 65535);
                                    local v392 = u28(v388, 16);
                                    local v393 = u29(v389 * v391 + u31(u29(v389 * v392 + v390 * v391, 65535), 16), 4294967295) % 4294967296;
                                    v52[v385] = v393 ~= v393 and 0 or v393 - v393 % 1;
                                end;

                                v280 = 1;
                                continue;
                            end;

                            if v281 >= 34 then
                                if v281 >= 51 then
                                    if v281 < 60 then
                                        if v281 < 55 then
                                            if v281 < 53 then
                                                if v281 == 52 then
                                                    v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781303816[v45] + v52[UNNAMED_2819781304248[v45]];
                                                else
                                                    v52[UNNAMED_2819781304248[v45]] = u41[UNNAMED_2819781303816[v45]][UNNAMED_2819781303864[v45]];
                                                end;
                                            elseif v281 == 54 then
                                                v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304248[v45] - v52[UNNAMED_2819781302040[v45]];
                                            else
                                                UNNAMED_2819781304056[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]];
                                            end;
                                        elseif v281 < 57 then
                                            if v281 == 56 then
                                                local v394 = nil;
                                                local v395 = UNNAMED_2819781304248[v45];
                                                local v396 = UNNAMED_2819781303864[v45];
                                                local v397 = UNNAMED_2819781303816[v45];
                                                local v398 = v397[0];

                                                if v398 then
                                                    local v399 = #v398 / 3;

                                                    if v399 > 0 then
                                                        v394 = {};

                                                        for i = 1, v399 do
                                                            local v400 = (i - 1) * 3;
                                                            local v401 = v398[v400 + 2];
                                                            local v402 = v398[v400 + 1];
                                                            local v403;

                                                            if v401 == 2 then
                                                                v49 = v49 or {};
                                                                local v404 = v49[v402];

                                                                if not v404 then
                                                                    v404 = {
                                                                        [5] = v52,
                                                                        [4] = v402
                                                                    };
                                                                    v49[v402] = v404;
                                                                end;

                                                                v394[i] = v404;
                                                                v403 = i;
                                                            elseif v401 == 0 then
                                                                v394[i] = v52[v402];
                                                                v403 = i;
                                                            elseif v401 == 3 then
                                                                v394[i] = u18[v402];
                                                                v403 = i;
                                                            elseif v401 == 1 then
                                                                v55 = v55 or {};
                                                                local v405 = v55[v402];

                                                                if not v405 then
                                                                    v405 = {
                                                                        [5] = v52,
                                                                        [4] = v402,
                                                                        [6] = v398[v400 + 3]
                                                                    };
                                                                    v55[v402] = v405;
                                                                end;

                                                                v394[i] = v405;
                                                                v403 = i;
                                                            else
                                                                v403 = i;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                local v406 = v397[-2];
                                                v397[v406] = v394;
                                                local v407 = v396(u26(v397, 1, v397[-1]));
                                                v397[v406] = nil;
                                                v52[v395] = v407;
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = u18[UNNAMED_2819781301992[v45]];
                                            end;
                                        elseif v281 < 58 then
                                            v52[UNNAMED_2819781304248[v45]][UNNAMED_2819781303864[v45]] = v52[UNNAMED_2819781301992[v45]];
                                        elseif v281 == 59 then
                                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] - UNNAMED_2819781304248[v45];
                                        else
                                            v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] - v52[UNNAMED_2819781304248[v45]];
                                        end;
                                    elseif v281 >= 64 then
                                        if v281 < 66 then
                                            if v281 == 65 then
                                                v52[UNNAMED_2819781302040[v45]][v52[UNNAMED_2819781301992[v45]]] = UNNAMED_2819781304248[v45];
                                            end;
                                        elseif v281 < 67 then
                                            v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304248[v45]](v52[UNNAMED_2819781301992[v45]]);
                                        elseif v281 == 68 then
                                            v45 = UNNAMED_2819781304248[v45];
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]][UNNAMED_2819781301992[v45]];
                                        end;
                                    elseif v281 < 62 then
                                        if v281 ~= 61 then
                                            if v49 then
                                                for i in u40, v49 do
                                                    local v408 = v49[i];

                                                    if v408 then
                                                        v408[5] = v408;
                                                        v408[6] = v52[i];
                                                        v408[4] = 6;
                                                        v49[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v55 then
                                                for i, v in u40, v55 do
                                                    local v409 = v[6];

                                                    if v55 then
                                                        local v410 = v55[i];

                                                        if v410 then
                                                            local v411 = u24(v409);
                                                            u27(v52, i, i + v409 - 1, 1, v411);
                                                            v410[5] = v411;
                                                            v410[4] = 1;
                                                            v55[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return;
                                        end;

                                        v52[UNNAMED_2819781304248[v45]](u26(v52[UNNAMED_2819781302040[v45]], 1, v52[UNNAMED_2819781302040[v45]].n));
                                    elseif v281 == 63 then
                                        v52[UNNAMED_2819781302040[v45]] = not v52[UNNAMED_2819781304248[v45]];
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] <= v52[UNNAMED_2819781301992[v45]];
                                    end;
                                elseif v281 >= 42 then
                                    if v281 < 46 then
                                        if v281 >= 44 then
                                            if v281 == 45 then
                                                v52[UNNAMED_2819781304248[v45]] = u30(v52[UNNAMED_2819781301992[v45]], UNNAMED_2819781303864[v45]);
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304056[UNNAMED_2819781304248[v45]];
                                                v52[UNNAMED_2819781302040[v45 + 1]] = v52[UNNAMED_2819781301992[v45 + 1]] + UNNAMED_2819781304248[v45 + 1];
                                                local v412 = UNNAMED_2819781301992[v45 + 2];
                                                local v413 = v52[UNNAMED_2819781304248[v45 + 2]];
                                                v52[v412] = v52[UNNAMED_2819781302040[v45 + 2]];
                                                v52[v412 + 1] = v413;
                                                local v414 = UNNAMED_2819781304248[v45 + 3];
                                                v52[v414] = v52[v414](v52[v414 + 1], v52[v414 + 2]);
                                                v45 = v45 + 3;
                                            end;
                                        elseif v281 == 43 then
                                            v52[UNNAMED_2819781301992[v45]] = u28(v52[UNNAMED_2819781302040[v45]], UNNAMED_2819781304248[v45]);
                                        else
                                            local v415 = u18[UNNAMED_2819781301992[v45]];
                                            v415[5][v415[4]] = v52[UNNAMED_2819781304248[v45]];
                                        end;
                                    elseif v281 >= 48 then
                                        if v281 < 49 then
                                            v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781302040[v45] * v52[UNNAMED_2819781301992[v45]];
                                        else
                                            if v281 == 50 then
                                                if v49 then
                                                    for i in u40, v49 do
                                                        local v416 = v49[i];

                                                        if v416 then
                                                            v416[5] = v416;
                                                            v416[6] = v52[i];
                                                            v416[4] = 6;
                                                            v49[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v55 then
                                                    for i, v in u40, v55 do
                                                        local v417 = v[6];

                                                        if v55 then
                                                            local v418 = v55[i];

                                                            if v418 then
                                                                local v419 = u24(v417);
                                                                u27(v52, i, i + v417 - 1, 1, v419);
                                                                v418[5] = v419;
                                                                v418[4] = 1;
                                                                v55[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return UNNAMED_2819781304008[v45];
                                            end;

                                            v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]] / v52[UNNAMED_2819781302040[v45]];
                                        end;
                                    elseif v281 == 47 then
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] % UNNAMED_2819781302040[v45];
                                    else
                                        v50 = v50 + v51;
                                        local v420;

                                        if v51 <= 0 then
                                            v420 = v54 <= v50;
                                        else
                                            v420 = v50 <= v54;
                                        end;

                                        if v420 then
                                            v52[UNNAMED_2819781301992[v45]] = v50;
                                            v45 = UNNAMED_2819781304248[v45];
                                        else
                                            v45 = UNNAMED_2819781302040[v45];
                                        end;
                                    end;
                                elseif v281 >= 38 then
                                    if v281 < 40 then
                                        if v281 == 39 then
                                            local v421 = UNNAMED_2819781301992[v45];
                                            u27(v52, v421 + 1, v421 + UNNAMED_2819781302040[v45], UNNAMED_2819781304248[v45] + 1, v52[v421]);
                                        else
                                            local v422 = v52[UNNAMED_2819781302040[v45]] % 4294967296;
                                            v52[UNNAMED_2819781301992[v45]] = v422 ~= v422 and 0 or v422 - v422 % 1;
                                        end;
                                    elseif v281 == 41 then
                                        local v423 = UNNAMED_2819781304248[v45];
                                        local v424 = u30(UNNAMED_2819781302040[v45], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                                        local v425 = UNNAMED_2819781303960[5];
                                        local v426 = u30(v425[v423], 109162203);
                                        v425[v423] = v426;
                                        local v427 = UNNAMED_2819781303960[4];
                                        local v428 = v426 + 1;
                                        local v429 = u32(v427, v428);
                                        local v430;

                                        if v429 < 128 then
                                            v430 = v428 + 1;
                                        else
                                            local v431 = u32(v427, v428 + 1);

                                            if v431 < 128 then
                                                v429 = v429 - 128 + v431 * 128;
                                                v430 = v428 + 2;
                                            else
                                                local v432 = u32(v427, v428 + 2);

                                                if v432 < 128 then
                                                    v429 = v429 - 128 + (v431 - 128) * 16384 + v432 * 128;
                                                    v430 = v428 + 3;
                                                else
                                                    local v433 = u32(v427, v428 + 3);
                                                    v429 = (v429 - 128) * 16384 + (v431 - 128) * 128 + (v432 - 128) + v433 % 128 * 2097152 + (v433 - v433 % 128) * 2097152;
                                                    v430 = v428 + 4;
                                                end;
                                            end;
                                        end;

                                        local v434 = v424 * 16843009;
                                        local v435 = v430 + v429;
                                        local v436 = v435 - v429 % 4;

                                        for i = v430, v436 - 1, 4 do
                                            u33(v427, i, (u30(u34(v427, i), v434)));
                                            local _ = i;
                                        end;

                                        for i = v436, v435 - 1 do
                                            u35(v427, i, (u30(u32(v427, i), v424)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819781304248[v45] = 238;
                                        UNNAMED_2819781302040[v45] = 226;
                                        UNNAMED_2819781301992[v45] = 165;
                                        UNNAMED_2819781304296[v45] = 64;
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = u37(v52[UNNAMED_2819781302040[v45]], v52[UNNAMED_2819781301992[v45]]);
                                    end;
                                elseif v281 >= 36 then
                                    if v281 == 37 then
                                        v52[UNNAMED_2819781302040[v45]] = u41[UNNAMED_2819781303816[v45]];
                                    else
                                        v52[UNNAMED_2819781302040[v45]][v52[UNNAMED_2819781304248[v45]]] = v52[UNNAMED_2819781301992[v45]];
                                    end;
                                elseif v281 == 35 then
                                    v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]];
                                else
                                    v52[UNNAMED_2819781301992[v45]] = UNNAMED_2819781304056[UNNAMED_2819781304008[v45]];
                                end;
                            else
                                if v281 >= 17 then
                                    if v281 >= 25 then
                                        if v281 >= 29 then
                                            if v281 >= 31 then
                                                if v281 >= 32 then
                                                    if v281 == 33 then
                                                        v52[UNNAMED_2819781304248[v45]] = u29(UNNAMED_2819781301992[v45], v52[UNNAMED_2819781302040[v45]]);
                                                    else
                                                        v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]](u26(v52[UNNAMED_2819781302040[v45]], 1, v52[UNNAMED_2819781302040[v45]].n));
                                                    end;
                                                else
                                                    local v437 = u18[UNNAMED_2819781301992[v45]];
                                                    v52[UNNAMED_2819781304248[v45]] = v437[5][v437[4]][v52[UNNAMED_2819781302040[v45]]];
                                                end;
                                            elseif v281 == 30 then
                                                v45 = v52[UNNAMED_2819781304248[v45]];
                                            elseif v52[UNNAMED_2819781301992[v45]] ~= UNNAMED_2819781302040[v45] then
                                                v45 = UNNAMED_2819781304248[v45];
                                            end;
                                        elseif v281 < 27 then
                                            if v281 == 26 then
                                                v52[UNNAMED_2819781304248[v45]] = u29(v52[UNNAMED_2819781301992[v45]], v52[UNNAMED_2819781302040[v45]]);
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] * UNNAMED_2819781304248[v45];
                                            end;
                                        else
                                            if v281 ~= 28 then
                                                if v49 then
                                                    for i in u40, v49 do
                                                        local v438 = v49[i];

                                                        if v438 then
                                                            v438[5] = v438;
                                                            v438[6] = v52[i];
                                                            v438[4] = 6;
                                                            v49[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v55 then
                                                    for i, v in u40, v55 do
                                                        local v439 = v[6];

                                                        if v55 then
                                                            local v440 = v55[i];

                                                            if v440 then
                                                                local v441 = u24(v439);
                                                                u27(v52, i, i + v439 - 1, 1, v441);
                                                                v440[5] = v441;
                                                                v440[4] = 1;
                                                                v55[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return v52[UNNAMED_2819781304248[v45]];
                                            end;

                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] + UNNAMED_2819781303816[v45];
                                        end;
                                    elseif v281 >= 21 then
                                        if v281 < 23 then
                                            if v281 == 22 then
                                                v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]][UNNAMED_2819781301992[v45]];
                                                v52[UNNAMED_2819781304248[v45 + 1]] = v52[UNNAMED_2819781302040[v45 + 1]][UNNAMED_2819781301992[v45 + 1]];
                                                v52[UNNAMED_2819781304248[v45 + 2]] = v52[UNNAMED_2819781302040[v45 + 2]][UNNAMED_2819781301992[v45 + 2]];
                                                v52[UNNAMED_2819781304248[v45 + 3]] = v52[UNNAMED_2819781301992[v45 + 3]] + v52[UNNAMED_2819781302040[v45 + 3]];
                                                v52[UNNAMED_2819781304248[v45 + 4]] = v52[UNNAMED_2819781302040[v45 + 4]] <= UNNAMED_2819781301992[v45 + 4];
                                                v45 = v45 + 4;
                                            else
                                                v52[UNNAMED_2819781304248[v45]] = {};
                                            end;
                                        elseif v281 == 24 then
                                            local v442 = UNNAMED_2819781301992[v45];
                                            local v443 = v52[UNNAMED_2819781302040[v45]];
                                            v52[v442] = UNNAMED_2819781304248[v45];
                                            v52[v442 + 1] = v443;
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]]();
                                        end;
                                    elseif v281 < 19 then
                                        if v281 == 18 then
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] % v52[UNNAMED_2819781302040[v45]];
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] % UNNAMED_2819781303864[v45];
                                        end;
                                    elseif v281 == 20 then
                                        v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781301992[v45]] / UNNAMED_2819781304248[v45];
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = v44;
                                    end;

                                    v280 = 1;
                                    continue;
                                end;

                                if v281 >= 8 then
                                    if v281 >= 12 then
                                        if v281 >= 14 then
                                            if v281 < 15 then
                                                v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]][v52[UNNAMED_2819781302040[v45]]];
                                            elseif v281 == 16 then
                                                v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781304248[v45]](UNNAMED_2819781303864[v45]);
                                            else
                                                local v444 = u18[UNNAMED_2819781304248[v45]];
                                                v52[UNNAMED_2819781301992[v45]] = v444[5][v444[4]];
                                            end;
                                        elseif v281 == 13 then
                                            v45 = v52[UNNAMED_2819781302040[v45]];
                                        elseif v52[UNNAMED_2819781301992[v45]] > UNNAMED_2819781304248[v45] then
                                            v45 = UNNAMED_2819781302040[v45];
                                        end;
                                    elseif v281 < 10 then
                                        if v281 == 9 then
                                            v44 = v52[UNNAMED_2819781301992[v45]];
                                        else
                                            local v445 = u30(UNNAMED_2819781302040[v45], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                                            local v446 = UNNAMED_2819781304248[v45] + 1;

                                            for i = 1, UNNAMED_2819781301992[v45] do
                                                local v447 = u29(u30(v445, (u31(v445, 13))), 536870911);
                                                local v448 = u30(v447, (u28(v447, 13)));
                                                v445 = u29(u30(v448, (u31(v448, 14))), 536870911);
                                                UNNAMED_2819781304248[v446] = u30(UNNAMED_2819781304248[v446], (u29(u28(v445, 0), 127)));
                                                UNNAMED_2819781302040[v446] = u30(UNNAMED_2819781302040[v446], (u29(u28(v445, 7), 127)));
                                                UNNAMED_2819781301992[v446] = u30(UNNAMED_2819781301992[v446], (u29(u28(v445, 14), 127)));
                                                UNNAMED_2819781304296[v446] = u30(UNNAMED_2819781304296[v446], (u29(u28(v445, 21), 127)));
                                                v446 = v446 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819781304296[v45] = 64;
                                        end;
                                    elseif v281 == 11 then
                                        v52[UNNAMED_2819781302040[v45]] = #v52[UNNAMED_2819781301992[v45]];
                                    else
                                        v52[UNNAMED_2819781301992[v45]] = v52[UNNAMED_2819781302040[v45]] == UNNAMED_2819781304248[v45];
                                    end;

                                    v280 = 1;
                                    continue;
                                end;

                                if v281 >= 4 then
                                    if v281 >= 6 then
                                        if v281 == 7 then
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] + v52[UNNAMED_2819781302040[v45]];
                                        else
                                            local v449 = UNNAMED_2819781302040[v45];
                                            local v450 = UNNAMED_2819781301992[v45];
                                            v52[v449] = v52[UNNAMED_2819781304248[v45]];
                                            v52[v449 + 1] = v450;
                                        end;
                                    elseif v281 == 5 then
                                        v53 = {
                                            [9] = v53,
                                            [7] = v51,
                                            [8] = v50,
                                            [5] = v54,
                                            [6] = v48
                                        };
                                        local v451 = UNNAMED_2819781301992[v45];
                                        v51 = v52[v451 + 2] + 0;
                                        v54 = v52[v451 + 1] + 0;
                                        v50 = v52[v451] - v51;
                                        v45 = UNNAMED_2819781304248[v45];
                                    else
                                        local v452 = u18[UNNAMED_2819781304248[v45]];
                                        v52[UNNAMED_2819781301992[v45]] = v452[5][v452[4]];
                                        v52[UNNAMED_2819781304248[v45 + 1]](UNNAMED_2819781303816[v45 + 1], UNNAMED_2819781303864[v45 + 1]);
                                        local v453 = u18[UNNAMED_2819781301992[v45 + 2]];
                                        v453[5][v453[4]] = UNNAMED_2819781304008[v45 + 2];
                                        local v454 = u18[UNNAMED_2819781304248[v45 + 3]];
                                        v52[UNNAMED_2819781301992[v45 + 3]] = v454[5][v454[4]];
                                        v52[UNNAMED_2819781302040[v45 + 4]]();
                                        v45 = v45 + 4;
                                    end;

                                    v280 = 1;
                                    continue;
                                end;

                                if v281 >= 2 then
                                    if v281 == 3 then
                                        v52[UNNAMED_2819781302040[v45]] = u29(v52[UNNAMED_2819781301992[v45]], UNNAMED_2819781304008[v45]);
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781301992[v45]] < UNNAMED_2819781302040[v45];
                                    end;

                                    v280 = 1;
                                    continue;
                                end;

                                if v281 == 1 then
                                    v46 = UNNAMED_2819781302040[v45];
                                    v45 = UNNAMED_2819781304248[v45] + 1;
                                    v57 = 8;
                                    break;
                                end;

                                v52[UNNAMED_2819781302040[v45]] = u37(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781303816[v45]);
                            end;

                            v280 = 1;
                            continue;
                        elseif v280 == 1 then
                            v280 = -1;
                            v45 = v45 + 1;
                            break;
                        else
                            break;
                        end;
                    end;

                    if v57 ~= -1 then
                        break;
                    end;
                end;

                if v57 ~= -1 then
                    continue;
                end;

                v57 = 10;
                continue;
            elseif v57 == 10 then
                v57 = -1;

                while true do
                    local v45;
                    local v455 = 0;

                    while true do
                        if v455 == 0 then
                            v455 = -1;
                            local v456 = UNNAMED_2819781301992[v45];

                            if v456 < 43 then
                                if v456 >= 21 then
                                    if v456 < 32 then
                                        if v456 >= 26 then
                                            if v456 < 29 then
                                                if v456 < 27 then
                                                    local v457 = UNNAMED_2819781304296[v45];
                                                    local v458, v459 = v50();

                                                    if v458 then
                                                        v52[v457] = v459;
                                                        v45 = UNNAMED_2819781304248[v45];
                                                    else
                                                        v45 = UNNAMED_2819781302040[v45];
                                                    end;
                                                elseif v456 == 28 then
                                                    local v460 = u18[UNNAMED_2819781304296[v45]];
                                                    v460[5][v460[4]] = UNNAMED_2819781303864[v45];
                                                else
                                                    v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781301992;
                                                end;
                                            elseif v456 < 30 then
                                                v50 = v50 + v51;
                                                local v461;

                                                if v51 <= 0 then
                                                    v461 = v54 <= v50;
                                                else
                                                    v461 = v50 <= v54;
                                                end;

                                                if v461 then
                                                    v52[UNNAMED_2819781304248[v45]] = v50;
                                                    v45 = UNNAMED_2819781302040[v45];
                                                else
                                                    v45 = UNNAMED_2819781304296[v45];
                                                end;
                                            elseif v456 == 31 then
                                                local v462 = UNNAMED_2819781302040[v45];
                                                local v463 = UNNAMED_2819781304296[v45];
                                                local v464 = UNNAMED_2819781304248[v45];
                                                local _ = v462 + v464 - 1;
                                                local _ = v462 + v463;
                                                u27(u25(v52[v462](u26(v52, v462 + 1, v462 + v463))), 1, v464, v462, v52);
                                            else
                                                v43 = v52[UNNAMED_2819781304296[v45]];
                                            end;
                                        elseif v456 < 23 then
                                            if v456 == 22 then
                                                v52[UNNAMED_2819781302040[v45]][UNNAMED_2819781304008[v45]] = v52[UNNAMED_2819781304296[v45]];
                                            else
                                                local v465 = UNNAMED_2819781304248[v45];
                                                local v466 = v52[UNNAMED_2819781304296[v45]];
                                                v52[v465] = v52[UNNAMED_2819781302040[v45]];
                                                v52[v465 + 1] = v466;
                                            end;
                                        elseif v456 >= 24 then
                                            if v456 == 25 then
                                                local v467 = UNNAMED_2819781302040[v45];
                                                local v468 = u30(UNNAMED_2819781304248[v45], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                                                local v469 = UNNAMED_2819781303960[5];
                                                local v470 = u30(v469[v467], 109162203);
                                                v469[v467] = v470;
                                                local v471 = UNNAMED_2819781303960[4];
                                                local v472 = v470 + 1;
                                                local v473 = u32(v471, v472);
                                                local v474;

                                                if v473 < 128 then
                                                    v474 = v472 + 1;
                                                else
                                                    local v475 = u32(v471, v472 + 1);

                                                    if v475 < 128 then
                                                        v473 = v473 - 128 + v475 * 128;
                                                        v474 = v472 + 2;
                                                    else
                                                        local v476 = u32(v471, v472 + 2);

                                                        if v476 < 128 then
                                                            v473 = v473 - 128 + (v475 - 128) * 16384 + v476 * 128;
                                                            v474 = v472 + 3;
                                                        else
                                                            local v477 = u32(v471, v472 + 3);
                                                            v473 = (v473 - 128) * 16384 + (v475 - 128) * 128 + (v476 - 128) + v477 % 128 * 2097152 + (v477 - v477 % 128) * 2097152;
                                                            v474 = v472 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v478 = v468 * 16843009;
                                                local v479 = v474 + v473;
                                                local v480 = v479 - v473 % 4;

                                                for i = v474, v480 - 1, 4 do
                                                    u33(v471, i, (u30(u34(v471, i), v478)));
                                                    local _ = i;
                                                end;

                                                for i = v480, v479 - 1 do
                                                    u35(v471, i, (u30(u32(v471, i), v468)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819781302040[v45] = 232;
                                                UNNAMED_2819781304248[v45] = 48;
                                                UNNAMED_2819781304296[v45] = 59;
                                                UNNAMED_2819781301992[v45] = 17;
                                            else
                                                local v481 = UNNAMED_2819781304296[v45];
                                                local v482 = u38(u39);
                                                v482(UNNAMED_2819781304056, v52[v481], v52[v481 + 1], v52[v481 + 2]);
                                                local v483 = UNNAMED_2819781304248[v45];
                                                v45 = UNNAMED_2819781302040[v45];
                                                v48 = v483;
                                                v50 = v482;
                                                v53 = {
                                                    [9] = v53,
                                                    [7] = v51,
                                                    [8] = v50,
                                                    [5] = v54,
                                                    [6] = v48
                                                };
                                            end;
                                        elseif v52[UNNAMED_2819781304248[v45]] > UNNAMED_2819781302040[v45] then
                                            v45 = UNNAMED_2819781304296[v45];
                                        end;
                                    elseif v456 >= 37 then
                                        if v456 < 40 then
                                            if v456 < 38 then
                                                local v484 = UNNAMED_2819781302040[v45];
                                                local v485 = UNNAMED_2819781304248[v45];
                                                local v486 = u30(v44, u29(u28(v44, 14), 262143), (u29(u28(v44, 28), 15)));
                                                local v487 = UNNAMED_2819781304296[v45];
                                                local v488 = v487 < 2097152 and 7 or 14;
                                                local v489 = u29(v487, u31(1, v488) - 1);
                                                local v490 = u28(v487, v488);
                                                UNNAMED_2819781304248[v45] = u30(v485, 95, (u29(u28(v486, 7), 127)));
                                                UNNAMED_2819781304296[v45] = u30(v489, 67, (u29(u28(v486, 14), 127)));
                                                UNNAMED_2819781302040[v45] = u30(v484, 77, (u29(v486, 127)));
                                                UNNAMED_2819781301992[v45] = u30(v490, 1, (u29(u28(v486, 21), 127)));
                                                v45 = v45 - 1;
                                            elseif v456 == 39 then
                                                v52[UNNAMED_2819781304296[v45]](UNNAMED_2819781304008[v45], UNNAMED_2819781303864[v45]);
                                            else
                                                v52[UNNAMED_2819781304296[v45]] = not v52[UNNAMED_2819781302040[v45]];
                                            end;
                                        elseif v456 < 41 then
                                            local v491 = UNNAMED_2819781304296[v45];
                                            local v492 = u30(v44, u29(u28(v44, 14), 262143), (u29(u28(v44, 28), 15)));
                                            local v493 = UNNAMED_2819781304248[v45];
                                            local v494 = UNNAMED_2819781302040[v45];
                                            local v495 = v491 < 16384 and 7 or (v491 < 2097152 and 14 or 21);
                                            local v496 = u28(v491, v495);
                                            local v497 = u29(v491, u31(1, v495) - 1);
                                            UNNAMED_2819781301992[v45] = u30(v496, 28, (u29(u28(v492, 21), 127)));
                                            UNNAMED_2819781304248[v45] = u30(v493, 63, (u29(u28(v492, 7), 127)));
                                            UNNAMED_2819781302040[v45] = u30(v494, 27, (u29(v492, 127)));
                                            UNNAMED_2819781304296[v45] = u30(v497, 23, (u29(u28(v492, 14), 127)));
                                            v45 = v45 - 1;
                                        elseif v456 == 42 then
                                            v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781304296;
                                        else
                                            v52[UNNAMED_2819781304296[v45]] = UNNAMED_2819781302040[v45] * v52[UNNAMED_2819781304248[v45]];
                                        end;
                                    elseif v456 >= 34 then
                                        if v456 >= 35 then
                                            if v456 == 36 then
                                                v52[UNNAMED_2819781304248[v45]] = v43;
                                            else
                                                v52[UNNAMED_2819781304296[v45]] = v44;
                                            end;
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781304296[v45] + v52[UNNAMED_2819781302040[v45]];
                                        end;
                                    elseif v456 == 33 then
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781304296[v45]] + UNNAMED_2819781302040[v45];
                                    else
                                        v52[UNNAMED_2819781304296[v45]] = -v52[UNNAMED_2819781302040[v45]];
                                    end;
                                elseif v456 < 10 then
                                    if v456 < 5 then
                                        if v456 >= 2 then
                                            if v456 < 3 then
                                                local v498 = UNNAMED_2819781302040[v45];
                                                local v499 = UNNAMED_2819781304248[v45];
                                                local v500 = {
                                                    n = v499 - v498 + 1
                                                };
                                                u27(v52, v498, v499, 1, v500);
                                                v52[UNNAMED_2819781304296[v45]] = v500;
                                            elseif v456 == 4 then
                                                v52[UNNAMED_2819781304296[v45]] = u30(v52[UNNAMED_2819781302040[v45]], UNNAMED_2819781304248[v45]);
                                            else
                                                v45 = UNNAMED_2819781304248[v45];
                                            end;
                                        elseif v456 == 1 then
                                            local v501 = v52[UNNAMED_2819781304248[v45]] % 4294967296;
                                            v52[UNNAMED_2819781302040[v45]] = v501 ~= v501 and 0 or v501 - v501 % 1;
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781304056[UNNAMED_2819781302040[v45]];
                                        end;
                                    elseif v456 >= 7 then
                                        if v456 >= 8 then
                                            if v456 == 9 then
                                                v53 = {
                                                    [9] = v53,
                                                    [7] = v51,
                                                    [8] = v50,
                                                    [5] = v54,
                                                    [6] = v48
                                                };
                                                local v502 = UNNAMED_2819781302040[v45];
                                                v51 = v52[v502 + 2] + 0;
                                                v54 = v52[v502 + 1] + 0;
                                                v50 = v52[v502] - v51;
                                                v45 = UNNAMED_2819781304248[v45];
                                            else
                                                v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] < UNNAMED_2819781304296[v45];
                                            end;
                                        else
                                            v52[UNNAMED_2819781302040[v45]][v52[UNNAMED_2819781304248[v45]]] = v52[UNNAMED_2819781304296[v45]];
                                        end;
                                    elseif v456 == 6 then
                                        v52[UNNAMED_2819781304296[v45]] = v52[UNNAMED_2819781302040[v45]] == UNNAMED_2819781304248[v45];
                                    else
                                        v52[UNNAMED_2819781304248[v45]](UNNAMED_2819781303912[v45]);
                                    end;
                                elseif v456 >= 15 then
                                    if v456 < 18 then
                                        if v456 < 16 then
                                            v52[UNNAMED_2819781304296[v45]] = v52[UNNAMED_2819781302040[v45]] - UNNAMED_2819781304008[v45];
                                        elseif v456 ~= 17 then
                                            v52[UNNAMED_2819781304248[v45]] = u29(v52[UNNAMED_2819781304296[v45]], v52[UNNAMED_2819781302040[v45]]);
                                        end;
                                    elseif v456 < 19 then
                                        v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304248[v45]] % v52[UNNAMED_2819781304296[v45]];
                                    elseif v456 == 20 then
                                        local v503 = u18[UNNAMED_2819781304248[v45]];
                                        v52[UNNAMED_2819781304296[v45]] = v503[5][v503[4]][v52[UNNAMED_2819781302040[v45]]];
                                    else
                                        local v504 = UNNAMED_2819781304248[v45];
                                        local v505 = v52[UNNAMED_2819781304296[v45]];
                                        local v506 = u29(v52[UNNAMED_2819781302040[v45]], 4294967295);
                                        local v507 = u29(v505, 4294967295);
                                        local v508 = u29(v506, 65535);
                                        local v509 = u28(v506, 16);
                                        local v510 = u29(v507, 65535);
                                        local v511 = u28(v507, 16);
                                        local v512 = u29(v508 * v510 + u31(u29(v508 * v511 + v509 * v510, 65535), 16), 4294967295) % 4294967296;
                                        v52[v504] = v512 ~= v512 and 0 or v512 - v512 % 1;
                                    end;
                                elseif v456 >= 12 then
                                    if v456 < 13 then
                                        v52[UNNAMED_2819781304296[v45]]();
                                    elseif v456 == 14 then
                                        v52[UNNAMED_2819781304248[v45]] = {};
                                    else
                                        local v513 = u18[UNNAMED_2819781304248[v45]];
                                        v52[UNNAMED_2819781302040[v45]] = v513[5][v513[4]];
                                    end;
                                elseif v456 == 11 then
                                    v52[UNNAMED_2819781304296[v45]] = v52[UNNAMED_2819781304248[v45]] + v52[UNNAMED_2819781302040[v45]];
                                else
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] ~= UNNAMED_2819781304296[v45];
                                end;
                            elseif v456 < 65 then
                                if v456 >= 54 then
                                    if v456 < 59 then
                                        if v456 >= 56 then
                                            if v456 < 57 then
                                                v52[UNNAMED_2819781304296[v45]] = UNNAMED_2819781303864[v45];
                                            elseif v456 == 58 then
                                                v52[UNNAMED_2819781304248[v45]] = u37(v52[UNNAMED_2819781302040[v45]], v52[UNNAMED_2819781304296[v45]]);
                                            elseif v52[UNNAMED_2819781304296[v45]] then
                                                v45 = UNNAMED_2819781304248[v45];
                                            else
                                                v45 = UNNAMED_2819781302040[v45];
                                            end;
                                        elseif v456 == 55 then
                                            local v514 = u18[UNNAMED_2819781304248[v45]];
                                            v514[5][v514[4]][UNNAMED_2819781303912[v45]] = v52[UNNAMED_2819781302040[v45]];
                                        else
                                            v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304296[v45]] % UNNAMED_2819781304248[v45];
                                        end;
                                    elseif v456 >= 62 then
                                        if v456 < 63 then
                                            if v49 then
                                                for i in u40, v49 do
                                                    local v515 = v49[i];

                                                    if v515 then
                                                        v515[5] = v515;
                                                        v515[6] = v52[i];
                                                        v515[4] = 6;
                                                        v49[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v55 then
                                                for i, v in u40, v55 do
                                                    local v516 = v[6];

                                                    if v55 then
                                                        local v517 = v55[i];

                                                        if v517 then
                                                            local v518 = u24(v516);
                                                            u27(v52, i, i + v516 - 1, 1, v518);
                                                            v517[5] = v518;
                                                            v517[4] = 1;
                                                            v55[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return;
                                        end;

                                        if v456 == 64 then
                                            v52[UNNAMED_2819781304296[v45]] = u30(v52[UNNAMED_2819781304248[v45]], UNNAMED_2819781303864[v45]);
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] == v52[UNNAMED_2819781304296[v45]];
                                        end;
                                    elseif v456 < 60 then
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781304296[v45]] * UNNAMED_2819781302040[v45];
                                    elseif v456 == 61 then
                                        v45 = v52[UNNAMED_2819781302040[v45]];
                                    else
                                        v52[UNNAMED_2819781304248[v45]] = UNNAMED_2819781302040[v45];
                                    end;
                                elseif v456 >= 48 then
                                    if v456 >= 51 then
                                        if v456 >= 52 then
                                            if v456 == 53 then
                                                v52[UNNAMED_2819781304296[v45]] = UNNAMED_2819781303960;
                                            else
                                                v52[UNNAMED_2819781304248[v45]] = u29(v52[UNNAMED_2819781302040[v45]], UNNAMED_2819781304296[v45]);
                                            end;
                                        else
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] // UNNAMED_2819781304296[v45];
                                        end;
                                    elseif v456 >= 49 then
                                        if v456 == 50 then
                                            v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304296[v45]] - UNNAMED_2819781304248[v45];
                                        else
                                            local v519 = UNNAMED_2819781302040[v45];
                                            local v520 = UNNAMED_2819781304248[v45] + 1;

                                            for i = 1, UNNAMED_2819781304296[v45] do
                                                local v521 = u29(u30(v519, (u31(v519, 13))), 536870911);
                                                local v522 = u30(v521, (u28(v521, 13)));
                                                v519 = u29(u30(v522, (u31(v522, 14))), 536870911);
                                                UNNAMED_2819781302040[v520] = u30(UNNAMED_2819781302040[v520], (u29(u28(v519, 0), 127)));
                                                UNNAMED_2819781304248[v520] = u30(UNNAMED_2819781304248[v520], (u29(u28(v519, 7), 127)));
                                                UNNAMED_2819781304296[v520] = u30(UNNAMED_2819781304296[v520], (u29(u28(v519, 14), 127)));
                                                UNNAMED_2819781301992[v520] = u30(UNNAMED_2819781301992[v520], (u29(u28(v519, 21), 127)));
                                                v520 = v520 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819781301992[v45] = 17;
                                        end;
                                    else
                                        v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304248[v45]](v52[UNNAMED_2819781304296[v45]]);
                                    end;
                                elseif v456 < 45 then
                                    if v456 == 44 then
                                        if v52[UNNAMED_2819781304296[v45]] then
                                            v45 = UNNAMED_2819781304248[v45];
                                        else
                                            v45 = UNNAMED_2819781302040[v45];
                                        end;
                                    else
                                        v45 = v52[UNNAMED_2819781304248[v45]];
                                    end;
                                elseif v456 >= 46 then
                                    if v456 == 47 then
                                        local v523 = u30(UNNAMED_2819781304248[v45], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                                        local v524 = UNNAMED_2819781302040[v45] + 1;

                                        for i = 1, UNNAMED_2819781304296[v45] do
                                            local v525 = u29(u30(v523, (u31(v523, 13))), 536870911);
                                            local v526 = u30(v525, (u28(v525, 13)));
                                            v523 = u29(u30(v526, (u31(v526, 14))), 536870911);
                                            UNNAMED_2819781302040[v524] = u30(UNNAMED_2819781302040[v524], (u29(u28(v523, 0), 127)));
                                            UNNAMED_2819781304248[v524] = u30(UNNAMED_2819781304248[v524], (u29(u28(v523, 7), 127)));
                                            UNNAMED_2819781304296[v524] = u30(UNNAMED_2819781304296[v524], (u29(u28(v523, 14), 127)));
                                            UNNAMED_2819781301992[v524] = u30(UNNAMED_2819781301992[v524], (u29(u28(v523, 21), 127)));
                                            v524 = v524 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819781301992[v45] = 17;
                                    elseif v49 then
                                        local v527 = UNNAMED_2819781304248[v45];
                                        local v528 = v49[v527];

                                        if v528 then
                                            v528[5] = v528;
                                            v528[6] = v52[v527];
                                            v528[4] = 6;
                                            v49[v527] = nil;
                                        end;

                                        local v529 = UNNAMED_2819781304296[v45];
                                        local v530 = v49[v529];

                                        if v530 then
                                            v530[5] = v530;
                                            v530[6] = v52[v529];
                                            v530[4] = 6;
                                            v49[v529] = nil;
                                        end;
                                    end;
                                else
                                    v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] + UNNAMED_2819781303912[v45];
                                end;
                            elseif v456 >= 76 then
                                if v456 >= 81 then
                                    if v456 < 84 then
                                        if v456 >= 82 then
                                            if v456 == 83 then
                                                local v531 = u30(UNNAMED_2819781304248[v45], (u29(u30(v43, (u29(u28(v43, 29), 7))), 536870911)));
                                                local v532 = UNNAMED_2819781302040[v45] + 1;

                                                for i = 1, UNNAMED_2819781304296[v45] do
                                                    local v533 = u29(u30(v531, (u31(v531, 13))), 536870911);
                                                    local v534 = u30(v533, (u28(v533, 13)));
                                                    v531 = u29(u30(v534, (u31(v534, 14))), 536870911);
                                                    UNNAMED_2819781302040[v532] = u30(UNNAMED_2819781302040[v532], (u29(u28(v531, 0), 127)));
                                                    UNNAMED_2819781304248[v532] = u30(UNNAMED_2819781304248[v532], (u29(u28(v531, 7), 127)));
                                                    UNNAMED_2819781304296[v532] = u30(UNNAMED_2819781304296[v532], (u29(u28(v531, 14), 127)));
                                                    UNNAMED_2819781301992[v532] = u30(UNNAMED_2819781301992[v532], (u29(u28(v531, 21), 127)));
                                                    v532 = v532 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819781301992[v45] = 17;
                                            else
                                                v52[UNNAMED_2819781302040[v45]] = u30(v52[UNNAMED_2819781304248[v45]], v52[UNNAMED_2819781304296[v45]]);
                                            end;
                                        else
                                            v52[UNNAMED_2819781304296[v45]] = v52[UNNAMED_2819781304248[v45]] * v52[UNNAMED_2819781302040[v45]];
                                        end;
                                    elseif v456 < 85 then
                                        v44 = v52[UNNAMED_2819781304296[v45]];
                                    elseif v456 == 86 then
                                        v50 = v53[8];
                                        v54 = v53[5];
                                        v51 = v53[7];
                                        v48 = v53[6];
                                        v53 = v53[9];
                                    else
                                        v52[UNNAMED_2819781304248[v45]](v52[UNNAMED_2819781304296[v45]]);
                                    end;
                                elseif v456 < 78 then
                                    if v456 == 77 then
                                        if v52[UNNAMED_2819781304296[v45]] >= UNNAMED_2819781304248[v45] then
                                            v45 = UNNAMED_2819781302040[v45];
                                        end;
                                    else
                                        local v535 = UNNAMED_2819781304296[v45];
                                        local v536 = UNNAMED_2819781304248[v45];
                                        local v537 = UNNAMED_2819781303960[5];
                                        local v538 = u30(v537[v535], 109162203);
                                        v537[v535] = v538;
                                        local v539 = UNNAMED_2819781303960[4];
                                        local v540 = v538 + 1;
                                        local v541 = u32(v539, v540);
                                        local v542;

                                        if v541 < 128 then
                                            v542 = v540 + 1;
                                        else
                                            local v543 = u32(v539, v540 + 1);

                                            if v543 < 128 then
                                                v541 = v541 - 128 + v543 * 128;
                                                v542 = v540 + 2;
                                            else
                                                local v544 = u32(v539, v540 + 2);

                                                if v544 < 128 then
                                                    v541 = v541 - 128 + (v543 - 128) * 16384 + v544 * 128;
                                                    v542 = v540 + 3;
                                                else
                                                    local v545 = u32(v539, v540 + 3);
                                                    v541 = (v541 - 128) * 16384 + (v543 - 128) * 128 + (v544 - 128) + v545 % 128 * 2097152 + (v545 - v545 % 128) * 2097152;
                                                    v542 = v540 + 4;
                                                end;
                                            end;
                                        end;

                                        local v546 = v536 * 16843009;
                                        local v547 = v542 + v541;
                                        local v548 = v547 - v541 % 4;

                                        for i = v542, v548 - 1, 4 do
                                            u33(v539, i, (u30(u34(v539, i), v546)));
                                            local _ = i;
                                        end;

                                        for i = v548, v547 - 1 do
                                            u35(v539, i, (u30(u32(v539, i), v536)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819781304296[v45] = 176;
                                        UNNAMED_2819781304248[v45] = 125;
                                        UNNAMED_2819781302040[v45] = 24;
                                        UNNAMED_2819781301992[v45] = 17;
                                    end;
                                elseif v456 < 79 then
                                    local v549 = UNNAMED_2819781302040[v45];
                                    local v550 = u30(UNNAMED_2819781304248[v45], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                                    local v551 = UNNAMED_2819781303960[5];
                                    local v552 = u30(v551[v549], 109162203);
                                    v551[v549] = v552;
                                    local v553 = UNNAMED_2819781303960[4];
                                    local v554 = v552 + 1;
                                    local v555 = u32(v553, v554);
                                    local v556;

                                    if v555 < 128 then
                                        v556 = v554 + 1;
                                    else
                                        local v557 = u32(v553, v554 + 1);

                                        if v557 < 128 then
                                            v555 = v555 - 128 + v557 * 128;
                                            v556 = v554 + 2;
                                        else
                                            local v558 = u32(v553, v554 + 2);

                                            if v558 < 128 then
                                                v555 = v555 - 128 + (v557 - 128) * 16384 + v558 * 128;
                                                v556 = v554 + 3;
                                            else
                                                local v559 = u32(v553, v554 + 3);
                                                v555 = (v555 - 128) * 16384 + (v557 - 128) * 128 + (v558 - 128) + v559 % 128 * 2097152 + (v559 - v559 % 128) * 2097152;
                                                v556 = v554 + 4;
                                            end;
                                        end;
                                    end;

                                    local v560 = v550 * 16843009;
                                    local v561 = v556 + v555;
                                    local v562 = v561 - v555 % 4;

                                    for i = v556, v562 - 1, 4 do
                                        u33(v553, i, (u30(u34(v553, i), v560)));
                                        local _ = i;
                                    end;

                                    for i = v562, v561 - 1 do
                                        u35(v553, i, (u30(u32(v553, i), v550)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819781302040[v45] = 117;
                                    UNNAMED_2819781304248[v45] = 65;
                                    UNNAMED_2819781304296[v45] = 128;
                                    UNNAMED_2819781301992[v45] = 17;
                                elseif v456 == 80 then
                                    local v563 = u18[UNNAMED_2819781304248[v45]];
                                    v563[5][v563[4]] = v52[UNNAMED_2819781304296[v45]];
                                elseif v52[UNNAMED_2819781302040[v45]] ~= UNNAMED_2819781304248[v45] then
                                    v45 = UNNAMED_2819781304296[v45];
                                end;
                            else
                                if v456 < 70 then
                                    if v456 < 67 then
                                        if v456 == 66 then
                                            v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781304296[v45]];
                                        else
                                            v52[UNNAMED_2819781302040[v45]] = UNNAMED_2819781304248;
                                        end;
                                    elseif v456 >= 68 then
                                        if v456 == 69 then
                                            if v52[UNNAMED_2819781304248[v45]] ~= v52[UNNAMED_2819781302040[v45]] then
                                                v45 = UNNAMED_2819781304296[v45];
                                            end;
                                        elseif UNNAMED_2819781304296[v45] >= v52[UNNAMED_2819781302040[v45]] then
                                            v45 = UNNAMED_2819781304248[v45];
                                        end;
                                    else
                                        local v564 = nil;
                                        local v565 = UNNAMED_2819781302040[v45];
                                        local v566 = UNNAMED_2819781303912[v45];
                                        local v567 = UNNAMED_2819781304008[v45];
                                        local v568 = v567[0];

                                        if v568 then
                                            local v569 = #v568 / 3;

                                            if v569 > 0 then
                                                v564 = {};

                                                for i = 1, v569 do
                                                    local v570 = (i - 1) * 3;
                                                    local v571 = v568[v570 + 2];
                                                    local v572 = v568[v570 + 1];
                                                    local v573;

                                                    if v571 == 2 then
                                                        v49 = v49 or {};
                                                        local v574 = v49[v572];

                                                        if not v574 then
                                                            v574 = {
                                                                [5] = v52,
                                                                [4] = v572
                                                            };
                                                            v49[v572] = v574;
                                                        end;

                                                        v564[i] = v574;
                                                        v573 = i;
                                                    elseif v571 == 0 then
                                                        v564[i] = v52[v572];
                                                        v573 = i;
                                                    elseif v571 == 3 then
                                                        v564[i] = u18[v572];
                                                        v573 = i;
                                                    elseif v571 == 1 then
                                                        v55 = v55 or {};
                                                        local v575 = v55[v572];

                                                        if not v575 then
                                                            v575 = {
                                                                [5] = v52,
                                                                [4] = v572,
                                                                [6] = v568[v570 + 3]
                                                            };
                                                            v55[v572] = v575;
                                                        end;

                                                        v564[i] = v575;
                                                        v573 = i;
                                                    else
                                                        v573 = i;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v576 = v567[-2];
                                        v567[v576] = v564;
                                        local v577 = v566(u26(v567, 1, v567[-1]));
                                        v567[v576] = nil;
                                        v52[v565] = v577;
                                    end;

                                    v455 = 1;
                                    continue;
                                end;

                                if v456 >= 73 then
                                    if v456 >= 74 then
                                        if v456 == 75 then
                                            v52[UNNAMED_2819781302040[v45]] = v52[UNNAMED_2819781304248[v45]]();
                                        else
                                            local v578 = u18[UNNAMED_2819781304248[v45]];
                                            v578[5][v578[4]][v52[UNNAMED_2819781302040[v45]]] = v52[UNNAMED_2819781304296[v45]];
                                        end;
                                    else
                                        v52[UNNAMED_2819781304296[v45]] = UNNAMED_2819781302040;
                                    end;

                                    v455 = 1;
                                    continue;
                                end;

                                if v456 >= 71 then
                                    if v456 ~= 72 then
                                        v52[UNNAMED_2819781304248[v45]] = v52[UNNAMED_2819781302040[v45]] - v52[UNNAMED_2819781304296[v45]];
                                        v455 = 1;
                                        continue;
                                    end;

                                    v46 = UNNAMED_2819781304248[v45];
                                    v45 = UNNAMED_2819781304296[v45] + 1;
                                    v57 = 7;
                                    break;
                                end;

                                v52[UNNAMED_2819781302040[v45]] = u29(v52[UNNAMED_2819781304296[v45]], UNNAMED_2819781304008[v45]);
                            end;

                            v455 = 1;
                            continue;
                        elseif v455 == 1 then
                            v455 = -1;
                            v45 = v45 + 1;
                            break;
                        else
                            break;
                        end;
                    end;

                    if v57 ~= -1 then
                        break;
                    end;
                end;

                if v57 ~= -1 then
                    continue;
                end;

                v57 = 11;
                continue;
            elseif v57 == 11 then
                v57 = -1;
                v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781304296[v47]] * v52[UNNAMED_2819781302040[v47]];
                v57 = 12;
                continue;
            elseif v57 == 12 then
                v57 = -1;
                v57 = 14;
                continue;
            elseif v57 == 13 then
                v57 = -1;

                if v56 < 60 then
                    if v56 == 59 then
                        v50 = v50 + v51;
                        local v579;

                        if v51 <= 0 then
                            v579 = v54 <= v50;
                        else
                            v579 = v50 <= v54;
                        end;

                        if v579 then
                            v52[UNNAMED_2819781302040[v47]] = v50;
                            v47 = UNNAMED_2819781301992[v47];
                        else
                            v47 = UNNAMED_2819781304296[v47];
                        end;
                    else
                        v52[UNNAMED_2819781301992[v47]] = u30(v52[UNNAMED_2819781304296[v47]], UNNAMED_2819781302040[v47]);
                    end;
                elseif v56 >= 61 then
                    if v56 ~= 62 and UNNAMED_2819781303912[v47] > v52[UNNAMED_2819781301992[v47]] then
                        v47 = UNNAMED_2819781302040[v47];
                    end;
                else
                    local v580 = UNNAMED_2819781301992[v47];
                    local v581 = u30(UNNAMED_2819781302040[v47], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                    local v582 = UNNAMED_2819781303960[5];
                    local v583 = u30(v582[v580], 109162203);
                    v582[v580] = v583;
                    local v584 = UNNAMED_2819781303960[4];
                    local v585 = v583 + 1;
                    local v586 = u32(v584, v585);
                    local v587;

                    if v586 < 128 then
                        v587 = v585 + 1;
                    else
                        local v588 = u32(v584, v585 + 1);

                        if v588 < 128 then
                            v586 = v586 - 128 + v588 * 128;
                            v587 = v585 + 2;
                        else
                            local v589 = u32(v584, v585 + 2);

                            if v589 < 128 then
                                v586 = v586 - 128 + (v588 - 128) * 16384 + v589 * 128;
                                v587 = v585 + 3;
                            else
                                local v590 = u32(v584, v585 + 3);
                                v586 = (v586 - 128) * 16384 + (v588 - 128) * 128 + (v589 - 128) + v590 % 128 * 2097152 + (v590 - v590 % 128) * 2097152;
                                v587 = v585 + 4;
                            end;
                        end;
                    end;

                    local v591 = v581 * 16843009;
                    local v592 = v587 + v586;
                    local v593 = v592 - v586 % 4;

                    for i = v587, v593 - 1, 4 do
                        u33(v584, i, (u30(u34(v584, i), v591)));
                        local _ = i;
                    end;

                    for i = v593, v592 - 1 do
                        u35(v584, i, (u30(u32(v584, i), v581)));
                        local _ = i;
                    end;

                    UNNAMED_2819781301992[v47] = 22;
                    UNNAMED_2819781302040[v47] = 188;
                    UNNAMED_2819781304296[v47] = 154;
                    UNNAMED_2819781304248[v47] = 62;
                end;

                v57 = 14;
                continue;
            elseif v57 == 14 then
                v57 = -1;
                v57 = 16;
                continue;
            elseif v57 == 15 then
                v57 = -1;

                if v56 < 18 then
                    if v56 < 9 then
                        if v56 >= 4 then
                            if v56 >= 6 then
                                if v56 < 7 then
                                    v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781301992[v47]];
                                else
                                    if v56 == 8 then
                                        return;
                                    end;

                                    v47 = UNNAMED_2819781304296[v47];
                                end;
                            elseif v56 == 5 then
                                v52[UNNAMED_2819781304296[v47]] = v52[UNNAMED_2819781302040[v47]] - UNNAMED_2819781303816[v47];
                            else
                                v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781301992[v47]] % UNNAMED_2819781304296[v47];
                            end;
                        elseif v56 >= 2 then
                            if v56 == 3 then
                                local v594 = u18[UNNAMED_2819781302040[v47]];
                                v52[UNNAMED_2819781301992[v47]] = v594[5][v594[4]];
                            else
                                local v595 = UNNAMED_2819781302040[v47];
                                local v596 = v52[UNNAMED_2819781301992[v47]];
                                v52[v595] = v52[UNNAMED_2819781304296[v47]];
                                v52[v595 + 1] = v596;
                            end;
                        elseif v56 == 1 then
                            local v597 = UNNAMED_2819781301992[v47];
                            local v598 = UNNAMED_2819781304296[v47];
                            local v599 = UNNAMED_2819781302040[v47];
                            local _ = v597 + v599 - 1;
                            local _ = v597 + v598;
                            u27(u25(v52[v597](u26(v52, v597 + 1, v597 + v598))), 1, v599, v597, v52);
                        else
                            v52[UNNAMED_2819781304296[v47]] = v52[UNNAMED_2819781301992[v47]] == UNNAMED_2819781302040[v47];
                        end;
                    elseif v56 < 13 then
                        if v56 < 11 then
                            if v56 == 10 then
                                v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781304296[v47]] == v52[UNNAMED_2819781302040[v47]];
                            else
                                v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781304296[v47]] // UNNAMED_2819781302040[v47];
                            end;
                        elseif v56 == 12 then
                            v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781304296[v47]] > UNNAMED_2819781302040[v47];
                        else
                            v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781304296[v47]] - UNNAMED_2819781301992[v47];
                        end;
                    elseif v56 < 15 then
                        if v56 == 14 then
                            if v52[UNNAMED_2819781301992[v47]] > UNNAMED_2819781304296[v47] then
                                v47 = UNNAMED_2819781302040[v47];
                            end;
                        else
                            v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781304296[v47]][UNNAMED_2819781303816[v47]];
                        end;
                    elseif v56 < 16 then
                        v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781301992[v47]] + v52[UNNAMED_2819781304296[v47]];
                    else
                        if v56 ~= 17 then
                            return UNNAMED_2819781303864[v47];
                        end;

                        v52[UNNAMED_2819781302040[v47]] = UNNAMED_2819781301992[v47] + v52[UNNAMED_2819781304296[v47]];
                    end;
                elseif v56 >= 27 then
                    if v56 >= 31 then
                        if v56 < 33 then
                            if v56 == 32 then
                                v52[UNNAMED_2819781304296[v47]] = v44;
                            else
                                v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781304296[v47]] - v52[UNNAMED_2819781301992[v47]];
                            end;
                        elseif v56 >= 34 then
                            if v56 == 35 then
                                local v600 = u30(UNNAMED_2819781302040[v47], (u29(u30(v44, (u29(u28(v44, 29), 7))), 536870911)));
                                local v601 = UNNAMED_2819781301992[v47] + 1;

                                for i = 1, UNNAMED_2819781304296[v47] do
                                    local v602 = u29(u30(v600, (u31(v600, 13))), 536870911);
                                    local v603 = u30(v602, (u28(v602, 13)));
                                    v600 = u29(u30(v603, (u31(v603, 14))), 536870911);
                                    UNNAMED_2819781301992[v601] = u30(UNNAMED_2819781301992[v601], (u29(u28(v600, 0), 127)));
                                    UNNAMED_2819781302040[v601] = u30(UNNAMED_2819781302040[v601], (u29(u28(v600, 7), 127)));
                                    UNNAMED_2819781304296[v601] = u30(UNNAMED_2819781304296[v601], (u29(u28(v600, 14), 127)));
                                    UNNAMED_2819781304248[v601] = u30(UNNAMED_2819781304248[v601], (u29(u28(v600, 21), 127)));
                                    v601 = v601 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819781304248[v47] = 62;
                            else
                                v52[UNNAMED_2819781301992[v47]] = u18[UNNAMED_2819781302040[v47]][v52[UNNAMED_2819781304296[v47]]];
                            end;
                        else
                            v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781302040[v47]] * UNNAMED_2819781304296[v47];
                        end;
                    elseif v56 >= 29 then
                        if v56 == 30 then
                            v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781302040[v47]] * UNNAMED_2819781303912[v47];
                        else
                            v52[UNNAMED_2819781301992[v47]] = v52[UNNAMED_2819781304296[v47]](v52[UNNAMED_2819781302040[v47]]);
                        end;
                    elseif v56 == 28 then
                        v52[UNNAMED_2819781304296[v47]] = u30(v52[UNNAMED_2819781302040[v47]], v52[UNNAMED_2819781301992[v47]]);
                    else
                        v52[UNNAMED_2819781302040[v47]] = v43;
                    end;
                elseif v56 < 22 then
                    if v56 >= 20 then
                        if v56 == 21 then
                            local v604 = UNNAMED_2819781304296[v47];
                            local v605 = v52[UNNAMED_2819781301992[v47]];
                            v52[v604] = UNNAMED_2819781302040[v47];
                            v52[v604 + 1] = v605;
                        else
                            v43 = v52[UNNAMED_2819781304296[v47]];
                        end;
                    elseif v56 == 19 then
                        v52[UNNAMED_2819781301992[v47]] = u31(v52[UNNAMED_2819781302040[v47]], UNNAMED_2819781304296[v47]);
                    elseif v52[UNNAMED_2819781301992[v47]] then
                        v47 = UNNAMED_2819781304296[v47];
                    else
                        v47 = UNNAMED_2819781302040[v47];
                    end;
                elseif v56 < 24 then
                    if v56 == 23 then
                        v52[UNNAMED_2819781304296[v47]] = u18[UNNAMED_2819781302040[v47]];
                    else
                        v52[UNNAMED_2819781304296[v47]] = UNNAMED_2819781302040[v47] * v52[UNNAMED_2819781301992[v47]];
                    end;
                elseif v56 >= 25 then
                    if v56 == 26 then
                        local v606 = v52[UNNAMED_2819781301992[v47]] % 4294967296;
                        v52[UNNAMED_2819781302040[v47]] = v606 ~= v606 and 0 or v606 - v606 % 1;
                    else
                        v52[UNNAMED_2819781304296[v47]] = v52[UNNAMED_2819781302040[v47]] // v52[UNNAMED_2819781301992[v47]];
                    end;
                else
                    v52[UNNAMED_2819781302040[v47]] = v52[UNNAMED_2819781301992[v47]][v52[UNNAMED_2819781304296[v47]]];
                end;

                v57 = 16;
                continue;
            elseif v57 == 16 then
                v57 = -1;
                v47 = v47 + 1;
                v57 = 1;
                continue;
            elseif v57 == 17 then
                v57 = -1;
                break;
            else
                break;
            end;
        end;
    end;
end;