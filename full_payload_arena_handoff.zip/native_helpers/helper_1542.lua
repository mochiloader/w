-- Decompiled with Potassium's decompiler.

local v1 = 17;
local v2 = nil;
local v3 = nil;
local v4 = nil;
local v5 = nil;
local v6 = nil;
local v7 = nil;
local v8 = nil;
local v9 = nil;
local v10 = nil;
local v11 = nil;

while true do
    while v1 <= 14 do
        if v1 <= 6 then
            if v1 <= 2 then
                if v1 <= 0 then
                    local v12 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600 + 3);
                    v3 = (v3 - 128) * 16384 + (v4 - 128) * 128 + (v5 - 128) + v12 % 128 * 2097152 + (v12 - v12 % 128) * 2097152;
                    UNNAMED_2819735048600 = UNNAMED_2819735048600 + 4;
                    v1 = 26;
                elseif v1 <= 1 then
                    v3 = v3 - 128 + v4 * 128;
                    v6 = v6 + 2;
                    v1 = 11;
                else
                    local v13 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600 + 3);
                    v4 = (v4 - 128) * 16384 + (v5 - 128) * 128 + (v7 - 128) + v13 % 128 * 2097152 + (v13 - v13 % 128) * 2097152;
                    UNNAMED_2819735048600 = UNNAMED_2819735048600 + 4;
                    v1 = 9;
                end;
            elseif v1 <= 4 then
                if v1 <= 3 then
                    local v14 = v8[2];
                    local v15 = v8[3];
                    local v16 = v8[5] + v14;
                    local v17 = v14 <= 0;
                    local v18 = v15 <= v16;
                    v8[5] = v16;

                    if v17 and v18 and v18 or not v17 and v16 <= v15 then
                        v10 = v16;
                        v1 = 6;
                    else
                        v1 = 16;
                    end;
                else
                    UNNAMED_2819735034488 = (v4 * UNNAMED_2819735034488 + v5) % 256;
                    UNNAMED_2819735050520[93](v2, v3, (UNNAMED_2819735050520[11](UNNAMED_2819735050520[22](v9, v6 + v3), UNNAMED_2819735048600, UNNAMED_2819735034488)));
                    v1 = 14;
                end;
            elseif v1 <= 5 then
                local v19 = UNNAMED_2819735050520[22](v9, v6 + 3);
                v3 = (v3 - 128) * 16384 + (v4 - 128) * 128 + (v5 - 128) + v19 % 128 * 2097152 + (v19 - v19 % 128) * 2097152;
                v6 = v6 + 4;
                v1 = 11;
            else
                local v20 = UNNAMED_2819735050520[105];
                local v21 = UNNAMED_2819735050520[5](v9, v6 + v10);
                v20(v2, v10, (UNNAMED_2819735050520[11](v21, UNNAMED_2819735034392[5][UNNAMED_2819735034392[4]][UNNAMED_2819735034488], v7)));
                UNNAMED_2819735034488 = UNNAMED_2819735082776[5][UNNAMED_2819735082776[4]][UNNAMED_2819735034488];
                v1 = 3;
            end;
        elseif v1 <= 10 then
            if v1 <= 8 then
                if v1 > 7 then
                    return UNNAMED_2819735082872, UNNAMED_2819735034488;
                end;

                v3 = v3 - 128 + (v4 - 128) * 16384 + v5 * 128;
                v6 = v6 + 3;
                v1 = 11;
            elseif v1 <= 9 then
                local v22 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600);
                local _ = UNNAMED_2819735048600 + 1;
                UNNAMED_2819735050520[25](v9, v6 + v3, v22, v4);
                v1 = 8;
            else
                v4 = v4 - 128 + (v5 - 128) * 16384 + v7 * 128;
                UNNAMED_2819735048600 = UNNAMED_2819735048600 + 3;
                v1 = 9;
            end;
        elseif v1 <= 12 then
            if v1 <= 11 then
                UNNAMED_2819735034488 = (UNNAMED_2819735048600 + UNNAMED_2819735034488) % 256;
                v2 = UNNAMED_2819735050520[4](v3);
                v7 = UNNAMED_2819735048600 * 16843009;
                v11 = v3 - v3 % 4;
                v8 = {
                    v8,
                    4,
                    v11 - 1 + 0,
                    nil,
                    -4
                };
                v1 = 3;
                v4 = 41;
                v5 = 135;
            else
                v1 = v7 < 128 and 10 or 2;
            end;
        elseif v1 <= 13 then
            v8 = v8[1];
            UNNAMED_2819735082872[6] = UNNAMED_2819735050520[28](UNNAMED_2819735082872);
            UNNAMED_2819735082872, UNNAMED_2819735034488, UNNAMED_2819735048600 = UNNAMED_2819735050520:T3(UNNAMED_2819735082872, v2);
            v3 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600);
            v1 = v3 < 128 and 20 or 25;
        else
            local v23 = v8[5];
            local v24 = v8[4];
            local v25 = v8[3] + v23;
            local v26 = v23 <= 0;
            local v27 = v24 <= v25;
            v8[3] = v25;

            if v26 and v27 and v27 or not v26 and v25 <= v24 then
                v3 = v25;
                v1 = 4;
            else
                v1 = 13;
            end;
        end;
    end;

    if v1 <= 22 then
        if v1 <= 18 then
            if v1 <= 16 then
                if v1 <= 15 then
                    v4 = v4 - 128 + v5 * 128;
                    UNNAMED_2819735048600 = UNNAMED_2819735048600 + 2;
                    v1 = 9;
                else
                    v8 = v8[1];
                    v1 = 19;
                end;
            elseif v1 <= 17 then
                v9 = UNNAMED_2819735082872[4];
                v6 = UNNAMED_2819735082872[5][UNNAMED_2819735034488] + 1;
                v3 = UNNAMED_2819735050520[22](v9, v6);
                v1 = v3 < 128 and 21 or 29;
            else
                v3 = v3 - 128 + (v4 - 128) * 16384 + v5 * 128;
                UNNAMED_2819735048600 = UNNAMED_2819735048600 + 3;
                v1 = 26;
            end;
        elseif v1 <= 20 then
            if v1 <= 19 then
                v8 = {
                    v8,
                    nil,
                    v11 - 1,
                    v3 - 1 + 0,
                    1
                };
                v1 = 14;
            else
                UNNAMED_2819735048600 = UNNAMED_2819735048600 + 1;
                v1 = 26;
            end;
        elseif v1 <= 21 then
            v6 = v6 + 1;
            v1 = 11;
        else
            v3 = v3 - 128 + v4 * 128;
            UNNAMED_2819735048600 = UNNAMED_2819735048600 + 2;
            v1 = 26;
        end;
    elseif v1 <= 26 then
        if v1 <= 24 then
            if v1 <= 23 then
                v5 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600 + 2);
                v1 = v5 < 128 and 18 or 0;
            else
                v7 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600 + 2);
                v1 = 12;
            end;
        elseif v1 <= 25 then
            v4 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600 + 1);
            v1 = v4 < 128 and 22 or 23;
        else
            v4 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600);
            v1 = v4 < 128 and 30 or 28;
        end;
    elseif v1 <= 28 then
        if v1 <= 27 then
            v5 = UNNAMED_2819735050520[22](v9, v6 + 2);
            v1 = v5 < 128 and 7 or 5;
        else
            v5 = UNNAMED_2819735050520[22](v2, UNNAMED_2819735048600 + 1);
            v1 = v5 < 128 and 15 or 24;
        end;
    elseif v1 <= 29 then
        v4 = UNNAMED_2819735050520[22](v9, v6 + 1);
        v1 = v4 < 128 and 1 or 27;
    else
        UNNAMED_2819735048600 = UNNAMED_2819735048600 + 1;
        v1 = 9;
    end;
end;