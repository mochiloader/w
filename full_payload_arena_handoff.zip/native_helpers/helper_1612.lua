-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819774896360[21];
local u2 = UNNAMED_2819774896360[80];
local u3 = UNNAMED_2819774896360[113];
local u4 = UNNAMED_2819774896360[43];
local u5 = UNNAMED_2819774896360[67];
local u6 = UNNAMED_2819774896360[11];
local u7 = UNNAMED_2819774896360[92];
local u8 = UNNAMED_2819774896360[47];
local u9 = UNNAMED_2819774896360[35];
local u10 = UNNAMED_2819774896360[110];
local u11 = UNNAMED_2819774896360[84];
local u12 = UNNAMED_2819774896360[59];
local _3 = UNNAMED_2819774896360._3;
local u13 = UNNAMED_2819774896360[117];
local u14 = UNNAMED_2819774896360[64];
local P3 = UNNAMED_2819774896360.P3;
local u15 = UNNAMED_2819774896360[22];
local u16 = UNNAMED_2819774896360[105];
local u17 = UNNAMED_2819774896360[5];
local u18 = UNNAMED_2819774896360[93];
local G3 = UNNAMED_2819774896360.G3;

return function(u19, u20, u21, p22) -- Line: 3, Name: f
    -- upvalues: u1 (copy), u2 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u12 (copy), _3 (copy), u13 (copy), u14 (copy), P3 (copy), u15 (copy), u16 (copy), u17 (copy), u18 (copy), G3 (copy), UNNAMED_2819774896408 (copy), UNNAMED_2819774896456 (copy), UNNAMED_2819774896504 (copy), UNNAMED_2819774896552 (copy), UNNAMED_2819774896600 (copy), UNNAMED_2819774896648 (copy), UNNAMED_2819774896696 (copy), UNNAMED_2819774896072 (copy), UNNAMED_2819774896120 (copy), UNNAMED_2819774896168 (copy), UNNAMED_2819774896216 (copy), UNNAMED_2819774896360 (copy), UNNAMED_2819774896264 (copy), UNNAMED_2819774896312 (copy)
    local u23 = u1;
    local u24 = u2;
    local u25 = u3;
    local u26 = u4;
    local u27 = u5;
    local u28 = u6;
    local u29 = u7;
    local u30 = u8;
    local u31 = u9;
    local u32 = u10;
    local u33 = u11;
    local u34 = u12;
    local u35 = _3;
    local u36 = u13;
    local u37 = u14;
    local u38 = P3;
    local u39 = u15;
    local u40 = u16;
    local u41 = u17;
    local u42 = u18;
    local u43 = G3;

    return function(...) -- Line: 313
        -- upvalues: u21 (copy), u20 (copy), u23 (copy), UNNAMED_2819774896408 (ref), UNNAMED_2819774896456 (ref), UNNAMED_2819774896504 (ref), u27 (copy), u30 (copy), u25 (copy), u26 (copy), u28 (copy), u29 (copy), u31 (copy), u32 (copy), u33 (copy), u34 (copy), u35 (copy), u36 (copy), u37 (copy), u38 (copy), u39 (copy), u40 (copy), u41 (copy), u42 (copy), u24 (copy), UNNAMED_2819774896552 (ref), UNNAMED_2819774896600 (ref), UNNAMED_2819774896648 (ref), UNNAMED_2819774896696 (ref), UNNAMED_2819774896072 (ref), UNNAMED_2819774896120 (ref), u19 (copy), UNNAMED_2819774896168 (ref), UNNAMED_2819774896216 (ref), UNNAMED_2819774896360 (ref), UNNAMED_2819774896264 (ref), u43 (copy), UNNAMED_2819774896312 (ref)
        local u44 = u21;
        local u45 = u20;
        local u46 = u23;
        local u47 = u46(UNNAMED_2819774896408);
        local u48 = UNNAMED_2819774896456;
        local u49 = UNNAMED_2819774896504;
        local u50 = nil;
        local u51 = nil;
        local u52 = nil;
        local u53 = nil;
        local u54 = nil;
        local u55 = nil;
        local u56 = nil;
        local u57 = u27;
        local u58 = u30;
        local u59 = u25;
        local u60 = u26;
        local u61 = u28;
        local u62 = u29;
        local u63 = u31;
        local u64 = u32;
        local u65 = u33;
        local u66 = u34;
        local u67 = u35;
        local u68 = u36;
        local u69 = u37;
        local u70 = u38;
        local u71 = u39;
        local u72 = u40;
        local u73 = u41;
        local u74 = u42;
        local v1084, v1085, v1086, v1087, v1088 = u24(function(...) -- Line: 3
            -- upvalues: u49 (ref), UNNAMED_2819774896552 (ref), u48 (ref), u47 (copy), UNNAMED_2819774896600 (ref), UNNAMED_2819774896648 (ref), UNNAMED_2819774896696 (ref), u59 (copy), u60 (copy), u57 (copy), UNNAMED_2819774896072 (ref), u61 (copy), u62 (copy), UNNAMED_2819774896120 (ref), u19 (ref), u55 (ref), u56 (ref), u58 (copy), u46 (copy), u64 (copy), u44 (ref), u63 (copy), u65 (copy), UNNAMED_2819774896168 (ref), u51 (ref), u50 (ref), u52 (ref), u53 (ref), u54 (ref), UNNAMED_2819774896216 (ref), u45 (ref), u66 (copy), u67 (copy), u68 (copy), u69 (copy), u70 (copy), UNNAMED_2819774896360 (ref), u71 (copy), u72 (copy), u73 (copy), u74 (copy), UNNAMED_2819774896264 (ref)
            local v75, v76, v77, v78, v79, v80;
            local u49, v75, v76, v77, v78, v79, v80, u55, u48, u56, u44, u50, u51, u52, u53, u45, u54;
            local v81 = 0;

            while true do
                if v81 == 0 then
                    v81 = -1;
                    v75 = nil;
                    v76 = nil;
                    v77 = nil;
                    v78 = nil;
                    v79 = nil;
                    v80 = nil;

                    if u49 ~= 113 then
                        v81 = 1;
                        continue;
                    end;

                    v81 = 6;
                    continue;
                elseif v81 == 1 then
                    v81 = -1;

                    if u49 ~= 127 then
                        v81 = 2;
                        continue;
                    end;

                    v81 = 5;
                    continue;
                elseif v81 == 2 then
                    v81 = -1;

                    if u49 ~= 240 then
                        v81 = 3;
                        continue;
                    end;

                    v81 = 4;
                    continue;
                elseif v81 == 3 then
                    v81 = -1;

                    if u49 ~= 31 then
                        return;
                    end;

                    while true do
                        local v82 = UNNAMED_2819774896696[u48];

                        if v82 < 95 then
                            if v82 < 47 then
                                if v82 < 23 then
                                    if v82 < 11 then
                                        if v82 < 5 then
                                            if v82 >= 2 then
                                                if v82 < 3 then
                                                    v79 = UNNAMED_2819774896600[u48];
                                                    local v83 = UNNAMED_2819774896648[u48];
                                                    u47[v79] = UNNAMED_2819774896264[u48];
                                                    u47[v79 + 1] = v83;
                                                elseif v82 == 4 then
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] // u47[UNNAMED_2819774896552[u48]];
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]];
                                                    v79 = UNNAMED_2819774896648[u48 + 1];
                                                    v77 = UNNAMED_2819774896552[u48 + 1];
                                                    v75 = UNNAMED_2819774896600[u48 + 1];
                                                    v78 = v79 + v75 - 1;
                                                    v76 = v79 + v77;
                                                    v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                                    u59(v80, 1, v75, v79, u47);
                                                    u48 = u48 + 1;
                                                end;
                                            elseif v82 == 1 then
                                                if u47[UNNAMED_2819774896600[u48]] ~= u47[UNNAMED_2819774896552[u48]] then
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896552[u48]]] = UNNAMED_2819774896648[u48];
                                            end;
                                        elseif v82 >= 8 then
                                            if v82 >= 9 then
                                                if v82 == 10 then
                                                    u51 = u51 + u53;

                                                    if u53 <= 0 then
                                                        v79 = u52 <= u51;
                                                    else
                                                        v79 = u51 <= u52;
                                                    end;

                                                    if v79 then
                                                        u47[UNNAMED_2819774896648[u48]] = u51;
                                                        u48 = UNNAMED_2819774896552[u48];
                                                    else
                                                        u48 = UNNAMED_2819774896600[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896120[u48] * UNNAMED_2819774896264[u48];
                                                end;
                                            else
                                                v79 = UNNAMED_2819774896648[u48];
                                                v77 = UNNAMED_2819774896552[u48];
                                                v75 = UNNAMED_2819774896600[u48];
                                                v78 = v79 + v75 - 1;
                                                v76 = v79 + v77;
                                                v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                                u59(v80, 1, v75, v79, u47);
                                            end;
                                        elseif v82 >= 6 then
                                            if v82 == 7 then
                                                v79 = UNNAMED_2819774896552[u48];
                                                local v84 = u47[UNNAMED_2819774896648[u48]];
                                                u47[v79] = u47[UNNAMED_2819774896600[u48]];
                                                u47[v79 + 1] = v84;
                                            elseif UNNAMED_2819774896648[u48] > u47[UNNAMED_2819774896600[u48]] then
                                                u48 = UNNAMED_2819774896552[u48];
                                            end;
                                        else
                                            u67[UNNAMED_2819774896072[u48]][UNNAMED_2819774896264[u48]] = u47[UNNAMED_2819774896648[u48]];
                                        end;
                                    elseif v82 < 17 then
                                        if v82 >= 14 then
                                            if v82 < 15 then
                                                local v85 = u55;
                                                local v86 = u56;

                                                if v85 then
                                                    for i in u58, v85 do
                                                        local v87 = v85[i];

                                                        if v87 then
                                                            v87[5] = v87;
                                                            v87[6] = u47[i];
                                                            v87[4] = 6;
                                                            v85[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v86 then
                                                    for i, v in u58, v86 do
                                                        local v88 = v[6];

                                                        if v86 then
                                                            local v89 = v86[i];

                                                            if v89 then
                                                                local v90 = u46(v88);
                                                                u59(u47, i, i + v88 - 1, 1, v90);
                                                                v89[5] = v90;
                                                                v89[4] = 1;
                                                                v86[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(u47[UNNAMED_2819774896552[u48]], u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                                            end;

                                            if v82 ~= 16 and u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896072[u48] then
                                                u48 = UNNAMED_2819774896552[u48];
                                            end;
                                        elseif v82 >= 12 then
                                            if v82 == 13 then
                                                u47[UNNAMED_2819774896648[u48]] = #u47[UNNAMED_2819774896552[u48]];
                                            else
                                                local v91 = UNNAMED_2819774896600[u48];
                                                local v92 = UNNAMED_2819774896264[u48];
                                                local v93 = u64(UNNAMED_2819774896648[u48], 4294967295);
                                                local v94 = u64(v92, 4294967295);
                                                local v95 = u64(v93, 65535);
                                                local v96 = u63(v93, 16);
                                                local v97 = u64(v94, 65535);
                                                local v98 = u63(v94, 16);
                                                local v99 = u64(v95 * v97 + u65(u64(v95 * v98 + v96 * v97, 65535), 16), 4294967295) % 4294967296;
                                                u47[v91] = v99 ~= v99 and 0 or v99 - v99 % 1;
                                            end;
                                        else
                                            v79 = UNNAMED_2819774896552[u48];
                                            v77, v75 = u51();

                                            if v77 then
                                                u47[v79] = v75;
                                                u48 = UNNAMED_2819774896648[u48];
                                            else
                                                u48 = UNNAMED_2819774896600[u48];
                                            end;
                                        end;
                                    elseif v82 < 20 then
                                        if v82 < 18 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] - u47[UNNAMED_2819774896552[u48]];
                                        elseif v82 == 19 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] ~= u47[UNNAMED_2819774896600[u48]];
                                        else
                                            v79 = UNNAMED_2819774896552[u48];
                                            v77 = UNNAMED_2819774896648[u48];
                                            v75 = UNNAMED_2819774896600[u48];
                                            v78 = v79 + v77;
                                            u47[v79] = u60(u47[v79](u57(u47, v79 + 1, v78)));
                                        end;
                                    elseif v82 >= 21 then
                                        if v82 == 22 then
                                            u47[UNNAMED_2819774896648[u48]] = {};
                                        else
                                            local v100 = UNNAMED_2819774896600[u48];
                                            local v101 = u47[UNNAMED_2819774896648[u48]];
                                            local v102 = u64(UNNAMED_2819774896264[u48], 4294967295);
                                            local v103 = u64(v101, 4294967295);
                                            local v104 = u64(v102, 65535);
                                            local v105 = u63(v102, 16);
                                            local v106 = u64(v103, 65535);
                                            local v107 = u63(v103, 16);
                                            local v108 = u64(v104 * v106 + u65(u64(v104 * v107 + v105 * v106, 65535), 16), 4294967295) % 4294967296;
                                            u47[v100] = v108 ~= v108 and 0 or v108 - v108 % 1;
                                        end;
                                    else
                                        v79 = UNNAMED_2819774896552[u48];
                                        v77 = u61(u44, u64(u63(u44, 14), 262143), (u64(u63(u44, 28), 15)));
                                        v75 = UNNAMED_2819774896600[u48];
                                        v78 = UNNAMED_2819774896648[u48];
                                        v76 = v75 < 2097152 and 7 or 14;
                                        v80 = u64(v75, u65(1, v76) - 1);
                                        UNNAMED_2819774896696[u48] = u61(u63(v75, v76), 55, (u64(u63(v77, 21), 127)));
                                        UNNAMED_2819774896552[u48] = u61(v79, 33, (u64(v77, 127)));
                                        UNNAMED_2819774896648[u48] = u61(v78, 2, (u64(u63(v77, 7), 127)));
                                        UNNAMED_2819774896600[u48] = u61(v80, 53, (u64(u63(v77, 14), 127)));
                                        u48 = u48 - 1;
                                    end;
                                elseif v82 >= 35 then
                                    if v82 >= 41 then
                                        if v82 < 44 then
                                            if v82 < 42 then
                                                u67[UNNAMED_2819774896120[u48]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896264[u48];
                                            elseif v82 == 43 then
                                                local v109 = UNNAMED_2819774896552[u48];
                                                local v110 = u47[UNNAMED_2819774896648[u48]];
                                                local v111 = u64(u47[UNNAMED_2819774896600[u48]], 4294967295);
                                                local v112 = u64(v110, 4294967295);
                                                local v113 = u64(v111, 65535);
                                                local v114 = u63(v111, 16);
                                                local v115 = u64(v112, 65535);
                                                local v116 = u63(v112, 16);
                                                local v117 = u64(v113 * v115 + u65(u64(v113 * v116 + v114 * v115, 65535), 16), 4294967295) % 4294967296;
                                                u47[v109] = v117 ~= v117 and 0 or v117 - v117 % 1;
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = u64(u47[UNNAMED_2819774896552[u48]], u47[UNNAMED_2819774896648[u48]]);
                                            end;
                                        else
                                            if v82 < 45 then
                                                local v118 = u55;
                                                local v119 = u56;

                                                if v118 then
                                                    for i in u58, v118 do
                                                        local v120 = v118[i];

                                                        if v120 then
                                                            v120[5] = v120;
                                                            v120[6] = u47[i];
                                                            v120[4] = 6;
                                                            v118[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v119 then
                                                    for i, v in u58, v119 do
                                                        local v121 = v[6];

                                                        if v119 then
                                                            local v122 = v119[i];

                                                            if v122 then
                                                                local v123 = u46(v121);
                                                                u59(u47, i, i + v121 - 1, 1, v123);
                                                                v122[5] = v123;
                                                                v122[4] = 1;
                                                                v119[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(u47[UNNAMED_2819774896600[u48]]);
                                            end;

                                            if v82 == 46 then
                                                u47[UNNAMED_2819774896552[u48]]();
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] ~= UNNAMED_2819774896552[u48];
                                            end;
                                        end;
                                    elseif v82 < 38 then
                                        if v82 < 36 then
                                            u47[UNNAMED_2819774896648[u48]] = u64(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896600[u48]);
                                        elseif v82 == 37 then
                                            if u55 then
                                                local v124 = u55;
                                                local v125 = UNNAMED_2819774896600[u48];
                                                local v126 = v124[v125];

                                                if v126 then
                                                    v126[5] = v126;
                                                    v126[6] = u47[v125];
                                                    v126[4] = 6;
                                                    v124[v125] = nil;
                                                end;

                                                local v127 = u55;
                                                local v128 = UNNAMED_2819774896552[u48];
                                                local v129 = v127[v128];

                                                if v129 then
                                                    v129[5] = v129;
                                                    v129[6] = u47[v128];
                                                    v129[4] = 6;
                                                    v127[v128] = nil;
                                                end;

                                                local v130 = u55;
                                                local v131 = UNNAMED_2819774896648[u48];
                                                local v132 = v130[v131];

                                                if v132 then
                                                    v132[5] = v132;
                                                    v132[6] = u47[v131];
                                                    v132[4] = 6;
                                                    v130[v131] = nil;
                                                end;
                                            end;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896264[u48]];
                                        end;
                                    elseif v82 < 39 then
                                        v79 = UNNAMED_2819774896648[u48];
                                        v77 = UNNAMED_2819774896600[u48];
                                        v75 = UNNAMED_2819774896552[u48];
                                        v78 = u47[v79];
                                        u59(u47, v79 + 1, v79 + v77, v75 + 1, v78);
                                    elseif v82 == 40 then
                                        u47[UNNAMED_2819774896552[u48]] = u19[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896648[u48]]];
                                    else
                                        u47[UNNAMED_2819774896648[u48]] = u61(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896264[u48]);
                                    end;
                                elseif v82 >= 29 then
                                    if v82 >= 32 then
                                        if v82 < 33 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] // UNNAMED_2819774896600[u48];
                                        elseif v82 == 34 then
                                            v79 = UNNAMED_2819774896648[u48];
                                            v77, v75, v78 = u51();

                                            if v77 then
                                                u47[v79] = v75;
                                                u47[v79 + 1] = v78;
                                                u48 = UNNAMED_2819774896552[u48];
                                            else
                                                u48 = UNNAMED_2819774896600[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896072[u48]] = u47[UNNAMED_2819774896552[u48]];
                                        end;
                                    else
                                        if v82 >= 30 then
                                            if v82 ~= 31 then
                                                local v133 = u55;
                                                local v134 = u56;

                                                if v133 then
                                                    for i in u58, v133 do
                                                        local v135 = v133[i];

                                                        if v135 then
                                                            v135[5] = v135;
                                                            v135[6] = u47[i];
                                                            v135[4] = 6;
                                                            v133[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v134 then
                                                    for i, v in u58, v134 do
                                                        local v136 = v[6];

                                                        if v134 then
                                                            local v137 = v134[i];

                                                            if v137 then
                                                                local v138 = u46(v136);
                                                                u59(u47, i, i + v136 - 1, 1, v138);
                                                                v137[5] = v138;
                                                                v137[4] = 1;
                                                                v134[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, false;
                                            end;

                                            local v139 = UNNAMED_2819774896648[u48];
                                            local v140 = UNNAMED_2819774896600[u48];
                                            local v141 = v139 + v140;
                                            local v142 = u47[v141];
                                            local n = v142.n;
                                            local v143 = u55;
                                            local v144 = u56;

                                            if v143 then
                                                for i in u58, v143 do
                                                    local v145 = v143[i];

                                                    if v145 then
                                                        v145[5] = v145;
                                                        v145[6] = u47[i];
                                                        v145[4] = 6;
                                                        v143[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v144 then
                                                for i, v in u58, v144 do
                                                    local v146 = v[6];

                                                    if v144 then
                                                        local v147 = v144[i];

                                                        if v147 then
                                                            local v148 = u46(v146);
                                                            u59(u47, i, i + v146 - 1, 1, v148);
                                                            v147[5] = v148;
                                                            v147[4] = 1;
                                                            v144[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            v142.n = v140 + n - 1;
                                            u59(v142, 1, n, v140, v142);
                                            u59(u47, v139 + 1, v141 - 1, 1, v142);

                                            return true, true, v139, v142;
                                        end;

                                        u47[UNNAMED_2819774896552[u48]] = u61(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896648[u48]);
                                    end;
                                elseif v82 < 26 then
                                    if v82 < 24 then
                                        u45 = u47[UNNAMED_2819774896600[u48]];
                                    elseif v82 == 25 then
                                        u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896264[u48];
                                    else
                                        u67[UNNAMED_2819774896072[u48]] = UNNAMED_2819774896120[u48];
                                    end;
                                elseif v82 < 27 then
                                    local v149 = nil;
                                    local v150 = UNNAMED_2819774896648[u48];
                                    local v151 = UNNAMED_2819774896072[u48];
                                    local v152 = UNNAMED_2819774896264[u48];
                                    local v153 = u55;
                                    local v154 = u56;
                                    local v155 = v152[0];

                                    if v155 then
                                        local v156 = #v155 / 3;

                                        if v156 > 0 then
                                            v149 = {};

                                            for i = 1, v156 do
                                                local v157 = (i - 1) * 3;
                                                local v158 = v155[v157 + 2];
                                                local v159 = v155[v157 + 1];
                                                local v160;

                                                if v158 == 2 then
                                                    v153 = v153 or {};
                                                    local v161 = v153[v159];

                                                    if not v161 then
                                                        v161 = {
                                                            [5] = u47,
                                                            [4] = v159
                                                        };
                                                        v153[v159] = v161;
                                                    end;

                                                    v149[i] = v161;
                                                    v160 = i;
                                                elseif v158 == 0 then
                                                    v149[i] = u47[v159];
                                                    v160 = i;
                                                elseif v158 == 3 then
                                                    v149[i] = u19[v159];
                                                    v160 = i;
                                                elseif v158 == 1 then
                                                    v154 = v154 or {};
                                                    local v162 = v154[v159];

                                                    if not v162 then
                                                        v162 = {
                                                            [5] = u47,
                                                            [4] = v159,
                                                            [6] = v155[v157 + 3]
                                                        };
                                                        v154[v159] = v162;
                                                    end;

                                                    v149[i] = v162;
                                                    v160 = i;
                                                else
                                                    v160 = i;
                                                end;
                                            end;
                                        end;
                                    end;

                                    local v163 = v152[-2];
                                    v152[v163] = v149;
                                    local v164 = v151(u57(v152, 1, v152[-1]));
                                    v152[v163] = nil;
                                    u47[v150] = v164;
                                    u55 = v153;
                                    u56 = v154;
                                elseif v82 == 28 then
                                    v79 = UNNAMED_2819774896648[u48];
                                    v77 = UNNAMED_2819774896552[u48];
                                    v75 = UNNAMED_2819774896600[u48];
                                    v78 = u47[v79];
                                    v76 = v79 + v77;
                                    v80 = u47[v76];
                                    u59(u47, v79 + 1, v76 - 1, v75 + 1, v78);
                                    u59(v80, 1, v80.n, v75 + v77, v78);
                                else
                                    u47[UNNAMED_2819774896552[u48]] = u62(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896072[u48]);
                                end;
                            elseif v82 < 71 then
                                if v82 < 59 then
                                    if v82 >= 53 then
                                        if v82 < 56 then
                                            if v82 < 54 then
                                                u47[UNNAMED_2819774896600[u48]](UNNAMED_2819774896264[u48]);
                                            elseif v82 == 55 then
                                                if u47[UNNAMED_2819774896600[u48]] >= UNNAMED_2819774896648[u48] then
                                                    u48 = UNNAMED_2819774896552[u48];
                                                end;
                                            else
                                                v79 = UNNAMED_2819774896600[u48] + 1;
                                                v77 = UNNAMED_2819774896648[u48];

                                                for i = 1, UNNAMED_2819774896552[u48] do
                                                    local v165 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                    local v166 = u61(v165, (u63(v165, 13)));
                                                    v77 = u64(u61(v166, (u65(v166, 14))), 536870911);
                                                    UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                    UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                    UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 14), 127)));
                                                    UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 21), 127)));
                                                    v79 = v79 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896696[u48] = 16;
                                            end;
                                        elseif v82 < 57 then
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] - UNNAMED_2819774896120[u48];
                                        elseif v82 == 58 then
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] / UNNAMED_2819774896600[u48];
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u45;
                                        end;
                                    elseif v82 >= 50 then
                                        if v82 < 51 then
                                            local v167 = u55;
                                            local v168 = u56;

                                            if v167 then
                                                for i in u58, v167 do
                                                    local v169 = v167[i];

                                                    if v169 then
                                                        v169[5] = v169;
                                                        v169[6] = u47[i];
                                                        v169[4] = 6;
                                                        v167[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v168 then
                                                for i, v in u58, v168 do
                                                    local v170 = v[6];

                                                    if v168 then
                                                        local v171 = v168[i];

                                                        if v171 then
                                                            local v172 = u46(v170);
                                                            u59(u47, i, i + v170 - 1, 1, v172);
                                                            v171[5] = v172;
                                                            v171[4] = 1;
                                                            v168[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u60(UNNAMED_2819774896072[u48], u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n));
                                        end;

                                        if v82 == 52 then
                                            if u47[UNNAMED_2819774896552[u48]] > u47[UNNAMED_2819774896600[u48]] then
                                                u48 = UNNAMED_2819774896648[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896600[u48]]);
                                        end;
                                    elseif v82 >= 48 then
                                        if v82 == 49 then
                                            u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48] + u47[UNNAMED_2819774896600[u48]];
                                        else
                                            u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896600[u48]]);
                                        end;
                                    else
                                        v79 = UNNAMED_2819774896552[u48];
                                        v77 = UNNAMED_2819774896648[u48];
                                        v75 = UNNAMED_2819774896600[u48];
                                        v78 = v79 + v77;
                                        v76 = u47[v78];
                                        v80 = v76.n;
                                        v76.n = v77 + v80 - 1;
                                        u59(v76, 1, v80, v77, v76);
                                        u59(u47, v79 + 1, v78 - 1, 1, v76);
                                        u47[v79] = u60(u47[v79](u57(v76, 1, v76.n)));
                                    end;
                                elseif v82 < 65 then
                                    if v82 < 62 then
                                        if v82 >= 60 then
                                            if v82 == 61 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]][u47[UNNAMED_2819774896600[u48]]];
                                            else
                                                u48 = u47[UNNAMED_2819774896600[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48] .. u47[UNNAMED_2819774896600[u48]];
                                        end;
                                    else
                                        if v82 < 63 then
                                            local v173 = u55;
                                            local v174 = u56;

                                            if v173 then
                                                for i in u58, v173 do
                                                    local v175 = v173[i];

                                                    if v175 then
                                                        v175[5] = v175;
                                                        v175[6] = u47[i];
                                                        v175[4] = 6;
                                                        v173[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v174 then
                                                for i, v in u58, v174 do
                                                    local v176 = v[6];

                                                    if v174 then
                                                        local v177 = v174[i];

                                                        if v177 then
                                                            local v178 = u46(v176);
                                                            u59(u47, i, i + v176 - 1, 1, v178);
                                                            v177[5] = v178;
                                                            v177[4] = 1;
                                                            v174[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u47[UNNAMED_2819774896600[u48]];
                                        end;

                                        if v82 == 64 then
                                            v79 = u47[UNNAMED_2819774896600[u48]];
                                            u47[UNNAMED_2819774896552[u48]] = u60(u57(v79, UNNAMED_2819774896648[u48], v79.n));
                                        else
                                            u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896600[u48] - u47[UNNAMED_2819774896648[u48]];
                                        end;
                                    end;
                                elseif v82 >= 68 then
                                    if v82 < 69 then
                                        local v179 = u55;
                                        local v180 = u56;

                                        if v179 then
                                            for i in u58, v179 do
                                                local v181 = v179[i];

                                                if v181 then
                                                    v181[5] = v181;
                                                    v181[6] = u47[i];
                                                    v181[4] = 6;
                                                    v179[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v180 then
                                            for i, v in u58, v180 do
                                                local v182 = v[6];

                                                if v180 then
                                                    local v183 = v180[i];

                                                    if v183 then
                                                        local v184 = u46(v182);
                                                        u59(u47, i, i + v182 - 1, 1, v184);
                                                        v183[5] = v184;
                                                        v183[4] = 1;
                                                        v180[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819774896648[u48], u60(u47[UNNAMED_2819774896552[u48]]);
                                    end;

                                    if v82 ~= 70 then
                                        local v185 = u55;
                                        local v186 = u56;

                                        if v185 then
                                            for i in u58, v185 do
                                                local v187 = v185[i];

                                                if v187 then
                                                    v187[5] = v187;
                                                    v187[6] = u47[i];
                                                    v187[4] = 6;
                                                    v185[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v186 then
                                            for i, v in u58, v186 do
                                                local v188 = v[6];

                                                if v186 then
                                                    local v189 = v186[i];

                                                    if v189 then
                                                        local v190 = u46(v188);
                                                        u59(u47, i, i + v188 - 1, 1, v190);
                                                        v189[5] = v190;
                                                        v189[4] = 1;
                                                        v186[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819774896600[u48], u60(u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896552[u48]]);
                                    end;

                                    u19[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896600[u48]]] = UNNAMED_2819774896264[u48];
                                elseif v82 >= 66 then
                                    if v82 == 67 then
                                        u47[UNNAMED_2819774896552[u48]](UNNAMED_2819774896072[u48], UNNAMED_2819774896120[u48]);
                                    else
                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] == u47[UNNAMED_2819774896552[u48]];
                                    end;
                                else
                                    v79 = UNNAMED_2819774896648[u48];
                                    v77 = u61(u44, u64(u63(u44, 14), 262143), (u64(u63(u44, 28), 15)));
                                    v75 = UNNAMED_2819774896552[u48];
                                    v78 = UNNAMED_2819774896600[u48];
                                    v76 = v79 < 16384 and 7 or (v79 < 2097152 and 14 or 21);
                                    v80 = u64(v79, u65(1, v76) - 1);
                                    local v191 = u63(v79, v76);
                                    UNNAMED_2819774896600[u48] = u61(v78, 116, (u64(u63(v77, 14), 127)));
                                    UNNAMED_2819774896552[u48] = u61(v75, 74, (u64(v77, 127)));
                                    UNNAMED_2819774896648[u48] = u61(v80, 92, (u64(u63(v77, 7), 127)));
                                    UNNAMED_2819774896696[u48] = u61(v191, 66, (u64(u63(v77, 21), 127)));
                                    u48 = u48 - 1;
                                end;
                            elseif v82 < 83 then
                                if v82 >= 77 then
                                    if v82 < 80 then
                                        if v82 < 78 then
                                            u47[UNNAMED_2819774896600[u48]] = u67[UNNAMED_2819774896264[u48]];
                                        elseif v82 == 79 then
                                            v79 = UNNAMED_2819774896648[u48];
                                            local v192 = u47[UNNAMED_2819774896552[u48]];
                                            u47[v79] = UNNAMED_2819774896072[u48];
                                            u47[v79 + 1] = v192;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] % u47[UNNAMED_2819774896552[u48]];
                                        end;
                                    elseif v82 < 81 then
                                        u47[UNNAMED_2819774896552[u48]] = -u47[UNNAMED_2819774896648[u48]];
                                    elseif v82 == 82 then
                                        u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] > UNNAMED_2819774896600[u48];
                                    else
                                        u47[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896552[u48]]] = u47[UNNAMED_2819774896600[u48]];
                                    end;
                                elseif v82 < 74 then
                                    if v82 < 72 then
                                        u47[UNNAMED_2819774896600[u48]] = u63(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896552[u48]);
                                    elseif v82 == 73 then
                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] > UNNAMED_2819774896264[u48];
                                    else
                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]] * UNNAMED_2819774896120[u48];
                                    end;
                                elseif v82 < 75 then
                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]] .. UNNAMED_2819774896120[u48];
                                else
                                    if v82 ~= 76 then
                                        local v193 = u55;
                                        local v194 = u56;

                                        if v193 then
                                            for i in u58, v193 do
                                                local v195 = v193[i];

                                                if v195 then
                                                    v195[5] = v195;
                                                    v195[6] = u47[i];
                                                    v195[4] = 6;
                                                    v193[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v194 then
                                            for i, v in u58, v194 do
                                                local v196 = v[6];

                                                if v194 then
                                                    local v197 = v194[i];

                                                    if v197 then
                                                        local v198 = u46(v196);
                                                        u59(u47, i, i + v196 - 1, 1, v198);
                                                        v197[5] = v198;
                                                        v197[4] = 1;
                                                        v194[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u60(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896120[u48]);
                                    end;

                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] + u47[UNNAMED_2819774896648[u48]];
                                end;
                            elseif v82 >= 89 then
                                if v82 >= 92 then
                                    if v82 < 93 then
                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] + UNNAMED_2819774896072[u48];
                                    elseif v82 == 94 then
                                        v79 = UNNAMED_2819774896552[u48];
                                        local v199 = u47[UNNAMED_2819774896600[u48]];
                                        u47[v79] = UNNAMED_2819774896648[u48];
                                        u47[v79 + 1] = v199;
                                    else
                                        local v200;

                                        if u47[UNNAMED_2819774896552[u48]] then
                                            v200 = UNNAMED_2819774896600[u48];
                                        else
                                            v200 = UNNAMED_2819774896648[u48];
                                        end;

                                        u48 = v200;
                                    end;
                                elseif v82 >= 90 then
                                    if v82 == 91 then
                                        local v201 = u55;
                                        local v202 = u56;

                                        if v201 then
                                            for i in u58, v201 do
                                                local v203 = v201[i];

                                                if v203 then
                                                    v203[5] = v203;
                                                    v203[6] = u47[i];
                                                    v203[4] = 6;
                                                    v201[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v202 then
                                            for i, v in u58, v202 do
                                                local v204 = v[6];

                                                if v202 then
                                                    local v205 = v202[i];

                                                    if v205 then
                                                        local v206 = u46(v204);
                                                        u59(u47, i, i + v204 - 1, 1, v206);
                                                        v205[5] = v206;
                                                        v205[4] = 1;
                                                        v202[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, true, UNNAMED_2819774896552[u48], u47[UNNAMED_2819774896648[u48]];
                                    end;

                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] % UNNAMED_2819774896120[u48];
                                else
                                    v79 = UNNAMED_2819774896552[u48];
                                    local v207 = UNNAMED_2819774896600[u48];
                                    u47[v79] = UNNAMED_2819774896648[u48];
                                    u47[v79 + 1] = v207;
                                end;
                            elseif v82 < 86 then
                                if v82 < 84 then
                                    local v208 = u55;
                                    local v209 = u56;

                                    if v208 then
                                        for i in u58, v208 do
                                            local v210 = v208[i];

                                            if v210 then
                                                v210[5] = v210;
                                                v210[6] = u47[i];
                                                v210[4] = 6;
                                                v208[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v209 then
                                        for i, v in u58, v209 do
                                            local v211 = v[6];

                                            if v209 then
                                                local v212 = v209[i];

                                                if v212 then
                                                    local v213 = u46(v211);
                                                    u59(u47, i, i + v211 - 1, 1, v213);
                                                    v212[5] = v213;
                                                    v212[4] = 1;
                                                    v209[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u60(UNNAMED_2819774896264[u48]);
                                end;

                                if v82 == 85 then
                                    v79 = UNNAMED_2819774896648[u48];
                                    local v214 = UNNAMED_2819774896552[u48];
                                    u47[v79] = u47[UNNAMED_2819774896600[u48]];
                                    u47[v79 + 1] = v214;
                                else
                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] * UNNAMED_2819774896600[u48];
                                end;
                            elseif v82 >= 87 then
                                if v82 == 88 then
                                    v79 = u19[UNNAMED_2819774896552[u48]];
                                    v79[5][v79[4]] = u47[UNNAMED_2819774896600[u48]];
                                else
                                    u51 = u50[8];
                                    u52 = u50[5];
                                    u53 = u50[7];
                                    u54 = u50[6];
                                    u50 = u50[9];
                                end;
                            else
                                u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896600[u48] + u47[UNNAMED_2819774896648[u48]];
                            end;
                        elseif v82 < 142 then
                            if v82 < 118 then
                                if v82 < 106 then
                                    if v82 < 100 then
                                        if v82 >= 97 then
                                            if v82 >= 98 then
                                                if v82 == 99 then
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] % UNNAMED_2819774896600[u48];
                                                else
                                                    u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896264[u48]] = u47[UNNAMED_2819774896600[u48]];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] < u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        elseif v82 == 96 then
                                            local v215 = u47[UNNAMED_2819774896648[u48]] % 4294967296;
                                            u47[UNNAMED_2819774896600[u48]] = v215 ~= v215 and 0 or v215 - v215 % 1;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u65(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896552[u48]);
                                        end;
                                    elseif v82 < 103 then
                                        if v82 >= 101 then
                                            if v82 == 102 then
                                                u48 = u47[UNNAMED_2819774896552[u48]];
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = u60(u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896264[u48]));
                                            end;
                                        else
                                            local v216 = UNNAMED_2819774896552[u48];
                                            local v217 = UNNAMED_2819774896648[u48];
                                            local v218, v219 = u47[UNNAMED_2819774896600[u48]]();
                                            u47[v216] = v218;
                                            u47[v217] = v219;
                                        end;
                                    elseif v82 < 104 then
                                        u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896648[u48]], u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                                    elseif v82 == 105 then
                                        u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896264[u48]] = UNNAMED_2819774896600[u48];
                                    else
                                        v79 = u19[UNNAMED_2819774896648[u48]];
                                        v79[5][v79[4]][UNNAMED_2819774896264[u48]] = UNNAMED_2819774896072[u48];
                                    end;
                                elseif v82 >= 112 then
                                    if v82 < 115 then
                                        if v82 < 113 then
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896072[u48]);
                                        else
                                            if v82 == 114 then
                                                local v220 = u55;
                                                local v221 = u56;

                                                if v220 then
                                                    for i in u58, v220 do
                                                        local v222 = v220[i];

                                                        if v222 then
                                                            v222[5] = v222;
                                                            v222[6] = u47[i];
                                                            v222[4] = 6;
                                                            v220[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v221 then
                                                    for i, v in u58, v221 do
                                                        local v223 = v[6];

                                                        if v221 then
                                                            local v224 = v221[i];

                                                            if v224 then
                                                                local v225 = u46(v223);
                                                                u59(u47, i, i + v223 - 1, 1, v225);
                                                                v224[5] = v225;
                                                                v224[4] = 1;
                                                                v221[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819774896600[u48], u60();
                                            end;

                                            v79 = UNNAMED_2819774896552[u48];
                                            local v226 = UNNAMED_2819774896072[u48];
                                            u47[v79] = UNNAMED_2819774896648[u48];
                                            u47[v79 + 1] = v226;
                                        end;
                                    elseif v82 >= 116 then
                                        if v82 == 117 then
                                            u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]];
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u68(u47[UNNAMED_2819774896552[u48]]);
                                        end;
                                    else
                                        u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]];
                                    end;
                                elseif v82 < 109 then
                                    if v82 >= 107 then
                                        if v82 ~= 108 then
                                            local v227 = u55;
                                            local v228 = u56;

                                            if v227 then
                                                for i in u58, v227 do
                                                    local v229 = v227[i];

                                                    if v229 then
                                                        v229[5] = v229;
                                                        v229[6] = u47[i];
                                                        v229[4] = 6;
                                                        v227[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v228 then
                                                for i, v in u58, v228 do
                                                    local v230 = v[6];

                                                    if v228 then
                                                        local v231 = v228[i];

                                                        if v231 then
                                                            local v232 = u46(v230);
                                                            u59(u47, i, i + v230 - 1, 1, v232);
                                                            v231[5] = v232;
                                                            v231[4] = 1;
                                                            v228[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819774896600[u48], u60(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896264[u48]);
                                        end;

                                        u50 = {
                                            [6] = u54,
                                            [5] = u52,
                                            [9] = u50,
                                            [8] = u51,
                                            [7] = u53
                                        };
                                        v79 = UNNAMED_2819774896648[u48];
                                        u53 = u47[v79 + 2] + 0;
                                        u52 = u47[v79 + 1] + 0;
                                        u51 = u47[v79] - u53;
                                        u48 = UNNAMED_2819774896552[u48];
                                    elseif UNNAMED_2819774896264[u48] >= u47[UNNAMED_2819774896600[u48]] then
                                        u48 = UNNAMED_2819774896648[u48];
                                    end;
                                elseif v82 >= 110 then
                                    if v82 == 111 then
                                        if u47[UNNAMED_2819774896600[u48]] >= u47[UNNAMED_2819774896648[u48]] then
                                            u48 = UNNAMED_2819774896552[u48];
                                        end;
                                    else
                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896552[u48]]);
                                    end;
                                else
                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896072[u48] * u47[UNNAMED_2819774896552[u48]];
                                end;
                            elseif v82 >= 130 then
                                if v82 >= 136 then
                                    if v82 >= 139 then
                                        if v82 < 140 then
                                            local v233 = u55;
                                            local v234 = u56;

                                            if v233 then
                                                for i in u58, v233 do
                                                    local v235 = v233[i];

                                                    if v235 then
                                                        v235[5] = v235;
                                                        v235[6] = u47[i];
                                                        v235[4] = 6;
                                                        v233[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v234 then
                                                for i, v in u58, v234 do
                                                    local v236 = v[6];

                                                    if v234 then
                                                        local v237 = v234[i];

                                                        if v237 then
                                                            local v238 = u46(v236);
                                                            u59(u47, i, i + v236 - 1, 1, v238);
                                                            v237[5] = v238;
                                                            v237[4] = 1;
                                                            v234[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u60(UNNAMED_2819774896120[u48], UNNAMED_2819774896264[u48]);
                                        end;

                                        if v82 == 141 then
                                            u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48];
                                        else
                                            v79 = UNNAMED_2819774896552[u48] + 1;
                                            v77 = u61(UNNAMED_2819774896648[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));

                                            for i = 1, UNNAMED_2819774896600[u48] do
                                                local v239 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                local v240 = u61(v239, (u63(v239, 13)));
                                                v77 = u64(u61(v240, (u65(v240, 14))), 536870911);
                                                UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 14), 127)));
                                                UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 21), 127)));
                                                v79 = v79 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819774896696[u48] = 16;
                                        end;
                                    elseif v82 < 137 then
                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]][UNNAMED_2819774896600[u48]];
                                    elseif v82 == 138 then
                                        v79 = u19[UNNAMED_2819774896600[u48]];
                                        v79[5][v79[4]] = UNNAMED_2819774896264[u48];
                                    else
                                        u19[UNNAMED_2819774896552[u48]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896648[u48];
                                    end;
                                elseif v82 < 133 then
                                    if v82 < 131 then
                                        u47[UNNAMED_2819774896552[u48]](u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                                    else
                                        if v82 == 132 then
                                            local v241 = u55;
                                            local v242 = u56;

                                            if v241 then
                                                for i in u58, v241 do
                                                    local v243 = v241[i];

                                                    if v243 then
                                                        v243[5] = v243;
                                                        v243[6] = u47[i];
                                                        v243[4] = 6;
                                                        v241[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v242 then
                                                for i, v in u58, v242 do
                                                    local v244 = v[6];

                                                    if v242 then
                                                        local v245 = v242[i];

                                                        if v245 then
                                                            local v246 = u46(v244);
                                                            u59(u47, i, i + v244 - 1, 1, v246);
                                                            v245[5] = v246;
                                                            v245[4] = 1;
                                                            v242[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819774896552[u48], u60(UNNAMED_2819774896072[u48], u47[UNNAMED_2819774896648[u48]]);
                                        end;

                                        u47[UNNAMED_2819774896600[u48]] = u67[UNNAMED_2819774896264[u48]][u47[UNNAMED_2819774896648[u48]]];
                                    end;
                                elseif v82 >= 134 then
                                    if v82 == 135 then
                                        u47[UNNAMED_2819774896600[u48]] = u60(u47[UNNAMED_2819774896552[u48]]());
                                    else
                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]]();
                                    end;
                                else
                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] * u47[UNNAMED_2819774896600[u48]];
                                end;
                            elseif v82 < 124 then
                                if v82 >= 121 then
                                    if v82 < 122 then
                                        u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896600[u48] ^ u47[UNNAMED_2819774896648[u48]];
                                    elseif v82 == 123 then
                                        u47[UNNAMED_2819774896552[u48]] = u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896072[u48]];
                                    else
                                        local v247 = UNNAMED_2819774896648[u48];
                                        local v248 = UNNAMED_2819774896600[u48];
                                        local v249 = UNNAMED_2819774896216[5];
                                        local v250 = u61(v249[v247], 109162203);
                                        v249[v247] = v250;
                                        local v251 = UNNAMED_2819774896216[4];
                                        local v252 = v250 + 1;
                                        local v253 = u71(v251, v252);
                                        local v254;

                                        if v253 < 128 then
                                            v254 = v252 + 1;
                                        else
                                            local v255 = u71(v251, v252 + 1);

                                            if v255 < 128 then
                                                v253 = v253 - 128 + v255 * 128;
                                                v254 = v252 + 2;
                                            else
                                                local v256 = u71(v251, v252 + 2);

                                                if v256 < 128 then
                                                    v253 = v253 - 128 + (v255 - 128) * 16384 + v256 * 128;
                                                    v254 = v252 + 3;
                                                else
                                                    local v257 = u71(v251, v252 + 3);
                                                    v253 = (v253 - 128) * 16384 + (v255 - 128) * 128 + (v256 - 128) + v257 % 128 * 2097152 + (v257 - v257 % 128) * 2097152;
                                                    v254 = v252 + 4;
                                                end;
                                            end;
                                        end;

                                        local v258 = v248 * 16843009;
                                        local v259 = v254 + v253;
                                        local v260 = v259 - v253 % 4;

                                        for i = v254, v260 - 1, 4 do
                                            u72(v251, i, (u61(u73(v251, i), v258)));
                                            local _ = i;
                                        end;

                                        for i = v260, v259 - 1 do
                                            u74(v251, i, (u61(u71(v251, i), v248)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819774896648[u48] = 229;
                                        UNNAMED_2819774896600[u48] = 199;
                                        UNNAMED_2819774896552[u48] = 60;
                                        UNNAMED_2819774896696[u48] = 16;
                                    end;
                                elseif v82 >= 119 then
                                    if v82 == 120 then
                                        u19[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896600[u48]]] = u47[UNNAMED_2819774896552[u48]];
                                    else
                                        u47[UNNAMED_2819774896648[u48]] = u62(u47[UNNAMED_2819774896552[u48]], u47[UNNAMED_2819774896600[u48]]);
                                    end;
                                else
                                    u48 = UNNAMED_2819774896552[u48];
                                end;
                            elseif v82 >= 127 then
                                if v82 < 128 then
                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] .. u47[UNNAMED_2819774896552[u48]];
                                elseif v82 == 129 then
                                    u47[UNNAMED_2819774896600[u48]] = u19[UNNAMED_2819774896648[u48]];
                                else
                                    local v261;

                                    if u47[UNNAMED_2819774896648[u48]] then
                                        v261 = UNNAMED_2819774896600[u48];
                                    else
                                        v261 = UNNAMED_2819774896552[u48];
                                    end;

                                    u48 = v261;
                                end;
                            elseif v82 < 125 then
                                u47[UNNAMED_2819774896600[u48]] = u44;
                            elseif v82 == 126 then
                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]](u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                            else
                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] / UNNAMED_2819774896264[u48];
                            end;
                        elseif v82 < 166 then
                            if v82 < 154 then
                                if v82 < 148 then
                                    if v82 >= 145 then
                                        if v82 < 146 then
                                            u47[UNNAMED_2819774896600[u48]] = u61(u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896552[u48]]);
                                        elseif v82 == 147 then
                                            u47[UNNAMED_2819774896600[u48]](UNNAMED_2819774896264[u48], u47[UNNAMED_2819774896648[u48]]);
                                        else
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] >= UNNAMED_2819774896648[u48];
                                        end;
                                    elseif v82 >= 143 then
                                        if v82 == 144 then
                                            v79 = UNNAMED_2819774896552[u48];
                                            v77 = u47[UNNAMED_2819774896600[u48]];
                                            u47[v79 + 1] = v77;
                                            u47[v79] = v77[UNNAMED_2819774896120[u48]];
                                        else
                                            v79 = u19[UNNAMED_2819774896648[u48]];
                                            u47[UNNAMED_2819774896552[u48]] = v79[5][v79[4]][UNNAMED_2819774896072[u48]];
                                        end;
                                    else
                                        u47[UNNAMED_2819774896552[u48]] = u47;
                                    end;
                                elseif v82 >= 151 then
                                    if v82 >= 152 then
                                        if v82 == 153 then
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] == UNNAMED_2819774896648[u48];
                                        else
                                            v79 = u19[UNNAMED_2819774896600[u48]];
                                            u47[UNNAMED_2819774896648[u48]] = v79[5][v79[4]];
                                        end;
                                    else
                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] / u47[UNNAMED_2819774896552[u48]];
                                    end;
                                elseif v82 >= 149 then
                                    if v82 ~= 150 then
                                        local v262 = UNNAMED_2819774896600[u48];
                                        local v263 = v262 + UNNAMED_2819774896552[u48];
                                        local v264 = u55;
                                        local v265 = u56;

                                        if v264 then
                                            for i in u58, v264 do
                                                local v266 = v264[i];

                                                if v266 then
                                                    v266[5] = v266;
                                                    v266[6] = u47[i];
                                                    v266[4] = 6;
                                                    v264[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v265 then
                                            for i, v in u58, v265 do
                                                local v267 = v[6];

                                                if v265 then
                                                    local v268 = v265[i];

                                                    if v268 then
                                                        local v269 = u46(v267);
                                                        u59(u47, i, i + v267 - 1, 1, v269);
                                                        v268[5] = v269;
                                                        v268[4] = 1;
                                                        v265[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return true, false, v262, v263;
                                    end;

                                    u50 = {
                                        [6] = u54,
                                        [5] = u52,
                                        [9] = u50,
                                        [8] = u51,
                                        [7] = u53
                                    };
                                    v79 = UNNAMED_2819774896648[u48];
                                    v77 = u69(u70);
                                    v77(UNNAMED_2819774896360, u47[v79], u47[v79 + 1], u47[v79 + 2]);
                                    u51 = v77;
                                    u54 = UNNAMED_2819774896600[u48];
                                    u48 = UNNAMED_2819774896552[u48];
                                else
                                    local v270 = UNNAMED_2819774896552[u48];
                                    local v271 = u61(UNNAMED_2819774896648[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));
                                    local v272 = UNNAMED_2819774896216[5];
                                    local v273 = u61(v272[v270], 109162203);
                                    v272[v270] = v273;
                                    local v274 = UNNAMED_2819774896216[4];
                                    local v275 = v273 + 1;
                                    local v276 = u71(v274, v275);
                                    local v277;

                                    if v276 < 128 then
                                        v277 = v275 + 1;
                                    else
                                        local v278 = u71(v274, v275 + 1);

                                        if v278 < 128 then
                                            v276 = v276 - 128 + v278 * 128;
                                            v277 = v275 + 2;
                                        else
                                            local v279 = u71(v274, v275 + 2);

                                            if v279 < 128 then
                                                v276 = v276 - 128 + (v278 - 128) * 16384 + v279 * 128;
                                                v277 = v275 + 3;
                                            else
                                                local v280 = u71(v274, v275 + 3);
                                                v276 = (v276 - 128) * 16384 + (v278 - 128) * 128 + (v279 - 128) + v280 % 128 * 2097152 + (v280 - v280 % 128) * 2097152;
                                                v277 = v275 + 4;
                                            end;
                                        end;
                                    end;

                                    local v281 = v271 * 16843009;
                                    local v282 = v277 + v276;
                                    local v283 = v282 - v276 % 4;

                                    for i = v277, v283 - 1, 4 do
                                        u72(v274, i, (u61(u73(v274, i), v281)));
                                        local _ = i;
                                    end;

                                    for i = v283, v282 - 1 do
                                        u74(v274, i, (u61(u71(v274, i), v271)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819774896552[u48] = 113;
                                    UNNAMED_2819774896648[u48] = 125;
                                    UNNAMED_2819774896600[u48] = 38;
                                    UNNAMED_2819774896696[u48] = 16;
                                end;
                            elseif v82 < 160 then
                                if v82 < 157 then
                                    if v82 >= 155 then
                                        if v82 == 156 then
                                            local v284 = UNNAMED_2819774896648[u48];
                                            local v285 = UNNAMED_2819774896264[u48];
                                            local v286 = u64(UNNAMED_2819774896072[u48], 4294967295);
                                            local v287 = u64(v285, 4294967295);
                                            local v288 = u64(v286, 65535);
                                            local v289 = u63(v286, 16);
                                            local v290 = u64(v287, 65535);
                                            local v291 = u63(v287, 16);
                                            local v292 = u64(v288 * v290 + u65(u64(v288 * v291 + v289 * v290, 65535), 16), 4294967295) % 4294967296;
                                            u47[v284] = v292 ~= v292 and 0 or v292 - v292 % 1;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] - UNNAMED_2819774896552[u48];
                                        end;
                                    else
                                        u47[UNNAMED_2819774896648[u48]] = u64(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896264[u48]);
                                    end;
                                elseif v82 >= 158 then
                                    if v82 == 159 then
                                        local v293 = u55;
                                        local v294 = u56;

                                        if v293 then
                                            for i in u58, v293 do
                                                local v295 = v293[i];

                                                if v295 then
                                                    v295[5] = v295;
                                                    v295[6] = u47[i];
                                                    v295[4] = 6;
                                                    v293[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v294 then
                                            for i, v in u58, v294 do
                                                local v296 = v[6];

                                                if v294 then
                                                    local v297 = v294[i];

                                                    if v297 then
                                                        local v298 = u46(v296);
                                                        u59(u47, i, i + v296 - 1, 1, v298);
                                                        v297[5] = v298;
                                                        v297[4] = 1;
                                                        v294[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        local v299 = UNNAMED_2819774896600[u48];
                                        local v300 = UNNAMED_2819774896552[u48];
                                        local v301 = v299 + v300 - 1;
                                        local v302 = u47[v301];
                                        local n = v302.n;
                                        v302.n = v300 + n - 1;
                                        u59(v302, 1, n, v300, v302);
                                        u59(u47, v299, v301 - 1, 1, v302);

                                        return false, true, v302;
                                    end;

                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896072[u48] - u47[UNNAMED_2819774896552[u48]];
                                elseif UNNAMED_2819774896600[u48] >= u47[UNNAMED_2819774896648[u48]] then
                                    u48 = UNNAMED_2819774896552[u48];
                                end;
                            elseif v82 < 163 then
                                if v82 >= 161 then
                                    if v82 ~= 162 then
                                        local v303 = u55;
                                        local v304 = u56;

                                        if v303 then
                                            for i in u58, v303 do
                                                local v305 = v303[i];

                                                if v305 then
                                                    v305[5] = v305;
                                                    v305[6] = u47[i];
                                                    v305[4] = 6;
                                                    v303[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v304 then
                                            for i, v in u58, v304 do
                                                local v306 = v[6];

                                                if v304 then
                                                    local v307 = v304[i];

                                                    if v307 then
                                                        local v308 = u46(v306);
                                                        u59(u47, i, i + v306 - 1, 1, v308);
                                                        v307[5] = v308;
                                                        v307[4] = 1;
                                                        v304[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return false, true, u60(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896072[u48], UNNAMED_2819774896120[u48]);
                                    end;

                                    if u55 then
                                        local v309 = u55;
                                        local v310 = UNNAMED_2819774896600[u48];
                                        local v311 = v309[v310];

                                        if v311 then
                                            v311[5] = v311;
                                            v311[6] = u47[v310];
                                            v311[4] = 6;
                                            v309[v310] = nil;
                                        end;

                                        local v312 = u55;
                                        local v313 = UNNAMED_2819774896648[u48];
                                        local v314 = v312[v313];

                                        if v314 then
                                            v314[5] = v314;
                                            v314[6] = u47[v313];
                                            v314[4] = 6;
                                            v312[v313] = nil;
                                        end;
                                    end;
                                else
                                    u47[UNNAMED_2819774896552[u48]] = not u47[UNNAMED_2819774896648[u48]];
                                end;
                            elseif v82 >= 164 then
                                if v82 == 165 then
                                    v79 = UNNAMED_2819774896552[u48];
                                    v77 = UNNAMED_2819774896600[u48];
                                    v75 = UNNAMED_2819774896648[u48];
                                    v78 = v79 + v75 - 1;
                                    v76 = v79 + v77;
                                    v80 = u47[v76];
                                    local n = v80.n;
                                    v80.n = v77 + n - 1;
                                    u59(v80, 1, n, v77, v80);
                                    u59(u47, v79 + 1, v76 - 1, 1, v80);
                                    u59(u60(u47[v79](u57(v80, 1, v80.n))), 1, v75, v79, u47);
                                else
                                    u47[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896648[u48]]] = UNNAMED_2819774896264[u48];
                                end;
                            else
                                u47[UNNAMED_2819774896648[u48]] = u67[UNNAMED_2819774896072[u48]][UNNAMED_2819774896264[u48]];
                            end;
                        elseif v82 >= 178 then
                            if v82 >= 184 then
                                if v82 >= 187 then
                                    if v82 < 188 then
                                        if u55 then
                                            local v315 = u55;
                                            local v316 = UNNAMED_2819774896648[u48];
                                            local v317 = v315[v316];

                                            if v317 then
                                                v317[5] = v317;
                                                v317[6] = u47[v316];
                                                v317[4] = 6;
                                                v315[v316] = nil;
                                            end;
                                        end;
                                    elseif v82 == 189 then
                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] + UNNAMED_2819774896552[u48];
                                    elseif u47[UNNAMED_2819774896600[u48]] > UNNAMED_2819774896552[u48] then
                                        u48 = UNNAMED_2819774896648[u48];
                                    end;
                                elseif v82 >= 185 then
                                    if v82 == 186 then
                                        v79 = u19[UNNAMED_2819774896552[u48]];
                                        v79[5][v79[4]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896600[u48]];
                                    else
                                        local v318 = UNNAMED_2819774896552[u48];
                                        local v319 = UNNAMED_2819774896648[u48];
                                        local v320 = u64(u47[UNNAMED_2819774896600[u48]], 4294967295);
                                        local v321 = u64(v319, 4294967295);
                                        local v322 = u64(v320, 65535);
                                        local v323 = u63(v320, 16);
                                        local v324 = u64(v321, 65535);
                                        local v325 = u63(v321, 16);
                                        local v326 = u64(v322 * v324 + u65(u64(v322 * v325 + v323 * v324, 65535), 16), 4294967295) % 4294967296;
                                        u47[v318] = v326 ~= v326 and 0 or v326 - v326 % 1;
                                    end;
                                else
                                    u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896600[u48]](u47[UNNAMED_2819774896552[u48]]));
                                end;
                            elseif v82 < 181 then
                                if v82 < 179 then
                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] == UNNAMED_2819774896120[u48];
                                elseif v82 == 180 then
                                    u47[UNNAMED_2819774896552[u48]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896072[u48];
                                else
                                    local v327 = UNNAMED_2819774896552[u48];
                                    local v328 = u61(UNNAMED_2819774896648[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));
                                    local v329 = UNNAMED_2819774896216[5];
                                    local v330 = u61(v329[v327], 109162203);
                                    v329[v327] = v330;
                                    local v331 = UNNAMED_2819774896216[4];
                                    local v332 = v330 + 1;
                                    local v333 = u71(v331, v332);
                                    local v334;

                                    if v333 < 128 then
                                        v334 = v332 + 1;
                                    else
                                        local v335 = u71(v331, v332 + 1);

                                        if v335 < 128 then
                                            v333 = v333 - 128 + v335 * 128;
                                            v334 = v332 + 2;
                                        else
                                            local v336 = u71(v331, v332 + 2);

                                            if v336 < 128 then
                                                v333 = v333 - 128 + (v335 - 128) * 16384 + v336 * 128;
                                                v334 = v332 + 3;
                                            else
                                                local v337 = u71(v331, v332 + 3);
                                                v333 = (v333 - 128) * 16384 + (v335 - 128) * 128 + (v336 - 128) + v337 % 128 * 2097152 + (v337 - v337 % 128) * 2097152;
                                                v334 = v332 + 4;
                                            end;
                                        end;
                                    end;

                                    local v338 = v328 * 16843009;
                                    local v339 = v334 + v333;
                                    local v340 = v339 - v333 % 4;

                                    for i = v334, v340 - 1, 4 do
                                        u72(v331, i, (u61(u73(v331, i), v338)));
                                        local _ = i;
                                    end;

                                    for i = v340, v339 - 1 do
                                        u74(v331, i, (u61(u71(v331, i), v328)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819774896552[u48] = 249;
                                    UNNAMED_2819774896648[u48] = 231;
                                    UNNAMED_2819774896600[u48] = 181;
                                    UNNAMED_2819774896696[u48] = 16;
                                end;
                            elseif v82 >= 182 then
                                if v82 == 183 then
                                    u44 = u47[UNNAMED_2819774896552[u48]];
                                else
                                    u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896552[u48];
                                end;
                            elseif u47[UNNAMED_2819774896552[u48]] ~= UNNAMED_2819774896120[u48] then
                                u48 = UNNAMED_2819774896600[u48];
                            end;
                        elseif v82 >= 172 then
                            if v82 < 175 then
                                if v82 < 173 then
                                    local v341 = u55;
                                    local v342 = u56;

                                    if v341 then
                                        for i in u58, v341 do
                                            local v343 = v341[i];

                                            if v343 then
                                                v343[5] = v343;
                                                v343[6] = u47[i];
                                                v343[4] = 6;
                                                v341[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v342 then
                                        for i, v in u58, v342 do
                                            local v344 = v[6];

                                            if v342 then
                                                local v345 = v342[i];

                                                if v345 then
                                                    local v346 = u46(v344);
                                                    u59(u47, i, i + v344 - 1, 1, v346);
                                                    v345[5] = v346;
                                                    v345[4] = 1;
                                                    v342[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819774896600[u48], u60(UNNAMED_2819774896264[u48]);
                                end;

                                if v82 == 174 then
                                    local v347 = u55;
                                    local v348 = u56;

                                    if v347 then
                                        for i in u58, v347 do
                                            local v349 = v347[i];

                                            if v349 then
                                                v349[5] = v349;
                                                v349[6] = u47[i];
                                                v349[4] = 6;
                                                v347[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v348 then
                                        for i, v in u58, v348 do
                                            local v350 = v[6];

                                            if v348 then
                                                local v351 = v348[i];

                                                if v351 then
                                                    local v352 = u46(v350);
                                                    u59(u47, i, i + v350 - 1, 1, v352);
                                                    v351[5] = v352;
                                                    v351[4] = 1;
                                                    v348[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u60(UNNAMED_2819774896264[u48], u47[UNNAMED_2819774896648[u48]]);
                                end;

                                u67[UNNAMED_2819774896264[u48]] = u47[UNNAMED_2819774896648[u48]];
                            elseif v82 < 176 then
                                if u47[UNNAMED_2819774896552[u48]] ~= UNNAMED_2819774896648[u48] then
                                    u48 = UNNAMED_2819774896600[u48];
                                end;
                            else
                                if v82 ~= 177 then
                                    local v353 = u55;
                                    local v354 = u56;

                                    if v353 then
                                        for i in u58, v353 do
                                            local v355 = v353[i];

                                            if v355 then
                                                v355[5] = v355;
                                                v355[6] = u47[i];
                                                v355[4] = 6;
                                                v353[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v354 then
                                        for i, v in u58, v354 do
                                            local v356 = v[6];

                                            if v354 then
                                                local v357 = v354[i];

                                                if v357 then
                                                    local v358 = u46(v356);
                                                    u59(u47, i, i + v356 - 1, 1, v358);
                                                    v357[5] = v358;
                                                    v357[4] = 1;
                                                    v354[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return false, true, u60(u47[UNNAMED_2819774896600[u48]], u47[UNNAMED_2819774896648[u48]]);
                                end;

                                u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896072[u48]);
                            end;
                        elseif v82 >= 169 then
                            if v82 >= 170 then
                                if v82 ~= 171 then
                                    local v359 = u55;
                                    local v360 = u56;

                                    if v359 then
                                        for i in u58, v359 do
                                            local v361 = v359[i];

                                            if v361 then
                                                v361[5] = v361;
                                                v361[6] = u47[i];
                                                v361[4] = 6;
                                                v359[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v360 then
                                        for i, v in u58, v360 do
                                            local v362 = v[6];

                                            if v360 then
                                                local v363 = v360[i];

                                                if v363 then
                                                    local v364 = u46(v362);
                                                    u59(u47, i, i + v362 - 1, 1, v364);
                                                    v363[5] = v364;
                                                    v363[4] = 1;
                                                    v360[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return true, true, UNNAMED_2819774896600[u48], u60(u47[UNNAMED_2819774896552[u48]], u57(u47[UNNAMED_2819774896648[u48]], 1, u47[UNNAMED_2819774896648[u48]].n));
                                end;

                                if UNNAMED_2819774896072[u48] > u47[UNNAMED_2819774896552[u48]] then
                                    u48 = UNNAMED_2819774896648[u48];
                                end;
                            else
                                u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] < UNNAMED_2819774896072[u48];
                            end;
                        elseif v82 >= 167 then
                            if v82 == 168 then
                                v79 = UNNAMED_2819774896648[u48];
                                local v365 = UNNAMED_2819774896264[u48];
                                u47[v79] = UNNAMED_2819774896072[u48];
                                u47[v79 + 1] = v365;
                            else
                                u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] ~= UNNAMED_2819774896120[u48];
                            end;
                        else
                            v79 = UNNAMED_2819774896552[u48] + 1;
                            v77 = u61(UNNAMED_2819774896648[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));

                            for i = 1, UNNAMED_2819774896600[u48] do
                                local v366 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                local v367 = u61(v366, (u63(v366, 13)));
                                v77 = u64(u61(v367, (u65(v367, 14))), 536870911);
                                UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 14), 127)));
                                UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 21), 127)));
                                v79 = v79 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819774896696[u48] = 16;
                        end;

                        u48 = u48 + 1;
                    end;

                    v81 = 4;
                    continue;
                elseif v81 == 4 then
                    v81 = -1;

                    while true do
                        local u48;
                        local v368 = 0;

                        while true do
                            if v368 == 0 then
                                v368 = -1;
                                local v369 = UNNAMED_2819774896600[u48];

                                if v369 < 103 then
                                    if v369 >= 51 then
                                        if v369 >= 77 then
                                            if v369 < 90 then
                                                if v369 >= 83 then
                                                    if v369 >= 86 then
                                                        if v369 >= 88 then
                                                            if v369 == 89 then
                                                                v79 = u19[UNNAMED_2819774896648[u48]];
                                                                v79[5][v79[4]][UNNAMED_2819774896168[u48]] = UNNAMED_2819774896552[u48];
                                                            else
                                                                local v370 = UNNAMED_2819774896696[u48];
                                                                local v371 = UNNAMED_2819774896264[u48];
                                                                local v372 = u64(UNNAMED_2819774896120[u48], 4294967295);
                                                                local v373 = u64(v371, 4294967295);
                                                                local v374 = u64(v372, 65535);
                                                                local v375 = u63(v372, 16);
                                                                local v376 = u64(v373, 65535);
                                                                local v377 = u63(v373, 16);
                                                                local v378 = u64(v374 * v376 + u65(u64(v374 * v377 + v375 * v376, 65535), 16), 4294967295) % 4294967296;
                                                                u47[v370] = v378 ~= v378 and 0 or v378 - v378 % 1;
                                                            end;
                                                        elseif v369 == 87 then
                                                            v79 = u47[UNNAMED_2819774896552[u48]];
                                                            u47[UNNAMED_2819774896648[u48]] = u60(u57(v79, UNNAMED_2819774896696[u48], v79.n));
                                                        else
                                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896696[u48]] % UNNAMED_2819774896648[u48];
                                                        end;
                                                    elseif v369 >= 84 then
                                                        if v369 == 85 then
                                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896264[u48];
                                                        else
                                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]];
                                                            v79 = UNNAMED_2819774896648[u48 + 1];
                                                            v77 = UNNAMED_2819774896696[u48 + 1];
                                                            v75 = UNNAMED_2819774896552[u48 + 1];
                                                            v78 = v79 + v75 - 1;
                                                            v76 = v79 + v77;
                                                            v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                                            u59(v80, 1, v75, v79, u47);
                                                            u48 = u48 + 1;
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896696[u48]] = u64(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896648[u48]);
                                                    end;
                                                elseif v369 < 80 then
                                                    if v369 < 78 then
                                                        v79 = u19[UNNAMED_2819774896648[u48]];
                                                        v79[5][v79[4]] = UNNAMED_2819774896168[u48];
                                                    elseif v369 == 79 then
                                                        u47[UNNAMED_2819774896696[u48]] = u62(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896264[u48]);
                                                    else
                                                        u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896120[u48]);
                                                    end;
                                                elseif v369 >= 81 then
                                                    if v369 == 82 then
                                                        local v379 = u47[UNNAMED_2819774896696[u48]] % 4294967296;
                                                        u47[UNNAMED_2819774896552[u48]] = v379 ~= v379 and 0 or v379 - v379 % 1;
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896696[u48]]));
                                                    end;
                                                end;
                                            elseif v369 >= 96 then
                                                if v369 < 99 then
                                                    if v369 >= 97 then
                                                        if v369 == 98 then
                                                            local v380 = u55;
                                                            local v381 = u56;

                                                            if v380 then
                                                                for i in u58, v380 do
                                                                    local v382 = v380[i];

                                                                    if v382 then
                                                                        v382[5] = v382;
                                                                        v382[6] = u47[i];
                                                                        v382[4] = 6;
                                                                        v380[i] = nil;
                                                                    end;
                                                                end;
                                                            end;

                                                            if v381 then
                                                                for i, v in u58, v381 do
                                                                    local v383 = v[6];

                                                                    if v381 then
                                                                        local v384 = v381[i];

                                                                        if v384 then
                                                                            local v385 = u46(v383);
                                                                            u59(u47, i, i + v383 - 1, 1, v385);
                                                                            v384[5] = v385;
                                                                            v384[4] = 1;
                                                                            v381[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;
                                                            end;

                                                            return true, true, UNNAMED_2819774896696[u48], u60(u47[UNNAMED_2819774896648[u48]]);
                                                        end;

                                                        local v386 = UNNAMED_2819774896552[u48];
                                                        local v387 = u47[UNNAMED_2819774896648[u48]];
                                                        local v388 = u64(UNNAMED_2819774896168[u48], 4294967295);
                                                        local v389 = u64(v387, 4294967295);
                                                        local v390 = u64(v388, 65535);
                                                        local v391 = u63(v388, 16);
                                                        local v392 = u64(v389, 65535);
                                                        local v393 = u63(v389, 16);
                                                        local v394 = u64(v390 * v392 + u65(u64(v390 * v393 + v391 * v392, 65535), 16), 4294967295) % 4294967296;
                                                        u47[v386] = v394 ~= v394 and 0 or v394 - v394 % 1;
                                                    else
                                                        local v395 = UNNAMED_2819774896648[u48];
                                                        local v396 = u47[UNNAMED_2819774896696[u48]];
                                                        local v397 = u64(u47[UNNAMED_2819774896552[u48]], 4294967295);
                                                        local v398 = u64(v396, 4294967295);
                                                        local v399 = u64(v397, 65535);
                                                        local v400 = u63(v397, 16);
                                                        local v401 = u64(v398, 65535);
                                                        local v402 = u63(v398, 16);
                                                        local v403 = u64(v399 * v401 + u65(u64(v399 * v402 + v400 * v401, 65535), 16), 4294967295) % 4294967296;
                                                        u47[v395] = v403 ~= v403 and 0 or v403 - v403 % 1;
                                                    end;
                                                elseif v369 < 101 then
                                                    if v369 == 100 then
                                                        local v404 = u55;
                                                        local v405 = u56;

                                                        if v404 then
                                                            for i in u58, v404 do
                                                                local v406 = v404[i];

                                                                if v406 then
                                                                    v406[5] = v406;
                                                                    v406[6] = u47[i];
                                                                    v406[4] = 6;
                                                                    v404[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v405 then
                                                            for i, v in u58, v405 do
                                                                local v407 = v[6];

                                                                if v405 then
                                                                    local v408 = v405[i];

                                                                    if v408 then
                                                                        local v409 = u46(v407);
                                                                        u59(u47, i, i + v407 - 1, 1, v409);
                                                                        v408[5] = v409;
                                                                        v408[4] = 1;
                                                                        v405[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(UNNAMED_2819774896264[u48], u47[UNNAMED_2819774896648[u48]]);
                                                    end;

                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] % UNNAMED_2819774896264[u48];
                                                elseif v369 == 102 then
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48] * u47[UNNAMED_2819774896696[u48]];
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u19[UNNAMED_2819774896552[u48]][UNNAMED_2819774896120[u48]];
                                                end;
                                            elseif v369 < 93 then
                                                if v369 < 91 then
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]] .. UNNAMED_2819774896120[u48];
                                                elseif v369 == 92 then
                                                    u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896120[u48] - u47[UNNAMED_2819774896696[u48]];
                                                else
                                                    u67[UNNAMED_2819774896120[u48]][UNNAMED_2819774896264[u48]] = UNNAMED_2819774896168[u48];
                                                end;
                                            elseif v369 >= 94 then
                                                if v369 == 95 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77, v75, v78 = u51();

                                                    if v77 then
                                                        u47[v79] = v75;
                                                        u47[v79 + 1] = v78;
                                                        u48 = UNNAMED_2819774896552[u48];
                                                    else
                                                        u48 = UNNAMED_2819774896696[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] < UNNAMED_2819774896168[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896552[u48]]);
                                            end;
                                        elseif v369 >= 64 then
                                            if v369 < 70 then
                                                if v369 < 67 then
                                                    if v369 >= 65 then
                                                        if v369 == 66 then
                                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] > UNNAMED_2819774896552[u48];
                                                        else
                                                            v79 = UNNAMED_2819774896552[u48] + 1;
                                                            v77 = u61(UNNAMED_2819774896648[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));

                                                            for i = 1, UNNAMED_2819774896696[u48] do
                                                                local v410 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                                local v411 = u61(v410, (u63(v410, 13)));
                                                                v77 = u64(u61(v411, (u65(v411, 14))), 536870911);
                                                                UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                                UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                                UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 14), 127)));
                                                                UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 21), 127)));
                                                                v79 = v79 + 1;
                                                                local _ = i;
                                                            end;

                                                            UNNAMED_2819774896600[u48] = 80;
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896696[u48]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896264[u48];
                                                    end;
                                                elseif v369 < 68 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = UNNAMED_2819774896696[u48];
                                                    v75 = UNNAMED_2819774896552[u48];
                                                    v78 = v79 + v75 - 1;
                                                    v76 = v79 + v77;
                                                    v80 = u47[v76];
                                                    local n = v80.n;
                                                    v80.n = v77 + n - 1;
                                                    u59(v80, 1, n, v77, v80);
                                                    u59(u47, v79 + 1, v76 - 1, 1, v80);
                                                    u59(u60(u47[v79](u57(v80, 1, v80.n))), 1, v75, v79, u47);
                                                elseif v369 == 69 then
                                                    local v412;

                                                    if u47[UNNAMED_2819774896648[u48]] then
                                                        v412 = UNNAMED_2819774896552[u48];
                                                    else
                                                        v412 = UNNAMED_2819774896696[u48];
                                                    end;

                                                    u48 = v412;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] - UNNAMED_2819774896552[u48];
                                                end;
                                            elseif v369 >= 73 then
                                                if v369 >= 75 then
                                                    if v369 == 76 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] >= u47[UNNAMED_2819774896696[u48]];
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = {};
                                                    end;
                                                elseif v369 == 74 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    local v413 = u47[UNNAMED_2819774896552[u48]];
                                                    u47[v79] = UNNAMED_2819774896696[u48];
                                                    u47[v79 + 1] = v413;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u64(u47[UNNAMED_2819774896696[u48]], u47[UNNAMED_2819774896552[u48]]);
                                                end;
                                            elseif v369 >= 71 then
                                                if v369 == 72 then
                                                    v79 = u19[UNNAMED_2819774896696[u48]];
                                                    u47[UNNAMED_2819774896552[u48]] = v79[5][v79[4]][UNNAMED_2819774896648[u48]];
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] + u47[UNNAMED_2819774896552[u48]];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u68(u47[UNNAMED_2819774896696[u48]]);
                                            end;
                                        elseif v369 < 57 then
                                            if v369 >= 54 then
                                                if v369 >= 55 then
                                                    if v369 == 56 then
                                                        u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]][u47[UNNAMED_2819774896648[u48]]];
                                                    else
                                                        u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896648[u48] ^ u47[UNNAMED_2819774896696[u48]];
                                                    end;
                                                else
                                                    u19[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896696[u48]]] = UNNAMED_2819774896264[u48];
                                                end;
                                            elseif v369 >= 52 then
                                                if v369 == 53 then
                                                    u47[UNNAMED_2819774896696[u48]] = u62(u47[UNNAMED_2819774896552[u48]], u47[UNNAMED_2819774896648[u48]]);
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u64(UNNAMED_2819774896120[u48], u47[UNNAMED_2819774896696[u48]]);
                                                end;
                                            else
                                                v79 = u19[UNNAMED_2819774896552[u48]];
                                                u47[UNNAMED_2819774896696[u48]] = v79[5][v79[4]][UNNAMED_2819774896120[u48]];
                                            end;
                                        elseif v369 < 60 then
                                            if v369 < 58 then
                                                u47[UNNAMED_2819774896696[u48]] = UNNAMED_2819774896648[u48] + u47[UNNAMED_2819774896552[u48]];
                                            elseif v369 == 59 then
                                                u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]] == UNNAMED_2819774896648[u48];
                                            else
                                                u48 = u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        elseif v369 < 62 then
                                            if v369 == 61 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] + UNNAMED_2819774896264[u48];
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]](u57(u47[UNNAMED_2819774896696[u48]], 1, u47[UNNAMED_2819774896696[u48]].n));
                                            end;
                                        elseif v369 == 63 then
                                            if UNNAMED_2819774896648[u48] > u47[UNNAMED_2819774896696[u48]] then
                                                u48 = UNNAMED_2819774896552[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896552[u48]] = u61(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896696[u48]);
                                        end;
                                    elseif v369 >= 25 then
                                        if v369 >= 38 then
                                            if v369 >= 44 then
                                                if v369 >= 47 then
                                                    if v369 >= 49 then
                                                        if v369 == 50 then
                                                            v79 = u19[UNNAMED_2819774896552[u48]];
                                                            v79[5][v79[4]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896696[u48]];
                                                        else
                                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] > u47[UNNAMED_2819774896552[u48]];
                                                        end;
                                                    elseif v369 == 48 then
                                                        u47[UNNAMED_2819774896696[u48]]();
                                                    else
                                                        u47[UNNAMED_2819774896696[u48]][u47[UNNAMED_2819774896552[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                                    end;
                                                elseif v369 < 45 then
                                                    u47[UNNAMED_2819774896696[u48]] = u64(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896120[u48]);
                                                elseif v369 == 46 then
                                                    u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896120[u48], u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n));
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u19[UNNAMED_2819774896552[u48]];
                                                end;
                                            elseif v369 < 41 then
                                                if v369 >= 39 then
                                                    if v369 ~= 40 then
                                                        local v414 = u55;
                                                        local v415 = u56;

                                                        if v414 then
                                                            for i in u58, v414 do
                                                                local v416 = v414[i];

                                                                if v416 then
                                                                    v416[5] = v416;
                                                                    v416[6] = u47[i];
                                                                    v416[4] = 6;
                                                                    v414[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v415 then
                                                            for i, v in u58, v415 do
                                                                local v417 = v[6];

                                                                if v415 then
                                                                    local v418 = v415[i];

                                                                    if v418 then
                                                                        local v419 = u46(v417);
                                                                        u59(u47, i, i + v417 - 1, 1, v419);
                                                                        v418[5] = v419;
                                                                        v418[4] = 1;
                                                                        v415[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896696[u48]]);
                                                    end;

                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896264[u48]];
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896120[u48] + u47[UNNAMED_2819774896696[u48]];
                                                end;
                                            elseif v369 < 42 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] * UNNAMED_2819774896264[u48];
                                            else
                                                if v369 == 43 then
                                                    local v420 = u55;
                                                    local v421 = u56;

                                                    if v420 then
                                                        for i in u58, v420 do
                                                            local v422 = v420[i];

                                                            if v422 then
                                                                v422[5] = v422;
                                                                v422[6] = u47[i];
                                                                v422[4] = 6;
                                                                v420[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v421 then
                                                        for i, v in u58, v421 do
                                                            local v423 = v[6];

                                                            if v421 then
                                                                local v424 = v421[i];

                                                                if v424 then
                                                                    local v425 = u46(v423);
                                                                    u59(u47, i, i + v423 - 1, 1, v425);
                                                                    v424[5] = v425;
                                                                    v424[4] = 1;
                                                                    v421[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896648[u48], u47[UNNAMED_2819774896696[u48]];
                                                end;

                                                v79 = UNNAMED_2819774896552[u48];
                                                local v426 = UNNAMED_2819774896648[u48];
                                                u47[v79] = UNNAMED_2819774896168[u48];
                                                u47[v79 + 1] = v426;
                                            end;
                                        elseif v369 < 31 then
                                            if v369 >= 28 then
                                                if v369 >= 29 then
                                                    if v369 == 30 then
                                                        v79 = u61(u44, u64(u63(u44, 14), 262143), (u64(u63(u44, 28), 15)));
                                                        v77 = UNNAMED_2819774896552[u48];
                                                        v75 = UNNAMED_2819774896648[u48];
                                                        v78 = UNNAMED_2819774896696[u48];
                                                        v76 = v75 < 16384 and 7 or (v75 < 2097152 and 14 or 21);
                                                        v80 = u63(v75, v76);
                                                        local v427 = u64(v75, u65(1, v76) - 1);
                                                        UNNAMED_2819774896696[u48] = u61(v78, 108, (u64(u63(v79, 14), 127)));
                                                        UNNAMED_2819774896552[u48] = u61(v77, 127, (u64(v79, 127)));
                                                        UNNAMED_2819774896648[u48] = u61(v427, 67, (u64(u63(v79, 7), 127)));
                                                        UNNAMED_2819774896600[u48] = u61(v80, 124, (u64(u63(v79, 21), 127)));
                                                        u48 = u48 - 1;
                                                    else
                                                        local v428 = UNNAMED_2819774896552[u48];
                                                        local v429 = u61(UNNAMED_2819774896648[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));
                                                        local v430 = UNNAMED_2819774896216[5];
                                                        local v431 = u61(v430[v428], 109162203);
                                                        v430[v428] = v431;
                                                        local v432 = UNNAMED_2819774896216[4];
                                                        local v433 = v431 + 1;
                                                        local v434 = u71(v432, v433);
                                                        local v435;

                                                        if v434 < 128 then
                                                            v435 = v433 + 1;
                                                        else
                                                            local v436 = u71(v432, v433 + 1);

                                                            if v436 < 128 then
                                                                v434 = v434 - 128 + v436 * 128;
                                                                v435 = v433 + 2;
                                                            else
                                                                local v437 = u71(v432, v433 + 2);

                                                                if v437 < 128 then
                                                                    v434 = v434 - 128 + (v436 - 128) * 16384 + v437 * 128;
                                                                    v435 = v433 + 3;
                                                                else
                                                                    local v438 = u71(v432, v433 + 3);
                                                                    v434 = (v434 - 128) * 16384 + (v436 - 128) * 128 + (v437 - 128) + v438 % 128 * 2097152 + (v438 - v438 % 128) * 2097152;
                                                                    v435 = v433 + 4;
                                                                end;
                                                            end;
                                                        end;

                                                        local v439 = v429 * 16843009;
                                                        local v440 = v435 + v434;
                                                        local v441 = v440 - v434 % 4;

                                                        for i = v435, v441 - 1, 4 do
                                                            u72(v432, i, (u61(u73(v432, i), v439)));
                                                            local _ = i;
                                                        end;

                                                        for i = v441, v440 - 1 do
                                                            u74(v432, i, (u61(u71(v432, i), v429)));
                                                            local _ = i;
                                                        end;

                                                        UNNAMED_2819774896552[u48] = 42;
                                                        UNNAMED_2819774896648[u48] = 156;
                                                        UNNAMED_2819774896696[u48] = 248;
                                                        UNNAMED_2819774896600[u48] = 80;
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896696[u48]] ~= UNNAMED_2819774896648[u48];
                                                end;
                                            else
                                                if v369 < 26 then
                                                    local v442 = u55;
                                                    local v443 = u56;

                                                    if v442 then
                                                        for i in u58, v442 do
                                                            local v444 = v442[i];

                                                            if v444 then
                                                                v444[5] = v444;
                                                                v444[6] = u47[i];
                                                                v444[4] = 6;
                                                                v442[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v443 then
                                                        for i, v in u58, v443 do
                                                            local v445 = v[6];

                                                            if v443 then
                                                                local v446 = v443[i];

                                                                if v446 then
                                                                    local v447 = u46(v445);
                                                                    u59(u47, i, i + v445 - 1, 1, v447);
                                                                    v446[5] = v447;
                                                                    v446[4] = 1;
                                                                    v443[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896696[u48], u60(u47[UNNAMED_2819774896552[u48]], u57(u47[UNNAMED_2819774896648[u48]], 1, u47[UNNAMED_2819774896648[u48]].n));
                                                end;

                                                if v369 == 27 then
                                                    u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896648[u48]], u57(u47[UNNAMED_2819774896696[u48]], 1, u47[UNNAMED_2819774896696[u48]].n));
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] - u47[UNNAMED_2819774896552[u48]];
                                                end;
                                            end;
                                        elseif v369 < 34 then
                                            if v369 < 32 then
                                                u19[UNNAMED_2819774896552[u48]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896696[u48]];
                                            elseif v369 == 33 then
                                                u47[UNNAMED_2819774896696[u48]](u47[UNNAMED_2819774896648[u48]]);
                                            else
                                                u48 = u47[UNNAMED_2819774896696[u48]];
                                            end;
                                        elseif v369 < 36 then
                                            if v369 == 35 then
                                                local v448 = UNNAMED_2819774896552[u48];
                                                local v449 = u61(UNNAMED_2819774896648[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));
                                                local v450 = UNNAMED_2819774896216[5];
                                                local v451 = u61(v450[v448], 109162203);
                                                v450[v448] = v451;
                                                local v452 = UNNAMED_2819774896216[4];
                                                local v453 = v451 + 1;
                                                local v454 = u71(v452, v453);
                                                local v455;

                                                if v454 < 128 then
                                                    v455 = v453 + 1;
                                                else
                                                    local v456 = u71(v452, v453 + 1);

                                                    if v456 < 128 then
                                                        v454 = v454 - 128 + v456 * 128;
                                                        v455 = v453 + 2;
                                                    else
                                                        local v457 = u71(v452, v453 + 2);

                                                        if v457 < 128 then
                                                            v454 = v454 - 128 + (v456 - 128) * 16384 + v457 * 128;
                                                            v455 = v453 + 3;
                                                        else
                                                            local v458 = u71(v452, v453 + 3);
                                                            v454 = (v454 - 128) * 16384 + (v456 - 128) * 128 + (v457 - 128) + v458 % 128 * 2097152 + (v458 - v458 % 128) * 2097152;
                                                            v455 = v453 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v459 = v449 * 16843009;
                                                local v460 = v455 + v454;
                                                local v461 = v460 - v454 % 4;

                                                for i = v455, v461 - 1, 4 do
                                                    u72(v452, i, (u61(u73(v452, i), v459)));
                                                    local _ = i;
                                                end;

                                                for i = v461, v460 - 1 do
                                                    u74(v452, i, (u61(u71(v452, i), v449)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896552[u48] = 21;
                                                UNNAMED_2819774896648[u48] = 205;
                                                UNNAMED_2819774896696[u48] = 192;
                                                UNNAMED_2819774896600[u48] = 80;
                                            else
                                                v79 = UNNAMED_2819774896552[u48] + 1;
                                                v77 = u61(UNNAMED_2819774896648[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));

                                                for i = 1, UNNAMED_2819774896696[u48] do
                                                    local v462 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                    local v463 = u61(v462, (u63(v462, 13)));
                                                    v77 = u64(u61(v463, (u65(v463, 14))), 536870911);
                                                    UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                    UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                    UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 14), 127)));
                                                    UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 21), 127)));
                                                    v79 = v79 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896600[u48] = 80;
                                            end;
                                        elseif v369 == 37 then
                                            u47[UNNAMED_2819774896648[u48]] = u19[UNNAMED_2819774896552[u48]][u47[UNNAMED_2819774896696[u48]]];
                                        else
                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]] / UNNAMED_2819774896648[u48];
                                        end;
                                    elseif v369 < 12 then
                                        if v369 >= 6 then
                                            if v369 >= 9 then
                                                if v369 < 10 then
                                                    v79 = UNNAMED_2819774896696[u48];
                                                    local v464 = UNNAMED_2819774896648[u48];
                                                    u47[v79] = UNNAMED_2819774896552[u48];
                                                    u47[v79 + 1] = v464;
                                                elseif v369 == 11 then
                                                    for i = UNNAMED_2819774896696[u48], UNNAMED_2819774896648[u48] do
                                                        u47[i] = nil;
                                                        local _ = i;
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896648[u48] - u47[UNNAMED_2819774896696[u48]];
                                                end;
                                            elseif v369 >= 7 then
                                                if v369 == 8 then
                                                    if UNNAMED_2819774896552[u48] >= u47[UNNAMED_2819774896696[u48]] then
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    end;
                                                elseif u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896264[u48] then
                                                    u48 = UNNAMED_2819774896696[u48];
                                                end;
                                            else
                                                v79 = u19[UNNAMED_2819774896696[u48]];
                                                u47[UNNAMED_2819774896648[u48]] = v79[5][v79[4]];
                                            end;
                                        elseif v369 >= 3 then
                                            if v369 < 4 then
                                                u50 = {
                                                    [6] = u54,
                                                    [5] = u52,
                                                    [9] = u50,
                                                    [8] = u51,
                                                    [7] = u53
                                                };
                                                v79 = UNNAMED_2819774896696[u48];
                                                u53 = u47[v79 + 2] + 0;
                                                u52 = u47[v79 + 1] + 0;
                                                u51 = u47[v79] - u53;
                                                u48 = UNNAMED_2819774896648[u48];
                                            elseif v369 == 5 then
                                                u47[UNNAMED_2819774896552[u48]] = u67[UNNAMED_2819774896168[u48]];
                                            elseif u55 then
                                                local v465 = u55;
                                                local v466 = UNNAMED_2819774896648[u48];
                                                local v467 = v465[v466];

                                                if v467 then
                                                    v467[5] = v467;
                                                    v467[6] = u47[v466];
                                                    v467[4] = 6;
                                                    v465[v466] = nil;
                                                end;
                                            end;
                                        elseif v369 >= 1 then
                                            if v369 == 2 then
                                                u47[UNNAMED_2819774896696[u48]] = UNNAMED_2819774896120[u48] .. u47[UNNAMED_2819774896552[u48]];
                                            else
                                                u44 = u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] * u47[UNNAMED_2819774896696[u48]];
                                        end;
                                    elseif v369 >= 18 then
                                        if v369 < 21 then
                                            if v369 >= 19 then
                                                if v369 == 20 then
                                                    u47[UNNAMED_2819774896648[u48]] = u62(UNNAMED_2819774896168[u48], u47[UNNAMED_2819774896552[u48]]);
                                                elseif u47[UNNAMED_2819774896552[u48]] ~= UNNAMED_2819774896696[u48] then
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            else
                                                u67[UNNAMED_2819774896264[u48]][UNNAMED_2819774896168[u48]] = u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        elseif v369 >= 23 then
                                            if v369 == 24 then
                                                u47[UNNAMED_2819774896648[u48]] = #u47[UNNAMED_2819774896696[u48]];
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] ~= u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        elseif v369 == 22 then
                                            u45 = u47[UNNAMED_2819774896696[u48]];
                                        else
                                            u47[UNNAMED_2819774896552[u48]][u47[UNNAMED_2819774896648[u48]]] = UNNAMED_2819774896168[u48];
                                        end;
                                    elseif v369 >= 15 then
                                        if v369 >= 16 then
                                            if v369 == 17 then
                                                local v468 = UNNAMED_2819774896696[u48];
                                                local v469 = UNNAMED_2819774896648[u48];
                                                local v470 = UNNAMED_2819774896216[5];
                                                local v471 = u61(v470[v468], 109162203);
                                                v470[v468] = v471;
                                                local v472 = UNNAMED_2819774896216[4];
                                                local v473 = v471 + 1;
                                                local v474 = u71(v472, v473);
                                                local v475;

                                                if v474 < 128 then
                                                    v475 = v473 + 1;
                                                else
                                                    local v476 = u71(v472, v473 + 1);

                                                    if v476 < 128 then
                                                        v474 = v474 - 128 + v476 * 128;
                                                        v475 = v473 + 2;
                                                    else
                                                        local v477 = u71(v472, v473 + 2);

                                                        if v477 < 128 then
                                                            v474 = v474 - 128 + (v476 - 128) * 16384 + v477 * 128;
                                                            v475 = v473 + 3;
                                                        else
                                                            local v478 = u71(v472, v473 + 3);
                                                            v474 = (v474 - 128) * 16384 + (v476 - 128) * 128 + (v477 - 128) + v478 % 128 * 2097152 + (v478 - v478 % 128) * 2097152;
                                                            v475 = v473 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v479 = v469 * 16843009;
                                                local v480 = v475 + v474;
                                                local v481 = v480 - v474 % 4;

                                                for i = v475, v481 - 1, 4 do
                                                    u72(v472, i, (u61(u73(v472, i), v479)));
                                                    local _ = i;
                                                end;

                                                for i = v481, v480 - 1 do
                                                    u74(v472, i, (u61(u71(v472, i), v469)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896696[u48] = 78;
                                                UNNAMED_2819774896648[u48] = 229;
                                                UNNAMED_2819774896552[u48] = 8;
                                                UNNAMED_2819774896600[u48] = 80;
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = UNNAMED_2819774896648[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896552[u48]] = u63(u47[UNNAMED_2819774896696[u48]], UNNAMED_2819774896648[u48]);
                                        end;
                                    elseif v369 >= 13 then
                                        if v369 == 14 then
                                            if u47[UNNAMED_2819774896648[u48]] ~= u47[UNNAMED_2819774896552[u48]] then
                                                u48 = UNNAMED_2819774896696[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896696[u48] * u47[UNNAMED_2819774896552[u48]];
                                        end;
                                    else
                                        v79 = UNNAMED_2819774896696[u48] + 1;
                                        v77 = UNNAMED_2819774896648[u48];

                                        for i = 1, UNNAMED_2819774896552[u48] do
                                            local v482 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                            local v483 = u61(v482, (u63(v482, 13)));
                                            v77 = u64(u61(v483, (u65(v483, 14))), 536870911);
                                            UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                            UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                            UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 14), 127)));
                                            UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 21), 127)));
                                            v79 = v79 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819774896600[u48] = 80;
                                    end;
                                else
                                    if v369 >= 155 then
                                        if v369 >= 181 then
                                            if v369 >= 194 then
                                                if v369 >= 200 then
                                                    if v369 >= 203 then
                                                        if v369 < 205 then
                                                            if v369 == 204 then
                                                                u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]] < u47[UNNAMED_2819774896648[u48]];
                                                            else
                                                                v79 = UNNAMED_2819774896648[u48];
                                                                v77, v75 = u51();

                                                                if v77 then
                                                                    u47[v79] = v75;
                                                                    u48 = UNNAMED_2819774896696[u48];
                                                                else
                                                                    u48 = UNNAMED_2819774896552[u48];
                                                                end;
                                                            end;
                                                        else
                                                            if v369 == 206 then
                                                                local v484 = u55;
                                                                local v485 = u56;

                                                                if v484 then
                                                                    for i in u58, v484 do
                                                                        local v486 = v484[i];

                                                                        if v486 then
                                                                            v486[5] = v486;
                                                                            v486[6] = u47[i];
                                                                            v486[4] = 6;
                                                                            v484[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;

                                                                if v485 then
                                                                    for i, v in u58, v485 do
                                                                        local v487 = v[6];

                                                                        if v485 then
                                                                            local v488 = v485[i];

                                                                            if v488 then
                                                                                local v489 = u46(v487);
                                                                                u59(u47, i, i + v487 - 1, 1, v489);
                                                                                v488[5] = v489;
                                                                                v488[4] = 1;
                                                                                v485[i] = nil;
                                                                            end;
                                                                        end;
                                                                    end;
                                                                end;

                                                                return false, true, u60(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896168[u48], UNNAMED_2819774896264[u48]);
                                                            end;

                                                            u47[UNNAMED_2819774896648[u48]] = -u47[UNNAMED_2819774896696[u48]];
                                                        end;
                                                    elseif v369 < 201 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] // UNNAMED_2819774896696[u48];
                                                    else
                                                        if v369 == 202 then
                                                            local v490 = UNNAMED_2819774896552[u48];
                                                            local v491 = v490 + UNNAMED_2819774896648[u48];
                                                            local v492 = u55;
                                                            local v493 = u56;

                                                            if v492 then
                                                                for i in u58, v492 do
                                                                    local v494 = v492[i];

                                                                    if v494 then
                                                                        v494[5] = v494;
                                                                        v494[6] = u47[i];
                                                                        v494[4] = 6;
                                                                        v492[i] = nil;
                                                                    end;
                                                                end;
                                                            end;

                                                            if v493 then
                                                                for i, v in u58, v493 do
                                                                    local v495 = v[6];

                                                                    if v493 then
                                                                        local v496 = v493[i];

                                                                        if v496 then
                                                                            local v497 = u46(v495);
                                                                            u59(u47, i, i + v495 - 1, 1, v497);
                                                                            v496[5] = v497;
                                                                            v496[4] = 1;
                                                                            v493[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;
                                                            end;

                                                            return true, false, v490, v491;
                                                        end;

                                                        u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]] % u47[UNNAMED_2819774896648[u48]];
                                                    end;
                                                elseif v369 >= 197 then
                                                    if v369 < 198 then
                                                        u47[UNNAMED_2819774896648[u48]] = not u47[UNNAMED_2819774896552[u48]];
                                                    elseif v369 == 199 then
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    else
                                                        v79 = UNNAMED_2819774896696[u48];
                                                        v77 = u47[UNNAMED_2819774896552[u48]];
                                                        u47[v79 + 1] = v77;
                                                        u47[v79] = v77[UNNAMED_2819774896120[u48]];
                                                    end;
                                                elseif v369 < 195 then
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] .. u47[UNNAMED_2819774896696[u48]];
                                                else
                                                    if v369 ~= 196 then
                                                        local v498 = u55;
                                                        local v499 = u56;

                                                        if v498 then
                                                            for i in u58, v498 do
                                                                local v500 = v498[i];

                                                                if v500 then
                                                                    v500[5] = v500;
                                                                    v500[6] = u47[i];
                                                                    v500[4] = 6;
                                                                    v498[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v499 then
                                                            for i, v in u58, v499 do
                                                                local v501 = v[6];

                                                                if v499 then
                                                                    local v502 = v499[i];

                                                                    if v502 then
                                                                        local v503 = u46(v501);
                                                                        u59(u47, i, i + v501 - 1, 1, v503);
                                                                        v502[5] = v503;
                                                                        v502[4] = 1;
                                                                        v499[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return true, true, UNNAMED_2819774896648[u48], u60(u47[UNNAMED_2819774896696[u48]], u47[UNNAMED_2819774896552[u48]]);
                                                    end;

                                                    local v504 = UNNAMED_2819774896696[u48];
                                                    local v505 = UNNAMED_2819774896648[u48];
                                                    local v506 = u64(u47[UNNAMED_2819774896552[u48]], 4294967295);
                                                    local v507 = u64(v505, 4294967295);
                                                    local v508 = u64(v506, 65535);
                                                    local v509 = u63(v506, 16);
                                                    local v510 = u64(v507, 65535);
                                                    local v511 = u63(v507, 16);
                                                    local v512 = u64(v508 * v510 + u65(u64(v508 * v511 + v509 * v510, 65535), 16), 4294967295) % 4294967296;
                                                    u47[v504] = v512 ~= v512 and 0 or v512 - v512 % 1;
                                                end;
                                            elseif v369 < 187 then
                                                if v369 >= 184 then
                                                    if v369 >= 185 then
                                                        if v369 == 186 then
                                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] == u47[UNNAMED_2819774896552[u48]];
                                                        else
                                                            v79 = UNNAMED_2819774896648[u48];
                                                            v77 = UNNAMED_2819774896696[u48];
                                                            v75 = UNNAMED_2819774896552[u48];
                                                            v78 = v79 + v75 - 1;
                                                            v76 = v79 + v77;
                                                            v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                                            u59(v80, 1, v75, v79, u47);
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896120[u48] % u47[UNNAMED_2819774896696[u48]];
                                                    end;
                                                elseif v369 >= 182 then
                                                    if v369 == 183 then
                                                        u47[UNNAMED_2819774896696[u48]] = u45;
                                                    elseif UNNAMED_2819774896264[u48] > u47[UNNAMED_2819774896696[u48]] then
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    end;
                                                else
                                                    v79 = UNNAMED_2819774896696[u48];
                                                    local v513 = u47[UNNAMED_2819774896552[u48]];
                                                    u47[v79] = u47[UNNAMED_2819774896648[u48]];
                                                    u47[v79 + 1] = v513;
                                                end;
                                            elseif v369 >= 190 then
                                                if v369 < 192 then
                                                    if v369 == 191 then
                                                        v79 = UNNAMED_2819774896648[u48];
                                                        local v514 = UNNAMED_2819774896168[u48];
                                                        u47[v79] = u47[UNNAMED_2819774896552[u48]];
                                                        u47[v79 + 1] = v514;
                                                    else
                                                        v79 = UNNAMED_2819774896552[u48];
                                                        local v515 = u47[UNNAMED_2819774896648[u48]];
                                                        u47[v79] = UNNAMED_2819774896168[u48];
                                                        u47[v79 + 1] = v515;
                                                    end;
                                                elseif v369 == 193 then
                                                    u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896120[u48], UNNAMED_2819774896264[u48]);
                                                else
                                                    u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896168[u48]] = UNNAMED_2819774896264[u48];
                                                end;
                                            elseif v369 < 188 then
                                                if u47[UNNAMED_2819774896648[u48]] >= u47[UNNAMED_2819774896552[u48]] then
                                                    u48 = UNNAMED_2819774896696[u48];
                                                end;
                                            elseif v369 == 189 then
                                                u47[UNNAMED_2819774896648[u48]](u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n));
                                            else
                                                v79 = UNNAMED_2819774896696[u48];
                                                v77 = UNNAMED_2819774896552[u48];
                                                v75 = UNNAMED_2819774896648[u48];
                                                v78 = u47[v79];
                                                v76 = v79 + v77;
                                                v80 = u47[v76];
                                                u59(u47, v79 + 1, v76 - 1, v75 + 1, v78);
                                                u59(v80, 1, v80.n, v75 + v77, v78);
                                            end;
                                        elseif v369 >= 168 then
                                            if v369 >= 174 then
                                                if v369 >= 177 then
                                                    if v369 < 179 then
                                                        if v369 == 178 then
                                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] <= UNNAMED_2819774896552[u48];
                                                        else
                                                            u47[UNNAMED_2819774896552[u48]] = u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896696[u48]];
                                                        end;
                                                    elseif v369 == 180 then
                                                        local v516 = UNNAMED_2819774896552[u48];
                                                        local v517 = UNNAMED_2819774896696[u48];
                                                        local v518, v519 = u47[UNNAMED_2819774896648[u48]]();
                                                        u47[v516] = v518;
                                                        u47[v517] = v519;
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] // u47[UNNAMED_2819774896552[u48]];
                                                    end;
                                                elseif v369 >= 175 then
                                                    if v369 == 176 then
                                                        local v520 = u55;
                                                        local v521 = u56;

                                                        if v520 then
                                                            for i in u58, v520 do
                                                                local v522 = v520[i];

                                                                if v522 then
                                                                    v522[5] = v522;
                                                                    v522[6] = u47[i];
                                                                    v522[4] = 6;
                                                                    v520[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v521 then
                                                            for i, v in u58, v521 do
                                                                local v523 = v[6];

                                                                if v521 then
                                                                    local v524 = v521[i];

                                                                    if v524 then
                                                                        local v525 = u46(v523);
                                                                        u59(u47, i, i + v523 - 1, 1, v525);
                                                                        v524[5] = v525;
                                                                        v524[4] = 1;
                                                                        v521[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(UNNAMED_2819774896264[u48]);
                                                    end;

                                                    u47[UNNAMED_2819774896552[u48]] = u47;
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u44;
                                                end;
                                            elseif v369 >= 171 then
                                                if v369 >= 172 then
                                                    if v369 ~= 173 then
                                                        local v526 = u55;
                                                        local v527 = u56;

                                                        if v526 then
                                                            for i in u58, v526 do
                                                                local v528 = v526[i];

                                                                if v528 then
                                                                    v528[5] = v528;
                                                                    v528[6] = u47[i];
                                                                    v528[4] = 6;
                                                                    v526[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v527 then
                                                            for i, v in u58, v527 do
                                                                local v529 = v[6];

                                                                if v527 then
                                                                    local v530 = v527[i];

                                                                    if v530 then
                                                                        local v531 = u46(v529);
                                                                        u59(u47, i, i + v529 - 1, 1, v531);
                                                                        v530[5] = v531;
                                                                        v530[4] = 1;
                                                                        v527[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(UNNAMED_2819774896168[u48], UNNAMED_2819774896264[u48]);
                                                    end;

                                                    local v532 = UNNAMED_2819774896552[u48];
                                                    local v533 = u47[UNNAMED_2819774896696[u48]];
                                                    local v534 = u64(UNNAMED_2819774896648[u48], 4294967295);
                                                    local v535 = u64(v533, 4294967295);
                                                    local v536 = u64(v534, 65535);
                                                    local v537 = u63(v534, 16);
                                                    local v538 = u64(v535, 65535);
                                                    local v539 = u63(v535, 16);
                                                    local v540 = u64(v536 * v538 + u65(u64(v536 * v539 + v537 * v538, 65535), 16), 4294967295) % 4294967296;
                                                    u47[v532] = v540 ~= v540 and 0 or v540 - v540 % 1;
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] <= UNNAMED_2819774896264[u48];
                                                end;
                                            elseif v369 >= 169 then
                                                if v369 == 170 then
                                                    u50 = {
                                                        [6] = u54,
                                                        [5] = u52,
                                                        [9] = u50,
                                                        [8] = u51,
                                                        [7] = u53
                                                    };
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = u69(u70);
                                                    v77(UNNAMED_2819774896360, u47[v79], u47[v79 + 1], u47[v79 + 2]);
                                                    u51 = v77;
                                                    u54 = UNNAMED_2819774896696[u48];
                                                    u48 = UNNAMED_2819774896552[u48];
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896552[u48]]());
                                                end;
                                            else
                                                u67[UNNAMED_2819774896168[u48]][u47[UNNAMED_2819774896552[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        elseif v369 < 161 then
                                            if v369 < 158 then
                                                if v369 < 156 then
                                                    v79 = UNNAMED_2819774896696[u48];
                                                    v77 = UNNAMED_2819774896648[u48];
                                                    v75 = UNNAMED_2819774896552[u48];
                                                    v78 = u47[v79];
                                                    u59(u47, v79 + 1, v79 + v77, v75 + 1, v78);
                                                else
                                                    if v369 == 157 then
                                                        local v541 = u55;
                                                        local v542 = u56;

                                                        if v541 then
                                                            for i in u58, v541 do
                                                                local v543 = v541[i];

                                                                if v543 then
                                                                    v543[5] = v543;
                                                                    v543[6] = u47[i];
                                                                    v543[4] = 6;
                                                                    v541[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v542 then
                                                            for i, v in u58, v542 do
                                                                local v544 = v[6];

                                                                if v542 then
                                                                    local v545 = v542[i];

                                                                    if v545 then
                                                                        local v546 = u46(v544);
                                                                        u59(u47, i, i + v544 - 1, 1, v546);
                                                                        v545[5] = v546;
                                                                        v545[4] = 1;
                                                                        v542[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896168[u48]);
                                                    end;

                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = UNNAMED_2819774896696[u48];
                                                    v75 = UNNAMED_2819774896552[u48];
                                                    v78 = v79 + v77;
                                                    u47[v79] = u60(u47[v79](u57(u47, v79 + 1, v78)));
                                                end;
                                            elseif v369 >= 159 then
                                                if v369 == 160 then
                                                    v79 = UNNAMED_2819774896552[u48];
                                                    v77 = UNNAMED_2819774896648[u48];
                                                    v75 = UNNAMED_2819774896696[u48];
                                                    v78 = v79 + v77;
                                                    v76 = u47[v78];
                                                    v80 = v76.n;
                                                    v76.n = v77 + v80 - 1;
                                                    u59(v76, 1, v80, v77, v76);
                                                    u59(u47, v79 + 1, v78 - 1, 1, v76);
                                                    u47[v79] = u60(u47[v79](u57(v76, 1, v76.n)));
                                                else
                                                    u67[UNNAMED_2819774896264[u48]] = UNNAMED_2819774896168[u48];
                                                end;
                                            else
                                                u51 = u50[8];
                                                u52 = u50[5];
                                                u53 = u50[7];
                                                u54 = u50[6];
                                                u50 = u50[9];
                                            end;
                                        elseif v369 >= 164 then
                                            if v369 >= 166 then
                                                if v369 ~= 167 then
                                                    local v547 = u55;
                                                    local v548 = u56;

                                                    if v547 then
                                                        for i in u58, v547 do
                                                            local v549 = v547[i];

                                                            if v549 then
                                                                v549[5] = v549;
                                                                v549[6] = u47[i];
                                                                v549[4] = 6;
                                                                v547[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v548 then
                                                        for i, v in u58, v548 do
                                                            local v550 = v[6];

                                                            if v548 then
                                                                local v551 = v548[i];

                                                                if v551 then
                                                                    local v552 = u46(v550);
                                                                    u59(u47, i, i + v550 - 1, 1, v552);
                                                                    v551[5] = v552;
                                                                    v551[4] = 1;
                                                                    v548[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u60(u47[UNNAMED_2819774896552[u48]]);
                                                end;

                                                if UNNAMED_2819774896264[u48] >= u47[UNNAMED_2819774896648[u48]] then
                                                    u48 = UNNAMED_2819774896696[u48];
                                                end;
                                            elseif v369 == 165 then
                                                local v553 = UNNAMED_2819774896696[u48];
                                                local v554 = UNNAMED_2819774896264[u48];
                                                local v555 = u64(u47[UNNAMED_2819774896648[u48]], 4294967295);
                                                local v556 = u64(v554, 4294967295);
                                                local v557 = u64(v555, 65535);
                                                local v558 = u63(v555, 16);
                                                local v559 = u64(v556, 65535);
                                                local v560 = u63(v556, 16);
                                                local v561 = u64(v557 * v559 + u65(u64(v557 * v560 + v558 * v559, 65535), 16), 4294967295) % 4294967296;
                                                u47[v553] = v561 ~= v561 and 0 or v561 - v561 % 1;
                                            else
                                                u67[UNNAMED_2819774896168[u48]] = u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        elseif v369 >= 162 then
                                            if v369 == 163 then
                                                u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896696[u48]](u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n)));
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] + UNNAMED_2819774896696[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] / UNNAMED_2819774896264[u48];
                                        end;

                                        v368 = 1;
                                        continue;
                                    end;

                                    if v369 < 129 then
                                        if v369 < 116 then
                                            if v369 < 109 then
                                                if v369 >= 106 then
                                                    if v369 >= 107 then
                                                        if v369 ~= 108 then
                                                            local v562 = u55;
                                                            local v563 = u56;

                                                            if v562 then
                                                                for i in u58, v562 do
                                                                    local v564 = v562[i];

                                                                    if v564 then
                                                                        v564[5] = v564;
                                                                        v564[6] = u47[i];
                                                                        v564[4] = 6;
                                                                        v562[i] = nil;
                                                                    end;
                                                                end;
                                                            end;

                                                            if v563 then
                                                                for i, v in u58, v563 do
                                                                    local v565 = v[6];

                                                                    if v563 then
                                                                        local v566 = v563[i];

                                                                        if v566 then
                                                                            local v567 = u46(v565);
                                                                            u59(u47, i, i + v565 - 1, 1, v567);
                                                                            v566[5] = v567;
                                                                            v566[4] = 1;
                                                                            v563[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;
                                                            end;

                                                            return false, true, u47[UNNAMED_2819774896696[u48]];
                                                        end;

                                                        u47[UNNAMED_2819774896696[u48]] = UNNAMED_2819774896120[u48];
                                                    else
                                                        u19[UNNAMED_2819774896552[u48]][u47[UNNAMED_2819774896696[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                                    end;
                                                elseif v369 < 104 then
                                                    u47[UNNAMED_2819774896696[u48]] = UNNAMED_2819774896360[UNNAMED_2819774896648[u48]];
                                                else
                                                    if v369 ~= 105 then
                                                        local v568 = u55;
                                                        local v569 = u56;

                                                        if v568 then
                                                            for i in u58, v568 do
                                                                local v570 = v568[i];

                                                                if v570 then
                                                                    v570[5] = v570;
                                                                    v570[6] = u47[i];
                                                                    v570[4] = 6;
                                                                    v568[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v569 then
                                                            for i, v in u58, v569 do
                                                                local v571 = v[6];

                                                                if v569 then
                                                                    local v572 = v569[i];

                                                                    if v572 then
                                                                        local v573 = u46(v571);
                                                                        u59(u47, i, i + v571 - 1, 1, v573);
                                                                        v572[5] = v573;
                                                                        v572[4] = 1;
                                                                        v569[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, false;
                                                    end;

                                                    v79 = u19[UNNAMED_2819774896552[u48]];
                                                    v79[5][v79[4]] = u47[UNNAMED_2819774896648[u48]];
                                                end;
                                            elseif v369 < 112 then
                                                if v369 >= 110 then
                                                    if v369 == 111 then
                                                        u47[UNNAMED_2819774896696[u48]] = u67[UNNAMED_2819774896264[u48]][UNNAMED_2819774896120[u48]];
                                                    elseif u47[UNNAMED_2819774896552[u48]] > u47[UNNAMED_2819774896696[u48]] then
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    end;
                                                else
                                                    u51 = u51 + u53;

                                                    if u53 <= 0 then
                                                        v79 = u52 <= u51;
                                                    else
                                                        v79 = u51 <= u52;
                                                    end;

                                                    if v79 then
                                                        u47[UNNAMED_2819774896648[u48]] = u51;
                                                        u48 = UNNAMED_2819774896552[u48];
                                                    else
                                                        u48 = UNNAMED_2819774896696[u48];
                                                    end;
                                                end;
                                            elseif v369 < 114 then
                                                if v369 == 113 then
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]][UNNAMED_2819774896552[u48]];
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] <= u47[UNNAMED_2819774896696[u48]];
                                                end;
                                            elseif v369 == 115 then
                                                u47[UNNAMED_2819774896552[u48]] = u61(u47[UNNAMED_2819774896696[u48]], UNNAMED_2819774896120[u48]);
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896264[u48]));
                                            end;
                                        elseif v369 < 122 then
                                            if v369 >= 119 then
                                                if v369 < 120 then
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]]();
                                                elseif v369 == 121 then
                                                    if u47[UNNAMED_2819774896552[u48]] > UNNAMED_2819774896168[u48] then
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]][UNNAMED_2819774896168[u48]] = UNNAMED_2819774896648[u48];
                                                end;
                                            elseif v369 >= 117 then
                                                if v369 == 118 then
                                                    local v574;

                                                    if u47[UNNAMED_2819774896696[u48]] then
                                                        v574 = UNNAMED_2819774896648[u48];
                                                    else
                                                        v574 = UNNAMED_2819774896552[u48];
                                                    end;

                                                    u48 = v574;
                                                elseif u47[UNNAMED_2819774896696[u48]] ~= UNNAMED_2819774896264[u48] then
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            else
                                                v79 = UNNAMED_2819774896648[u48];
                                                local v575 = UNNAMED_2819774896264[u48];
                                                u47[v79] = UNNAMED_2819774896696[u48];
                                                u47[v79 + 1] = v575;
                                            end;
                                        elseif v369 >= 125 then
                                            if v369 < 127 then
                                                if v369 == 126 then
                                                    local v576 = u55;
                                                    local v577 = u56;

                                                    if v576 then
                                                        for i in u58, v576 do
                                                            local v578 = v576[i];

                                                            if v578 then
                                                                v578[5] = v578;
                                                                v578[6] = u47[i];
                                                                v578[4] = 6;
                                                                v576[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v577 then
                                                        for i, v in u58, v577 do
                                                            local v579 = v[6];

                                                            if v577 then
                                                                local v580 = v577[i];

                                                                if v580 then
                                                                    local v581 = u46(v579);
                                                                    u59(u47, i, i + v579 - 1, 1, v581);
                                                                    v580[5] = v581;
                                                                    v580[4] = 1;
                                                                    v577[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896696[u48], u60(UNNAMED_2819774896120[u48], u47[UNNAMED_2819774896552[u48]]);
                                                end;

                                                u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896552[u48]] ~= UNNAMED_2819774896120[u48];
                                            elseif v369 == 128 then
                                                v79 = UNNAMED_2819774896696[u48];
                                                local v582 = UNNAMED_2819774896264[u48];
                                                u47[v79] = UNNAMED_2819774896120[u48];
                                                u47[v79 + 1] = v582;
                                            else
                                                local v583 = nil;
                                                local v584 = UNNAMED_2819774896552[u48];
                                                local v585 = UNNAMED_2819774896120[u48];
                                                local v586 = UNNAMED_2819774896168[u48];
                                                local v587 = u55;
                                                local v588 = u56;
                                                local v589 = v586[0];

                                                if v589 then
                                                    local v590 = #v589 / 3;

                                                    if v590 > 0 then
                                                        v583 = {};

                                                        for i = 1, v590 do
                                                            local v591 = (i - 1) * 3;
                                                            local v592 = v589[v591 + 2];
                                                            local v593 = v589[v591 + 1];
                                                            local v594;

                                                            if v592 == 2 then
                                                                v587 = v587 or {};
                                                                local v595 = v587[v593];

                                                                if not v595 then
                                                                    v595 = {
                                                                        [5] = u47,
                                                                        [4] = v593
                                                                    };
                                                                    v587[v593] = v595;
                                                                end;

                                                                v583[i] = v595;
                                                                v594 = i;
                                                            elseif v592 == 0 then
                                                                v583[i] = u47[v593];
                                                                v594 = i;
                                                            elseif v592 == 3 then
                                                                v583[i] = u19[v593];
                                                                v594 = i;
                                                            elseif v592 == 1 then
                                                                v588 = v588 or {};
                                                                local v596 = v588[v593];

                                                                if not v596 then
                                                                    v596 = {
                                                                        [5] = u47,
                                                                        [4] = v593,
                                                                        [6] = v589[v591 + 3]
                                                                    };
                                                                    v588[v593] = v596;
                                                                end;

                                                                v583[i] = v596;
                                                                v594 = i;
                                                            else
                                                                v594 = i;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                local v597 = v586[-2];
                                                v586[v597] = v583;
                                                local v598 = v585(u57(v586, 1, v586[-1]));
                                                v586[v597] = nil;
                                                u47[v584] = v598;
                                                u55 = v587;
                                                u56 = v588;
                                            end;
                                        elseif v369 >= 123 then
                                            if v369 == 124 then
                                                u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] * UNNAMED_2819774896696[u48];
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u61(UNNAMED_2819774896168[u48], u47[UNNAMED_2819774896552[u48]]);
                                            end;
                                        elseif u55 then
                                            local v599 = u55;
                                            local v600 = UNNAMED_2819774896648[u48];
                                            local v601 = v599[v600];

                                            if v601 then
                                                v601[5] = v601;
                                                v601[6] = u47[v600];
                                                v601[4] = 6;
                                                v599[v600] = nil;
                                            end;

                                            local v602 = u55;
                                            local v603 = UNNAMED_2819774896552[u48];
                                            local v604 = v602[v603];

                                            if v604 then
                                                v604[5] = v604;
                                                v604[6] = u47[v603];
                                                v604[4] = 6;
                                                v602[v603] = nil;
                                            end;
                                        end;
                                    else
                                        if v369 >= 142 then
                                            if v369 < 148 then
                                                if v369 < 145 then
                                                    if v369 < 143 then
                                                        if u47[UNNAMED_2819774896552[u48]] > UNNAMED_2819774896648[u48] then
                                                            u48 = UNNAMED_2819774896696[u48];
                                                        end;
                                                    elseif v369 == 144 then
                                                        u47[UNNAMED_2819774896696[u48]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896552[u48]];
                                                    else
                                                        v79 = u61(u44, u64(u63(u44, 14), 262143), (u64(u63(u44, 28), 15)));
                                                        v77 = UNNAMED_2819774896696[u48];
                                                        v75 = UNNAMED_2819774896552[u48];
                                                        v78 = UNNAMED_2819774896648[u48];
                                                        v76 = v77 < 2097152 and 7 or 14;
                                                        v80 = u64(v77, u65(1, v76) - 1);
                                                        local v605 = u63(v77, v76);
                                                        UNNAMED_2819774896648[u48] = u61(v78, 67, (u64(u63(v79, 7), 127)));
                                                        UNNAMED_2819774896600[u48] = u61(v605, 121, (u64(u63(v79, 21), 127)));
                                                        UNNAMED_2819774896552[u48] = u61(v75, 3, (u64(v79, 127)));
                                                        UNNAMED_2819774896696[u48] = u61(v80, 31, (u64(u63(v79, 14), 127)));
                                                        u48 = u48 - 1;
                                                    end;
                                                elseif v369 < 146 then
                                                    v79 = u19[UNNAMED_2819774896696[u48]];
                                                    v79[5][v79[4]][UNNAMED_2819774896264[u48]] = UNNAMED_2819774896120[u48];
                                                elseif v369 == 147 then
                                                    u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896264[u48], u47[UNNAMED_2819774896648[u48]]);
                                                else
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    local v606 = UNNAMED_2819774896552[u48];
                                                    u47[v79] = u47[UNNAMED_2819774896696[u48]];
                                                    u47[v79 + 1] = v606;
                                                end;
                                            elseif v369 < 151 then
                                                if v369 < 149 then
                                                    if u47[UNNAMED_2819774896552[u48]] >= UNNAMED_2819774896648[u48] then
                                                        u48 = UNNAMED_2819774896696[u48];
                                                    end;
                                                elseif v369 == 150 then
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896696[u48] / u47[UNNAMED_2819774896552[u48]];
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896552[u48];
                                                end;
                                            elseif v369 >= 153 then
                                                if v369 == 154 then
                                                    u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896696[u48]], UNNAMED_2819774896120[u48]);
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] == UNNAMED_2819774896168[u48];
                                                end;
                                            elseif v369 == 152 then
                                                u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896168[u48]] = UNNAMED_2819774896552[u48];
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = u61(u47[UNNAMED_2819774896552[u48]], u47[UNNAMED_2819774896648[u48]]);
                                            end;

                                            v368 = 1;
                                            continue;
                                        end;

                                        if v369 >= 135 then
                                            if v369 < 138 then
                                                if v369 >= 136 then
                                                    if v369 == 137 then
                                                        u47[UNNAMED_2819774896648[u48]] = u65(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896696[u48]);
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u67[UNNAMED_2819774896168[u48]][u47[UNNAMED_2819774896552[u48]]];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]];
                                                end;
                                            elseif v369 >= 140 then
                                                if v369 == 141 then
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] / u47[UNNAMED_2819774896696[u48]];
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48] + UNNAMED_2819774896168[u48];
                                                end;
                                            elseif v369 == 139 then
                                                u47[UNNAMED_2819774896552[u48]][UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]];
                                            elseif u55 then
                                                local v607 = u55;
                                                local v608 = UNNAMED_2819774896696[u48];
                                                local v609 = v607[v608];

                                                if v609 then
                                                    v609[5] = v609;
                                                    v609[6] = u47[v608];
                                                    v609[4] = 6;
                                                    v607[v608] = nil;
                                                end;

                                                local v610 = u55;
                                                local v611 = UNNAMED_2819774896552[u48];
                                                local v612 = v610[v611];

                                                if v612 then
                                                    v612[5] = v612;
                                                    v612[6] = u47[v611];
                                                    v612[4] = 6;
                                                    v610[v611] = nil;
                                                end;

                                                local v613 = u55;
                                                local v614 = UNNAMED_2819774896648[u48];
                                                local v615 = v613[v614];

                                                if v615 then
                                                    v615[5] = v615;
                                                    v615[6] = u47[v614];
                                                    v615[4] = 6;
                                                    v613[v614] = nil;
                                                end;
                                            end;
                                        elseif v369 >= 132 then
                                            if v369 < 133 then
                                                u47[UNNAMED_2819774896696[u48]] = u46(UNNAMED_2819774896552[u48]);
                                            elseif v369 == 134 then
                                                local v616 = UNNAMED_2819774896552[u48];
                                                local v617 = UNNAMED_2819774896120[u48];
                                                local v618 = u64(UNNAMED_2819774896696[u48], 4294967295);
                                                local v619 = u64(v617, 4294967295);
                                                local v620 = u64(v618, 65535);
                                                local v621 = u63(v618, 16);
                                                local v622 = u64(v619, 65535);
                                                local v623 = u63(v619, 16);
                                                local v624 = u64(v620 * v622 + u65(u64(v620 * v623 + v621 * v622, 65535), 16), 4294967295) % 4294967296;
                                                u47[v616] = v624 ~= v624 and 0 or v624 - v624 % 1;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] - UNNAMED_2819774896264[u48];
                                            end;
                                        else
                                            if v369 < 130 then
                                                u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896696[u48]], u47[UNNAMED_2819774896648[u48]]);
                                                v368 = 1;
                                                continue;
                                            end;

                                            if v369 == 131 then
                                                u49 = UNNAMED_2819774896648[u48];
                                                u48 = UNNAMED_2819774896696[u48] + 1;
                                                v81 = 3;
                                                break;
                                            end;

                                            u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896120[u48]);
                                        end;
                                    end;
                                end;

                                v368 = 1;
                                continue;
                            elseif v368 == 1 then
                                v368 = -1;
                                u48 = u48 + 1;
                                break;
                            else
                                break;
                            end;
                        end;

                        if v81 ~= -1 then
                            break;
                        end;
                    end;

                    if v81 ~= -1 then
                        continue;
                    end;

                    v81 = 5;
                    continue;
                elseif v81 == 5 then
                    v81 = -1;

                    while true do
                        local u48;
                        local v625 = 0;

                        while true do
                            if v625 == 0 then
                                v625 = -1;
                                local v626 = UNNAMED_2819774896696[u48];

                                if v626 < 95 then
                                    if v626 < 47 then
                                        if v626 < 23 then
                                            if v626 >= 11 then
                                                if v626 >= 17 then
                                                    if v626 >= 20 then
                                                        if v626 < 21 then
                                                            u47[UNNAMED_2819774896600[u48]] = not u47[UNNAMED_2819774896648[u48]];
                                                        else
                                                            if v626 ~= 22 then
                                                                local v627 = u55;
                                                                local v628 = u56;

                                                                if v627 then
                                                                    for i in u58, v627 do
                                                                        local v629 = v627[i];

                                                                        if v629 then
                                                                            v629[5] = v629;
                                                                            v629[6] = u47[i];
                                                                            v629[4] = 6;
                                                                            v627[i] = nil;
                                                                        end;
                                                                    end;
                                                                end;

                                                                if v628 then
                                                                    for i, v in u58, v628 do
                                                                        local v630 = v[6];

                                                                        if v628 then
                                                                            local v631 = v628[i];

                                                                            if v631 then
                                                                                local v632 = u46(v630);
                                                                                u59(u47, i, i + v630 - 1, 1, v632);
                                                                                v631[5] = v632;
                                                                                v631[4] = 1;
                                                                                v628[i] = nil;
                                                                            end;
                                                                        end;
                                                                    end;
                                                                end;

                                                                return true, true, UNNAMED_2819774896648[u48], u60(UNNAMED_2819774896072[u48], u47[UNNAMED_2819774896552[u48]]);
                                                            end;

                                                            v79 = u19[UNNAMED_2819774896552[u48]];
                                                            v79[5][v79[4]] = u47[UNNAMED_2819774896648[u48]];
                                                        end;
                                                    elseif v626 < 18 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] == UNNAMED_2819774896600[u48];
                                                    elseif v626 == 19 then
                                                        u47[UNNAMED_2819774896552[u48]] = u61(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896120[u48]);
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] < u47[UNNAMED_2819774896552[u48]];
                                                    end;
                                                elseif v626 < 14 then
                                                    if v626 >= 12 then
                                                        if v626 == 13 then
                                                            u67[UNNAMED_2819774896264[u48]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896072[u48];
                                                        else
                                                            u48 = u47[UNNAMED_2819774896600[u48]];
                                                        end;
                                                    else
                                                        v79 = UNNAMED_2819774896648[u48];
                                                        v77 = u47[UNNAMED_2819774896552[u48]];
                                                        u47[v79 + 1] = v77;
                                                        u47[v79] = v77[UNNAMED_2819774896072[u48]];
                                                    end;
                                                elseif v626 < 15 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77, v75, v78 = u51();

                                                    if v77 then
                                                        u47[v79] = v75;
                                                        u47[v79 + 1] = v78;
                                                        u48 = UNNAMED_2819774896552[u48];
                                                    else
                                                        u48 = UNNAMED_2819774896600[u48];
                                                    end;
                                                elseif v626 == 16 then
                                                    v79 = UNNAMED_2819774896552[u48];
                                                    v77 = UNNAMED_2819774896648[u48];
                                                    v75 = UNNAMED_2819774896600[u48];
                                                    v78 = u61(u44, u64(u63(u44, 14), 262143), (u64(u63(u44, 28), 15)));
                                                    v76 = v77 < 2097152 and 7 or 14;
                                                    v80 = u64(v77, u65(1, v76) - 1);
                                                    local v633 = u63(v77, v76);
                                                    UNNAMED_2819774896648[u48] = u61(v80, 9, (u64(u63(v78, 7), 127)));
                                                    UNNAMED_2819774896600[u48] = u61(v75, 109, (u64(u63(v78, 14), 127)));
                                                    UNNAMED_2819774896552[u48] = u61(v79, 42, (u64(v78, 127)));
                                                    UNNAMED_2819774896696[u48] = u61(v633, 126, (u64(u63(v78, 21), 127)));
                                                    u48 = u48 - 1;
                                                else
                                                    v79 = UNNAMED_2819774896600[u48];
                                                    local v634 = UNNAMED_2819774896264[u48];
                                                    u47[v79] = UNNAMED_2819774896648[u48];
                                                    u47[v79 + 1] = v634;
                                                end;
                                            elseif v626 >= 5 then
                                                if v626 < 8 then
                                                    if v626 >= 6 then
                                                        if v626 == 7 then
                                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]] > UNNAMED_2819774896120[u48];
                                                        else
                                                            u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896264[u48], u47[UNNAMED_2819774896600[u48]]);
                                                        end;
                                                    else
                                                        u45 = u47[UNNAMED_2819774896600[u48]];
                                                    end;
                                                elseif v626 < 9 then
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]] / UNNAMED_2819774896648[u48];
                                                else
                                                    if v626 == 10 then
                                                        local v635 = u55;
                                                        local v636 = u56;

                                                        if v635 then
                                                            for i in u58, v635 do
                                                                local v637 = v635[i];

                                                                if v637 then
                                                                    v637[5] = v637;
                                                                    v637[6] = u47[i];
                                                                    v637[4] = 6;
                                                                    v635[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v636 then
                                                            for i, v in u58, v636 do
                                                                local v638 = v[6];

                                                                if v636 then
                                                                    local v639 = v636[i];

                                                                    if v639 then
                                                                        local v640 = u46(v638);
                                                                        u59(u47, i, i + v638 - 1, 1, v640);
                                                                        v639[5] = v640;
                                                                        v639[4] = 1;
                                                                        v636[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, false;
                                                    end;

                                                    if u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896552[u48] then
                                                        u48 = UNNAMED_2819774896600[u48];
                                                    end;
                                                end;
                                            elseif v626 >= 2 then
                                                if v626 < 3 then
                                                    v79 = UNNAMED_2819774896600[u48];
                                                    local v641 = UNNAMED_2819774896648[u48];
                                                    u47[v79] = u47[UNNAMED_2819774896552[u48]];
                                                    u47[v79 + 1] = v641;
                                                elseif v626 == 4 then
                                                    v79 = UNNAMED_2819774896600[u48];
                                                    local v642 = u47[UNNAMED_2819774896648[u48]];
                                                    u47[v79] = u47[UNNAMED_2819774896552[u48]];
                                                    u47[v79 + 1] = v642;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896600[u48]]];
                                                end;
                                            elseif v626 == 1 then
                                                v79 = u19[UNNAMED_2819774896552[u48]];
                                                v79[5][v79[4]] = UNNAMED_2819774896120[u48];
                                            else
                                                v79 = UNNAMED_2819774896648[u48];
                                                v77 = u47[UNNAMED_2819774896552[u48]];
                                                u47[v79 + 1] = v77;
                                                u47[v79] = v77[UNNAMED_2819774896072[u48]];
                                                u47[UNNAMED_2819774896648[u48 + 1]] = u47[UNNAMED_2819774896552[u48 + 1]];
                                                u47[UNNAMED_2819774896648[u48 + 2]] = UNNAMED_2819774896072[u48 + 2];
                                                u47[UNNAMED_2819774896648[u48 + 3]] = u47[UNNAMED_2819774896552[u48 + 3]];
                                                u48 = u48 + 3;
                                            end;
                                        elseif v626 >= 35 then
                                            if v626 >= 41 then
                                                if v626 < 44 then
                                                    if v626 >= 42 then
                                                        if v626 == 43 then
                                                            v79 = UNNAMED_2819774896552[u48];
                                                            v77, v75 = u51();

                                                            if v77 then
                                                                u47[v79] = v75;
                                                                u48 = UNNAMED_2819774896600[u48];
                                                            else
                                                                u48 = UNNAMED_2819774896648[u48];
                                                            end;
                                                        else
                                                            u47[UNNAMED_2819774896600[u48]] = u68(u47[UNNAMED_2819774896648[u48]]);
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896648;
                                                    end;
                                                elseif v626 >= 45 then
                                                    if v626 == 46 then
                                                        u47[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896552[u48]]] = UNNAMED_2819774896072[u48];
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] - u47[UNNAMED_2819774896552[u48]];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u19[UNNAMED_2819774896600[u48]][UNNAMED_2819774896120[u48]];
                                                end;
                                            elseif v626 < 38 then
                                                if v626 < 36 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = UNNAMED_2819774896600[u48];
                                                    v75 = UNNAMED_2819774896552[u48];
                                                    v78 = v79 + v77;
                                                    v76 = u47[v78];
                                                    v80 = v76.n;
                                                    v76.n = v77 + v80 - 1;
                                                    u59(v76, 1, v80, v77, v76);
                                                    u59(u47, v79 + 1, v78 - 1, 1, v76);
                                                    u47[v79] = u60(u47[v79](u57(v76, 1, v76.n)));
                                                elseif v626 == 37 then
                                                    v79 = UNNAMED_2819774896600[u48];
                                                    v77 = UNNAMED_2819774896648[u48];
                                                    v75 = UNNAMED_2819774896552[u48];
                                                    v78 = u47[v79];
                                                    u59(u47, v79 + 1, v79 + v77, v75 + 1, v78);
                                                elseif u47[UNNAMED_2819774896552[u48]] ~= UNNAMED_2819774896600[u48] then
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            elseif v626 >= 39 then
                                                if v626 == 40 then
                                                    u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] .. u47[UNNAMED_2819774896648[u48]];
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] % u47[UNNAMED_2819774896552[u48]];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48] + u47[UNNAMED_2819774896600[u48]];
                                            end;
                                        elseif v626 < 29 then
                                            if v626 < 26 then
                                                if v626 >= 24 then
                                                    if v626 == 25 then
                                                        u67[UNNAMED_2819774896120[u48]][u47[UNNAMED_2819774896552[u48]]] = UNNAMED_2819774896072[u48];
                                                    else
                                                        u47[UNNAMED_2819774896600[u48]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896552[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] - UNNAMED_2819774896264[u48];
                                                end;
                                            elseif v626 < 27 then
                                                u47[UNNAMED_2819774896600[u48]] = u67[UNNAMED_2819774896264[u48]][u47[UNNAMED_2819774896648[u48]]];
                                            elseif v626 == 28 then
                                                if UNNAMED_2819774896648[u48] > u47[UNNAMED_2819774896552[u48]] then
                                                    u48 = UNNAMED_2819774896600[u48];
                                                end;
                                            else
                                                v79 = u19[UNNAMED_2819774896648[u48]];
                                                u47[UNNAMED_2819774896552[u48]] = v79[5][v79[4]][UNNAMED_2819774896072[u48]];
                                            end;
                                        elseif v626 >= 32 then
                                            if v626 < 33 then
                                                u51 = u51 + u53;

                                                if u53 <= 0 then
                                                    v79 = u52 <= u51;
                                                else
                                                    v79 = u51 <= u52;
                                                end;

                                                if v79 then
                                                    u47[UNNAMED_2819774896600[u48]] = u51;
                                                    u48 = UNNAMED_2819774896552[u48];
                                                else
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            elseif v626 == 34 then
                                                u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896072[u48];
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] / u47[UNNAMED_2819774896600[u48]];
                                            end;
                                        elseif v626 >= 30 then
                                            if v626 == 31 then
                                                local v643 = u55;
                                                local v644 = u56;

                                                if v643 then
                                                    for i in u58, v643 do
                                                        local v645 = v643[i];

                                                        if v645 then
                                                            v645[5] = v645;
                                                            v645[6] = u47[i];
                                                            v645[4] = 6;
                                                            v643[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v644 then
                                                    for i, v in u58, v644 do
                                                        local v646 = v[6];

                                                        if v644 then
                                                            local v647 = v644[i];

                                                            if v647 then
                                                                local v648 = u46(v646);
                                                                u59(u47, i, i + v646 - 1, 1, v648);
                                                                v647[5] = v648;
                                                                v647[4] = 1;
                                                                v644[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(u47[UNNAMED_2819774896600[u48]], u47[UNNAMED_2819774896552[u48]]);
                                            end;

                                            u47[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896600[u48]]] = u47[UNNAMED_2819774896552[u48]];
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u19[UNNAMED_2819774896552[u48]];
                                        end;
                                    elseif v626 >= 71 then
                                        if v626 >= 83 then
                                            if v626 < 89 then
                                                if v626 < 86 then
                                                    if v626 >= 84 then
                                                        if v626 == 85 then
                                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] + UNNAMED_2819774896072[u48];
                                                        else
                                                            v79 = UNNAMED_2819774896552[u48];
                                                            v77 = UNNAMED_2819774896600[u48];
                                                            v75 = UNNAMED_2819774896648[u48];
                                                            v78 = v79 + v75 - 1;
                                                            v76 = v79 + v77;
                                                            v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                                            u59(v80, 1, v75, v79, u47);
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]] > UNNAMED_2819774896648[u48];
                                                    end;
                                                elseif v626 < 87 then
                                                    u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896072[u48] .. u47[UNNAMED_2819774896648[u48]];
                                                elseif v626 == 88 then
                                                    if UNNAMED_2819774896072[u48] >= u47[UNNAMED_2819774896648[u48]] then
                                                        u48 = UNNAMED_2819774896552[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = {};
                                                end;
                                            elseif v626 < 92 then
                                                if v626 < 90 then
                                                    u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896216;
                                                elseif v626 == 91 then
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] + UNNAMED_2819774896552[u48];
                                                elseif u47[UNNAMED_2819774896552[u48]] > UNNAMED_2819774896072[u48] then
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            elseif v626 >= 93 then
                                                if v626 == 94 then
                                                    u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896600[u48] ^ u47[UNNAMED_2819774896648[u48]];
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u64(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896552[u48]);
                                                end;
                                            else
                                                local v649 = UNNAMED_2819774896600[u48];
                                                local v650 = u47[UNNAMED_2819774896648[u48]];
                                                local v651 = u64(UNNAMED_2819774896264[u48], 4294967295);
                                                local v652 = u64(v650, 4294967295);
                                                local v653 = u64(v651, 65535);
                                                local v654 = u63(v651, 16);
                                                local v655 = u64(v652, 65535);
                                                local v656 = u63(v652, 16);
                                                local v657 = u64(v653 * v655 + u65(u64(v653 * v656 + v654 * v655, 65535), 16), 4294967295) % 4294967296;
                                                u47[v649] = v657 ~= v657 and 0 or v657 - v657 % 1;
                                            end;
                                        elseif v626 >= 77 then
                                            if v626 < 80 then
                                                if v626 >= 78 then
                                                    if v626 == 79 then
                                                        if u55 then
                                                            local v658 = u55;
                                                            local v659 = UNNAMED_2819774896552[u48];
                                                            local v660 = v658[v659];

                                                            if v660 then
                                                                v660[5] = v660;
                                                                v660[6] = u47[v659];
                                                                v660[4] = 6;
                                                                v658[v659] = nil;
                                                            end;

                                                            local v661 = u55;
                                                            local v662 = UNNAMED_2819774896648[u48];
                                                            local v663 = v661[v662];

                                                            if v663 then
                                                                v663[5] = v663;
                                                                v663[6] = u47[v662];
                                                                v663[4] = 6;
                                                                v661[v662] = nil;
                                                            end;

                                                            local v664 = u55;
                                                            local v665 = UNNAMED_2819774896600[u48];
                                                            local v666 = v664[v665];

                                                            if v666 then
                                                                v666[5] = v666;
                                                                v666[6] = u47[v665];
                                                                v666[4] = 6;
                                                                v664[v665] = nil;
                                                            end;
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] % UNNAMED_2819774896072[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896264[u48] * UNNAMED_2819774896072[u48];
                                                end;
                                            elseif v626 < 81 then
                                                u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]]();
                                            else
                                                if v626 == 82 then
                                                    local v667 = u55;
                                                    local v668 = u56;

                                                    if v667 then
                                                        for i in u58, v667 do
                                                            local v669 = v667[i];

                                                            if v669 then
                                                                v669[5] = v669;
                                                                v669[6] = u47[i];
                                                                v669[4] = 6;
                                                                v667[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v668 then
                                                        for i, v in u58, v668 do
                                                            local v670 = v[6];

                                                            if v668 then
                                                                local v671 = v668[i];

                                                                if v671 then
                                                                    local v672 = u46(v670);
                                                                    u59(u47, i, i + v670 - 1, 1, v672);
                                                                    v671[5] = v672;
                                                                    v671[4] = 1;
                                                                    v668[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896648[u48], u60(UNNAMED_2819774896072[u48]);
                                                end;

                                                v79 = UNNAMED_2819774896648[u48];
                                                local v673 = UNNAMED_2819774896072[u48];
                                                u47[v79] = UNNAMED_2819774896264[u48];
                                                u47[v79 + 1] = v673;
                                            end;
                                        elseif v626 < 74 then
                                            if v626 < 72 then
                                                u44 = u47[UNNAMED_2819774896552[u48]];
                                            elseif v626 == 73 then
                                                local v674 = UNNAMED_2819774896552[u48];
                                                local v675 = u61(UNNAMED_2819774896648[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));
                                                local v676 = UNNAMED_2819774896216[5];
                                                local v677 = u61(v676[v674], 109162203);
                                                v676[v674] = v677;
                                                local v678 = UNNAMED_2819774896216[4];
                                                local v679 = v677 + 1;
                                                local v680 = u71(v678, v679);
                                                local v681;

                                                if v680 < 128 then
                                                    v681 = v679 + 1;
                                                else
                                                    local v682 = u71(v678, v679 + 1);

                                                    if v682 < 128 then
                                                        v680 = v680 - 128 + v682 * 128;
                                                        v681 = v679 + 2;
                                                    else
                                                        local v683 = u71(v678, v679 + 2);

                                                        if v683 < 128 then
                                                            v680 = v680 - 128 + (v682 - 128) * 16384 + v683 * 128;
                                                            v681 = v679 + 3;
                                                        else
                                                            local v684 = u71(v678, v679 + 3);
                                                            v680 = (v680 - 128) * 16384 + (v682 - 128) * 128 + (v683 - 128) + v684 % 128 * 2097152 + (v684 - v684 % 128) * 2097152;
                                                            v681 = v679 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v685 = v675 * 16843009;
                                                local v686 = v681 + v680;
                                                local v687 = v686 - v680 % 4;

                                                for i = v681, v687 - 1, 4 do
                                                    u72(v678, i, (u61(u73(v678, i), v685)));
                                                    local _ = i;
                                                end;

                                                for i = v687, v686 - 1 do
                                                    u74(v678, i, (u61(u71(v678, i), v675)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896552[u48] = 163;
                                                UNNAMED_2819774896648[u48] = 35;
                                                UNNAMED_2819774896600[u48] = 219;
                                                UNNAMED_2819774896696[u48] = 190;
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = u65(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896552[u48]);
                                            end;
                                        else
                                            if v626 < 75 then
                                                local v688 = u55;
                                                local v689 = u56;

                                                if v688 then
                                                    for i in u58, v688 do
                                                        local v690 = v688[i];

                                                        if v690 then
                                                            v690[5] = v690;
                                                            v690[6] = u47[i];
                                                            v690[4] = 6;
                                                            v688[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v689 then
                                                    for i, v in u58, v689 do
                                                        local v691 = v[6];

                                                        if v689 then
                                                            local v692 = v689[i];

                                                            if v692 then
                                                                local v693 = u46(v691);
                                                                u59(u47, i, i + v691 - 1, 1, v693);
                                                                v692[5] = v693;
                                                                v692[4] = 1;
                                                                v689[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(u47[UNNAMED_2819774896552[u48]]);
                                            end;

                                            if v626 == 76 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]];
                                                u47[UNNAMED_2819774896648[u48 + 1]] = UNNAMED_2819774896072[u48 + 1];
                                                u47[UNNAMED_2819774896648[u48 + 2]] = u47[UNNAMED_2819774896552[u48 + 2]];
                                                v79 = UNNAMED_2819774896552[u48 + 3];
                                                v77 = u47[v79];
                                                v75 = u47[v79 + 1];
                                                v78 = u47[v79 + 2];
                                                u47[v79] = v77(v75, v78);
                                                u48 = u48 + 3;
                                            else
                                                u67[UNNAMED_2819774896072[u48]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        end;
                                    elseif v626 < 59 then
                                        if v626 < 53 then
                                            if v626 < 50 then
                                                if v626 >= 48 then
                                                    if v626 == 49 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] // UNNAMED_2819774896552[u48];
                                                    else
                                                        v79 = u19[UNNAMED_2819774896648[u48]];
                                                        u47[UNNAMED_2819774896600[u48]] = v79[5][v79[4]];
                                                    end;
                                                else
                                                    u48 = u47[UNNAMED_2819774896648[u48]];
                                                end;
                                            elseif v626 >= 51 then
                                                if v626 ~= 52 then
                                                    local v694 = u55;
                                                    local v695 = u56;

                                                    if v694 then
                                                        for i in u58, v694 do
                                                            local v696 = v694[i];

                                                            if v696 then
                                                                v696[5] = v696;
                                                                v696[6] = u47[i];
                                                                v696[4] = 6;
                                                                v694[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v695 then
                                                        for i, v in u58, v695 do
                                                            local v697 = v[6];

                                                            if v695 then
                                                                local v698 = v695[i];

                                                                if v698 then
                                                                    local v699 = u46(v697);
                                                                    u59(u47, i, i + v697 - 1, 1, v699);
                                                                    v698[5] = v699;
                                                                    v698[4] = 1;
                                                                    v695[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896648[u48], u60(u47[UNNAMED_2819774896552[u48]]);
                                                end;

                                                v79 = UNNAMED_2819774896600[u48] + 1;
                                                v77 = UNNAMED_2819774896552[u48];

                                                for i = 1, UNNAMED_2819774896648[u48] do
                                                    local v700 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                    local v701 = u61(v700, (u63(v700, 13)));
                                                    v77 = u64(u61(v701, (u65(v701, 14))), 536870911);
                                                    UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                    UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                    UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 14), 127)));
                                                    UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 21), 127)));
                                                    v79 = v79 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896696[u48] = 190;
                                            elseif UNNAMED_2819774896600[u48] >= u47[UNNAMED_2819774896648[u48]] then
                                                u48 = UNNAMED_2819774896552[u48];
                                            end;
                                        elseif v626 < 56 then
                                            if v626 < 54 then
                                                u67[UNNAMED_2819774896264[u48]][u47[UNNAMED_2819774896600[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                            elseif v626 == 55 then
                                                u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896552[u48] - u47[UNNAMED_2819774896600[u48]];
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896600;
                                            end;
                                        elseif v626 < 57 then
                                            if u47[UNNAMED_2819774896600[u48]] > u47[UNNAMED_2819774896648[u48]] then
                                                u48 = UNNAMED_2819774896552[u48];
                                            end;
                                        elseif v626 == 58 then
                                            u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896600[u48]]);
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]][UNNAMED_2819774896264[u48]];
                                        end;
                                    elseif v626 < 65 then
                                        if v626 < 62 then
                                            if v626 < 60 then
                                                u47[UNNAMED_2819774896648[u48]]();
                                            elseif v626 == 61 then
                                                local v702 = UNNAMED_2819774896648[u48];
                                                local v703 = u47[UNNAMED_2819774896552[u48]];
                                                u47[v702 + 1] = v703;
                                                u47[v702] = v703[UNNAMED_2819774896072[u48]];
                                                u47[UNNAMED_2819774896648[u48 + 1]] = u47[UNNAMED_2819774896552[u48 + 1]];
                                                u47[UNNAMED_2819774896648[u48 + 2]] = UNNAMED_2819774896072[u48 + 2];
                                                u47[UNNAMED_2819774896648[u48 + 3]] = u47[UNNAMED_2819774896552[u48 + 3]];
                                                v79 = UNNAMED_2819774896552[u48 + 4];
                                                v77 = u47[v79];
                                                v75 = u47[v79 + 1];
                                                v78 = u47[v79 + 2];
                                                u47[v79] = v77(v75, v78);
                                                u48 = u48 + 4;
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896552;
                                            end;
                                        else
                                            if v626 < 63 then
                                                local v704 = u55;
                                                local v705 = u56;

                                                if v704 then
                                                    for i in u58, v704 do
                                                        local v706 = v704[i];

                                                        if v706 then
                                                            v706[5] = v706;
                                                            v706[6] = u47[i];
                                                            v706[4] = 6;
                                                            v704[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v705 then
                                                    for i, v in u58, v705 do
                                                        local v707 = v[6];

                                                        if v705 then
                                                            local v708 = v705[i];

                                                            if v708 then
                                                                local v709 = u46(v707);
                                                                u59(u47, i, i + v707 - 1, 1, v709);
                                                                v708[5] = v709;
                                                                v708[4] = 1;
                                                                v705[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(u47[UNNAMED_2819774896648[u48]], u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n));
                                            end;

                                            if v626 == 64 then
                                                u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] ~= UNNAMED_2819774896600[u48];
                                            else
                                                u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896264[u48]);
                                            end;
                                        end;
                                    elseif v626 >= 68 then
                                        if v626 < 69 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] * UNNAMED_2819774896072[u48];
                                        elseif v626 == 70 then
                                            u47[UNNAMED_2819774896552[u48]] = u62(u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896600[u48]]);
                                        else
                                            u47[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896600[u48]]] = UNNAMED_2819774896552[u48];
                                        end;
                                    elseif v626 < 66 then
                                        u19[UNNAMED_2819774896552[u48]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896600[u48];
                                    elseif v626 == 67 then
                                        u47[UNNAMED_2819774896648[u48]] = u61(u47[UNNAMED_2819774896552[u48]], UNNAMED_2819774896600[u48]);
                                    else
                                        local v710 = UNNAMED_2819774896552[u48];
                                        local v711 = u47[UNNAMED_2819774896600[u48]];
                                        local v712 = u64(u47[UNNAMED_2819774896648[u48]], 4294967295);
                                        local v713 = u64(v711, 4294967295);
                                        local v714 = u64(v712, 65535);
                                        local v715 = u63(v712, 16);
                                        local v716 = u64(v713, 65535);
                                        local v717 = u63(v713, 16);
                                        local v718 = u64(v714 * v716 + u65(u64(v714 * v717 + v715 * v716, 65535), 16), 4294967295) % 4294967296;
                                        u47[v710] = v718 ~= v718 and 0 or v718 - v718 % 1;
                                    end;
                                elseif v626 < 143 then
                                    if v626 < 119 then
                                        if v626 >= 107 then
                                            if v626 >= 113 then
                                                if v626 < 116 then
                                                    if v626 < 114 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] // u47[UNNAMED_2819774896552[u48]];
                                                    elseif v626 == 115 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] ~= u47[UNNAMED_2819774896600[u48]];
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896072[u48];
                                                        u47[UNNAMED_2819774896648[u48 + 1]] = u47[UNNAMED_2819774896552[u48 + 1]];
                                                        v79 = UNNAMED_2819774896552[u48 + 2];
                                                        v77 = u47[v79];
                                                        v75 = u47[v79 + 1];
                                                        v78 = u47[v79 + 2];
                                                        u47[v79] = v77(v75, v78);
                                                        u48 = u48 + 2;
                                                    end;
                                                elseif v626 < 117 then
                                                    u19[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896552[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                                elseif v626 == 118 then
                                                    local v719;

                                                    if u47[UNNAMED_2819774896648[u48]] then
                                                        v719 = UNNAMED_2819774896552[u48];
                                                    else
                                                        v719 = UNNAMED_2819774896600[u48];
                                                    end;

                                                    u48 = v719;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u63(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896648[u48]);
                                                end;
                                            elseif v626 < 110 then
                                                if v626 >= 108 then
                                                    if v626 ~= 109 then
                                                        local v720 = u55;
                                                        local v721 = u56;

                                                        if v720 then
                                                            for i in u58, v720 do
                                                                local v722 = v720[i];

                                                                if v722 then
                                                                    v722[5] = v722;
                                                                    v722[6] = u47[i];
                                                                    v722[4] = 6;
                                                                    v720[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v721 then
                                                            for i, v in u58, v721 do
                                                                local v723 = v[6];

                                                                if v721 then
                                                                    local v724 = v721[i];

                                                                    if v724 then
                                                                        local v725 = u46(v723);
                                                                        u59(u47, i, i + v723 - 1, 1, v725);
                                                                        v724[5] = v725;
                                                                        v724[4] = 1;
                                                                        v721[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(UNNAMED_2819774896072[u48], UNNAMED_2819774896264[u48]);
                                                    end;

                                                    u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896696;
                                                else
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    local v726 = UNNAMED_2819774896600[u48];
                                                    u47[v79] = UNNAMED_2819774896552[u48];
                                                    u47[v79 + 1] = v726;
                                                end;
                                            elseif v626 >= 111 then
                                                if v626 == 112 then
                                                    u19[UNNAMED_2819774896552[u48]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896600[u48]];
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896264[u48]);
                                                end;
                                            elseif u55 then
                                                local v727 = u55;
                                                local v728 = UNNAMED_2819774896552[u48];
                                                local v729 = v727[v728];

                                                if v729 then
                                                    v729[5] = v729;
                                                    v729[6] = u47[v728];
                                                    v729[4] = 6;
                                                    v727[v728] = nil;
                                                end;

                                                local v730 = u55;
                                                local v731 = UNNAMED_2819774896600[u48];
                                                local v732 = v730[v731];

                                                if v732 then
                                                    v732[5] = v732;
                                                    v732[6] = u47[v731];
                                                    v732[4] = 6;
                                                    v730[v731] = nil;
                                                end;
                                            end;
                                        elseif v626 < 101 then
                                            if v626 < 98 then
                                                if v626 < 96 then
                                                    local v733 = u55;
                                                    local v734 = u56;

                                                    if v733 then
                                                        for i in u58, v733 do
                                                            local v735 = v733[i];

                                                            if v735 then
                                                                v735[5] = v735;
                                                                v735[6] = u47[i];
                                                                v735[4] = 6;
                                                                v733[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v734 then
                                                        for i, v in u58, v734 do
                                                            local v736 = v[6];

                                                            if v734 then
                                                                local v737 = v734[i];

                                                                if v737 then
                                                                    local v738 = u46(v736);
                                                                    u59(u47, i, i + v736 - 1, 1, v738);
                                                                    v737[5] = v738;
                                                                    v737[4] = 1;
                                                                    v734[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u60(UNNAMED_2819774896072[u48]);
                                                end;

                                                if v626 == 97 then
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]](u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n));
                                                else
                                                    u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896600[u48]]);
                                                end;
                                            elseif v626 < 99 then
                                                if u47[UNNAMED_2819774896648[u48]] ~= u47[UNNAMED_2819774896600[u48]] then
                                                    u48 = UNNAMED_2819774896552[u48];
                                                end;
                                            elseif v626 == 100 then
                                                u47[UNNAMED_2819774896648[u48]] = u67[UNNAMED_2819774896264[u48]];
                                            else
                                                local v739 = nil;
                                                local v740 = UNNAMED_2819774896648[u48];
                                                local v741 = UNNAMED_2819774896072[u48];
                                                local v742 = UNNAMED_2819774896264[u48];
                                                local v743 = u55;
                                                local v744 = u56;
                                                local v745 = v742[0];

                                                if v745 then
                                                    local v746 = #v745 / 3;

                                                    if v746 > 0 then
                                                        v739 = {};

                                                        for i = 1, v746 do
                                                            local v747 = (i - 1) * 3;
                                                            local v748 = v745[v747 + 2];
                                                            local v749 = v745[v747 + 1];
                                                            local v750;

                                                            if v748 == 2 then
                                                                v743 = v743 or {};
                                                                local v751 = v743[v749];

                                                                if not v751 then
                                                                    v751 = {
                                                                        [5] = u47,
                                                                        [4] = v749
                                                                    };
                                                                    v743[v749] = v751;
                                                                end;

                                                                v739[i] = v751;
                                                                v750 = i;
                                                            elseif v748 == 0 then
                                                                v739[i] = u47[v749];
                                                                v750 = i;
                                                            elseif v748 == 3 then
                                                                v739[i] = u19[v749];
                                                                v750 = i;
                                                            elseif v748 == 1 then
                                                                v744 = v744 or {};
                                                                local v752 = v744[v749];

                                                                if not v752 then
                                                                    v752 = {
                                                                        [5] = u47,
                                                                        [4] = v749,
                                                                        [6] = v745[v747 + 3]
                                                                    };
                                                                    v744[v749] = v752;
                                                                end;

                                                                v739[i] = v752;
                                                                v750 = i;
                                                            else
                                                                v750 = i;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                local v753 = v742[-2];
                                                v742[v753] = v739;
                                                local v754 = v741(u57(v742, 1, v742[-1]));
                                                v742[v753] = nil;
                                                u47[v740] = v754;
                                                u55 = v743;
                                                u56 = v744;
                                            end;
                                        elseif v626 < 104 then
                                            if v626 >= 102 then
                                                if v626 == 103 then
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896552[u48] * u47[UNNAMED_2819774896600[u48]];
                                                elseif u47[UNNAMED_2819774896648[u48]] ~= UNNAMED_2819774896264[u48] then
                                                    u48 = UNNAMED_2819774896600[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896552[u48]] = u60(u47[UNNAMED_2819774896600[u48]]());
                                            end;
                                        elseif v626 >= 105 then
                                            if v626 == 106 then
                                                v79 = u19[UNNAMED_2819774896552[u48]];
                                                v79[5][v79[4]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896120[u48];
                                            else
                                                u67[UNNAMED_2819774896264[u48]] = u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] == UNNAMED_2819774896072[u48];
                                        end;
                                    elseif v626 < 131 then
                                        if v626 < 125 then
                                            if v626 < 122 then
                                                if v626 >= 120 then
                                                    if v626 == 121 then
                                                        u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]] % UNNAMED_2819774896648[u48];
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] / UNNAMED_2819774896264[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] >= UNNAMED_2819774896552[u48];
                                                end;
                                            elseif v626 < 123 then
                                                u47[UNNAMED_2819774896648[u48]] = u61(u47[UNNAMED_2819774896600[u48]], u47[UNNAMED_2819774896552[u48]]);
                                            elseif v626 == 124 then
                                                v79 = UNNAMED_2819774896552[u48] + 1;
                                                v77 = u61(UNNAMED_2819774896648[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));

                                                for i = 1, UNNAMED_2819774896600[u48] do
                                                    local v755 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                    local v756 = u61(v755, (u63(v755, 13)));
                                                    v77 = u64(u61(v756, (u65(v756, 14))), 536870911);
                                                    UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                    UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                    UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 14), 127)));
                                                    UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 21), 127)));
                                                    v79 = v79 + 1;
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896696[u48] = 190;
                                            else
                                                u47[UNNAMED_2819774896552[u48]] = #u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        elseif v626 >= 128 then
                                            if v626 >= 129 then
                                                if v626 == 130 then
                                                    u50 = {
                                                        [6] = u54,
                                                        [5] = u52,
                                                        [9] = u50,
                                                        [8] = u51,
                                                        [7] = u53
                                                    };
                                                    v79 = UNNAMED_2819774896552[u48];
                                                    v77 = u69(u70);
                                                    v77(UNNAMED_2819774896360, u47[v79], u47[v79 + 1], u47[v79 + 2]);
                                                    u51 = v77;
                                                    u54 = UNNAMED_2819774896648[u48];
                                                    u48 = UNNAMED_2819774896600[u48];
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] <= UNNAMED_2819774896552[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896552[u48]], u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                                            end;
                                        elseif v626 >= 126 then
                                            if v626 == 127 then
                                                u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896072[u48]] = u47[UNNAMED_2819774896552[u48]];
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] * u47[UNNAMED_2819774896552[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]];
                                        end;
                                    elseif v626 >= 137 then
                                        if v626 < 140 then
                                            if v626 < 138 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] - UNNAMED_2819774896600[u48];
                                            elseif v626 == 139 then
                                                v79 = UNNAMED_2819774896648[u48];
                                                v77 = UNNAMED_2819774896552[u48];
                                                v75 = UNNAMED_2819774896600[u48];
                                                v78 = v79 + v75 - 1;
                                                v76 = v79 + v77;
                                                v80 = u47[v76];
                                                local n = v80.n;
                                                v80.n = v77 + n - 1;
                                                u59(v80, 1, n, v77, v80);
                                                u59(u47, v79 + 1, v76 - 1, 1, v80);
                                                u59(u60(u47[v79](u57(v80, 1, v80.n))), 1, v75, v79, u47);
                                            else
                                                u47[UNNAMED_2819774896552[u48]] = -u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        elseif v626 < 141 then
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896600[u48]](u47[UNNAMED_2819774896648[u48]]);
                                        else
                                            if v626 == 142 then
                                                local v757 = u55;
                                                local v758 = u56;

                                                if v757 then
                                                    for i in u58, v757 do
                                                        local v759 = v757[i];

                                                        if v759 then
                                                            v759[5] = v759;
                                                            v759[6] = u47[i];
                                                            v759[4] = 6;
                                                            v757[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v758 then
                                                    for i, v in u58, v758 do
                                                        local v760 = v[6];

                                                        if v758 then
                                                            local v761 = v758[i];

                                                            if v761 then
                                                                local v762 = u46(v760);
                                                                u59(u47, i, i + v760 - 1, 1, v762);
                                                                v761[5] = v762;
                                                                v761[4] = 1;
                                                                v758[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896264[u48]);
                                            end;

                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896264[u48];
                                        end;
                                    elseif v626 >= 134 then
                                        if v626 < 135 then
                                            local v763 = u55;
                                            local v764 = u56;

                                            if v763 then
                                                for i in u58, v763 do
                                                    local v765 = v763[i];

                                                    if v765 then
                                                        v765[5] = v765;
                                                        v765[6] = u47[i];
                                                        v765[4] = 6;
                                                        v763[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v764 then
                                                for i, v in u58, v764 do
                                                    local v766 = v[6];

                                                    if v764 then
                                                        local v767 = v764[i];

                                                        if v767 then
                                                            local v768 = u46(v766);
                                                            u59(u47, i, i + v766 - 1, 1, v768);
                                                            v767[5] = v768;
                                                            v767[4] = 1;
                                                            v764[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u60(UNNAMED_2819774896120[u48], u47[UNNAMED_2819774896552[u48]]);
                                        end;

                                        if v626 == 136 then
                                            u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896600[u48]];
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u19[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896552[u48]]];
                                        end;
                                    elseif v626 >= 132 then
                                        if v626 == 133 then
                                            u47[UNNAMED_2819774896552[u48]](UNNAMED_2819774896072[u48], u57(u47[UNNAMED_2819774896648[u48]], 1, u47[UNNAMED_2819774896648[u48]].n));
                                        else
                                            local v769;

                                            if u47[UNNAMED_2819774896600[u48]] then
                                                v769 = UNNAMED_2819774896648[u48];
                                            else
                                                v769 = UNNAMED_2819774896552[u48];
                                            end;

                                            u48 = v769;
                                        end;
                                    else
                                        u47[UNNAMED_2819774896600[u48]] = u45;
                                    end;
                                elseif v626 >= 167 then
                                    if v626 >= 179 then
                                        if v626 >= 185 then
                                            if v626 >= 188 then
                                                if v626 < 189 then
                                                    u47[UNNAMED_2819774896600[u48]] = u44;
                                                elseif v626 ~= 190 then
                                                    v79 = UNNAMED_2819774896552[u48] + 1;
                                                    v77 = u61(UNNAMED_2819774896648[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));

                                                    for i = 1, UNNAMED_2819774896600[u48] do
                                                        local v770 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                        local v771 = u61(v770, (u63(v770, 13)));
                                                        v77 = u64(u61(v771, (u65(v771, 14))), 536870911);
                                                        UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 0), 127)));
                                                        UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 7), 127)));
                                                        UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 14), 127)));
                                                        UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 21), 127)));
                                                        v79 = v79 + 1;
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819774896696[u48] = 190;
                                                end;
                                            elseif v626 < 186 then
                                                u19[UNNAMED_2819774896600[u48]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896264[u48];
                                            elseif v626 == 187 then
                                                local v772 = UNNAMED_2819774896552[u48];
                                                local v773 = UNNAMED_2819774896120[u48];
                                                local v774 = u64(UNNAMED_2819774896072[u48], 4294967295);
                                                local v775 = u64(v773, 4294967295);
                                                local v776 = u64(v774, 65535);
                                                local v777 = u63(v774, 16);
                                                local v778 = u64(v775, 65535);
                                                local v779 = u63(v775, 16);
                                                local v780 = u64(v776 * v778 + u65(u64(v776 * v779 + v777 * v778, 65535), 16), 4294967295) % 4294967296;
                                                u47[v772] = v780 ~= v780 and 0 or v780 - v780 % 1;
                                            elseif u47[UNNAMED_2819774896552[u48]] > UNNAMED_2819774896600[u48] then
                                                u48 = UNNAMED_2819774896648[u48];
                                            end;
                                        elseif v626 < 182 then
                                            if v626 >= 180 then
                                                if v626 == 181 then
                                                    u47[UNNAMED_2819774896648[u48]] = u64(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896264[u48]);
                                                elseif UNNAMED_2819774896264[u48] > u47[UNNAMED_2819774896648[u48]] then
                                                    u48 = UNNAMED_2819774896600[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896552[u48]][UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]];
                                            end;
                                        elseif v626 < 183 then
                                            v79 = UNNAMED_2819774896552[u48];
                                            v77 = u47[v79];
                                            v75 = u47[v79 + 1];
                                            v78 = u47[v79 + 2];
                                            u47[v79] = v77(v75, v78);
                                        elseif v626 == 184 then
                                            u47[UNNAMED_2819774896600[u48]](u57(u47[UNNAMED_2819774896552[u48]], 1, u47[UNNAMED_2819774896552[u48]].n));
                                        else
                                            local v781 = UNNAMED_2819774896552[u48];
                                            local v782 = u61(UNNAMED_2819774896648[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));
                                            local v783 = UNNAMED_2819774896216[5];
                                            local v784 = u61(v783[v781], 109162203);
                                            v783[v781] = v784;
                                            local v785 = UNNAMED_2819774896216[4];
                                            local v786 = v784 + 1;
                                            local v787 = u71(v785, v786);
                                            local v788;

                                            if v787 < 128 then
                                                v788 = v786 + 1;
                                            else
                                                local v789 = u71(v785, v786 + 1);

                                                if v789 < 128 then
                                                    v787 = v787 - 128 + v789 * 128;
                                                    v788 = v786 + 2;
                                                else
                                                    local v790 = u71(v785, v786 + 2);

                                                    if v790 < 128 then
                                                        v787 = v787 - 128 + (v789 - 128) * 16384 + v790 * 128;
                                                        v788 = v786 + 3;
                                                    else
                                                        local v791 = u71(v785, v786 + 3);
                                                        v787 = (v787 - 128) * 16384 + (v789 - 128) * 128 + (v790 - 128) + v791 % 128 * 2097152 + (v791 - v791 % 128) * 2097152;
                                                        v788 = v786 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v792 = v782 * 16843009;
                                            local v793 = v788 + v787;
                                            local v794 = v793 - v787 % 4;

                                            for i = v788, v794 - 1, 4 do
                                                u72(v785, i, (u61(u73(v785, i), v792)));
                                                local _ = i;
                                            end;

                                            for i = v794, v793 - 1 do
                                                u74(v785, i, (u61(u71(v785, i), v782)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819774896552[u48] = 133;
                                            UNNAMED_2819774896648[u48] = 151;
                                            UNNAMED_2819774896600[u48] = 44;
                                            UNNAMED_2819774896696[u48] = 190;
                                        end;
                                    elseif v626 >= 173 then
                                        if v626 >= 176 then
                                            if v626 >= 177 then
                                                if v626 == 178 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = UNNAMED_2819774896552[u48];
                                                    v75 = UNNAMED_2819774896600[u48];
                                                    v78 = u61(u44, u64(u63(u44, 14), 262143), (u64(u63(u44, 28), 15)));
                                                    v76 = v77 < 16384 and 7 or (v77 < 2097152 and 14 or 21);
                                                    v80 = u63(v77, v76);
                                                    local v795 = u64(v77, u65(1, v76) - 1);
                                                    UNNAMED_2819774896600[u48] = u61(v75, 120, (u64(u63(v78, 14), 127)));
                                                    UNNAMED_2819774896552[u48] = u61(v795, 92, (u64(v78, 127)));
                                                    UNNAMED_2819774896696[u48] = u61(v80, 2, (u64(u63(v78, 21), 127)));
                                                    UNNAMED_2819774896648[u48] = u61(v79, 109, (u64(u63(v78, 7), 127)));
                                                    u48 = u48 - 1;
                                                else
                                                    u47[UNNAMED_2819774896552[u48]] = u67[UNNAMED_2819774896120[u48]][UNNAMED_2819774896072[u48]];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u62(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896264[u48]);
                                            end;
                                        elseif v626 >= 174 then
                                            if v626 == 175 then
                                                v79 = UNNAMED_2819774896648[u48];
                                                v77 = UNNAMED_2819774896600[u48];
                                                v75 = UNNAMED_2819774896552[u48];
                                                v78 = v79 + v77;
                                                u47[v79] = u60(u47[v79](u57(u47, v79 + 1, v78)));
                                            else
                                                u47[UNNAMED_2819774896552[u48]] = u47[UNNAMED_2819774896648[u48]] < UNNAMED_2819774896600[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896264[u48];
                                        end;
                                    elseif v626 < 170 then
                                        if v626 < 168 then
                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896552[u48]] > u47[UNNAMED_2819774896648[u48]];
                                        else
                                            if v626 == 169 then
                                                local v796 = u55;
                                                local v797 = u56;

                                                if v796 then
                                                    for i in u58, v796 do
                                                        local v798 = v796[i];

                                                        if v798 then
                                                            v798[5] = v798;
                                                            v798[6] = u47[i];
                                                            v798[4] = 6;
                                                            v796[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v797 then
                                                    for i, v in u58, v797 do
                                                        local v799 = v[6];

                                                        if v797 then
                                                            local v800 = v797[i];

                                                            if v800 then
                                                                local v801 = u46(v799);
                                                                u59(u47, i, i + v799 - 1, 1, v801);
                                                                v800[5] = v801;
                                                                v800[4] = 1;
                                                                v797[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819774896552[u48], u60();
                                            end;

                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] == u47[UNNAMED_2819774896600[u48]];
                                        end;
                                    elseif v626 >= 171 then
                                        if v626 == 172 then
                                            if u55 then
                                                local v802 = u55;
                                                local v803 = UNNAMED_2819774896600[u48];
                                                local v804 = v802[v803];

                                                if v804 then
                                                    v804[5] = v804;
                                                    v804[6] = u47[v803];
                                                    v804[4] = 6;
                                                    v802[v803] = nil;
                                                end;
                                            end;
                                        else
                                            v79 = u19[UNNAMED_2819774896648[u48]];
                                            v79[5][v79[4]][UNNAMED_2819774896264[u48]] = u47[UNNAMED_2819774896600[u48]];
                                        end;
                                    else
                                        local v805 = u47[UNNAMED_2819774896648[u48]] % 4294967296;
                                        u47[UNNAMED_2819774896552[u48]] = v805 ~= v805 and 0 or v805 - v805 % 1;
                                    end;
                                else
                                    if v626 < 155 then
                                        if v626 >= 149 then
                                            if v626 < 152 then
                                                if v626 < 150 then
                                                    v79 = UNNAMED_2819774896600[u48];
                                                    local v806 = u47[UNNAMED_2819774896648[u48]];
                                                    u47[v79] = UNNAMED_2819774896264[u48];
                                                    u47[v79 + 1] = v806;
                                                elseif v626 == 151 then
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] .. UNNAMED_2819774896264[u48];
                                                else
                                                    u50 = {
                                                        [6] = u54,
                                                        [5] = u52,
                                                        [9] = u50,
                                                        [8] = u51,
                                                        [7] = u53
                                                    };
                                                    v79 = UNNAMED_2819774896552[u48];
                                                    u53 = u47[v79 + 2] + 0;
                                                    u52 = u47[v79 + 1] + 0;
                                                    u51 = u47[v79] - u53;
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            elseif v626 >= 153 then
                                                if v626 == 154 then
                                                    local v807 = UNNAMED_2819774896552[u48];
                                                    local v808 = UNNAMED_2819774896648[u48];
                                                    local v809 = UNNAMED_2819774896216[5];
                                                    local v810 = u61(v809[v807], 109162203);
                                                    v809[v807] = v810;
                                                    local v811 = UNNAMED_2819774896216[4];
                                                    local v812 = v810 + 1;
                                                    local v813 = u71(v811, v812);
                                                    local v814;

                                                    if v813 < 128 then
                                                        v814 = v812 + 1;
                                                    else
                                                        local v815 = u71(v811, v812 + 1);

                                                        if v815 < 128 then
                                                            v813 = v813 - 128 + v815 * 128;
                                                            v814 = v812 + 2;
                                                        else
                                                            local v816 = u71(v811, v812 + 2);

                                                            if v816 < 128 then
                                                                v813 = v813 - 128 + (v815 - 128) * 16384 + v816 * 128;
                                                                v814 = v812 + 3;
                                                            else
                                                                local v817 = u71(v811, v812 + 3);
                                                                v813 = (v813 - 128) * 16384 + (v815 - 128) * 128 + (v816 - 128) + v817 % 128 * 2097152 + (v817 - v817 % 128) * 2097152;
                                                                v814 = v812 + 4;
                                                            end;
                                                        end;
                                                    end;

                                                    local v818 = v808 * 16843009;
                                                    local v819 = v814 + v813;
                                                    local v820 = v819 - v813 % 4;

                                                    for i = v814, v820 - 1, 4 do
                                                        u72(v811, i, (u61(u73(v811, i), v818)));
                                                        local _ = i;
                                                    end;

                                                    for i = v820, v819 - 1 do
                                                        u74(v811, i, (u61(u71(v811, i), v808)));
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819774896552[u48] = 212;
                                                    UNNAMED_2819774896648[u48] = 21;
                                                    UNNAMED_2819774896600[u48] = 154;
                                                    UNNAMED_2819774896696[u48] = 190;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] * UNNAMED_2819774896600[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896552[u48]](UNNAMED_2819774896072[u48]));
                                            end;
                                        elseif v626 >= 146 then
                                            if v626 < 147 then
                                                v79 = UNNAMED_2819774896648[u48];
                                                local v821 = u47[UNNAMED_2819774896552[u48]];
                                                u47[v79] = UNNAMED_2819774896600[u48];
                                                u47[v79 + 1] = v821;
                                            elseif v626 == 148 then
                                                u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896600[u48];
                                            else
                                                u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896072[u48] * u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        elseif v626 < 144 then
                                            if u47[UNNAMED_2819774896552[u48]] >= u47[UNNAMED_2819774896600[u48]] then
                                                u48 = UNNAMED_2819774896648[u48];
                                            end;
                                        elseif v626 == 145 then
                                            v79 = UNNAMED_2819774896648[u48];
                                            local v822 = UNNAMED_2819774896552[u48];
                                            u47[v79] = UNNAMED_2819774896072[u48];
                                            u47[v79 + 1] = v822;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u60(u47[UNNAMED_2819774896552[u48]](u47[UNNAMED_2819774896648[u48]]));
                                        end;

                                        v625 = 1;
                                        continue;
                                    end;

                                    if v626 < 161 then
                                        if v626 < 158 then
                                            if v626 >= 156 then
                                                if v626 == 157 then
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896552[u48]] + u47[UNNAMED_2819774896600[u48]];
                                                else
                                                    u48 = UNNAMED_2819774896600[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896552[u48]] = UNNAMED_2819774896600[u48] + u47[UNNAMED_2819774896648[u48]];
                                            end;

                                            v625 = 1;
                                            continue;
                                        end;

                                        if v626 >= 159 then
                                            if v626 == 160 then
                                                u47[UNNAMED_2819774896600[u48]] = u64(u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896552[u48]]);
                                            else
                                                local v823 = UNNAMED_2819774896648[u48];
                                                local v824 = UNNAMED_2819774896600[u48];
                                                local v825 = u64(u47[UNNAMED_2819774896552[u48]], 4294967295);
                                                local v826 = u64(v824, 4294967295);
                                                local v827 = u64(v825, 65535);
                                                local v828 = u63(v825, 16);
                                                local v829 = u64(v826, 65535);
                                                local v830 = u63(v826, 16);
                                                local v831 = u64(v827 * v829 + u65(u64(v827 * v830 + v828 * v829, 65535), 16), 4294967295) % 4294967296;
                                                u47[v823] = v831 ~= v831 and 0 or v831 - v831 % 1;
                                            end;

                                            v625 = 1;
                                            continue;
                                        end;

                                        u49 = UNNAMED_2819774896648[u48];
                                        u48 = UNNAMED_2819774896600[u48] + 1;
                                        v81 = 2;
                                        break;
                                    end;

                                    if v626 >= 164 then
                                        if v626 < 165 then
                                            local v832 = UNNAMED_2819774896648[u48];
                                            local v833 = v832 + UNNAMED_2819774896552[u48];
                                            local v834 = u55;
                                            local v835 = u56;

                                            if v834 then
                                                for i in u58, v834 do
                                                    local v836 = v834[i];

                                                    if v836 then
                                                        v836[5] = v836;
                                                        v836[6] = u47[i];
                                                        v836[4] = 6;
                                                        v834[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v835 then
                                                for i, v in u58, v835 do
                                                    local v837 = v[6];

                                                    if v835 then
                                                        local v838 = v835[i];

                                                        if v838 then
                                                            local v839 = u46(v837);
                                                            u59(u47, i, i + v837 - 1, 1, v839);
                                                            v838[5] = v839;
                                                            v838[4] = 1;
                                                            v835[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, false, v832, v833;
                                        end;

                                        if v626 == 166 then
                                            u47[UNNAMED_2819774896600[u48]](u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896264[u48]);
                                        else
                                            u51 = u50[8];
                                            u52 = u50[5];
                                            u53 = u50[7];
                                            u54 = u50[6];
                                            u50 = u50[9];
                                        end;
                                    elseif v626 >= 162 then
                                        if v626 == 163 then
                                            v79 = UNNAMED_2819774896600[u48];
                                            v77 = UNNAMED_2819774896648[u48];
                                            v75 = UNNAMED_2819774896552[u48];
                                            v78 = u47[v79];
                                            v76 = v79 + v77;
                                            v80 = u47[v76];
                                            u59(u47, v79 + 1, v76 - 1, v75 + 1, v78);
                                            u59(v80, 1, v80.n, v75 + v77, v78);
                                        elseif u47[UNNAMED_2819774896600[u48]] >= UNNAMED_2819774896264[u48] then
                                            u48 = UNNAMED_2819774896648[u48];
                                        end;
                                    else
                                        u47[UNNAMED_2819774896552[u48]] = u47;
                                    end;
                                end;

                                v625 = 1;
                                continue;
                            elseif v625 == 1 then
                                v625 = -1;
                                u48 = u48 + 1;
                                break;
                            else
                                break;
                            end;
                        end;

                        if v81 ~= -1 then
                            break;
                        end;
                    end;

                    if v81 ~= -1 then
                        continue;
                    end;

                    v81 = 6;
                    continue;
                elseif v81 == 6 then
                    v81 = -1;

                    while true do
                        local u48;
                        local v840 = 0;

                        while true do
                            if v840 == 0 then
                                v840 = -1;
                                local v841 = UNNAMED_2819774896552[u48];

                                if v841 >= 96 then
                                    if v841 >= 144 then
                                        if v841 >= 168 then
                                            if v841 >= 180 then
                                                if v841 < 186 then
                                                    if v841 < 183 then
                                                        if v841 >= 181 then
                                                            if v841 == 182 then
                                                                v79 = u47[UNNAMED_2819774896696[u48]];
                                                                u47[UNNAMED_2819774896600[u48]] = u60(u57(v79, UNNAMED_2819774896648[u48], v79.n));
                                                            else
                                                                local v842 = UNNAMED_2819774896600[u48];
                                                                local v843 = UNNAMED_2819774896696[u48];
                                                                local v844, v845 = u47[UNNAMED_2819774896648[u48]]();
                                                                u47[v842] = v844;
                                                                u47[v843] = v845;
                                                            end;
                                                        else
                                                            v79 = UNNAMED_2819774896696[u48];
                                                            v77, v75 = u51();

                                                            if v77 then
                                                                u47[v79] = v75;
                                                                u48 = UNNAMED_2819774896648[u48];
                                                            else
                                                                u48 = UNNAMED_2819774896600[u48];
                                                            end;
                                                        end;
                                                    elseif v841 < 184 then
                                                        u47[UNNAMED_2819774896696[u48]] = u68(u47[UNNAMED_2819774896648[u48]]);
                                                    elseif v841 == 185 then
                                                        u47[UNNAMED_2819774896600[u48]] = u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896168[u48]];
                                                    elseif u47[UNNAMED_2819774896648[u48]] ~= UNNAMED_2819774896072[u48] then
                                                        u48 = UNNAMED_2819774896696[u48];
                                                    end;
                                                elseif v841 >= 189 then
                                                    if v841 >= 190 then
                                                        if v841 == 191 then
                                                            u44 = u47[UNNAMED_2819774896696[u48]];
                                                        else
                                                            local v846;

                                                            if u47[UNNAMED_2819774896600[u48]] then
                                                                v846 = UNNAMED_2819774896696[u48];
                                                            else
                                                                v846 = UNNAMED_2819774896648[u48];
                                                            end;

                                                            u48 = v846;
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896120[u48];
                                                    end;
                                                elseif v841 >= 187 then
                                                    if v841 == 188 then
                                                        u67[UNNAMED_2819774896168[u48]] = UNNAMED_2819774896072[u48];
                                                    else
                                                        u19[UNNAMED_2819774896648[u48]][UNNAMED_2819774896168[u48]] = UNNAMED_2819774896072[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]](u47[UNNAMED_2819774896648[u48]]);
                                                end;
                                            elseif v841 < 174 then
                                                if v841 >= 171 then
                                                    if v841 >= 172 then
                                                        if v841 == 173 then
                                                            u47[UNNAMED_2819774896600[u48]] = u67[UNNAMED_2819774896120[u48]][UNNAMED_2819774896168[u48]];
                                                        else
                                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] - u47[UNNAMED_2819774896600[u48]];
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] % UNNAMED_2819774896648[u48];
                                                    end;
                                                elseif v841 >= 169 then
                                                    if v841 == 170 then
                                                        u47[UNNAMED_2819774896600[u48]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896696[u48]];
                                                    else
                                                        u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896600[u48]] // UNNAMED_2819774896648[u48];
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896072[u48] * u47[UNNAMED_2819774896696[u48]];
                                                end;
                                            elseif v841 >= 177 then
                                                if v841 < 178 then
                                                    u19[UNNAMED_2819774896648[u48]][u47[UNNAMED_2819774896600[u48]]] = UNNAMED_2819774896168[u48];
                                                else
                                                    if v841 == 179 then
                                                        local v847 = u55;
                                                        local v848 = u56;

                                                        if v847 then
                                                            for i in u58, v847 do
                                                                local v849 = v847[i];

                                                                if v849 then
                                                                    v849[5] = v849;
                                                                    v849[6] = u47[i];
                                                                    v849[4] = 6;
                                                                    v847[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v848 then
                                                            for i, v in u58, v848 do
                                                                local v850 = v[6];

                                                                if v848 then
                                                                    local v851 = v848[i];

                                                                    if v851 then
                                                                        local v852 = u46(v850);
                                                                        u59(u47, i, i + v850 - 1, 1, v852);
                                                                        v851[5] = v852;
                                                                        v851[4] = 1;
                                                                        v848[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(UNNAMED_2819774896168[u48], u47[UNNAMED_2819774896600[u48]]);
                                                    end;

                                                    u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896648;
                                                end;
                                            elseif v841 < 175 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] * UNNAMED_2819774896600[u48];
                                            elseif v841 == 176 then
                                                u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896600[u48]]());
                                            elseif u47[UNNAMED_2819774896600[u48]] ~= u47[UNNAMED_2819774896648[u48]] then
                                                u48 = UNNAMED_2819774896696[u48];
                                            end;
                                        elseif v841 >= 156 then
                                            if v841 < 162 then
                                                if v841 < 159 then
                                                    if v841 >= 157 then
                                                        if v841 == 158 then
                                                            u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896168[u48] + u47[UNNAMED_2819774896600[u48]];
                                                        else
                                                            u67[UNNAMED_2819774896168[u48]][UNNAMED_2819774896072[u48]] = u47[UNNAMED_2819774896648[u48]];
                                                        end;
                                                    else
                                                        u47[UNNAMED_2819774896696[u48]] = u63(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896600[u48]);
                                                    end;
                                                elseif v841 >= 160 then
                                                    if v841 == 161 then
                                                        if u47[UNNAMED_2819774896648[u48]] > UNNAMED_2819774896072[u48] then
                                                            u48 = UNNAMED_2819774896696[u48];
                                                        end;
                                                    else
                                                        v79 = { ... };
                                                        v77 = UNNAMED_2819774896600[u48];
                                                        u59(v79, 1, UNNAMED_2819774896696[u48], v77, u47);
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] > UNNAMED_2819774896168[u48];
                                                end;
                                            elseif v841 < 165 then
                                                if v841 >= 163 then
                                                    if v841 == 164 then
                                                        u50 = {
                                                            [6] = u54,
                                                            [5] = u52,
                                                            [9] = u50,
                                                            [8] = u51,
                                                            [7] = u53
                                                        };
                                                        v79 = UNNAMED_2819774896600[u48];
                                                        v77 = u69(u70);
                                                        v77(UNNAMED_2819774896360, u47[v79], u47[v79 + 1], u47[v79 + 2]);
                                                        u51 = v77;
                                                        u54 = UNNAMED_2819774896696[u48];
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    else
                                                        u47[UNNAMED_2819774896696[u48]][u47[UNNAMED_2819774896600[u48]]] = UNNAMED_2819774896120[u48];
                                                    end;
                                                else
                                                    local v853 = UNNAMED_2819774896600[u48];
                                                    local v854 = UNNAMED_2819774896696[u48];
                                                    local v855 = UNNAMED_2819774896216[5];
                                                    local v856 = u61(v855[v853], 109162203);
                                                    v855[v853] = v856;
                                                    local v857 = UNNAMED_2819774896216[4];
                                                    local v858 = v856 + 1;
                                                    local v859 = u71(v857, v858);
                                                    local v860;

                                                    if v859 < 128 then
                                                        v860 = v858 + 1;
                                                    else
                                                        local v861 = u71(v857, v858 + 1);

                                                        if v861 < 128 then
                                                            v859 = v859 - 128 + v861 * 128;
                                                            v860 = v858 + 2;
                                                        else
                                                            local v862 = u71(v857, v858 + 2);

                                                            if v862 < 128 then
                                                                v859 = v859 - 128 + (v861 - 128) * 16384 + v862 * 128;
                                                                v860 = v858 + 3;
                                                            else
                                                                local v863 = u71(v857, v858 + 3);
                                                                v859 = (v859 - 128) * 16384 + (v861 - 128) * 128 + (v862 - 128) + v863 % 128 * 2097152 + (v863 - v863 % 128) * 2097152;
                                                                v860 = v858 + 4;
                                                            end;
                                                        end;
                                                    end;

                                                    local v864 = v854 * 16843009;
                                                    local v865 = v860 + v859;
                                                    local v866 = v865 - v859 % 4;

                                                    for i = v860, v866 - 1, 4 do
                                                        u72(v857, i, (u61(u73(v857, i), v864)));
                                                        local _ = i;
                                                    end;

                                                    for i = v866, v865 - 1 do
                                                        u74(v857, i, (u61(u71(v857, i), v854)));
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819774896600[u48] = 164;
                                                    UNNAMED_2819774896696[u48] = 52;
                                                    UNNAMED_2819774896648[u48] = 243;
                                                    UNNAMED_2819774896552[u48] = 86;
                                                end;
                                            else
                                                if v841 < 166 then
                                                    local v867 = u55;
                                                    local v868 = u56;

                                                    if v867 then
                                                        for i in u58, v867 do
                                                            local v869 = v867[i];

                                                            if v869 then
                                                                v869[5] = v869;
                                                                v869[6] = u47[i];
                                                                v869[4] = 6;
                                                                v867[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v868 then
                                                        for i, v in u58, v868 do
                                                            local v870 = v[6];

                                                            if v868 then
                                                                local v871 = v868[i];

                                                                if v871 then
                                                                    local v872 = u46(v870);
                                                                    u59(u47, i, i + v870 - 1, 1, v872);
                                                                    v871[5] = v872;
                                                                    v871[4] = 1;
                                                                    v868[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896600[u48], u60(u47[UNNAMED_2819774896696[u48]], u47[UNNAMED_2819774896648[u48]]);
                                                end;

                                                if v841 == 167 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = UNNAMED_2819774896696[u48];
                                                    v75 = UNNAMED_2819774896600[u48];
                                                    v78 = v79 + v77;
                                                    u47[v79] = u60(u47[v79](u57(u47, v79 + 1, v78)));
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] % UNNAMED_2819774896072[u48];
                                                end;
                                            end;
                                        elseif v841 < 150 then
                                            if v841 >= 147 then
                                                if v841 < 148 then
                                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]][UNNAMED_2819774896072[u48]];
                                                elseif v841 == 149 then
                                                    u47[UNNAMED_2819774896648[u48]] = u45;
                                                else
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]](u57(u47[UNNAMED_2819774896648[u48]], 1, u47[UNNAMED_2819774896648[u48]].n));
                                                end;
                                            elseif v841 < 145 then
                                                u50 = {
                                                    [6] = u54,
                                                    [5] = u52,
                                                    [9] = u50,
                                                    [8] = u51,
                                                    [7] = u53
                                                };
                                                v79 = UNNAMED_2819774896600[u48];
                                                u53 = u47[v79 + 2] + 0;
                                                u52 = u47[v79 + 1] + 0;
                                                u51 = u47[v79] - u53;
                                                u48 = UNNAMED_2819774896696[u48];
                                            elseif v841 == 146 then
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] < UNNAMED_2819774896648[u48];
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896600[u48]] + UNNAMED_2819774896120[u48];
                                            end;
                                        elseif v841 >= 153 then
                                            if v841 < 154 then
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] == UNNAMED_2819774896120[u48];
                                            elseif v841 == 155 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896696[u48]]];
                                            else
                                                u19[UNNAMED_2819774896696[u48]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896648[u48];
                                            end;
                                        elseif v841 < 151 then
                                            u19[UNNAMED_2819774896696[u48]][UNNAMED_2819774896120[u48]] = u47[UNNAMED_2819774896600[u48]];
                                        elseif v841 == 152 then
                                            v79 = UNNAMED_2819774896600[u48];
                                            local v873 = u47[UNNAMED_2819774896648[u48]];
                                            u47[v79] = UNNAMED_2819774896168[u48];
                                            u47[v79 + 1] = v873;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = u60(u47[UNNAMED_2819774896600[u48]](u47[UNNAMED_2819774896696[u48]]));
                                        end;
                                    elseif v841 >= 120 then
                                        if v841 >= 132 then
                                            if v841 >= 138 then
                                                if v841 >= 141 then
                                                    if v841 < 142 then
                                                        local v874 = u55;
                                                        local v875 = u56;

                                                        if v874 then
                                                            for i in u58, v874 do
                                                                local v876 = v874[i];

                                                                if v876 then
                                                                    v876[5] = v876;
                                                                    v876[6] = u47[i];
                                                                    v876[4] = 6;
                                                                    v874[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v875 then
                                                            for i, v in u58, v875 do
                                                                local v877 = v[6];

                                                                if v875 then
                                                                    local v878 = v875[i];

                                                                    if v878 then
                                                                        local v879 = u46(v877);
                                                                        u59(u47, i, i + v877 - 1, 1, v879);
                                                                        v878[5] = v879;
                                                                        v878[4] = 1;
                                                                        v875[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return false, true, u60(u47[UNNAMED_2819774896696[u48]], u47[UNNAMED_2819774896648[u48]]);
                                                    end;

                                                    if v841 == 143 then
                                                        u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896696[u48]], u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                                                    else
                                                        u47[UNNAMED_2819774896600[u48]] = u64(u47[UNNAMED_2819774896696[u48]], u47[UNNAMED_2819774896648[u48]]);
                                                    end;
                                                elseif v841 < 139 then
                                                    u47[UNNAMED_2819774896648[u48]] = u44;
                                                elseif v841 == 140 then
                                                    u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] - UNNAMED_2819774896648[u48];
                                                else
                                                    v79 = u19[UNNAMED_2819774896696[u48]];
                                                    u47[UNNAMED_2819774896648[u48]] = v79[5][v79[4]];
                                                end;
                                            elseif v841 < 135 then
                                                if v841 >= 133 then
                                                    if v841 == 134 then
                                                        v79 = UNNAMED_2819774896696[u48];
                                                        v77 = UNNAMED_2819774896648[u48];
                                                        v75 = UNNAMED_2819774896600[u48];
                                                        v78 = v79 + v77;
                                                        v76 = u47[v78];
                                                        v80 = v76.n;
                                                        v76.n = v77 + v80 - 1;
                                                        u59(v76, 1, v80, v77, v76);
                                                        u59(u47, v79 + 1, v78 - 1, 1, v76);
                                                        u47[v79] = u60(u47[v79](u57(v76, 1, v76.n)));
                                                    else
                                                        local v880;

                                                        if u47[UNNAMED_2819774896600[u48]] then
                                                            v880 = UNNAMED_2819774896648[u48];
                                                        else
                                                            v880 = UNNAMED_2819774896696[u48];
                                                        end;

                                                        u48 = v880;
                                                    end;
                                                else
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896600[u48];
                                                end;
                                            elseif v841 >= 136 then
                                                if v841 == 137 then
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896696;
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]]();
                                                end;
                                            else
                                                v79 = UNNAMED_2819774896600[u48];
                                                local v881 = UNNAMED_2819774896696[u48];
                                                u47[v79] = u47[UNNAMED_2819774896648[u48]];
                                                u47[v79 + 1] = v881;
                                            end;
                                        elseif v841 >= 126 then
                                            if v841 < 129 then
                                                if v841 >= 127 then
                                                    if v841 == 128 then
                                                        u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]][UNNAMED_2819774896648[u48]];
                                                    else
                                                        local v882 = UNNAMED_2819774896648[u48];
                                                        local v883 = UNNAMED_2819774896696[u48];
                                                        local v884 = u64(u47[UNNAMED_2819774896600[u48]], 4294967295);
                                                        local v885 = u64(v883, 4294967295);
                                                        local v886 = u64(v884, 65535);
                                                        local v887 = u63(v884, 16);
                                                        local v888 = u64(v885, 65535);
                                                        local v889 = u63(v885, 16);
                                                        local v890 = u64(v886 * v888 + u65(u64(v886 * v889 + v887 * v888, 65535), 16), 4294967295) % 4294967296;
                                                        u47[v882] = v890 ~= v890 and 0 or v890 - v890 % 1;
                                                    end;
                                                else
                                                    v79 = u19[UNNAMED_2819774896600[u48]];
                                                    u47[UNNAMED_2819774896648[u48]] = v79[5][v79[4]][UNNAMED_2819774896168[u48]];
                                                end;
                                            elseif v841 < 130 then
                                                u47[UNNAMED_2819774896696[u48]] = u61(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896120[u48]);
                                            elseif v841 == 131 then
                                                local v891 = nil;
                                                local v892 = UNNAMED_2819774896696[u48];
                                                local v893 = UNNAMED_2819774896120[u48];
                                                local v894 = UNNAMED_2819774896072[u48];
                                                local v895 = u55;
                                                local v896 = u56;
                                                local v897 = v894[0];

                                                if v897 then
                                                    local v898 = #v897 / 3;

                                                    if v898 > 0 then
                                                        v891 = {};

                                                        for i = 1, v898 do
                                                            local v899 = (i - 1) * 3;
                                                            local v900 = v897[v899 + 2];
                                                            local v901 = v897[v899 + 1];
                                                            local v902;

                                                            if v900 == 2 then
                                                                v895 = v895 or {};
                                                                local v903 = v895[v901];

                                                                if not v903 then
                                                                    v903 = {
                                                                        [5] = u47,
                                                                        [4] = v901
                                                                    };
                                                                    v895[v901] = v903;
                                                                end;

                                                                v891[i] = v903;
                                                                v902 = i;
                                                            elseif v900 == 0 then
                                                                v891[i] = u47[v901];
                                                                v902 = i;
                                                            elseif v900 == 3 then
                                                                v891[i] = u19[v901];
                                                                v902 = i;
                                                            elseif v900 == 1 then
                                                                v896 = v896 or {};
                                                                local v904 = v896[v901];

                                                                if not v904 then
                                                                    v904 = {
                                                                        [5] = u47,
                                                                        [4] = v901,
                                                                        [6] = v897[v899 + 3]
                                                                    };
                                                                    v896[v901] = v904;
                                                                end;

                                                                v891[i] = v904;
                                                                v902 = i;
                                                            else
                                                                v902 = i;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                local v905 = v894[-2];
                                                v894[v905] = v891;
                                                local v906 = v893(u57(v894, 1, v894[-1]));
                                                v894[v905] = nil;
                                                u47[v892] = v906;
                                                u55 = v895;
                                                u56 = v896;
                                            else
                                                v79 = UNNAMED_2819774896648[u48];
                                                local v907 = UNNAMED_2819774896600[u48];
                                                u47[v79] = UNNAMED_2819774896168[u48];
                                                u47[v79 + 1] = v907;
                                            end;
                                        elseif v841 < 123 then
                                            if v841 < 121 then
                                                u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896696[u48] * u47[UNNAMED_2819774896600[u48]];
                                            elseif v841 == 122 then
                                                local v908 = u47[UNNAMED_2819774896600[u48]] % 4294967296;
                                                u47[UNNAMED_2819774896648[u48]] = v908 ~= v908 and 0 or v908 - v908 % 1;
                                            else
                                                v79 = UNNAMED_2819774896696[u48];
                                                v77, v75, v78 = u51();

                                                if v77 then
                                                    u47[v79] = v75;
                                                    u47[v79 + 1] = v78;
                                                    u48 = UNNAMED_2819774896648[u48];
                                                else
                                                    u48 = UNNAMED_2819774896600[u48];
                                                end;
                                            end;
                                        elseif v841 < 124 then
                                            u47[UNNAMED_2819774896696[u48]](u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896072[u48]);
                                        elseif v841 == 125 then
                                            local v909 = UNNAMED_2819774896648[u48];
                                            local v910 = UNNAMED_2819774896168[u48];
                                            local v911 = u64(UNNAMED_2819774896072[u48], 4294967295);
                                            local v912 = u64(v910, 4294967295);
                                            local v913 = u64(v911, 65535);
                                            local v914 = u63(v911, 16);
                                            local v915 = u64(v912, 65535);
                                            local v916 = u63(v912, 16);
                                            local v917 = u64(v913 * v915 + u65(u64(v913 * v916 + v914 * v915, 65535), 16), 4294967295) % 4294967296;
                                            u47[v909] = v917 ~= v917 and 0 or v917 - v917 % 1;
                                        else
                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896600[u48]] * UNNAMED_2819774896120[u48];
                                        end;
                                    elseif v841 >= 108 then
                                        if v841 >= 114 then
                                            if v841 < 117 then
                                                if v841 >= 115 then
                                                    if v841 == 116 then
                                                        v79 = u19[UNNAMED_2819774896600[u48]];
                                                        v79[5][v79[4]] = UNNAMED_2819774896168[u48];
                                                    else
                                                        u47[UNNAMED_2819774896600[u48]] = u60(u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896120[u48]));
                                                    end;
                                                else
                                                    u51 = u51 + u53;

                                                    if u53 <= 0 then
                                                        v79 = u52 <= u51;
                                                    else
                                                        v79 = u51 <= u52;
                                                    end;

                                                    if v79 then
                                                        u47[UNNAMED_2819774896696[u48]] = u51;
                                                        u48 = UNNAMED_2819774896648[u48];
                                                    else
                                                        u48 = UNNAMED_2819774896600[u48];
                                                    end;
                                                end;
                                            elseif v841 >= 118 then
                                                if v841 == 119 then
                                                    if u55 then
                                                        local v918 = u55;
                                                        local v919 = UNNAMED_2819774896600[u48];
                                                        local v920 = v918[v919];

                                                        if v920 then
                                                            v920[5] = v920;
                                                            v920[6] = u47[v919];
                                                            v920[4] = 6;
                                                            v918[v919] = nil;
                                                        end;
                                                    end;
                                                else
                                                    v79 = u19[UNNAMED_2819774896600[u48]];
                                                    v79[5][v79[4]][UNNAMED_2819774896120[u48]] = UNNAMED_2819774896168[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = u64(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896648[u48]);
                                            end;
                                        elseif v841 >= 111 then
                                            if v841 >= 112 then
                                                if v841 ~= 113 then
                                                    local v921 = u55;
                                                    local v922 = u56;

                                                    if v921 then
                                                        for i in u58, v921 do
                                                            local v923 = v921[i];

                                                            if v923 then
                                                                v923[5] = v923;
                                                                v923[6] = u47[i];
                                                                v923[4] = 6;
                                                                v921[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v922 then
                                                        for i, v in u58, v922 do
                                                            local v924 = v[6];

                                                            if v922 then
                                                                local v925 = v922[i];

                                                                if v925 then
                                                                    local v926 = u46(v924);
                                                                    u59(u47, i, i + v924 - 1, 1, v926);
                                                                    v925[5] = v926;
                                                                    v925[4] = 1;
                                                                    v922[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896600[u48], u60(u47[UNNAMED_2819774896696[u48]], u57(u47[UNNAMED_2819774896648[u48]], 1, u47[UNNAMED_2819774896648[u48]].n));
                                                end;

                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] - UNNAMED_2819774896072[u48];
                                            else
                                                v79 = UNNAMED_2819774896648[u48];
                                                local v927 = UNNAMED_2819774896696[u48];
                                                u47[v79] = UNNAMED_2819774896600[u48];
                                                u47[v79 + 1] = v927;
                                            end;
                                        elseif v841 < 109 then
                                            if u55 then
                                                local v928 = u55;
                                                local v929 = UNNAMED_2819774896600[u48];
                                                local v930 = v928[v929];

                                                if v930 then
                                                    v930[5] = v930;
                                                    v930[6] = u47[v929];
                                                    v930[4] = 6;
                                                    v928[v929] = nil;
                                                end;

                                                local v931 = u55;
                                                local v932 = UNNAMED_2819774896696[u48];
                                                local v933 = v931[v932];

                                                if v933 then
                                                    v933[5] = v933;
                                                    v933[6] = u47[v932];
                                                    v933[4] = 6;
                                                    v931[v932] = nil;
                                                end;
                                            end;
                                        elseif v841 == 110 then
                                            local v934 = UNNAMED_2819774896696[u48];
                                            local v935 = u61(UNNAMED_2819774896600[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));
                                            local v936 = UNNAMED_2819774896216[5];
                                            local v937 = u61(v936[v934], 109162203);
                                            v936[v934] = v937;
                                            local v938 = UNNAMED_2819774896216[4];
                                            local v939 = v937 + 1;
                                            local v940 = u71(v938, v939);
                                            local v941;

                                            if v940 < 128 then
                                                v941 = v939 + 1;
                                            else
                                                local v942 = u71(v938, v939 + 1);

                                                if v942 < 128 then
                                                    v940 = v940 - 128 + v942 * 128;
                                                    v941 = v939 + 2;
                                                else
                                                    local v943 = u71(v938, v939 + 2);

                                                    if v943 < 128 then
                                                        v940 = v940 - 128 + (v942 - 128) * 16384 + v943 * 128;
                                                        v941 = v939 + 3;
                                                    else
                                                        local v944 = u71(v938, v939 + 3);
                                                        v940 = (v940 - 128) * 16384 + (v942 - 128) * 128 + (v943 - 128) + v944 % 128 * 2097152 + (v944 - v944 % 128) * 2097152;
                                                        v941 = v939 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v945 = v935 * 16843009;
                                            local v946 = v941 + v940;
                                            local v947 = v946 - v940 % 4;

                                            for i = v941, v947 - 1, 4 do
                                                u72(v938, i, (u61(u73(v938, i), v945)));
                                                local _ = i;
                                            end;

                                            for i = v947, v946 - 1 do
                                                u74(v938, i, (u61(u71(v938, i), v935)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819774896696[u48] = 239;
                                            UNNAMED_2819774896600[u48] = 197;
                                            UNNAMED_2819774896648[u48] = 41;
                                            UNNAMED_2819774896552[u48] = 86;
                                        else
                                            v79 = UNNAMED_2819774896648[u48];
                                            v77 = UNNAMED_2819774896696[u48];
                                            v75 = UNNAMED_2819774896600[u48];
                                            v78 = v79 + v75 - 1;
                                            v76 = v79 + v77;
                                            v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                            u59(v80, 1, v75, v79, u47);
                                        end;
                                    elseif v841 < 102 then
                                        if v841 < 99 then
                                            if v841 >= 97 then
                                                if v841 == 98 then
                                                    local v948 = u55;
                                                    local v949 = u56;

                                                    if v948 then
                                                        for i in u58, v948 do
                                                            local v950 = v948[i];

                                                            if v950 then
                                                                v950[5] = v950;
                                                                v950[6] = u47[i];
                                                                v950[4] = 6;
                                                                v948[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v949 then
                                                        for i, v in u58, v949 do
                                                            local v951 = v[6];

                                                            if v949 then
                                                                local v952 = v949[i];

                                                                if v952 then
                                                                    local v953 = u46(v951);
                                                                    u59(u47, i, i + v951 - 1, 1, v953);
                                                                    v952[5] = v953;
                                                                    v952[4] = 1;
                                                                    v949[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896696[u48], u60(u47[UNNAMED_2819774896648[u48]]);
                                                end;

                                                u47[UNNAMED_2819774896696[u48]] = u67[UNNAMED_2819774896120[u48]];
                                            else
                                                v79 = UNNAMED_2819774896600[u48];
                                                local v954 = u47[UNNAMED_2819774896696[u48]];
                                                u47[v79] = u47[UNNAMED_2819774896648[u48]];
                                                u47[v79 + 1] = v954;
                                            end;
                                        elseif v841 >= 100 then
                                            if v841 == 101 then
                                                local v955 = UNNAMED_2819774896696[u48];
                                                local v956 = u61(UNNAMED_2819774896600[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));
                                                local v957 = UNNAMED_2819774896216[5];
                                                local v958 = u61(v957[v955], 109162203);
                                                v957[v955] = v958;
                                                local v959 = UNNAMED_2819774896216[4];
                                                local v960 = v958 + 1;
                                                local v961 = u71(v959, v960);
                                                local v962;

                                                if v961 < 128 then
                                                    v962 = v960 + 1;
                                                else
                                                    local v963 = u71(v959, v960 + 1);

                                                    if v963 < 128 then
                                                        v961 = v961 - 128 + v963 * 128;
                                                        v962 = v960 + 2;
                                                    else
                                                        local v964 = u71(v959, v960 + 2);

                                                        if v964 < 128 then
                                                            v961 = v961 - 128 + (v963 - 128) * 16384 + v964 * 128;
                                                            v962 = v960 + 3;
                                                        else
                                                            local v965 = u71(v959, v960 + 3);
                                                            v961 = (v961 - 128) * 16384 + (v963 - 128) * 128 + (v964 - 128) + v965 % 128 * 2097152 + (v965 - v965 % 128) * 2097152;
                                                            v962 = v960 + 4;
                                                        end;
                                                    end;
                                                end;

                                                local v966 = v956 * 16843009;
                                                local v967 = v962 + v961;
                                                local v968 = v967 - v961 % 4;

                                                for i = v962, v968 - 1, 4 do
                                                    u72(v959, i, (u61(u73(v959, i), v966)));
                                                    local _ = i;
                                                end;

                                                for i = v968, v967 - 1 do
                                                    u74(v959, i, (u61(u71(v959, i), v956)));
                                                    local _ = i;
                                                end;

                                                UNNAMED_2819774896696[u48] = 187;
                                                UNNAMED_2819774896600[u48] = 245;
                                                UNNAMED_2819774896648[u48] = 185;
                                                UNNAMED_2819774896552[u48] = 86;
                                            else
                                                u48 = u47[UNNAMED_2819774896600[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896072[u48], u57(u47[UNNAMED_2819774896696[u48]], 1, u47[UNNAMED_2819774896696[u48]].n));
                                        end;
                                    elseif v841 >= 105 then
                                        if v841 < 106 then
                                            local v969 = UNNAMED_2819774896648[u48];
                                            local v970 = v969 + UNNAMED_2819774896696[u48];
                                            local v971 = u55;
                                            local v972 = u56;

                                            if v971 then
                                                for i in u58, v971 do
                                                    local v973 = v971[i];

                                                    if v973 then
                                                        v973[5] = v973;
                                                        v973[6] = u47[i];
                                                        v973[4] = 6;
                                                        v971[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v972 then
                                                for i, v in u58, v972 do
                                                    local v974 = v[6];

                                                    if v972 then
                                                        local v975 = v972[i];

                                                        if v975 then
                                                            local v976 = u46(v974);
                                                            u59(u47, i, i + v974 - 1, 1, v976);
                                                            v975[5] = v976;
                                                            v975[4] = 1;
                                                            v972[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, false, v969, v970;
                                        end;

                                        if v841 == 107 then
                                            local v977 = u55;
                                            local v978 = u56;

                                            if v977 then
                                                for i in u58, v977 do
                                                    local v979 = v977[i];

                                                    if v979 then
                                                        v979[5] = v979;
                                                        v979[6] = u47[i];
                                                        v979[4] = 6;
                                                        v977[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v978 then
                                                for i, v in u58, v978 do
                                                    local v980 = v[6];

                                                    if v978 then
                                                        local v981 = v978[i];

                                                        if v981 then
                                                            local v982 = u46(v980);
                                                            u59(u47, i, i + v980 - 1, 1, v982);
                                                            v981[5] = v982;
                                                            v981[4] = 1;
                                                            v978[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return false, true, u60(UNNAMED_2819774896072[u48], UNNAMED_2819774896168[u48]);
                                        end;

                                        if u47[UNNAMED_2819774896648[u48]] >= UNNAMED_2819774896600[u48] then
                                            u48 = UNNAMED_2819774896696[u48];
                                        end;
                                    elseif v841 < 103 then
                                        if UNNAMED_2819774896600[u48] > u47[UNNAMED_2819774896648[u48]] then
                                            u48 = UNNAMED_2819774896696[u48];
                                        end;
                                    elseif v841 == 104 then
                                        u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] ~= UNNAMED_2819774896072[u48];
                                    else
                                        v79 = UNNAMED_2819774896600[u48];
                                        v77 = UNNAMED_2819774896648[u48];
                                        v75 = UNNAMED_2819774896696[u48];
                                        v78 = u47[v79];
                                        u59(u47, v79 + 1, v79 + v77, v75 + 1, v78);
                                    end;

                                    v840 = 1;
                                    continue;
                                end;

                                if v841 >= 48 then
                                    if v841 < 72 then
                                        if v841 < 60 then
                                            if v841 >= 54 then
                                                if v841 >= 57 then
                                                    if v841 < 58 then
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] + u47[UNNAMED_2819774896600[u48]];
                                                    elseif v841 == 59 then
                                                        u19[UNNAMED_2819774896696[u48]][u47[UNNAMED_2819774896648[u48]]] = u47[UNNAMED_2819774896600[u48]];
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] < UNNAMED_2819774896072[u48];
                                                    end;
                                                elseif v841 < 55 then
                                                    u45 = u47[UNNAMED_2819774896648[u48]];
                                                elseif v841 == 56 then
                                                    u47[UNNAMED_2819774896696[u48]] = u47;
                                                else
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] ~= u47[UNNAMED_2819774896600[u48]];
                                                end;
                                            elseif v841 >= 51 then
                                                if v841 < 52 then
                                                    v79 = UNNAMED_2819774896696[u48] + 1;
                                                    v77 = UNNAMED_2819774896600[u48];

                                                    for i = 1, UNNAMED_2819774896648[u48] do
                                                        local v983 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                        local v984 = u61(v983, (u63(v983, 13)));
                                                        v77 = u64(u61(v984, (u65(v984, 14))), 536870911);
                                                        UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 0), 127)));
                                                        UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 7), 127)));
                                                        UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 14), 127)));
                                                        UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 21), 127)));
                                                        v79 = v79 + 1;
                                                        local _ = i;
                                                    end;

                                                    UNNAMED_2819774896552[u48] = 86;
                                                elseif v841 == 53 then
                                                    u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896600[u48]] > u47[UNNAMED_2819774896648[u48]];
                                                elseif u47[UNNAMED_2819774896648[u48]] > UNNAMED_2819774896696[u48] then
                                                    u48 = UNNAMED_2819774896600[u48];
                                                end;
                                            else
                                                if v841 < 49 then
                                                    local v985 = u55;
                                                    local v986 = u56;

                                                    if v985 then
                                                        for i in u58, v985 do
                                                            local v987 = v985[i];

                                                            if v987 then
                                                                v987[5] = v987;
                                                                v987[6] = u47[i];
                                                                v987[4] = 6;
                                                                v985[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v986 then
                                                        for i, v in u58, v986 do
                                                            local v988 = v[6];

                                                            if v986 then
                                                                local v989 = v986[i];

                                                                if v989 then
                                                                    local v990 = u46(v988);
                                                                    u59(u47, i, i + v988 - 1, 1, v990);
                                                                    v989[5] = v990;
                                                                    v989[4] = 1;
                                                                    v986[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, false;
                                                end;

                                                if v841 ~= 50 then
                                                    local v991 = u55;
                                                    local v992 = u56;

                                                    if v991 then
                                                        for i in u58, v991 do
                                                            local v993 = v991[i];

                                                            if v993 then
                                                                v993[5] = v993;
                                                                v993[6] = u47[i];
                                                                v993[4] = 6;
                                                                v991[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v992 then
                                                        for i, v in u58, v992 do
                                                            local v994 = v[6];

                                                            if v992 then
                                                                local v995 = v992[i];

                                                                if v995 then
                                                                    local v996 = u46(v994);
                                                                    u59(u47, i, i + v994 - 1, 1, v996);
                                                                    v995[5] = v996;
                                                                    v995[4] = 1;
                                                                    v992[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return true, true, UNNAMED_2819774896600[u48], u60(UNNAMED_2819774896120[u48], u57(u47[UNNAMED_2819774896696[u48]], 1, u47[UNNAMED_2819774896696[u48]].n));
                                                end;

                                                v79 = u47[UNNAMED_2819774896696[u48]];
                                                v77 = UNNAMED_2819774896600[u48];
                                                v75 = UNNAMED_2819774896648[u48];
                                                u59(v79, 1, v75, v77, u47);
                                            end;
                                        elseif v841 >= 66 then
                                            if v841 >= 69 then
                                                if v841 >= 70 then
                                                    if v841 == 71 then
                                                        v79 = u19[UNNAMED_2819774896648[u48]];
                                                        v79[5][v79[4]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896696[u48];
                                                    else
                                                        u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896552;
                                                    end;
                                                else
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    v77 = UNNAMED_2819774896600[u48];
                                                    v75 = u61(u45, u64(u63(u45, 14), 262143), (u64(u63(u45, 28), 15)));
                                                    v78 = UNNAMED_2819774896696[u48];
                                                    v76 = v79 < 2097152 and 7 or 14;
                                                    v80 = u63(v79, v76);
                                                    local v997 = u64(v79, u65(1, v76) - 1);
                                                    UNNAMED_2819774896696[u48] = u61(v78, 66, (u64(v75, 127)));
                                                    UNNAMED_2819774896600[u48] = u61(v77, 83, (u64(u63(v75, 7), 127)));
                                                    UNNAMED_2819774896552[u48] = u61(v80, 60, (u64(u63(v75, 21), 127)));
                                                    UNNAMED_2819774896648[u48] = u61(v997, 7, (u64(u63(v75, 14), 127)));
                                                    u48 = u48 - 1;
                                                end;
                                            elseif v841 < 67 then
                                                u67[UNNAMED_2819774896072[u48]] = u47[UNNAMED_2819774896648[u48]];
                                            elseif v841 == 68 then
                                                if u55 then
                                                    local v998 = u55;
                                                    local v999 = UNNAMED_2819774896648[u48];
                                                    local v1000 = v998[v999];

                                                    if v1000 then
                                                        v1000[5] = v1000;
                                                        v1000[6] = u47[v999];
                                                        v1000[4] = 6;
                                                        v998[v999] = nil;
                                                    end;

                                                    local v1001 = u55;
                                                    local v1002 = UNNAMED_2819774896696[u48];
                                                    local v1003 = v1001[v1002];

                                                    if v1003 then
                                                        v1003[5] = v1003;
                                                        v1003[6] = u47[v1002];
                                                        v1003[4] = 6;
                                                        v1001[v1002] = nil;
                                                    end;

                                                    local v1004 = u55;
                                                    local v1005 = UNNAMED_2819774896600[u48];
                                                    local v1006 = v1004[v1005];

                                                    if v1006 then
                                                        v1006[5] = v1006;
                                                        v1006[6] = u47[v1005];
                                                        v1006[4] = 6;
                                                        v1004[v1005] = nil;
                                                    end;
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] // u47[UNNAMED_2819774896696[u48]];
                                            end;
                                        elseif v841 >= 63 then
                                            if v841 < 64 then
                                                u47[UNNAMED_2819774896696[u48]] = {};
                                            elseif v841 == 65 then
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] == u47[UNNAMED_2819774896696[u48]];
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896600[u48]](UNNAMED_2819774896120[u48]);
                                            end;
                                        elseif v841 < 61 then
                                            u47[UNNAMED_2819774896696[u48]] = u64(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896072[u48]);
                                        elseif v841 == 62 then
                                            if UNNAMED_2819774896648[u48] >= u47[UNNAMED_2819774896600[u48]] then
                                                u48 = UNNAMED_2819774896696[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896696[u48] ^ u47[UNNAMED_2819774896648[u48]];
                                        end;
                                    elseif v841 >= 84 then
                                        if v841 < 90 then
                                            if v841 < 87 then
                                                if v841 < 85 then
                                                    u47[UNNAMED_2819774896648[u48]] = #u47[UNNAMED_2819774896696[u48]];
                                                elseif v841 ~= 86 then
                                                    local v1007 = UNNAMED_2819774896696[u48];
                                                    local v1008 = u47[UNNAMED_2819774896600[u48]];
                                                    local v1009 = u64(UNNAMED_2819774896120[u48], 4294967295);
                                                    local v1010 = u64(v1008, 4294967295);
                                                    local v1011 = u64(v1009, 65535);
                                                    local v1012 = u63(v1009, 16);
                                                    local v1013 = u64(v1010, 65535);
                                                    local v1014 = u63(v1010, 16);
                                                    local v1015 = u64(v1011 * v1013 + u65(u64(v1011 * v1014 + v1012 * v1013, 65535), 16), 4294967295) % 4294967296;
                                                    u47[v1007] = v1015 ~= v1015 and 0 or v1015 - v1015 % 1;
                                                end;
                                            elseif v841 < 88 then
                                                u47[UNNAMED_2819774896600[u48]] = u65(u47[UNNAMED_2819774896696[u48]], UNNAMED_2819774896648[u48]);
                                            else
                                                if v841 == 89 then
                                                    local v1016 = u55;
                                                    local v1017 = u56;

                                                    if v1016 then
                                                        for i in u58, v1016 do
                                                            local v1018 = v1016[i];

                                                            if v1018 then
                                                                v1018[5] = v1018;
                                                                v1018[6] = u47[i];
                                                                v1018[4] = 6;
                                                                v1016[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v1017 then
                                                        for i, v in u58, v1017 do
                                                            local v1019 = v[6];

                                                            if v1017 then
                                                                local v1020 = v1017[i];

                                                                if v1020 then
                                                                    local v1021 = u46(v1019);
                                                                    u59(u47, i, i + v1019 - 1, 1, v1021);
                                                                    v1020[5] = v1021;
                                                                    v1020[4] = 1;
                                                                    v1017[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    local v1022 = UNNAMED_2819774896600[u48];

                                                    return false, false, v1022, v1022 + UNNAMED_2819774896648[u48] - 1;
                                                end;

                                                u47[UNNAMED_2819774896600[u48]][UNNAMED_2819774896168[u48]] = UNNAMED_2819774896648[u48];
                                            end;
                                        elseif v841 < 93 then
                                            if v841 >= 91 then
                                                if v841 == 92 then
                                                    local v1023 = u55;
                                                    local v1024 = u56;

                                                    if v1023 then
                                                        for i in u58, v1023 do
                                                            local v1025 = v1023[i];

                                                            if v1025 then
                                                                v1025[5] = v1025;
                                                                v1025[6] = u47[i];
                                                                v1025[4] = 6;
                                                                v1023[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v1024 then
                                                        for i, v in u58, v1024 do
                                                            local v1026 = v[6];

                                                            if v1024 then
                                                                local v1027 = v1024[i];

                                                                if v1027 then
                                                                    local v1028 = u46(v1026);
                                                                    u59(u47, i, i + v1026 - 1, 1, v1028);
                                                                    v1027[5] = v1028;
                                                                    v1027[4] = 1;
                                                                    v1024[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u60(u47[UNNAMED_2819774896600[u48]]);
                                                end;

                                                u47[UNNAMED_2819774896648[u48]](UNNAMED_2819774896072[u48]);
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u61(UNNAMED_2819774896072[u48], UNNAMED_2819774896168[u48]);
                                            end;
                                        else
                                            if v841 >= 94 then
                                                if v841 == 95 then
                                                    local v1029 = u55;
                                                    local v1030 = u56;

                                                    if v1029 then
                                                        for i in u58, v1029 do
                                                            local v1031 = v1029[i];

                                                            if v1031 then
                                                                v1031[5] = v1031;
                                                                v1031[6] = u47[i];
                                                                v1031[4] = 6;
                                                                v1029[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v1030 then
                                                        for i, v in u58, v1030 do
                                                            local v1032 = v[6];

                                                            if v1030 then
                                                                local v1033 = v1030[i];

                                                                if v1033 then
                                                                    local v1034 = u46(v1032);
                                                                    u59(u47, i, i + v1032 - 1, 1, v1034);
                                                                    v1033[5] = v1034;
                                                                    v1033[4] = 1;
                                                                    v1030[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    return false, true, u47[UNNAMED_2819774896648[u48]];
                                                end;

                                                local v1035 = u55;
                                                local v1036 = u56;

                                                if v1035 then
                                                    for i in u58, v1035 do
                                                        local v1037 = v1035[i];

                                                        if v1037 then
                                                            v1037[5] = v1037;
                                                            v1037[6] = u47[i];
                                                            v1037[4] = 6;
                                                            v1035[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v1036 then
                                                    for i, v in u58, v1036 do
                                                        local v1038 = v[6];

                                                        if v1036 then
                                                            local v1039 = v1036[i];

                                                            if v1039 then
                                                                local v1040 = u46(v1038);
                                                                u59(u47, i, i + v1038 - 1, 1, v1040);
                                                                v1039[5] = v1040;
                                                                v1039[4] = 1;
                                                                v1036[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return true, true, UNNAMED_2819774896600[u48], u47[UNNAMED_2819774896696[u48]];
                                            end;

                                            u47[UNNAMED_2819774896648[u48]] = u67[UNNAMED_2819774896168[u48]][u47[UNNAMED_2819774896600[u48]]];
                                        end;
                                    elseif v841 >= 78 then
                                        if v841 >= 81 then
                                            if v841 < 82 then
                                                u47[UNNAMED_2819774896648[u48]][UNNAMED_2819774896072[u48]] = UNNAMED_2819774896168[u48];
                                            elseif v841 == 83 then
                                                v79 = UNNAMED_2819774896648[u48];
                                                v77 = UNNAMED_2819774896696[u48];
                                                v75 = UNNAMED_2819774896600[u48];
                                                v78 = u47[v79];
                                                v76 = v79 + v77;
                                                v80 = u47[v76];
                                                u59(u47, v79 + 1, v76 - 1, v75 + 1, v78);
                                                u59(v80, 1, v80.n, v75 + v77, v78);
                                            else
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] .. UNNAMED_2819774896120[u48];
                                            end;
                                        elseif v841 >= 79 then
                                            if v841 == 80 then
                                                v79 = UNNAMED_2819774896648[u48];
                                                v77 = UNNAMED_2819774896600[u48];
                                                v75 = UNNAMED_2819774896696[u48];
                                                v78 = u61(u45, u64(u63(u45, 14), 262143), (u64(u63(u45, 28), 15)));
                                                v76 = v75 < 16384 and 7 or (v75 < 2097152 and 14 or 21);
                                                v80 = u63(v75, v76);
                                                UNNAMED_2819774896696[u48] = u61(u64(v75, u65(1, v76) - 1), 58, (u64(v78, 127)));
                                                UNNAMED_2819774896600[u48] = u61(v77, 44, (u64(u63(v78, 7), 127)));
                                                UNNAMED_2819774896648[u48] = u61(v79, 38, (u64(u63(v78, 14), 127)));
                                                UNNAMED_2819774896552[u48] = u61(v80, 20, (u64(u63(v78, 21), 127)));
                                                u48 = u48 - 1;
                                            else
                                                v79 = UNNAMED_2819774896600[u48];
                                                v77 = u47[UNNAMED_2819774896696[u48]];
                                                u47[v79 + 1] = v77;
                                                u47[v79] = v77[UNNAMED_2819774896120[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] % u47[UNNAMED_2819774896648[u48]];
                                        end;
                                    elseif v841 >= 75 then
                                        if v841 < 76 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] > UNNAMED_2819774896600[u48];
                                        elseif v841 == 77 then
                                            if u47[UNNAMED_2819774896696[u48]] >= u47[UNNAMED_2819774896648[u48]] then
                                                u48 = UNNAMED_2819774896600[u48];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896696[u48]]();
                                        end;
                                    elseif v841 >= 73 then
                                        if v841 == 74 then
                                            u67[UNNAMED_2819774896072[u48]][u47[UNNAMED_2819774896696[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                        else
                                            v79 = u19[UNNAMED_2819774896648[u48]];
                                            v79[5][v79[4]] = u47[UNNAMED_2819774896600[u48]];
                                        end;
                                    else
                                        u48 = UNNAMED_2819774896696[u48];
                                    end;

                                    v840 = 1;
                                    continue;
                                end;

                                if v841 < 24 then
                                    if v841 < 12 then
                                        if v841 < 6 then
                                            if v841 >= 3 then
                                                if v841 < 4 then
                                                    v79 = UNNAMED_2819774896648[u48];
                                                    local v1041 = UNNAMED_2819774896072[u48];
                                                    u47[v79] = UNNAMED_2819774896168[u48];
                                                    u47[v79 + 1] = v1041;
                                                else
                                                    if v841 ~= 5 then
                                                        local v1042 = u55;
                                                        local v1043 = u56;

                                                        if v1042 then
                                                            for i in u58, v1042 do
                                                                local v1044 = v1042[i];

                                                                if v1044 then
                                                                    v1044[5] = v1044;
                                                                    v1044[6] = u47[i];
                                                                    v1044[4] = 6;
                                                                    v1042[i] = nil;
                                                                end;
                                                            end;
                                                        end;

                                                        if v1043 then
                                                            for i, v in u58, v1043 do
                                                                local v1045 = v[6];

                                                                if v1043 then
                                                                    local v1046 = v1043[i];

                                                                    if v1046 then
                                                                        local v1047 = u46(v1045);
                                                                        u59(u47, i, i + v1045 - 1, 1, v1047);
                                                                        v1046[5] = v1047;
                                                                        v1046[4] = 1;
                                                                        v1043[i] = nil;
                                                                    end;
                                                                end;
                                                            end;
                                                        end;

                                                        return true, true, UNNAMED_2819774896600[u48], u60(u47[UNNAMED_2819774896648[u48]], UNNAMED_2819774896168[u48]);
                                                    end;

                                                    if UNNAMED_2819774896120[u48] >= u47[UNNAMED_2819774896600[u48]] then
                                                        u48 = UNNAMED_2819774896696[u48];
                                                    end;
                                                end;
                                            elseif v841 >= 1 then
                                                if v841 == 2 then
                                                    u47[UNNAMED_2819774896648[u48]] = UNNAMED_2819774896072[u48] .. u47[UNNAMED_2819774896696[u48]];
                                                elseif u47[UNNAMED_2819774896600[u48]] > u47[UNNAMED_2819774896696[u48]] then
                                                    u48 = UNNAMED_2819774896648[u48];
                                                end;
                                            else
                                                u47[UNNAMED_2819774896696[u48]] = u62(u47[UNNAMED_2819774896648[u48]], u47[UNNAMED_2819774896600[u48]]);
                                            end;
                                        elseif v841 < 9 then
                                            if v841 < 7 then
                                                local v1048 = u55;
                                                local v1049 = u56;

                                                if v1048 then
                                                    for i in u58, v1048 do
                                                        local v1050 = v1048[i];

                                                        if v1050 then
                                                            v1050[5] = v1050;
                                                            v1050[6] = u47[i];
                                                            v1050[4] = 6;
                                                            v1048[i] = nil;
                                                        end;
                                                    end;
                                                end;

                                                if v1049 then
                                                    for i, v in u58, v1049 do
                                                        local v1051 = v[6];

                                                        if v1049 then
                                                            local v1052 = v1049[i];

                                                            if v1052 then
                                                                local v1053 = u46(v1051);
                                                                u59(u47, i, i + v1051 - 1, 1, v1053);
                                                                v1052[5] = v1053;
                                                                v1052[4] = 1;
                                                                v1049[i] = nil;
                                                            end;
                                                        end;
                                                    end;
                                                end;

                                                return false, true, u60(UNNAMED_2819774896120[u48]);
                                            end;

                                            if v841 == 8 then
                                                u47[UNNAMED_2819774896648[u48]] = u61(u47[UNNAMED_2819774896600[u48]], u47[UNNAMED_2819774896696[u48]]);
                                            else
                                                u51 = u50[8];
                                                u52 = u50[5];
                                                u53 = u50[7];
                                                u54 = u50[6];
                                                u50 = u50[9];
                                            end;
                                        elseif v841 < 10 then
                                            if u47[UNNAMED_2819774896600[u48]] ~= UNNAMED_2819774896696[u48] then
                                                u48 = UNNAMED_2819774896648[u48];
                                            end;
                                        elseif v841 == 11 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] .. u47[UNNAMED_2819774896600[u48]];
                                        elseif UNNAMED_2819774896120[u48] > u47[UNNAMED_2819774896600[u48]] then
                                            u48 = UNNAMED_2819774896696[u48];
                                        end;
                                    elseif v841 >= 18 then
                                        if v841 < 21 then
                                            if v841 >= 19 then
                                                if v841 == 20 then
                                                    local v1054 = UNNAMED_2819774896648[u48];
                                                    local v1055 = UNNAMED_2819774896696[u48];
                                                    local v1056 = v1054 + v1055;
                                                    local v1057 = u47[v1056];
                                                    local n = v1057.n;
                                                    local v1058 = u55;
                                                    local v1059 = u56;

                                                    if v1058 then
                                                        for i in u58, v1058 do
                                                            local v1060 = v1058[i];

                                                            if v1060 then
                                                                v1060[5] = v1060;
                                                                v1060[6] = u47[i];
                                                                v1060[4] = 6;
                                                                v1058[i] = nil;
                                                            end;
                                                        end;
                                                    end;

                                                    if v1059 then
                                                        for i, v in u58, v1059 do
                                                            local v1061 = v[6];

                                                            if v1059 then
                                                                local v1062 = v1059[i];

                                                                if v1062 then
                                                                    local v1063 = u46(v1061);
                                                                    u59(u47, i, i + v1061 - 1, 1, v1063);
                                                                    v1062[5] = v1063;
                                                                    v1062[4] = 1;
                                                                    v1059[i] = nil;
                                                                end;
                                                            end;
                                                        end;
                                                    end;

                                                    v1057.n = v1055 + n - 1;
                                                    u59(v1057, 1, n, v1055, v1057);
                                                    u59(u47, v1054 + 1, v1056 - 1, 1, v1057);

                                                    return true, true, v1054, v1057;
                                                end;

                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896648[u48]] ~= UNNAMED_2819774896696[u48];
                                            else
                                                u48 = u47[UNNAMED_2819774896648[u48]];
                                            end;
                                        elseif v841 < 22 then
                                            u47[UNNAMED_2819774896648[u48]] = u19[UNNAMED_2819774896696[u48]];
                                        elseif v841 == 23 then
                                            u47[UNNAMED_2819774896696[u48]] = UNNAMED_2819774896216;
                                        else
                                            u47[UNNAMED_2819774896648[u48]] = not u47[UNNAMED_2819774896600[u48]];
                                        end;
                                    elseif v841 >= 15 then
                                        if v841 >= 16 then
                                            if v841 == 17 then
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]] == UNNAMED_2819774896648[u48];
                                            elseif u47[UNNAMED_2819774896696[u48]] >= UNNAMED_2819774896072[u48] then
                                                u48 = UNNAMED_2819774896648[u48];
                                            end;
                                        else
                                            v79 = UNNAMED_2819774896696[u48] + 1;
                                            v77 = u61(UNNAMED_2819774896600[u48], (u64(u61(u45, (u64(u63(u45, 29), 7))), 536870911)));

                                            for i = 1, UNNAMED_2819774896648[u48] do
                                                local v1064 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                                local v1065 = u61(v1064, (u63(v1064, 13)));
                                                v77 = u64(u61(v1065, (u65(v1065, 14))), 536870911);
                                                UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 0), 127)));
                                                UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 7), 127)));
                                                UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 14), 127)));
                                                UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 21), 127)));
                                                v79 = v79 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819774896552[u48] = 86;
                                        end;
                                    elseif v841 < 13 then
                                        u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]][1];
                                    elseif v841 == 14 then
                                        v79 = UNNAMED_2819774896696[u48];
                                        v77 = { ... };
                                        v75 = UNNAMED_2819774896648[u48];
                                        u59(v77, 1, v79 - 1, v75, u47);
                                        u47[v75 + v79 - 1] = u60(u66(v79, ...));
                                    else
                                        v79 = UNNAMED_2819774896696[u48];
                                        local v1066 = UNNAMED_2819774896072[u48];
                                        u47[v79] = UNNAMED_2819774896648[u48];
                                        u47[v79 + 1] = v1066;
                                    end;

                                    v840 = 1;
                                    continue;
                                end;

                                if v841 >= 36 then
                                    if v841 < 42 then
                                        if v841 < 39 then
                                            if v841 < 37 then
                                                u47[UNNAMED_2819774896600[u48]](u47[UNNAMED_2819774896648[u48]]);
                                            elseif v841 == 38 then
                                                u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]];
                                            else
                                                v79 = UNNAMED_2819774896696[u48];
                                                v77 = UNNAMED_2819774896600[u48];
                                                v75 = UNNAMED_2819774896648[u48];
                                                v78 = v79 + v75 - 1;
                                                v76 = v79 + v77;
                                                v80 = u47[v76];
                                                local n = v80.n;
                                                v80.n = v77 + n - 1;
                                                u59(v80, 1, n, v77, v80);
                                                u59(u47, v79 + 1, v76 - 1, 1, v80);
                                                u59(u60(u47[v79](u57(v80, 1, v80.n))), 1, v75, v79, u47);
                                            end;
                                        elseif v841 < 40 then
                                            u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896696[u48]] + UNNAMED_2819774896600[u48];
                                        elseif v841 == 41 then
                                            u47[UNNAMED_2819774896696[u48]](UNNAMED_2819774896072[u48], u47[UNNAMED_2819774896648[u48]]);
                                        else
                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] * u47[UNNAMED_2819774896600[u48]];
                                        end;
                                    elseif v841 < 45 then
                                        if v841 >= 43 then
                                            if v841 == 44 then
                                                for i = UNNAMED_2819774896600[u48], UNNAMED_2819774896648[u48] do
                                                    u47[i] = nil;
                                                    local _ = i;
                                                end;
                                            else
                                                u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] / u47[UNNAMED_2819774896696[u48]];
                                            end;
                                        else
                                            u47[UNNAMED_2819774896600[u48]] = -u47[UNNAMED_2819774896648[u48]];
                                        end;
                                    elseif v841 < 46 then
                                        u47[UNNAMED_2819774896696[u48]] = u61(u47[UNNAMED_2819774896600[u48]], UNNAMED_2819774896648[u48]);
                                    elseif v841 == 47 then
                                        u47[UNNAMED_2819774896696[u48]](u57(u47[UNNAMED_2819774896600[u48]], 1, u47[UNNAMED_2819774896600[u48]].n));
                                    else
                                        u47[UNNAMED_2819774896600[u48]] = u62(u47[UNNAMED_2819774896696[u48]], UNNAMED_2819774896120[u48]);
                                    end;
                                elseif v841 >= 30 then
                                    if v841 < 33 then
                                        if v841 < 31 then
                                            u47[UNNAMED_2819774896696[u48]] = u47[UNNAMED_2819774896648[u48]] < u47[UNNAMED_2819774896600[u48]];
                                        elseif v841 == 32 then
                                            u47[UNNAMED_2819774896648[u48]](u47[UNNAMED_2819774896600[u48]], u47[UNNAMED_2819774896696[u48]]);
                                        else
                                            u47[UNNAMED_2819774896696[u48]][u47[UNNAMED_2819774896600[u48]]] = u47[UNNAMED_2819774896648[u48]];
                                        end;
                                    elseif v841 < 34 then
                                        v79 = UNNAMED_2819774896600[u48];
                                        v77 = u47[UNNAMED_2819774896696[u48]];
                                        u47[v79 + 1] = v77;
                                        u47[v79] = v77[UNNAMED_2819774896120[u48]];
                                        u47[UNNAMED_2819774896600[u48 + 1]] = u47[UNNAMED_2819774896696[u48 + 1]];
                                        u47[UNNAMED_2819774896600[u48 + 2]] = UNNAMED_2819774896120[u48 + 2];
                                        u47[UNNAMED_2819774896600[u48 + 3]] = u47[UNNAMED_2819774896696[u48 + 3]];
                                        u48 = u48 + 3;
                                    else
                                        if v841 ~= 35 then
                                            local v1067 = u55;
                                            local v1068 = u56;

                                            if v1067 then
                                                for i in u58, v1067 do
                                                    local v1069 = v1067[i];

                                                    if v1069 then
                                                        v1069[5] = v1069;
                                                        v1069[6] = u47[i];
                                                        v1069[4] = 6;
                                                        v1067[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v1068 then
                                                for i, v in u58, v1068 do
                                                    local v1070 = v[6];

                                                    if v1068 then
                                                        local v1071 = v1068[i];

                                                        if v1071 then
                                                            local v1072 = u46(v1070);
                                                            u59(u47, i, i + v1070 - 1, 1, v1072);
                                                            v1071[5] = v1072;
                                                            v1071[4] = 1;
                                                            v1068[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return true, true, UNNAMED_2819774896648[u48], u60();
                                        end;

                                        u47[UNNAMED_2819774896696[u48]] = u19[UNNAMED_2819774896600[u48]][u47[UNNAMED_2819774896648[u48]]];
                                    end;
                                else
                                    if v841 < 27 then
                                        if v841 < 25 then
                                            u47[UNNAMED_2819774896600[u48]] = u47[UNNAMED_2819774896696[u48]];
                                            v79 = UNNAMED_2819774896648[u48 + 1];
                                            v77 = UNNAMED_2819774896696[u48 + 1];
                                            v75 = UNNAMED_2819774896600[u48 + 1];
                                            v78 = v79 + v75 - 1;
                                            v76 = v79 + v77;
                                            v80 = u60(u47[v79](u57(u47, v79 + 1, v79 + v77)));
                                            u59(v80, 1, v75, v79, u47);
                                            u48 = u48 + 1;
                                        elseif v841 == 26 then
                                            u47[UNNAMED_2819774896600[u48]] = UNNAMED_2819774896600;
                                        else
                                            local v1073 = UNNAMED_2819774896696[u48];
                                            local v1074 = u47[UNNAMED_2819774896648[u48]];
                                            local v1075 = u64(u47[UNNAMED_2819774896600[u48]], 4294967295);
                                            local v1076 = u64(v1074, 4294967295);
                                            local v1077 = u64(v1075, 65535);
                                            local v1078 = u63(v1075, 16);
                                            local v1079 = u64(v1076, 65535);
                                            local v1080 = u63(v1076, 16);
                                            local v1081 = u64(v1077 * v1079 + u65(u64(v1077 * v1080 + v1078 * v1079, 65535), 16), 4294967295) % 4294967296;
                                            u47[v1073] = v1081 ~= v1081 and 0 or v1081 - v1081 % 1;
                                        end;

                                        v840 = 1;
                                        continue;
                                    end;

                                    if v841 < 28 then
                                        v79 = UNNAMED_2819774896696[u48] + 1;
                                        v77 = u61(UNNAMED_2819774896600[u48], (u64(u61(u44, (u64(u63(u44, 29), 7))), 536870911)));

                                        for i = 1, UNNAMED_2819774896648[u48] do
                                            local v1082 = u64(u61(v77, (u65(v77, 13))), 536870911);
                                            local v1083 = u61(v1082, (u63(v1082, 13)));
                                            v77 = u64(u61(v1083, (u65(v1083, 14))), 536870911);
                                            UNNAMED_2819774896696[v79] = u61(UNNAMED_2819774896696[v79], (u64(u63(v77, 0), 127)));
                                            UNNAMED_2819774896600[v79] = u61(UNNAMED_2819774896600[v79], (u64(u63(v77, 7), 127)));
                                            UNNAMED_2819774896648[v79] = u61(UNNAMED_2819774896648[v79], (u64(u63(v77, 14), 127)));
                                            UNNAMED_2819774896552[v79] = u61(UNNAMED_2819774896552[v79], (u64(u63(v77, 21), 127)));
                                            v79 = v79 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819774896552[u48] = 86;
                                        v840 = 1;
                                        continue;
                                    end;

                                    if v841 == 29 then
                                        u49 = UNNAMED_2819774896648[u48];
                                        u48 = UNNAMED_2819774896600[u48] + 1;
                                        v81 = 1;
                                        break;
                                    end;

                                    u47[UNNAMED_2819774896648[u48]] = u47[UNNAMED_2819774896600[u48]] / UNNAMED_2819774896696[u48];
                                end;

                                v840 = 1;
                                continue;
                            elseif v840 == 1 then
                                v840 = -1;
                                u48 = u48 + 1;
                                break;
                            else
                                break;
                            end;
                        end;

                        if v81 ~= -1 then
                            break;
                        end;
                    end;

                    if v81 ~= -1 then
                        continue;
                    end;

                    break;
                else
                    break;
                end;
            end;
        end, ...);

        if v1084 then
            if v1085 then
                if v1086 then
                    return u47[v1087](u57(v1088, 1, v1088.n));
                end;

                return u47[v1087](u57(u47, v1087 + 1, v1088));
            end;

            if v1087 then
                if v1086 then
                    return u57(v1087, 1, v1087.n);
                end;

                return u57(u47, v1087, v1088);
            end;
        else
            local v1089 = u55;
            local v1090 = u56;

            if v1089 then
                for i in u58, v1089 do
                    local v1091 = v1089[i];

                    if v1091 then
                        v1091[5] = v1091;
                        v1091[6] = u47[i];
                        v1091[4] = 6;
                        v1089[i] = nil;
                    end;
                end;
            end;

            if v1090 then
                for i, v in u58, v1090 do
                    local v1092 = v[6];

                    if v1090 then
                        local v1093 = v1090[i];

                        if v1093 then
                            local v1094 = u46(v1092);
                            u59(u47, i, i + v1092 - 1, 1, v1094);
                            v1093[5] = v1094;
                            v1093[4] = 1;
                            v1090[i] = nil;
                        end;
                    end;
                end;
            end;

            u43(UNNAMED_2819774896360, v1085, u48, UNNAMED_2819774896312);
        end;
    end;
end;