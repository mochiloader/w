-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735087672[21];
local u2 = UNNAMED_2819735087672[11];
local u3 = UNNAMED_2819735087672[110];
local u4 = UNNAMED_2819735087672[35];
local u5 = UNNAMED_2819735087672[84];
local u6 = UNNAMED_2819735087672[113];
local u7 = UNNAMED_2819735087672[22];
local u8 = UNNAMED_2819735087672[105];
local u9 = UNNAMED_2819735087672[5];
local u10 = UNNAMED_2819735087672[93];
local u11 = UNNAMED_2819735087672[92];
local u12 = UNNAMED_2819735087672[43];
local u13 = UNNAMED_2819735087672[67];

return function(p14, u15, p16, u17, p18, u19, p20, p21) -- Line: 3
    -- upvalues: u1 (copy), u2 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u12 (copy), u13 (copy), UNNAMED_2819735088392 (copy), UNNAMED_2819735086952 (copy), UNNAMED_2819735088440 (copy), UNNAMED_2819735037800 (copy), UNNAMED_2819735055608 (copy), UNNAMED_2819735046536 (copy), UNNAMED_2819735058440 (copy), UNNAMED_2819735092472 (copy), UNNAMED_2819735052200 (copy), UNNAMED_2819735067896 (copy), UNNAMED_2819735055416 (copy), UNNAMED_2819735087672 (copy)
    local u22 = u1;
    local u23 = u2;
    local u24 = u3;
    local u25 = u4;
    local u26 = u5;
    local u27 = u6;
    local u28 = u7;
    local u29 = u8;
    local u30 = u9;
    local u31 = u10;
    local u32 = u11;
    local u33 = u12;
    local u34 = u13;

    return function(...) -- Line: 3
        -- upvalues: u22 (copy), UNNAMED_2819735088392 (ref), UNNAMED_2819735086952 (ref), UNNAMED_2819735088440 (ref), UNNAMED_2819735037800 (ref), u23 (copy), UNNAMED_2819735055608 (ref), u24 (copy), UNNAMED_2819735046536 (ref), UNNAMED_2819735058440 (ref), u19 (copy), u25 (copy), u26 (copy), u27 (copy), u15 (copy), UNNAMED_2819735092472 (ref), u28 (copy), u29 (copy), u30 (copy), u31 (copy), u17 (copy), UNNAMED_2819735052200 (ref), UNNAMED_2819735067896 (ref), u32 (copy), UNNAMED_2819735055416 (ref), UNNAMED_2819735087672 (ref), u33 (copy), u34 (copy)
        local v35, v36, v37, v38, v39, v40, v41, v42, v43, v44;
        local v45 = 0;

        while true do
            if v45 == 0 then
                v45 = -1;
                v35 = u22(UNNAMED_2819735088392);

                if UNNAMED_2819735086952 ~= 94 then
                    v36 = UNNAMED_2819735088440;
                    v37 = UNNAMED_2819735086952;
                    v45 = 4;
                    continue;
                end;

                v38 = UNNAMED_2819735088440;
                v39 = UNNAMED_2819735086952;
                v45 = 1;
                continue;
            elseif v45 == 1 then
                v45 = -1;
                v40 = UNNAMED_2819735037800[v38];

                if v40 >= 5 then
                    v45 = 2;
                    continue;
                end;

                if v40 < 2 then
                    if v40 ~= 1 then
                        u27({ ... }, 1, 6, UNNAMED_2819735037800[v38 + 1], v35);
                        v35[UNNAMED_2819735055608[v38]] = 50;
                        local v46 = v35[81];
                        v35[1] = v35[53];
                        v35[2] = v46;
                        v35[21] = v35[UNNAMED_2819735046536[v38]];
                        v35[6] = v35[UNNAMED_2819735046536[v38 + 1]];
                        v35[UNNAMED_2819735058440[v38 + 1]] = v35[73];
                        v35[5] = v35[88];
                        v35[23] = v35[113];
                        v38 = v38 + 1;
                    end;
                elseif v40 >= 3 then
                    if v40 == 4 then
                        v38 = u23(UNNAMED_2819735058440[v38], (u24(u23(UNNAMED_2819735037800[v38], 92, v39), 127)));
                    else
                        local v47 = u23(UNNAMED_2819735055608[v38], (u24(u23(u15, (u24(u25(u15, 29), 7))), 536870911)));
                        local v48 = UNNAMED_2819735046536[v38] + 1;

                        for i = 1, UNNAMED_2819735058440[v38] do
                            local v49 = u24(u23(v47, (u26(v47, 13))), 536870911);
                            local v50 = u23(v49, (u25(v49, 13)));
                            v47 = u24(u23(v50, (u26(v50, 14))), 536870911);
                            UNNAMED_2819735046536[v48] = u23(UNNAMED_2819735046536[v48], (u24(u25(v47, 0), 127)));
                            UNNAMED_2819735055608[v48] = u23(UNNAMED_2819735055608[v48], (u24(u25(v47, 7), 127)));
                            UNNAMED_2819735058440[v48] = u23(UNNAMED_2819735058440[v48], (u24(u25(v47, 14), 127)));
                            UNNAMED_2819735037800[v48] = u23(UNNAMED_2819735037800[v48], (u24(u25(v47, 21), 127)));
                            v48 = v48 + 1;
                            local _ = i;
                        end;

                        UNNAMED_2819735037800[v38] = 1;
                    end;
                else
                    v35[u23(UNNAMED_2819735046536[v38], (u24(u23(1, UNNAMED_2819735037800[v38]), 127)))] = v35[UNNAMED_2819735055608[v38]];
                end;

                v45 = 18;
                continue;
            elseif v45 == 2 then
                v45 = -1;

                if v40 >= 8 then
                    v45 = 17;
                    continue;
                end;

                if v40 < 6 then
                    v45 = 3;
                    continue;
                end;

                v45 = 16;
                continue;
            elseif v45 == 3 then
                v45 = -1;
                v37 = UNNAMED_2819735055608[v38];
                v36 = u23(UNNAMED_2819735058440[v38], (u24(u23(UNNAMED_2819735037800[v38], 28), 127))) + 1;
                v45 = 4;
                continue;
            elseif v45 == 4 then
                v45 = -1;

                if v37 == 127 then
                    local v51;
                    local v51, v36, v37;
                    local v52 = 0;

                    while true do
                        if v52 == 0 then
                            v52 = -1;
                            v51 = UNNAMED_2819735058440[v36];

                            if v51 < 5 then
                                if v51 >= 2 then
                                    if v51 < 3 then
                                        v35[u23(UNNAMED_2819735055608[v36], 58)] = v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735058440[v36], 127)))];
                                    elseif v51 == 4 then
                                        local v53 = UNNAMED_2819735046536[v36];
                                        local v54 = u23(UNNAMED_2819735037800[v36], (u24(u23(u19, (u24(u25(u19, 29), 7))), 536870911)));
                                        local v55 = UNNAMED_2819735092472[5];
                                        local v56 = u23(v55[v53], 109162203);
                                        v55[v53] = v56;
                                        local v57 = UNNAMED_2819735092472[4];
                                        local v58 = v56 + 1;
                                        local v59 = u28(v57, v58);
                                        local v60;

                                        if v59 < 128 then
                                            v60 = v58 + 1;
                                        else
                                            local v61 = u28(v57, v58 + 1);

                                            if v61 < 128 then
                                                v59 = v59 - 128 + v61 * 128;
                                                v60 = v58 + 2;
                                            else
                                                local v62 = u28(v57, v58 + 2);

                                                if v62 < 128 then
                                                    v59 = v59 - 128 + (v61 - 128) * 16384 + v62 * 128;
                                                    v60 = v58 + 3;
                                                else
                                                    local v63 = u28(v57, v58 + 3);
                                                    v59 = (v59 - 128) * 16384 + (v61 - 128) * 128 + (v62 - 128) + v63 % 128 * 2097152 + (v63 - v63 % 128) * 2097152;
                                                    v60 = v58 + 4;
                                                end;
                                            end;
                                        end;

                                        local v64 = v54 * 16843009;
                                        local v65 = v60 + v59;
                                        local v66 = v65 - v59 % 4;

                                        for i = v60, v66 - 1, 4 do
                                            u29(v57, i, (u23(u30(v57, i), v64)));
                                            local _ = i;
                                        end;

                                        for i = v66, v65 - 1 do
                                            u31(v57, i, (u23(u28(v57, i), v54)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735046536[v36] = 168;
                                        UNNAMED_2819735037800[v36] = 126;
                                        UNNAMED_2819735055608[v36] = 198;
                                        UNNAMED_2819735058440[v36] = 8;
                                    elseif v35[UNNAMED_2819735037800[v36]] > u23(UNNAMED_2819735055608[v36], (u24(u23(v37, UNNAMED_2819735058440[v36]), 127))) then
                                        v36 = UNNAMED_2819735046536[v36];
                                    end;
                                elseif v51 == 1 then
                                    v36 = u23(UNNAMED_2819735046536[v36], (u24(u23(v37, 126, UNNAMED_2819735058440[v36]), 127)));
                                else
                                    local v67 = UNNAMED_2819735037800[v36];
                                    local v68 = UNNAMED_2819735055608[v36];
                                    local v69 = u23(u15, u24(u25(u15, 14), 262143), (u24(u25(u15, 28), 15)));
                                    local v70 = UNNAMED_2819735046536[v36];
                                    local v71 = v67 < 16384 and 7 or (v67 < 2097152 and 14 or 21);
                                    local v72 = u24(v67, u26(1, v71) - 1);
                                    local v73 = u25(v67, v71);
                                    UNNAMED_2819735046536[v36] = u23(v70, 122, (u24(v69, 127)));
                                    UNNAMED_2819735037800[v36] = u23(v72, 107, (u24(u25(v69, 7), 127)));
                                    UNNAMED_2819735058440[v36] = u23(v73, 39, (u24(u25(v69, 21), 127)));
                                    UNNAMED_2819735055608[v36] = u23(v68, 77, (u24(u25(v69, 14), 127)));
                                    v36 = v36 - 1;
                                end;

                                v52 = 1;
                                continue;
                            end;

                            if v51 >= 7 then
                                v52 = 2;
                                continue;
                            end;

                            if v51 == 6 then
                                v35[UNNAMED_2819735046536[v36]] = UNNAMED_2819735055608[v36];
                            else
                                v36 = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v37, 67), 127)))];
                            end;

                            v52 = 1;
                            continue;
                        elseif v52 == 1 then
                            v52 = -1;
                            v36 = v36 + 1;
                            v52 = 0;
                            continue;
                        elseif v52 == 2 then
                            v52 = -1;

                            if v51 >= 8 then
                                if v51 == 9 then
                                    local v74 = u23(UNNAMED_2819735046536[v36], (u24(v36, 127)));
                                    local v75 = v35[UNNAMED_2819735037800[v36]];
                                    local v76 = v35[u23(UNNAMED_2819735055608[v36], (u24(u23(v37, v36), 127)))];
                                    v35[v74] = v75;
                                    v35[v74 + 1] = v76;
                                end;

                                v52 = 1;
                                continue;
                            end;

                            v37 = u23(UNNAMED_2819735046536[v36], (u24(UNNAMED_2819735058440[v36], 127)));
                            v36 = u23(UNNAMED_2819735055608[v36], 92) + 1;
                            break;
                        else
                            break;
                        end;
                    end;
                end;

                if v37 == 236 then
                    while true do
                        local v36;
                        local v77 = 0;

                        while true do
                            if v77 == 0 then
                                v77 = -1;
                                local v78 = UNNAMED_2819735046536[v36];

                                if v78 < 3 then
                                    if v78 < 1 then
                                        local v79 = UNNAMED_2819735058440[v36];
                                        local v80 = UNNAMED_2819735055608[v36];
                                        local v81 = UNNAMED_2819735037800[v36];
                                        local v82 = u23(u17, u24(u25(u17, 14), 262143), (u24(u25(u17, 28), 15)));
                                        local v83 = v81 < 16384 and 7 or (v81 < 2097152 and 14 or 21);
                                        local v84 = u24(v81, u26(1, v83) - 1);
                                        UNNAMED_2819735046536[v36] = u23(u25(v81, v83), 7, (u24(u25(v82, 21), 127)));
                                        UNNAMED_2819735058440[v36] = u23(v79, 116, (u24(u25(v82, 7), 127)));
                                        UNNAMED_2819735037800[v36] = u23(v84, 109, (u24(u25(v82, 14), 127)));
                                        UNNAMED_2819735055608[v36] = u23(v80, 27, (u24(v82, 127)));
                                        v36 = v36 - 1;
                                    elseif v78 == 2 then
                                        if v35[u23(UNNAMED_2819735037800[v36], 117)] > u23(UNNAMED_2819735055608[v36], (u24(u23(v37, 41), 127))) then
                                            v36 = UNNAMED_2819735058440[v36];
                                        end;
                                    else
                                        v36 = u23(UNNAMED_2819735055608[v36], (u24(u23(UNNAMED_2819735046536[v36], 61, v37), 127)));
                                    end;

                                    v77 = 1;
                                    continue;
                                end;

                                if v78 < 4 then
                                    v36 = v35[u23(UNNAMED_2819735055608[v36], (u24(u23(77, v37, UNNAMED_2819735046536[v36]), 127)))];
                                    v77 = 1;
                                    continue;
                                end;

                                if v78 == 5 then
                                    v77 = -2;
                                    break;
                                end;

                                v35[UNNAMED_2819735037800[v36]] = UNNAMED_2819735055608[v36];
                                v77 = 1;
                                continue;
                            elseif v77 == 1 then
                                v77 = -1;
                                v36 = v36 + 1;
                                break;
                            else
                                break;
                            end;
                        end;

                        if v77 == -2 then
                            break;
                        end;
                    end;

                    v37 = u23(UNNAMED_2819735055608[v36], 102);
                    v36 = u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735046536[v36], 127))) + 1;
                end;

                if v37 ~= 124 then
                    v42 = u19;
                    v45 = 10;
                    continue;
                end;

                v41 = u15;
                v42 = u19;
                v43 = u17;
                v45 = 5;
                continue;
            elseif v45 == 5 then
                v45 = -1;
                v44 = UNNAMED_2819735055608[v36];

                if v44 >= 52 then
                    v45 = 14;
                    continue;
                end;

                if v44 < 26 then
                    v45 = 6;
                    continue;
                end;

                if v44 < 39 then
                    if v44 < 32 then
                        if v44 >= 29 then
                            if v44 >= 30 then
                                if v44 == 31 then
                                    if v35[UNNAMED_2819735037800[v36]] ~= u23(UNNAMED_2819735058440[v36], (u24(v37, 127))) then
                                        v36 = u23(UNNAMED_2819735046536[v36], (u24(u23(UNNAMED_2819735055608[v36], v37), 127)));
                                    end;
                                else
                                    local v85 = u23(UNNAMED_2819735046536[v36], (u24(u23(v43, (u24(u25(v43, 29), 7))), 536870911)));
                                    local v86 = UNNAMED_2819735037800[v36] + 1;

                                    for i = 1, UNNAMED_2819735058440[v36] do
                                        local v87 = u24(u23(v85, (u26(v85, 13))), 536870911);
                                        local v88 = u23(v87, (u25(v87, 13)));
                                        v85 = u24(u23(v88, (u26(v88, 14))), 536870911);
                                        UNNAMED_2819735037800[v86] = u23(UNNAMED_2819735037800[v86], (u24(u25(v85, 0), 127)));
                                        UNNAMED_2819735046536[v86] = u23(UNNAMED_2819735046536[v86], (u24(u25(v85, 7), 127)));
                                        UNNAMED_2819735058440[v86] = u23(UNNAMED_2819735058440[v86], (u24(u25(v85, 14), 127)));
                                        UNNAMED_2819735055608[v86] = u23(UNNAMED_2819735055608[v86], (u24(u25(v85, 21), 127)));
                                        v86 = v86 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735055608[v36] = 96;
                                end;
                            else
                                v35[UNNAMED_2819735037800[v36]] = u24(v35[UNNAMED_2819735046536[v36]], v35[u23(UNNAMED_2819735058440[v36], (u24(v37, 127)))]);
                            end;
                        elseif v44 < 27 then
                            v35[u23(UNNAMED_2819735058440[v36], (u24(v37, 127)))] = v35[UNNAMED_2819735037800[v36]] % v35[UNNAMED_2819735046536[v36]];
                        elseif v44 == 28 then
                            v35[u23(UNNAMED_2819735046536[v36], (u24(u23(108, UNNAMED_2819735055608[v36], v37), 127)))] = v35[UNNAMED_2819735058440[v36]] >= v35[u23(UNNAMED_2819735037800[v36], (u24(u23(UNNAMED_2819735055608[v36], v36, v37), 127)))];
                        else
                            v35[33] = UNNAMED_2819735067896[v36 + 2];
                            v35[5] = UNNAMED_2819735055416[v36 + 2];
                            v35[23] = UNNAMED_2819735067896[v36];
                            v35[UNNAMED_2819735055608[v36 + 1]] = 67108864;
                            v35[551] = UNNAMED_2819735055416[v36 + 1];
                            v35[552] = 46628761;
                            v35[553] = UNNAMED_2819735055608[v36 + 2];
                            v35[UNNAMED_2819735037800[v36 + 1]] = v35[UNNAMED_2819735037800[v36 + 2]];
                            v36 = v36 + 2;
                        end;
                    elseif v44 < 35 then
                        if v44 < 33 then
                            if v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v37, UNNAMED_2819735055608[v36]), 127)))] then
                                v36 = u23(UNNAMED_2819735046536[v36], (u24(u23(57, UNNAMED_2819735055608[v36]), 127)));
                            else
                                v36 = u23(UNNAMED_2819735037800[v36], (u24(u23(v37, 45, UNNAMED_2819735055608[v36]), 127)));
                            end;
                        elseif v44 == 34 then
                            v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127))) + v35[UNNAMED_2819735046536[v36]]] = v35[u23(UNNAMED_2819735058440[v36], (u24(u23(118, UNNAMED_2819735055608[v36]), 127)))];
                        else
                            local v89 = u23(UNNAMED_2819735058440[v36], (u24(UNNAMED_2819735055608[v36], 127)));
                            local v90 = UNNAMED_2819735055416[v36];
                            v35[v89] = UNNAMED_2819735052200[v36];
                            v35[v89 + 1] = v90;
                        end;
                    elseif v44 < 37 then
                        if v44 == 36 then
                            v35[UNNAMED_2819735046536[v36]] = v35[UNNAMED_2819735058440[v36]] <= u23(UNNAMED_2819735037800[v36], (u24(u23(60, v36, v37), 127)));
                        else
                            local v91 = UNNAMED_2819735058440[v36];
                            local v92 = UNNAMED_2819735046536[v36] + 1;

                            for i = 1, UNNAMED_2819735037800[v36] do
                                local v93 = u24(u23(v91, (u26(v91, 13))), 536870911);
                                local v94 = u23(v93, (u25(v93, 13)));
                                v91 = u24(u23(v94, (u26(v94, 14))), 536870911);
                                UNNAMED_2819735037800[v92] = u23(UNNAMED_2819735037800[v92], (u24(u25(v91, 0), 127)));
                                UNNAMED_2819735046536[v92] = u23(UNNAMED_2819735046536[v92], (u24(u25(v91, 7), 127)));
                                UNNAMED_2819735058440[v92] = u23(UNNAMED_2819735058440[v92], (u24(u25(v91, 14), 127)));
                                UNNAMED_2819735055608[v92] = u23(UNNAMED_2819735055608[v92], (u24(u25(v91, 21), 127)));
                                v92 = v92 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735055608[v36] = 96;
                        end;
                    elseif v44 == 38 then
                        v35[u23(UNNAMED_2819735037800[v36], (u24(v37, 127)))] = v41;
                    else
                        v35[u23(UNNAMED_2819735046536[v36], (u24(u23(40, v36, UNNAMED_2819735055608[v36]), 127)))] = {};
                    end;
                elseif v44 >= 45 then
                    if v44 >= 48 then
                        if v44 >= 50 then
                            if v44 == 51 then
                                local v95 = UNNAMED_2819735037800[v36];
                                local v96 = v35[u23(UNNAMED_2819735046536[v36], 27)];
                                local v97 = v35[UNNAMED_2819735058440[v36]];
                                v35[v95] = v96;
                                v35[v95 + 1] = v97;
                            else
                                v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v36, v37, 49), 127)))] = v42;
                            end;
                        elseif v44 == 49 then
                            local v98 = UNNAMED_2819735046536[v36];
                            local v99 = u23(v43, u24(u25(v43, 14), 262143), (u24(u25(v43, 28), 15)));
                            local v100 = UNNAMED_2819735037800[v36];
                            local v101 = UNNAMED_2819735058440[v36];
                            local v102 = v100 < 2097152 and 7 or 14;
                            local v103 = u25(v100, v102);
                            UNNAMED_2819735037800[v36] = u23(u24(v100, u26(1, v102) - 1), 3, (u24(v99, 127)));
                            UNNAMED_2819735046536[v36] = u23(v98, 69, (u24(u25(v99, 7), 127)));
                            UNNAMED_2819735058440[v36] = u23(v101, 84, (u24(u25(v99, 14), 127)));
                            UNNAMED_2819735055608[v36] = u23(v103, 94, (u24(u25(v99, 21), 127)));
                            v36 = v36 - 1;
                        else
                            v35[1] = v35[UNNAMED_2819735055608[v36 + 1]] - v35[1];
                            v35[1] = v35[UNNAMED_2819735046536[v36 + 1]] / v35[551];
                            v35[13][v35[UNNAMED_2819735058440[v36]]] = v35[1];
                            v35[1] = v41;
                            v35[1] = u23(v35[1], UNNAMED_2819735052200[v36]);
                            v41 = v35[1];
                            v35[20] = 1;
                            v36 = v36 + 1;
                        end;
                    elseif v44 >= 46 then
                        if v44 == 47 then
                            local v104 = UNNAMED_2819735058440[v36];
                            local v105 = UNNAMED_2819735046536[v36];
                            local v106 = u23(UNNAMED_2819735037800[v36], 103);
                            local _ = v104 + v106 - 1;
                            local _ = v104 + v105;
                            u27(u33(v35[v104](u34(v35, v104 + 1, v104 + v105))), 1, v106, v104, v35);
                        else
                            v35[u23(UNNAMED_2819735058440[v36], (u24(u23(4, v37), 127)))] = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(UNNAMED_2819735055608[v36], v37, v36), 127)))] + UNNAMED_2819735046536[v36];
                        end;
                    else
                        v35[UNNAMED_2819735046536[v36]] = UNNAMED_2819735058440[v36];
                    end;
                elseif v44 < 42 then
                    if v44 < 40 then
                        v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v36, UNNAMED_2819735055608[v36], 63), 127)))] = u22(UNNAMED_2819735046536[v36]);
                    elseif v44 == 41 then
                        local v107 = UNNAMED_2819735046536[v36];
                        local v108 = UNNAMED_2819735037800[v36];
                        local v109 = u23(v43, u24(u25(v43, 14), 262143), (u24(u25(v43, 28), 15)));
                        local v110 = UNNAMED_2819735058440[v36];
                        local v111 = v107 < 16384 and 7 or (v107 < 2097152 and 14 or 21);
                        local v112 = u25(v107, v111);
                        local v113 = u24(v107, u26(1, v111) - 1);
                        UNNAMED_2819735058440[v36] = u23(v110, 84, (u24(u25(v109, 14), 127)));
                        UNNAMED_2819735037800[v36] = u23(v108, 97, (u24(v109, 127)));
                        UNNAMED_2819735046536[v36] = u23(v113, 22, (u24(u25(v109, 7), 127)));
                        UNNAMED_2819735055608[v36] = u23(v112, 122, (u24(u25(v109, 21), 127)));
                        v36 = v36 - 1;
                    else
                        v35[u23(UNNAMED_2819735046536[v36], 89)] = UNNAMED_2819735058440[v36] - v35[u23(UNNAMED_2819735037800[v36], (u24(u23(UNNAMED_2819735055608[v36], v36), 127)))];
                    end;
                elseif v44 >= 43 then
                    if v44 == 44 then
                        v35[u23(UNNAMED_2819735046536[v36], (u24(v37, 127)))] = v35[UNNAMED_2819735037800[v36] + v35[UNNAMED_2819735058440[v36]]];
                    else
                        v42 = v35[1];
                        v35[32][70] = UNNAMED_2819735046536[v36];
                        v35[32][53] = 5;
                        v35[32][UNNAMED_2819735037800[v36]] = UNNAMED_2819735058440[v36];
                        v35[32][67] = 12;
                        v35[33] = v41;
                    end;
                else
                    v35[2] = v35[2] * v35[552];
                    v35[1] = v35[UNNAMED_2819735055608[v36 + 1]] * v35[25];
                    v35[UNNAMED_2819735055608[v36 + 2]] = v35[UNNAMED_2819735037800[v36 + 2]] + v35[2];
                    v35[1] = v35[UNNAMED_2819735046536[v36 + 2]] % v35[UNNAMED_2819735058440[v36 + 2]];
                    v35[UNNAMED_2819735037800[v36]] = v35[UNNAMED_2819735046536[v36 + 1]] + v35[UNNAMED_2819735037800[v36 + 1]];
                    v35[UNNAMED_2819735058440[v36]] = v35[UNNAMED_2819735058440[v36 + 1]] % v35[23];
                    v35[UNNAMED_2819735046536[v36]] = v43;
                    v36 = v36 + 2;
                end;

                v45 = 13;
                continue;
            elseif v45 == 6 then
                v45 = -1;

                if v44 >= 13 then
                    v45 = 7;
                    continue;
                end;

                if v44 < 6 then
                    if v44 >= 3 then
                        if v44 < 4 then
                            v35[u23(UNNAMED_2819735058440[v36], (u24(u23(UNNAMED_2819735055608[v36], v37, v36), 127)))] = v35[UNNAMED_2819735046536[v36]] - v35[UNNAMED_2819735037800[v36]];
                        elseif v44 == 5 then
                            v35[15] = UNNAMED_2819735067896[v36 + 1] + UNNAMED_2819735055416[v36 + 1];
                            v35[17] = 1 - v35[15];
                            v35[18] = UNNAMED_2819735055416[v36] + UNNAMED_2819735052200[v36];
                            v35[14] = u22(UNNAMED_2819735055608[v36 + 1]);
                            v35[16] = v35[0];
                            v35[19] = v35[9];
                            v36 = v36 + 1;
                        else
                            v35[UNNAMED_2819735037800[v36]] = v35[u23(UNNAMED_2819735046536[v36], (u24(v37, 127)))] * v35[u23(UNNAMED_2819735058440[v36], (u24(v37, 127)))];
                        end;
                    elseif v44 < 1 then
                        local v114 = u23(UNNAMED_2819735037800[v36], (u24(u23(v36, v37), 127)));
                        local v115 = UNNAMED_2819735058440[v36];
                        u23(UNNAMED_2819735046536[v36], 102);
                        v35[v114] = u33(v35[v114](u34(v35, v114 + 1, v114 + v115)));
                    elseif v44 == 2 then
                        v35[u23(UNNAMED_2819735046536[v36], (u24(UNNAMED_2819735055608[v36], 127)))] = UNNAMED_2819735067896[v36];
                    else
                        v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v37, 71), 127)))] = v35[UNNAMED_2819735058440[v36]] + v35[UNNAMED_2819735046536[v36]];
                    end;
                elseif v44 >= 9 then
                    if v44 >= 11 then
                        if v44 == 12 then
                            v35[UNNAMED_2819735058440[v36]] = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(26, UNNAMED_2819735055608[v36], v36), 127)))] < UNNAMED_2819735046536[v36];
                        else
                            v35[1] = v35[9][UNNAMED_2819735055608[v36 + 1]];
                            v35[2] = v35[9][4];
                            v35[3] = v35[UNNAMED_2819735046536[v36]][5];
                            v35[1] = v35[1] + v35[2];
                            v35[UNNAMED_2819735046536[v36 + 1]] = v35[UNNAMED_2819735058440[v36]] <= 0;
                            v35[4] = not v35[2];
                            v35[UNNAMED_2819735058440[v36 + 1]] = v35[1] >= v35[3];
                            v35[3] = v35[UNNAMED_2819735037800[v36 + 1]] <= v35[3];
                            v36 = v36 + 1;
                        end;
                    elseif v44 == 10 then
                        v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127)))] = v35[UNNAMED_2819735058440[v36]] - u23(UNNAMED_2819735046536[v36], (u24(u23(56, v37), 127)));
                    else
                        v35[u23(UNNAMED_2819735046536[v36], (u24(UNNAMED_2819735055608[v36], 127)))] = v35[UNNAMED_2819735037800[v36]] ~= v35[u23(UNNAMED_2819735058440[v36], (u24(u23(UNNAMED_2819735055608[v36], v36), 127)))];
                    end;
                elseif v44 >= 7 then
                    if v44 == 8 then
                        v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v37, UNNAMED_2819735055608[v36], v36), 127)))] = v35[UNNAMED_2819735046536[v36]] == UNNAMED_2819735037800[v36];
                    else
                        v35[u23(UNNAMED_2819735037800[v36], (u24(v36, 127)))] = u23(v35[UNNAMED_2819735058440[v36]], UNNAMED_2819735055416[v36]);
                    end;
                else
                    v35[1] = v35[UNNAMED_2819735055608[v36 + 1]] % v35[25];
                    v35[2] = v35[33] - v35[UNNAMED_2819735055608[v36 + 2]];
                    v35[2] = v35[UNNAMED_2819735037800[v36 + 1]] / v35[UNNAMED_2819735046536[v36 + 2]];
                    v35[UNNAMED_2819735037800[v36 + 2]] = v35[2] * v35[UNNAMED_2819735058440[v36 + 1]];
                    v35[UNNAMED_2819735037800[v36]] = v35[1] * v35[553];
                    v35[4] = v35[UNNAMED_2819735058440[v36 + 2]];
                    v36 = v36 + 2;
                end;

                v45 = 13;
                continue;
            elseif v45 == 7 then
                v45 = -1;

                if v44 < 19 then
                    v45 = 8;
                    continue;
                end;

                if v44 >= 22 then
                    if v44 >= 24 then
                        if v44 == 25 then
                            for i = u23(UNNAMED_2819735058440[v36], (u24(u23(v36, v37, 104), 127))), u23(UNNAMED_2819735046536[v36], (u24(u23(v37, 89), 127))) do
                                v35[i] = nil;
                                local _ = i;
                            end;
                        else
                            v35[1] = v35[9][2];
                            v35[UNNAMED_2819735055608[v36 + 1]] = v35[9][4];
                            v35[3] = v35[9][UNNAMED_2819735037800[v36]];
                            v35[UNNAMED_2819735058440[v36 + 1]] = v35[UNNAMED_2819735037800[v36 + 1]] + v35[2];
                            v35[UNNAMED_2819735058440[v36]] = v35[2] <= 0;
                            v35[4] = not v35[2];
                            v36 = v36 + 1;
                        end;
                    elseif v44 == 23 then
                        v35[UNNAMED_2819735037800[v36]] = v35[u23(UNNAMED_2819735046536[v36], (u24(UNNAMED_2819735055608[v36], 127)))];
                    else
                        v35[18] = UNNAMED_2819735055416[v36 + 3] + UNNAMED_2819735052200[v36];
                        v35[16] = UNNAMED_2819735055608[v36 + 3] - v35[UNNAMED_2819735055608[v36 + 1]];
                        v35[UNNAMED_2819735055608[v36 + 2]] = UNNAMED_2819735055416[v36 + 2] + UNNAMED_2819735067896[v36 + 1];
                        v35[UNNAMED_2819735058440[v36]] = u22(UNNAMED_2819735037800[v36 + 1]);
                        v35[UNNAMED_2819735046536[v36 + 1]] = v35[0];
                        v35[15] = v35[UNNAMED_2819735058440[v36 + 2]];
                        local v116 = UNNAMED_2819735037800[v36 + 3];
                        u27(v35, v116 + 1, v116 + UNNAMED_2819735037800[v36 + 2], 1, v35[v116]);
                        v35[20] = 62;
                        v36 = v36 + 3;
                    end;
                elseif v44 < 20 then
                    v35[u23(UNNAMED_2819735058440[v36], (u24(u23(87, v37), 127)))][v35[u23(UNNAMED_2819735046536[v36], 64)]] = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(85, v36), 127)))];
                elseif v44 == 21 then
                    v36 = u23(UNNAMED_2819735037800[v36], (u24(u23(25, UNNAMED_2819735055608[v36]), 127)));
                else
                    v35[1] = v35[13] - v35[25];
                    v35[UNNAMED_2819735055608[v36 + 1]] = v35[1] / 2;
                    v35[1] = v35[5] - v35[UNNAMED_2819735046536[v36]];
                    v35[UNNAMED_2819735058440[v36]] = v35[1] / 2;
                    v35[UNNAMED_2819735037800[v36]] = v35[13] % 2;
                    v35[UNNAMED_2819735046536[v36 + 1]] = v35[UNNAMED_2819735058440[v36 + 1]] % 2;
                    v36 = v36 + 1;
                end;

                v45 = 13;
                continue;
            elseif v45 == 8 then
                v45 = -1;

                if v44 < 16 then
                    v45 = 12;
                    continue;
                end;

                if v44 < 17 then
                    v45 = 9;
                    continue;
                end;

                v45 = 11;
                continue;
            elseif v45 == 9 then
                v45 = -1;
                v37 = UNNAMED_2819735037800[v36];
                v36 = u23(UNNAMED_2819735046536[v36], 13) + 1;
                v45 = 10;
                continue;
            elseif v45 == 10 then
                v45 = -1;

                if v37 == 84 then
                    local v117;

                    while true do
                        v117 = UNNAMED_2819735037800[v36];

                        if v117 >= 1 then
                            break;
                        end;

                        v35[UNNAMED_2819735055608[v36]] = u23(v35[UNNAMED_2819735046536[v36]], (u23(UNNAMED_2819735058440[v36], (u24(v36, 127)))));
                        v36 = v36 + 1;
                    end;

                    if v117 == 2 then
                        return v35[u23(UNNAMED_2819735046536[v36], (u24(u23(23, v37), 127)))];
                    end;

                    return v35[u23(UNNAMED_2819735055608[v36], (u24(u23(105, v36), 127)))], v35[UNNAMED_2819735046536[v36]];
                end;

                if v37 ~= 101 then
                    return;
                end;

                while true do
                    local v118 = UNNAMED_2819735058440[v36];

                    if v118 >= 2 then
                        if v118 == 3 then
                            return v35[u23(UNNAMED_2819735055608[v36], (u24(u23(v36, v37), 127)))], v35[UNNAMED_2819735037800[v36]];
                        end;

                        v35[UNNAMED_2819735055608[v36]] = v35[u23(UNNAMED_2819735046536[v36], (u24(u23(UNNAMED_2819735058440[v36], v37, 22), 127)))] + UNNAMED_2819735052200[v36];
                    elseif v118 == 1 then
                        v35[u23(UNNAMED_2819735055608[v36], (u24(u23(UNNAMED_2819735058440[v36], 49), 127)))] = v42;
                    else
                        local v119 = u23(UNNAMED_2819735046536[v36], 93);
                        local v120 = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v36, 43), 127)))] % 4294967296;
                        v35[v119] = v120 ~= v120 and 0 or v120 - v120 % 1;
                    end;

                    v36 = v36 + 1;
                end;

                v45 = 11;
                continue;
            elseif v45 == 11 then
                v45 = -1;

                if v44 == 18 then
                    if v35[u23(UNNAMED_2819735037800[v36], (u24(u23(UNNAMED_2819735055608[v36], v37), 127)))] > u23(UNNAMED_2819735058440[v36], (u24(u23(113, v37, UNNAMED_2819735055608[v36]), 127))) then
                        v36 = UNNAMED_2819735046536[v36];
                    end;
                else
                    v35[33] = v35[1] + 1;
                    v35[1] = v41;
                    v35[1] = v35[1] + v35[UNNAMED_2819735046536[v36]];
                    v41 = v35[1];
                    v35[UNNAMED_2819735058440[v36]] = u23(v35[36], 308766547);
                    v35[UNNAMED_2819735037800[v36]] = v42;
                end;

                v45 = 13;
                continue;
            elseif v45 == 12 then
                v45 = -1;

                if v44 >= 14 then
                    if v44 == 15 then
                        v35[32][50] = 2;
                        v35[32][69] = 14;
                        v35[UNNAMED_2819735046536[v36]][102] = UNNAMED_2819735058440[v36];
                        v35[1] = v43;
                        v35[UNNAMED_2819735037800[v36]] = v35[1] // v35[36];
                        v43 = v35[1];
                    else
                        v41 = v35[u23(UNNAMED_2819735058440[v36], (u24(v36, 127)))];
                    end;
                else
                    v35[u23(UNNAMED_2819735046536[v36], (u24(UNNAMED_2819735055608[v36], 127)))] = UNNAMED_2819735087672[u23(UNNAMED_2819735058440[v36], (u24(u23(v37, v36, UNNAMED_2819735055608[v36]), 127)))];
                end;

                v45 = 13;
                continue;
            elseif v45 == 13 then
                v45 = -1;
                v45 = 15;
                continue;
            elseif v45 == 14 then
                v45 = -1;

                if v44 < 78 then
                    if v44 >= 65 then
                        if v44 >= 71 then
                            if v44 >= 74 then
                                if v44 >= 76 then
                                    if v44 == 77 then
                                        v36 = v35[u23(UNNAMED_2819735037800[v36], 45)];
                                    else
                                        v35[u23(UNNAMED_2819735046536[v36], (u24(v37, 127)))] = UNNAMED_2819735052200[v36] + UNNAMED_2819735067896[v36];
                                    end;
                                elseif v44 == 75 then
                                    local v121 = UNNAMED_2819735058440[v36];
                                    local v122 = UNNAMED_2819735037800[v36];
                                    local v123 = UNNAMED_2819735092472[5];
                                    local v124 = u23(v123[v121], 109162203);
                                    v123[v121] = v124;
                                    local v125 = UNNAMED_2819735092472[4];
                                    local v126 = v124 + 1;
                                    local v127 = u28(v125, v126);
                                    local v128;

                                    if v127 < 128 then
                                        v128 = v126 + 1;
                                    else
                                        local v129 = u28(v125, v126 + 1);

                                        if v129 < 128 then
                                            v127 = v127 - 128 + v129 * 128;
                                            v128 = v126 + 2;
                                        else
                                            local v130 = u28(v125, v126 + 2);

                                            if v130 < 128 then
                                                v127 = v127 - 128 + (v129 - 128) * 16384 + v130 * 128;
                                                v128 = v126 + 3;
                                            else
                                                local v131 = u28(v125, v126 + 3);
                                                v127 = (v127 - 128) * 16384 + (v129 - 128) * 128 + (v130 - 128) + v131 % 128 * 2097152 + (v131 - v131 % 128) * 2097152;
                                                v128 = v126 + 4;
                                            end;
                                        end;
                                    end;

                                    local v132 = v122 * 16843009;
                                    local v133 = v128 + v127;
                                    local v134 = v133 - v127 % 4;

                                    for i = v128, v134 - 1, 4 do
                                        u29(v125, i, (u23(u30(v125, i), v132)));
                                        local _ = i;
                                    end;

                                    for i = v134, v133 - 1 do
                                        u31(v125, i, (u23(u28(v125, i), v122)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735058440[v36] = 198;
                                    UNNAMED_2819735037800[v36] = 156;
                                    UNNAMED_2819735046536[v36] = 253;
                                    UNNAMED_2819735055608[v36] = 96;
                                else
                                    local v135 = u23(UNNAMED_2819735046536[v36], (u24(u23(v41, (u24(u25(v41, 29), 7))), 536870911)));
                                    local v136 = UNNAMED_2819735037800[v36] + 1;

                                    for i = 1, UNNAMED_2819735058440[v36] do
                                        local v137 = u24(u23(v135, (u26(v135, 13))), 536870911);
                                        local v138 = u23(v137, (u25(v137, 13)));
                                        v135 = u24(u23(v138, (u26(v138, 14))), 536870911);
                                        UNNAMED_2819735037800[v136] = u23(UNNAMED_2819735037800[v136], (u24(u25(v135, 0), 127)));
                                        UNNAMED_2819735046536[v136] = u23(UNNAMED_2819735046536[v136], (u24(u25(v135, 7), 127)));
                                        UNNAMED_2819735058440[v136] = u23(UNNAMED_2819735058440[v136], (u24(u25(v135, 14), 127)));
                                        UNNAMED_2819735055608[v136] = u23(UNNAMED_2819735055608[v136], (u24(u25(v135, 21), 127)));
                                        v136 = v136 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735055608[v36] = 96;
                                end;
                            elseif v44 >= 72 then
                                if v44 == 73 then
                                    v35[UNNAMED_2819735058440[v36]] = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v36, 63), 127)))] // v35[u23(UNNAMED_2819735046536[v36], (u24(u23(UNNAMED_2819735055608[v36], v37), 127)))];
                                else
                                    v35[u23(UNNAMED_2819735046536[v36], 49)] = u23(UNNAMED_2819735058440[v36], (u24(u23(v37, 111), 127)));
                                end;
                            else
                                v35[UNNAMED_2819735037800[v36]] = v35[UNNAMED_2819735046536[v36]] * u23(UNNAMED_2819735058440[v36], (u24(u23(114, v36, v37), 127)));
                            end;
                        elseif v44 < 68 then
                            if v44 >= 66 then
                                if v44 == 67 then
                                    v35[1] = v35[9][2];
                                    v35[2] = v35[9][UNNAMED_2819735055608[v36 + 2]];
                                    v35[3] = v35[9][UNNAMED_2819735055608[v36 + 1]];
                                    v35[1] = v35[UNNAMED_2819735037800[v36 + 2]] + v35[UNNAMED_2819735046536[v36]];
                                    v35[UNNAMED_2819735058440[v36]] = v35[2] <= 0;
                                    v35[UNNAMED_2819735037800[v36 + 1]] = not v35[2];
                                    v35[UNNAMED_2819735058440[v36 + 1]] = v35[UNNAMED_2819735037800[v36]] >= v35[3];
                                    v35[UNNAMED_2819735046536[v36 + 1]] = v35[1] <= v35[3];
                                    v36 = v36 + 2;
                                else
                                    v35[UNNAMED_2819735037800[v36]] = v35[u23(UNNAMED_2819735046536[v36], (u24(v37, 127)))] ~= UNNAMED_2819735058440[v36];
                                end;
                            else
                                local v139 = u23(UNNAMED_2819735046536[v36], (u24(u23(v42, (u24(u25(v42, 29), 7))), 536870911)));
                                local v140 = UNNAMED_2819735037800[v36] + 1;

                                for i = 1, UNNAMED_2819735058440[v36] do
                                    local v141 = u24(u23(v139, (u26(v139, 13))), 536870911);
                                    local v142 = u23(v141, (u25(v141, 13)));
                                    v139 = u24(u23(v142, (u26(v142, 14))), 536870911);
                                    UNNAMED_2819735037800[v140] = u23(UNNAMED_2819735037800[v140], (u24(u25(v139, 0), 127)));
                                    UNNAMED_2819735046536[v140] = u23(UNNAMED_2819735046536[v140], (u24(u25(v139, 7), 127)));
                                    UNNAMED_2819735058440[v140] = u23(UNNAMED_2819735058440[v140], (u24(u25(v139, 14), 127)));
                                    UNNAMED_2819735055608[v140] = u23(UNNAMED_2819735055608[v140], (u24(u25(v139, 21), 127)));
                                    v140 = v140 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735055608[v36] = 96;
                            end;
                        elseif v44 < 69 then
                            local v143 = u23(UNNAMED_2819735037800[v36], 113);
                            local v144 = v35[u23(UNNAMED_2819735046536[v36], (u24(u23(v36, v37), 127)))];
                            local v145 = v35[UNNAMED_2819735058440[v36]];
                            local v146 = u24(v144, 4294967295);
                            local v147 = u24(v145, 4294967295);
                            local v148 = u24(v146, 65535);
                            local v149 = u25(v146, 16);
                            local v150 = u24(v147, 65535);
                            local v151 = u25(v147, 16);
                            local v152 = u24(v148 * v150 + u26(u24(v148 * v151 + v149 * v150, 65535), 16), 4294967295) % 4294967296;
                            v35[v143] = v152 ~= v152 and 0 or v152 - v152 % 1;
                        elseif v44 == 70 then
                            v35[UNNAMED_2819735058440[v36]][u23(UNNAMED_2819735037800[v36], (u24(u23(2, v37, v36), 127)))] = v35[UNNAMED_2819735046536[v36]];
                        else
                            v35[u23(UNNAMED_2819735037800[v36], (u24(u23(82, UNNAMED_2819735055608[v36], v36), 127)))] = u23(UNNAMED_2819735046536[v36], (u24(u23(v36, 37, v37), 127))) + v35[UNNAMED_2819735058440[v36]];
                        end;
                    elseif v44 >= 58 then
                        if v44 < 61 then
                            if v44 < 59 then
                                v35[u23(UNNAMED_2819735046536[v36], (u24(u23(v37, UNNAMED_2819735055608[v36], 120), 127)))] = v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v37, 1), 127)))] <= v35[UNNAMED_2819735037800[v36]];
                            elseif v44 == 60 then
                                v35[u23(UNNAMED_2819735058440[v36], (u24(UNNAMED_2819735055608[v36], 127)))][UNNAMED_2819735037800[v36]] = UNNAMED_2819735046536[v36];
                            else
                                v35[1] = v35[UNNAMED_2819735037800[v36]][UNNAMED_2819735046536[v36]];
                                v35[2] = v35[9][5];
                                v35[3] = v35[9][3];
                                v35[1] = v35[1] + v35[2];
                                v35[UNNAMED_2819735058440[v36]] = v35[2] <= 0;
                                v35[4] = not v35[2];
                            end;
                        elseif v44 >= 63 then
                            if v44 == 64 then
                                v35[u23(UNNAMED_2819735046536[v36], (u24(u23(UNNAMED_2819735055608[v36], v36, 91), 127)))] = v43;
                            else
                                v43 = v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127)))];
                            end;
                        elseif v44 == 62 then
                            v35[UNNAMED_2819735058440[v36]] = u32(v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127)))], v35[UNNAMED_2819735046536[v36]]);
                        else
                            v35[1] = v35[21](v35[32]);
                            v35[UNNAMED_2819735046536[v36] + v35[32]] = v35[1];
                            v35[294 + v35[32]] = v35[UNNAMED_2819735058440[v36]];
                            v35[1] = v35[33] * v35[32];
                            v35[2] = v43;
                            v35[2] = v35[2] - v35[36];
                            v43 = v35[2];
                            v35[1] = v35[1] + v35[5];
                        end;
                    elseif v44 < 55 then
                        if v44 < 53 then
                            v35[u23(UNNAMED_2819735046536[v36], (u24(v37, 127)))] = v35[UNNAMED_2819735037800[v36]] // u23(UNNAMED_2819735058440[v36], (u24(u23(v36, 52), 127)));
                        elseif v44 == 54 then
                            if v35[u23(UNNAMED_2819735058440[v36], (u24(v37, 127)))] then
                                v36 = UNNAMED_2819735037800[v36];
                            else
                                v36 = u23(UNNAMED_2819735046536[v36], 79);
                            end;
                        else
                            v35[1] = v35[UNNAMED_2819735055608[v36 + 1]] - v35[25];
                            v35[13] = v35[1] / UNNAMED_2819735058440[v36 + 1];
                            v35[1] = v35[UNNAMED_2819735058440[v36]] - v35[552];
                            v35[5] = v35[UNNAMED_2819735037800[v36]] / 2;
                            v35[1] = v43;
                            v35[36] = u23(v35[36], v35[UNNAMED_2819735037800[v36 + 1]]);
                            v36 = v36 + 1;
                        end;
                    elseif v44 >= 56 then
                        if v44 == 57 then
                            v35[1] = v35[13] - v35[UNNAMED_2819735055608[v36 + 2]];
                            v35[13] = v35[UNNAMED_2819735055608[v36 + 1]] / UNNAMED_2819735058440[v36];
                            v35[1] = v35[UNNAMED_2819735037800[v36 + 1]] - v35[552];
                            v35[5] = v35[UNNAMED_2819735037800[v36]] / 2;
                            v35[25] = v35[UNNAMED_2819735046536[v36]] % 2;
                            v35[552] = v35[UNNAMED_2819735037800[v36 + 2]] % UNNAMED_2819735058440[v36 + 1];
                            v36 = v36 + 2;
                        else
                            local v153 = UNNAMED_2819735037800[v36];
                            local v154 = u23(UNNAMED_2819735046536[v36], (u24(v37, 127)));
                            local v155 = u23(UNNAMED_2819735058440[v36], (u24(u23(100, v36), 127)));
                            u27(v35, v153 + 1, v153 + v154, v155 + 1, v35[v153]);
                        end;
                    else
                        v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v37, UNNAMED_2819735055608[v36], v36), 127)))] = v35[u23(UNNAMED_2819735046536[v36], (u24(u23(v37, 6, UNNAMED_2819735055608[v36]), 127)))] / UNNAMED_2819735058440[v36];
                    end;
                elseif v44 < 91 then
                    if v44 >= 84 then
                        if v44 >= 87 then
                            if v44 < 89 then
                                if v44 == 88 then
                                    v35[16] = 0 - v35[19];
                                    local v156 = u22(5);
                                    v35[UNNAMED_2819735055608[v36 + 1]] = UNNAMED_2819735067896[v36 + 1] + UNNAMED_2819735055416[v36];
                                    v35[UNNAMED_2819735058440[v36]] = v156;
                                    v35[18] = v35[0];
                                    v35[UNNAMED_2819735037800[v36]] = v35[9];
                                    u27(v35, 15, 19, 1, v35[14]);
                                    v35[20] = 49;
                                    v36 = v36 + 1;
                                else
                                    v35[u23(UNNAMED_2819735046536[v36], (u24(u23(1, v36, v37), 127)))] = v35[UNNAMED_2819735058440[v36]] .. v35[UNNAMED_2819735037800[v36]];
                                end;
                            elseif v44 == 90 then
                                v35[UNNAMED_2819735055608[v36 + 1]] = u23(v35[36], v35[1]);
                                v35[1] = v42;
                                v35[UNNAMED_2819735037800[v36 + 1]] = v41;
                                local v157 = v35[1];
                                local v158 = u24(v35[UNNAMED_2819735058440[v36 + 1]], 4294967295);
                                local v159 = u24(v157, 4294967295);
                                local v160 = u24(v158, 65535);
                                local v161 = u25(v158, 16);
                                local v162 = u24(v159, 65535);
                                local v163 = u25(v159, 16);
                                local v164 = u24(v160 * v162 + u26(u24(v160 * v163 + v161 * v162, 65535), 16), 4294967295) % 4294967296;
                                v35[1] = v164 ~= v164 and 0 or v164 - v164 % 1;
                                v41 = v35[UNNAMED_2819735058440[v36]];
                                v35[UNNAMED_2819735046536[v36]] = UNNAMED_2819735052200[v36] + UNNAMED_2819735055416[v36 + 1];
                                v36 = v36 + 1;
                            else
                                v35[u23(UNNAMED_2819735058440[v36], (u24(v37, 127)))] = v35[UNNAMED_2819735037800[v36]][u23(UNNAMED_2819735046536[v36], (u24(u23(UNNAMED_2819735055608[v36], v36, v37), 127)))];
                            end;
                        elseif v44 < 85 then
                            local v165 = u22(5);
                            v35[18] = UNNAMED_2819735067896[v36 + 1] + UNNAMED_2819735052200[v36];
                            v35[19] = 0 - v35[18];
                            v35[16] = UNNAMED_2819735055416[v36 + 1] + UNNAMED_2819735067896[v36];
                            v35[14] = v165;
                            v35[17] = v35[0];
                            v35[UNNAMED_2819735055608[v36 + 1]] = v35[9];
                            v36 = v36 + 1;
                        elseif v44 == 86 then
                            v35[u23(UNNAMED_2819735046536[v36], (u24(u23(v37, v36), 127)))] = u23(v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v36, 19), 127)))], (u23(UNNAMED_2819735037800[v36], 60)));
                        else
                            v36 = v35[u23(UNNAMED_2819735058440[v36], (u24(UNNAMED_2819735055608[v36], 127)))];
                        end;
                    elseif v44 >= 81 then
                        if v44 < 82 then
                            v35[UNNAMED_2819735037800[v36]] = v35[UNNAMED_2819735058440[v36]] >= u23(UNNAMED_2819735046536[v36], (u24(UNNAMED_2819735055608[v36], 127)));
                        elseif v44 == 83 then
                            v35[u23(UNNAMED_2819735037800[v36], (u24(u23(UNNAMED_2819735055608[v36], 115), 127)))] = not v35[u23(UNNAMED_2819735058440[v36], (u24(u23(UNNAMED_2819735055608[v36], v36, v37), 127)))];
                        else
                            v35[UNNAMED_2819735046536[v36]] = v35[u23(UNNAMED_2819735058440[v36], (u24(u23(UNNAMED_2819735055608[v36], v37), 127)))] % UNNAMED_2819735052200[v36];
                        end;
                    elseif v44 >= 79 then
                        if v44 == 80 then
                            local v166 = u23(UNNAMED_2819735058440[v36], (u24(u23(118, UNNAMED_2819735055608[v36], v36), 127)));
                            local v167 = u23(UNNAMED_2819735037800[v36], 23);
                            local v168 = u23(UNNAMED_2819735046536[v36], (u24(u23(v36, UNNAMED_2819735055608[v36], v37), 127)));
                            v35[v166] = v167;
                            v35[v166 + 1] = v168;
                        else
                            v42 = v35[u23(UNNAMED_2819735046536[v36], (u24(u23(UNNAMED_2819735055608[v36], v37), 127)))];
                        end;
                    else
                        v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v36, 57), 127)))] = v35[u23(UNNAMED_2819735058440[v36], (u24(v37, 127)))] - UNNAMED_2819735055416[v36];
                    end;
                elseif v44 < 98 then
                    if v44 >= 94 then
                        if v44 < 96 then
                            if v44 == 95 then
                                v35[u23(UNNAMED_2819735037800[v36], (u24(v36, 127)))] = v35[UNNAMED_2819735058440[v36]] / v35[UNNAMED_2819735046536[v36]];
                            else
                                v35[u23(UNNAMED_2819735037800[v36], (u24(v36, 127)))] = v35[UNNAMED_2819735058440[v36]] == v35[UNNAMED_2819735046536[v36]];
                            end;
                        elseif v44 == 97 then
                            v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127)))] = u23(UNNAMED_2819735058440[v36], (u24(u23(UNNAMED_2819735055608[v36], 83), 127))) * v35[UNNAMED_2819735046536[v36]];
                        end;
                    elseif v44 < 92 then
                        v35[u23(UNNAMED_2819735046536[v36], (u24(v36, 127)))] = v35[UNNAMED_2819735058440[v36]][v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127)))]];
                    elseif v44 == 93 then
                        v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v36, UNNAMED_2819735055608[v36]), 127)))] = u24(v35[u23(UNNAMED_2819735058440[v36], (u24(u23(v36, UNNAMED_2819735055608[v36]), 127)))], UNNAMED_2819735046536[v36]);
                    else
                        v35[UNNAMED_2819735055608[v36 + 1]] = #v35[34];
                        v35[UNNAMED_2819735055608[v36 + 2]] = UNNAMED_2819735055416[v36 + 2] + UNNAMED_2819735052200[v36];
                        v35[UNNAMED_2819735037800[v36 + 2]] = 1 - v35[UNNAMED_2819735058440[v36 + 1]];
                        v35[UNNAMED_2819735037800[v36 + 1]] = v35[2] + 0;
                        v35[UNNAMED_2819735046536[v36 + 1]] = u22(UNNAMED_2819735058440[v36]);
                        v35[UNNAMED_2819735058440[v36 + 2]] = v35[0];
                        v36 = v36 + 2;
                    end;
                elseif v44 < 101 then
                    if v44 >= 99 then
                        if v44 == 100 then
                            v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v37, UNNAMED_2819735055608[v36], 23), 127)))] = v35[u23(UNNAMED_2819735058440[v36], (u24(u23(UNNAMED_2819735055608[v36], v37), 127)))] + UNNAMED_2819735055416[v36];
                        else
                            v35[u23(UNNAMED_2819735046536[v36], (u24(v36, 127)))] = v35[UNNAMED_2819735058440[v36]] % UNNAMED_2819735037800[v36];
                        end;
                    else
                        local v169 = u23(UNNAMED_2819735058440[v36], (u24(UNNAMED_2819735055608[v36], 127)));
                        local v170 = v35[u23(UNNAMED_2819735037800[v36], (u24(u23(UNNAMED_2819735055608[v36], 49, v37), 127)))] % 4294967296;
                        v35[v169] = v170 ~= v170 and 0 or v170 - v170 % 1;
                    end;
                elseif v44 >= 103 then
                    if v44 == 104 then
                        v35[UNNAMED_2819735055608[v36 + 1]] = v35[9][5];
                        v35[2] = v35[9][UNNAMED_2819735037800[v36 + 1]];
                        v35[3] = v35[UNNAMED_2819735037800[v36]][2];
                        v35[1] = v35[1] + v35[UNNAMED_2819735058440[v36 + 1]];
                        v35[2] = v35[UNNAMED_2819735046536[v36]] <= UNNAMED_2819735058440[v36];
                        v35[UNNAMED_2819735046536[v36 + 1]] = not v35[2];
                        v36 = v36 + 1;
                    elseif v35[u23(UNNAMED_2819735037800[v36], (u24(u23(v37, UNNAMED_2819735055608[v36], 59), 127)))] ~= v35[u23(UNNAMED_2819735046536[v36], (u24(u23(v37, UNNAMED_2819735055608[v36], 1), 127)))] then
                        v36 = u23(UNNAMED_2819735058440[v36], 65);
                    end;
                elseif v44 == 102 then
                    v35[u23(UNNAMED_2819735037800[v36], (u24(UNNAMED_2819735055608[v36], 127)))] = u23(v35[u23(UNNAMED_2819735058440[v36], (u24(v36, 127)))], v35[UNNAMED_2819735046536[v36]]);
                else
                    v35[1] = v35[UNNAMED_2819735055608[v36 + 1]][5];
                    v35[2] = v35[9][UNNAMED_2819735046536[v36 + 1]];
                    v35[3] = v35[UNNAMED_2819735058440[v36]][1];
                    v35[1] = v35[1] + v35[2];
                    v35[UNNAMED_2819735046536[v36]] = v35[UNNAMED_2819735037800[v36]] <= 0;
                    v36 = v36 + 1;
                end;

                v45 = 15;
                continue;
            elseif v45 == 15 then
                v45 = -1;
                v36 = v36 + 1;
                v45 = 5;
                continue;
            elseif v45 == 16 then
                v45 = -1;

                if v40 == 7 then
                    local v171 = UNNAMED_2819735046536[v38];
                    local v172 = UNNAMED_2819735055608[v38] + 1;

                    for i = 1, UNNAMED_2819735058440[v38] do
                        local v173 = u24(u23(v171, (u26(v171, 13))), 536870911);
                        local v174 = u23(v173, (u25(v173, 13)));
                        v171 = u24(u23(v174, (u26(v174, 14))), 536870911);
                        UNNAMED_2819735046536[v172] = u23(UNNAMED_2819735046536[v172], (u24(u25(v171, 0), 127)));
                        UNNAMED_2819735055608[v172] = u23(UNNAMED_2819735055608[v172], (u24(u25(v171, 7), 127)));
                        UNNAMED_2819735058440[v172] = u23(UNNAMED_2819735058440[v172], (u24(u25(v171, 14), 127)));
                        UNNAMED_2819735037800[v172] = u23(UNNAMED_2819735037800[v172], (u24(u25(v171, 21), 127)));
                        v172 = v172 + 1;
                        local _ = i;
                    end;

                    UNNAMED_2819735037800[v38] = 1;
                else
                    local v175 = UNNAMED_2819735046536[v38];
                    local v176 = v35[u23(UNNAMED_2819735055608[v38], (u24(u23(v38, UNNAMED_2819735037800[v38]), 127)))];
                    local v177 = v35[u23(UNNAMED_2819735058440[v38], (u24(u23(104, v38, UNNAMED_2819735037800[v38]), 127)))];
                    v35[v175] = v176;
                    v35[v175 + 1] = v177;
                end;

                v45 = 18;
                continue;
            elseif v45 == 17 then
                v45 = -1;

                if v40 >= 9 then
                    if v40 == 10 then
                        v38 = v35[u23(UNNAMED_2819735055608[v38], (u24(u23(85, v39), 127)))];
                    else
                        v35[UNNAMED_2819735046536[v38]] = UNNAMED_2819735055608[v38];
                    end;
                else
                    local v178 = UNNAMED_2819735058440[v38];
                    local v179 = UNNAMED_2819735055608[v38];
                    local v180 = UNNAMED_2819735046536[v38];
                    local v181 = u23(u19, u24(u25(u19, 14), 262143), (u24(u25(u19, 28), 15)));
                    local v182 = v179 < 16384 and 7 or (v179 < 2097152 and 14 or 21);
                    local v183 = u25(v179, v182);
                    UNNAMED_2819735055608[v38] = u23(u24(v179, u26(1, v182) - 1), 120, (u24(u25(v181, 7), 127)));
                    UNNAMED_2819735037800[v38] = u23(v183, 13, (u24(u25(v181, 21), 127)));
                    UNNAMED_2819735058440[v38] = u23(v178, 106, (u24(u25(v181, 14), 127)));
                    UNNAMED_2819735046536[v38] = u23(v180, 0, (u24(v181, 127)));
                    v38 = v38 - 1;
                end;

                v45 = 18;
                continue;
            elseif v45 == 18 then
                v45 = -1;
                v38 = v38 + 1;
                v45 = 1;
                continue;
            elseif v45 == 19 then
                v45 = -1;
                break;
            else
                break;
            end;
        end;
    end;
end;