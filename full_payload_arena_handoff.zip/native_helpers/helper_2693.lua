-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735064680;
local u2 = UNNAMED_2819735040104;
local u3 = UNNAMED_2819735061656;
local u4 = UNNAMED_2819735083208;
local u5 = UNNAMED_2819735058632;
local u6 = UNNAMED_2819735034056;
local u7 = UNNAMED_2819735080184;
local u8 = UNNAMED_2819735055608;
local u9 = UNNAMED_2819735052584;
local u10 = UNNAMED_2819735049560;
local u11 = UNNAMED_2819735092664;
local u12 = UNNAMED_2819735068088;
local u13 = UNNAMED_2819735089640;
local u14 = UNNAMED_2819735065064;
local u15 = UNNAMED_2819735037464;
local u16 = UNNAMED_2819735083592;
local u17 = UNNAMED_2819735034440;
local u18 = UNNAMED_2819735080568;
local u19 = UNNAMED_2819735055992;

return function(...) -- Line: 3
    -- upvalues: u1 (copy), UNNAMED_2819735028392 (ref), UNNAMED_2819735074520 (ref), UNNAMED_2819735049944 (ref), UNNAMED_2819732806648 (copy), UNNAMED_2819732806600 (copy), UNNAMED_2819735043896 (ref), UNNAMED_2819735090024 (ref), UNNAMED_2819735065448 (ref), UNNAMED_2819735031800 (ref), UNNAMED_2819735080952 (ref), UNNAMED_2819732806552 (copy), u2 (copy), u3 (copy), u4 (copy), UNNAMED_2819735056376 (ref), u7 (copy), u6 (copy), u5 (copy), u8 (copy), UNNAMED_2819735028776 (ref), UNNAMED_2819735053352 (ref), u9 (copy), u10 (copy), u11 (copy), u12 (copy), UNNAMED_2819735050328 (ref), u13 (copy), u14 (copy), UNNAMED_2819735071880 (ref), u15 (copy), u16 (copy), u17 (copy), u18 (copy), u19 (copy)
    local v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32, v33;
    local v34 = 0;

    while true do
        if v34 == 0 then
            v34 = -1;
            v25 = nil;
            v26 = nil;
            v27 = nil;
            v28 = nil;
            v29 = u1(UNNAMED_2819735028392);
            v30 = nil;
            v31 = nil;
            v32 = nil;

            if UNNAMED_2819735074520 ~= 104 then
                v20 = UNNAMED_2819732806600;
                v21 = UNNAMED_2819732806648;
                v22 = UNNAMED_2819735049944;
                v23 = UNNAMED_2819735074520;
                v34 = 6;
                continue;
            end;

            v24 = UNNAMED_2819735049944;
            v21 = UNNAMED_2819732806648;
            v20 = UNNAMED_2819732806600;
            v34 = 1;
            continue;
        elseif v34 == 1 then
            v34 = -1;
            v33 = UNNAMED_2819735043896[v24];

            if v33 < 36 then
                v34 = 15;
                continue;
            end;

            if v33 >= 54 then
                v34 = 2;
                continue;
            end;

            if v33 < 45 then
                if v33 < 40 then
                    if v33 < 38 then
                        if v33 == 37 then
                            if UNNAMED_2819735031800[v24] >= v29[UNNAMED_2819735065448[v24]] then
                                v24 = UNNAMED_2819735090024[v24];
                            end;
                        elseif v29[UNNAMED_2819735065448[v24]] ~= UNNAMED_2819735031800[v24] then
                            v24 = UNNAMED_2819735090024[v24];
                        end;
                    elseif v33 == 39 then
                        if v29[UNNAMED_2819735090024[v24]] then
                            v24 = UNNAMED_2819735065448[v24];
                        else
                            v24 = UNNAMED_2819735031800[v24];
                        end;
                    else
                        local v35 = UNNAMED_2819735090024[v24];
                        local v36 = u7(v21, u6(u5(v21, 14), 262143), (u6(u5(v21, 28), 15)));
                        local v37 = UNNAMED_2819735065448[v24];
                        local v38 = UNNAMED_2819735031800[v24];
                        local v39 = v37 < 16384 and 7 or (v37 < 2097152 and 14 or 21);
                        local v40 = u6(v37, u8(1, v39) - 1);
                        local v41 = u5(v37, v39);
                        UNNAMED_2819735090024[v24] = u7(v35, 7, (u6(u5(v36, 7), 127)));
                        UNNAMED_2819735043896[v24] = u7(v41, 31, (u6(u5(v36, 21), 127)));
                        UNNAMED_2819735031800[v24] = u7(v38, 111, (u6(u5(v36, 14), 127)));
                        UNNAMED_2819735065448[v24] = u7(v40, 38, (u6(v36, 127)));
                        v24 = v24 - 1;
                    end;
                elseif v33 < 42 then
                    if v33 == 41 then
                        v29[UNNAMED_2819735090024[v24]]();
                    else
                        local v42 = UNNAMED_2819732806552[UNNAMED_2819735065448[v24]];
                        v42[5][v42[4]] = v29[UNNAMED_2819735031800[v24]];
                    end;
                elseif v33 >= 43 then
                    if v33 == 44 then
                        v24 = v29[UNNAMED_2819735031800[v24]];
                    else
                        local v43 = UNNAMED_2819735031800[v24];
                        local v44 = UNNAMED_2819735065448[v24];
                        local v45 = UNNAMED_2819735053352[5];
                        local v46 = u7(v45[v43], 109162203);
                        v45[v43] = v46;
                        local v47 = UNNAMED_2819735053352[4];
                        local v48 = v46 + 1;
                        local v49 = u9(v47, v48);
                        local v50;

                        if v49 < 128 then
                            v50 = v48 + 1;
                        else
                            local v51 = u9(v47, v48 + 1);

                            if v51 < 128 then
                                v49 = v49 - 128 + v51 * 128;
                                v50 = v48 + 2;
                            else
                                local v52 = u9(v47, v48 + 2);

                                if v52 < 128 then
                                    v49 = v49 - 128 + (v51 - 128) * 16384 + v52 * 128;
                                    v50 = v48 + 3;
                                else
                                    local v53 = u9(v47, v48 + 3);
                                    v49 = (v49 - 128) * 16384 + (v51 - 128) * 128 + (v52 - 128) + v53 % 128 * 2097152 + (v53 - v53 % 128) * 2097152;
                                    v50 = v48 + 4;
                                end;
                            end;
                        end;

                        local v54 = v44 * 16843009;
                        local v55 = v50 + v49;
                        local v56 = v55 - v49 % 4;

                        for i = v50, v56 - 1, 4 do
                            u10(v47, i, (u7(u11(v47, i), v54)));
                            local _ = i;
                        end;

                        for i = v56, v55 - 1 do
                            u12(v47, i, (u7(u9(v47, i), v44)));
                            local _ = i;
                        end;

                        UNNAMED_2819735031800[v24] = 78;
                        UNNAMED_2819735065448[v24] = 1;
                        UNNAMED_2819735090024[v24] = 188;
                        UNNAMED_2819735043896[v24] = 62;
                    end;
                else
                    local v57 = UNNAMED_2819735065448[v24];
                    local v58 = u7(UNNAMED_2819735090024[v24], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                    local v59 = UNNAMED_2819735053352[5];
                    local v60 = u7(v59[v57], 109162203);
                    v59[v57] = v60;
                    local v61 = UNNAMED_2819735053352[4];
                    local v62 = v60 + 1;
                    local v63 = u9(v61, v62);
                    local v64;

                    if v63 < 128 then
                        v64 = v62 + 1;
                    else
                        local v65 = u9(v61, v62 + 1);

                        if v65 < 128 then
                            v63 = v63 - 128 + v65 * 128;
                            v64 = v62 + 2;
                        else
                            local v66 = u9(v61, v62 + 2);

                            if v66 < 128 then
                                v63 = v63 - 128 + (v65 - 128) * 16384 + v66 * 128;
                                v64 = v62 + 3;
                            else
                                local v67 = u9(v61, v62 + 3);
                                v63 = (v63 - 128) * 16384 + (v65 - 128) * 128 + (v66 - 128) + v67 % 128 * 2097152 + (v67 - v67 % 128) * 2097152;
                                v64 = v62 + 4;
                            end;
                        end;
                    end;

                    local v68 = v58 * 16843009;
                    local v69 = v64 + v63;
                    local v70 = v69 - v63 % 4;

                    for i = v64, v70 - 1, 4 do
                        u10(v61, i, (u7(u11(v61, i), v68)));
                        local _ = i;
                    end;

                    for i = v70, v69 - 1 do
                        u12(v61, i, (u7(u9(v61, i), v58)));
                        local _ = i;
                    end;

                    UNNAMED_2819735065448[v24] = 60;
                    UNNAMED_2819735090024[v24] = 83;
                    UNNAMED_2819735031800[v24] = 210;
                    UNNAMED_2819735043896[v24] = 62;
                end;
            elseif v33 >= 49 then
                if v33 >= 51 then
                    if v33 >= 52 then
                        if v33 == 53 then
                            v29[UNNAMED_2819735090024[v24]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v24]];
                        else
                            u4({ ... }, 1, UNNAMED_2819735090024[v24], UNNAMED_2819735031800[v24], v29);
                        end;
                    else
                        v29[UNNAMED_2819735065448[v24]](v29[UNNAMED_2819735031800[v24]]);
                    end;
                elseif v33 == 50 then
                    local v71 = u7(UNNAMED_2819735090024[v24], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                    local v72 = UNNAMED_2819735065448[v24] + 1;

                    for i = 1, UNNAMED_2819735031800[v24] do
                        local v73 = u6(u7(v71, (u8(v71, 13))), 536870911);
                        local v74 = u7(v73, (u5(v73, 13)));
                        v71 = u6(u7(v74, (u8(v74, 14))), 536870911);
                        UNNAMED_2819735065448[v72] = u7(UNNAMED_2819735065448[v72], (u6(u5(v71, 0), 127)));
                        UNNAMED_2819735090024[v72] = u7(UNNAMED_2819735090024[v72], (u6(u5(v71, 7), 127)));
                        UNNAMED_2819735031800[v72] = u7(UNNAMED_2819735031800[v72], (u6(u5(v71, 14), 127)));
                        UNNAMED_2819735043896[v72] = u7(UNNAMED_2819735043896[v72], (u6(u5(v71, 21), 127)));
                        v72 = v72 + 1;
                        local _ = i;
                    end;

                    UNNAMED_2819735043896[v24] = 62;
                else
                    v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735090024[v24]][UNNAMED_2819735031800[v24]];
                end;
            elseif v33 >= 47 then
                if v33 == 48 then
                    v27 = v30[8];
                    v31 = v30[5];
                    v28 = v30[7];
                    v25 = v30[6];
                    v30 = v30[9];
                else
                    local v75 = UNNAMED_2819735065448[v24];
                    local v76 = UNNAMED_2819735090024[v24];
                    u4({ ... }, 1, v75 - 1, v76, v29);
                    v29[v76 + v75 - 1] = u2(u13(v75, ...));
                end;
            elseif v33 == 46 then
                v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735090024[v24]] + UNNAMED_2819735031800[v24];
            else
                v29[UNNAMED_2819735090024[v24]] = u14(v29[UNNAMED_2819735065448[v24]], v29[UNNAMED_2819735031800[v24]]);
            end;

            v34 = 14;
            continue;
        elseif v34 == 2 then
            v34 = -1;

            if v33 < 63 then
                v34 = 3;
                continue;
            end;

            if v33 >= 68 then
                if v33 >= 70 then
                    if v33 < 71 then
                        if v29[UNNAMED_2819735031800[v24]] >= UNNAMED_2819735090024[v24] then
                            v24 = UNNAMED_2819735065448[v24];
                        end;
                    elseif v33 == 72 then
                        v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735031800[v24]] < UNNAMED_2819735065448[v24];
                    else
                        v29[UNNAMED_2819735090024[v24]] = UNNAMED_2819735031800[v24];
                    end;
                elseif v33 == 69 then
                    v30 = {
                        [9] = v30,
                        [7] = v28,
                        [8] = v27,
                        [5] = v31,
                        [6] = v25
                    };
                    local v77 = UNNAMED_2819735090024[v24];
                    v28 = v29[v77 + 2] + 0;
                    v31 = v29[v77 + 1] + 0;
                    v27 = v29[v77] - v28;
                    v24 = UNNAMED_2819735031800[v24];
                else
                    v21 = v29[UNNAMED_2819735031800[v24]];
                end;
            elseif v33 < 65 then
                if v33 == 64 then
                    v29[UNNAMED_2819735065448[v24]] = u7(UNNAMED_2819735028776[v24], UNNAMED_2819735056376[v24]);
                else
                    local v78 = UNNAMED_2819735065448[v24];
                    local v79 = UNNAMED_2819735031800[v24];
                    local v80 = UNNAMED_2819735090024[v24];
                    local v81 = u7(v21, u6(u5(v21, 14), 262143), (u6(u5(v21, 28), 15)));
                    local v82 = v78 < 2097152 and 7 or 14;
                    local v83 = u6(v78, u8(1, v82) - 1);
                    local v84 = u5(v78, v82);
                    UNNAMED_2819735065448[v24] = u7(v83, 56, (u6(v81, 127)));
                    UNNAMED_2819735031800[v24] = u7(v79, 77, (u6(u5(v81, 14), 127)));
                    UNNAMED_2819735090024[v24] = u7(v80, 39, (u6(u5(v81, 7), 127)));
                    UNNAMED_2819735043896[v24] = u7(v84, 72, (u6(u5(v81, 21), 127)));
                    v24 = v24 - 1;
                end;
            elseif v33 >= 66 then
                if v33 == 67 then
                    local v85 = UNNAMED_2819735065448[v24];
                    v29[v85] = v29[v85](v29[v85 + 1], v29[v85 + 2]);
                else
                    local v86 = UNNAMED_2819735090024[v24];
                    local v87 = UNNAMED_2819735031800[v24] + 1;

                    for i = 1, UNNAMED_2819735065448[v24] do
                        local v88 = u6(u7(v86, (u8(v86, 13))), 536870911);
                        local v89 = u7(v88, (u5(v88, 13)));
                        v86 = u6(u7(v89, (u8(v89, 14))), 536870911);
                        UNNAMED_2819735065448[v87] = u7(UNNAMED_2819735065448[v87], (u6(u5(v86, 0), 127)));
                        UNNAMED_2819735090024[v87] = u7(UNNAMED_2819735090024[v87], (u6(u5(v86, 7), 127)));
                        UNNAMED_2819735031800[v87] = u7(UNNAMED_2819735031800[v87], (u6(u5(v86, 14), 127)));
                        UNNAMED_2819735043896[v87] = u7(UNNAMED_2819735043896[v87], (u6(u5(v86, 21), 127)));
                        v87 = v87 + 1;
                        local _ = i;
                    end;

                    UNNAMED_2819735043896[v24] = 62;
                end;
            else
                v29[UNNAMED_2819735031800[v24]] = v29[UNNAMED_2819735065448[v24]] + UNNAMED_2819735056376[v24];
            end;

            v34 = 14;
            continue;
        elseif v34 == 3 then
            v34 = -1;

            if v33 >= 58 then
                v34 = 13;
                continue;
            end;

            if v33 >= 56 then
                v34 = 4;
                continue;
            end;

            if v33 == 55 then
                local v90 = UNNAMED_2819732806552[UNNAMED_2819735031800[v24]];
                v29[UNNAMED_2819735090024[v24]] = v90[5][v90[4]][v29[UNNAMED_2819735065448[v24]]];
            else
                v29[UNNAMED_2819735090024[v24]] = u7(v29[UNNAMED_2819735065448[v24]], UNNAMED_2819735028776[v24]);
            end;

            v34 = 12;
            continue;
        elseif v34 == 4 then
            v34 = -1;

            if v33 ~= 57 then
                v34 = 5;
                continue;
            end;

            v34 = 11;
            continue;
        elseif v34 == 5 then
            v34 = -1;
            v23 = UNNAMED_2819735031800[v24];
            v22 = UNNAMED_2819735065448[v24] + 1;
            v34 = 6;
            continue;
        elseif v34 == 6 then
            v34 = -1;

            if v23 ~= 138 then
                v34 = 7;
                continue;
            end;

            v34 = 10;
            continue;
        elseif v34 == 7 then
            v34 = -1;

            if v23 ~= 144 then
                v34 = 8;
                continue;
            end;

            v34 = 9;
            continue;
        elseif v34 == 8 then
            v34 = -1;

            if v23 ~= 156 then
                return;
            end;

            while true do
                local v91 = UNNAMED_2819735031800[v22];

                if v91 >= 69 then
                    if v91 >= 103 then
                        if v91 < 120 then
                            if v91 < 111 then
                                if v91 < 107 then
                                    if v91 < 105 then
                                        if v91 == 104 then
                                            if UNNAMED_2819735090024[v22] >= v29[UNNAMED_2819735043896[v22]] then
                                                v22 = UNNAMED_2819735065448[v22];
                                            end;
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = u7(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735080952[v22]);
                                        end;
                                    elseif v91 == 106 then
                                        v29[UNNAMED_2819735043896[v22]][UNNAMED_2819735065448[v22]] = UNNAMED_2819735056376[v22];
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] == UNNAMED_2819735080952[v22];
                                    end;
                                elseif v91 < 109 then
                                    if v91 == 108 then
                                        local v92 = UNNAMED_2819735043896[v22];
                                        local v93 = v29[UNNAMED_2819735090024[v22]];
                                        local v94 = u6(v29[UNNAMED_2819735065448[v22]], 4294967295);
                                        local v95 = u6(v93, 4294967295);
                                        local v96 = u6(v94, 65535);
                                        local v97 = u5(v94, 16);
                                        local v98 = u6(v95, 65535);
                                        local v99 = u5(v95, 16);
                                        local v100 = u6(v96 * v98 + u8(u6(v96 * v99 + v97 * v98, 65535), 16), 4294967295) % 4294967296;
                                        v29[v92] = v100 ~= v100 and 0 or v100 - v100 % 1;
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735065448[v22];
                                    end;
                                elseif v91 == 110 then
                                    if v29[UNNAMED_2819735043896[v22]] >= UNNAMED_2819735065448[v22] then
                                        v22 = UNNAMED_2819735090024[v22];
                                    end;
                                else
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]][v29[UNNAMED_2819735065448[v22]]];
                                end;
                            elseif v91 < 115 then
                                if v91 >= 113 then
                                    if v91 == 114 then
                                        v29[UNNAMED_2819735043896[v22]][UNNAMED_2819735056376[v22]] = UNNAMED_2819735065448[v22];
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] < v29[UNNAMED_2819735065448[v22]];
                                    end;
                                elseif v91 == 112 then
                                    v22 = v29[UNNAMED_2819735090024[v22]];
                                else
                                    local v101 = UNNAMED_2819732806552[UNNAMED_2819735090024[v22]];
                                    v101[5][v101[4]] = v29[UNNAMED_2819735065448[v22]];
                                end;
                            elseif v91 >= 117 then
                                if v91 < 118 then
                                    v29[UNNAMED_2819735065448[v22]](v29[UNNAMED_2819735090024[v22]]);
                                elseif v91 == 119 then
                                    v29[UNNAMED_2819735043896[v22]] = u14(v29[UNNAMED_2819735090024[v22]], v29[UNNAMED_2819735065448[v22]]);
                                else
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]]();
                                end;
                            elseif v91 == 116 then
                                v29[UNNAMED_2819735090024[v22]](UNNAMED_2819735071880[v22], v29[UNNAMED_2819735065448[v22]]);
                            elseif v26 then
                                local v102 = UNNAMED_2819735065448[v22];
                                local v103 = v26[v102];

                                if v103 then
                                    v103[5] = v103;
                                    v103[6] = v29[v102];
                                    v103[4] = 6;
                                    v26[v102] = nil;
                                end;

                                local v104 = UNNAMED_2819735090024[v22];
                                local v105 = v26[v104];

                                if v105 then
                                    v105[5] = v105;
                                    v105[6] = v29[v104];
                                    v105[4] = 6;
                                    v26[v104] = nil;
                                end;

                                local v106 = UNNAMED_2819735043896[v22];
                                local v107 = v26[v106];

                                if v107 then
                                    v107[5] = v107;
                                    v107[6] = v29[v106];
                                    v107[4] = 6;
                                    v26[v106] = nil;
                                end;
                            end;
                        elseif v91 >= 129 then
                            if v91 < 133 then
                                if v91 < 131 then
                                    if v91 == 130 then
                                        local v108 = UNNAMED_2819735043896[v22];
                                        u4(v29, v108 + 1, v108 + UNNAMED_2819735065448[v22], UNNAMED_2819735090024[v22] + 1, v29[v108]);
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = u18[UNNAMED_2819735080952[v22]];
                                    end;
                                elseif v91 == 132 then
                                    local v109 = nil;
                                    local v110 = UNNAMED_2819735090024[v22];
                                    local v111 = UNNAMED_2819735080952[v22];
                                    local v112 = UNNAMED_2819735071880[v22];
                                    local v113 = v112[0];

                                    if v113 then
                                        local v114 = #v113 / 3;

                                        if v114 > 0 then
                                            v109 = {};

                                            for i = 1, v114 do
                                                local v115 = (i - 1) * 3;
                                                local v116 = v113[v115 + 2];
                                                local v117 = v113[v115 + 1];
                                                local v118;

                                                if v116 == 2 then
                                                    v26 = v26 or {};
                                                    local v119 = v26[v117];

                                                    if not v119 then
                                                        v119 = {
                                                            [5] = v29,
                                                            [4] = v117
                                                        };
                                                        v26[v117] = v119;
                                                    end;

                                                    v109[i] = v119;
                                                    v118 = i;
                                                elseif v116 == 0 then
                                                    v109[i] = v29[v117];
                                                    v118 = i;
                                                elseif v116 == 3 then
                                                    v109[i] = UNNAMED_2819732806552[v117];
                                                    v118 = i;
                                                elseif v116 == 1 then
                                                    v32 = v32 or {};
                                                    local v120 = v32[v117];

                                                    if not v120 then
                                                        v120 = {
                                                            [5] = v29,
                                                            [4] = v117,
                                                            [6] = v113[v115 + 3]
                                                        };
                                                        v32[v117] = v120;
                                                    end;

                                                    v109[i] = v120;
                                                    v118 = i;
                                                else
                                                    v118 = i;
                                                end;
                                            end;
                                        end;
                                    end;

                                    local v121 = v112[-2];
                                    v112[v121] = v109;
                                    local v122 = v111(u3(v112, 1, v112[-1]));
                                    v112[v121] = nil;
                                    v29[v110] = v122;
                                else
                                    v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] <= v29[UNNAMED_2819735043896[v22]];
                                end;
                            elseif v91 < 135 then
                                if v91 == 134 then
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] % UNNAMED_2819735065448[v22];
                                else
                                    v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735043896[v22]] // v29[UNNAMED_2819735065448[v22]];
                                end;
                            elseif v91 >= 136 then
                                if v91 == 137 then
                                    if v26 then
                                        local v123 = UNNAMED_2819735043896[v22];
                                        local v124 = v26[v123];

                                        if v124 then
                                            v124[5] = v124;
                                            v124[6] = v29[v123];
                                            v124[4] = 6;
                                            v26[v123] = nil;
                                        end;

                                        local v125 = UNNAMED_2819735090024[v22];
                                        local v126 = v26[v125];

                                        if v126 then
                                            v126[5] = v126;
                                            v126[6] = v29[v125];
                                            v126[4] = 6;
                                            v26[v125] = nil;
                                        end;
                                    end;
                                else
                                    v29[UNNAMED_2819735090024[v22]] = u5(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735065448[v22]);
                                end;
                            else
                                v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735050328[UNNAMED_2819735056376[v22]];
                            end;
                        elseif v91 < 124 then
                            if v91 < 122 then
                                if v91 == 121 then
                                    local v127 = UNNAMED_2819735065448[v22];
                                    local v128 = u15(u16);
                                    v128(UNNAMED_2819735050328, v29[v127], v29[v127 + 1], v29[v127 + 2]);
                                    local v129 = UNNAMED_2819735090024[v22];
                                    v22 = UNNAMED_2819735043896[v22];
                                    v27 = v128;
                                    v25 = v129;
                                    v30 = {
                                        [9] = v30,
                                        [7] = v28,
                                        [8] = v27,
                                        [5] = v31,
                                        [6] = v25
                                    };
                                else
                                    v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] * UNNAMED_2819735056376[v22];
                                end;
                            elseif v91 == 123 then
                                UNNAMED_2819735050328[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]];
                            else
                                v29[UNNAMED_2819735090024[v22]] = not v29[UNNAMED_2819735043896[v22]];
                            end;
                        elseif v91 >= 126 then
                            if v91 < 127 then
                                local v130 = UNNAMED_2819735090024[v22];
                                local v131 = UNNAMED_2819735065448[v22];
                                local v132 = UNNAMED_2819735053352[5];
                                local v133 = u7(v132[v130], 109162203);
                                v132[v130] = v133;
                                local v134 = UNNAMED_2819735053352[4];
                                local v135 = v133 + 1;
                                local v136 = u9(v134, v135);
                                local v137;

                                if v136 < 128 then
                                    v137 = v135 + 1;
                                else
                                    local v138 = u9(v134, v135 + 1);

                                    if v138 < 128 then
                                        v136 = v136 - 128 + v138 * 128;
                                        v137 = v135 + 2;
                                    else
                                        local v139 = u9(v134, v135 + 2);

                                        if v139 < 128 then
                                            v136 = v136 - 128 + (v138 - 128) * 16384 + v139 * 128;
                                            v137 = v135 + 3;
                                        else
                                            local v140 = u9(v134, v135 + 3);
                                            v136 = (v136 - 128) * 16384 + (v138 - 128) * 128 + (v139 - 128) + v140 % 128 * 2097152 + (v140 - v140 % 128) * 2097152;
                                            v137 = v135 + 4;
                                        end;
                                    end;
                                end;

                                local v141 = v131 * 16843009;
                                local v142 = v137 + v136;
                                local v143 = v142 - v136 % 4;

                                for i = v137, v143 - 1, 4 do
                                    u10(v134, i, (u7(u11(v134, i), v141)));
                                    local _ = i;
                                end;

                                for i = v143, v142 - 1 do
                                    u12(v134, i, (u7(u9(v134, i), v131)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735090024[v22] = 221;
                                UNNAMED_2819735065448[v22] = 131;
                                UNNAMED_2819735043896[v22] = 226;
                                UNNAMED_2819735031800[v22] = 11;
                            elseif v91 == 128 then
                                local v144 = UNNAMED_2819732806552[UNNAMED_2819735090024[v22]];
                                v29[UNNAMED_2819735043896[v22]] = v144[5][v144[4]][v29[UNNAMED_2819735065448[v22]]];
                            else
                                v29[UNNAMED_2819735043896[v22]][UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]];
                            end;
                        elseif v91 == 125 then
                            v29[UNNAMED_2819735090024[v22]] = u14(v29[UNNAMED_2819735065448[v22]], UNNAMED_2819735071880[v22]);
                        else
                            v29[UNNAMED_2819735065448[v22]] = u7(v29[UNNAMED_2819735043896[v22]], v29[UNNAMED_2819735090024[v22]]);
                        end;
                    elseif v91 >= 86 then
                        if v91 < 94 then
                            if v91 >= 90 then
                                if v91 < 92 then
                                    if v91 == 91 then
                                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] + UNNAMED_2819735043896[v22];
                                    else
                                        v29[UNNAMED_2819735090024[v22]](v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735080952[v22]);
                                    end;
                                else
                                    if v91 ~= 93 then
                                        if v26 then
                                            for i in u17, v26 do
                                                local v145 = v26[i];

                                                if v145 then
                                                    v145[5] = v145;
                                                    v145[6] = v29[i];
                                                    v145[4] = 6;
                                                    v26[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v32 then
                                            for i, v in u17, v32 do
                                                local v146 = v[6];

                                                if v32 then
                                                    local v147 = v32[i];

                                                    if v147 then
                                                        local v148 = u1(v146);
                                                        u4(v29, i, i + v146 - 1, 1, v148);
                                                        v147[5] = v148;
                                                        v147[4] = 1;
                                                        v32[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return;
                                    end;

                                    local v149 = UNNAMED_2819735090024[v22];
                                    local v150 = UNNAMED_2819735065448[v22];
                                    local v151 = UNNAMED_2819735043896[v22];
                                    local v152 = u7(v20, u6(u5(v20, 14), 262143), (u6(u5(v20, 28), 15)));
                                    local v153 = v149 < 2097152 and 7 or 14;
                                    local v154 = u5(v149, v153);
                                    local v155 = u6(v149, u8(1, v153) - 1);
                                    UNNAMED_2819735043896[v22] = u7(v151, 17, (u6(u5(v152, 7), 127)));
                                    UNNAMED_2819735031800[v22] = u7(v154, 102, (u6(u5(v152, 21), 127)));
                                    UNNAMED_2819735065448[v22] = u7(v150, 100, (u6(u5(v152, 14), 127)));
                                    UNNAMED_2819735090024[v22] = u7(v155, 69, (u6(v152, 127)));
                                    v22 = v22 - 1;
                                end;
                            elseif v91 >= 88 then
                                if v91 == 89 then
                                    if v29[UNNAMED_2819735090024[v22]] > UNNAMED_2819735043896[v22] then
                                        v22 = UNNAMED_2819735065448[v22];
                                    end;
                                else
                                    v29[UNNAMED_2819735065448[v22]][v29[UNNAMED_2819735043896[v22]]] = UNNAMED_2819735056376[v22];
                                end;
                            elseif v91 == 87 then
                                v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735050328;
                            else
                                local v156 = UNNAMED_2819735043896[v22];
                                local v157, v158 = v27();

                                if v157 then
                                    v29[v156] = v158;
                                    v22 = UNNAMED_2819735090024[v22];
                                else
                                    v22 = UNNAMED_2819735065448[v22];
                                end;
                            end;
                        elseif v91 >= 98 then
                            if v91 >= 100 then
                                if v91 >= 101 then
                                    if v91 == 102 then
                                        if v26 then
                                            for i in u17, v26 do
                                                local v159 = v26[i];

                                                if v159 then
                                                    v159[5] = v159;
                                                    v159[6] = v29[i];
                                                    v159[4] = 6;
                                                    v26[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v32 then
                                            for i, v in u17, v32 do
                                                local v160 = v[6];

                                                if v32 then
                                                    local v161 = v32[i];

                                                    if v161 then
                                                        local v162 = u1(v160);
                                                        u4(v29, i, i + v160 - 1, 1, v162);
                                                        v161[5] = v162;
                                                        v161[4] = 1;
                                                        v32[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return v29[UNNAMED_2819735043896[v22]];
                                    end;

                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] * v29[UNNAMED_2819735065448[v22]];
                                elseif UNNAMED_2819735065448[v22] > v29[UNNAMED_2819735090024[v22]] then
                                    v22 = UNNAMED_2819735043896[v22];
                                end;
                            elseif v91 == 99 then
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] // UNNAMED_2819735065448[v22];
                            else
                                local v163 = UNNAMED_2819735065448[v22];
                                local v164, v165, v166 = v27();

                                if v164 then
                                    v29[v163] = v165;
                                    v29[v163 + 1] = v166;
                                    v22 = UNNAMED_2819735090024[v22];
                                else
                                    v22 = UNNAMED_2819735043896[v22];
                                end;
                            end;
                        elseif v91 < 96 then
                            if v91 == 95 then
                                local v167 = UNNAMED_2819735065448[v22];
                                local v168 = UNNAMED_2819735090024[v22];
                                local v169 = UNNAMED_2819735043896[v22];
                                local _ = v167 + v169 - 1;
                                local v170 = v167 + v168;
                                local v171 = v29[v170];
                                local n = v171.n;
                                v171.n = v168 + n - 1;
                                u4(v171, 1, n, v168, v171);
                                u4(v29, v167 + 1, v170 - 1, 1, v171);
                                u4(u2(v29[v167](u3(v171, 1, v171.n))), 1, v169, v167, v29);
                            else
                                local v172 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                v172[5][v172[4]] = UNNAMED_2819735071880[v22];
                            end;
                        elseif v91 == 97 then
                            v29[UNNAMED_2819735090024[v22]]();
                        else
                            v29[UNNAMED_2819735043896[v22]] = u7(UNNAMED_2819735056376[v22], UNNAMED_2819735080952[v22]);
                        end;
                    elseif v91 < 77 then
                        if v91 < 73 then
                            if v91 < 71 then
                                if v91 == 70 then
                                    v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]][UNNAMED_2819735071880[v22]];
                                else
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] >= v29[UNNAMED_2819735090024[v22]];
                                end;
                            elseif v91 == 72 then
                                v29[UNNAMED_2819735065448[v22]] = {};
                            else
                                local v173 = UNNAMED_2819735090024[v22];
                                local _ = UNNAMED_2819735043896[v22];
                                v29[v173] = u2(v29[v173](u3(v29, v173 + 1, v173 + UNNAMED_2819735065448[v22])));
                            end;
                        elseif v91 >= 75 then
                            if v91 == 76 then
                                v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] == UNNAMED_2819735043896[v22];
                            else
                                v29[UNNAMED_2819735043896[v22]] = u6(v29[UNNAMED_2819735090024[v22]], v29[UNNAMED_2819735065448[v22]]);
                            end;
                        else
                            if v91 == 74 then
                                if v26 then
                                    for i in u17, v26 do
                                        local v174 = v26[i];

                                        if v174 then
                                            v174[5] = v174;
                                            v174[6] = v29[i];
                                            v174[4] = 6;
                                            v26[i] = nil;
                                        end;
                                    end;
                                end;

                                if v32 then
                                    for i, v in u17, v32 do
                                        local v175 = v[6];

                                        if v32 then
                                            local v176 = v32[i];

                                            if v176 then
                                                local v177 = u1(v175);
                                                u4(v29, i, i + v175 - 1, 1, v177);
                                                v176[5] = v177;
                                                v176[4] = 1;
                                                v32[i] = nil;
                                            end;
                                        end;
                                    end;
                                end;

                                return UNNAMED_2819735080952[v22];
                            end;

                            v29[UNNAMED_2819735043896[v22]] = u1(UNNAMED_2819735090024[v22]);
                        end;
                    elseif v91 >= 81 then
                        if v91 >= 83 then
                            if v91 >= 84 then
                                if v91 == 85 then
                                    local v178 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                    v29[UNNAMED_2819735090024[v22]] = v178[5][v178[4]];
                                else
                                    v21 = v29[UNNAMED_2819735065448[v22]];
                                end;
                            else
                                v29[UNNAMED_2819735043896[v22]] = u6(v29[UNNAMED_2819735065448[v22]], UNNAMED_2819735090024[v22]);
                            end;
                        elseif v91 == 82 then
                            local v179 = UNNAMED_2819735065448[v22];
                            local v180 = UNNAMED_2819735090024[v22] + 1;

                            for i = 1, UNNAMED_2819735043896[v22] do
                                local v181 = u6(u7(v179, (u8(v179, 13))), 536870911);
                                local v182 = u7(v181, (u5(v181, 13)));
                                v179 = u6(u7(v182, (u8(v182, 14))), 536870911);
                                UNNAMED_2819735090024[v180] = u7(UNNAMED_2819735090024[v180], (u6(u5(v179, 0), 127)));
                                UNNAMED_2819735043896[v180] = u7(UNNAMED_2819735043896[v180], (u6(u5(v179, 7), 127)));
                                UNNAMED_2819735065448[v180] = u7(UNNAMED_2819735065448[v180], (u6(u5(v179, 14), 127)));
                                UNNAMED_2819735031800[v180] = u7(UNNAMED_2819735031800[v180], (u6(u5(v179, 21), 127)));
                                v180 = v180 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735031800[v22] = 11;
                        else
                            local v183 = UNNAMED_2819735090024[v22];
                            local v184 = UNNAMED_2819735071880[v22];
                            local v185 = u6(UNNAMED_2819735080952[v22], 4294967295);
                            local v186 = u6(v184, 4294967295);
                            local v187 = u6(v185, 65535);
                            local v188 = u5(v185, 16);
                            local v189 = u6(v186, 65535);
                            local v190 = u5(v186, 16);
                            local v191 = u6(v187 * v189 + u8(u6(v187 * v190 + v188 * v189, 65535), 16), 4294967295) % 4294967296;
                            v29[v183] = v191 ~= v191 and 0 or v191 - v191 % 1;
                        end;
                    elseif v91 < 79 then
                        if v91 == 78 then
                            v29[UNNAMED_2819735065448[v22]] = v29;
                        else
                            UNNAMED_2819735050328[UNNAMED_2819735071880[v22]] = v29[UNNAMED_2819735065448[v22]];
                        end;
                    elseif v91 == 80 then
                        local v192 = UNNAMED_2819735065448[v22];
                        local v193 = UNNAMED_2819735043896[v22];
                        local v194 = UNNAMED_2819735090024[v22];
                        local v195 = v29[v192];
                        local v196 = v192 + v193;
                        local v197 = v29[v196];
                        u4(v29, v192 + 1, v196 - 1, v194 + 1, v195);
                        u4(v197, 1, v197.n, v194 + v193, v195);
                    else
                        v29[UNNAMED_2819735090024[v22]](v29[UNNAMED_2819735065448[v22]], v29[UNNAMED_2819735043896[v22]]);
                    end;
                elseif v91 >= 34 then
                    if v91 >= 51 then
                        if v91 >= 60 then
                            if v91 < 64 then
                                if v91 < 62 then
                                    if v91 == 61 then
                                        v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735090024[v22] + v29[UNNAMED_2819735065448[v22]];
                                    else
                                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] - UNNAMED_2819735056376[v22];
                                    end;
                                elseif v91 == 63 then
                                    v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735071880[v22];
                                else
                                    local v198 = UNNAMED_2819735065448[v22];
                                    local v199 = UNNAMED_2819735090024[v22];
                                    local v200 = UNNAMED_2819735043896[v22];
                                    local _ = v198 + v200 - 1;
                                    local _ = v198 + v199;
                                    u4(u2(v29[v198](u3(v29, v198 + 1, v198 + v199))), 1, v200, v198, v29);
                                end;
                            elseif v91 < 66 then
                                if v91 == 65 then
                                    v20 = v29[UNNAMED_2819735065448[v22]];
                                else
                                    local v201 = UNNAMED_2819735043896[v22];
                                    local v202 = v29[UNNAMED_2819735065448[v22]];
                                    v29[v201 + 1] = v202;
                                    v29[v201] = v202[UNNAMED_2819735056376[v22]];
                                end;
                            elseif v91 >= 67 then
                                if v91 == 68 then
                                    v29[UNNAMED_2819735065448[v22]][v29[UNNAMED_2819735090024[v22]]] = v29[UNNAMED_2819735043896[v22]];
                                elseif v29[UNNAMED_2819735090024[v22]] ~= UNNAMED_2819735065448[v22] then
                                    v22 = UNNAMED_2819735043896[v22];
                                end;
                            else
                                v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] * UNNAMED_2819735090024[v22];
                            end;
                        elseif v91 >= 55 then
                            if v91 >= 57 then
                                if v91 >= 58 then
                                    if v91 == 59 then
                                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] - v29[UNNAMED_2819735090024[v22]];
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = u18[UNNAMED_2819735080952[v22]][UNNAMED_2819735056376[v22]];
                                    end;
                                else
                                    v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735056376[v22] + UNNAMED_2819735071880[v22];
                                end;
                            else
                                if v91 ~= 56 then
                                    if v26 then
                                        for i in u17, v26 do
                                            local v203 = v26[i];

                                            if v203 then
                                                v203[5] = v203;
                                                v203[6] = v29[i];
                                                v203[4] = 6;
                                                v26[i] = nil;
                                            end;
                                        end;
                                    end;

                                    if v32 then
                                        for i, v in u17, v32 do
                                            local v204 = v[6];

                                            if v32 then
                                                local v205 = v32[i];

                                                if v205 then
                                                    local v206 = u1(v204);
                                                    u4(v29, i, i + v204 - 1, 1, v206);
                                                    v205[5] = v206;
                                                    v205[4] = 1;
                                                    v32[i] = nil;
                                                end;
                                            end;
                                        end;
                                    end;

                                    return v29[UNNAMED_2819735065448[v22]], v29[UNNAMED_2819735043896[v22]];
                                end;

                                if v29[UNNAMED_2819735065448[v22]] then
                                    v22 = UNNAMED_2819735090024[v22];
                                else
                                    v22 = UNNAMED_2819735043896[v22];
                                end;
                            end;
                        elseif v91 < 53 then
                            if v91 == 52 then
                                v29[UNNAMED_2819735065448[v22]] = v21;
                            else
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]][UNNAMED_2819735090024[v22]];
                            end;
                        elseif v91 == 54 then
                            v29[UNNAMED_2819735043896[v22]](UNNAMED_2819735080952[v22], UNNAMED_2819735056376[v22]);
                            v29[UNNAMED_2819735043896[v22 + 1]] = UNNAMED_2819735065448[v22 + 1];
                            v29[UNNAMED_2819735090024[v22 + 2]]();
                            v22 = v22 + 2;
                        else
                            v29[UNNAMED_2819735043896[v22]][UNNAMED_2819735080952[v22]] = v29[UNNAMED_2819735090024[v22]];
                        end;
                    elseif v91 < 42 then
                        if v91 < 38 then
                            if v91 >= 36 then
                                if v91 == 37 then
                                    v29[UNNAMED_2819735043896[v22]][UNNAMED_2819735090024[v22]] = UNNAMED_2819735065448[v22];
                                else
                                    v29[UNNAMED_2819735043896[v22]] = v20;
                                end;
                            elseif v91 == 35 then
                                v27 = v30[8];
                                v31 = v30[5];
                                v28 = v30[7];
                                v25 = v30[6];
                                v30 = v30[9];
                            else
                                v29[UNNAMED_2819735043896[v22]](UNNAMED_2819735080952[v22], UNNAMED_2819735056376[v22]);
                            end;
                        elseif v91 >= 40 then
                            if v91 == 41 then
                                v29[UNNAMED_2819735043896[v22]] = #v29[UNNAMED_2819735065448[v22]];
                            else
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] ~= UNNAMED_2819735080952[v22];
                            end;
                        elseif v91 == 39 then
                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] + v29[UNNAMED_2819735043896[v22]];
                        else
                            local v207 = UNNAMED_2819735090024[v22];
                            local v208 = UNNAMED_2819735065448[v22];
                            v29[v207] = UNNAMED_2819735071880[v22];
                            v29[v207 + 1] = v208;
                        end;
                    elseif v91 >= 46 then
                        if v91 >= 48 then
                            if v91 < 49 then
                                v29[UNNAMED_2819735043896[v22]](UNNAMED_2819735080952[v22], UNNAMED_2819735056376[v22]);
                                v29[UNNAMED_2819735043896[v22 + 1]] = UNNAMED_2819735065448[v22 + 1];
                                v29[UNNAMED_2819735090024[v22 + 2]]();
                                v29[UNNAMED_2819735043896[v22 + 3]] = UNNAMED_2819735065448[v22 + 3];
                                v22 = v22 + 3;
                            elseif v91 == 50 then
                                local v209 = UNNAMED_2819735043896[v22];
                                local v210 = UNNAMED_2819735056376[v22];
                                v29[v209] = UNNAMED_2819735065448[v22];
                                v29[v209 + 1] = v210;
                            else
                                local v211 = UNNAMED_2819735090024[v22];
                                local v212 = v29[UNNAMED_2819735065448[v22]];
                                v29[v211] = UNNAMED_2819735043896[v22];
                                v29[v211 + 1] = v212;
                            end;
                        elseif v91 == 47 then
                            v29[UNNAMED_2819735090024[v22]](v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735080952[v22]);
                            v29[UNNAMED_2819735090024[v22 + 1]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v22 + 1]];
                            v29[UNNAMED_2819735090024[v22 + 2]](v29[UNNAMED_2819735043896[v22 + 2]], UNNAMED_2819735080952[v22 + 2]);
                            v22 = v22 + 2;
                        elseif v29[UNNAMED_2819735043896[v22]] then
                            v22 = UNNAMED_2819735065448[v22];
                        else
                            v22 = UNNAMED_2819735090024[v22];
                        end;
                    elseif v91 >= 44 then
                        if v91 == 45 then
                            local v213 = UNNAMED_2819735090024[v22];
                            local v214 = v29[UNNAMED_2819735043896[v22]];
                            v29[v213] = UNNAMED_2819735080952[v22];
                            v29[v213 + 1] = v214;
                        else
                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] ~= UNNAMED_2819735090024[v22];
                        end;
                    elseif v91 == 43 then
                        v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v22]];
                        v29[UNNAMED_2819735090024[v22 + 1]](v29[UNNAMED_2819735043896[v22 + 1]], UNNAMED_2819735080952[v22 + 1]);
                        v29[UNNAMED_2819735090024[v22 + 2]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v22 + 2]];
                        v22 = v22 + 2;
                    else
                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] <= UNNAMED_2819735043896[v22];
                    end;
                elseif v91 >= 17 then
                    if v91 >= 25 then
                        if v91 < 29 then
                            if v91 < 27 then
                                if v91 == 26 then
                                    v22 = UNNAMED_2819735065448[v22];
                                else
                                    v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735056376[v22] + v29[UNNAMED_2819735043896[v22]];
                                end;
                            elseif v91 == 28 then
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] - UNNAMED_2819735090024[v22];
                            else
                                local v215 = UNNAMED_2819735043896[v22];
                                local v216 = UNNAMED_2819735090024[v22];
                                local v217 = UNNAMED_2819735065448[v22];
                                local v218 = u7(v20, u6(u5(v20, 14), 262143), (u6(u5(v20, 28), 15)));
                                local v219 = v217 < 16384 and 7 or (v217 < 2097152 and 14 or 21);
                                local v220 = u6(v217, u8(1, v219) - 1);
                                UNNAMED_2819735031800[v22] = u7(u5(v217, v219), 104, (u6(u5(v218, 21), 127)));
                                UNNAMED_2819735043896[v22] = u7(v215, 5, (u6(u5(v218, 7), 127)));
                                UNNAMED_2819735065448[v22] = u7(v220, 49, (u6(u5(v218, 14), 127)));
                                UNNAMED_2819735090024[v22] = u7(v216, 2, (u6(v218, 127)));
                                v22 = v22 - 1;
                            end;
                        elseif v91 >= 31 then
                            if v91 >= 32 then
                                if v91 == 33 then
                                    local v221 = v29[UNNAMED_2819735043896[v22]] % 4294967296;
                                    v29[UNNAMED_2819735090024[v22]] = v221 ~= v221 and 0 or v221 - v221 % 1;
                                elseif v26 then
                                    local v222 = UNNAMED_2819735043896[v22];
                                    local v223 = v26[v222];

                                    if v223 then
                                        v223[5] = v223;
                                        v223[6] = v29[v222];
                                        v223[4] = 6;
                                        v26[v222] = nil;
                                    end;
                                end;
                            else
                                local v224 = u7(UNNAMED_2819735043896[v22], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                                local v225 = UNNAMED_2819735090024[v22] + 1;

                                for i = 1, UNNAMED_2819735065448[v22] do
                                    local v226 = u6(u7(v224, (u8(v224, 13))), 536870911);
                                    local v227 = u7(v226, (u5(v226, 13)));
                                    v224 = u6(u7(v227, (u8(v227, 14))), 536870911);
                                    UNNAMED_2819735090024[v225] = u7(UNNAMED_2819735090024[v225], (u6(u5(v224, 0), 127)));
                                    UNNAMED_2819735043896[v225] = u7(UNNAMED_2819735043896[v225], (u6(u5(v224, 7), 127)));
                                    UNNAMED_2819735065448[v225] = u7(UNNAMED_2819735065448[v225], (u6(u5(v224, 14), 127)));
                                    UNNAMED_2819735031800[v225] = u7(UNNAMED_2819735031800[v225], (u6(u5(v224, 21), 127)));
                                    v225 = v225 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735031800[v22] = 11;
                            end;
                        elseif v91 == 30 then
                            v29[UNNAMED_2819735043896[v22]] = u19(v29[UNNAMED_2819735090024[v22]]);
                        else
                            local v228 = u7(UNNAMED_2819735043896[v22], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                            local v229 = UNNAMED_2819735090024[v22] + 1;

                            for i = 1, UNNAMED_2819735065448[v22] do
                                local v230 = u6(u7(v228, (u8(v228, 13))), 536870911);
                                local v231 = u7(v230, (u5(v230, 13)));
                                v228 = u6(u7(v231, (u8(v231, 14))), 536870911);
                                UNNAMED_2819735090024[v229] = u7(UNNAMED_2819735090024[v229], (u6(u5(v228, 0), 127)));
                                UNNAMED_2819735043896[v229] = u7(UNNAMED_2819735043896[v229], (u6(u5(v228, 7), 127)));
                                UNNAMED_2819735065448[v229] = u7(UNNAMED_2819735065448[v229], (u6(u5(v228, 14), 127)));
                                UNNAMED_2819735031800[v229] = u7(UNNAMED_2819735031800[v229], (u6(u5(v228, 21), 127)));
                                v229 = v229 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735031800[v22] = 11;
                        end;
                    elseif v91 < 21 then
                        if v91 < 19 then
                            if v91 == 18 then
                                v29[UNNAMED_2819735090024[v22]][UNNAMED_2819735080952[v22]] = UNNAMED_2819735071880[v22];
                            else
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] + UNNAMED_2819735080952[v22];
                            end;
                        elseif v91 == 20 then
                            local v232 = UNNAMED_2819735065448[v22];
                            local v233 = UNNAMED_2819735090024[v22];
                            v29[v232] = UNNAMED_2819735043896[v22];
                            v29[v232 + 1] = v233;
                        else
                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] < UNNAMED_2819735090024[v22];
                        end;
                    elseif v91 < 23 then
                        if v91 == 22 then
                            v29[UNNAMED_2819735065448[v22]] = u7(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735090024[v22]);
                        else
                            local v234 = UNNAMED_2819735065448[v22];
                            local v235 = UNNAMED_2819735071880[v22];
                            v29[v234] = UNNAMED_2819735056376[v22];
                            v29[v234 + 1] = v235;
                        end;
                    elseif v91 == 24 then
                        for i = UNNAMED_2819735090024[v22], UNNAMED_2819735043896[v22] do
                            v29[i] = nil;
                            local _ = i;
                        end;
                    else
                        v30 = {
                            [9] = v30,
                            [7] = v28,
                            [8] = v27,
                            [5] = v31,
                            [6] = v25
                        };
                        local v236 = UNNAMED_2819735043896[v22];
                        v28 = v29[v236 + 2] + 0;
                        v31 = v29[v236 + 1] + 0;
                        v27 = v29[v236] - v28;
                        v22 = UNNAMED_2819735090024[v22];
                    end;
                elseif v91 >= 8 then
                    if v91 >= 12 then
                        if v91 < 14 then
                            if v91 == 13 then
                                v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735043896[v22] * v29[UNNAMED_2819735090024[v22]];
                            else
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]];
                            end;
                        elseif v91 < 15 then
                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]](v29[UNNAMED_2819735090024[v22]]);
                        elseif v91 == 16 then
                            v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v22]];
                        else
                            v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735090024[v22] - v29[UNNAMED_2819735043896[v22]];
                        end;
                    elseif v91 < 10 then
                        if v91 == 9 then
                            if v26 then
                                for i in u17, v26 do
                                    local v237 = v26[i];

                                    if v237 then
                                        v237[5] = v237;
                                        v237[6] = v29[i];
                                        v237[4] = 6;
                                        v26[i] = nil;
                                    end;
                                end;
                            end;

                            if v32 then
                                for i, v in u17, v32 do
                                    local v238 = v[6];

                                    if v32 then
                                        local v239 = v32[i];

                                        if v239 then
                                            local v240 = u1(v238);
                                            u4(v29, i, i + v238 - 1, 1, v240);
                                            v239[5] = v240;
                                            v239[4] = 1;
                                            v32[i] = nil;
                                        end;
                                    end;
                                end;
                            end;

                            return v29[UNNAMED_2819735090024[v22]](u3(v29[UNNAMED_2819735065448[v22]], 1, v29[UNNAMED_2819735065448[v22]].n));
                        end;

                        local v241 = UNNAMED_2819735043896[v22];
                        local v242 = v29[UNNAMED_2819735065448[v22]];
                        v29[v241] = v29[UNNAMED_2819735090024[v22]];
                        v29[v241 + 1] = v242;
                    elseif v91 ~= 11 then
                        v29[UNNAMED_2819735065448[v22]](v29[UNNAMED_2819735090024[v22]]);
                        v29[UNNAMED_2819735090024[v22 + 1]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v22 + 1]];
                        v29[UNNAMED_2819735065448[v22 + 2]](v29[UNNAMED_2819735090024[v22 + 2]]);
                        v29[UNNAMED_2819735090024[v22 + 3]] = UNNAMED_2819735050328[UNNAMED_2819735065448[v22 + 3]];
                        v22 = v22 + 3;
                    end;
                elseif v91 < 4 then
                    if v91 >= 2 then
                        if v91 == 3 then
                            v27 = v27 + v28;
                            local v243;

                            if v28 <= 0 then
                                v243 = v31 <= v27;
                            else
                                v243 = v27 <= v31;
                            end;

                            if v243 then
                                v29[UNNAMED_2819735065448[v22]] = v27;
                                v22 = UNNAMED_2819735090024[v22];
                            else
                                v22 = UNNAMED_2819735043896[v22];
                            end;
                        else
                            local v244 = UNNAMED_2819735090024[v22];
                            local v245 = UNNAMED_2819735043896[v22];
                            local _ = UNNAMED_2819735065448[v22];
                            local v246 = v244 + v245;
                            local v247 = v29[v246];
                            local n = v247.n;
                            v247.n = v245 + n - 1;
                            u4(v247, 1, n, v245, v247);
                            u4(v29, v244 + 1, v246 - 1, 1, v247);
                            v29[v244] = u2(v29[v244](u3(v247, 1, v247.n)));
                        end;
                    elseif v91 == 1 then
                        v29[UNNAMED_2819735065448[v22]](UNNAMED_2819735071880[v22]);
                    else
                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]](UNNAMED_2819735071880[v22]);
                    end;
                elseif v91 < 6 then
                    if v91 == 5 then
                        v29[UNNAMED_2819735090024[v22]] = u8(v29[UNNAMED_2819735065448[v22]], UNNAMED_2819735043896[v22]);
                    else
                        UNNAMED_2819735050328[UNNAMED_2819735056376[v22]] = UNNAMED_2819735080952[v22];
                    end;
                elseif v91 == 7 then
                    local v248 = UNNAMED_2819735065448[v22];
                    local v249 = v29[UNNAMED_2819735090024[v22]];
                    local v250 = u6(UNNAMED_2819735071880[v22], 4294967295);
                    local v251 = u6(v249, 4294967295);
                    local v252 = u6(v250, 65535);
                    local v253 = u5(v250, 16);
                    local v254 = u6(v251, 65535);
                    local v255 = u5(v251, 16);
                    local v256 = u6(v252 * v254 + u8(u6(v252 * v255 + v253 * v254, 65535), 16), 4294967295) % 4294967296;
                    v29[v248] = v256 ~= v256 and 0 or v256 - v256 % 1;
                else
                    v22 = v29[UNNAMED_2819735043896[v22]];
                end;

                v22 = v22 + 1;
            end;

            v34 = 9;
            continue;
        elseif v34 == 9 then
            v34 = -1;

            while true do
                local v22;
                local v257 = 0;

                while true do
                    if v257 == 0 then
                        v257 = -1;
                        local v258 = UNNAMED_2819735031800[v22];

                        if v258 >= 69 then
                            if v258 < 103 then
                                if v258 >= 86 then
                                    if v258 < 94 then
                                        if v258 < 90 then
                                            if v258 >= 88 then
                                                if v258 == 89 then
                                                    v29[UNNAMED_2819735065448[v22]](UNNAMED_2819735071880[v22], v29[UNNAMED_2819735090024[v22]]);
                                                else
                                                    v29[UNNAMED_2819735090024[v22]][UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]];
                                                end;
                                            elseif v258 == 87 then
                                                local v259 = UNNAMED_2819735065448[v22];
                                                local v260 = v29[UNNAMED_2819735043896[v22]];
                                                v29[v259] = v29[UNNAMED_2819735090024[v22]];
                                                v29[v259 + 1] = v260;
                                            else
                                                local v261 = UNNAMED_2819735043896[v22];
                                                local v262 = v29[UNNAMED_2819735090024[v22]];
                                                v29[v261 + 1] = v262;
                                                v29[v261] = v262[UNNAMED_2819735080952[v22]];
                                            end;
                                        elseif v258 >= 92 then
                                            if v258 == 93 then
                                                v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735090024[v22];
                                            else
                                                v20 = v29[UNNAMED_2819735065448[v22]];
                                            end;
                                        elseif v258 == 91 then
                                            local v263 = UNNAMED_2819732806552[UNNAMED_2819735090024[v22]];
                                            v29[UNNAMED_2819735043896[v22]] = v263[5][v263[4]][UNNAMED_2819735080952[v22]];
                                        else
                                            v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735090024[v22] % v29[UNNAMED_2819735043896[v22]];
                                        end;
                                    elseif v258 < 98 then
                                        if v258 >= 96 then
                                            if v258 == 97 then
                                                if v29[UNNAMED_2819735065448[v22]] then
                                                    v22 = UNNAMED_2819735090024[v22];
                                                else
                                                    v22 = UNNAMED_2819735043896[v22];
                                                end;
                                            elseif v29[UNNAMED_2819735065448[v22]] >= UNNAMED_2819735090024[v22] then
                                                v22 = UNNAMED_2819735043896[v22];
                                            end;
                                        elseif v258 == 95 then
                                            v29[UNNAMED_2819735090024[v22]](UNNAMED_2819735080952[v22]);
                                        elseif v29[UNNAMED_2819735065448[v22]] >= v29[UNNAMED_2819735043896[v22]] then
                                            v22 = UNNAMED_2819735090024[v22];
                                        end;
                                    elseif v258 < 100 then
                                        if v258 == 99 then
                                            v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735050328[UNNAMED_2819735043896[v22]];
                                        else
                                            v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]][UNNAMED_2819735056376[v22]];
                                        end;
                                    elseif v258 < 101 then
                                        v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735071880[v22] + UNNAMED_2819735056376[v22];
                                    elseif v258 == 102 then
                                        v29[UNNAMED_2819735090024[v22]] = u1(UNNAMED_2819735043896[v22]);
                                    else
                                        local v264 = UNNAMED_2819735043896[v22];
                                        local v265 = UNNAMED_2819735065448[v22];
                                        local v266 = UNNAMED_2819735090024[v22];
                                        local _ = v264 + v266 - 1;
                                        local _ = v264 + v265;
                                        u4(u2(v29[v264](u3(v29, v264 + 1, v264 + v265))), 1, v266, v264, v29);
                                    end;
                                elseif v258 >= 77 then
                                    if v258 < 81 then
                                        if v258 >= 79 then
                                            if v258 == 80 then
                                                local v267 = UNNAMED_2819735065448[v22];
                                                local v268 = u7(v21, u6(u5(v21, 14), 262143), (u6(u5(v21, 28), 15)));
                                                local v269 = UNNAMED_2819735043896[v22];
                                                local v270 = UNNAMED_2819735090024[v22];
                                                local v271 = v269 < 16384 and 7 or (v269 < 2097152 and 14 or 21);
                                                local v272 = u6(v269, u8(1, v271) - 1);
                                                local v273 = u5(v269, v271);
                                                UNNAMED_2819735090024[v22] = u7(v270, 97, (u6(u5(v268, 7), 127)));
                                                UNNAMED_2819735031800[v22] = u7(v273, 120, (u6(u5(v268, 21), 127)));
                                                UNNAMED_2819735043896[v22] = u7(v272, 63, (u6(v268, 127)));
                                                UNNAMED_2819735065448[v22] = u7(v267, 93, (u6(u5(v268, 14), 127)));
                                                v22 = v22 - 1;
                                            else
                                                v27 = v30[8];
                                                v31 = v30[5];
                                                v28 = v30[7];
                                                v25 = v30[6];
                                                v30 = v30[9];
                                            end;
                                        elseif v258 == 78 then
                                            local v274 = UNNAMED_2819735090024[v22];
                                            local v275 = v29[UNNAMED_2819735043896[v22]];
                                            local v276 = u6(UNNAMED_2819735065448[v22], 4294967295);
                                            local v277 = u6(v275, 4294967295);
                                            local v278 = u6(v276, 65535);
                                            local v279 = u5(v276, 16);
                                            local v280 = u6(v277, 65535);
                                            local v281 = u5(v277, 16);
                                            local v282 = u6(v278 * v280 + u8(u6(v278 * v281 + v279 * v280, 65535), 16), 4294967295) % 4294967296;
                                            v29[v274] = v282 ~= v282 and 0 or v282 - v282 % 1;
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = u14(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735065448[v22]);
                                        end;
                                    elseif v258 < 83 then
                                        if v258 == 82 then
                                            v29[UNNAMED_2819735090024[v22]](v29[UNNAMED_2819735065448[v22]]);
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = v20;
                                        end;
                                    elseif v258 >= 84 then
                                        if v258 == 85 then
                                            v29[UNNAMED_2819735090024[v22]] = u6(UNNAMED_2819735071880[v22], v29[UNNAMED_2819735065448[v22]]);
                                        else
                                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] >= v29[UNNAMED_2819735043896[v22]];
                                        end;
                                    else
                                        local v283 = u7(UNNAMED_2819735090024[v22], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                                        local v284 = UNNAMED_2819735043896[v22] + 1;

                                        for i = 1, UNNAMED_2819735065448[v22] do
                                            local v285 = u6(u7(v283, (u8(v283, 13))), 536870911);
                                            local v286 = u7(v285, (u5(v285, 13)));
                                            v283 = u6(u7(v286, (u8(v286, 14))), 536870911);
                                            UNNAMED_2819735043896[v284] = u7(UNNAMED_2819735043896[v284], (u6(u5(v283, 0), 127)));
                                            UNNAMED_2819735090024[v284] = u7(UNNAMED_2819735090024[v284], (u6(u5(v283, 7), 127)));
                                            UNNAMED_2819735065448[v284] = u7(UNNAMED_2819735065448[v284], (u6(u5(v283, 14), 127)));
                                            UNNAMED_2819735031800[v284] = u7(UNNAMED_2819735031800[v284], (u6(u5(v283, 21), 127)));
                                            v284 = v284 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735031800[v22] = 64;
                                    end;
                                elseif v258 >= 73 then
                                    if v258 >= 75 then
                                        if v258 == 76 then
                                            v29[UNNAMED_2819735065448[v22]] = u7(UNNAMED_2819735090024[v22], v29[UNNAMED_2819735043896[v22]]);
                                        else
                                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] == v29[UNNAMED_2819735043896[v22]];
                                        end;
                                    elseif v258 == 74 then
                                        v29[UNNAMED_2819735043896[v22]] = u6(v29[UNNAMED_2819735090024[v22]], UNNAMED_2819735065448[v22]);
                                    else
                                        local v287 = UNNAMED_2819735065448[v22];
                                        local v288 = UNNAMED_2819735043896[v22];
                                        v29[v287] = UNNAMED_2819735056376[v22];
                                        v29[v287 + 1] = v288;
                                    end;
                                elseif v258 < 71 then
                                    if v258 == 70 then
                                        v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735050328;
                                    else
                                        local v289 = UNNAMED_2819735090024[v22];
                                        local v290 = UNNAMED_2819735071880[v22];
                                        v29[v289] = UNNAMED_2819735065448[v22];
                                        v29[v289 + 1] = v290;
                                    end;
                                elseif v258 == 72 then
                                    if UNNAMED_2819735043896[v22] >= v29[UNNAMED_2819735090024[v22]] then
                                        v22 = UNNAMED_2819735065448[v22];
                                    end;
                                else
                                    v29[UNNAMED_2819735090024[v22]] = u14(UNNAMED_2819735043896[v22], v29[UNNAMED_2819735065448[v22]]);
                                end;
                            elseif v258 < 120 then
                                if v258 >= 111 then
                                    if v258 >= 115 then
                                        if v258 >= 117 then
                                            if v258 >= 118 then
                                                if v258 == 119 then
                                                    if v29[UNNAMED_2819735090024[v22]] then
                                                        v22 = UNNAMED_2819735043896[v22];
                                                    else
                                                        v22 = UNNAMED_2819735065448[v22];
                                                    end;
                                                else
                                                    v29[UNNAMED_2819735065448[v22]](v29[UNNAMED_2819735090024[v22]], UNNAMED_2819735071880[v22]);
                                                end;
                                            else
                                                local v291 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                                v291[5][v291[4]][v29[UNNAMED_2819735090024[v22]]] = UNNAMED_2819735043896[v22];
                                            end;
                                        elseif v258 == 116 then
                                            local v292 = UNNAMED_2819735043896[v22];
                                            local v293 = u7(UNNAMED_2819735090024[v22], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                                            local v294 = UNNAMED_2819735053352[5];
                                            local v295 = u7(v294[v292], 109162203);
                                            v294[v292] = v295;
                                            local v296 = UNNAMED_2819735053352[4];
                                            local v297 = v295 + 1;
                                            local v298 = u9(v296, v297);
                                            local v299;

                                            if v298 < 128 then
                                                v299 = v297 + 1;
                                            else
                                                local v300 = u9(v296, v297 + 1);

                                                if v300 < 128 then
                                                    v298 = v298 - 128 + v300 * 128;
                                                    v299 = v297 + 2;
                                                else
                                                    local v301 = u9(v296, v297 + 2);

                                                    if v301 < 128 then
                                                        v298 = v298 - 128 + (v300 - 128) * 16384 + v301 * 128;
                                                        v299 = v297 + 3;
                                                    else
                                                        local v302 = u9(v296, v297 + 3);
                                                        v298 = (v298 - 128) * 16384 + (v300 - 128) * 128 + (v301 - 128) + v302 % 128 * 2097152 + (v302 - v302 % 128) * 2097152;
                                                        v299 = v297 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v303 = v293 * 16843009;
                                            local v304 = v299 + v298;
                                            local v305 = v304 - v298 % 4;

                                            for i = v299, v305 - 1, 4 do
                                                u10(v296, i, (u7(u11(v296, i), v303)));
                                                local _ = i;
                                            end;

                                            for i = v305, v304 - 1 do
                                                u12(v296, i, (u7(u9(v296, i), v293)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735043896[v22] = 38;
                                            UNNAMED_2819735090024[v22] = 98;
                                            UNNAMED_2819735065448[v22] = 203;
                                            UNNAMED_2819735031800[v22] = 64;
                                        else
                                            v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] // UNNAMED_2819735090024[v22];
                                        end;
                                    elseif v258 >= 113 then
                                        if v258 == 114 then
                                            local v306 = UNNAMED_2819735043896[v22];
                                            v29[v306] = v29[v306](v29[v306 + 1], v29[v306 + 2]);
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] ~= UNNAMED_2819735043896[v22];
                                        end;
                                    elseif v258 == 112 then
                                        v29[UNNAMED_2819735065448[v22]] = u8(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735090024[v22]);
                                    elseif v26 then
                                        local v307 = UNNAMED_2819735043896[v22];
                                        local v308 = v26[v307];

                                        if v308 then
                                            v308[5] = v308;
                                            v308[6] = v29[v307];
                                            v308[4] = 6;
                                            v26[v307] = nil;
                                        end;

                                        local v309 = UNNAMED_2819735065448[v22];
                                        local v310 = v26[v309];

                                        if v310 then
                                            v310[5] = v310;
                                            v310[6] = v29[v309];
                                            v310[4] = 6;
                                            v26[v309] = nil;
                                        end;
                                    end;
                                elseif v258 < 107 then
                                    if v258 < 105 then
                                        if v258 == 104 then
                                            v29[UNNAMED_2819735043896[v22]](v29[UNNAMED_2819735065448[v22]], v29[UNNAMED_2819735090024[v22]]);
                                        else
                                            local v311 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                            v311[5][v311[4]] = UNNAMED_2819735071880[v22];
                                        end;
                                    elseif v258 == 106 then
                                        v29[UNNAMED_2819735043896[v22]] = u19(v29[UNNAMED_2819735090024[v22]]);
                                    else
                                        local v312 = UNNAMED_2819735043896[v22];
                                        local _ = UNNAMED_2819735090024[v22];
                                        v29[v312] = u2(v29[v312](u3(v29, v312 + 1, v312 + UNNAMED_2819735065448[v22])));
                                    end;
                                elseif v258 >= 109 then
                                    if v258 == 110 then
                                        local v313 = UNNAMED_2819735043896[v22];
                                        local v314 = UNNAMED_2819735065448[v22];
                                        local v315 = UNNAMED_2819735053352[5];
                                        local v316 = u7(v315[v313], 109162203);
                                        v315[v313] = v316;
                                        local v317 = UNNAMED_2819735053352[4];
                                        local v318 = v316 + 1;
                                        local v319 = u9(v317, v318);
                                        local v320;

                                        if v319 < 128 then
                                            v320 = v318 + 1;
                                        else
                                            local v321 = u9(v317, v318 + 1);

                                            if v321 < 128 then
                                                v319 = v319 - 128 + v321 * 128;
                                                v320 = v318 + 2;
                                            else
                                                local v322 = u9(v317, v318 + 2);

                                                if v322 < 128 then
                                                    v319 = v319 - 128 + (v321 - 128) * 16384 + v322 * 128;
                                                    v320 = v318 + 3;
                                                else
                                                    local v323 = u9(v317, v318 + 3);
                                                    v319 = (v319 - 128) * 16384 + (v321 - 128) * 128 + (v322 - 128) + v323 % 128 * 2097152 + (v323 - v323 % 128) * 2097152;
                                                    v320 = v318 + 4;
                                                end;
                                            end;
                                        end;

                                        local v324 = v314 * 16843009;
                                        local v325 = v320 + v319;
                                        local v326 = v325 - v319 % 4;

                                        for i = v320, v326 - 1, 4 do
                                            u10(v317, i, (u7(u11(v317, i), v324)));
                                            local _ = i;
                                        end;

                                        for i = v326, v325 - 1 do
                                            u12(v317, i, (u7(u9(v317, i), v314)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735043896[v22] = 28;
                                        UNNAMED_2819735065448[v22] = 57;
                                        UNNAMED_2819735090024[v22] = 9;
                                        UNNAMED_2819735031800[v22] = 64;
                                    else
                                        v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735071880[v22];
                                    end;
                                elseif v258 == 108 then
                                    local v327 = UNNAMED_2819735065448[v22];
                                    local v328 = UNNAMED_2819735056376[v22];
                                    v29[v327] = UNNAMED_2819735071880[v22];
                                    v29[v327 + 1] = v328;
                                else
                                    v29[UNNAMED_2819735090024[v22]]();
                                end;
                            elseif v258 < 129 then
                                if v258 < 124 then
                                    if v258 < 122 then
                                        if v258 == 121 then
                                            v29[UNNAMED_2819735043896[v22]](UNNAMED_2819735080952[v22], UNNAMED_2819735056376[v22]);
                                        else
                                            local v329 = UNNAMED_2819735065448[v22];
                                            local v330 = UNNAMED_2819735043896[v22];
                                            local v331 = u6(v29[UNNAMED_2819735090024[v22]], 4294967295);
                                            local v332 = u6(v330, 4294967295);
                                            local v333 = u6(v331, 65535);
                                            local v334 = u5(v331, 16);
                                            local v335 = u6(v332, 65535);
                                            local v336 = u5(v332, 16);
                                            local v337 = u6(v333 * v335 + u8(u6(v333 * v336 + v334 * v335, 65535), 16), 4294967295) % 4294967296;
                                            v29[v329] = v337 ~= v337 and 0 or v337 - v337 % 1;
                                        end;
                                    elseif v258 == 123 then
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] // v29[UNNAMED_2819735090024[v22]];
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = -v29[UNNAMED_2819735065448[v22]];
                                    end;
                                elseif v258 >= 126 then
                                    if v258 < 127 then
                                        local v338 = UNNAMED_2819735090024[v22];
                                        local v339 = v29[UNNAMED_2819735065448[v22]];
                                        local v340 = u6(UNNAMED_2819735071880[v22], 4294967295);
                                        local v341 = u6(v339, 4294967295);
                                        local v342 = u6(v340, 65535);
                                        local v343 = u5(v340, 16);
                                        local v344 = u6(v341, 65535);
                                        local v345 = u5(v341, 16);
                                        local v346 = u6(v342 * v344 + u8(u6(v342 * v345 + v343 * v344, 65535), 16), 4294967295) % 4294967296;
                                        v29[v338] = v346 ~= v346 and 0 or v346 - v346 % 1;
                                    elseif v258 == 128 then
                                        v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] * v29[UNNAMED_2819735043896[v22]];
                                    else
                                        v29[UNNAMED_2819735090024[v22]] = u7(v29[UNNAMED_2819735065448[v22]], UNNAMED_2819735043896[v22]);
                                    end;
                                elseif v258 == 125 then
                                    v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] + UNNAMED_2819735043896[v22];
                                else
                                    v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] - UNNAMED_2819735071880[v22];
                                end;
                            elseif v258 < 133 then
                                if v258 >= 131 then
                                    if v258 == 132 then
                                        local v347 = UNNAMED_2819735090024[v22];
                                        local v348 = UNNAMED_2819735065448[v22] + 1;

                                        for i = 1, UNNAMED_2819735043896[v22] do
                                            local v349 = u6(u7(v347, (u8(v347, 13))), 536870911);
                                            local v350 = u7(v349, (u5(v349, 13)));
                                            v347 = u6(u7(v350, (u8(v350, 14))), 536870911);
                                            UNNAMED_2819735043896[v348] = u7(UNNAMED_2819735043896[v348], (u6(u5(v347, 0), 127)));
                                            UNNAMED_2819735090024[v348] = u7(UNNAMED_2819735090024[v348], (u6(u5(v347, 7), 127)));
                                            UNNAMED_2819735065448[v348] = u7(UNNAMED_2819735065448[v348], (u6(u5(v347, 14), 127)));
                                            UNNAMED_2819735031800[v348] = u7(UNNAMED_2819735031800[v348], (u6(u5(v347, 21), 127)));
                                            v348 = v348 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735031800[v22] = 64;
                                    else
                                        local v351 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                        v351[5][v351[4]][v29[UNNAMED_2819735043896[v22]]] = v29[UNNAMED_2819735090024[v22]];
                                    end;
                                elseif v258 == 130 then
                                    v29[UNNAMED_2819735065448[v22]] = u7(v29[UNNAMED_2819735090024[v22]], v29[UNNAMED_2819735043896[v22]]);
                                else
                                    local v352 = UNNAMED_2819735043896[v22];
                                    local v353 = u7(v21, u6(u5(v21, 14), 262143), (u6(u5(v21, 28), 15)));
                                    local v354 = UNNAMED_2819735090024[v22];
                                    local v355 = UNNAMED_2819735065448[v22];
                                    local v356 = v354 < 2097152 and 7 or 14;
                                    local v357 = u5(v354, v356);
                                    UNNAMED_2819735090024[v22] = u7(u6(v354, u8(1, v356) - 1), 52, (u6(u5(v353, 7), 127)));
                                    UNNAMED_2819735043896[v22] = u7(v352, 86, (u6(v353, 127)));
                                    UNNAMED_2819735031800[v22] = u7(v357, 22, (u6(u5(v353, 21), 127)));
                                    UNNAMED_2819735065448[v22] = u7(v355, 111, (u6(u5(v353, 14), 127)));
                                    v22 = v22 - 1;
                                end;
                            elseif v258 >= 135 then
                                if v258 < 136 then
                                    v29[UNNAMED_2819735043896[v22]](v29[UNNAMED_2819735065448[v22]], u3(v29[UNNAMED_2819735090024[v22]], 1, v29[UNNAMED_2819735090024[v22]].n));
                                elseif v258 == 137 then
                                    local v358 = UNNAMED_2819735065448[v22];
                                    local v359 = UNNAMED_2819735043896[v22];
                                    v29[v358] = UNNAMED_2819735090024[v22];
                                    v29[v358 + 1] = v359;
                                else
                                    v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735043896[v22] + v29[UNNAMED_2819735090024[v22]];
                                end;
                            elseif v258 == 134 then
                                if v26 then
                                    local v360 = UNNAMED_2819735065448[v22];
                                    local v361 = v26[v360];

                                    if v361 then
                                        v361[5] = v361;
                                        v361[6] = v29[v360];
                                        v361[4] = 6;
                                        v26[v360] = nil;
                                    end;
                                end;
                            else
                                local v362 = UNNAMED_2819735065448[v22];
                                local v363 = v29[UNNAMED_2819735043896[v22]];
                                local v364 = u6(v29[UNNAMED_2819735090024[v22]], 4294967295);
                                local v365 = u6(v363, 4294967295);
                                local v366 = u6(v364, 65535);
                                local v367 = u5(v364, 16);
                                local v368 = u6(v365, 65535);
                                local v369 = u5(v365, 16);
                                local v370 = u6(v366 * v368 + u8(u6(v366 * v369 + v367 * v368, 65535), 16), 4294967295) % 4294967296;
                                v29[v362] = v370 ~= v370 and 0 or v370 - v370 % 1;
                            end;

                            v257 = 1;
                            continue;
                        end;

                        if v258 >= 34 then
                            if v258 >= 51 then
                                if v258 < 60 then
                                    if v258 < 55 then
                                        if v258 < 53 then
                                            if v258 == 52 then
                                                v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735080952[v22] + v29[UNNAMED_2819735043896[v22]];
                                            else
                                                v29[UNNAMED_2819735043896[v22]] = u18[UNNAMED_2819735080952[v22]][UNNAMED_2819735056376[v22]];
                                            end;
                                        elseif v258 == 54 then
                                            v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735043896[v22] - v29[UNNAMED_2819735090024[v22]];
                                        else
                                            UNNAMED_2819735050328[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]];
                                        end;
                                    elseif v258 < 57 then
                                        if v258 == 56 then
                                            local v371 = nil;
                                            local v372 = UNNAMED_2819735043896[v22];
                                            local v373 = UNNAMED_2819735056376[v22];
                                            local v374 = UNNAMED_2819735080952[v22];
                                            local v375 = v374[0];

                                            if v375 then
                                                local v376 = #v375 / 3;

                                                if v376 > 0 then
                                                    v371 = {};

                                                    for i = 1, v376 do
                                                        local v377 = (i - 1) * 3;
                                                        local v378 = v375[v377 + 2];
                                                        local v379 = v375[v377 + 1];
                                                        local v380;

                                                        if v378 == 2 then
                                                            v26 = v26 or {};
                                                            local v381 = v26[v379];

                                                            if not v381 then
                                                                v381 = {
                                                                    [5] = v29,
                                                                    [4] = v379
                                                                };
                                                                v26[v379] = v381;
                                                            end;

                                                            v371[i] = v381;
                                                            v380 = i;
                                                        elseif v378 == 0 then
                                                            v371[i] = v29[v379];
                                                            v380 = i;
                                                        elseif v378 == 3 then
                                                            v371[i] = UNNAMED_2819732806552[v379];
                                                            v380 = i;
                                                        elseif v378 == 1 then
                                                            v32 = v32 or {};
                                                            local v382 = v32[v379];

                                                            if not v382 then
                                                                v382 = {
                                                                    [5] = v29,
                                                                    [4] = v379,
                                                                    [6] = v375[v377 + 3]
                                                                };
                                                                v32[v379] = v382;
                                                            end;

                                                            v371[i] = v382;
                                                            v380 = i;
                                                        else
                                                            v380 = i;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            local v383 = v374[-2];
                                            v374[v383] = v371;
                                            local v384 = v373(u3(v374, 1, v374[-1]));
                                            v374[v383] = nil;
                                            v29[v372] = v384;
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                        end;
                                    elseif v258 < 58 then
                                        v29[UNNAMED_2819735043896[v22]][UNNAMED_2819735056376[v22]] = v29[UNNAMED_2819735065448[v22]];
                                    elseif v258 == 59 then
                                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] - UNNAMED_2819735043896[v22];
                                    else
                                        v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] - v29[UNNAMED_2819735043896[v22]];
                                    end;
                                elseif v258 >= 64 then
                                    if v258 < 66 then
                                        if v258 == 65 then
                                            v29[UNNAMED_2819735090024[v22]][v29[UNNAMED_2819735065448[v22]]] = UNNAMED_2819735043896[v22];
                                        end;
                                    elseif v258 < 67 then
                                        v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735043896[v22]](v29[UNNAMED_2819735065448[v22]]);
                                    elseif v258 == 68 then
                                        v22 = UNNAMED_2819735043896[v22];
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]][UNNAMED_2819735065448[v22]];
                                    end;
                                elseif v258 < 62 then
                                    if v258 ~= 61 then
                                        if v26 then
                                            for i in u17, v26 do
                                                local v385 = v26[i];

                                                if v385 then
                                                    v385[5] = v385;
                                                    v385[6] = v29[i];
                                                    v385[4] = 6;
                                                    v26[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v32 then
                                            for i, v in u17, v32 do
                                                local v386 = v[6];

                                                if v32 then
                                                    local v387 = v32[i];

                                                    if v387 then
                                                        local v388 = u1(v386);
                                                        u4(v29, i, i + v386 - 1, 1, v388);
                                                        v387[5] = v388;
                                                        v387[4] = 1;
                                                        v32[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return;
                                    end;

                                    v29[UNNAMED_2819735043896[v22]](u3(v29[UNNAMED_2819735090024[v22]], 1, v29[UNNAMED_2819735090024[v22]].n));
                                elseif v258 == 63 then
                                    v29[UNNAMED_2819735090024[v22]] = not v29[UNNAMED_2819735043896[v22]];
                                else
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] <= v29[UNNAMED_2819735065448[v22]];
                                end;
                            elseif v258 >= 42 then
                                if v258 < 46 then
                                    if v258 >= 44 then
                                        if v258 == 45 then
                                            v29[UNNAMED_2819735043896[v22]] = u7(v29[UNNAMED_2819735065448[v22]], UNNAMED_2819735056376[v22]);
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735050328[UNNAMED_2819735043896[v22]];
                                            v29[UNNAMED_2819735090024[v22 + 1]] = v29[UNNAMED_2819735065448[v22 + 1]] + UNNAMED_2819735043896[v22 + 1];
                                            local v389 = UNNAMED_2819735065448[v22 + 2];
                                            local v390 = v29[UNNAMED_2819735043896[v22 + 2]];
                                            v29[v389] = v29[UNNAMED_2819735090024[v22 + 2]];
                                            v29[v389 + 1] = v390;
                                            local v391 = UNNAMED_2819735043896[v22 + 3];
                                            v29[v391] = v29[v391](v29[v391 + 1], v29[v391 + 2]);
                                            v22 = v22 + 3;
                                        end;
                                    elseif v258 == 43 then
                                        v29[UNNAMED_2819735065448[v22]] = u5(v29[UNNAMED_2819735090024[v22]], UNNAMED_2819735043896[v22]);
                                    else
                                        local v392 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                        v392[5][v392[4]] = v29[UNNAMED_2819735043896[v22]];
                                    end;
                                elseif v258 >= 48 then
                                    if v258 < 49 then
                                        v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735090024[v22] * v29[UNNAMED_2819735065448[v22]];
                                    else
                                        if v258 == 50 then
                                            if v26 then
                                                for i in u17, v26 do
                                                    local v393 = v26[i];

                                                    if v393 then
                                                        v393[5] = v393;
                                                        v393[6] = v29[i];
                                                        v393[4] = 6;
                                                        v26[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v32 then
                                                for i, v in u17, v32 do
                                                    local v394 = v[6];

                                                    if v32 then
                                                        local v395 = v32[i];

                                                        if v395 then
                                                            local v396 = u1(v394);
                                                            u4(v29, i, i + v394 - 1, 1, v396);
                                                            v395[5] = v396;
                                                            v395[4] = 1;
                                                            v32[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return UNNAMED_2819735071880[v22];
                                        end;

                                        v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]] / v29[UNNAMED_2819735090024[v22]];
                                    end;
                                elseif v258 == 47 then
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] % UNNAMED_2819735090024[v22];
                                else
                                    v27 = v27 + v28;
                                    local v397;

                                    if v28 <= 0 then
                                        v397 = v31 <= v27;
                                    else
                                        v397 = v27 <= v31;
                                    end;

                                    if v397 then
                                        v29[UNNAMED_2819735065448[v22]] = v27;
                                        v22 = UNNAMED_2819735043896[v22];
                                    else
                                        v22 = UNNAMED_2819735090024[v22];
                                    end;
                                end;
                            elseif v258 >= 38 then
                                if v258 < 40 then
                                    if v258 == 39 then
                                        local v398 = UNNAMED_2819735065448[v22];
                                        u4(v29, v398 + 1, v398 + UNNAMED_2819735090024[v22], UNNAMED_2819735043896[v22] + 1, v29[v398]);
                                    else
                                        local v399 = v29[UNNAMED_2819735090024[v22]] % 4294967296;
                                        v29[UNNAMED_2819735065448[v22]] = v399 ~= v399 and 0 or v399 - v399 % 1;
                                    end;
                                elseif v258 == 41 then
                                    local v400 = UNNAMED_2819735043896[v22];
                                    local v401 = u7(UNNAMED_2819735090024[v22], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                                    local v402 = UNNAMED_2819735053352[5];
                                    local v403 = u7(v402[v400], 109162203);
                                    v402[v400] = v403;
                                    local v404 = UNNAMED_2819735053352[4];
                                    local v405 = v403 + 1;
                                    local v406 = u9(v404, v405);
                                    local v407;

                                    if v406 < 128 then
                                        v407 = v405 + 1;
                                    else
                                        local v408 = u9(v404, v405 + 1);

                                        if v408 < 128 then
                                            v406 = v406 - 128 + v408 * 128;
                                            v407 = v405 + 2;
                                        else
                                            local v409 = u9(v404, v405 + 2);

                                            if v409 < 128 then
                                                v406 = v406 - 128 + (v408 - 128) * 16384 + v409 * 128;
                                                v407 = v405 + 3;
                                            else
                                                local v410 = u9(v404, v405 + 3);
                                                v406 = (v406 - 128) * 16384 + (v408 - 128) * 128 + (v409 - 128) + v410 % 128 * 2097152 + (v410 - v410 % 128) * 2097152;
                                                v407 = v405 + 4;
                                            end;
                                        end;
                                    end;

                                    local v411 = v401 * 16843009;
                                    local v412 = v407 + v406;
                                    local v413 = v412 - v406 % 4;

                                    for i = v407, v413 - 1, 4 do
                                        u10(v404, i, (u7(u11(v404, i), v411)));
                                        local _ = i;
                                    end;

                                    for i = v413, v412 - 1 do
                                        u12(v404, i, (u7(u9(v404, i), v401)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735043896[v22] = 238;
                                    UNNAMED_2819735090024[v22] = 226;
                                    UNNAMED_2819735065448[v22] = 165;
                                    UNNAMED_2819735031800[v22] = 64;
                                else
                                    v29[UNNAMED_2819735043896[v22]] = u14(v29[UNNAMED_2819735090024[v22]], v29[UNNAMED_2819735065448[v22]]);
                                end;
                            elseif v258 >= 36 then
                                if v258 == 37 then
                                    v29[UNNAMED_2819735090024[v22]] = u18[UNNAMED_2819735080952[v22]];
                                else
                                    v29[UNNAMED_2819735090024[v22]][v29[UNNAMED_2819735043896[v22]]] = v29[UNNAMED_2819735065448[v22]];
                                end;
                            elseif v258 == 35 then
                                v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]];
                            else
                                v29[UNNAMED_2819735065448[v22]] = UNNAMED_2819735050328[UNNAMED_2819735071880[v22]];
                            end;
                        else
                            if v258 >= 17 then
                                if v258 >= 25 then
                                    if v258 >= 29 then
                                        if v258 >= 31 then
                                            if v258 >= 32 then
                                                if v258 == 33 then
                                                    v29[UNNAMED_2819735043896[v22]] = u6(UNNAMED_2819735065448[v22], v29[UNNAMED_2819735090024[v22]]);
                                                else
                                                    v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]](u3(v29[UNNAMED_2819735090024[v22]], 1, v29[UNNAMED_2819735090024[v22]].n));
                                                end;
                                            else
                                                local v414 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22]];
                                                v29[UNNAMED_2819735043896[v22]] = v414[5][v414[4]][v29[UNNAMED_2819735090024[v22]]];
                                            end;
                                        elseif v258 == 30 then
                                            v22 = v29[UNNAMED_2819735043896[v22]];
                                        elseif v29[UNNAMED_2819735065448[v22]] ~= UNNAMED_2819735090024[v22] then
                                            v22 = UNNAMED_2819735043896[v22];
                                        end;
                                    elseif v258 < 27 then
                                        if v258 == 26 then
                                            v29[UNNAMED_2819735043896[v22]] = u6(v29[UNNAMED_2819735065448[v22]], v29[UNNAMED_2819735090024[v22]]);
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] * UNNAMED_2819735043896[v22];
                                        end;
                                    else
                                        if v258 ~= 28 then
                                            if v26 then
                                                for i in u17, v26 do
                                                    local v415 = v26[i];

                                                    if v415 then
                                                        v415[5] = v415;
                                                        v415[6] = v29[i];
                                                        v415[4] = 6;
                                                        v26[i] = nil;
                                                    end;
                                                end;
                                            end;

                                            if v32 then
                                                for i, v in u17, v32 do
                                                    local v416 = v[6];

                                                    if v32 then
                                                        local v417 = v32[i];

                                                        if v417 then
                                                            local v418 = u1(v416);
                                                            u4(v29, i, i + v416 - 1, 1, v418);
                                                            v417[5] = v418;
                                                            v417[4] = 1;
                                                            v32[i] = nil;
                                                        end;
                                                    end;
                                                end;
                                            end;

                                            return v29[UNNAMED_2819735043896[v22]];
                                        end;

                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] + UNNAMED_2819735080952[v22];
                                    end;
                                elseif v258 >= 21 then
                                    if v258 < 23 then
                                        if v258 == 22 then
                                            v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]][UNNAMED_2819735065448[v22]];
                                            v29[UNNAMED_2819735043896[v22 + 1]] = v29[UNNAMED_2819735090024[v22 + 1]][UNNAMED_2819735065448[v22 + 1]];
                                            v29[UNNAMED_2819735043896[v22 + 2]] = v29[UNNAMED_2819735090024[v22 + 2]][UNNAMED_2819735065448[v22 + 2]];
                                            v29[UNNAMED_2819735043896[v22 + 3]] = v29[UNNAMED_2819735065448[v22 + 3]] + v29[UNNAMED_2819735090024[v22 + 3]];
                                            v29[UNNAMED_2819735043896[v22 + 4]] = v29[UNNAMED_2819735090024[v22 + 4]] <= UNNAMED_2819735065448[v22 + 4];
                                            v22 = v22 + 4;
                                        else
                                            v29[UNNAMED_2819735043896[v22]] = {};
                                        end;
                                    elseif v258 == 24 then
                                        local v419 = UNNAMED_2819735065448[v22];
                                        local v420 = v29[UNNAMED_2819735090024[v22]];
                                        v29[v419] = UNNAMED_2819735043896[v22];
                                        v29[v419 + 1] = v420;
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]]();
                                    end;
                                elseif v258 < 19 then
                                    if v258 == 18 then
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] % v29[UNNAMED_2819735090024[v22]];
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] % UNNAMED_2819735056376[v22];
                                    end;
                                elseif v258 == 20 then
                                    v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735065448[v22]] / UNNAMED_2819735043896[v22];
                                else
                                    v29[UNNAMED_2819735065448[v22]] = v21;
                                end;

                                v257 = 1;
                                continue;
                            end;

                            if v258 >= 8 then
                                if v258 >= 12 then
                                    if v258 >= 14 then
                                        if v258 < 15 then
                                            v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]][v29[UNNAMED_2819735090024[v22]]];
                                        elseif v258 == 16 then
                                            v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735043896[v22]](UNNAMED_2819735056376[v22]);
                                        else
                                            local v421 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                            v29[UNNAMED_2819735065448[v22]] = v421[5][v421[4]];
                                        end;
                                    elseif v258 == 13 then
                                        v22 = v29[UNNAMED_2819735090024[v22]];
                                    elseif v29[UNNAMED_2819735065448[v22]] > UNNAMED_2819735043896[v22] then
                                        v22 = UNNAMED_2819735090024[v22];
                                    end;
                                elseif v258 < 10 then
                                    if v258 == 9 then
                                        v21 = v29[UNNAMED_2819735065448[v22]];
                                    else
                                        local v422 = u7(UNNAMED_2819735090024[v22], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                                        local v423 = UNNAMED_2819735043896[v22] + 1;

                                        for i = 1, UNNAMED_2819735065448[v22] do
                                            local v424 = u6(u7(v422, (u8(v422, 13))), 536870911);
                                            local v425 = u7(v424, (u5(v424, 13)));
                                            v422 = u6(u7(v425, (u8(v425, 14))), 536870911);
                                            UNNAMED_2819735043896[v423] = u7(UNNAMED_2819735043896[v423], (u6(u5(v422, 0), 127)));
                                            UNNAMED_2819735090024[v423] = u7(UNNAMED_2819735090024[v423], (u6(u5(v422, 7), 127)));
                                            UNNAMED_2819735065448[v423] = u7(UNNAMED_2819735065448[v423], (u6(u5(v422, 14), 127)));
                                            UNNAMED_2819735031800[v423] = u7(UNNAMED_2819735031800[v423], (u6(u5(v422, 21), 127)));
                                            v423 = v423 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735031800[v22] = 64;
                                    end;
                                elseif v258 == 11 then
                                    v29[UNNAMED_2819735090024[v22]] = #v29[UNNAMED_2819735065448[v22]];
                                else
                                    v29[UNNAMED_2819735065448[v22]] = v29[UNNAMED_2819735090024[v22]] == UNNAMED_2819735043896[v22];
                                end;

                                v257 = 1;
                                continue;
                            end;

                            if v258 >= 4 then
                                if v258 >= 6 then
                                    if v258 == 7 then
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] + v29[UNNAMED_2819735090024[v22]];
                                    else
                                        local v426 = UNNAMED_2819735090024[v22];
                                        local v427 = UNNAMED_2819735065448[v22];
                                        v29[v426] = v29[UNNAMED_2819735043896[v22]];
                                        v29[v426 + 1] = v427;
                                    end;
                                elseif v258 == 5 then
                                    v30 = {
                                        [9] = v30,
                                        [7] = v28,
                                        [8] = v27,
                                        [5] = v31,
                                        [6] = v25
                                    };
                                    local v428 = UNNAMED_2819735065448[v22];
                                    v28 = v29[v428 + 2] + 0;
                                    v31 = v29[v428 + 1] + 0;
                                    v27 = v29[v428] - v28;
                                    v22 = UNNAMED_2819735043896[v22];
                                else
                                    local v429 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                    v29[UNNAMED_2819735065448[v22]] = v429[5][v429[4]];
                                    v29[UNNAMED_2819735043896[v22 + 1]](UNNAMED_2819735080952[v22 + 1], UNNAMED_2819735056376[v22 + 1]);
                                    local v430 = UNNAMED_2819732806552[UNNAMED_2819735065448[v22 + 2]];
                                    v430[5][v430[4]] = UNNAMED_2819735071880[v22 + 2];
                                    local v431 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22 + 3]];
                                    v29[UNNAMED_2819735065448[v22 + 3]] = v431[5][v431[4]];
                                    v29[UNNAMED_2819735090024[v22 + 4]]();
                                    v22 = v22 + 4;
                                end;

                                v257 = 1;
                                continue;
                            end;

                            if v258 >= 2 then
                                if v258 == 3 then
                                    v29[UNNAMED_2819735090024[v22]] = u6(v29[UNNAMED_2819735065448[v22]], UNNAMED_2819735071880[v22]);
                                else
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735065448[v22]] < UNNAMED_2819735090024[v22];
                                end;

                                v257 = 1;
                                continue;
                            end;

                            if v258 == 1 then
                                v23 = UNNAMED_2819735090024[v22];
                                v22 = UNNAMED_2819735043896[v22] + 1;
                                v34 = 8;
                                break;
                            end;

                            v29[UNNAMED_2819735090024[v22]] = u14(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735080952[v22]);
                        end;

                        v257 = 1;
                        continue;
                    elseif v257 == 1 then
                        v257 = -1;
                        v22 = v22 + 1;
                        break;
                    else
                        break;
                    end;
                end;

                if v34 ~= -1 then
                    break;
                end;
            end;

            if v34 ~= -1 then
                continue;
            end;

            v34 = 10;
            continue;
        elseif v34 == 10 then
            v34 = -1;

            while true do
                local v22;
                local v432 = 0;

                while true do
                    if v432 == 0 then
                        v432 = -1;
                        local v433 = UNNAMED_2819735065448[v22];

                        if v433 < 43 then
                            if v433 >= 21 then
                                if v433 < 32 then
                                    if v433 >= 26 then
                                        if v433 < 29 then
                                            if v433 < 27 then
                                                local v434 = UNNAMED_2819735031800[v22];
                                                local v435, v436 = v27();

                                                if v435 then
                                                    v29[v434] = v436;
                                                    v22 = UNNAMED_2819735043896[v22];
                                                else
                                                    v22 = UNNAMED_2819735090024[v22];
                                                end;
                                            elseif v433 == 28 then
                                                local v437 = UNNAMED_2819732806552[UNNAMED_2819735031800[v22]];
                                                v437[5][v437[4]] = UNNAMED_2819735056376[v22];
                                            else
                                                v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735065448;
                                            end;
                                        elseif v433 < 30 then
                                            v27 = v27 + v28;
                                            local v438;

                                            if v28 <= 0 then
                                                v438 = v31 <= v27;
                                            else
                                                v438 = v27 <= v31;
                                            end;

                                            if v438 then
                                                v29[UNNAMED_2819735043896[v22]] = v27;
                                                v22 = UNNAMED_2819735090024[v22];
                                            else
                                                v22 = UNNAMED_2819735031800[v22];
                                            end;
                                        elseif v433 == 31 then
                                            local v439 = UNNAMED_2819735090024[v22];
                                            local v440 = UNNAMED_2819735031800[v22];
                                            local v441 = UNNAMED_2819735043896[v22];
                                            local _ = v439 + v441 - 1;
                                            local _ = v439 + v440;
                                            u4(u2(v29[v439](u3(v29, v439 + 1, v439 + v440))), 1, v441, v439, v29);
                                        else
                                            v20 = v29[UNNAMED_2819735031800[v22]];
                                        end;
                                    elseif v433 < 23 then
                                        if v433 == 22 then
                                            v29[UNNAMED_2819735090024[v22]][UNNAMED_2819735071880[v22]] = v29[UNNAMED_2819735031800[v22]];
                                        else
                                            local v442 = UNNAMED_2819735043896[v22];
                                            local v443 = v29[UNNAMED_2819735031800[v22]];
                                            v29[v442] = v29[UNNAMED_2819735090024[v22]];
                                            v29[v442 + 1] = v443;
                                        end;
                                    elseif v433 >= 24 then
                                        if v433 == 25 then
                                            local v444 = UNNAMED_2819735090024[v22];
                                            local v445 = u7(UNNAMED_2819735043896[v22], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                                            local v446 = UNNAMED_2819735053352[5];
                                            local v447 = u7(v446[v444], 109162203);
                                            v446[v444] = v447;
                                            local v448 = UNNAMED_2819735053352[4];
                                            local v449 = v447 + 1;
                                            local v450 = u9(v448, v449);
                                            local v451;

                                            if v450 < 128 then
                                                v451 = v449 + 1;
                                            else
                                                local v452 = u9(v448, v449 + 1);

                                                if v452 < 128 then
                                                    v450 = v450 - 128 + v452 * 128;
                                                    v451 = v449 + 2;
                                                else
                                                    local v453 = u9(v448, v449 + 2);

                                                    if v453 < 128 then
                                                        v450 = v450 - 128 + (v452 - 128) * 16384 + v453 * 128;
                                                        v451 = v449 + 3;
                                                    else
                                                        local v454 = u9(v448, v449 + 3);
                                                        v450 = (v450 - 128) * 16384 + (v452 - 128) * 128 + (v453 - 128) + v454 % 128 * 2097152 + (v454 - v454 % 128) * 2097152;
                                                        v451 = v449 + 4;
                                                    end;
                                                end;
                                            end;

                                            local v455 = v445 * 16843009;
                                            local v456 = v451 + v450;
                                            local v457 = v456 - v450 % 4;

                                            for i = v451, v457 - 1, 4 do
                                                u10(v448, i, (u7(u11(v448, i), v455)));
                                                local _ = i;
                                            end;

                                            for i = v457, v456 - 1 do
                                                u12(v448, i, (u7(u9(v448, i), v445)));
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735090024[v22] = 232;
                                            UNNAMED_2819735043896[v22] = 48;
                                            UNNAMED_2819735031800[v22] = 59;
                                            UNNAMED_2819735065448[v22] = 17;
                                        else
                                            local v458 = UNNAMED_2819735031800[v22];
                                            local v459 = u15(u16);
                                            v459(UNNAMED_2819735050328, v29[v458], v29[v458 + 1], v29[v458 + 2]);
                                            local v460 = UNNAMED_2819735043896[v22];
                                            v22 = UNNAMED_2819735090024[v22];
                                            v25 = v460;
                                            v27 = v459;
                                            v30 = {
                                                [9] = v30,
                                                [7] = v28,
                                                [8] = v27,
                                                [5] = v31,
                                                [6] = v25
                                            };
                                        end;
                                    elseif v29[UNNAMED_2819735043896[v22]] > UNNAMED_2819735090024[v22] then
                                        v22 = UNNAMED_2819735031800[v22];
                                    end;
                                elseif v433 >= 37 then
                                    if v433 < 40 then
                                        if v433 < 38 then
                                            local v461 = UNNAMED_2819735090024[v22];
                                            local v462 = UNNAMED_2819735043896[v22];
                                            local v463 = u7(v21, u6(u5(v21, 14), 262143), (u6(u5(v21, 28), 15)));
                                            local v464 = UNNAMED_2819735031800[v22];
                                            local v465 = v464 < 2097152 and 7 or 14;
                                            local v466 = u6(v464, u8(1, v465) - 1);
                                            local v467 = u5(v464, v465);
                                            UNNAMED_2819735043896[v22] = u7(v462, 95, (u6(u5(v463, 7), 127)));
                                            UNNAMED_2819735031800[v22] = u7(v466, 67, (u6(u5(v463, 14), 127)));
                                            UNNAMED_2819735090024[v22] = u7(v461, 77, (u6(v463, 127)));
                                            UNNAMED_2819735065448[v22] = u7(v467, 1, (u6(u5(v463, 21), 127)));
                                            v22 = v22 - 1;
                                        elseif v433 == 39 then
                                            v29[UNNAMED_2819735031800[v22]](UNNAMED_2819735071880[v22], UNNAMED_2819735056376[v22]);
                                        else
                                            v29[UNNAMED_2819735031800[v22]] = not v29[UNNAMED_2819735090024[v22]];
                                        end;
                                    elseif v433 < 41 then
                                        local v468 = UNNAMED_2819735031800[v22];
                                        local v469 = u7(v21, u6(u5(v21, 14), 262143), (u6(u5(v21, 28), 15)));
                                        local v470 = UNNAMED_2819735043896[v22];
                                        local v471 = UNNAMED_2819735090024[v22];
                                        local v472 = v468 < 16384 and 7 or (v468 < 2097152 and 14 or 21);
                                        local v473 = u5(v468, v472);
                                        local v474 = u6(v468, u8(1, v472) - 1);
                                        UNNAMED_2819735065448[v22] = u7(v473, 28, (u6(u5(v469, 21), 127)));
                                        UNNAMED_2819735043896[v22] = u7(v470, 63, (u6(u5(v469, 7), 127)));
                                        UNNAMED_2819735090024[v22] = u7(v471, 27, (u6(v469, 127)));
                                        UNNAMED_2819735031800[v22] = u7(v474, 23, (u6(u5(v469, 14), 127)));
                                        v22 = v22 - 1;
                                    elseif v433 == 42 then
                                        v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735031800;
                                    else
                                        v29[UNNAMED_2819735031800[v22]] = UNNAMED_2819735090024[v22] * v29[UNNAMED_2819735043896[v22]];
                                    end;
                                elseif v433 >= 34 then
                                    if v433 >= 35 then
                                        if v433 == 36 then
                                            v29[UNNAMED_2819735043896[v22]] = v20;
                                        else
                                            v29[UNNAMED_2819735031800[v22]] = v21;
                                        end;
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735031800[v22] + v29[UNNAMED_2819735090024[v22]];
                                    end;
                                elseif v433 == 33 then
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735031800[v22]] + UNNAMED_2819735090024[v22];
                                else
                                    v29[UNNAMED_2819735031800[v22]] = -v29[UNNAMED_2819735090024[v22]];
                                end;
                            elseif v433 < 10 then
                                if v433 < 5 then
                                    if v433 >= 2 then
                                        if v433 < 3 then
                                            local v475 = UNNAMED_2819735090024[v22];
                                            local v476 = UNNAMED_2819735043896[v22];
                                            local v477 = {
                                                n = v476 - v475 + 1
                                            };
                                            u4(v29, v475, v476, 1, v477);
                                            v29[UNNAMED_2819735031800[v22]] = v477;
                                        elseif v433 == 4 then
                                            v29[UNNAMED_2819735031800[v22]] = u7(v29[UNNAMED_2819735090024[v22]], UNNAMED_2819735043896[v22]);
                                        else
                                            v22 = UNNAMED_2819735043896[v22];
                                        end;
                                    elseif v433 == 1 then
                                        local v478 = v29[UNNAMED_2819735043896[v22]] % 4294967296;
                                        v29[UNNAMED_2819735090024[v22]] = v478 ~= v478 and 0 or v478 - v478 % 1;
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735050328[UNNAMED_2819735090024[v22]];
                                    end;
                                elseif v433 >= 7 then
                                    if v433 >= 8 then
                                        if v433 == 9 then
                                            v30 = {
                                                [9] = v30,
                                                [7] = v28,
                                                [8] = v27,
                                                [5] = v31,
                                                [6] = v25
                                            };
                                            local v479 = UNNAMED_2819735090024[v22];
                                            v28 = v29[v479 + 2] + 0;
                                            v31 = v29[v479 + 1] + 0;
                                            v27 = v29[v479] - v28;
                                            v22 = UNNAMED_2819735043896[v22];
                                        else
                                            v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] < UNNAMED_2819735031800[v22];
                                        end;
                                    else
                                        v29[UNNAMED_2819735090024[v22]][v29[UNNAMED_2819735043896[v22]]] = v29[UNNAMED_2819735031800[v22]];
                                    end;
                                elseif v433 == 6 then
                                    v29[UNNAMED_2819735031800[v22]] = v29[UNNAMED_2819735090024[v22]] == UNNAMED_2819735043896[v22];
                                else
                                    v29[UNNAMED_2819735043896[v22]](UNNAMED_2819735028776[v22]);
                                end;
                            elseif v433 >= 15 then
                                if v433 < 18 then
                                    if v433 < 16 then
                                        v29[UNNAMED_2819735031800[v22]] = v29[UNNAMED_2819735090024[v22]] - UNNAMED_2819735071880[v22];
                                    elseif v433 ~= 17 then
                                        v29[UNNAMED_2819735043896[v22]] = u6(v29[UNNAMED_2819735031800[v22]], v29[UNNAMED_2819735090024[v22]]);
                                    end;
                                elseif v433 < 19 then
                                    v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735043896[v22]] % v29[UNNAMED_2819735031800[v22]];
                                elseif v433 == 20 then
                                    local v480 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                    v29[UNNAMED_2819735031800[v22]] = v480[5][v480[4]][v29[UNNAMED_2819735090024[v22]]];
                                else
                                    local v481 = UNNAMED_2819735043896[v22];
                                    local v482 = v29[UNNAMED_2819735031800[v22]];
                                    local v483 = u6(v29[UNNAMED_2819735090024[v22]], 4294967295);
                                    local v484 = u6(v482, 4294967295);
                                    local v485 = u6(v483, 65535);
                                    local v486 = u5(v483, 16);
                                    local v487 = u6(v484, 65535);
                                    local v488 = u5(v484, 16);
                                    local v489 = u6(v485 * v487 + u8(u6(v485 * v488 + v486 * v487, 65535), 16), 4294967295) % 4294967296;
                                    v29[v481] = v489 ~= v489 and 0 or v489 - v489 % 1;
                                end;
                            elseif v433 >= 12 then
                                if v433 < 13 then
                                    v29[UNNAMED_2819735031800[v22]]();
                                elseif v433 == 14 then
                                    v29[UNNAMED_2819735043896[v22]] = {};
                                else
                                    local v490 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                    v29[UNNAMED_2819735090024[v22]] = v490[5][v490[4]];
                                end;
                            elseif v433 == 11 then
                                v29[UNNAMED_2819735031800[v22]] = v29[UNNAMED_2819735043896[v22]] + v29[UNNAMED_2819735090024[v22]];
                            else
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] ~= UNNAMED_2819735031800[v22];
                            end;
                        elseif v433 < 65 then
                            if v433 >= 54 then
                                if v433 < 59 then
                                    if v433 >= 56 then
                                        if v433 < 57 then
                                            v29[UNNAMED_2819735031800[v22]] = UNNAMED_2819735056376[v22];
                                        elseif v433 == 58 then
                                            v29[UNNAMED_2819735043896[v22]] = u14(v29[UNNAMED_2819735090024[v22]], v29[UNNAMED_2819735031800[v22]]);
                                        elseif v29[UNNAMED_2819735031800[v22]] then
                                            v22 = UNNAMED_2819735043896[v22];
                                        else
                                            v22 = UNNAMED_2819735090024[v22];
                                        end;
                                    elseif v433 == 55 then
                                        local v491 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                        v491[5][v491[4]][UNNAMED_2819735028776[v22]] = v29[UNNAMED_2819735090024[v22]];
                                    else
                                        v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735031800[v22]] % UNNAMED_2819735043896[v22];
                                    end;
                                elseif v433 >= 62 then
                                    if v433 < 63 then
                                        if v26 then
                                            for i in u17, v26 do
                                                local v492 = v26[i];

                                                if v492 then
                                                    v492[5] = v492;
                                                    v492[6] = v29[i];
                                                    v492[4] = 6;
                                                    v26[i] = nil;
                                                end;
                                            end;
                                        end;

                                        if v32 then
                                            for i, v in u17, v32 do
                                                local v493 = v[6];

                                                if v32 then
                                                    local v494 = v32[i];

                                                    if v494 then
                                                        local v495 = u1(v493);
                                                        u4(v29, i, i + v493 - 1, 1, v495);
                                                        v494[5] = v495;
                                                        v494[4] = 1;
                                                        v32[i] = nil;
                                                    end;
                                                end;
                                            end;
                                        end;

                                        return;
                                    end;

                                    if v433 == 64 then
                                        v29[UNNAMED_2819735031800[v22]] = u7(v29[UNNAMED_2819735043896[v22]], UNNAMED_2819735056376[v22]);
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] == v29[UNNAMED_2819735031800[v22]];
                                    end;
                                elseif v433 < 60 then
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735031800[v22]] * UNNAMED_2819735090024[v22];
                                elseif v433 == 61 then
                                    v22 = v29[UNNAMED_2819735090024[v22]];
                                else
                                    v29[UNNAMED_2819735043896[v22]] = UNNAMED_2819735090024[v22];
                                end;
                            elseif v433 >= 48 then
                                if v433 >= 51 then
                                    if v433 >= 52 then
                                        if v433 == 53 then
                                            v29[UNNAMED_2819735031800[v22]] = UNNAMED_2819735053352;
                                        else
                                            v29[UNNAMED_2819735043896[v22]] = u6(v29[UNNAMED_2819735090024[v22]], UNNAMED_2819735031800[v22]);
                                        end;
                                    else
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] // UNNAMED_2819735031800[v22];
                                    end;
                                elseif v433 >= 49 then
                                    if v433 == 50 then
                                        v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735031800[v22]] - UNNAMED_2819735043896[v22];
                                    else
                                        local v496 = UNNAMED_2819735090024[v22];
                                        local v497 = UNNAMED_2819735043896[v22] + 1;

                                        for i = 1, UNNAMED_2819735031800[v22] do
                                            local v498 = u6(u7(v496, (u8(v496, 13))), 536870911);
                                            local v499 = u7(v498, (u5(v498, 13)));
                                            v496 = u6(u7(v499, (u8(v499, 14))), 536870911);
                                            UNNAMED_2819735090024[v497] = u7(UNNAMED_2819735090024[v497], (u6(u5(v496, 0), 127)));
                                            UNNAMED_2819735043896[v497] = u7(UNNAMED_2819735043896[v497], (u6(u5(v496, 7), 127)));
                                            UNNAMED_2819735031800[v497] = u7(UNNAMED_2819735031800[v497], (u6(u5(v496, 14), 127)));
                                            UNNAMED_2819735065448[v497] = u7(UNNAMED_2819735065448[v497], (u6(u5(v496, 21), 127)));
                                            v497 = v497 + 1;
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735065448[v22] = 17;
                                    end;
                                else
                                    v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735043896[v22]](v29[UNNAMED_2819735031800[v22]]);
                                end;
                            elseif v433 < 45 then
                                if v433 == 44 then
                                    if v29[UNNAMED_2819735031800[v22]] then
                                        v22 = UNNAMED_2819735043896[v22];
                                    else
                                        v22 = UNNAMED_2819735090024[v22];
                                    end;
                                else
                                    v22 = v29[UNNAMED_2819735043896[v22]];
                                end;
                            elseif v433 >= 46 then
                                if v433 == 47 then
                                    local v500 = u7(UNNAMED_2819735043896[v22], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                                    local v501 = UNNAMED_2819735090024[v22] + 1;

                                    for i = 1, UNNAMED_2819735031800[v22] do
                                        local v502 = u6(u7(v500, (u8(v500, 13))), 536870911);
                                        local v503 = u7(v502, (u5(v502, 13)));
                                        v500 = u6(u7(v503, (u8(v503, 14))), 536870911);
                                        UNNAMED_2819735090024[v501] = u7(UNNAMED_2819735090024[v501], (u6(u5(v500, 0), 127)));
                                        UNNAMED_2819735043896[v501] = u7(UNNAMED_2819735043896[v501], (u6(u5(v500, 7), 127)));
                                        UNNAMED_2819735031800[v501] = u7(UNNAMED_2819735031800[v501], (u6(u5(v500, 14), 127)));
                                        UNNAMED_2819735065448[v501] = u7(UNNAMED_2819735065448[v501], (u6(u5(v500, 21), 127)));
                                        v501 = v501 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735065448[v22] = 17;
                                elseif v26 then
                                    local v504 = UNNAMED_2819735043896[v22];
                                    local v505 = v26[v504];

                                    if v505 then
                                        v505[5] = v505;
                                        v505[6] = v29[v504];
                                        v505[4] = 6;
                                        v26[v504] = nil;
                                    end;

                                    local v506 = UNNAMED_2819735031800[v22];
                                    local v507 = v26[v506];

                                    if v507 then
                                        v507[5] = v507;
                                        v507[6] = v29[v506];
                                        v507[4] = 6;
                                        v26[v506] = nil;
                                    end;
                                end;
                            else
                                v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] + UNNAMED_2819735028776[v22];
                            end;
                        elseif v433 >= 76 then
                            if v433 >= 81 then
                                if v433 < 84 then
                                    if v433 >= 82 then
                                        if v433 == 83 then
                                            local v508 = u7(UNNAMED_2819735043896[v22], (u6(u7(v20, (u6(u5(v20, 29), 7))), 536870911)));
                                            local v509 = UNNAMED_2819735090024[v22] + 1;

                                            for i = 1, UNNAMED_2819735031800[v22] do
                                                local v510 = u6(u7(v508, (u8(v508, 13))), 536870911);
                                                local v511 = u7(v510, (u5(v510, 13)));
                                                v508 = u6(u7(v511, (u8(v511, 14))), 536870911);
                                                UNNAMED_2819735090024[v509] = u7(UNNAMED_2819735090024[v509], (u6(u5(v508, 0), 127)));
                                                UNNAMED_2819735043896[v509] = u7(UNNAMED_2819735043896[v509], (u6(u5(v508, 7), 127)));
                                                UNNAMED_2819735031800[v509] = u7(UNNAMED_2819735031800[v509], (u6(u5(v508, 14), 127)));
                                                UNNAMED_2819735065448[v509] = u7(UNNAMED_2819735065448[v509], (u6(u5(v508, 21), 127)));
                                                v509 = v509 + 1;
                                                local _ = i;
                                            end;

                                            UNNAMED_2819735065448[v22] = 17;
                                        else
                                            v29[UNNAMED_2819735090024[v22]] = u7(v29[UNNAMED_2819735043896[v22]], v29[UNNAMED_2819735031800[v22]]);
                                        end;
                                    else
                                        v29[UNNAMED_2819735031800[v22]] = v29[UNNAMED_2819735043896[v22]] * v29[UNNAMED_2819735090024[v22]];
                                    end;
                                elseif v433 < 85 then
                                    v21 = v29[UNNAMED_2819735031800[v22]];
                                elseif v433 == 86 then
                                    v27 = v30[8];
                                    v31 = v30[5];
                                    v28 = v30[7];
                                    v25 = v30[6];
                                    v30 = v30[9];
                                else
                                    v29[UNNAMED_2819735043896[v22]](v29[UNNAMED_2819735031800[v22]]);
                                end;
                            elseif v433 < 78 then
                                if v433 == 77 then
                                    if v29[UNNAMED_2819735031800[v22]] >= UNNAMED_2819735043896[v22] then
                                        v22 = UNNAMED_2819735090024[v22];
                                    end;
                                else
                                    local v512 = UNNAMED_2819735031800[v22];
                                    local v513 = UNNAMED_2819735043896[v22];
                                    local v514 = UNNAMED_2819735053352[5];
                                    local v515 = u7(v514[v512], 109162203);
                                    v514[v512] = v515;
                                    local v516 = UNNAMED_2819735053352[4];
                                    local v517 = v515 + 1;
                                    local v518 = u9(v516, v517);
                                    local v519;

                                    if v518 < 128 then
                                        v519 = v517 + 1;
                                    else
                                        local v520 = u9(v516, v517 + 1);

                                        if v520 < 128 then
                                            v518 = v518 - 128 + v520 * 128;
                                            v519 = v517 + 2;
                                        else
                                            local v521 = u9(v516, v517 + 2);

                                            if v521 < 128 then
                                                v518 = v518 - 128 + (v520 - 128) * 16384 + v521 * 128;
                                                v519 = v517 + 3;
                                            else
                                                local v522 = u9(v516, v517 + 3);
                                                v518 = (v518 - 128) * 16384 + (v520 - 128) * 128 + (v521 - 128) + v522 % 128 * 2097152 + (v522 - v522 % 128) * 2097152;
                                                v519 = v517 + 4;
                                            end;
                                        end;
                                    end;

                                    local v523 = v513 * 16843009;
                                    local v524 = v519 + v518;
                                    local v525 = v524 - v518 % 4;

                                    for i = v519, v525 - 1, 4 do
                                        u10(v516, i, (u7(u11(v516, i), v523)));
                                        local _ = i;
                                    end;

                                    for i = v525, v524 - 1 do
                                        u12(v516, i, (u7(u9(v516, i), v513)));
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735031800[v22] = 176;
                                    UNNAMED_2819735043896[v22] = 125;
                                    UNNAMED_2819735090024[v22] = 24;
                                    UNNAMED_2819735065448[v22] = 17;
                                end;
                            elseif v433 < 79 then
                                local v526 = UNNAMED_2819735090024[v22];
                                local v527 = u7(UNNAMED_2819735043896[v22], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                                local v528 = UNNAMED_2819735053352[5];
                                local v529 = u7(v528[v526], 109162203);
                                v528[v526] = v529;
                                local v530 = UNNAMED_2819735053352[4];
                                local v531 = v529 + 1;
                                local v532 = u9(v530, v531);
                                local v533;

                                if v532 < 128 then
                                    v533 = v531 + 1;
                                else
                                    local v534 = u9(v530, v531 + 1);

                                    if v534 < 128 then
                                        v532 = v532 - 128 + v534 * 128;
                                        v533 = v531 + 2;
                                    else
                                        local v535 = u9(v530, v531 + 2);

                                        if v535 < 128 then
                                            v532 = v532 - 128 + (v534 - 128) * 16384 + v535 * 128;
                                            v533 = v531 + 3;
                                        else
                                            local v536 = u9(v530, v531 + 3);
                                            v532 = (v532 - 128) * 16384 + (v534 - 128) * 128 + (v535 - 128) + v536 % 128 * 2097152 + (v536 - v536 % 128) * 2097152;
                                            v533 = v531 + 4;
                                        end;
                                    end;
                                end;

                                local v537 = v527 * 16843009;
                                local v538 = v533 + v532;
                                local v539 = v538 - v532 % 4;

                                for i = v533, v539 - 1, 4 do
                                    u10(v530, i, (u7(u11(v530, i), v537)));
                                    local _ = i;
                                end;

                                for i = v539, v538 - 1 do
                                    u12(v530, i, (u7(u9(v530, i), v527)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735090024[v22] = 117;
                                UNNAMED_2819735043896[v22] = 65;
                                UNNAMED_2819735031800[v22] = 128;
                                UNNAMED_2819735065448[v22] = 17;
                            elseif v433 == 80 then
                                local v540 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                v540[5][v540[4]] = v29[UNNAMED_2819735031800[v22]];
                            elseif v29[UNNAMED_2819735090024[v22]] ~= UNNAMED_2819735043896[v22] then
                                v22 = UNNAMED_2819735031800[v22];
                            end;
                        else
                            if v433 < 70 then
                                if v433 < 67 then
                                    if v433 == 66 then
                                        v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735031800[v22]];
                                    else
                                        v29[UNNAMED_2819735090024[v22]] = UNNAMED_2819735043896;
                                    end;
                                elseif v433 >= 68 then
                                    if v433 == 69 then
                                        if v29[UNNAMED_2819735043896[v22]] ~= v29[UNNAMED_2819735090024[v22]] then
                                            v22 = UNNAMED_2819735031800[v22];
                                        end;
                                    elseif UNNAMED_2819735031800[v22] >= v29[UNNAMED_2819735090024[v22]] then
                                        v22 = UNNAMED_2819735043896[v22];
                                    end;
                                else
                                    local v541 = nil;
                                    local v542 = UNNAMED_2819735090024[v22];
                                    local v543 = UNNAMED_2819735028776[v22];
                                    local v544 = UNNAMED_2819735071880[v22];
                                    local v545 = v544[0];

                                    if v545 then
                                        local v546 = #v545 / 3;

                                        if v546 > 0 then
                                            v541 = {};

                                            for i = 1, v546 do
                                                local v547 = (i - 1) * 3;
                                                local v548 = v545[v547 + 2];
                                                local v549 = v545[v547 + 1];
                                                local v550;

                                                if v548 == 2 then
                                                    v26 = v26 or {};
                                                    local v551 = v26[v549];

                                                    if not v551 then
                                                        v551 = {
                                                            [5] = v29,
                                                            [4] = v549
                                                        };
                                                        v26[v549] = v551;
                                                    end;

                                                    v541[i] = v551;
                                                    v550 = i;
                                                elseif v548 == 0 then
                                                    v541[i] = v29[v549];
                                                    v550 = i;
                                                elseif v548 == 3 then
                                                    v541[i] = UNNAMED_2819732806552[v549];
                                                    v550 = i;
                                                elseif v548 == 1 then
                                                    v32 = v32 or {};
                                                    local v552 = v32[v549];

                                                    if not v552 then
                                                        v552 = {
                                                            [5] = v29,
                                                            [4] = v549,
                                                            [6] = v545[v547 + 3]
                                                        };
                                                        v32[v549] = v552;
                                                    end;

                                                    v541[i] = v552;
                                                    v550 = i;
                                                else
                                                    v550 = i;
                                                end;
                                            end;
                                        end;
                                    end;

                                    local v553 = v544[-2];
                                    v544[v553] = v541;
                                    local v554 = v543(u3(v544, 1, v544[-1]));
                                    v544[v553] = nil;
                                    v29[v542] = v554;
                                end;

                                v432 = 1;
                                continue;
                            end;

                            if v433 >= 73 then
                                if v433 >= 74 then
                                    if v433 == 75 then
                                        v29[UNNAMED_2819735090024[v22]] = v29[UNNAMED_2819735043896[v22]]();
                                    else
                                        local v555 = UNNAMED_2819732806552[UNNAMED_2819735043896[v22]];
                                        v555[5][v555[4]][v29[UNNAMED_2819735090024[v22]]] = v29[UNNAMED_2819735031800[v22]];
                                    end;
                                else
                                    v29[UNNAMED_2819735031800[v22]] = UNNAMED_2819735090024;
                                end;

                                v432 = 1;
                                continue;
                            end;

                            if v433 >= 71 then
                                if v433 ~= 72 then
                                    v29[UNNAMED_2819735043896[v22]] = v29[UNNAMED_2819735090024[v22]] - v29[UNNAMED_2819735031800[v22]];
                                    v432 = 1;
                                    continue;
                                end;

                                v23 = UNNAMED_2819735043896[v22];
                                v22 = UNNAMED_2819735031800[v22] + 1;
                                v34 = 7;
                                break;
                            end;

                            v29[UNNAMED_2819735090024[v22]] = u6(v29[UNNAMED_2819735031800[v22]], UNNAMED_2819735071880[v22]);
                        end;

                        v432 = 1;
                        continue;
                    elseif v432 == 1 then
                        v432 = -1;
                        v22 = v22 + 1;
                        break;
                    else
                        break;
                    end;
                end;

                if v34 ~= -1 then
                    break;
                end;
            end;

            if v34 ~= -1 then
                continue;
            end;

            v34 = 11;
            continue;
        elseif v34 == 11 then
            v34 = -1;
            v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735031800[v24]] * v29[UNNAMED_2819735090024[v24]];
            v34 = 12;
            continue;
        elseif v34 == 12 then
            v34 = -1;
            v34 = 14;
            continue;
        elseif v34 == 13 then
            v34 = -1;

            if v33 < 60 then
                if v33 == 59 then
                    v27 = v27 + v28;
                    local v556;

                    if v28 <= 0 then
                        v556 = v31 <= v27;
                    else
                        v556 = v27 <= v31;
                    end;

                    if v556 then
                        v29[UNNAMED_2819735090024[v24]] = v27;
                        v24 = UNNAMED_2819735065448[v24];
                    else
                        v24 = UNNAMED_2819735031800[v24];
                    end;
                else
                    v29[UNNAMED_2819735065448[v24]] = u7(v29[UNNAMED_2819735031800[v24]], UNNAMED_2819735090024[v24]);
                end;
            elseif v33 >= 61 then
                if v33 ~= 62 and UNNAMED_2819735028776[v24] > v29[UNNAMED_2819735065448[v24]] then
                    v24 = UNNAMED_2819735090024[v24];
                end;
            else
                local v557 = UNNAMED_2819735065448[v24];
                local v558 = u7(UNNAMED_2819735090024[v24], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                local v559 = UNNAMED_2819735053352[5];
                local v560 = u7(v559[v557], 109162203);
                v559[v557] = v560;
                local v561 = UNNAMED_2819735053352[4];
                local v562 = v560 + 1;
                local v563 = u9(v561, v562);
                local v564;

                if v563 < 128 then
                    v564 = v562 + 1;
                else
                    local v565 = u9(v561, v562 + 1);

                    if v565 < 128 then
                        v563 = v563 - 128 + v565 * 128;
                        v564 = v562 + 2;
                    else
                        local v566 = u9(v561, v562 + 2);

                        if v566 < 128 then
                            v563 = v563 - 128 + (v565 - 128) * 16384 + v566 * 128;
                            v564 = v562 + 3;
                        else
                            local v567 = u9(v561, v562 + 3);
                            v563 = (v563 - 128) * 16384 + (v565 - 128) * 128 + (v566 - 128) + v567 % 128 * 2097152 + (v567 - v567 % 128) * 2097152;
                            v564 = v562 + 4;
                        end;
                    end;
                end;

                local v568 = v558 * 16843009;
                local v569 = v564 + v563;
                local v570 = v569 - v563 % 4;

                for i = v564, v570 - 1, 4 do
                    u10(v561, i, (u7(u11(v561, i), v568)));
                    local _ = i;
                end;

                for i = v570, v569 - 1 do
                    u12(v561, i, (u7(u9(v561, i), v558)));
                    local _ = i;
                end;

                UNNAMED_2819735065448[v24] = 22;
                UNNAMED_2819735090024[v24] = 188;
                UNNAMED_2819735031800[v24] = 154;
                UNNAMED_2819735043896[v24] = 62;
            end;

            v34 = 14;
            continue;
        elseif v34 == 14 then
            v34 = -1;
            v34 = 16;
            continue;
        elseif v34 == 15 then
            v34 = -1;

            if v33 < 18 then
                if v33 < 9 then
                    if v33 >= 4 then
                        if v33 >= 6 then
                            if v33 < 7 then
                                v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735065448[v24]];
                            else
                                if v33 == 8 then
                                    return;
                                end;

                                v24 = UNNAMED_2819735031800[v24];
                            end;
                        elseif v33 == 5 then
                            v29[UNNAMED_2819735031800[v24]] = v29[UNNAMED_2819735090024[v24]] - UNNAMED_2819735080952[v24];
                        else
                            v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735065448[v24]] % UNNAMED_2819735031800[v24];
                        end;
                    elseif v33 >= 2 then
                        if v33 == 3 then
                            local v571 = UNNAMED_2819732806552[UNNAMED_2819735090024[v24]];
                            v29[UNNAMED_2819735065448[v24]] = v571[5][v571[4]];
                        else
                            local v572 = UNNAMED_2819735090024[v24];
                            local v573 = v29[UNNAMED_2819735065448[v24]];
                            v29[v572] = v29[UNNAMED_2819735031800[v24]];
                            v29[v572 + 1] = v573;
                        end;
                    elseif v33 == 1 then
                        local v574 = UNNAMED_2819735065448[v24];
                        local v575 = UNNAMED_2819735031800[v24];
                        local v576 = UNNAMED_2819735090024[v24];
                        local _ = v574 + v576 - 1;
                        local _ = v574 + v575;
                        u4(u2(v29[v574](u3(v29, v574 + 1, v574 + v575))), 1, v576, v574, v29);
                    else
                        v29[UNNAMED_2819735031800[v24]] = v29[UNNAMED_2819735065448[v24]] == UNNAMED_2819735090024[v24];
                    end;
                elseif v33 < 13 then
                    if v33 < 11 then
                        if v33 == 10 then
                            v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735031800[v24]] == v29[UNNAMED_2819735090024[v24]];
                        else
                            v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735031800[v24]] // UNNAMED_2819735090024[v24];
                        end;
                    elseif v33 == 12 then
                        v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735031800[v24]] > UNNAMED_2819735090024[v24];
                    else
                        v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735031800[v24]] - UNNAMED_2819735065448[v24];
                    end;
                elseif v33 < 15 then
                    if v33 == 14 then
                        if v29[UNNAMED_2819735065448[v24]] > UNNAMED_2819735031800[v24] then
                            v24 = UNNAMED_2819735090024[v24];
                        end;
                    else
                        v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735031800[v24]][UNNAMED_2819735080952[v24]];
                    end;
                elseif v33 < 16 then
                    v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735065448[v24]] + v29[UNNAMED_2819735031800[v24]];
                else
                    if v33 ~= 17 then
                        return UNNAMED_2819735056376[v24];
                    end;

                    v29[UNNAMED_2819735090024[v24]] = UNNAMED_2819735065448[v24] + v29[UNNAMED_2819735031800[v24]];
                end;
            elseif v33 >= 27 then
                if v33 >= 31 then
                    if v33 < 33 then
                        if v33 == 32 then
                            v29[UNNAMED_2819735031800[v24]] = v21;
                        else
                            v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735031800[v24]] - v29[UNNAMED_2819735065448[v24]];
                        end;
                    elseif v33 >= 34 then
                        if v33 == 35 then
                            local v577 = u7(UNNAMED_2819735090024[v24], (u6(u7(v21, (u6(u5(v21, 29), 7))), 536870911)));
                            local v578 = UNNAMED_2819735065448[v24] + 1;

                            for i = 1, UNNAMED_2819735031800[v24] do
                                local v579 = u6(u7(v577, (u8(v577, 13))), 536870911);
                                local v580 = u7(v579, (u5(v579, 13)));
                                v577 = u6(u7(v580, (u8(v580, 14))), 536870911);
                                UNNAMED_2819735065448[v578] = u7(UNNAMED_2819735065448[v578], (u6(u5(v577, 0), 127)));
                                UNNAMED_2819735090024[v578] = u7(UNNAMED_2819735090024[v578], (u6(u5(v577, 7), 127)));
                                UNNAMED_2819735031800[v578] = u7(UNNAMED_2819735031800[v578], (u6(u5(v577, 14), 127)));
                                UNNAMED_2819735043896[v578] = u7(UNNAMED_2819735043896[v578], (u6(u5(v577, 21), 127)));
                                v578 = v578 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735043896[v24] = 62;
                        else
                            v29[UNNAMED_2819735065448[v24]] = UNNAMED_2819732806552[UNNAMED_2819735090024[v24]][v29[UNNAMED_2819735031800[v24]]];
                        end;
                    else
                        v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735090024[v24]] * UNNAMED_2819735031800[v24];
                    end;
                elseif v33 >= 29 then
                    if v33 == 30 then
                        v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735090024[v24]] * UNNAMED_2819735028776[v24];
                    else
                        v29[UNNAMED_2819735065448[v24]] = v29[UNNAMED_2819735031800[v24]](v29[UNNAMED_2819735090024[v24]]);
                    end;
                elseif v33 == 28 then
                    v29[UNNAMED_2819735031800[v24]] = u7(v29[UNNAMED_2819735090024[v24]], v29[UNNAMED_2819735065448[v24]]);
                else
                    v29[UNNAMED_2819735090024[v24]] = v20;
                end;
            elseif v33 < 22 then
                if v33 >= 20 then
                    if v33 == 21 then
                        local v581 = UNNAMED_2819735031800[v24];
                        local v582 = v29[UNNAMED_2819735065448[v24]];
                        v29[v581] = UNNAMED_2819735090024[v24];
                        v29[v581 + 1] = v582;
                    else
                        v20 = v29[UNNAMED_2819735031800[v24]];
                    end;
                elseif v33 == 19 then
                    v29[UNNAMED_2819735065448[v24]] = u8(v29[UNNAMED_2819735090024[v24]], UNNAMED_2819735031800[v24]);
                elseif v29[UNNAMED_2819735065448[v24]] then
                    v24 = UNNAMED_2819735031800[v24];
                else
                    v24 = UNNAMED_2819735090024[v24];
                end;
            elseif v33 < 24 then
                if v33 == 23 then
                    v29[UNNAMED_2819735031800[v24]] = UNNAMED_2819732806552[UNNAMED_2819735090024[v24]];
                else
                    v29[UNNAMED_2819735031800[v24]] = UNNAMED_2819735090024[v24] * v29[UNNAMED_2819735065448[v24]];
                end;
            elseif v33 >= 25 then
                if v33 == 26 then
                    local v583 = v29[UNNAMED_2819735065448[v24]] % 4294967296;
                    v29[UNNAMED_2819735090024[v24]] = v583 ~= v583 and 0 or v583 - v583 % 1;
                else
                    v29[UNNAMED_2819735031800[v24]] = v29[UNNAMED_2819735090024[v24]] // v29[UNNAMED_2819735065448[v24]];
                end;
            else
                v29[UNNAMED_2819735090024[v24]] = v29[UNNAMED_2819735065448[v24]][v29[UNNAMED_2819735031800[v24]]];
            end;

            v34 = 16;
            continue;
        elseif v34 == 16 then
            v34 = -1;
            v24 = v24 + 1;
            v34 = 1;
            continue;
        elseif v34 == 17 then
            v34 = -1;
            break;
        else
            break;
        end;
    end;
end;