-- Decompiled with Potassium's decompiler.

return true, 18, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil;