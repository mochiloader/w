-- Decompiled with Potassium's decompiler.

return true, 117, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil;