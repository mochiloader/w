-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3, p4) -- Line: 3
    local u5 = p3[1];
    local u6 = p3[2];
    local u7 = p3[3];
    local u8 = p3[4];
    local u9 = p3[5];
    local u10 = p3[6];
    local u11 = p3[7];

    return function() -- Line: 3
        -- upvalues: u5 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy)
        local v12 = u6 or function() -- Line: 3
        end;

        for _, v in (u5 or function() -- Line: 3
            return {};
        end)() do
            if u7(v) == "function" then
                local v13 = v12(v);
                local info = u8.getinfo(v);

                if v13 and v13.name ~= info.name then
                    u9(2);
                    break;
                end;
            end;
        end;

        local v14 = nil;

        for _, v in u10 do
            if u7(v) == "function" then
                local l_isShitsploit = isShitsploit;

                if l_isShitsploit then
                    v12 = not l_isShitsploit;
                end;

                v12 = v12 or function() -- Line: 3
                end;
                local v15 = v12(v);

                if v15 and (v15.name == "request" and u11 ~= v) then
                    if not v14 then
                        return;
                    end;

                    u9(4);

                    return;
                end;
            end;
        end;
    end;
end;