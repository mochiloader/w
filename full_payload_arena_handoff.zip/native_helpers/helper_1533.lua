-- Decompiled with Potassium's decompiler.

local u1 = UNNAMED_2819735049656[21];
local u2 = UNNAMED_2819735049656[80];
local _3 = UNNAMED_2819735049656._3;
local u3 = UNNAMED_2819735049656[43];
local u4 = UNNAMED_2819735049656[67];
local u5 = UNNAMED_2819735049656[113];
local u6 = UNNAMED_2819735049656[47];
local u7 = UNNAMED_2819735049656[11];
local u8 = UNNAMED_2819735049656[22];
local u9 = UNNAMED_2819735049656[105];
local u10 = UNNAMED_2819735049656[5];
local u11 = UNNAMED_2819735049656[93];
local u12 = UNNAMED_2819735049656[35];
local u13 = UNNAMED_2819735049656[110];
local u14 = UNNAMED_2819735049656[84];
local u15 = UNNAMED_2819735049656[59];
local G3 = UNNAMED_2819735049656.G3;

return function(p16, p17, u18, u19, p20) -- Line: 3, Name: C
    -- upvalues: u1 (copy), u2 (copy), _3 (copy), u3 (copy), u4 (copy), u5 (copy), u6 (copy), u7 (copy), u8 (copy), u9 (copy), u10 (copy), u11 (copy), u12 (copy), u13 (copy), u14 (copy), u15 (copy), G3 (copy), UNNAMED_2819735031224 (copy), UNNAMED_2819735076968 (copy), UNNAMED_2819735043128 (copy), UNNAMED_2819735064680 (copy), UNNAMED_2819735070824 (copy), UNNAMED_2819735046248 (copy), UNNAMED_2819735027960 (copy), UNNAMED_2819735047544 (copy), UNNAMED_2819735090456 (copy), UNNAMED_2819735087432 (copy), UNNAMED_2819735059736 (copy), UNNAMED_2819735049656 (copy), UNNAMED_2819735065880 (copy), UNNAMED_2819735084312 (copy)
    local u21 = u1;
    local u22 = u2;
    local u23 = _3;
    local u24 = u3;
    local u25 = u4;
    local u26 = u5;
    local u27 = u6;
    local u28 = u7;
    local u29 = u8;
    local u30 = u9;
    local u31 = u10;
    local u32 = u11;
    local u33 = u12;
    local u34 = u13;
    local u35 = u14;
    local u36 = u15;
    local u37 = G3;

    return function(...) -- Line: 3, Name: N
        -- upvalues: u18 (copy), u21 (copy), UNNAMED_2819735031224 (ref), UNNAMED_2819735076968 (ref), UNNAMED_2819735043128 (ref), u25 (copy), u27 (copy), u26 (copy), u23 (copy), u24 (copy), u28 (copy), u29 (copy), u30 (copy), u31 (copy), u32 (copy), u33 (copy), u34 (copy), u35 (copy), u36 (copy), u22 (copy), UNNAMED_2819735064680 (ref), u19 (copy), UNNAMED_2819735070824 (ref), UNNAMED_2819735046248 (ref), UNNAMED_2819735027960 (ref), UNNAMED_2819735047544 (ref), UNNAMED_2819735090456 (ref), UNNAMED_2819735087432 (ref), UNNAMED_2819735059736 (ref), UNNAMED_2819735049656 (ref), UNNAMED_2819735065880 (ref), u37 (copy), UNNAMED_2819735084312 (ref)
        local u38 = u18;
        local u39 = u21(UNNAMED_2819735031224);
        local u40 = UNNAMED_2819735076968;
        local u41 = UNNAMED_2819735043128;
        local u42 = nil;
        local u43 = nil;
        local u44 = u25;
        local u45 = u26;
        local u46 = u23;
        local u47 = u24;
        local u48 = u28;
        local u49 = u29;
        local u50 = u30;
        local u51 = u31;
        local u52 = u32;
        local u53 = u33;
        local u54 = u34;
        local u55 = u35;
        local u56 = u36;
        local v445, v446, v447, v448, v449 = u22(function(...) -- Line: 3
            -- upvalues: u41 (copy), UNNAMED_2819735064680 (ref), u40 (ref), u39 (copy), u19 (ref), UNNAMED_2819735070824 (ref), UNNAMED_2819735046248 (ref), UNNAMED_2819735027960 (ref), UNNAMED_2819735047544 (ref), u46 (copy), UNNAMED_2819735090456 (ref), UNNAMED_2819735087432 (ref), u47 (copy), u44 (copy), u45 (copy), u38 (ref), UNNAMED_2819735059736 (ref), u48 (copy), u49 (copy), u50 (copy), u51 (copy), u52 (copy), UNNAMED_2819735049656 (ref), u54 (copy), u53 (copy), u55 (copy), u56 (copy), UNNAMED_2819735065880 (ref), u42 (copy), u43 (copy)
            if u41 == 158 then
                while true do
                    local v57 = UNNAMED_2819735064680[u40];

                    if v57 < 54 then
                        if v57 >= 27 then
                            if v57 < 40 then
                                if v57 >= 33 then
                                    if v57 >= 36 then
                                        if v57 < 38 then
                                            if v57 == 37 then
                                                u39[2] = u19[UNNAMED_2819735070824[u40]];
                                                u39[14] = u39[2]();
                                                local v58;

                                                if u39[UNNAMED_2819735064680[u40 + 1]] then
                                                    v58 = UNNAMED_2819735046248[u40] - 1;
                                                else
                                                    v58 = UNNAMED_2819735027960[u40] - 1;
                                                end;

                                                u40 = v58;
                                                u40 = u40 + 1;
                                            else
                                                u39[5] = u19[UNNAMED_2819735046248[u40 + 3]];
                                                local v59 = u39[UNNAMED_2819735064680[u40 + 1]];
                                                u39[4] = v59;
                                                u39[3] = v59[UNNAMED_2819735047544[u40 + 2]];
                                                local v60 = 3;
                                                u39[UNNAMED_2819735064680[u40 + 3]] = u39[3];
                                                u39[3] = u46[UNNAMED_2819735090456[u40 + 3]][UNNAMED_2819735087432[u40 + 1]];
                                                u39[5] = u39[3][UNNAMED_2819735047544[u40 + 3]];
                                                u39[3] = u39[2];
                                                local v61 = UNNAMED_2819735064680[u40 + 2];
                                                local v62 = UNNAMED_2819735027960[u40];
                                                local _ = v60 + v62 - 1;
                                                local _ = v60 + v61;
                                                u45(u47(u39[v60](u44(u39, 4, v60 + v61))), 1, v62, v60, u39);
                                                local v63;

                                                if u39[UNNAMED_2819735046248[u40 + 2]] then
                                                    v63 = UNNAMED_2819735070824[u40] - 3;
                                                else
                                                    v63 = UNNAMED_2819735070824[u40 + 2] - 3;
                                                end;

                                                u40 = v63;
                                                u40 = u40 + 3;
                                            end;
                                        else
                                            if v57 == 39 then
                                                u39[1] = u19[UNNAMED_2819735046248[u40]][UNNAMED_2819735047544[u40]];
                                                local v64 = u39[32];
                                                u39[2] = u47(u44(v64, 1, v64.n));
                                                u39[3] = u19[UNNAMED_2819735070824[u40]];

                                                return true, true, 1, u47(u39[3], u44(u39[2], 1, u39[2].n));
                                            end;

                                            u39[2] = u39[2][UNNAMED_2819735047544[u40]];
                                            local v65;

                                            if u39[2] then
                                                v65 = UNNAMED_2819735046248[u40];
                                            else
                                                v65 = UNNAMED_2819735070824[u40];
                                            end;

                                            u40 = v65;
                                        end;
                                    elseif v57 < 34 then
                                        u39[2] = u19[UNNAMED_2819735027960[u40]][UNNAMED_2819735087432[u40 + 1]];
                                        u39[2] = u39[2][UNNAMED_2819735047544[u40 + 1]];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = not u39[2];
                                        local v66;

                                        if u39[2] then
                                            v66 = UNNAMED_2819735046248[u40] - 1;
                                        else
                                            v66 = UNNAMED_2819735070824[u40 + 1] - 1;
                                        end;

                                        u40 = v66;
                                        u40 = u40 + 1;
                                    elseif v57 == 35 then
                                        u39[4] = UNNAMED_2819735047544[u40];
                                        u40 = UNNAMED_2819735046248[u40];
                                    else
                                        u40 = UNNAMED_2819735027960[u40];
                                    end;
                                elseif v57 < 30 then
                                    if v57 < 28 then
                                        local v67 = u19[UNNAMED_2819735027960[u40 + 2]];
                                        u39[UNNAMED_2819735064680[u40 + 2]] = v67[5][v67[4]];
                                        local v68 = u19[UNNAMED_2819735070824[u40 + 2]];
                                        u39[4] = v68[5][v68[4]];
                                        u39[3] = 1 - u39[4];
                                        u39[UNNAMED_2819735064680[u40 + 3]] = u39[3] * u39[8];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = u39[2] + u39[3];
                                        local v69 = u19[UNNAMED_2819735070824[u40 + 3]];
                                        v69[5][v69[4]] = u39[2];
                                        local v70 = u19[UNNAMED_2819735070824[u40 + 1]];
                                        u39[4] = v70[5][v70[4]];
                                        local v71 = u19[UNNAMED_2819735027960[u40]];
                                        v71[5][v71[4]][UNNAMED_2819735047544[u40 + 1]] = u39[UNNAMED_2819735046248[u40]];
                                        local v72 = u19[UNNAMED_2819735046248[u40 + 2]];
                                        u39[2] = v72[5][v72[4]];

                                        if UNNAMED_2819735090456[u40] >= u39[2] then
                                            u40 = UNNAMED_2819735046248[u40 + 3] - 3;
                                        end;

                                        u40 = u40 + 3;
                                    elseif v57 == 29 then
                                        local v73 = u19[UNNAMED_2819735027960[u40]];
                                        u39[2] = v73[5][v73[4]];
                                        local v74;

                                        if u39[2] then
                                            v74 = UNNAMED_2819735046248[u40];
                                        else
                                            v74 = UNNAMED_2819735070824[u40];
                                        end;

                                        u40 = v74;
                                    else
                                        u39[4] = u19[UNNAMED_2819735070824[u40]][UNNAMED_2819735087432[u40 + 1]];
                                        local v75;

                                        if u39[4] then
                                            v75 = UNNAMED_2819735027960[u40 + 1] - 1;
                                        else
                                            v75 = UNNAMED_2819735070824[u40 + 1] - 1;
                                        end;

                                        u40 = v75;
                                        u40 = u40 + 1;
                                    end;
                                elseif v57 < 31 then
                                    local v76 = 1;
                                    u39[5] = u19[UNNAMED_2819735027960[u40 + 1]];
                                    local v77 = u39[5];
                                    u39[4] = v77;
                                    u39[3] = v77[UNNAMED_2819735090456[u40 + 1]];
                                    u39[2] = u39[3];
                                    u39[3] = u46[UNNAMED_2819735090456[u40 + 2]][UNNAMED_2819735047544[u40]];
                                    u39[5] = u39[3][UNNAMED_2819735087432[u40]];
                                    u39[3] = u39[2];
                                    local v78 = UNNAMED_2819735064680[u40 + 2];
                                    local v79 = UNNAMED_2819735064680[u40 + 1];
                                    local _ = v78 + v76 - 1;
                                    local _ = v78 + v79;
                                    u45(u47(u39[v78](u44(u39, v78 + 1, v78 + v79))), 1, v76, v78, u39);
                                    local v80;

                                    if u39[UNNAMED_2819735027960[u40 + 2]] then
                                        v80 = UNNAMED_2819735046248[u40 + 2] - 2;
                                    else
                                        v80 = UNNAMED_2819735070824[u40] - 2;
                                    end;

                                    u40 = v80;
                                    u40 = u40 + 2;
                                else
                                    if v57 ~= 32 then
                                        local v81 = u19[UNNAMED_2819735070824[u40 + 1]];
                                        u39[9] = v81[5][v81[4]];
                                        local v82 = u39[UNNAMED_2819735064680[u40 + 1]];
                                        u39[5] = v82;
                                        u39[4] = v82[UNNAMED_2819735087432[u40 + 1]];
                                        u39[4](u39[5]);
                                        local v83 = u19[UNNAMED_2819735027960[u40 + 1]];
                                        v83[5][v83[4]] = u39[11];

                                        return false, false;
                                    end;

                                    u39[2] = u19[UNNAMED_2819735027960[u40 + 1]][UNNAMED_2819735047544[u40 + 4]];
                                    u39[2] = u39[2](UNNAMED_2819735047544[u40 + 3]);
                                    local v84 = u19[UNNAMED_2819735046248[u40 + 1]];
                                    v84[5][v84[4]] = u39[2];
                                    u39[2] = 118289103;
                                    u38 = u39[2];
                                    local v85 = u19[UNNAMED_2819735046248[u40 + 4]];
                                    v85[5][v85[4]][UNNAMED_2819735090456[u40]] = UNNAMED_2819735047544[u40 + 6];
                                    local v86 = u19[UNNAMED_2819735070824[u40 + 1]];
                                    v86[5][v86[4]][UNNAMED_2819735090456[u40 + 5]] = UNNAMED_2819735087432[u40 + 6];
                                    local v87 = u19[UNNAMED_2819735027960[u40 + 2]];
                                    v87[5][v87[4]][UNNAMED_2819735087432[u40 + 5]] = UNNAMED_2819735047544[u40];
                                    local v88 = u19[UNNAMED_2819735070824[u40 + 4]];
                                    v88[5][v88[4]][UNNAMED_2819735090456[u40 + 2]] = UNNAMED_2819735090456[u40 + 6];
                                    local v89 = u19[UNNAMED_2819735070824[u40 + 3]];
                                    v89[5][v89[4]][UNNAMED_2819735087432[u40]] = 1;
                                    local v90 = u19[UNNAMED_2819735027960[u40 + 5]];
                                    v90[5][v90[4]][UNNAMED_2819735087432[u40 + 2]] = UNNAMED_2819735087432[u40 + 3];
                                    u40 = u40 + 6;
                                end;
                            elseif v57 >= 47 then
                                if v57 < 50 then
                                    if v57 >= 48 then
                                        if v57 == 49 then
                                            u39[5] = u19[UNNAMED_2819735046248[u40 + 1]];
                                            local v91 = u39[5];
                                            u39[3] = v91;
                                            u39[2] = v91[UNNAMED_2819735090456[u40 + 2]];
                                            u39[4] = u19[UNNAMED_2819735046248[u40 + 2]];
                                            u39[UNNAMED_2819735064680[u40 + 2]](u39[UNNAMED_2819735064680[u40 + 1]], u39[4]);
                                            local v92 = u19[UNNAMED_2819735027960[u40]];
                                            u39[2] = v92[5][v92[4]];
                                            local v93;

                                            if u39[2] then
                                                v93 = UNNAMED_2819735046248[u40] - 2;
                                            else
                                                v93 = UNNAMED_2819735070824[u40] - 2;
                                            end;

                                            u40 = v93;
                                            u40 = u40 + 2;
                                        else
                                            local v94 = u19[UNNAMED_2819735046248[u40]];
                                            u39[2] = v94[5][v94[4]];
                                            u39[3] = not u39[2];
                                            local v95;

                                            if u39[2] then
                                                v95 = UNNAMED_2819735070824[u40];
                                            else
                                                v95 = UNNAMED_2819735027960[u40];
                                            end;

                                            u40 = v95;
                                        end;
                                    else
                                        local v96 = u19[UNNAMED_2819735070824[u40 + 1]];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = v96[5][v96[4]];
                                        local v97;

                                        if u39[2] then
                                            v97 = UNNAMED_2819735046248[u40] - 1;
                                        else
                                            v97 = UNNAMED_2819735070824[u40] - 1;
                                        end;

                                        u40 = v97;
                                        u40 = u40 + 1;
                                    end;
                                elseif v57 < 52 then
                                    if v57 == 51 then
                                        local v98 = u19[UNNAMED_2819735046248[u40]];
                                        u39[4] = v98[5][v98[4]];
                                        local v99 = u39[4];
                                        u39[2] = v99;
                                        u39[1] = v99[UNNAMED_2819735047544[u40]];
                                        u39[1](u39[2]);

                                        return false, false;
                                    end;

                                    local v100 = u19[UNNAMED_2819735070824[u40]];
                                    u39[2] = v100[5][v100[4]];
                                    u39[3] = u19[UNNAMED_2819735027960[u40]];
                                    u39[9] = u39[3]();
                                elseif v57 == 53 then
                                    u39[13] = u39[13] - UNNAMED_2819735047544[u40];
                                    u40 = UNNAMED_2819735070824[u40];
                                else
                                    u39[4] = -u39[31];
                                    u39[UNNAMED_2819735064680[u40 + 1]] = u39[4] * 18;
                                    u39[UNNAMED_2819735027960[u40 + 1]] = u39[UNNAMED_2819735027960[u40]](u39[UNNAMED_2819735070824[u40 + 1]]);
                                    u39[8] = 1 - u39[3];
                                    local v101;

                                    if u39[7] then
                                        v101 = UNNAMED_2819735070824[u40] - 1;
                                    else
                                        v101 = UNNAMED_2819735046248[u40 + 1] - 1;
                                    end;

                                    u40 = v101;
                                    u40 = u40 + 1;
                                end;
                            elseif v57 >= 43 then
                                if v57 >= 45 then
                                    if v57 == 46 then
                                        u39[5] = u19[UNNAMED_2819735027960[u40 + 3]];
                                        local v102 = u39[5];
                                        u39[3] = v102;
                                        u39[2] = v102[UNNAMED_2819735090456[u40]];
                                        u39[12] = u39[2];
                                        local v103 = u19[UNNAMED_2819735070824[u40 + 2]];
                                        u39[4] = v103[5][v103[4]];
                                        u39[2] = u46[UNNAMED_2819735047544[u40 + 4]][UNNAMED_2819735047544[u40]];
                                        u39[5] = u19[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735087432[u40 + 3]];
                                        u39[6] = u39[5][UNNAMED_2819735047544[u40 + 1]];
                                        u39[5] = u46[UNNAMED_2819735090456[u40 + 1]][UNNAMED_2819735090456[u40 + 3]];
                                        u39[7] = u39[5][UNNAMED_2819735087432[u40]];
                                        u39[5] = u46[UNNAMED_2819735047544[u40 + 2]][UNNAMED_2819735087432[u40 + 4]];
                                        u39[8] = u39[UNNAMED_2819735064680[u40 + 2]][UNNAMED_2819735090456[u40 + 4]];
                                        u39[5] = u39[UNNAMED_2819735064680[u40 + 4]];
                                        local v104 = UNNAMED_2819735064680[u40 + 1];
                                        u39[v104] = u39[v104](u39[v104 + 1], u39[v104 + 2], u39[v104 + 3]);
                                        u40 = UNNAMED_2819735046248[u40 + 2] - 4;
                                        u40 = u40 + 4;
                                    else
                                        local v105 = u19[UNNAMED_2819735070824[u40 + 1]];
                                        u39[2] = v105[5][v105[4]][UNNAMED_2819735087432[u40 + 1]];
                                        local v106;

                                        if u39[2] then
                                            v106 = UNNAMED_2819735070824[u40] - 1;
                                        else
                                            v106 = UNNAMED_2819735027960[u40 + 1] - 1;
                                        end;

                                        u40 = v106;
                                        u40 = u40 + 1;
                                    end;
                                else
                                    if v57 == 44 then
                                        local v107 = 2;
                                        u39[6] = {};
                                        u39[7] = u39[14][UNNAMED_2819735090456[u40 + 1]];
                                        u39[6][UNNAMED_2819735047544[u40]] = u39[7];
                                        u39[2] = u39[12];
                                        u45(u47(u39[v107](u44(u39, 3, 6))), 1, 1, v107, u39);
                                        local v108 = u19[UNNAMED_2819735046248[u40 + 1]];
                                        v108[5][v108[4]] = u39[2];
                                        local v109 = u19[UNNAMED_2819735046248[u40]];
                                        u39[5] = v109[5][v109[4]];
                                        local v110 = u39[5];
                                        u39[3] = v110;
                                        u39[2] = v110[UNNAMED_2819735090456[u40]];
                                        u39[2](u39[3]);

                                        return false, false;
                                    end;

                                    u40 = UNNAMED_2819735070824[u40];
                                end;
                            elseif v57 < 41 then
                                local v111 = UNNAMED_2819735046248[u40];
                                local v112 = UNNAMED_2819735027960[u40];
                                local v113 = UNNAMED_2819735059736[5];
                                local v114 = u48(v113[v111], 109162203);
                                v113[v111] = v114;
                                local v115 = UNNAMED_2819735059736[4];
                                local v116 = v114 + 1;
                                local v117 = u49(v115, v116);
                                local v118;

                                if v117 < 128 then
                                    v118 = v116 + 1;
                                else
                                    local v119 = u49(v115, v116 + 1);

                                    if v119 < 128 then
                                        v117 = v117 - 128 + v119 * 128;
                                        v118 = v116 + 2;
                                    else
                                        local v120 = u49(v115, v116 + 2);

                                        if v120 < 128 then
                                            v117 = v117 - 128 + (v119 - 128) * 16384 + v120 * 128;
                                            v118 = v116 + 3;
                                        else
                                            local v121 = u49(v115, v116 + 3);
                                            v117 = (v117 - 128) * 16384 + (v119 - 128) * 128 + (v120 - 128) + v121 % 128 * 2097152 + (v121 - v121 % 128) * 2097152;
                                            v118 = v116 + 4;
                                        end;
                                    end;
                                end;

                                local v122 = v112 * 16843009;
                                local v123 = v118 + v117;
                                local v124 = v123 - v117 % 4;

                                for i = v118, v124 - 1, 4 do
                                    u50(v115, i, (u48(u51(v115, i), v122)));
                                    local _ = i;
                                end;

                                for i = v124, v123 - 1 do
                                    u52(v115, i, (u48(u49(v115, i), v112)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735046248[u40] = 114;
                                UNNAMED_2819735027960[u40] = 67;
                                UNNAMED_2819735070824[u40] = 35;
                                UNNAMED_2819735064680[u40] = 57;
                            elseif v57 == 42 then
                                local v125 = 1;
                                local v126 = u19[UNNAMED_2819735070824[u40 + 1]];
                                v126[5][v126[4]][UNNAMED_2819735047544[u40 + 3]] = UNNAMED_2819735090456[u40];
                                u39[5] = u19[UNNAMED_2819735046248[u40]];
                                local v127 = u39[5];
                                u39[3] = v127;
                                u39[2] = v127[UNNAMED_2819735047544[u40 + 2]];
                                u39[5] = u39[2];
                                u39[UNNAMED_2819735064680[u40 + 1]] = u46[UNNAMED_2819735087432[u40 + 2]][UNNAMED_2819735090456[u40 + 3]];
                                u39[UNNAMED_2819735064680[u40 + 3]] = u39[2][UNNAMED_2819735087432[u40 + 3]];
                                u39[2] = u39[UNNAMED_2819735064680[u40 + 2]];
                                local v128 = UNNAMED_2819735027960[u40];
                                local v129 = UNNAMED_2819735027960[u40 + 1];
                                local _ = v128 + v125 - 1;
                                local _ = v128 + v129;
                                u45(u47(u39[v128](u44(u39, v128 + 1, v128 + v129))), 1, v125, v128, u39);
                                u39[13] = UNNAMED_2819735090456[u40 + 2];
                                u40 = u40 + 3;
                            else
                                local v130 = {};
                                UNNAMED_2819735049656:q3(v130, 0, ...);
                                u45(v130, 1, 1, 31, u39);
                                u39[3] = u19[UNNAMED_2819735070824[u40]];
                                u39[2] = u46[UNNAMED_2819735087432[u40 + 1]][u39[3]];
                                u39[3] = u19[UNNAMED_2819735046248[u40]];

                                if u39[2] ~= u39[3] then
                                    u40 = UNNAMED_2819735070824[u40 + 1] - 1;
                                end;

                                u40 = u40 + 1;
                            end;
                        elseif v57 >= 13 then
                            if v57 >= 20 then
                                if v57 >= 23 then
                                    if v57 < 25 then
                                        if v57 == 24 then
                                            u39[31] = UNNAMED_2819735087432[u40];
                                            u40 = UNNAMED_2819735070824[u40];
                                        else
                                            u39[5] = u19[UNNAMED_2819735027960[u40 + 2]];
                                            local v131 = u39[5];
                                            u39[4] = v131;
                                            local v132 = 2;
                                            u39[3] = v131[UNNAMED_2819735090456[u40]];
                                            u39[UNNAMED_2819735064680[u40 + 2]] = u39[3];
                                            u39[UNNAMED_2819735064680[u40 + 1]] = u46[UNNAMED_2819735047544[u40]][UNNAMED_2819735087432[u40]];
                                            u39[5] = u39[3][UNNAMED_2819735087432[u40 + 2]];
                                            u39[3] = u39[2];
                                            local v133 = UNNAMED_2819735070824[u40 + 1];
                                            local v134 = UNNAMED_2819735027960[u40 + 1];
                                            local _ = v133 + v134 - 1;
                                            local _ = v133 + v132;
                                            u45(u47(u39[v133](u44(u39, v133 + 1, v133 + v132))), 1, v134, v133, u39);
                                            local v135;

                                            if u39[3] then
                                                v135 = UNNAMED_2819735070824[u40 + 2] - 2;
                                            else
                                                v135 = UNNAMED_2819735046248[u40 + 1] - 2;
                                            end;

                                            u40 = v135;
                                            u40 = u40 + 2;
                                        end;
                                    else
                                        if v57 == 26 then
                                            u39[2][UNNAMED_2819735090456[u40]] = u39[UNNAMED_2819735064680[u40 + 1]];
                                            local v136 = u19[UNNAMED_2819735027960[u40]];
                                            u39[2] = v136[5][v136[4]];
                                            u39[UNNAMED_2819735046248[u40 + 1]] = u39[9][UNNAMED_2819735090456[u40 + 1]];
                                            u39[2][UNNAMED_2819735047544[u40 + 1]] = u39[UNNAMED_2819735046248[u40]];

                                            return false, false;
                                        end;

                                        if u39[UNNAMED_2819735046248[u40]] > u39[UNNAMED_2819735027960[u40]] then
                                            u40 = UNNAMED_2819735070824[u40];
                                        end;
                                    end;
                                elseif v57 < 21 then
                                    if u39[UNNAMED_2819735046248[u40]] ~= u39[UNNAMED_2819735027960[u40]] then
                                        u40 = UNNAMED_2819735070824[u40];
                                    end;
                                elseif v57 == 22 then
                                    u40 = UNNAMED_2819735046248[u40];
                                else
                                    u39[2] = u39[9][UNNAMED_2819735087432[u40]];
                                    u39[3] = UNNAMED_2819735090456[u40 + 2];
                                    u38 = u39[3];
                                    u39[2] = u39[2][UNNAMED_2819735090456[u40 + 1]];
                                    u39[UNNAMED_2819735064680[u40 + 1]] = UNNAMED_2819735047544[u40 + 2] + u39[2];
                                    u39[2] = not u39[UNNAMED_2819735064680[u40 + 2]];
                                    local v137;

                                    if u39[2] then
                                        v137 = UNNAMED_2819735027960[u40] - 2;
                                    else
                                        v137 = UNNAMED_2819735027960[u40 + 1] - 2;
                                    end;

                                    u40 = v137;
                                    u40 = u40 + 2;
                                end;
                            elseif v57 < 16 then
                                if v57 < 14 then
                                    u39[3] = u19[UNNAMED_2819735046248[u40]][UNNAMED_2819735087432[u40 + 1]];
                                    local v138;

                                    if u39[31] then
                                        v138 = UNNAMED_2819735070824[u40 + 1] - 1;
                                    else
                                        v138 = UNNAMED_2819735070824[u40] - 1;
                                    end;

                                    u40 = v138;
                                    u40 = u40 + 1;
                                else
                                    if v57 ~= 15 then
                                        return false, false;
                                    end;

                                    u40 = UNNAMED_2819735046248[u40];
                                end;
                            elseif v57 < 18 then
                                if v57 == 17 then
                                    local v139 = u19[UNNAMED_2819735070824[u40]];
                                    u39[2] = v139[5][v139[4]][UNNAMED_2819735047544[u40]];
                                    u39[3] = u39[14][UNNAMED_2819735087432[u40]];
                                    u39[2] = u39[2] - u39[3];
                                    u39[2] = u39[2][UNNAMED_2819735087432[u40 + 2]];
                                    u39[3] = u19[UNNAMED_2819735070824[u40 + 2]][UNNAMED_2819735047544[u40 + 1]];
                                    u39[3] = u39[3][UNNAMED_2819735090456[u40 + 1]];

                                    if u39[UNNAMED_2819735064680[u40 + 1]] > u39[3] then
                                        u40 = UNNAMED_2819735027960[u40 + 2] - 2;
                                    end;

                                    u40 = u40 + 2;
                                elseif u39[UNNAMED_2819735070824[u40]] > UNNAMED_2819735027960[u40] then
                                    u40 = UNNAMED_2819735046248[u40];
                                end;
                            else
                                if v57 == 19 then
                                    local v140 = u19[UNNAMED_2819735027960[u40]];
                                    v140[5][v140[4]] = u39[32];

                                    return false, false;
                                end;

                                u39[3] = u19[UNNAMED_2819735027960[u40]];
                                local v141 = u19[UNNAMED_2819735046248[u40]];
                                u39[4] = v141[5][v141[4]];
                                u39[3](u39[2], u39[4]);
                                u40 = UNNAMED_2819735070824[u40];
                            end;
                        elseif v57 >= 6 then
                            if v57 >= 9 then
                                if v57 < 11 then
                                    if v57 == 10 then
                                        u39[2] = u19[UNNAMED_2819735046248[u40]];
                                        u39[2]();

                                        return false, false;
                                    end;

                                    u39[UNNAMED_2819735064680[u40 + 1]] = u19[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735090456[u40]];
                                    local v142;

                                    if u39[1] then
                                        v142 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    else
                                        v142 = UNNAMED_2819735070824[u40 + 1] - 1;
                                    end;

                                    u40 = v142;
                                    u40 = u40 + 1;
                                elseif v57 == 12 then
                                    u39[1] = 0;

                                    if u39[1] > 0 then
                                        u40 = UNNAMED_2819735027960[u40];
                                    end;
                                else
                                    local v143 = u19[UNNAMED_2819735046248[u40]];
                                    u39[2] = v143[5][v143[4]];
                                    local v144;

                                    if u39[UNNAMED_2819735064680[u40 + 1]] then
                                        v144 = UNNAMED_2819735070824[u40 + 1] - 1;
                                    else
                                        v144 = UNNAMED_2819735027960[u40] - 1;
                                    end;

                                    u40 = v144;
                                    u40 = u40 + 1;
                                end;
                            elseif v57 >= 7 then
                                if v57 == 8 then
                                    u39[4] = u46[UNNAMED_2819735047544[u40 + 1]][UNNAMED_2819735090456[u40 + 3]];
                                    u39[5] = u39[UNNAMED_2819735064680[u40 + 3]][UNNAMED_2819735087432[u40 + 3]];
                                    u39[UNNAMED_2819735064680[u40 + 2]] = u39[UNNAMED_2819735064680[u40 + 1]](u39[5]);
                                    u39[2][UNNAMED_2819735087432[u40 + 2]] = u39[UNNAMED_2819735027960[u40 + 2]];
                                    local v145 = u19[UNNAMED_2819735070824[u40]];
                                    u39[4] = v145[5][v145[4]];
                                    local v146 = u19[UNNAMED_2819735027960[u40]];
                                    v146[5][v146[4]][UNNAMED_2819735087432[u40]] = u39[UNNAMED_2819735046248[u40 + 1]];

                                    return false, false;
                                end;

                                u39[2] = 1564588;
                                u38 = u39[UNNAMED_2819735070824[u40]];
                                u40 = UNNAMED_2819735027960[u40];
                            else
                                u39[5] = u19[UNNAMED_2819735027960[u40 + 2]];
                                local v147 = UNNAMED_2819735064680[u40 + 2];
                                local v148 = u39[5];
                                u39[v147 + 1] = v148;
                                u39[v147] = v148[UNNAMED_2819735090456[u40]];
                                local v149 = 3;
                                u39[2] = u39[3];
                                u39[3] = u46[UNNAMED_2819735087432[u40 + 1]][UNNAMED_2819735090456[u40 + 1]];
                                u39[5] = u39[3][UNNAMED_2819735087432[u40 + 2]];
                                u39[3] = u39[UNNAMED_2819735064680[u40 + 1]];
                                u45(u47(u39[v149](u44(u39, 4, 5))), 1, 1, v149, u39);
                                local v150;

                                if u39[3] then
                                    v150 = UNNAMED_2819735046248[u40] - 2;
                                else
                                    v150 = UNNAMED_2819735070824[u40 + 2] - 2;
                                end;

                                u40 = v150;
                                u40 = u40 + 2;
                            end;
                        elseif v57 >= 3 then
                            if v57 >= 4 then
                                if v57 ~= 5 then
                                    local v151 = u19[UNNAMED_2819735046248[u40]];
                                    u39[5] = v151[5][v151[4]];
                                    local v152 = u39[5];
                                    u39[3] = v152;
                                    u39[2] = v152[UNNAMED_2819735047544[u40]];
                                    u39[2](u39[UNNAMED_2819735070824[u40]]);

                                    return false, false;
                                end;

                                local v153 = u19[UNNAMED_2819735027960[u40]];
                                u39[UNNAMED_2819735046248[u40]] = v153[5][v153[4]];
                            else
                                local v154 = u19[UNNAMED_2819735070824[u40]];
                                v154[5][v154[4]][UNNAMED_2819735087432[u40 + 1]] = u39[2];
                                local v155 = u19[UNNAMED_2819735027960[u40 + 1]];
                                v155[5][v155[4]] = u39[2];
                                u40 = UNNAMED_2819735070824[u40 + 1] - 1;
                                u40 = u40 + 1;
                            end;
                        elseif v57 < 1 then
                            local v156 = u19[UNNAMED_2819735046248[u40 + 1]];
                            u39[3] = v156[5][v156[4]][UNNAMED_2819735087432[u40]];
                            local v157;

                            if u39[UNNAMED_2819735064680[u40 + 1]] then
                                v157 = UNNAMED_2819735070824[u40 + 1] - 1;
                            else
                                v157 = UNNAMED_2819735027960[u40] - 1;
                            end;

                            u40 = v157;
                            u40 = u40 + 1;
                        elseif v57 == 2 then
                            local v158 = u19[UNNAMED_2819735070824[u40 + 1]];
                            u39[2] = v158[5][v158[4]];
                            local v159 = u19[UNNAMED_2819735070824[u40 + 2]];
                            u39[UNNAMED_2819735064680[u40 + 2]] = v159[5][v159[4]];
                            u39[4] = UNNAMED_2819735087432[u40 + 2] - u39[UNNAMED_2819735064680[u40 + 1]];
                            u39[4] = u39[4] * u39[8];
                            u39[2] = u39[2] + u39[4];
                            local v160 = u19[UNNAMED_2819735046248[u40 + 1]];
                            v160[5][v160[4]] = u39[2];
                            u39[UNNAMED_2819735027960[u40]] = u19[UNNAMED_2819735070824[u40]];
                            u39[2] = u39[UNNAMED_2819735046248[u40]]();
                            local v161 = u19[UNNAMED_2819735027960[u40 + 2]];
                            u39[4] = v161[5][v161[4]];

                            if u39[2] ~= u39[4] then
                                u40 = UNNAMED_2819735027960[u40 + 1] - 2;
                            end;

                            u40 = u40 + 2;
                        else
                            u39[3] = UNNAMED_2819735027960[u40];
                            u40 = UNNAMED_2819735046248[u40];
                        end;
                    elseif v57 < 81 then
                        if v57 >= 67 then
                            if v57 >= 74 then
                                if v57 < 77 then
                                    if v57 < 75 then
                                        local v162 = UNNAMED_2819735070824[u40];
                                        local v163 = UNNAMED_2819735046248[u40];
                                        local v164 = UNNAMED_2819735027960[u40];
                                        local v165 = u48(u38, u54(u53(u38, 14), 262143), (u54(u53(u38, 28), 15)));
                                        local v166 = v162 < 16384 and 7 or (v162 < 2097152 and 14 or 21);
                                        local v167 = u54(v162, u55(1, v166) - 1);
                                        UNNAMED_2819735064680[u40] = u48(u53(v162, v166), 45, (u54(u53(v165, 21), 127)));
                                        UNNAMED_2819735070824[u40] = u48(v167, 77, (u54(u53(v165, 7), 127)));
                                        UNNAMED_2819735027960[u40] = u48(v164, 125, (u54(v165, 127)));
                                        UNNAMED_2819735046248[u40] = u48(v163, 78, (u54(u53(v165, 14), 127)));
                                        u40 = u40 - 1;
                                    else
                                        if v57 == 76 then
                                            local v168 = u19[UNNAMED_2819735027960[u40]];
                                            u39[5] = v168[5][v168[4]];
                                            local v169 = u39[5];
                                            u39[3] = v169;
                                            u39[2] = v169[UNNAMED_2819735090456[u40]];
                                            u39[2](u39[UNNAMED_2819735064680[u40 + 1]]);
                                            local v170 = u19[UNNAMED_2819735046248[u40 + 1]];
                                            v170[5][v170[4]] = u39[15];

                                            return false, false;
                                        end;

                                        local v171 = u19[UNNAMED_2819735070824[u40 + 1]];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = v171[5][v171[4]];
                                        u39[2] = 494151920;
                                        u38 = u39[2];
                                        local v172 = UNNAMED_2819735070824[u40];
                                        local v173 = u39[4];
                                        u39[v172 + 1] = v173;
                                        u39[v172] = v173[UNNAMED_2819735087432[u40]];
                                        u39[2](u39[3]);
                                        u39[2] = 1564588;
                                        u38 = u39[2];
                                        u40 = UNNAMED_2819735027960[u40] - 1;
                                        u40 = u40 + 1;
                                    end;
                                elseif v57 >= 79 then
                                    if v57 == 80 then
                                        u39[2] = UNNAMED_2819735090456[u40 + 1];
                                        u38 = u39[2];
                                        u39[5] = u19[UNNAMED_2819735046248[u40 + 2]];
                                        local v174 = u39[5];
                                        u39[4] = v174;
                                        u39[3] = v174[UNNAMED_2819735090456[u40]];
                                        u39[2] = u39[3];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = u46[UNNAMED_2819735047544[u40 + 2]][UNNAMED_2819735087432[u40]];
                                        u39[5] = u39[3][UNNAMED_2819735047544[u40]];
                                        u39[3] = u39[2];
                                        u40 = UNNAMED_2819735070824[u40 + 2] - 2;
                                        u40 = u40 + 2;
                                    else
                                        local v175 = u19[UNNAMED_2819735046248[u40]];
                                        u39[2] = v175[5][v175[4]][UNNAMED_2819735090456[u40]];
                                        u39[3] = u39[UNNAMED_2819735064680[u40 + 1]][UNNAMED_2819735087432[u40 + 1]];

                                        if u39[3] <= 0 then
                                            u40 = UNNAMED_2819735027960[u40 + 1] - 1;
                                        end;

                                        u40 = u40 + 1;
                                    end;
                                elseif v57 == 78 then
                                    local v176 = u48(u38, u54(u53(u38, 14), 262143), (u54(u53(u38, 28), 15)));
                                    local v177 = UNNAMED_2819735046248[u40];
                                    local v178 = UNNAMED_2819735070824[u40];
                                    local v179 = UNNAMED_2819735027960[u40];
                                    local v180 = v179 < 2097152 and 7 or 14;
                                    local v181 = u53(v179, v180);
                                    local v182 = u54(v179, u55(1, v180) - 1);
                                    UNNAMED_2819735046248[u40] = u48(v177, 123, (u54(u53(v176, 14), 127)));
                                    UNNAMED_2819735070824[u40] = u48(v178, 78, (u54(u53(v176, 7), 127)));
                                    UNNAMED_2819735027960[u40] = u48(v182, 87, (u54(v176, 127)));
                                    UNNAMED_2819735064680[u40] = u48(v181, 8, (u54(u53(v176, 21), 127)));
                                    u40 = u40 - 1;
                                else
                                    local v183 = u19[UNNAMED_2819735070824[u40 + 1]];
                                    u39[2] = v183[5][v183[4]];
                                    u39[5] = u46[UNNAMED_2819735090456[u40 + 2]][UNNAMED_2819735047544[u40 + 1]];
                                    u39[5] = u39[5][UNNAMED_2819735087432[u40 + 1]];
                                    u39[2][UNNAMED_2819735047544[u40 + 3]] = u39[UNNAMED_2819735064680[u40 + 3]];
                                    u39[5] = u19[UNNAMED_2819735027960[u40 + 2]];
                                    local v184 = u19[UNNAMED_2819735046248[u40 + 3]];
                                    v184[5][v184[4]][UNNAMED_2819735090456[u40]] = u39[UNNAMED_2819735064680[u40 + 2]];
                                    u39[5] = u19[UNNAMED_2819735046248[u40 + 2]];
                                    local v185 = u19[UNNAMED_2819735046248[u40 + 4]];
                                    v185[5][v185[4]][UNNAMED_2819735047544[u40 + 4]] = u39[5];
                                    u39[UNNAMED_2819735064680[u40 + 1]] = UNNAMED_2819735064680[u40 + 4];
                                    u38 = u39[4];
                                    local v186 = u19[UNNAMED_2819735070824[u40 + 4]];
                                    v186[5][v186[4]] = u39[32];
                                    u40 = u40 + 4;
                                end;
                            elseif v57 >= 70 then
                                if v57 < 72 then
                                    if v57 == 71 then
                                        u39[5] = u19[UNNAMED_2819735027960[u40]];
                                        local v187 = u39[5];
                                        u39[3] = v187;
                                        u39[2] = v187[UNNAMED_2819735047544[u40 + 1]];
                                        u39[2](u39[3], UNNAMED_2819735090456[u40 + 1]);
                                        u39[UNNAMED_2819735064680[u40 + 1]] = u19[UNNAMED_2819735070824[u40]];
                                        u39[UNNAMED_2819735046248[u40]]();

                                        return false, false;
                                    end;

                                    local v188 = UNNAMED_2819735070824[u40];
                                    u39[4] = UNNAMED_2819735064680[u40 + 1];
                                    u39[5] = v188;
                                    local v189 = 2;
                                    u39[UNNAMED_2819735027960[u40]] = u39[6];
                                    u39[v189] = u39[v189](u39[3], u39[4], u39[5]);
                                    u39[3] = u39[2] + 2;
                                    local v190 = u19[UNNAMED_2819735070824[u40 + 1]];
                                    u39[2] = v190[5][v190[4]];
                                    u39[4] = not u39[2];
                                    local v191;

                                    if u39[2] then
                                        v191 = UNNAMED_2819735046248[u40 + 1] - 1;
                                    else
                                        v191 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    end;

                                    u40 = v191;
                                    u40 = u40 + 1;
                                elseif v57 == 73 then
                                    local v192 = u19[UNNAMED_2819735046248[u40]];
                                    u39[3] = v192[5][v192[4]];
                                    local v193;

                                    if u39[3] then
                                        v193 = UNNAMED_2819735070824[u40];
                                    else
                                        v193 = UNNAMED_2819735027960[u40];
                                    end;

                                    u40 = v193;
                                else
                                    u39[3] = u19[UNNAMED_2819735027960[u40 + 1]];
                                    u39[2] = u46[UNNAMED_2819735087432[u40]][u39[3]];
                                    u39[3] = u19[UNNAMED_2819735070824[u40]];
                                    u39[2] = u39[UNNAMED_2819735064680[u40 + 1]] ~= u39[3];
                                    u39[3] = UNNAMED_2819735087432[u40 + 1];
                                    u38 = u39[3];
                                    u40 = u40 + 1;
                                end;
                            else
                                if v57 < 68 then
                                    local v194 = u19[UNNAMED_2819735046248[u40]];
                                    u39[9] = v194[5][v194[4]];
                                    local v195 = u39[9];
                                    u39[5] = v195;
                                    u39[4] = v195[UNNAMED_2819735047544[u40 + 1]];
                                    u39[4](u39[UNNAMED_2819735064680[u40 + 1]]);
                                    local v196 = u19[UNNAMED_2819735046248[u40 + 1]];
                                    v196[5][v196[4]] = u39[11];

                                    return false, false;
                                end;

                                if v57 == 69 then
                                    local v197 = u19[UNNAMED_2819735046248[u40]];
                                    u39[3] = v197[5][v197[4]];
                                    local v198 = u19[UNNAMED_2819735027960[u40]];
                                    u39[5] = v198[5][v198[4]][UNNAMED_2819735087432[u40 + 1]];
                                    u39[1] = u39[2] * u39[1];
                                    u39[1] = u39[UNNAMED_2819735064680[u40 + 1]] * u39[UNNAMED_2819735027960[u40 + 1]];
                                    u39[UNNAMED_2819735070824[u40]] = u39[5] + u39[1];
                                    u39[3][UNNAMED_2819735090456[u40 + 1]] = u39[1];

                                    return false, false;
                                end;

                                local v199 = u19[UNNAMED_2819735027960[u40 + 1]];
                                u39[5] = v199[5][v199[4]];
                                local v200 = u39[5];
                                u39[3] = v200;
                                u39[2] = v200[UNNAMED_2819735047544[u40]];
                                u39[UNNAMED_2819735064680[u40 + 1]](u39[3]);
                                local v201 = u19[UNNAMED_2819735046248[u40 + 1]];
                                v201[5][v201[4]] = u39[15];
                                u40 = UNNAMED_2819735046248[u40] - 1;
                                u40 = u40 + 1;
                            end;
                        elseif v57 < 60 then
                            if v57 >= 57 then
                                if v57 >= 58 then
                                    if v57 == 59 then
                                        u40 = UNNAMED_2819735046248[u40];
                                    else
                                        local v202 = u19[UNNAMED_2819735027960[u40 + 1]];
                                        u39[2] = v202[5][v202[4]];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = u39[UNNAMED_2819735046248[u40]][UNNAMED_2819735087432[u40 + 1]];

                                        if u39[UNNAMED_2819735027960[u40]] <= 0 then
                                            u40 = UNNAMED_2819735070824[u40] - 1;
                                        end;

                                        u40 = u40 + 1;
                                    end;
                                end;
                            elseif v57 >= 55 then
                                if v57 == 56 then
                                    u39[2] = UNNAMED_2819735047544[u40];
                                    u38 = u39[UNNAMED_2819735070824[u40]];
                                    u40 = UNNAMED_2819735046248[u40];
                                else
                                    local v203 = u19[UNNAMED_2819735027960[u40 + 1]];
                                    u39[UNNAMED_2819735064680[u40 + 2]] = v203[5][v203[4]];
                                    local v204 = u39[5];
                                    u39[3] = v204;
                                    u39[2] = v204[UNNAMED_2819735087432[u40]];
                                    u39[2](u39[3]);
                                    local v205 = u19[UNNAMED_2819735027960[u40]];
                                    v205[5][v205[4]] = u39[15];
                                    u39[2] = UNNAMED_2819735087432[u40 + 2];
                                    u38 = u39[2];
                                    u39[UNNAMED_2819735064680[u40 + 1]] = UNNAMED_2819735090456[u40 + 2];
                                    u38 = u39[2];
                                    u40 = UNNAMED_2819735070824[u40 + 1] - 2;
                                    u40 = u40 + 2;
                                end;
                            else
                                local v206 = u19[UNNAMED_2819735070824[u40]];
                                u39[3] = v206[5][v206[4]];
                                u39[3] = u48(u39[UNNAMED_2819735064680[u40 + 1]], UNNAMED_2819735087432[u40]);
                                local v207 = u19[UNNAMED_2819735027960[u40]];
                                v207[5][v207[4]] = u39[3];

                                if u39[1] ~= u39[2] then
                                    u40 = UNNAMED_2819735046248[u40 + 1] - 1;
                                end;

                                u40 = u40 + 1;
                            end;
                        elseif v57 >= 63 then
                            if v57 < 65 then
                                if v57 == 64 then
                                    local v208 = u19[UNNAMED_2819735027960[u40]];
                                    u39[5] = v208[5][v208[4]];
                                    local v209 = u39[5];
                                    u39[3] = v209;
                                    u39[2] = v209[UNNAMED_2819735047544[u40 + 1]];
                                    u39[2](u39[UNNAMED_2819735064680[u40 + 1]]);
                                    u39[2] = 96702788;
                                    u38 = u39[UNNAMED_2819735046248[u40 + 1]];
                                    local v210 = u19[UNNAMED_2819735046248[u40]];
                                    v210[5][v210[4]] = u39[32];
                                    local v211 = u19[UNNAMED_2819735070824[u40 + 1]];
                                    v211[5][v211[4]] = u39[32];
                                    u39[UNNAMED_2819735070824[u40]] = 1564588;
                                    u38 = u39[2];

                                    return false, false;
                                end;

                                u39[7] = u19[UNNAMED_2819735070824[u40 + 1]];
                                u39[UNNAMED_2819735064680[u40 + 1]] = u39[UNNAMED_2819735027960[u40 + 1]][UNNAMED_2819735087432[u40]];
                                local v212;

                                if u39[2] then
                                    v212 = UNNAMED_2819735027960[u40] - 1;
                                else
                                    v212 = UNNAMED_2819735070824[u40] - 1;
                                end;

                                u40 = v212;
                                u40 = u40 + 1;
                            elseif v57 == 66 then
                                local v213 = u19[UNNAMED_2819735027960[u40]];
                                u39[1] = v213[5][v213[4]];
                                local v214;

                                if u39[UNNAMED_2819735064680[u40 + 1]] then
                                    v214 = UNNAMED_2819735070824[u40 + 1] - 1;
                                else
                                    v214 = UNNAMED_2819735027960[u40 + 1] - 1;
                                end;

                                u40 = v214;
                                u40 = u40 + 1;
                            else
                                u39[1] = u19[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735087432[u40 + 1]];
                                local v215;

                                if u39[UNNAMED_2819735064680[u40 + 1]] then
                                    v215 = UNNAMED_2819735046248[u40] - 1;
                                else
                                    v215 = UNNAMED_2819735027960[u40] - 1;
                                end;

                                u40 = v215;
                                u40 = u40 + 1;
                            end;
                        elseif v57 >= 61 then
                            if v57 == 62 then
                                u39[13] = u39[13] + UNNAMED_2819735047544[u40];
                                u40 = UNNAMED_2819735070824[u40];
                            else
                                u39[UNNAMED_2819735064680[u40 + 1]] = u19[UNNAMED_2819735027960[u40]][UNNAMED_2819735047544[u40 + 1]];
                                u39[2] = u39[2][UNNAMED_2819735090456[u40 + 1]];
                                local v216;

                                if u39[2] then
                                    v216 = UNNAMED_2819735046248[u40] - 1;
                                else
                                    v216 = UNNAMED_2819735070824[u40] - 1;
                                end;

                                u40 = v216;
                                u40 = u40 + 1;
                            end;
                        else
                            u39[UNNAMED_2819735064680[u40 + 1]] = u39[9][UNNAMED_2819735090456[u40 + 1]];
                            u39[UNNAMED_2819735027960[u40]] = u39[2][UNNAMED_2819735047544[u40 + 1]];
                            u39[13] = u39[13] - u39[2];
                            u40 = UNNAMED_2819735046248[u40 + 1] - 1;
                            u40 = u40 + 1;
                        end;
                    elseif v57 >= 95 then
                        if v57 >= 102 then
                            if v57 >= 105 then
                                if v57 < 107 then
                                    if v57 == 106 then
                                        u39[7] = u39[19];
                                        u40 = UNNAMED_2819735046248[u40];
                                    else
                                        u39[4] = u19[UNNAMED_2819735070824[u40]];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = not u39[4];
                                        local v217;

                                        if u39[UNNAMED_2819735070824[u40 + 1]] then
                                            v217 = UNNAMED_2819735027960[u40] - 1;
                                        else
                                            v217 = UNNAMED_2819735046248[u40] - 1;
                                        end;

                                        u40 = v217;
                                        u40 = u40 + 1;
                                    end;
                                elseif v57 == 108 then
                                    local v218 = u19[UNNAMED_2819735027960[u40 + 1]];
                                    u39[2] = v218[5][v218[4]][UNNAMED_2819735087432[u40]];
                                    u39[3] = u46[UNNAMED_2819735090456[u40 + 1]][UNNAMED_2819735087432[u40 + 1]];
                                    u39[3] = u39[3][UNNAMED_2819735047544[u40]];

                                    if u39[2] ~= u39[3] then
                                        u40 = UNNAMED_2819735070824[u40] - 1;
                                    end;

                                    u40 = u40 + 1;
                                else
                                    u39[2] = u39[9][UNNAMED_2819735090456[u40 + 1]];
                                    u39[2] = u39[2][UNNAMED_2819735047544[u40 + 1]];
                                    u39[13] = u39[UNNAMED_2819735064680[u40 + 1]] - u39[UNNAMED_2819735070824[u40]];
                                    u40 = UNNAMED_2819735027960[u40] - 1;
                                    u40 = u40 + 1;
                                end;
                            elseif v57 < 103 then
                                local v219 = u19[UNNAMED_2819735070824[u40 + 4]];
                                u39[2] = v219[5][v219[4]];
                                u39[5] = u19[UNNAMED_2819735070824[u40]][UNNAMED_2819735087432[u40 + 3]];
                                u39[UNNAMED_2819735064680[u40 + 2]] = u39[5][UNNAMED_2819735090456[u40 + 1]];
                                u39[UNNAMED_2819735064680[u40 + 1]][UNNAMED_2819735047544[u40 + 4]] = u39[5];
                                local v220 = u19[UNNAMED_2819735027960[u40 + 3]];
                                u39[9] = v220[5][v220[4]];
                                u39[6] = u46[UNNAMED_2819735047544[u40 + 1]][UNNAMED_2819735087432[u40 + 2]];
                                u39[UNNAMED_2819735064680[u40 + 3]] = u39[6];
                                local v221 = u39[3];
                                u39[4] = u39[UNNAMED_2819735064680[u40 + 4]];
                                u39[5] = v221;
                                local v222 = 2;
                                u39[v222] = u39[v222](u39[3], u39[4], u39[5]);
                                u39[UNNAMED_2819735046248[u40 + 4]][UNNAMED_2819735087432[u40 + 1]] = u39[2];
                                local v223 = u19[UNNAMED_2819735070824[u40 + 3]];
                                u39[UNNAMED_2819735027960[u40 + 2]] = v223[5][v223[4]];
                                u40 = UNNAMED_2819735027960[u40] - 4;
                                u40 = u40 + 4;
                            elseif v57 == 104 then
                                u39[2] = u19[UNNAMED_2819735046248[u40]];
                                u39[7] = u39[2]();
                                local v224;

                                if u39[7] then
                                    v224 = UNNAMED_2819735027960[u40];
                                else
                                    v224 = UNNAMED_2819735070824[u40];
                                end;

                                u40 = v224;
                            else
                                u39[UNNAMED_2819735064680[u40 + 1]] = u19[UNNAMED_2819735070824[u40 + 2]];
                                u39[UNNAMED_2819735064680[u40 + 2]] = u19[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735047544[u40 + 1]];
                                u39[4] = u39[4] - u39[UNNAMED_2819735027960[u40]];
                                u39[4] = u39[UNNAMED_2819735046248[u40 + 2]][UNNAMED_2819735087432[u40 + 1]];
                                u39[5] = u19[UNNAMED_2819735027960[u40 + 2]];
                                u40 = u40 + 2;
                            end;
                        elseif v57 < 98 then
                            if v57 >= 96 then
                                if v57 == 97 then
                                    u45({ ... }, 1, 2, 31, u39);

                                    return false, true, u47(u39[31], u39[32]);
                                end;

                                local v225 = UNNAMED_2819735027960[u40];
                                local v226 = u48(UNNAMED_2819735070824[u40], (u54(u48(u38, (u54(u53(u38, 29), 7))), 536870911)));
                                local v227 = UNNAMED_2819735059736[5];
                                local v228 = u48(v227[v225], 109162203);
                                v227[v225] = v228;
                                local v229 = UNNAMED_2819735059736[4];
                                local v230 = v228 + 1;
                                local v231 = u49(v229, v230);
                                local v232;

                                if v231 < 128 then
                                    v232 = v230 + 1;
                                else
                                    local v233 = u49(v229, v230 + 1);

                                    if v233 < 128 then
                                        v231 = v231 - 128 + v233 * 128;
                                        v232 = v230 + 2;
                                    else
                                        local v234 = u49(v229, v230 + 2);

                                        if v234 < 128 then
                                            v231 = v231 - 128 + (v233 - 128) * 16384 + v234 * 128;
                                            v232 = v230 + 3;
                                        else
                                            local v235 = u49(v229, v230 + 3);
                                            v231 = (v231 - 128) * 16384 + (v233 - 128) * 128 + (v234 - 128) + v235 % 128 * 2097152 + (v235 - v235 % 128) * 2097152;
                                            v232 = v230 + 4;
                                        end;
                                    end;
                                end;

                                local v236 = v226 * 16843009;
                                local v237 = v232 + v231;
                                local v238 = v237 - v231 % 4;

                                for i = v232, v238 - 1, 4 do
                                    u50(v229, i, (u48(u51(v229, i), v236)));
                                    local _ = i;
                                end;

                                for i = v238, v237 - 1 do
                                    u52(v229, i, (u48(u49(v229, i), v226)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735027960[u40] = 239;
                                UNNAMED_2819735070824[u40] = 51;
                                UNNAMED_2819735046248[u40] = 184;
                                UNNAMED_2819735064680[u40] = 57;
                            else
                                local v239 = 3;
                                u45(u47(u39[v239](u44(u39, 4, 5))), 1, 1, v239, u39);
                                local v240;

                                if u39[3] then
                                    v240 = UNNAMED_2819735046248[u40];
                                else
                                    v240 = UNNAMED_2819735027960[u40];
                                end;

                                u40 = v240;
                            end;
                        elseif v57 < 100 then
                            if v57 == 99 then
                                local v241 = u19[UNNAMED_2819735046248[u40]];
                                u39[5] = v241[5][v241[4]];
                                local v242 = u39[5];
                                u39[3] = v242;
                                u39[2] = v242[UNNAMED_2819735047544[u40]];
                                u39[2](u39[3]);
                                u40 = UNNAMED_2819735070824[u40];
                            else
                                u39[1] = u19[UNNAMED_2819735046248[u40]];
                                u39[UNNAMED_2819735027960[u40]] = u39[1]();
                            end;
                        elseif v57 == 101 then
                            u39[6] = u19[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735047544[u40 + 2]];
                            u39[2] = u19[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735090456[u40]];
                            u39[3] = u39[2][UNNAMED_2819735047544[u40 + 1]];
                            local v243;

                            if u39[3] then
                                v243 = UNNAMED_2819735027960[u40] - 2;
                            else
                                v243 = UNNAMED_2819735046248[u40] - 2;
                            end;

                            u40 = v243;
                            u40 = u40 + 2;
                        else
                            u39[3] = u19[UNNAMED_2819735070824[u40 + 1]];
                            local v244 = u19[UNNAMED_2819735027960[u40]];
                            u39[UNNAMED_2819735064680[u40 + 1]] = v244[5][v244[4]];
                            u39[3](u39[2], u39[4]);
                            u40 = UNNAMED_2819735046248[u40] - 1;
                            u40 = u40 + 1;
                        end;
                    elseif v57 < 88 then
                        if v57 < 84 then
                            if v57 < 82 then
                                local v245 = UNNAMED_2819735070824[u40];
                                local v246 = UNNAMED_2819735027960[u40];
                                u45({ ... }, 1, v245 - 1, v246, u39);
                                u39[v246 + v245 - 1] = u47(u56(v245, ...));
                            elseif v57 == 83 then
                                u45({ ... }, 1, UNNAMED_2819735064680[u40 + 2], UNNAMED_2819735064680[u40 + 1], u39);
                                u39[2] = u19[UNNAMED_2819735046248[u40 + 2]];
                                u39[1] = u46[UNNAMED_2819735087432[u40]][u39[UNNAMED_2819735027960[u40 + 2]]];
                                u39[2] = u19[UNNAMED_2819735027960[u40 + 1]];
                                local v247 = u19[UNNAMED_2819735070824[u40 + 2]];
                                u39[UNNAMED_2819735070824[u40]] = v247[5][v247[4]];
                                u39[3] = u39[3] + 111040668;

                                if u39[UNNAMED_2819735070824[u40 + 1]] ~= UNNAMED_2819735027960[u40] then
                                    u40 = UNNAMED_2819735046248[u40 + 1] - 2;
                                end;

                                u40 = u40 + 2;
                            else
                                local v248 = u19[UNNAMED_2819735070824[u40]];
                                u39[2] = v248[5][v248[4]];
                                local v249 = u19[UNNAMED_2819735070824[u40 + 1]];
                                u39[4] = v249[5][v249[4]];
                                u39[4] = u39[UNNAMED_2819735064680[u40 + 1]] == 176776780;
                                local v250;

                                if u39[4] then
                                    v250 = UNNAMED_2819735027960[u40] - 1;
                                else
                                    v250 = UNNAMED_2819735027960[u40 + 1] - 1;
                                end;

                                u40 = v250;
                                u40 = u40 + 1;
                            end;
                        elseif v57 >= 86 then
                            if v57 == 87 then
                                u39[2] = u19[UNNAMED_2819735027960[u40]];
                                u39[2] = u39[UNNAMED_2819735064680[u40 + 1]]();
                                local v251;

                                if u39[2] then
                                    v251 = UNNAMED_2819735027960[u40 + 1] - 1;
                                else
                                    v251 = UNNAMED_2819735046248[u40 + 1] - 1;
                                end;

                                u40 = v251;
                                u40 = u40 + 1;
                            else
                                local v252 = UNNAMED_2819735027960[u40] + 1;
                                local v253 = u48(UNNAMED_2819735070824[u40], (u54(u48(u38, (u54(u53(u38, 29), 7))), 536870911)));

                                for i = 1, UNNAMED_2819735046248[u40] do
                                    local v254 = u54(u48(v253, (u55(v253, 13))), 536870911);
                                    local v255 = u48(v254, (u53(v254, 13)));
                                    v253 = u54(u48(v255, (u55(v255, 14))), 536870911);
                                    UNNAMED_2819735027960[v252] = u48(UNNAMED_2819735027960[v252], (u54(u53(v253, 0), 127)));
                                    UNNAMED_2819735070824[v252] = u48(UNNAMED_2819735070824[v252], (u54(u53(v253, 7), 127)));
                                    UNNAMED_2819735046248[v252] = u48(UNNAMED_2819735046248[v252], (u54(u53(v253, 14), 127)));
                                    UNNAMED_2819735064680[v252] = u48(UNNAMED_2819735064680[v252], (u54(u53(v253, 21), 127)));
                                    v252 = v252 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735064680[u40] = 57;
                            end;
                        elseif v57 == 85 then
                            local v256 = UNNAMED_2819735027960[u40] + 1;
                            local v257 = UNNAMED_2819735046248[u40];

                            for i = 1, UNNAMED_2819735070824[u40] do
                                local v258 = u54(u48(v257, (u55(v257, 13))), 536870911);
                                local v259 = u48(v258, (u53(v258, 13)));
                                v257 = u54(u48(v259, (u55(v259, 14))), 536870911);
                                UNNAMED_2819735027960[v256] = u48(UNNAMED_2819735027960[v256], (u54(u53(v257, 0), 127)));
                                UNNAMED_2819735070824[v256] = u48(UNNAMED_2819735070824[v256], (u54(u53(v257, 7), 127)));
                                UNNAMED_2819735046248[v256] = u48(UNNAMED_2819735046248[v256], (u54(u53(v257, 14), 127)));
                                UNNAMED_2819735064680[v256] = u48(UNNAMED_2819735064680[v256], (u54(u53(v257, 21), 127)));
                                v256 = v256 + 1;
                                local _ = i;
                            end;

                            UNNAMED_2819735064680[u40] = 57;
                        else
                            u39[UNNAMED_2819735064680[u40 + 1]] = u19[UNNAMED_2819735027960[u40]];
                            u39[2] = u46[UNNAMED_2819735087432[u40]][u39[3]];
                            u39[3] = u19[UNNAMED_2819735070824[u40]];

                            if u39[2] ~= u39[3] then
                                u40 = UNNAMED_2819735046248[u40 + 1] - 1;
                            end;

                            u40 = u40 + 1;
                        end;
                    elseif v57 < 91 then
                        if v57 >= 89 then
                            if v57 == 90 then
                                local v260 = u19[UNNAMED_2819735027960[u40]];
                                u39[2] = v260[5][v260[4]];
                                local v261;

                                if u39[2] then
                                    v261 = UNNAMED_2819735070824[u40];
                                else
                                    v261 = UNNAMED_2819735046248[u40];
                                end;

                                u40 = v261;
                            else
                                local v262 = u19[UNNAMED_2819735046248[u40]];
                                u39[UNNAMED_2819735064680[u40 + 1]] = v262[5][v262[4]];
                                local v263;

                                if u39[2] then
                                    v263 = UNNAMED_2819735027960[u40] - 1;
                                else
                                    v263 = UNNAMED_2819735046248[u40 + 1] - 1;
                                end;

                                u40 = v263;
                                u40 = u40 + 1;
                            end;
                        else
                            u39[2] = u19[UNNAMED_2819735027960[u40]][UNNAMED_2819735090456[u40 + 1]];
                            u39[2] = u39[2][UNNAMED_2819735047544[u40 + 1]];
                            local v264;

                            if u39[2] then
                                v264 = UNNAMED_2819735070824[u40] - 1;
                            else
                                v264 = UNNAMED_2819735046248[u40] - 1;
                            end;

                            u40 = v264;
                            u40 = u40 + 1;
                        end;
                    elseif v57 >= 93 then
                        if v57 == 94 then
                            local v265 = u19[UNNAMED_2819735046248[u40 + 1]];
                            u39[5] = v265[5][v265[4]];
                            local v266 = u39[UNNAMED_2819735064680[u40 + 1]];
                            u39[3] = v266;
                            u39[2] = v266[UNNAMED_2819735047544[u40 + 1]];
                            u39[2](u39[3]);
                            local v267 = u19[UNNAMED_2819735070824[u40 + 1]];
                            v267[5][v267[4]] = u39[15];

                            return false, false;
                        end;

                        local v268;

                        if u39[UNNAMED_2819735027960[u40]] then
                            v268 = UNNAMED_2819735046248[u40];
                        else
                            v268 = UNNAMED_2819735070824[u40];
                        end;

                        u40 = v268;
                    elseif v57 == 92 then
                        u39[2] = u39[UNNAMED_2819735064680[u40 + 1]][UNNAMED_2819735087432[u40 + 1]];
                        u39[2] = u39[2][UNNAMED_2819735090456[u40]];
                        u39[UNNAMED_2819735070824[u40 + 1]] = u39[13] + u39[UNNAMED_2819735027960[u40]];
                        u40 = UNNAMED_2819735046248[u40] - 1;
                        u40 = u40 + 1;
                    else
                        u39[4] = u39[13][UNNAMED_2819735090456[u40 + 1]];
                        u39[UNNAMED_2819735064680[u40 + 1]] = u19[UNNAMED_2819735027960[u40 + 1]][UNNAMED_2819735087432[u40 + 1]];
                        u39[4] = u39[4] * u39[5];
                        local v269;

                        if u39[4] then
                            v269 = UNNAMED_2819735070824[u40] - 1;
                        else
                            v269 = UNNAMED_2819735027960[u40] - 1;
                        end;

                        u40 = v269;
                        u40 = u40 + 1;
                    end;

                    u40 = u40 + 1;
                end;
            else
                if u41 ~= 83 then
                    return;
                end;

                while true do
                    local v270 = UNNAMED_2819735046248[u40];

                    if v270 >= 52 then
                        if v270 < 78 then
                            if v270 >= 65 then
                                if v270 >= 71 then
                                    if v270 >= 74 then
                                        if v270 < 76 then
                                            if v270 == 75 then
                                                local v271 = u19[UNNAMED_2819735027960[u40]];
                                                v271[5][v271[4]] = u39[14];

                                                return false, false;
                                            end;

                                            local v272 = u19[UNNAMED_2819735027960[u40]];
                                            u39[9] = v272[5][v272[4]];
                                            local v273 = u39[UNNAMED_2819735046248[u40 + 1]];
                                            u39[7] = v273;
                                            u39[6] = v273[UNNAMED_2819735047544[u40 + 1]];
                                            u39[6](u39[7]);
                                            local v274 = u19[UNNAMED_2819735064680[u40]];
                                            v274[5][v274[4]] = u39[UNNAMED_2819735070824[u40]];
                                            u40 = UNNAMED_2819735064680[u40 + 1] - 1;
                                            u40 = u40 + 1;
                                        elseif v270 == 77 then
                                            u39[4] = u46[UNNAMED_2819735065880[u40]];

                                            if u39[UNNAMED_2819735070824[u40]] >= u39[3] then
                                                u40 = UNNAMED_2819735027960[u40];
                                            end;
                                        else
                                            u40 = UNNAMED_2819735070824[u40];
                                        end;
                                    else
                                        if v270 < 72 then
                                            local v275 = u19[UNNAMED_2819735070824[u40]];
                                            v275[5][v275[4]] = u39[UNNAMED_2819735064680[u40]];

                                            return false, false;
                                        end;

                                        if v270 == 73 then
                                            local v276 = u19[UNNAMED_2819735064680[u40]];
                                            v276[5][v276[4]] = u39[14];

                                            return false, false;
                                        end;

                                        u39[UNNAMED_2819735070824[u40]] = u39[6][UNNAMED_2819735047544[u40]];
                                        u39[5] = u39[UNNAMED_2819735064680[u40]] - u39[6];
                                    end;
                                elseif v270 < 68 then
                                    if v270 >= 66 then
                                        if v270 == 67 then
                                            local v277 = u19[UNNAMED_2819735027960[u40]];
                                            v277[5][v277[4]] = u39[14];

                                            return false, false;
                                        end;

                                        u46[UNNAMED_2819735065880[u40]] = u39[3];
                                        u39[2] = u46[UNNAMED_2819735047544[u40]];
                                        local v278;

                                        if u39[2] then
                                            v278 = UNNAMED_2819735070824[u40] - 1;
                                        else
                                            v278 = UNNAMED_2819735064680[u40 + 1] - 1;
                                        end;

                                        u40 = v278;
                                        u40 = u40 + 1;
                                    else
                                        u39[6] = u19[UNNAMED_2819735070824[u40]];
                                        u39[5] = u46[UNNAMED_2819735065880[u40]][u39[6]];
                                        u39[6] = u19[UNNAMED_2819735027960[u40]];
                                    end;
                                elseif v270 >= 69 then
                                    if v270 == 70 then
                                        local v279 = 5;
                                        u39[10] = u46[UNNAMED_2819735090456[u40 + 2]][UNNAMED_2819735065880[u40 + 1]];
                                        u39[5] = u39[11][UNNAMED_2819735090456[u40 + 1]];
                                        u39[UNNAMED_2819735046248[u40 + 2]] = u39[5][UNNAMED_2819735065880[u40]];
                                        u39[5] = u39[11][UNNAMED_2819735047544[u40 + 1]];
                                        u39[8] = u39[5][UNNAMED_2819735047544[u40]];
                                        u39[UNNAMED_2819735046248[u40 + 1]] = 0;
                                        u39[5] = u39[10];
                                        local v280 = UNNAMED_2819735064680[u40 + 2];
                                        local _ = v279 + v280;
                                        u45(u47(u39[v279](u44(u39, 6, v279 + v280))), 1, 1, v279, u39);
                                        u39[10] = u39[5];
                                        u39[5] = u39[10][UNNAMED_2819735090456[u40]];

                                        if u39[5] >= 3 then
                                            u40 = UNNAMED_2819735027960[u40 + 2] - 2;
                                        end;

                                        u40 = u40 + 2;
                                    else
                                        u39[5] = u19[UNNAMED_2819735070824[u40]];
                                        u39[11] = u39[5]();
                                        local v281;

                                        if u39[11] then
                                            v281 = UNNAMED_2819735027960[u40];
                                        else
                                            v281 = UNNAMED_2819735064680[u40];
                                        end;

                                        u40 = v281;
                                    end;
                                else
                                    u39[UNNAMED_2819735046248[u40 + 1]] = u46[UNNAMED_2819735065880[u40 + 1]];
                                    u39[9] = u46[UNNAMED_2819735047544[u40]];
                                    local v282;

                                    if u39[2] then
                                        v282 = UNNAMED_2819735070824[u40] - 1;
                                    else
                                        v282 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    end;

                                    u40 = v282;
                                    u40 = u40 + 1;
                                end;
                            elseif v270 >= 58 then
                                if v270 < 61 then
                                    if v270 >= 59 then
                                        if v270 ~= 60 then
                                            u46[UNNAMED_2819735090456[u40 + 1]] = u39[17];
                                            u39[3] = u39[17][UNNAMED_2819735047544[u40 + 2]];
                                            u46[UNNAMED_2819735065880[u40]] = u39[UNNAMED_2819735046248[u40 + 2]];
                                            u46[UNNAMED_2819735047544[u40 + 1]] = u39[19];
                                            u39[3] = u46[UNNAMED_2819735065880[u40 + 2]][UNNAMED_2819735090456[u40]];
                                            u39[3] = u39[3]();
                                            u46[UNNAMED_2819735047544[u40]] = u39[3];
                                            u40 = UNNAMED_2819735064680[u40 + 1] - 2;
                                            u40 = u40 + 2;
                                        end;
                                    else
                                        u39[5] = u39[11][UNNAMED_2819735090456[u40]];
                                        local v283 = u19[UNNAMED_2819735027960[u40]];
                                        u39[6] = v283[5][v283[4]];
                                        u39[8] = not u39[UNNAMED_2819735046248[u40 + 1]];
                                        u39[8] = not u39[8];
                                        local v284;

                                        if u39[8] then
                                            v284 = UNNAMED_2819735070824[u40 + 1] - 1;
                                        else
                                            v284 = UNNAMED_2819735064680[u40 + 1] - 1;
                                        end;

                                        u40 = v284;
                                        u40 = u40 + 1;
                                    end;
                                elseif v270 >= 63 then
                                    if v270 == 64 then
                                        local v285 = 1;
                                        u39[5] = u39[9][UNNAMED_2819735047544[u40]];
                                        u39[5] = -u39[5];
                                        local v286 = UNNAMED_2819735046248[u40 + 1];
                                        local v287 = u39[5];
                                        u39[v286 + 1] = v287;
                                        u39[v286] = v287[UNNAMED_2819735047544[u40 + 2]];
                                        local v288 = 2;
                                        u39[5] = u39[6];
                                        u39[8] = u39[10][UNNAMED_2819735090456[u40 + 1]];
                                        u39[UNNAMED_2819735046248[u40 + 2]] = u39[5];
                                        local v289 = UNNAMED_2819735070824[u40];
                                        local _ = v289 + v285 - 1;
                                        local _ = v289 + v288;
                                        u45(u47(u39[v289](u44(u39, v289 + 1, v289 + v288))), 1, v285, v289, u39);

                                        if u39[6] >= UNNAMED_2819735065880[u40] then
                                            u40 = UNNAMED_2819735064680[u40 + 1] - 2;
                                        end;

                                        u40 = u40 + 2;
                                    else
                                        local v290 = u39[7];
                                        u39[9] = v290;
                                        u39[8] = v290[UNNAMED_2819735065880[u40]];
                                        u39[6] = u39[8];
                                        local v291 = 8;
                                        u39[10] = UNNAMED_2819735065880[u40 + 1];
                                        u39[8] = u39[6];
                                        local v292 = UNNAMED_2819735046248[u40 + 1];
                                        local _ = v291 + v292;
                                        u45(u47(u39[v291](u44(u39, 9, v291 + v292))), 1, 1, v291, u39);
                                        local v293;

                                        if u39[8] then
                                            v293 = UNNAMED_2819735070824[u40] - 1;
                                        else
                                            v293 = UNNAMED_2819735070824[u40 + 1] - 1;
                                        end;

                                        u40 = v293;
                                        u40 = u40 + 1;
                                    end;
                                elseif v270 == 62 then
                                    local v294 = u19[UNNAMED_2819735064680[u40 + 3]];
                                    u39[10] = v294[5][v294[4]];
                                    local v295 = u19[UNNAMED_2819735070824[u40 + 3]];
                                    u39[9] = v295[5][v295[4]][UNNAMED_2819735090456[u40 + 2]];
                                    local v296 = u39[UNNAMED_2819735046248[u40 + 2]];
                                    u39[6] = v296;
                                    u39[5] = v296[UNNAMED_2819735047544[u40 + 1]];
                                    local v297 = 5;
                                    u39[UNNAMED_2819735046248[u40 + 1]] = u39[5];
                                    u39[8] = u39[8] * UNNAMED_2819735065880[u40];
                                    u39[UNNAMED_2819735046248[u40 + 3]] = u39[9];
                                    local v298 = UNNAMED_2819735027960[u40 + 3];
                                    local v299 = UNNAMED_2819735027960[u40];
                                    local _ = v297 + v299 - 1;
                                    local _ = v297 + v298;
                                    u45(u47(u39[v297](u44(u39, 6, v297 + v298))), 1, v299, v297, u39);
                                    u39[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735090456[u40]] = u39[5];
                                    u40 = UNNAMED_2819735064680[u40 + 1] - 3;
                                    u40 = u40 + 3;
                                else
                                    u39[6] = u39[7][UNNAMED_2819735090456[u40]];
                                    u39[6] = u39[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735047544[u40]];

                                    if u39[6] ~= UNNAMED_2819735047544[u40 + 1] then
                                        u40 = UNNAMED_2819735064680[u40 + 1] - 1;
                                    end;

                                    u40 = u40 + 1;
                                end;
                            elseif v270 < 55 then
                                if v270 >= 53 then
                                    if v270 == 54 then
                                        u39[9] = u19[UNNAMED_2819735064680[u40]];
                                        u39[5] = u39[UNNAMED_2819735027960[u40]][UNNAMED_2819735090456[u40]];
                                    else
                                        u39[11] = u46[UNNAMED_2819735090456[u40]];
                                        u40 = UNNAMED_2819735064680[u40];
                                    end;
                                else
                                    u40 = UNNAMED_2819735027960[u40];
                                end;
                            elseif v270 >= 56 then
                                if v270 ~= 57 then
                                    u39[UNNAMED_2819735046248[u40 + 1]] = UNNAMED_2819735065880[u40];
                                    u38 = u39[UNNAMED_2819735070824[u40]];
                                    local v300 = u19[UNNAMED_2819735064680[u40 + 1]];
                                    v300[5][v300[4]] = u39[15];

                                    return false, false;
                                end;

                                u39[UNNAMED_2819735064680[u40]] = u39[19][UNNAMED_2819735047544[u40]];

                                if u39[2] <= 1 then
                                    u40 = UNNAMED_2819735070824[u40];
                                end;
                            else
                                u39[9] = u46[UNNAMED_2819735090456[u40]][UNNAMED_2819735047544[u40 + 1]];
                                u39[6] = u39[5][UNNAMED_2819735090456[u40 + 1]];
                                u39[8] = u39[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735065880[u40]];
                                u39[7] = UNNAMED_2819735064680[u40 + 1];
                                u39[5] = u39[9];
                                u40 = UNNAMED_2819735027960[u40] - 1;
                                u40 = u40 + 1;
                            end;
                        elseif v270 < 91 then
                            if v270 < 84 then
                                if v270 >= 81 then
                                    if v270 < 82 then
                                        local v301 = u19[UNNAMED_2819735064680[u40]];
                                        v301[5][v301[4]] = u39[15];

                                        return false, false;
                                    end;

                                    if v270 == 83 then
                                        u39[4] = u46[UNNAMED_2819735047544[u40]];
                                        u39[4]();
                                        u46[UNNAMED_2819735065880[u40 + 1]] = UNNAMED_2819735065880[u40];
                                        u40 = UNNAMED_2819735027960[u40 + 1] - 1;
                                        u40 = u40 + 1;
                                    else
                                        local v302 = u19[UNNAMED_2819735064680[u40]];
                                        u39[6] = v302[5][v302[4]];
                                        local v303;

                                        if u39[UNNAMED_2819735046248[u40 + 1]] then
                                            v303 = UNNAMED_2819735064680[u40 + 1] - 1;
                                        else
                                            v303 = UNNAMED_2819735027960[u40] - 1;
                                        end;

                                        u40 = v303;
                                        u40 = u40 + 1;
                                    end;
                                elseif v270 < 79 then
                                    local v304 = u48(u38, u54(u53(u38, 14), 262143), (u54(u53(u38, 28), 15)));
                                    local v305 = UNNAMED_2819735064680[u40];
                                    local v306 = UNNAMED_2819735070824[u40];
                                    local v307 = UNNAMED_2819735027960[u40];
                                    local v308 = v305 < 2097152 and 7 or 14;
                                    local v309 = u54(v305, u55(1, v308) - 1);
                                    local v310 = u53(v305, v308);
                                    UNNAMED_2819735064680[u40] = u48(v309, 48, (u54(u53(v304, 14), 127)));
                                    UNNAMED_2819735070824[u40] = u48(v306, 71, (u54(v304, 127)));
                                    UNNAMED_2819735027960[u40] = u48(v307, 78, (u54(u53(v304, 7), 127)));
                                    UNNAMED_2819735046248[u40] = u48(v310, 15, (u54(u53(v304, 21), 127)));
                                    u40 = u40 - 1;
                                elseif v270 == 80 then
                                    u39[2] = u46[UNNAMED_2819735065880[u40]];
                                    local v311;

                                    if u39[2] then
                                        v311 = UNNAMED_2819735070824[u40];
                                    else
                                        v311 = UNNAMED_2819735027960[u40];
                                    end;

                                    u40 = v311;
                                else
                                    u39[2] = u46[UNNAMED_2819735090456[u40]];
                                    u39[2]();
                                    u39[10] = u19[UNNAMED_2819735070824[u40 + 2]][UNNAMED_2819735047544[u40 + 3]];
                                    u39[2] = u19[UNNAMED_2819735064680[u40 + 2]];
                                    local v312 = 4;
                                    local v313 = u39[8];
                                    u39[4] = u39[UNNAMED_2819735046248[u40 + 2]];
                                    u39[5] = v313;
                                    u39[6] = u39[UNNAMED_2819735046248[u40 + 1]];
                                    u45(u47(u39[v312](u44(u39, 5, 6))), 1, 1, v312, u39);
                                    local v314 = UNNAMED_2819735046248[u40 + 3];
                                    local v315 = UNNAMED_2819735027960[u40];
                                    u39[v314] = UNNAMED_2819735090456[u40 + 1];
                                    u39[v314 + 1] = v315;
                                    u39[3] = u39[10];
                                    local v316 = UNNAMED_2819735027960[u40 + 2];
                                    local v317 = UNNAMED_2819735070824[u40 + 3];
                                    local v318 = UNNAMED_2819735064680[u40 + 3];
                                    local _ = v316 + v318 - 1;
                                    local _ = v316 + v317;
                                    u45(u47(u39[v316](u44(u39, v316 + 1, v316 + v317))), 1, v318, v316, u39);
                                    u39[10] = u39[UNNAMED_2819735027960[u40 + 1]];
                                    u40 = UNNAMED_2819735064680[u40 + 1] - 3;
                                    u40 = u40 + 3;
                                end;
                            elseif v270 >= 87 then
                                if v270 >= 89 then
                                    if v270 == 90 then
                                        local v319 = u19[UNNAMED_2819735027960[u40]];
                                        u39[6] = v319[5][v319[4]];
                                        local v320;

                                        if u39[6] then
                                            v320 = UNNAMED_2819735070824[u40];
                                        else
                                            v320 = UNNAMED_2819735064680[u40];
                                        end;

                                        u40 = v320;
                                    else
                                        u39[9] = u19[UNNAMED_2819735070824[u40 + 1]];
                                        local v321 = u39[9];
                                        u39[7] = v321;
                                        u39[6] = v321[UNNAMED_2819735065880[u40 + 1]];
                                        local v322 = 6;
                                        u39[9] = u39[UNNAMED_2819735046248[u40 + 2]];
                                        u39[8] = UNNAMED_2819735065880[u40];
                                        u39[6] = u39[UNNAMED_2819735046248[u40 + 1]];
                                        local v323 = UNNAMED_2819735070824[u40 + 2];
                                        local v324 = UNNAMED_2819735027960[u40 + 2];
                                        local _ = v322 + v324 - 1;
                                        local _ = v322 + v323;
                                        u45(u47(u39[v322](u44(u39, 7, v322 + v323))), 1, v324, v322, u39);
                                        local v325;

                                        if u39[UNNAMED_2819735064680[u40 + 2]] then
                                            v325 = UNNAMED_2819735027960[u40 + 1] - 2;
                                        else
                                            v325 = UNNAMED_2819735070824[u40] - 2;
                                        end;

                                        u40 = v325;
                                        u40 = u40 + 2;
                                    end;
                                elseif v270 == 88 then
                                    u39[3] = u46[UNNAMED_2819735047544[u40]];
                                    u39[3]();
                                    u39[3] = u46[UNNAMED_2819735047544[u40 + 1]];
                                    local v326 = UNNAMED_2819735046248[u40 + 1];
                                    local v327, v328 = u39[3]();
                                    u39[v326] = v327;
                                    u39[9] = v328;
                                    local v329;

                                    if u39[2] then
                                        v329 = UNNAMED_2819735064680[u40 + 1] - 1;
                                    else
                                        v329 = UNNAMED_2819735070824[u40 + 1] - 1;
                                    end;

                                    u40 = v329;
                                    u40 = u40 + 1;
                                else
                                    u39[3] = u46[UNNAMED_2819735090456[u40]];
                                    local v330;

                                    if u39[UNNAMED_2819735046248[u40 + 1]] then
                                        v330 = UNNAMED_2819735070824[u40 + 1] - 1;
                                    else
                                        v330 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    end;

                                    u40 = v330;
                                    u40 = u40 + 1;
                                end;
                            elseif v270 < 85 then
                                u39[3] = u46[UNNAMED_2819735047544[u40]][UNNAMED_2819735065880[u40]];
                                u39[3] = u39[3]();
                                u39[4] = u46[UNNAMED_2819735090456[u40 + 1]];
                                u39[3] = u39[3] - u39[4];
                                u39[4] = u38;
                                u39[UNNAMED_2819735046248[u40 + 1]] = u39[4] == UNNAMED_2819735027960[u40 + 1];
                                local v331;

                                if u39[4] then
                                    v331 = UNNAMED_2819735064680[u40 + 1] - 1;
                                else
                                    v331 = UNNAMED_2819735070824[u40] - 1;
                                end;

                                u40 = v331;
                                u40 = u40 + 1;
                            elseif v270 == 86 then
                                u39[2] = u46[UNNAMED_2819735090456[u40]][UNNAMED_2819735047544[u40]];
                                local v332;

                                if u39[2] then
                                    v332 = UNNAMED_2819735064680[u40] - 1;
                                else
                                    v332 = UNNAMED_2819735064680[u40 + 1] - 1;
                                end;

                                u40 = v332;
                                u40 = u40 + 1;
                            else
                                u39[3] = u19[UNNAMED_2819735064680[u40]];
                                u39[17] = u39[3]();
                                u39[UNNAMED_2819735046248[u40 + 1]] = UNNAMED_2819735090456[u40 + 1];
                                u38 = u39[3];
                                u39[3] = UNNAMED_2819735090456[u40];
                                u38 = u39[UNNAMED_2819735027960[u40]];
                                local v333;

                                if u39[17] then
                                    v333 = UNNAMED_2819735027960[u40 + 1] - 1;
                                else
                                    v333 = UNNAMED_2819735064680[u40 + 1] - 1;
                                end;

                                u40 = v333;
                                u40 = u40 + 1;
                            end;
                        elseif v270 >= 98 then
                            if v270 >= 101 then
                                if v270 < 103 then
                                    if v270 == 102 then
                                        local v334 = u19[UNNAMED_2819735070824[u40]];
                                        v334[5][v334[4]] = u39[UNNAMED_2819735064680[u40]];

                                        return false, false;
                                    end;

                                    u39[11] = u39[3];
                                    u40 = UNNAMED_2819735064680[u40];
                                elseif v270 == 104 then
                                    u46[UNNAMED_2819735090456[u40]][UNNAMED_2819735065880[u40]] = UNNAMED_2819735065880[u40 + 1];
                                    local v335;

                                    if u39[14] then
                                        v335 = UNNAMED_2819735070824[u40 + 1] - 1;
                                    else
                                        v335 = UNNAMED_2819735027960[u40] - 1;
                                    end;

                                    u40 = v335;
                                    u40 = u40 + 1;
                                else
                                    local v336 = UNNAMED_2819735064680[u40] + 1;
                                    local v337 = UNNAMED_2819735027960[u40];

                                    for i = 1, UNNAMED_2819735070824[u40] do
                                        local v338 = u54(u48(v337, (u55(v337, 13))), 536870911);
                                        local v339 = u48(v338, (u53(v338, 13)));
                                        v337 = u54(u48(v339, (u55(v339, 14))), 536870911);
                                        UNNAMED_2819735070824[v336] = u48(UNNAMED_2819735070824[v336], (u54(u53(v337, 0), 127)));
                                        UNNAMED_2819735027960[v336] = u48(UNNAMED_2819735027960[v336], (u54(u53(v337, 7), 127)));
                                        UNNAMED_2819735064680[v336] = u48(UNNAMED_2819735064680[v336], (u54(u53(v337, 14), 127)));
                                        UNNAMED_2819735046248[v336] = u48(UNNAMED_2819735046248[v336], (u54(u53(v337, 21), 127)));
                                        v336 = v336 + 1;
                                        local _ = i;
                                    end;

                                    UNNAMED_2819735046248[u40] = 60;
                                end;
                            elseif v270 < 99 then
                                u39[3] = u46[UNNAMED_2819735047544[u40 + 2]];
                                u39[4] = UNNAMED_2819735090456[u40 + 1];
                                u38 = u39[4];
                                u39[3]();
                                u39[UNNAMED_2819735046248[u40 + 1]] = UNNAMED_2819735065880[u40 + 1];
                                u38 = u39[3];
                                local v340 = UNNAMED_2819735046248[u40 + 2];
                                local v341 = u39[21];
                                u39[v340] = u39[21];
                                u39[v340 + 1] = v341;
                                local v342;

                                if u39[UNNAMED_2819735027960[u40]] then
                                    v342 = UNNAMED_2819735064680[u40] - 2;
                                else
                                    v342 = UNNAMED_2819735027960[u40 + 1] - 2;
                                end;

                                u40 = v342;
                                u40 = u40 + 2;
                            elseif v270 == 100 then
                                u39[2] = u19[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735090456[u40 + 8]];
                                u39[2] = u39[2](UNNAMED_2819735065880[u40 + 5]);
                                u46[UNNAMED_2819735047544[u40 + 7]] = u39[2];
                                u46[UNNAMED_2819735065880[u40]][UNNAMED_2819735047544[u40]] = UNNAMED_2819735090456[u40 + 5];
                                u39[2] = u46[UNNAMED_2819735047544[u40 + 8]];
                                u39[UNNAMED_2819735046248[u40 + 7]] = u46[UNNAMED_2819735065880[u40 + 1]][UNNAMED_2819735047544[u40 + 3]];
                                u39[4] = u39[4][UNNAMED_2819735090456[u40 + 7]];
                                u39[UNNAMED_2819735046248[u40 + 8]][UNNAMED_2819735065880[u40 + 6]] = u39[4];
                                u46[UNNAMED_2819735065880[u40 + 7]][UNNAMED_2819735090456[u40 + 2]] = UNNAMED_2819735065880[u40 + 4];
                                u46[UNNAMED_2819735090456[u40 + 6]][UNNAMED_2819735047544[u40 + 5]] = UNNAMED_2819735090456[u40 + 9];
                                u46[UNNAMED_2819735090456[u40 + 3]][UNNAMED_2819735047544[u40 + 4]] = UNNAMED_2819735047544[u40 + 1];
                                u46[UNNAMED_2819735065880[u40 + 2]][UNNAMED_2819735047544[u40 + 9]] = UNNAMED_2819735065880[u40 + 3];
                                u39[2] = u46[UNNAMED_2819735047544[u40 + 6]];
                                u39[4] = u46[UNNAMED_2819735065880[u40 + 8]][UNNAMED_2819735047544[u40 + 2]];
                                u40 = UNNAMED_2819735070824[u40 + 4] - 9;
                                u40 = u40 + 9;
                            elseif u39[UNNAMED_2819735070824[u40]] ~= u39[UNNAMED_2819735027960[u40]] then
                                u40 = UNNAMED_2819735064680[u40];
                            end;
                        elseif v270 < 94 then
                            if v270 < 92 then
                                u46[UNNAMED_2819735065880[u40]] = UNNAMED_2819735047544[u40];

                                return false, false;
                            end;

                            if v270 == 93 then
                                local v343 = UNNAMED_2819735070824[u40] + 1;
                                local v344 = u48(UNNAMED_2819735027960[u40], (u54(u48(u38, (u54(u53(u38, 29), 7))), 536870911)));

                                for i = 1, UNNAMED_2819735064680[u40] do
                                    local v345 = u54(u48(v344, (u55(v344, 13))), 536870911);
                                    local v346 = u48(v345, (u53(v345, 13)));
                                    v344 = u54(u48(v346, (u55(v346, 14))), 536870911);
                                    UNNAMED_2819735070824[v343] = u48(UNNAMED_2819735070824[v343], (u54(u53(v344, 0), 127)));
                                    UNNAMED_2819735027960[v343] = u48(UNNAMED_2819735027960[v343], (u54(u53(v344, 7), 127)));
                                    UNNAMED_2819735064680[v343] = u48(UNNAMED_2819735064680[v343], (u54(u53(v344, 14), 127)));
                                    UNNAMED_2819735046248[v343] = u48(UNNAMED_2819735046248[v343], (u54(u53(v344, 21), 127)));
                                    v343 = v343 + 1;
                                    local _ = i;
                                end;

                                UNNAMED_2819735046248[u40] = 60;
                            else
                                u39[2] = u46[UNNAMED_2819735047544[u40]];
                                local v347;

                                if u39[2] then
                                    v347 = UNNAMED_2819735070824[u40];
                                else
                                    v347 = UNNAMED_2819735064680[u40];
                                end;

                                u40 = v347;
                            end;
                        elseif v270 < 96 then
                            if v270 == 95 then
                                local v348 = u19[UNNAMED_2819735064680[u40]];
                                u39[UNNAMED_2819735046248[u40 + 1]] = v348[5][v348[4]];
                                local v349;

                                if u39[UNNAMED_2819735070824[u40 + 1]] then
                                    v349 = UNNAMED_2819735027960[u40] - 1;
                                else
                                    v349 = UNNAMED_2819735070824[u40] - 1;
                                end;

                                u40 = v349;
                                u40 = u40 + 1;
                            else
                                u39[3] = u46[UNNAMED_2819735065880[u40]];
                                u39[UNNAMED_2819735046248[u40 + 1]] = u39[3](u39[17]);
                                local v350;

                                if u39[UNNAMED_2819735064680[u40 + 1]] then
                                    v350 = UNNAMED_2819735027960[u40 + 1] - 1;
                                else
                                    v350 = UNNAMED_2819735027960[u40] - 1;
                                end;

                                u40 = v350;
                                u40 = u40 + 1;
                            end;
                        elseif v270 == 97 then
                            u39[UNNAMED_2819735027960[u40]] = u39[9];
                            u40 = UNNAMED_2819735064680[u40];
                        else
                            local v351 = UNNAMED_2819735027960[u40];
                            local v352 = UNNAMED_2819735070824[u40];
                            local v353 = UNNAMED_2819735064680[u40];
                            local v354 = u48(u38, u54(u53(u38, 14), 262143), (u54(u53(u38, 28), 15)));
                            local v355 = v353 < 16384 and 7 or (v353 < 2097152 and 14 or 21);
                            local v356 = u53(v353, v355);
                            local v357 = u54(v353, u55(1, v355) - 1);
                            UNNAMED_2819735070824[u40] = u48(v352, 46, (u54(v354, 127)));
                            UNNAMED_2819735064680[u40] = u48(v357, 119, (u54(u53(v354, 14), 127)));
                            UNNAMED_2819735046248[u40] = u48(v356, 99, (u54(u53(v354, 21), 127)));
                            UNNAMED_2819735027960[u40] = u48(v351, 95, (u54(u53(v354, 7), 127)));
                            u40 = u40 - 1;
                        end;
                    elseif v270 >= 26 then
                        if v270 < 39 then
                            if v270 >= 32 then
                                if v270 >= 35 then
                                    if v270 < 37 then
                                        if v270 == 36 then
                                            u39[UNNAMED_2819735046248[u40 + 1]] = u19[UNNAMED_2819735064680[u40 + 1]];
                                            local v358 = u39[6];
                                            u39[5] = v358;
                                            u39[4] = v358[UNNAMED_2819735090456[u40]];
                                            u39[UNNAMED_2819735027960[u40 + 1]](u39[UNNAMED_2819735027960[u40]], UNNAMED_2819735090456[u40 + 1]);
                                            u39[2] = u46[UNNAMED_2819735065880[u40]];
                                            u39[2]();

                                            return false, false;
                                        end;

                                        u39[2] = u46[UNNAMED_2819735065880[u40 + 1]];
                                        u39[4] = u46[UNNAMED_2819735090456[u40 + 2]][UNNAMED_2819735047544[u40 + 1]];
                                        u39[UNNAMED_2819735046248[u40 + 2]] = u46[UNNAMED_2819735047544[u40 + 2]];
                                        u39[UNNAMED_2819735046248[u40 + 1]] = UNNAMED_2819735090456[u40 + 1];
                                        u38 = u39[UNNAMED_2819735064680[u40]];
                                        u39[4] = u39[4](u39[5]);
                                        u39[2][UNNAMED_2819735047544[u40]] = u39[4];
                                        u39[2] = UNNAMED_2819735090456[u40];
                                        u38 = u39[2];
                                        u40 = UNNAMED_2819735064680[u40 + 2] - 2;
                                        u40 = u40 + 2;
                                    elseif v270 == 38 then
                                        u39[UNNAMED_2819735046248[u40 + 1]] = u46[UNNAMED_2819735090456[u40 + 1]];
                                        local v359;

                                        if u39[4] then
                                            v359 = UNNAMED_2819735064680[u40 + 1] - 1;
                                        else
                                            v359 = UNNAMED_2819735070824[u40] - 1;
                                        end;

                                        u40 = v359;
                                        u40 = u40 + 1;
                                    else
                                        u40 = UNNAMED_2819735064680[u40];
                                    end;
                                elseif v270 >= 33 then
                                    if v270 == 34 then
                                        u39[UNNAMED_2819735046248[u40 + 1]] = u19[UNNAMED_2819735070824[u40 + 1]];
                                        u39[UNNAMED_2819735064680[u40 + 1]] = u46[UNNAMED_2819735047544[u40]][u39[UNNAMED_2819735064680[u40]]];
                                        u39[7] = u19[UNNAMED_2819735070824[u40]];

                                        if u39[6] ~= u39[7] then
                                            u40 = UNNAMED_2819735027960[u40 + 1] - 1;
                                        end;

                                        u40 = u40 + 1;
                                    else
                                        u39[3] = u39[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735065880[u40 + 1]];
                                        local v360;

                                        if u39[3] then
                                            v360 = UNNAMED_2819735027960[u40] - 1;
                                        else
                                            v360 = UNNAMED_2819735070824[u40] - 1;
                                        end;

                                        u40 = v360;
                                        u40 = u40 + 1;
                                    end;
                                else
                                    u39[3] = u39[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735065880[u40]];
                                    u39[4] = u46[UNNAMED_2819735090456[u40]];

                                    if u39[4] >= u39[3] then
                                        u40 = UNNAMED_2819735027960[u40] - 1;
                                    end;

                                    u40 = u40 + 1;
                                end;
                            elseif v270 >= 29 then
                                if v270 >= 30 then
                                    if v270 == 31 then
                                        local v361;

                                        if u39[UNNAMED_2819735070824[u40]] then
                                            v361 = UNNAMED_2819735064680[u40];
                                        else
                                            v361 = UNNAMED_2819735027960[u40];
                                        end;

                                        u40 = v361;
                                    else
                                        u39[2] = u46[UNNAMED_2819735065880[u40]];
                                        u39[3] = not u39[UNNAMED_2819735027960[u40]];
                                    end;
                                else
                                    u39[UNNAMED_2819735046248[u40 + 1]] = u46[UNNAMED_2819735065880[u40 + 1]];

                                    if u39[3] ~= u39[UNNAMED_2819735027960[u40 + 1]] then
                                        u40 = UNNAMED_2819735027960[u40] - 1;
                                    end;

                                    u40 = u40 + 1;
                                end;
                            elseif v270 < 27 then
                                u39[2] = u46[UNNAMED_2819735090456[u40 + 1]];
                                u39[4] = u19[UNNAMED_2819735064680[u40 + 4]][UNNAMED_2819735065880[u40 + 2]];
                                u39[UNNAMED_2819735046248[u40 + 3]] = u39[UNNAMED_2819735046248[u40 + 2]][UNNAMED_2819735047544[u40 + 1]];
                                u39[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735065880[u40]] = u39[4];
                                u39[2] = u46[UNNAMED_2819735065880[u40 + 3]];
                                u39[UNNAMED_2819735046248[u40 + 4]] = u39[2](u39[17]);
                                u39[4] = u19[UNNAMED_2819735027960[u40 + 4]][UNNAMED_2819735090456[u40 + 3]];
                                u39[5] = -u39[16];
                                u39[5] = u39[UNNAMED_2819735064680[u40 + 1]] * 16;
                                u39[4] = u39[4](u39[UNNAMED_2819735027960[u40 + 3]]);
                                u39[12] = 1 - u39[UNNAMED_2819735070824[u40 + 2]];
                                u40 = UNNAMED_2819735070824[u40] - 4;
                                u40 = u40 + 4;
                            else
                                if v270 == 28 then
                                    local v362 = u19[UNNAMED_2819735064680[u40]];
                                    v362[5][v362[4]] = u39[15];
                                    u39[6] = UNNAMED_2819735047544[u40];
                                    u38 = u39[6];

                                    return false, false;
                                end;

                                if u39[UNNAMED_2819735027960[u40]] >= UNNAMED_2819735064680[u40] then
                                    u40 = UNNAMED_2819735070824[u40];
                                end;
                            end;
                        elseif v270 < 45 then
                            if v270 < 42 then
                                if v270 < 40 then
                                    local v363 = u19[UNNAMED_2819735064680[u40]];
                                    u39[5] = v363[5][v363[4]][UNNAMED_2819735090456[u40]];
                                    local v364 = u19[UNNAMED_2819735027960[u40]];
                                    v364[5][v364[4]] = u39[5];

                                    return false, false;
                                end;

                                if v270 == 41 then
                                    u39[4] = u39[4][UNNAMED_2819735090456[u40 + 3]];
                                    u39[2][UNNAMED_2819735090456[u40 + 4]] = u39[4];
                                    u46[UNNAMED_2819735065880[u40 + 1]][UNNAMED_2819735065880[u40]] = UNNAMED_2819735047544[u40];
                                    u39[UNNAMED_2819735046248[u40 + 1]] = u46[UNNAMED_2819735047544[u40 + 1]];
                                    u39[4] = UNNAMED_2819735047544[u40 + 2] * UNNAMED_2819735047544[u40 + 3];
                                    u39[2][UNNAMED_2819735065880[u40 + 4]] = u39[4];
                                    u39[4] = u19[UNNAMED_2819735064680[u40 + 2]];
                                    u46[UNNAMED_2819735090456[u40]][UNNAMED_2819735090456[u40 + 2]] = u39[4];
                                    u40 = UNNAMED_2819735064680[u40 + 3] - 4;
                                    u40 = u40 + 4;
                                else
                                    u46[UNNAMED_2819735090456[u40 + 1]][UNNAMED_2819735047544[u40]] = UNNAMED_2819735090456[u40];
                                    local v365;

                                    if u39[14] then
                                        v365 = UNNAMED_2819735064680[u40 + 1] - 1;
                                    else
                                        v365 = UNNAMED_2819735064680[u40] - 1;
                                    end;

                                    u40 = v365;
                                    u40 = u40 + 1;
                                end;
                            else
                                if v270 < 43 then
                                    local v366 = u19[UNNAMED_2819735064680[u40]];
                                    u39[8] = v366[5][v366[4]];
                                    local v367 = u39[8];
                                    u39[6] = v367;
                                    u39[5] = v367[UNNAMED_2819735090456[u40]];
                                    u39[5](u39[6]);

                                    return false, false;
                                end;

                                if v270 == 44 then
                                    u46[UNNAMED_2819735090456[u40 + 1]] = UNNAMED_2819735047544[u40 + 1];
                                    u39[4] = u46[UNNAMED_2819735047544[u40]];
                                    local v368;

                                    if u39[UNNAMED_2819735046248[u40 + 1]] then
                                        v368 = UNNAMED_2819735070824[u40] - 1;
                                    else
                                        v368 = UNNAMED_2819735064680[u40 + 1] - 1;
                                    end;

                                    u40 = v368;
                                    u40 = u40 + 1;
                                else
                                    local v369 = u19[UNNAMED_2819735064680[u40 + 1]];
                                    u39[5] = v369[5][v369[4]][UNNAMED_2819735090456[u40 + 1]];
                                    local v370;

                                    if u39[UNNAMED_2819735046248[u40 + 1]] then
                                        v370 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    else
                                        v370 = UNNAMED_2819735027960[u40] - 1;
                                    end;

                                    u40 = v370;
                                    u40 = u40 + 1;
                                end;
                            end;
                        elseif v270 >= 48 then
                            if v270 >= 50 then
                                if v270 == 51 then
                                    u39[3] = u39[UNNAMED_2819735046248[u40 + 1]] + u39[UNNAMED_2819735064680[u40 + 1]];
                                    u46[UNNAMED_2819735047544[u40]] = u39[3];
                                    u39[3] = u46[UNNAMED_2819735090456[u40]];

                                    if u39[3] >= UNNAMED_2819735090456[u40 + 1] then
                                        u40 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    end;

                                    u40 = u40 + 1;
                                else
                                    u39[2] = u19[UNNAMED_2819735064680[u40 + 2]][UNNAMED_2819735047544[u40 + 2]];
                                    u39[2] = u39[2][UNNAMED_2819735047544[u40]];
                                    u39[4] = u19[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735047544[u40 + 1]];
                                    u39[14] = u39[4][UNNAMED_2819735065880[u40]];
                                    local v371;

                                    if u39[2] then
                                        v371 = UNNAMED_2819735070824[u40] - 2;
                                    else
                                        v371 = UNNAMED_2819735070824[u40 + 2] - 2;
                                    end;

                                    u40 = v371;
                                    u40 = u40 + 2;
                                end;
                            elseif v270 == 49 then
                                u39[2] = u46[UNNAMED_2819735065880[u40]];
                                local v372;

                                if u39[2] then
                                    v372 = UNNAMED_2819735027960[u40];
                                else
                                    v372 = UNNAMED_2819735070824[u40];
                                end;

                                u40 = v372;
                            else
                                u39[UNNAMED_2819735046248[u40 + 4]] = u39[9](u39[10]);
                                u39[UNNAMED_2819735046248[u40 + 1]][UNNAMED_2819735090456[u40 + 4]] = u39[UNNAMED_2819735046248[u40 + 2]];
                                u46[UNNAMED_2819735065880[u40 + 4]][UNNAMED_2819735047544[u40 + 4]] = u39[UNNAMED_2819735046248[u40 + 3]];
                                u46[UNNAMED_2819735065880[u40 + 2]][UNNAMED_2819735090456[u40 + 2]] = u39[3];
                                u39[2] = u46[UNNAMED_2819735047544[u40 + 3]];
                                u39[3] = u19[UNNAMED_2819735070824[u40 + 1]];
                                u39[UNNAMED_2819735046248[u40 + 5]](u39[UNNAMED_2819735027960[u40 + 2]], u39[4]);
                                u39[2] = u46[UNNAMED_2819735090456[u40 + 5]];
                                u39[UNNAMED_2819735070824[u40]] = u19[UNNAMED_2819735064680[u40 + 3]];
                                u39[3](u39[2], u39[5]);
                                u39[UNNAMED_2819735064680[u40 + 5]] = UNNAMED_2819735047544[u40 + 5];
                                u38 = u39[UNNAMED_2819735064680[u40 + 1]];
                                u39[UNNAMED_2819735064680[u40]] = UNNAMED_2819735090456[u40 + 3];
                                u38 = u39[2];
                                local v373;

                                if u39[14] then
                                    v373 = UNNAMED_2819735027960[u40] - 5;
                                else
                                    v373 = UNNAMED_2819735027960[u40 + 1] - 5;
                                end;

                                u40 = v373;
                                u40 = u40 + 5;
                            end;
                        elseif v270 >= 46 then
                            if v270 == 47 then
                                u39[6] = u19[UNNAMED_2819735070824[u40]];
                                u39[6](UNNAMED_2819735065880[u40]);

                                return false, false;
                            end;

                            local v374 = 5;
                            u45(u47(u39[v374](u44(u39, 6, 8))), 1, 1, v374, u39);
                            u39[9] = u39[5];
                            u39[5] = u39[9][UNNAMED_2819735065880[u40]];
                            u39[UNNAMED_2819735046248[u40 + 1]] = u19[UNNAMED_2819735027960[u40]][UNNAMED_2819735090456[u40 + 1]];

                            if u39[6] >= u39[5] then
                                u40 = UNNAMED_2819735070824[u40] - 1;
                            end;

                            u40 = u40 + 1;
                        else
                            local v375 = u19[UNNAMED_2819735027960[u40]];
                            u39[10] = v375[5][v375[4]];
                            local v376 = u19[UNNAMED_2819735027960[u40 + 1]];
                            u39[13] = v376[5][v376[4]];
                            local v377 = u39[UNNAMED_2819735046248[u40 + 1]];
                            u39[6] = v377;
                            u39[5] = v377[UNNAMED_2819735065880[u40 + 1]];
                            local v378 = 5;
                            u39[9] = u39[5];
                            u39[5] = u39[9];
                            u45(u47(u39[v378](u44(u39, 6, 8))), 1, 1, v378, u39);
                            u39[UNNAMED_2819735070824[u40 + 1]][UNNAMED_2819735090456[u40]] = u39[5];
                            u40 = UNNAMED_2819735064680[u40] - 1;
                            u40 = u40 + 1;
                        end;
                    elseif v270 >= 13 then
                        if v270 >= 19 then
                            if v270 >= 22 then
                                if v270 < 24 then
                                    if v270 == 23 then
                                        u39[3] = 0;
                                        u40 = UNNAMED_2819735027960[u40];
                                    else
                                        local v379 = UNNAMED_2819735027960[u40];
                                        local v380 = UNNAMED_2819735070824[u40];
                                        local v381 = UNNAMED_2819735059736[5];
                                        local v382 = u48(v381[v379], 109162203);
                                        v381[v379] = v382;
                                        local v383 = UNNAMED_2819735059736[4];
                                        local v384 = v382 + 1;
                                        local v385 = u49(v383, v384);
                                        local v386;

                                        if v385 < 128 then
                                            v386 = v384 + 1;
                                        else
                                            local v387 = u49(v383, v384 + 1);

                                            if v387 < 128 then
                                                v385 = v385 - 128 + v387 * 128;
                                                v386 = v384 + 2;
                                            else
                                                local v388 = u49(v383, v384 + 2);

                                                if v388 < 128 then
                                                    v385 = v385 - 128 + (v387 - 128) * 16384 + v388 * 128;
                                                    v386 = v384 + 3;
                                                else
                                                    local v389 = u49(v383, v384 + 3);
                                                    v385 = (v385 - 128) * 16384 + (v387 - 128) * 128 + (v388 - 128) + v389 % 128 * 2097152 + (v389 - v389 % 128) * 2097152;
                                                    v386 = v384 + 4;
                                                end;
                                            end;
                                        end;

                                        local v390 = v380 * 16843009;
                                        local v391 = v386 + v385;
                                        local v392 = v391 - v385 % 4;

                                        for i = v386, v392 - 1, 4 do
                                            u50(v383, i, (u48(u51(v383, i), v390)));
                                            local _ = i;
                                        end;

                                        for i = v392, v391 - 1 do
                                            u52(v383, i, (u48(u49(v383, i), v380)));
                                            local _ = i;
                                        end;

                                        UNNAMED_2819735027960[u40] = 77;
                                        UNNAMED_2819735070824[u40] = 118;
                                        UNNAMED_2819735064680[u40] = 62;
                                        UNNAMED_2819735046248[u40] = 60;
                                    end;
                                else
                                    if v270 ~= 25 then
                                        u39[4] = u46[UNNAMED_2819735090456[u40 + 1]];
                                        local v393 = UNNAMED_2819735046248[u40 + 1];
                                        local v394 = u39[UNNAMED_2819735070824[u40]];
                                        u39[v393 + 1] = v394;
                                        u39[v393] = v394[UNNAMED_2819735065880[u40]];
                                        u39[2](u39[3]);
                                        u46[UNNAMED_2819735047544[u40 + 1]] = u39[20];
                                        u46[UNNAMED_2819735047544[u40]] = u39[UNNAMED_2819735064680[u40 + 1]];

                                        return false, false;
                                    end;

                                    u39[17] = u39[21];
                                    u40 = UNNAMED_2819735027960[u40];
                                end;
                            elseif v270 >= 20 then
                                if v270 == 21 then
                                    local v395 = u19[UNNAMED_2819735064680[u40]];
                                    u39[6] = v395[5][v395[4]];
                                    local v396;

                                    if u39[6] then
                                        v396 = UNNAMED_2819735070824[u40];
                                    else
                                        v396 = UNNAMED_2819735027960[u40];
                                    end;

                                    u40 = v396;
                                else
                                    local v397 = u19[UNNAMED_2819735064680[u40]];
                                    u39[5] = v397[5][v397[4]];
                                    local v398;

                                    if u39[5] then
                                        v398 = UNNAMED_2819735027960[u40];
                                    else
                                        v398 = UNNAMED_2819735070824[u40];
                                    end;

                                    u40 = v398;
                                end;
                            else
                                u39[UNNAMED_2819735070824[u40]] = u39[9][UNNAMED_2819735047544[u40]];

                                if u39[2] <= 1 then
                                    u40 = UNNAMED_2819735064680[u40];
                                end;
                            end;
                        elseif v270 < 16 then
                            if v270 >= 14 then
                                if v270 == 15 then
                                    local v399 = 1;
                                    local v400 = u19[UNNAMED_2819735027960[u40 + 2]];
                                    u39[8] = v400[5][v400[4]];
                                    local v401 = u39[8];
                                    u39[6] = v401;
                                    u39[5] = v401[UNNAMED_2819735065880[u40 + 2]];
                                    u39[8] = u39[5];
                                    u39[UNNAMED_2819735046248[u40 + 2]] = UNNAMED_2819735090456[u40 + 1];
                                    u39[UNNAMED_2819735046248[u40 + 1]] = u39[8];
                                    local v402 = UNNAMED_2819735064680[u40];
                                    local v403 = UNNAMED_2819735070824[u40];
                                    local _ = v402 + v399 - 1;
                                    local _ = v402 + v403;
                                    u45(u47(u39[v402](u44(u39, v402 + 1, v402 + v403))), 1, v399, v402, u39);
                                    local v404;

                                    if u39[5] then
                                        v404 = UNNAMED_2819735070824[u40 + 2] - 2;
                                    else
                                        v404 = UNNAMED_2819735027960[u40] - 2;
                                    end;

                                    u40 = v404;
                                    u40 = u40 + 2;
                                else
                                    local v405 = 1;
                                    local v406 = 3;
                                    u39[9] = u39[UNNAMED_2819735046248[u40 + 1]];
                                    local v407 = UNNAMED_2819735064680[u40 + 1];
                                    local _ = v407 + v405 - 1;
                                    local _ = v407 + v406;
                                    u45(u47(u39[v407](u44(u39, v407 + 1, v407 + v406))), 1, v405, v407, u39);
                                    local v408;

                                    if u39[9] then
                                        v408 = UNNAMED_2819735027960[u40] - 1;
                                    else
                                        v408 = UNNAMED_2819735027960[u40 + 1] - 1;
                                    end;

                                    u40 = v408;
                                    u40 = u40 + 1;
                                end;
                            else
                                u39[11] = u19[UNNAMED_2819735064680[u40 + 3]];
                                u39[UNNAMED_2819735046248[u40 + 1]] = UNNAMED_2819735065880[u40 + 1];
                                local v409 = u39[12];
                                u39[2] = u39[UNNAMED_2819735046248[u40 + 2]];
                                u39[3] = v409;
                                local v410 = 2;
                                local v411 = u39[8];
                                u39[4] = u39[9];
                                u39[5] = v411;
                                u39[6] = u39[10];
                                u45(u47(u39[v410](u44(u39, 3, 6))), 1, 4, v410, u39);
                                u39[6] = u46[UNNAMED_2819735090456[u40 + 2]];
                                u39[9] = u46[UNNAMED_2819735090456[u40 + 1]][UNNAMED_2819735047544[u40 + 1]];
                                u39[UNNAMED_2819735046248[u40 + 3]] = u19[UNNAMED_2819735027960[u40 + 3]][UNNAMED_2819735090456[u40]];
                                u39[UNNAMED_2819735064680[u40]] = u39[UNNAMED_2819735027960[u40]][UNNAMED_2819735065880[u40 + 2]];
                                u40 = UNNAMED_2819735027960[u40 + 2] - 3;
                                u40 = u40 + 3;
                            end;
                        elseif v270 < 17 then
                            u39[5] = u46[UNNAMED_2819735090456[u40 + 6]][UNNAMED_2819735047544[u40 + 3]];
                            local v412 = u19[UNNAMED_2819735070824[u40]];
                            u39[8] = v412[5][v412[4]][UNNAMED_2819735047544[u40 + 5]];
                            local v413 = u19[UNNAMED_2819735027960[u40 + 4]];
                            u39[6] = v413[5][v413[4]];
                            local v414 = 7;
                            u39[UNNAMED_2819735046248[u40 + 1]] = UNNAMED_2819735065880[u40];
                            u38 = u39[10];
                            u39[UNNAMED_2819735046248[u40 + 6]] = u39[6][UNNAMED_2819735065880[u40 + 3]];
                            u39[7] = u39[UNNAMED_2819735046248[u40 + 4]][UNNAMED_2819735065880[u40 + 1]];
                            u39[UNNAMED_2819735046248[u40 + 3]] = u39[UNNAMED_2819735046248[u40 + 2]] + u39[UNNAMED_2819735046248[u40 + 5]];
                            u39[7] = u39[5];
                            local v415 = UNNAMED_2819735070824[u40 + 2];
                            local _ = v414 + v415;
                            u45(u47(u39[v414](u44(u39, 8, v414 + v415))), 1, 1, v414, u39);
                            u39[UNNAMED_2819735070824[u40 + 3]] = u19[UNNAMED_2819735064680[u40 + 5]][UNNAMED_2819735047544[u40 + 1]];
                            u39[9] = u19[UNNAMED_2819735064680[u40 + 6]][UNNAMED_2819735047544[u40 + 2]];
                            u39[10] = UNNAMED_2819735090456[u40 + 1];
                            local v416 = 8;
                            u39[11] = 1;
                            u39[UNNAMED_2819735070824[u40 + 4]] = u39[5];
                            u45(u47(u39[v416](u44(u39, 9, 11))), 1, 1, v416, u39);
                            local v417 = u19[UNNAMED_2819735064680[u40 + 2]];
                            u39[5] = v417[5][v417[4]];
                            u40 = UNNAMED_2819735027960[u40 + 6] - 6;
                            u40 = u40 + 6;
                        elseif v270 == 18 then
                            u39[2] = u46[UNNAMED_2819735047544[u40]];
                            local v418 = u39[2];
                            u39[10] = v418;
                            u39[9] = v418[UNNAMED_2819735090456[u40]];
                            u39[2] = u39[9];
                            local v419;

                            if u39[3] then
                                v419 = UNNAMED_2819735070824[u40 + 1] - 1;
                            else
                                v419 = UNNAMED_2819735064680[u40] - 1;
                            end;

                            u40 = v419;
                            u40 = u40 + 1;
                        else
                            u39[5] = u39[11][UNNAMED_2819735047544[u40]];
                            u39[5] = u39[5][UNNAMED_2819735047544[u40 + 1]];

                            if u39[UNNAMED_2819735046248[u40 + 1]] >= UNNAMED_2819735070824[u40 + 1] then
                                u40 = UNNAMED_2819735064680[u40 + 1] - 1;
                            end;

                            u40 = u40 + 1;
                        end;
                    elseif v270 < 6 then
                        if v270 < 3 then
                            if v270 < 1 then
                                local v420 = u19[UNNAMED_2819735027960[u40]];
                                u39[9] = v420[5][v420[4]];
                                local v421 = u39[9];
                                u39[7] = v421;
                                u39[6] = v421[UNNAMED_2819735090456[u40]];
                                u39[6](u39[7]);

                                return false, false;
                            end;

                            if v270 == 2 then
                                u39[UNNAMED_2819735027960[u40]] = u46[UNNAMED_2819735065880[u40]];
                            else
                                local v422 = 1;
                                local v423 = u39[6];
                                u39[8] = v423;
                                u39[7] = v423[UNNAMED_2819735090456[u40]];
                                local v424 = 2;
                                u39[6] = u39[7];
                                u39[9] = UNNAMED_2819735047544[u40];
                                u39[7] = u39[6];
                                local v425 = UNNAMED_2819735064680[u40];
                                local _ = v425 + v422 - 1;
                                local _ = v425 + v424;
                                u45(u47(u39[v425](u44(u39, v425 + 1, v425 + v424))), 1, v422, v425, u39);
                            end;
                        elseif v270 >= 4 then
                            if v270 == 5 then
                                local v426 = UNNAMED_2819735070824[u40];
                                local v427 = u48(UNNAMED_2819735027960[u40], (u54(u48(u38, (u54(u53(u38, 29), 7))), 536870911)));
                                local v428 = UNNAMED_2819735059736[5];
                                local v429 = u48(v428[v426], 109162203);
                                v428[v426] = v429;
                                local v430 = UNNAMED_2819735059736[4];
                                local v431 = v429 + 1;
                                local v432 = u49(v430, v431);
                                local v433;

                                if v432 < 128 then
                                    v433 = v431 + 1;
                                else
                                    local v434 = u49(v430, v431 + 1);

                                    if v434 < 128 then
                                        v432 = v432 - 128 + v434 * 128;
                                        v433 = v431 + 2;
                                    else
                                        local v435 = u49(v430, v431 + 2);

                                        if v435 < 128 then
                                            v432 = v432 - 128 + (v434 - 128) * 16384 + v435 * 128;
                                            v433 = v431 + 3;
                                        else
                                            local v436 = u49(v430, v431 + 3);
                                            v432 = (v432 - 128) * 16384 + (v434 - 128) * 128 + (v435 - 128) + v436 % 128 * 2097152 + (v436 - v436 % 128) * 2097152;
                                            v433 = v431 + 4;
                                        end;
                                    end;
                                end;

                                local v437 = v427 * 16843009;
                                local v438 = v433 + v432;
                                local v439 = v438 - v432 % 4;

                                for i = v433, v439 - 1, 4 do
                                    u50(v430, i, (u48(u51(v430, i), v437)));
                                    local _ = i;
                                end;

                                for i = v439, v438 - 1 do
                                    u52(v430, i, (u48(u49(v430, i), v427)));
                                    local _ = i;
                                end;

                                UNNAMED_2819735070824[u40] = 205;
                                UNNAMED_2819735027960[u40] = 61;
                                UNNAMED_2819735064680[u40] = 33;
                                UNNAMED_2819735046248[u40] = 60;
                            else
                                u45({ ... }, 1, 1, 3, u39);
                                u39[4] = u19[UNNAMED_2819735070824[u40 + 1]];
                                u39[2] = u46[UNNAMED_2819735065880[u40]][u39[4]];
                                u39[4] = u19[UNNAMED_2819735070824[u40]];

                                if u39[2] ~= u39[4] then
                                    u40 = UNNAMED_2819735064680[u40 + 1] - 1;
                                end;

                                u40 = u40 + 1;
                            end;
                        else
                            u39[UNNAMED_2819735046248[u40 + 1]] = u46[UNNAMED_2819735065880[u40]];
                            u46[UNNAMED_2819735047544[u40 + 1]] = UNNAMED_2819735090456[u40];
                            local v440;

                            if u39[2] then
                                v440 = UNNAMED_2819735070824[u40 + 1] - 1;
                            else
                                v440 = UNNAMED_2819735027960[u40] - 1;
                            end;

                            u40 = v440;
                            u40 = u40 + 1;
                        end;
                    elseif v270 < 9 then
                        if v270 >= 7 then
                            if v270 == 8 then
                                return false, false;
                            end;

                            u40 = UNNAMED_2819735070824[u40];
                        else
                            u46[UNNAMED_2819735047544[u40 + 1]][UNNAMED_2819735090456[u40 + 1]] = UNNAMED_2819735065880[u40];
                            local v441;

                            if u39[14] then
                                v441 = UNNAMED_2819735064680[u40 + 1] - 1;
                            else
                                v441 = UNNAMED_2819735070824[u40] - 1;
                            end;

                            u40 = v441;
                            u40 = u40 + 1;
                        end;
                    elseif v270 < 11 then
                        if v270 == 10 then
                            u46[UNNAMED_2819735090456[u40]][UNNAMED_2819735090456[u40 + 1]] = UNNAMED_2819735065880[u40];
                            local v442;

                            if u39[14] then
                                v442 = UNNAMED_2819735027960[u40] - 1;
                            else
                                v442 = UNNAMED_2819735064680[u40 + 1] - 1;
                            end;

                            u40 = v442;
                            u40 = u40 + 1;
                        else
                            u40 = UNNAMED_2819735070824[u40];
                        end;
                    else
                        if v270 == 12 then
                            local v443 = u19[UNNAMED_2819735064680[u40]];
                            v443[5][v443[4]] = u39[14];

                            return false, false;
                        end;

                        u39[2] = u46[UNNAMED_2819735090456[u40]];
                        local v444;

                        if u39[2] then
                            v444 = UNNAMED_2819735064680[u40];
                        else
                            v444 = UNNAMED_2819735027960[u40];
                        end;

                        u40 = v444;
                    end;

                    u40 = u40 + 1;
                end;
            end;
        end, ...);

        if v445 then
            if v446 then
                if v447 then
                    return u39[v448](u44(v449, 1, v449.n));
                end;

                return u39[v448](u44(u39, v448 + 1, v449));
            end;

            if v448 then
                if v447 then
                    return u44(v448, 1, v448.n);
                end;

                return u44(u39, v448, v449);
            end;
        else
            u37(UNNAMED_2819735049656, v446, u40, UNNAMED_2819735084312);
        end;
    end;
end;