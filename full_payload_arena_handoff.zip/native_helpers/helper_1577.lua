-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3) -- Line: 3
    -- upvalues: UNNAMED_2819735053400 (copy)
    local u4 = p1[1];
    local u5 = p1[2];
    local u6 = p1[3];

    return function() -- Line: 3
        -- upvalues: UNNAMED_2819735053400 (ref), u4 (copy), u5 (copy), u6 (copy)
        local v7 = 4;
        local v8 = nil;
        local v9 = nil;
        local v10 = nil;
        local v11 = nil;
        local v12 = nil;
        local v13 = nil;
        local v14 = nil;
        local v15 = nil;
        local v16 = nil;
        local v17 = nil;
        local v18 = nil;
        local v19 = nil;
        local v20 = nil;
        local v21 = nil;

        while true do
            while v7 <= 5 do
                if v7 <= 2 then
                    if v7 <= 0 then
                        v10 = {
                            1,
                            nil,
                            v9 - 1,
                            v10,
                            v8 - 1 + 0
                        };
                        v7 = 2;
                    elseif v7 <= 1 then
                        local v22 = UNNAMED_2819735053400[110](v11 + 1, 255);
                        v21 = UNNAMED_2819735053400[110](v13 + v12[v22], 255);
                        local v23 = v12[v22];
                        v12[v22] = v12[v21];
                        v12[v21] = v23;
                        v11 = UNNAMED_2819735053400[84](v12[UNNAMED_2819735053400[110](v12[v22] + v12[v21], 255)], 0);
                        v13 = v22 + 1;
                        v7 = 8;
                        v20 = 0;
                    else
                        local v24 = v10[1];
                        local v25 = v10[5];
                        local v26 = v10[3] + v24;
                        local v27 = v24 <= 0;
                        local v28 = v25 <= v26;
                        v10[3] = v26;

                        if v27 and v28 and v28 or not v27 and v26 <= v25 then
                            v20 = v26;
                            v7 = 10;
                        else
                            v7 = 9;
                        end;
                    end;
                elseif v7 <= 3 then
                    v10 = v10[1];
                    v7 = 0;
                elseif v7 <= 4 then
                    v16 = u4[5][u4[4]];
                    v17 = u5[5][u5[4]];
                    v8 = UNNAMED_2819735053400[0](v16) - v17;
                    v12 = u6[5][u6[4]];
                    v14 = UNNAMED_2819735053400[4](v8);
                    v9 = v8 - v8 % 4;
                    v10 = {
                        v10,
                        nil,
                        v9 - 1 + 0,
                        -4,
                        4
                    };
                    v7 = 6;
                    v11 = 0;
                    v13 = 0;
                else
                    local v29 = UNNAMED_2819735053400[110](v18, 255);
                    local v30 = v12[v19];
                    v12[v19] = v12[v29];
                    v12[v29] = v30;
                    local v31 = UNNAMED_2819735053400[92](v20, v11, v13, v21, (UNNAMED_2819735053400[84](v12[UNNAMED_2819735053400[110](v12[v19] + v12[v29], 255)], 24)));
                    UNNAMED_2819735053400[105](v14, v15, (UNNAMED_2819735053400[11](UNNAMED_2819735053400[5](v16, v17 + v15), v31)));
                    v13 = v29;
                    v20 = v19;
                    v21 = v13;
                    v11 = v20;
                    local v32 = v13;
                    v13 = v21;
                    v32 = v20;
                    v20 = v11;
                    v32 = v21;
                    v21 = v13;
                    v32 = v11;
                    v7 = 6;
                end;
            end;

            if v7 <= 8 then
                if v7 <= 6 then
                    local v33 = v10[5];
                    local v34 = v10[3];
                    local v35 = v10[4] + v33;
                    local v36 = v33 <= 0;
                    local v37 = v34 <= v35;
                    v10[4] = v35;

                    if v36 and v37 and v37 or not v36 and v35 <= v34 then
                        v15 = v35;
                        v7 = 1;
                    else
                        v7 = 3;
                    end;
                else
                    if v7 <= 7 then
                        return v14;
                    end;

                    local v38 = UNNAMED_2819735053400[110](v13, 255);
                    v21 = UNNAMED_2819735053400[110](v21 + v12[v38], 255);
                    local v39 = v12[v38];
                    v12[v38] = v12[v21];
                    v12[v21] = v39;
                    v13 = UNNAMED_2819735053400[84](v12[UNNAMED_2819735053400[110](v12[v38] + v12[v21], 255)], 8);
                    v19 = UNNAMED_2819735053400[110](v38 + 1, 255);
                    v7 = 11;
                end;
            elseif v7 <= 9 then
                v10 = v10[4];
                v7 = 7;
            elseif v7 <= 10 then
                v11 = UNNAMED_2819735053400[110](v11 + 1, 255);
                v13 = UNNAMED_2819735053400[110](v13 + v12[v11], 255);
                local v40 = v12[v11];
                v12[v11] = v12[v13];
                v12[v13] = v40;
                local v41 = v12[UNNAMED_2819735053400[110](v12[v11] + v12[v13], 255)];
                UNNAMED_2819735053400[93](v14, v20, (UNNAMED_2819735053400[11](UNNAMED_2819735053400[22](v16, v17 + v20), v41)));
                v7 = 2;
            else
                local v42 = UNNAMED_2819735053400[110](v21 + v12[v19], 255);
                local v43 = v12[v19];
                v12[v19] = v12[v42];
                v12[v42] = v43;
                v21 = UNNAMED_2819735053400[84](v12[UNNAMED_2819735053400[110](v12[v19] + v12[v42], 255)], 16);
                v19 = UNNAMED_2819735053400[110](v19 + 1, 255);
                v18 = v42 + v12[v19];
                v7 = 5;
            end;
        end;
    end;
end;