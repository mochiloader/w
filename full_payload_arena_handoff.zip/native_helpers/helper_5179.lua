-- Decompiled with Potassium's decompiler.

local v1 = nil;

for i = 3, UNNAMED_2819735037848 do
    v1 = { UNNAMED_2819735040056, UNNAMED_2819735029592, function() -- Line: 69
            -- upvalues: UNNAMED_2819735058104 (ref)
            for i2 = 1, UNNAMED_2819735058104 do
                local _ = i2;
            end;
        end };
    local _ = i;
end;

return v1[3];