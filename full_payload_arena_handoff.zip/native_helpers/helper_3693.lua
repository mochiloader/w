-- Decompiled with Potassium's decompiler.

-- Decompilation failed: internal error: entered unreachable code: BC { op_code: LOP_LOADKX, a: 12, b: 58, c: 0, aux: 2147483651 }