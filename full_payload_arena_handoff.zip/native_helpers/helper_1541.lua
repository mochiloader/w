-- Decompiled with Potassium's decompiler.

return function(p1, p2, p3, p4) -- Line: 3
    local u5 = p1[1];
    local u6 = p1[2];
    local u7 = p1[3];

    return function() -- Line: 3
        -- upvalues: u5 (copy), u6 (copy), u7 (copy)
        local v8 = 1;

        while v8 > 0 do
            u5[5][u5[4]] = true;
            u6[5][u6[4]] = u6[5][u6[4]] - u6[5][u6[4]] % 2 + 1;
            u7[5][u7[4]] = (944041 * u7[5][u7[4]] + 10745363) % 268435456;
            u7[5][u7[4]] = (374617 * u7[5][u7[4]] + 92144255) % 268435456;
            v8 = 0;
        end;
    end;
end;