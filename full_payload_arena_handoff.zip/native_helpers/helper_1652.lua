-- Decompiled with Potassium's decompiler.

(...)[...] = nil;